const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

let mainWindow;
let db;

// Create data directories
const dataDir = path.join(app.getPath('userData'), 'data');
const dbDir = path.join(dataDir, 'database');
const backupsDir = path.join(dataDir, 'backups');
const schemasDir = path.join(dataDir, 'schemas');
const modulesDir = path.join(dataDir, 'modules');

function createDirectories() {
  [dataDir, dbDir, backupsDir, schemasDir, modulesDir].forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });
}

function initDatabase() {
  const dbPath = path.join(dbDir, 'app.sqlite');
  db = new Database(dbPath);
  
  // Enable foreign keys
  db.pragma('foreign_keys = ON');
  
  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS memos (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT,
      type TEXT DEFAULT 'general',
      priority TEXT DEFAULT 'medium',
      tags TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      author_id TEXT,
      status TEXT DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS test_requests (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      type TEXT NOT NULL,
      priority TEXT DEFAULT 'medium',
      status TEXT DEFAULT 'pending',
      requested_by TEXT,
      assigned_to TEXT,
      due_date DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME,
      test_data TEXT,
      results TEXT
    );

    CREATE TABLE IF NOT EXISTS user_profiles (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      full_name TEXT,
      role TEXT DEFAULT 'lab_technician',
      department TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME,
      status TEXT DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS user_roles (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      permissions TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS schema_versions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      version TEXT NOT NULL,
      applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      description TEXT
    );

    -- Developer Mode tables
    CREATE TABLE IF NOT EXISTS form_definitions (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      fields TEXT NOT NULL,
      placement TEXT DEFAULT 'dashboard',
      module_id TEXT,
      custom_route TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_by TEXT
    );

    CREATE TABLE IF NOT EXISTS table_definitions (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      columns TEXT NOT NULL,
      data_source TEXT NOT NULL,
      features TEXT,
      placement TEXT DEFAULT 'dashboard',
      module_id TEXT,
      custom_route TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_by TEXT
    );

    CREATE TABLE IF NOT EXISTS component_definitions (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      component_code TEXT NOT NULL,
      props_schema TEXT,
      placement TEXT DEFAULT 'dashboard',
      module_id TEXT,
      custom_route TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_by TEXT
    );

    CREATE TABLE IF NOT EXISTS workflow_definitions (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      trigger_config TEXT NOT NULL,
      steps TEXT NOT NULL,
      placement TEXT DEFAULT 'dashboard',
      module_id TEXT,
      is_active BOOLEAN DEFAULT TRUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_by TEXT
    );

    CREATE TABLE IF NOT EXISTS api_endpoint_definitions (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      method TEXT NOT NULL,
      path TEXT NOT NULL,
      request_schema TEXT,
      response_schema TEXT,
      placement TEXT DEFAULT 'dashboard',
      module_id TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_by TEXT
    );
  `);

  // Insert default roles if they don't exist
  const insertRole = db.prepare(`
    INSERT OR IGNORE INTO user_roles (id, name, description, permissions)
    VALUES (?, ?, ?, ?)
  `);

  insertRole.run('admin', 'Administrator', 'Full system access', JSON.stringify(['*']));
  insertRole.run('lab', 'Lab Technician', 'Lab operations access', JSON.stringify(['lab.*', 'test.*']));
  insertRole.run('qa', 'Quality Assurance', 'QA operations access', JSON.stringify(['qa.*', 'test.read']));
  
  console.log('Database initialized');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  // Load the app
  if (process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:8080');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  createDirectories();
  initDatabase();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    if (db) db.close();
    app.quit();
  }
});

// IPC Handlers for database operations
ipcMain.handle('db-query', async (event, sql, params = []) => {
  try {
    const stmt = db.prepare(sql);
    const result = stmt.all(params);
    return { success: true, data: result };
  } catch (error) {
    console.error('Database query error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('db-run', async (event, sql, params = []) => {
  try {
    const stmt = db.prepare(sql);
    const result = stmt.run(params);
    return { success: true, data: result };
  } catch (error) {
    console.error('Database run error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('db-backup', async (event) => {
  try {
    const timestamp = new Date().toISOString().slice(0, 10);
    const backupPath = path.join(backupsDir, `backup-${timestamp}.sqlite`);
    
    // Create backup
    db.backup(backupPath);
    
    return { success: true, path: backupPath };
  } catch (error) {
    console.error('Backup error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('db-restore', async (event, backupPath) => {
  try {
    // Close current database
    if (db) db.close();
    
    // Copy backup to main database
    const mainDbPath = path.join(dbDir, 'app.sqlite');
    fs.copyFileSync(backupPath, mainDbPath);
    
    // Reinitialize database
    initDatabase();
    
    return { success: true };
  } catch (error) {
    console.error('Restore error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('export-data', async (event, format) => {
  try {
    const result = await dialog.showSaveDialog(mainWindow, {
      filters: [
        { name: 'JSON', extensions: ['json'] },
        { name: 'SQLite', extensions: ['sqlite'] }
      ]
    });

    if (result.canceled) return { success: false, canceled: true };

    if (format === 'json') {
      // Export as JSON
      const data = {
        memos: db.prepare('SELECT * FROM memos').all(),
        test_requests: db.prepare('SELECT * FROM test_requests').all(),
        user_profiles: db.prepare('SELECT * FROM user_profiles').all(),
        user_roles: db.prepare('SELECT * FROM user_roles').all(),
        exported_at: new Date().toISOString()
      };
      
      fs.writeFileSync(result.filePath, JSON.stringify(data, null, 2));
    } else {
      // Export as SQLite backup
      db.backup(result.filePath);
    }

    return { success: true, path: result.filePath };
  } catch (error) {
    console.error('Export error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('import-data', async (event) => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, {
      filters: [
        { name: 'JSON', extensions: ['json'] },
        { name: 'SQLite', extensions: ['sqlite'] }
      ]
    });

    if (result.canceled) return { success: false, canceled: true };

    const filePath = result.filePaths[0];
    const ext = path.extname(filePath);

    if (ext === '.json') {
      // Import JSON data
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      
      // Begin transaction
      const transaction = db.transaction(() => {
        // Clear existing data
        db.prepare('DELETE FROM memos').run();
        db.prepare('DELETE FROM test_requests').run();
        db.prepare('DELETE FROM user_profiles').run();
        
        // Insert imported data
        if (data.memos) {
          const insertMemo = db.prepare(`
            INSERT INTO memos (id, title, content, type, priority, tags, created_at, updated_at, author_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          data.memos.forEach(memo => insertMemo.run(Object.values(memo)));
        }

        if (data.test_requests) {
          const insertTest = db.prepare(`
            INSERT INTO test_requests (id, title, description, type, priority, status, requested_by, assigned_to, due_date, created_at, updated_at, completed_at, test_data, results)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          data.test_requests.forEach(test => insertTest.run(Object.values(test)));
        }

        if (data.user_profiles) {
          const insertProfile = db.prepare(`
            INSERT INTO user_profiles (id, username, email, full_name, role, department, created_at, updated_at, last_login, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          data.user_profiles.forEach(profile => insertProfile.run(Object.values(profile)));
        }
      });

      transaction();
    } else {
      // Import SQLite backup
      if (db) db.close();
      const mainDbPath = path.join(dbDir, 'app.sqlite');
      fs.copyFileSync(filePath, mainDbPath);
      initDatabase();
    }

    return { success: true };
  } catch (error) {
    console.error('Import error:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-app-paths', async () => {
  return {
    userData: app.getPath('userData'),
    dataDir,
    dbDir,
    backupsDir,
    schemasDir,
    modulesDir
  };
});

// PDF Generation Handler
ipcMain.handle('generate-pdf', async (event, data, template) => {
  try {
    const puppeteer = require('puppeteer');
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    // Generate HTML content based on template and data
    let htmlContent = generateHTMLTemplate(data, template);
    
    await page.setContent(htmlContent);
    
    // Get save path from user
    const result = await dialog.showSaveDialog(mainWindow, {
      filters: [{ name: 'PDF', extensions: ['pdf'] }],
      defaultPath: `export_${new Date().toISOString().slice(0, 10)}.pdf`
    });

    if (result.canceled) {
      await browser.close();
      return { success: false, canceled: true };
    }

    // Generate PDF
    await page.pdf({
      path: result.filePath,
      format: 'A4',
      printBackground: true,
      margin: {
        top: '20mm',
        right: '20mm',
        bottom: '20mm',
        left: '20mm'
      }
    });

    await browser.close();
    return { success: true, path: result.filePath };
  } catch (error) {
    console.error('PDF generation error:', error);
    return { success: false, error: error.message };
  }
});

// File Save Handler (for binary/general data)
ipcMain.handle('save-file-data', async (event, data, filename) => {
  try {
    const uploadsDir = path.join(dataDir, 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    if (filename.includes('/')) {
      // Handle subdirectories
      const fullPath = path.join(dataDir, filename);
      const dir = path.dirname(fullPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      if (Buffer.isBuffer(data)) {
        fs.writeFileSync(fullPath, data);
      } else {
        fs.writeFileSync(fullPath, data);
      }
      
      return { success: true, path: fullPath };
    } else {
      const result = await dialog.showSaveDialog(mainWindow, {
        defaultPath: filename
      });

      if (result.canceled) return { success: false, canceled: true };

      if (Buffer.isBuffer(data)) {
        fs.writeFileSync(result.filePath, data);
      } else {
        fs.writeFileSync(result.filePath, data);
      }
      return { success: true, path: result.filePath };
    }
  } catch (error) {
    console.error('File save error:', error);
    return { success: false, error: error.message };
  }
});

// Email sending handler
ipcMain.handle('send-email', async (event, { config, message }) => {
  try {
    const nodemailer = require('nodemailer');
    
    // Create transporter
    const transporter = nodemailer.createTransporter({
      host: config.smtpHost,
      port: config.smtpPort,
      secure: config.security === 'ssl',
      auth: {
        user: config.username,
        pass: config.password
      },
      tls: {
        rejectUnauthorized: false
      }
    });

    // Send email
    const info = await transporter.sendMail({
      from: `"${config.fromName}" <${config.fromEmail}>`,
      to: message.to.join(', '),
      cc: message.cc ? message.cc.join(', ') : undefined,
      bcc: message.bcc ? message.bcc.join(', ') : undefined,
      subject: message.subject,
      html: message.html,
      text: message.text,
      attachments: message.attachments
    });

    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
});

// File save handler for CSV exports
ipcMain.handle('save-file', async (event, filename, content) => {
  try {
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: filename,
      filters: [
        { name: 'CSV Files', extensions: ['csv'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });

    if (result.canceled) {
      return { success: false, canceled: true };
    }

    fs.writeFileSync(result.filePath, content, 'utf8');
    return { success: true, path: result.filePath };
  } catch (error) {
    console.error('File save error:', error);
    return { success: false, error: error.message };
  }
});

function generateHTMLTemplate(data, template) {
  // Basic HTML template generator
  const baseStyles = `
    <style>
      body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
      .header { text-align: center; margin-bottom: 30px; }
      .content { margin-bottom: 20px; }
      .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
      table { width: 100%; border-collapse: collapse; margin: 20px 0; }
      th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
      th { background-color: #f2f2f2; }
    </style>
  `;

  if (template === 'memo') {
    return `
      <!DOCTYPE html>
      <html>
      <head>${baseStyles}</head>
      <body>
        <div class="header">
          <h1>Laboratory Memo Report</h1>
          <p>Generated on ${new Date().toLocaleString()}</p>
        </div>
        <div class="content">
          <h2>Memo Details</h2>
          <p><strong>Title:</strong> ${data.title || 'N/A'}</p>
          <p><strong>Content:</strong> ${data.content || 'N/A'}</p>
          <p><strong>Type:</strong> ${data.type || 'N/A'}</p>
          <p><strong>Priority:</strong> ${data.priority || 'N/A'}</p>
          <p><strong>Created:</strong> ${data.created_at || 'N/A'}</p>
        </div>
        <div class="footer">
          <p>Laboratory Management System - Confidential</p>
        </div>
      </body>
      </html>
    `;
  }

  // Default template
  return `
    <!DOCTYPE html>
    <html>
    <head>${baseStyles}</head>
    <body>
      <div class="header">
        <h1>Laboratory Report</h1>
        <p>Generated on ${new Date().toLocaleString()}</p>
      </div>
      <div class="content">
        <pre>${JSON.stringify(data, null, 2)}</pre>
      </div>
      <div class="footer">
        <p>Laboratory Management System - Confidential</p>
      </div>
    </body>
    </html>
  `;
}