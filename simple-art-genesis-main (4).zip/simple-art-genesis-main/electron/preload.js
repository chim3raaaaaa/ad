const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Database operations
  dbQuery: (sql, params) => ipcRenderer.invoke('db-query', sql, params),
  dbRun: (sql, params) => ipcRenderer.invoke('db-run', sql, params),
  
  // Backup and restore
  createBackup: () => ipcRenderer.invoke('db-backup'),
  restoreBackup: (backupPath) => ipcRenderer.invoke('db-restore', backupPath),
  
  // Data export/import
  exportData: (format) => ipcRenderer.invoke('export-data', format),
  importData: () => ipcRenderer.invoke('import-data'),
  
  // App paths
  getAppPaths: () => ipcRenderer.invoke('get-app-paths'),
  
  // PDF generation
  generatePDF: (data, template) => ipcRenderer.invoke('generate-pdf', data, template),
  
  // File operations
  saveFile: (filename, content) => ipcRenderer.invoke('save-file', filename, content),
  saveFileData: (data, filename) => ipcRenderer.invoke('save-file-data', data, filename),
  
  // Email operations
  sendEmail: (emailData) => ipcRenderer.invoke('send-email', emailData)
});