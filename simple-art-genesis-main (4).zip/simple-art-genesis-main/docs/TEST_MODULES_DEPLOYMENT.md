# Test Modules System - Deployment Guide

## Overview

The enhanced Test Modules system provides a data-driven, cross-platform solution for managing laboratory test configurations, entries, and plant-specific data. This guide covers deployment, configuration, and maintenance procedures.

## Architecture

### Cross-Platform Design
- **Electron Mode**: Uses local SQLite databases via `window.electronAPI`
- **Browser Mode**: Calls REST API endpoints with server-side persistence
- **Unified Interface**: Same service methods work in both environments

### Key Components
1. **TestModulesAPI**: Cross-platform data access layer
2. **DynamicFormBuilder**: Runtime form generation based on database metadata
3. **EnhancedTestModulesHub**: Main UI with role-based permissions
4. **TestModulesFieldManager**: Admin interface for field configuration
5. **Migration Service**: Database schema management and seeding

## Database Schema

### Core Tables

```sql
-- Product Categories
CREATE TABLE product_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT DEFAULT 'TestTube',
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Product Types
CREATE TABLE product_types (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  table_suffix TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES product_categories(id)
);

-- Product Fields (Dynamic Form Configuration)
CREATE TABLE product_fields (
  id TEXT PRIMARY KEY,
  product_type_id TEXT NOT NULL,
  field_name TEXT NOT NULL,
  field_label TEXT NOT NULL,
  field_type TEXT CHECK (field_type IN ('text', 'number', 'date', 'select', 'textarea', 'boolean', 'file')),
  field_unit TEXT,
  is_required BOOLEAN DEFAULT 0,
  validation_rules JSON DEFAULT '[]',
  field_options JSON,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  UNIQUE (product_type_id, field_name)
);

-- Test Entries
CREATE TABLE test_entries (
  id TEXT PRIMARY KEY,
  product_type_id TEXT NOT NULL,
  memo_id TEXT,
  plant_id TEXT NOT NULL,
  officer_id TEXT NOT NULL,
  test_date DATE NOT NULL,
  test_data JSON NOT NULL,
  status TEXT CHECK (status IN ('draft', 'submitted', 'approved', 'rejected')) DEFAULT 'draft',
  notes TEXT,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id)
);

-- Plant Configuration
CREATE TABLE plant_configurations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  location TEXT,
  contact_info JSON DEFAULT '{}',
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Plant Machines
CREATE TABLE plant_machines (
  id TEXT PRIMARY KEY,
  plant_id TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  specifications JSON DEFAULT '{}',
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (plant_id) REFERENCES plant_configurations(id),
  UNIQUE (plant_id, name)
);

-- Plant Officers
CREATE TABLE plant_officers (
  id TEXT PRIMARY KEY,
  plant_id TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  contact_info JSON DEFAULT '{}',
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (plant_id) REFERENCES plant_configurations(id)
);

-- Memo Test Assignments
CREATE TABLE memo_test_assignments (
  id TEXT PRIMARY KEY,
  memo_id TEXT NOT NULL,
  product_type_id TEXT NOT NULL,
  required_tests JSON DEFAULT '[]',
  assigned_to TEXT,
  due_date DATE,
  status TEXT CHECK (status IN ('pending', 'in_progress', 'completed', 'overdue')) DEFAULT 'pending',
  test_entry_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (test_entry_id) REFERENCES test_entries(id),
  UNIQUE (memo_id, product_type_id)
);
```

### Dynamic Test Data Tables
For each product type, a corresponding test data table is created:
```sql
CREATE TABLE test_data_{table_suffix} (
  id TEXT PRIMARY KEY,
  test_entry_id TEXT NOT NULL,
  field_data JSON NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (test_entry_id) REFERENCES test_entries(id)
);
```

## Deployment Steps

### 1. Electron Application Setup

1. **Migration Execution**:
   ```typescript
   import { TestModulesMigrationService } from '@/services/database/testModulesMigrationService';
   
   // Run during app initialization
   await TestModulesMigrationService.runMigrations();
   ```

2. **Default Data Seeding**:
   ```typescript
   // Seeds default categories and basic configuration
   await TestModulesMigrationService.seedDefaultData();
   ```

3. **Electron Security Configuration**:
   ```javascript
   // electron/main.js
   const electronAPI = {
     dbQuery: (query, params) => {
       // Implement SQLite query execution
       // Add proper error handling and validation
     }
   };
   ```

### 2. Server-Side API Setup

1. **Environment Configuration**:
   ```env
   # .env
   DATABASE_URL=postgresql://user:password@localhost:5432/lims_db
   API_PORT=3001
   JWT_SECRET=your-jwt-secret
   NODE_ENV=production
   ```

2. **API Server Deployment**:
   ```typescript
   import { createTestModulesServerAPI } from '@/services/api/testModulesServerAPI';
   
   const apiClient = createTestModulesServerAPI({
     baseUrl: 'https://your-api-domain.com',
     apiKey: process.env.API_KEY,
     timeout: 30000
   });
   ```

3. **Database Migration for Server**:
   ```sql
   -- Run the schema SQL scripts on your production database
   -- Ensure proper indexing for performance:
   
   CREATE INDEX idx_test_entries_product_type ON test_entries(product_type_id);
   CREATE INDEX idx_test_entries_plant_date ON test_entries(plant_id, test_date);
   CREATE INDEX idx_test_entries_memo ON test_entries(memo_id);
   CREATE INDEX idx_product_fields_type_order ON product_fields(product_type_id, sort_order);
   CREATE INDEX idx_memo_assignments_memo ON memo_test_assignments(memo_id);
   CREATE INDEX idx_memo_assignments_assigned ON memo_test_assignments(assigned_to, status);
   ```

### 3. Frontend Configuration

1. **Update Main Application**:
   ```typescript
   // Replace TestModulesHub with EnhancedTestModulesHub in src/pages/TestModules.tsx
   import { EnhancedTestModulesHub } from '@/components/test-modules/EnhancedTestModulesHub';
   ```

2. **Reference Data Manager Integration**:
   ```typescript
   // Add TestModulesFieldManager to Reference Data Manager tabs
   import { TestModulesFieldManager } from '@/components/reference-data/TestModulesFieldManager';
   ```

3. **Role-Based Access Control**:
   ```typescript
   // Ensure proper role definitions in your auth system
   const roles = {
     'Lab Admin': ['test_module_admin', 'field_config', 'plant_config'],
     'Manager': ['test_entry', 'plant_config', 'view_all'],
     'Lab Technician': ['test_entry', 'view_assigned'],
     'Plant Officer': ['memo_create', 'view_status']
   };
   ```

## Configuration Guide

### 1. Initial Setup

1. **Access Reference Data Manager** (Lab Admin only):
   - Navigate to Settings → Reference Data Manager
   - Select "Test Modules Field Configuration" tab

2. **Configure Product Categories**:
   - Default categories (Aggregates, Concrete, Blocks) are pre-seeded
   - Add custom categories as needed with appropriate icons

3. **Configure Product Types**:
   - For each category, define specific product types
   - Each product type gets a unique table suffix for data storage

4. **Configure Fields**:
   - Select a product type
   - Add dynamic fields with:
     - Field name (database column name)
     - Display label
     - Data type (text, number, date, select, etc.)
     - Units and validation rules
     - Required status

### 2. Plant Configuration

1. **Plant Setup**:
   ```typescript
   // Configure plants with machines and officers
   const plantConfig = {
     name: 'Plant A - Aggregates',
     location: 'Industrial Zone 1',
     contact_info: {
       phone: '+230-123-4567',
       email: 'plant-a@company.com'
     },
     machines: [
       {
         name: 'Crusher Unit 1',
         type: 'Primary Crusher',
         specifications: {
           capacity: '200 tons/hour',
           power: '500 kW'
         }
       }
     ],
     officers: [
       {
         name: 'John Doe',
         role: 'Production Manager',
         contact_info: {
           phone: '+230-987-6543',
           email: 'john.doe@company.com'
         }
       }
     ]
   };
   ```

### 3. Memo Integration

1. **Test Assignment Workflow**:
   - Memos automatically create test assignments
   - Assignments track required tests per product type
   - Test entries link back to memo assignments
   - Completion updates memo status

2. **Assignment Management**:
   - Lab technicians can view assigned tests
   - Plant officers can track memo progress
   - Managers have overview of all assignments

## Usage Guide

### For Lab Administrators

1. **Field Configuration**:
   - Use TestModulesFieldManager to add/edit fields
   - Configure validation rules for data quality
   - Set field ordering for logical form flow

2. **Plant Management**:
   - Configure plant-specific machines and officers
   - Enable/disable plants as needed
   - Maintain contact information

### For Lab Technicians

1. **Test Data Entry**:
   - Forms are dynamically generated based on field configuration
   - Validation ensures data quality
   - Save as draft or submit for approval

2. **Memo Assignment Management**:
   - View assigned tests from memo integration
   - Mark tests as complete upon entry
   - Track assignment status and due dates

### For Plant Officers

1. **Memo Creation**:
   - Create memos that trigger test assignments
   - Track test completion status
   - Receive notifications on test completion

## Maintenance

### 1. Database Maintenance

1. **Regular Backups**:
   ```bash
   # For SQLite (Electron)
   sqlite3 lims_database.db ".backup backup_$(date +%Y%m%d_%H%M%S).db"
   
   # For PostgreSQL (Server)
   pg_dump -h localhost -U username database_name > backup_$(date +%Y%m%d_%H%M%S).sql
   ```

2. **Performance Monitoring**:
   - Monitor query performance on test_entries table
   - Add indexes for frequently filtered columns
   - Archive old test data periodically

### 2. System Updates

1. **Schema Migrations**:
   ```typescript
   // Add new migration to TestModulesMigrationService
   const migration_v2 = {
     version: '2.0.0',
     description: 'Add new field types',
     sql: `
       ALTER TABLE product_fields ADD COLUMN field_group TEXT;
       CREATE INDEX idx_product_fields_group ON product_fields(field_group);
     `
   };
   ```

2. **Data Migration**:
   ```typescript
   // Migrate existing data when field configurations change
   await TestModulesMigrationService.migrateTestData(oldSchema, newSchema);
   ```

### 3. Monitoring and Troubleshooting

1. **Error Logging**:
   - Monitor console logs for API failures
   - Track form validation errors
   - Log database connectivity issues

2. **Performance Metrics**:
   - Form rendering time
   - Database query performance
   - API response times

3. **User Activity Tracking**:
   - Track field configuration changes
   - Monitor test entry patterns
   - Audit data modifications

## Security Considerations

### 1. Role-Based Access Control
- Field configuration restricted to Lab Admin/Manager roles
- Test entry permissions based on plant assignments
- Audit trail for all configuration changes

### 2. Data Validation
- Server-side validation for all inputs
- SQL injection prevention through parameterized queries
- File upload restrictions and scanning

### 3. Cross-Platform Security
- Electron: Secure IPC communication
- Browser: HTTPS and JWT token authentication
- Database: Encrypted connections and proper user permissions

## Support and Extensions

### Adding New Field Types

1. **Extend ValidationRule Types**:
   ```typescript
   interface ValidationRule {
     type: 'min' | 'max' | 'pattern' | 'custom' | 'regex' | 'range';
     value: any;
     message: string;
   }
   ```

2. **Update DynamicFormBuilder**:
   ```typescript
   // Add new field type rendering
   case 'multiselect':
     return <MultiSelectInput {...fieldProps} />;
   ```

### Custom Plant Integration

1. **Extend Plant Configuration**:
   ```sql
   ALTER TABLE plant_configurations ADD COLUMN custom_config JSON DEFAULT '{}';
   ```

2. **Add Plant-Specific Validation**:
   ```typescript
   // Plant-specific validation rules
   const plantValidation = {
     plantId: 'plant-a',
     customRules: [
       { field: 'aggregate_size', rule: 'range', min: 5, max: 20 }
     ]
   };
   ```

## Conclusion

The enhanced Test Modules system provides a robust, flexible foundation for laboratory data management. The data-driven approach allows for easy customization without code changes, while the cross-platform design ensures compatibility across deployment environments.

For additional support or custom requirements, refer to the system documentation or contact the development team.