# Test Modules API Documentation

## Overview

The Test Modules API provides comprehensive endpoints for managing dynamic test configurations, data entry, and plant-specific information in the LIMS system. The API supports both Electron (SQLite) and browser (REST) environments with a unified interface.

## Base URLs

- **Development**: `http://localhost:3001/api/v1`
- **Production**: `https://your-api-domain.com/api/v1`
- **Electron**: Uses `window.electronAPI.dbQuery()` instead of HTTP

## Authentication

All API endpoints require authentication except for health checks.

### Headers
```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

## Product Categories

Manage test product categories (Aggregates, Concrete, Blocks, etc.)

### GET /test-modules/categories

Get all active product categories.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "aggregates",
      "name": "Aggregates",
      "description": "Sand, gravel, and crushed stone testing",
      "icon": "TestTube",
      "sort_order": 1,
      "is_active": true,
      "created_by": "admin",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

### POST /test-modules/categories

Create a new product category.

**Request:**
```json
{
  "name": "Concrete Products",
  "description": "All concrete-based testing procedures",
  "icon": "Building",
  "sort_order": 5,
  "is_active": true
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "generated-uuid",
    "message": "Category created successfully"
  }
}
```

### PUT /test-modules/categories/{id}

Update an existing product category.

**Request:**
```json
{
  "name": "Updated Category Name",
  "description": "Updated description",
  "sort_order": 10
}
```

### DELETE /test-modules/categories/{id}

Soft delete a product category (sets is_active to false).

## Product Types

Manage specific product types within categories.

### GET /test-modules/types

Get product types, optionally filtered by category.

**Query Parameters:**
- `category_id` (optional): Filter by category ID

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "concrete-cubes",
      "category_id": "concrete",
      "name": "Concrete Cubes",
      "description": "Standard concrete cube testing",
      "table_suffix": "concrete_cubes",
      "is_active": true,
      "created_by": "admin",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

### POST /test-modules/types

Create a new product type.

**Request:**
```json
{
  "category_id": "concrete",
  "name": "Concrete Cubes",
  "description": "Standard concrete cube testing",
  "table_suffix": "concrete_cubes",
  "is_active": true
}
```

### PUT /test-modules/types/{id}

Update a product type.

### DELETE /test-modules/types/{id}

Soft delete a product type.

## Product Fields

Manage dynamic field configurations for product types.

### GET /test-modules/fields

Get fields for a specific product type.

**Query Parameters:**
- `product_type_id` (required): Product type ID

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "field-uuid",
      "product_type_id": "concrete-cubes",
      "field_name": "compressive_strength",
      "field_label": "Compressive Strength",
      "field_type": "number",
      "field_unit": "MPa",
      "is_required": true,
      "validation_rules": [
        {
          "type": "min",
          "value": 0,
          "message": "Compressive strength must be positive"
        },
        {
          "type": "max",
          "value": 100,
          "message": "Compressive strength cannot exceed 100 MPa"
        }
      ],
      "field_options": null,
      "sort_order": 1,
      "is_active": true,
      "created_by": "admin",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

### POST /test-modules/fields

Create a new field configuration.

**Request:**
```json
{
  "product_type_id": "concrete-cubes",
  "field_name": "slump_value",
  "field_label": "Slump Value",
  "field_type": "number",
  "field_unit": "mm",
  "is_required": true,
  "validation_rules": [
    {
      "type": "min",
      "value": 0,
      "message": "Slump value must be positive"
    }
  ],
  "sort_order": 2
}
```

### PUT /test-modules/fields/{id}

Update a field configuration.

### DELETE /test-modules/fields/{id}

Soft delete a field configuration.

## Test Entries

Manage actual test data entries.

### GET /test-modules/entries

Get test entries with optional filtering.

**Query Parameters:**
- `product_type_id` (optional): Filter by product type
- `plant_id` (optional): Filter by plant
- `memo_id` (optional): Filter by memo
- `status` (optional): Filter by status (draft, submitted, approved, rejected)
- `date_from` (optional): Filter by date range (YYYY-MM-DD)
- `date_to` (optional): Filter by date range (YYYY-MM-DD)
- `page` (optional): Page number for pagination
- `limit` (optional): Results per page (default: 50)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "entry-uuid",
      "product_type_id": "concrete-cubes",
      "memo_id": "memo-123",
      "plant_id": "plant-a",
      "officer_id": "officer-1",
      "test_date": "2024-01-15",
      "test_data": {
        "compressive_strength": 35.5,
        "slump_value": 75,
        "water_cement_ratio": 0.45
      },
      "status": "approved",
      "notes": "Standard test procedure followed",
      "created_by": "tech-1",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T14:20:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 150,
    "pages": 3
  }
}
```

### POST /test-modules/entries

Create a new test entry.

**Request:**
```json
{
  "product_type_id": "concrete-cubes",
  "memo_id": "memo-123",
  "plant_id": "plant-a",
  "officer_id": "officer-1",
  "test_date": "2024-01-15",
  "test_data": {
    "compressive_strength": 35.5,
    "slump_value": 75,
    "water_cement_ratio": 0.45
  },
  "status": "submitted",
  "notes": "Test completed per standard procedure"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "generated-uuid",
    "message": "Test entry created successfully",
    "memo_updated": true
  }
}
```

### PUT /test-modules/entries/{id}

Update a test entry.

### DELETE /test-modules/entries/{id}

Delete a test entry.

## Plant Configuration

Manage plant information, machines, and officers.

### GET /test-modules/plants

Get all plant configurations.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "plant-a",
      "name": "Plant A - Aggregates",
      "location": "Industrial Zone 1",
      "contact_info": {
        "phone": "+230-123-4567",
        "email": "plant-a@company.com",
        "manager": "John Smith"
      },
      "machines": [
        {
          "id": "machine-1",
          "plant_id": "plant-a",
          "name": "Crusher Unit 1",
          "type": "Primary Crusher",
          "specifications": {
            "capacity": "200 tons/hour",
            "power": "500 kW",
            "year": 2020
          },
          "is_active": true,
          "created_at": "2024-01-01T00:00:00Z",
          "updated_at": "2024-01-01T00:00:00Z"
        }
      ],
      "officers": [
        {
          "id": "officer-1",
          "plant_id": "plant-a",
          "name": "Jane Doe",
          "role": "Quality Control Officer",
          "contact_info": {
            "phone": "+230-987-6543",
            "email": "jane.doe@company.com"
          },
          "is_active": true,
          "created_at": "2024-01-01T00:00:00Z",
          "updated_at": "2024-01-01T00:00:00Z"
        }
      ],
      "is_active": true,
      "created_by": "admin",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

### POST /test-modules/plants

Create a new plant configuration.

### PUT /test-modules/plants/{id}

Update plant configuration.

### Plant Machines

#### GET /test-modules/plants/{plant_id}/machines

Get machines for a specific plant.

#### POST /test-modules/plants/{plant_id}/machines

Add a machine to a plant.

**Request:**
```json
{
  "name": "Screening Unit 2",
  "type": "Vibrating Screen",
  "specifications": {
    "mesh_size": "20mm",
    "capacity": "150 tons/hour"
  }
}
```

#### PUT /test-modules/plants/{plant_id}/machines/{machine_id}

Update machine information.

#### DELETE /test-modules/plants/{plant_id}/machines/{machine_id}

Remove a machine from a plant.

### Plant Officers

#### GET /test-modules/plants/{plant_id}/officers

Get officers for a specific plant.

#### POST /test-modules/plants/{plant_id}/officers

Add an officer to a plant.

**Request:**
```json
{
  "name": "Robert Johnson",
  "role": "Production Supervisor",
  "contact_info": {
    "phone": "+230-555-0123",
    "email": "robert.johnson@company.com",
    "shift": "Day Shift"
  }
}
```

#### PUT /test-modules/plants/{plant_id}/officers/{officer_id}

Update officer information.

#### DELETE /test-modules/plants/{plant_id}/officers/{officer_id}

Remove an officer from a plant.

## Memo Test Assignments

Manage test assignments linked to memos.

### GET /test-modules/memo-assignments

Get memo test assignments with filtering.

**Query Parameters:**
- `memo_id` (optional): Filter by memo ID
- `assigned_to` (optional): Filter by assigned user
- `status` (optional): Filter by status
- `due_date_from` (optional): Filter by due date range
- `due_date_to` (optional): Filter by due date range

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "assignment-uuid",
      "memo_id": "memo-123",
      "product_type_id": "concrete-cubes",
      "required_tests": [
        "compressive_strength",
        "slump_test",
        "density_test"
      ],
      "assigned_to": "tech-1",
      "due_date": "2024-01-20",
      "status": "in_progress",
      "test_entry_id": null,
      "created_at": "2024-01-15T09:00:00Z",
      "updated_at": "2024-01-15T09:00:00Z"
    }
  ]
}
```

### POST /test-modules/memo-assignments

Create a new memo test assignment.

**Request:**
```json
{
  "memo_id": "memo-123",
  "product_type_id": "concrete-cubes",
  "required_tests": [
    "compressive_strength",
    "slump_test"
  ],
  "assigned_to": "tech-1",
  "due_date": "2024-01-25"
}
```

### PUT /test-modules/memo-assignments/{id}

Update a memo test assignment.

## Validation

Validate field values and test entries.

### POST /test-modules/validate-field

Validate a single field value.

**Request:**
```json
{
  "product_type_id": "concrete-cubes",
  "field_name": "compressive_strength",
  "value": 35.5
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "is_valid": true,
    "message": null
  }
}
```

### POST /test-modules/validate-entry

Validate a complete test entry.

**Request:**
```json
{
  "product_type_id": "concrete-cubes",
  "test_data": {
    "compressive_strength": 35.5,
    "slump_value": 75
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "is_valid": false,
    "field_errors": {
      "water_cement_ratio": "This field is required"
    },
    "general_errors": []
  }
}
```

## Utility Endpoints

System health and maintenance endpoints.

### GET /health

Check system health.

**Response:**
```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "timestamp": "2024-01-15T12:00:00Z",
    "database": "connected",
    "version": "1.0.0"
  }
}
```

### GET /test-modules/schema

Get current database schema information.

### POST /test-modules/migrate

Run database migrations.

**Request:**
```json
{
  "version": "2.0.0"
}
```

### GET /test-modules/export

Export test data.

**Query Parameters:**
- `format` (optional): Export format (json, csv, excel)
- `product_type_id` (optional): Filter by product type
- `date_from` (optional): Date range filter
- `date_to` (optional): Date range filter

### POST /test-modules/import

Import test data.

**Request:**
```json
{
  "format": "json",
  "data": [...],
  "options": {
    "update_existing": false,
    "validate_references": true
  }
}
```

## Error Responses

All endpoints return errors in a consistent format:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "compressive_strength",
      "value": -5,
      "constraint": "must be positive"
    }
  }
}
```

### Error Codes

- `VALIDATION_ERROR`: Input validation failed
- `NOT_FOUND`: Resource not found
- `UNAUTHORIZED`: Authentication required
- `FORBIDDEN`: Insufficient permissions
- `CONFLICT`: Resource already exists
- `INTERNAL_ERROR`: Server error
- `DATABASE_ERROR`: Database operation failed

## Rate Limiting

API endpoints are rate limited:
- **Standard endpoints**: 100 requests per minute
- **Data export**: 10 requests per hour
- **Data import**: 5 requests per hour

## SDK Usage Examples

### JavaScript/TypeScript

```typescript
import { TestModulesAPI } from '@/services/api/testModulesAPI';

// Get categories
const categories = await TestModulesAPI.getProductCategories();

// Create test entry
const entry = await TestModulesAPI.createTestEntry({
  product_type_id: 'concrete-cubes',
  plant_id: 'plant-a',
  officer_id: 'officer-1',
  test_date: '2024-01-15',
  test_data: {
    compressive_strength: 35.5,
    slump_value: 75
  },
  status: 'submitted'
});

// Validate field
const validation = TestModulesAPI.validateField(35.5, fieldConfig);
```

### Python

```python
import requests

base_url = "https://api.your-domain.com/api/v1"
headers = {"Authorization": "Bearer your-jwt-token"}

# Get categories
response = requests.get(f"{base_url}/test-modules/categories", headers=headers)
categories = response.json()

# Create test entry
entry_data = {
    "product_type_id": "concrete-cubes",
    "plant_id": "plant-a",
    "test_data": {"compressive_strength": 35.5}
}
response = requests.post(f"{base_url}/test-modules/entries", 
                        json=entry_data, headers=headers)
```

For additional examples and integration guides, see the main deployment documentation.