import { CustomTable } from '@/components/lab/TableBuilder';
import { CustomForm } from '@/components/lab/FormBuilder';
import { DataLink } from '@/components/lab/DataLinkManager';

export interface TableSchema {
  id: string;
  name: string;
  description: string;
  columns: Array<{
    id: string;
    name: string;
    type: string;
    required: boolean;
    unique: boolean;
    defaultValue?: string;
    options?: string[];
  }>;
  dataSource: string;
  features: {
    sorting: boolean;
    filtering: boolean;
    search: boolean;
    pagination: boolean;
    export: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

export interface FormSchema {
  id: string;
  name: string;
  description: string;
  fields: Array<{
    id: string;
    name: string;
    type: string;
    label: string;
    placeholder?: string;
    required: boolean;
    validation?: {
      minLength?: number;
      maxLength?: number;
      pattern?: string;
      custom?: string;
    };
    options?: string[];
    defaultValue?: string;
  }>;
  submitAction: string;
  styling: {
    layout: string;
    theme: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface ComponentSchema {
  id: string;
  name: string;
  type: string;
  description: string;
  props: Record<string, any>;
  styling: Record<string, any>;
  children?: ComponentSchema[];
  createdAt: string;
  updatedAt: string;
}

export interface WorkflowSchema {
  id: string;
  name: string;
  description: string;
  trigger: {
    type: string;
    conditions: Record<string, any>;
  };
  steps: Array<{
    id: string;
    type: string;
    name: string;
    config: Record<string, any>;
    nextStep?: string;
  }>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DataLinkSchema {
  id: string;
  name: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  linkType: string;
  cascadeDelete: boolean;
  enforceIntegrity: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface APIEndpointSchema {
  id: string;
  name: string;
  method: string;
  path: string;
  description: string;
  parameters: Array<{
    name: string;
    type: string;
    required: boolean;
    location: 'query' | 'body' | 'header' | 'path';
  }>;
  responseSchema: Record<string, any>;
  authentication: boolean;
  rateLimiting?: {
    requests: number;
    window: string;
  };
  createdAt: string;
  updatedAt: string;
}

export class DevToolsExportService {
  private getStorageKey(type: string): string {
    return `devtools_${type}`;
  }

  private loadFromStorage<T>(type: string): T[] {
    try {
      const data = localStorage.getItem(this.getStorageKey(type));
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error(`Error loading ${type} from storage:`, error);
      return [];
    }
  }

  private transformTableToSchema(table: CustomTable): TableSchema {
    return {
      id: table.name.toLowerCase().replace(/\s+/g, '_'),
      name: table.name,
      description: table.description || '',
      columns: table.columns.map(col => ({
        id: col.id,
        name: col.name,
        type: col.type,
        required: false, // TableColumn doesn't have required property
        unique: false, // TableColumn doesn't have unique property
        defaultValue: undefined, // TableColumn doesn't have defaultValue property
        options: col.options
      })),
      dataSource: table.dataSource || 'static',
      features: {
        sorting: table.features?.sorting || false,
        filtering: table.features?.filtering || false,
        search: table.features?.search || false,
        pagination: table.features?.pagination || false,
        export: table.features?.export || false
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  private transformFormToSchema(form: CustomForm): FormSchema {
    return {
      id: form.name.toLowerCase().replace(/\s+/g, '_'),
      name: form.name,
      description: form.description || '',
      fields: form.fields.map(field => ({
        id: field.id,
        name: field.label, // Use label as name since FormField doesn't have name
        type: field.type,
        label: field.label,
        placeholder: field.placeholder,
        required: field.required || false,
        validation: field.validation ? {
          custom: field.validation
        } : undefined,
        options: field.options,
        defaultValue: undefined // FormField doesn't have defaultValue
      })),
      submitAction: 'console', // CustomForm doesn't have submitAction
      styling: {
        layout: 'vertical', // CustomForm doesn't have layout
        theme: 'default' // CustomForm doesn't have theme
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  private transformDataLinkToSchema(link: DataLink): DataLinkSchema {
    return {
      id: link.id,
      name: link.name,
      sourceTable: link.sourceTable,
      sourceField: link.sourceField,
      targetTable: link.targetTable,
      targetField: link.targetField,
      linkType: link.linkType,
      cascadeDelete: link.cascadeDelete || false,
      enforceIntegrity: link.enforceReferentialIntegrity || false, // Use correct property name
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  async exportTables(): Promise<TableSchema[]> {
    const tables = this.loadFromStorage<CustomTable>('saved_tables');
    return tables.map(table => this.transformTableToSchema(table));
  }

  async exportForms(): Promise<FormSchema[]> {
    const forms = this.loadFromStorage<CustomForm>('saved_forms');
    return forms.map(form => this.transformFormToSchema(form));
  }

  async exportComponents(): Promise<ComponentSchema[]> {
    const components = this.loadFromStorage<any>('saved_components');
    return components.map(comp => ({
      id: comp.id || comp.name?.toLowerCase().replace(/\s+/g, '_'),
      name: comp.name || 'Unnamed Component',
      type: comp.type || 'custom',
      description: comp.description || '',
      props: comp.props || {},
      styling: comp.styling || {},
      children: comp.children || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
  }

  async exportWorkflows(): Promise<WorkflowSchema[]> {
    const workflows = this.loadFromStorage<any>('saved_workflows');
    return workflows.map(workflow => ({
      id: workflow.id || workflow.name?.toLowerCase().replace(/\s+/g, '_'),
      name: workflow.name || 'Unnamed Workflow',
      description: workflow.description || '',
      trigger: workflow.trigger || { type: 'manual', conditions: {} },
      steps: workflow.steps || [],
      isActive: workflow.isActive || false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
  }

  async exportDataLinks(): Promise<DataLinkSchema[]> {
    const dataLinks = this.loadFromStorage<DataLink>('data_links');
    return dataLinks.map(link => this.transformDataLinkToSchema(link));
  }

  async exportAPIEndpoints(): Promise<APIEndpointSchema[]> {
    const endpoints = this.loadFromStorage<any>('api_endpoints');
    return endpoints.map(endpoint => ({
      id: endpoint.id || endpoint.name?.toLowerCase().replace(/\s+/g, '_'),
      name: endpoint.name || 'Unnamed Endpoint',
      method: endpoint.method || 'GET',
      path: endpoint.path || '/',
      description: endpoint.description || '',
      parameters: endpoint.parameters || [],
      responseSchema: endpoint.responseSchema || {},
      authentication: endpoint.authentication || false,
      rateLimiting: endpoint.rateLimiting,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
  }

  async exportAll() {
    const [tables, forms, components, workflows, dataLinks, apiEndpoints] = await Promise.all([
      this.exportTables(),
      this.exportForms(),
      this.exportComponents(),
      this.exportWorkflows(),
      this.exportDataLinks(),
      this.exportAPIEndpoints()
    ]);

    return {
      tables,
      forms,
      components,
      workflows,
      dataLinks,
      apiEndpoints,
      exportedAt: new Date().toISOString(),
      version: '1.0.0'
    };
  }

  async downloadExport(type: 'all' | 'tables' | 'forms' | 'components' | 'workflows' | 'dataLinks' | 'apiEndpoints') {
    let data: any;
    let filename: string;

    switch (type) {
      case 'all':
        data = await this.exportAll();
        filename = 'devtools_export_all.json';
        break;
      case 'tables':
        data = await this.exportTables();
        filename = 'tables.json';
        break;
      case 'forms':
        data = await this.exportForms();
        filename = 'forms.json';
        break;
      case 'components':
        data = await this.exportComponents();
        filename = 'components.json';
        break;
      case 'workflows':
        data = await this.exportWorkflows();
        filename = 'workflows.json';
        break;
      case 'dataLinks':
        data = await this.exportDataLinks();
        filename = 'data_links.json';
        break;
      case 'apiEndpoints':
        data = await this.exportAPIEndpoints();
        filename = 'api_endpoints.json';
        break;
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

export const devToolsExportService = new DevToolsExportService();