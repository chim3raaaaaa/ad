import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { devToolsExportService } from './exportService';
import { 
  Download, 
  Database, 
  FileText, 
  Component, 
  GitBranch, 
  Link, 
  Server,
  Package,
  Eye,
  Copy
} from 'lucide-react';

export const DevToolsExporter: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [exportData, setExportData] = useState<any>(null);
  const [activePreview, setActivePreview] = useState<string>('');
  const { toast } = useToast();

  const exportTypes = [
    { key: 'tables', label: 'Tables', icon: Database, color: 'bg-blue-500' },
    { key: 'forms', label: 'Forms', icon: FileText, color: 'bg-green-500' },
    { key: 'components', label: 'Components', icon: Component, color: 'bg-purple-500' },
    { key: 'workflows', label: 'Workflows', icon: GitBranch, color: 'bg-orange-500' },
    { key: 'dataLinks', label: 'Data Links', icon: Link, color: 'bg-red-500' },
    { key: 'apiEndpoints', label: 'API Endpoints', icon: Server, color: 'bg-cyan-500' }
  ];

  const handleExportAll = async () => {
    setIsExporting(true);
    try {
      const data = await devToolsExportService.exportAll();
      setExportData(data);
      toast({
        title: "Export Complete",
        description: "All developer mode definitions have been exported successfully."
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export developer mode definitions.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = async (type: string) => {
    try {
      await devToolsExportService.downloadExport(type as any);
      toast({
        title: "Download Started",
        description: `${type === 'all' ? 'Complete export' : type} file is being downloaded.`
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download export file.",
        variant: "destructive"
      });
    }
  };

  const handlePreview = async (type: string) => {
    setIsExporting(true);
    try {
      let data;
      switch (type) {
        case 'tables':
          data = await devToolsExportService.exportTables();
          break;
        case 'forms':
          data = await devToolsExportService.exportForms();
          break;
        case 'components':
          data = await devToolsExportService.exportComponents();
          break;
        case 'workflows':
          data = await devToolsExportService.exportWorkflows();
          break;
        case 'dataLinks':
          data = await devToolsExportService.exportDataLinks();
          break;
        case 'apiEndpoints':
          data = await devToolsExportService.exportAPIEndpoints();
          break;
        default:
          data = await devToolsExportService.exportAll();
      }
      setActivePreview(JSON.stringify(data, null, 2));
    } catch (error) {
      toast({
        title: "Preview Failed",
        description: "Failed to generate preview.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(activePreview);
    toast({
      title: "Copied to Clipboard",
      description: "Export data has been copied to clipboard."
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Developer Mode Export Manager
          </CardTitle>
          <CardDescription>
            Export all builder definitions as structured JSON schemas for audit and deployment.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="export" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="export">Export Tools</TabsTrigger>
              <TabsTrigger value="preview">Preview Data</TabsTrigger>
            </TabsList>

            <TabsContent value="export" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {exportTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <Card key={type.key} className="relative">
                      <CardHeader className="pb-3">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-lg ${type.color} flex items-center justify-center`}>
                            <Icon className="w-4 h-4 text-white" />
                          </div>
                          <CardTitle className="text-lg">{type.label}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handlePreview(type.key)}
                            disabled={isExporting}
                            className="flex-1"
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            Preview
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleDownload(type.key)}
                            className="flex-1"
                          >
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <div className="pt-4 border-t">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Complete Export</CardTitle>
                    <CardDescription>
                      Export all builder definitions in a single comprehensive file.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-4">
                      <Button
                        onClick={handleExportAll}
                        disabled={isExporting}
                        className="flex-1"
                      >
                        <Package className="w-4 h-4 mr-2" />
                        {isExporting ? 'Generating...' : 'Generate Complete Export'}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleDownload('all')}
                        disabled={!exportData}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download All
                      </Button>
                    </div>
                    {exportData && (
                      <div className="text-sm text-muted-foreground">
                        <Badge variant="secondary" className="mr-2">
                          {exportData.tables?.length || 0} Tables
                        </Badge>
                        <Badge variant="secondary" className="mr-2">
                          {exportData.forms?.length || 0} Forms
                        </Badge>
                        <Badge variant="secondary" className="mr-2">
                          {exportData.components?.length || 0} Components
                        </Badge>
                        <Badge variant="secondary" className="mr-2">
                          {exportData.workflows?.length || 0} Workflows
                        </Badge>
                        <Badge variant="secondary" className="mr-2">
                          {exportData.dataLinks?.length || 0} Data Links
                        </Badge>
                        <Badge variant="secondary">
                          {exportData.apiEndpoints?.length || 0} API Endpoints
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="preview" className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Export Preview</CardTitle>
                    {activePreview && (
                      <Button variant="outline" size="sm" onClick={copyToClipboard}>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy to Clipboard
                      </Button>
                    )}
                  </div>
                  <CardDescription>
                    Preview the JSON structure before downloading.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {activePreview ? (
                    <ScrollArea className="h-96 w-full">
                      <Textarea
                        value={activePreview}
                        readOnly
                        className="min-h-96 font-mono text-xs"
                        placeholder="Click preview on any export type to see the JSON structure..."
                      />
                    </ScrollArea>
                  ) : (
                    <div className="h-96 flex items-center justify-center text-muted-foreground">
                      <div className="text-center">
                        <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No preview data available</p>
                        <p className="text-sm">Click "Preview" on any export type to see the JSON structure</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};