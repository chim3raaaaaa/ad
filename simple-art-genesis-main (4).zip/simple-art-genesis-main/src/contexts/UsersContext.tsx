import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { localAuthService, type LocalUser, type LocalRole } from '@/services/auth/localAuthService';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  status: 'active' | 'inactive';
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
}

interface Role {
  name: string;
  description: string;
  permissions: string[];
  color: string;
}

interface UsersContextType {
  users: User[];
  roles: Role[];
  addUser: (user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>, password: string) => Promise<void>;
  updateUser: (id: string, updates: Partial<User>, newPassword?: string) => Promise<void>;
  deleteUser: (id: string) => void;
  getUserById: (id: string) => User | undefined;
  addRole: (role: Role) => void;
  updateRole: (name: string, updates: Partial<Role>) => void;
  deleteRole: (name: string) => void;
  getRoleByName: (name: string) => Role | undefined;
  assignRole: (userId: string, roleName: string) => void;
  refreshUsers: () => void;
}

const UsersContext = createContext<UsersContextType | undefined>(undefined);

export function UsersProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);

  // Initialize data on mount
  useEffect(() => {
    localAuthService.initializeUsers();
    localAuthService.initializeRoles();
    loadData();
  }, []);

  const loadData = () => {
    // Convert LocalUser to User format
    const localUsers = localAuthService.getAllUsers();
    const formattedUsers: User[] = localUsers.map(user => ({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      status: user.status,
      lastLogin: user.last_login,
      createdAt: user.created_at,
      updatedAt: user.updated_at
    }));

    const localRoles = localAuthService.getRoles();
    
    setUsers(formattedUsers);
    setRoles(localRoles);
  };

  // User management functions
  const addUser = async (userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>, password: string) => {
    try {
      await localAuthService.createUser({
        name: userData.name,
        email: userData.email,
        role: userData.role,
        department: userData.department,
        status: userData.status
      }, password);
      loadData(); // Refresh data
      console.log('User added:', userData.name);
    } catch (error) {
      console.error('Failed to add user:', error);
      throw error;
    }
  };

  const updateUser = async (id: string, updates: Partial<User>, newPassword?: string) => {
    try {
      const success = await localAuthService.updateUserById(id, {
        name: updates.name,
        email: updates.email,
        role: updates.role,
        department: updates.department,
        status: updates.status
      }, newPassword);
      
      if (success) {
        loadData(); // Refresh data
        console.log('User updated:', id);
      }
    } catch (error) {
      console.error('Failed to update user:', error);
      throw error;
    }
  };

  const deleteUser = (id: string) => {
    const user = users.find(u => u.id === id);
    if (user) {
      const success = localAuthService.deleteUserById(id);
      if (success) {
        loadData(); // Refresh data
        console.log('User deleted:', user.name);
      }
    }
  };

  const getUserById = (id: string) => {
    return users.find(user => user.id === id);
  };

  // Role management functions
  const addRole = (roleData: Role) => {
    const currentRoles = localAuthService.getRoles();
    currentRoles.push(roleData);
    localStorage.setItem('lab-roles-db', JSON.stringify(currentRoles));
    loadData(); // Refresh data
    console.log('Role added:', roleData.name);
  };

  const updateRole = (name: string, updates: Partial<Role>) => {
    const currentRoles = localAuthService.getRoles();
    const index = currentRoles.findIndex(r => r.name === name);
    if (index !== -1) {
      currentRoles[index] = { ...currentRoles[index], ...updates };
      localStorage.setItem('lab-roles-db', JSON.stringify(currentRoles));
      loadData(); // Refresh data
      console.log('Role updated:', name);
    }
  };

  const deleteRole = (name: string) => {
    const role = roles.find(r => r.name === name);
    if (role) {
      // Check if role is in use
      const usersWithRole = users.filter(user => user.role === name);
      if (usersWithRole.length > 0) {
        console.warn('Cannot delete role - still assigned to users:', usersWithRole.length);
        return;
      }
      
      const currentRoles = localAuthService.getRoles();
      const filtered = currentRoles.filter(r => r.name !== name);
      localStorage.setItem('lab-roles-db', JSON.stringify(filtered));
      loadData(); // Refresh data
      console.log('Role deleted:', role.name);
    }
  };

  const getRoleByName = (name: string) => {
    return roles.find(role => role.name === name);
  };

  const assignRole = async (userId: string, roleName: string) => {
    await updateUser(userId, { role: roleName });
    console.log('Role assigned:', { userId, roleName });
  };

  const refreshUsers = () => {
    loadData();
    console.log('Users data refreshed');
  };

  const value: UsersContextType = {
    users,
    roles,
    addUser,
    updateUser,
    deleteUser,
    getUserById,
    addRole,
    updateRole,
    deleteRole,
    getRoleByName,
    assignRole,
    refreshUsers
  };

  return <UsersContext.Provider value={value}>{children}</UsersContext.Provider>;
}

export function useUsersContext() {
  const context = useContext(UsersContext);
  if (context === undefined) {
    throw new Error('useUsersContext must be used within a UsersProvider');
  }
  return context;
}

export type { User, Role };