import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface MemoData {
  id: string;
  reference: string;
  filename?: string;
  sender?: string;
  subject?: string;
  status: 'pending' | 'processing' | 'approved' | 'completed';
  category?: string; // Added category field for product-specific filtering
  extractedData: {
    date: string;
    site: string;
    officer: string;
    testType: string;
    product: string;
    clientName?: string;
    sampleType?: string;
    siteSupervisor?: string;
    blocksRequired?: number;
    lorry?: string;
  };
  // Additional properties for memo management
  labSite?: string;
  officerInCharge?: string;
  lorry?: string;
  blocksCount?: number;
  testPerformed?: string;
  retest?: string;
  postedBy?: string;
  productions?: any[];
  lastRefresh?: string;
  // Properties for reports
  linkedReports?: string[];
  // NEW: Memo Inbox Integration Properties
  inboxStatus?: 'not_submitted' | 'pending' | 'acknowledged' | 'flagged' | 'revision_required';
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  flaggedReasons?: string[];
  revisionHistory?: MemoRevision[];
  currentRevision?: number;
  discrepancyFlags?: MemoDiscrepancyFlag[];
  submittedToInboxAt?: string;
  submittedToInboxBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MemoRevision {
  id: string;
  revisionNumber: number;
  changes: string;
  revisedBy: string;
  revisedAt: string;
  reason: string;
}

export interface MemoDiscrepancyFlag {
  id: string;
  category: string;
  description: string;
  priority: 'minor' | 'major' | 'critical';
  flaggedBy: string;
  flaggedAt: string;
  resolved: boolean;
  resolvedBy?: string;
  resolvedAt?: string;
}

interface MemoContextType {
  memos: MemoData[];
  addMemo: (memo: MemoData) => void;
  updateMemo: (id: string, updates: Partial<MemoData>) => void;
  deleteMemo: (id: string) => void;
  getMemoById: (id: string) => MemoData | undefined;
  getMemosByStatus: (status: string) => MemoData[];
  refreshMemos: () => void;
  // NEW: Memo Inbox Integration Methods
  submitMemoToInbox: (memoId: string) => Promise<boolean>;
  getMemosByInboxStatus: (inboxStatus: string) => MemoData[];
  getAcknowledgedMemos: () => MemoData[];
  getPendingInboxMemos: () => MemoData[];
}

const MemoContext = createContext<MemoContextType | undefined>(undefined);

// Initial shared memo data with test data for notification system
const initialMemos: MemoData[] = [
  {
    id: 'memo-001',
    reference: 'UBP-MEMO-001-2024',
    filename: 'test-report-001.pdf',
    sender: 'lab.technician@ubp.mu',
    subject: 'Concrete Block Test - Production Batch 001',
    status: 'completed',
    extractedData: {
      date: new Date().toLocaleDateString(),
      site: 'TERRAROCK',
      officer: 'John Smith',
      testType: 'Compressive Strength',
      product: 'CONCRETE BLOCK 190x140x90',
      clientName: 'Construction Ltd',
      sampleType: 'Production Sample',
      siteSupervisor: 'Mike Johnson',
      blocksRequired: 6
    },
    labSite: 'TERRAROCK',
    officerInCharge: 'John Smith',
    blocksCount: 6,
    testPerformed: 'Compressive Strength',
    retest: 'No',
    postedBy: 'lab.technician@ubp.mu',
    productions: [],
    linkedReports: ['report-001'],
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
    updatedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString() // 30 minutes ago
  },
  {
    id: 'memo-002',
    reference: 'UBP-MEMO-002-2024',
    filename: 'test-request-002.pdf',
    sender: 'quality.control@ubp.mu',
    subject: 'Paving Block Test Request - Urgent',
    status: 'pending',
    extractedData: {
      date: new Date().toLocaleDateString(),
      site: 'CONCRETE LAB',
      officer: 'Sarah Wilson',
      testType: 'Water Absorption',
      product: 'PAVING BLOCK 80mm',
      clientName: 'Roadworks Inc',
      sampleType: 'Quality Control',
      siteSupervisor: 'David Brown',
      blocksRequired: 12
    },
    labSite: 'CONCRETE LAB',
    officerInCharge: 'Sarah Wilson',
    blocksCount: 12,
    testPerformed: 'Water Absorption',
    retest: 'No',
    postedBy: 'quality.control@ubp.mu',
    productions: [],
    linkedReports: [],
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
    updatedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'memo-003',
    reference: 'UBP-MEMO-003-2024',
    filename: 'test-memo-003.pdf',
    sender: 'lab.assistant@ubp.mu',
    subject: 'Cellular Block Density Test',
    status: 'processing',
    extractedData: {
      date: new Date().toLocaleDateString(),
      site: 'MATERIALS LAB',
      officer: 'Emily Davis',
      testType: 'Density Test',
      product: 'CELLULAR 150-25',
      clientName: 'Industrial Building Co',
      sampleType: 'Standard Sample',
      siteSupervisor: 'Robert Taylor',
      blocksRequired: 8
    },
    labSite: 'MATERIALS LAB',
    officerInCharge: 'Emily Davis',
    blocksCount: 8,
    testPerformed: 'Density Test',
    retest: 'No',
    postedBy: 'lab.assistant@ubp.mu',
    productions: [],
    linkedReports: [],
    createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
    updatedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString() // 15 minutes ago
  },
  {
    id: 'memo-004',
    reference: 'UBP-MEMO-004-2024',
    filename: 'kerb-test-004.pdf',
    sender: 'senior.tech@ubp.mu',
    subject: 'Kerb Stone Flexural Test - High Priority',
    status: 'approved',
    extractedData: {
      date: new Date().toLocaleDateString(),
      site: 'TERRAROCK',
      officer: 'Michael Chen',
      testType: 'Flexural Strength',
      product: 'KERB STONE STANDARD',
      clientName: 'Municipality Works',
      sampleType: 'Compliance Test',
      siteSupervisor: 'James Anderson',
      blocksRequired: 15
    },
    labSite: 'TERRAROCK',
    officerInCharge: 'Michael Chen',
    blocksCount: 15,
    testPerformed: 'Flexural Strength',
    retest: 'No',
    postedBy: 'senior.tech@ubp.mu',
    productions: [],
    linkedReports: [],
    createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(), // 45 minutes ago
    updatedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString() // 10 minutes ago
  }
];

export function MemoProvider({ children }: { children: ReactNode }) {
  const [memos, setMemos] = useState<MemoData[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load memos from database or localStorage
  const loadMemos = async () => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        // Load from Electron database
        const result = await window.electronAPI.dbQuery('SELECT * FROM memos ORDER BY created_at DESC');
        if (result.success && result.data) {
          // Transform database data to MemoData format
          const transformedMemos = result.data.map(memo => ({
            id: memo.id,
            reference: memo.title || `MEMO-${memo.id}`,
            filename: memo.filename || '',
            sender: memo.author_id || 'system',
            subject: memo.title || '',
            status: memo.status || 'pending',
            extractedData: {
              date: memo.created_at ? new Date(memo.created_at).toLocaleDateString() : '',
              site: 'Database Entry',
              officer: memo.author_id || 'System',
              testType: memo.type || 'General',
              product: memo.type || 'Lab Product',
              clientName: 'Database Client',
              sampleType: 'Standard',
              siteSupervisor: memo.author_id || 'System',
              blocksRequired: 0
            },
            labSite: 'Main Laboratory',
            officerInCharge: memo.author_id || 'System',
            blocksCount: 0,
            testPerformed: memo.type || 'General Test',
            retest: 'No',
            postedBy: memo.author_id || 'System',
            productions: [],
            linkedReports: [],
            createdAt: memo.created_at || new Date().toISOString(),
            updatedAt: memo.updated_at || new Date().toISOString()
          }));
          setMemos(transformedMemos);
        }
      } else {
        // Fallback to localStorage for web preview
        const savedMemos = localStorage.getItem('lab-memos');
        if (savedMemos) {
          const parsedMemos = JSON.parse(savedMemos);
          setMemos(parsedMemos);
        } else {
          // Start with empty memos
          setMemos([]);
        }
      }
    } catch (error) {
      console.error('Failed to load memos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMemos();
  }, []);

  // Save to localStorage as backup
  useEffect(() => {
    if (!window.electronAPI) {
      localStorage.setItem('lab-memos', JSON.stringify(memos));
    }
  }, [memos]);

  const addMemo = async (newMemo: MemoData) => {
    try {
      if (window.electronAPI) {
        // Save to database
        const result = await window.electronAPI.dbRun(
          `INSERT INTO memos (id, title, content, type, priority, tags, created_at, updated_at, author_id, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newMemo.id,
            newMemo.subject || newMemo.reference,
            JSON.stringify(newMemo.extractedData),
            newMemo.extractedData.testType || 'general',
            'medium',
            '',
            newMemo.createdAt,
            newMemo.updatedAt,
            newMemo.postedBy || 'system',
            newMemo.status
          ]
        );
        
        if (!result.success) {
          console.error('Failed to save memo to database:', result.error);
        }
      }
      
      // Update local state
      const memoWithTimestamp = {
        ...newMemo,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setMemos(prev => [memoWithTimestamp, ...prev]);
      console.log('Memo added to context:', memoWithTimestamp.reference);
    } catch (error) {
      console.error('Failed to add memo:', error);
    }
  };

  const updateMemo = async (id: string, updates: Partial<MemoData>) => {
    try {
      if (window.electronAPI) {
        // Update in database
        const result = await window.electronAPI.dbRun(
          'UPDATE memos SET title = ?, content = ?, status = ?, updated_at = ? WHERE id = ?',
          [
            updates.subject || updates.reference,
            JSON.stringify(updates.extractedData || {}),
            updates.status,
            new Date().toISOString(),
            id
          ]
        );
        
        if (!result.success) {
          console.error('Failed to update memo in database:', result.error);
        }
      }
      
      // Update local state
      setMemos(prev => prev.map(memo => 
        memo.id === id 
          ? { ...memo, ...updates, updatedAt: new Date().toISOString() }
          : memo
      ));
      console.log('Memo updated in context:', id);
    } catch (error) {
      console.error('Failed to update memo:', error);
    }
  };

  const deleteMemo = async (id: string) => {
    try {
      if (window.electronAPI) {
        // Delete from database
        const result = await window.electronAPI.dbRun('DELETE FROM memos WHERE id = ?', [id]);
        if (!result.success) {
          console.error('Failed to delete memo from database:', result.error);
        }
      }
      
      // Update local state
      setMemos(prev => prev.filter(memo => memo.id !== id));
      console.log('Memo deleted from context:', id);
    } catch (error) {
      console.error('Failed to delete memo:', error);
    }
  };

  const getMemoById = (id: string) => {
    return memos.find(memo => memo.id === id);
  };

  const getMemosByStatus = (status: string) => {
    return memos.filter(memo => memo.status === status);
  };

  const refreshMemos = () => {
    loadMemos();
  };

  // NEW: Memo Inbox Integration Methods
  const submitMemoToInbox = async (memoId: string): Promise<boolean> => {
    try {
      const memo = getMemoById(memoId);
      if (!memo) return false;

      // Import the inbox service
      const { memoInboxService } = await import('@/services/database/memoInboxService');
      
      // Submit to inbox
      await memoInboxService.submitMemoToInbox(
        memoId,
        memo.postedBy || 'current-user',
        memo.category || 'blocks',
        memo.reference
      );

      // Update memo status
      await updateMemo(memoId, {
        inboxStatus: 'pending',
        submittedToInboxAt: new Date().toISOString(),
        submittedToInboxBy: memo.postedBy || 'current-user'
      });

      return true;
    } catch (error) {
      console.error('Failed to submit memo to inbox:', error);
      return false;
    }
  };

  const getMemosByInboxStatus = (inboxStatus: string) => {
    return memos.filter(memo => memo.inboxStatus === inboxStatus);
  };

  const getAcknowledgedMemos = () => {
    return memos.filter(memo => memo.inboxStatus === 'acknowledged');
  };

  const getPendingInboxMemos = () => {
    return memos.filter(memo => memo.inboxStatus === 'pending');
  };

  // Add isLoading to the interface
  const value: MemoContextType & { isLoading: boolean } = {
    memos,
    addMemo,
    updateMemo,
    deleteMemo,
    getMemoById,
    getMemosByStatus,
    refreshMemos,
    submitMemoToInbox,
    getMemosByInboxStatus,
    getAcknowledgedMemos,
    getPendingInboxMemos,
    isLoading,
  };

  return <MemoContext.Provider value={value}>{children}</MemoContext.Provider>;
}

export function useMemoContext() {
  const context = useContext(MemoContext);
  if (context === undefined) {
    throw new Error('useMemoContext must be used within a MemoProvider');
  }
  return context;
}