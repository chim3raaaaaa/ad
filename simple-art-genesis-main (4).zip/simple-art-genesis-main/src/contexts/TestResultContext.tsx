import { useState, useEffect, createContext, useContext, ReactNode } from 'react';

// Create a singleton instance of ElectronDataService
const createElectronDataService = () => {
  // Define the service interface locally to avoid import issues
  const electronDataService = {
    async getTestRequests() {
      try {
        if (window.electronAPI) {
          // Initialize test_requests table if it doesn't exist
          await window.electronAPI.dbRun(`
            CREATE TABLE IF NOT EXISTS test_requests (
              id TEXT PRIMARY KEY,
              title TEXT NOT NULL,
              description TEXT,
              type TEXT,
              priority TEXT DEFAULT 'medium',
              status TEXT DEFAULT 'pending',
              requested_by TEXT,
              assigned_to TEXT,
              due_date TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
              completed_at TEXT,
              test_data TEXT,
              results TEXT,
              memo_id TEXT,
              client_name TEXT,
              sample_description TEXT,
              test_method TEXT,
              expected_results TEXT
            )
          `);

          const result = await window.electronAPI.dbQuery('SELECT * FROM test_requests ORDER BY created_at DESC');
          if (result.success && result.data) {
            return {
              data: result.data,
              count: result.data.length,
              page: 1,
              totalPages: 1
            };
          }
        }
        return { data: [], count: 0, page: 1, totalPages: 0 };
      } catch (error) {
        console.error('Failed to get test requests:', error);
        return { data: [], count: 0, page: 1, totalPages: 0 };
      }
    },

    async createTestRequest(testRequest: any) {
      try {
        const newRequest = {
          id: `request_${Date.now()}`,
          ...testRequest,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        if (window.electronAPI) {
          const result = await window.electronAPI.dbRun(
            `INSERT INTO test_requests (id, title, description, type, priority, status, requested_by, assigned_to, due_date, created_at, updated_at, completed_at, test_data, results)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              newRequest.id,
              newRequest.title || '',
              newRequest.description || '',
              newRequest.type || '',
              newRequest.priority || 'medium',
              newRequest.status || 'pending',
              newRequest.requested_by || '',
              newRequest.assigned_to || '',
              newRequest.due_date || null,
              newRequest.created_at,
              newRequest.updated_at,
              null,
              '',
              ''
            ]
          );

          if (!result.success) {
            return { data: null, error: result.error };
          }
        }

        return { data: newRequest };
      } catch (error) {
        return { data: null, error: error.message };
      }
    },

    async updateTestRequest(id: string, testRequest: any) {
      try {
        const updateData = {
          ...testRequest,
          updated_at: new Date().toISOString()
        };

        if (window.electronAPI) {
          const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
          const updateValues = updateFields.map(key => updateData[key]);
          
          if (updateFields.length > 0) {
            const sql = `UPDATE test_requests SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
            const result = await window.electronAPI.dbRun(sql, [...updateValues, id]);
            
            if (!result.success) {
              return { data: null, error: result.error };
            }
          }
        }

        return { data: { id, ...updateData } };
      } catch (error) {
        return { data: null, error: error.message };
      }
    },

    async deleteTestRequest(id: string) {
      try {
        if (window.electronAPI) {
          const result = await window.electronAPI.dbRun('DELETE FROM test_requests WHERE id = ?', [id]);
          if (!result.success) {
            return { data: false, error: result.error };
          }
        }
        return { data: true };
      } catch (error) {
        return { data: false, error: error.message };
      }
    }
  };

  return electronDataService;
};

const electronDataService = createElectronDataService();

export interface TestResult {
  id: string;
  title: string;
  description: string;
  type: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  requested_by: string;
  assigned_to?: string;
  due_date?: string;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  test_data?: string;
  results?: string;
}

interface TestResultContextType {
  testResults: TestResult[];
  addTestResult: (result: Omit<TestResult, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateTestResult: (id: string, updates: Partial<TestResult>) => Promise<void>;
  deleteTestResult: (id: string) => Promise<void>;
  refreshTestResults: () => Promise<void>;
  isLoading: boolean;
}

const TestResultContext = createContext<TestResultContextType | undefined>(undefined);

export function TestResultProvider({ children }: { children: ReactNode }) {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadTestResults = async () => {
    setIsLoading(true);
    try {
      const result = await electronDataService.getTestRequests();
      if (result.data) {
        setTestResults(result.data);
      }
    } catch (error) {
      console.error('Failed to load test results:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTestResults();
  }, []);

  const addTestResult = async (result: Omit<TestResult, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const response = await electronDataService.createTestRequest(result);
      if (response.data) {
        setTestResults(prev => [response.data, ...prev]);
      }
    } catch (error) {
      console.error('Failed to add test result:', error);
      throw error;
    }
  };

  const updateTestResult = async (id: string, updates: Partial<TestResult>) => {
    try {
      const result = await electronDataService.updateTestRequest(id, updates);
      if (result.data) {
        setTestResults(prev => prev.map(testResult => 
          testResult.id === id ? result.data : testResult
        ));
      }
    } catch (error) {
      console.error('Failed to update test result:', error);
      throw error;
    }
  };

  const deleteTestResult = async (id: string) => {
    try {
      await electronDataService.deleteTestRequest(id);
      setTestResults(prev => prev.filter(result => result.id !== id));
    } catch (error) {
      console.error('Failed to delete test result:', error);
      throw error;
    }
  };

  const refreshTestResults = async () => {
    await loadTestResults();
  };

  return (
    <TestResultContext.Provider value={{
      testResults,
      addTestResult,
      updateTestResult,
      deleteTestResult,
      refreshTestResults,
      isLoading
    }}>
      {children}
    </TestResultContext.Provider>
  );
}

export function useTestResults() {
  const context = useContext(TestResultContext);
  if (context === undefined) {
    throw new Error('useTestResults must be used within a TestResultProvider');
  }
  return context;
}