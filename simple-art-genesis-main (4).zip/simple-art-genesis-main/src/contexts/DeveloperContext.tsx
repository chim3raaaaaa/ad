import React, { createContext, useContext, useState, useEffect } from 'react';

interface DeveloperContextType {
  isDeveloperMode: boolean;
  setDeveloperMode: (enabled: boolean) => void;
  showFloatingPanel: boolean;
  setShowFloatingPanel: (show: boolean) => void;
  debugMode: boolean;
  setDebugMode: (enabled: boolean) => void;
  isRolePreview: boolean;
  setRolePreview: (enabled: boolean) => void;
  originalRole: string | null;
  setOriginalRole: (role: string | null) => void;
}

const DeveloperContext = createContext<DeveloperContextType | undefined>(undefined);

export const useDeveloperContext = () => {
  const context = useContext(DeveloperContext);
  if (context === undefined) {
    throw new Error('useDeveloperContext must be used within a DeveloperProvider');
  }
  return context;
};

export const DeveloperProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDeveloperMode, setIsDeveloperMode] = useState<boolean>(false);
  const [showFloatingPanel, setShowFloatingPanel] = useState<boolean>(false);
  const [debugMode, setDebugMode] = useState<boolean>(false);
  const [isRolePreview, setIsRolePreview] = useState<boolean>(false);
  const [originalRole, setOriginalRole] = useState<string | null>(null);

  // Load developer mode state from localStorage on init
  useEffect(() => {
    const savedDeveloperMode = localStorage.getItem('developer_mode_enabled');
    const savedFloatingPanel = localStorage.getItem('developer_floating_panel');
    const savedDebugMode = localStorage.getItem('developer_debug_mode');
    
    if (savedDeveloperMode === 'true') {
      setIsDeveloperMode(true);
    }
    if (savedFloatingPanel === 'true') {
      setShowFloatingPanel(true);
    }
    if (savedDebugMode === 'true') {
      setDebugMode(true);
    }
  }, []);

  // Save developer mode state to localStorage
  const setDeveloperMode = (enabled: boolean) => {
    setIsDeveloperMode(enabled);
    localStorage.setItem('developer_mode_enabled', enabled.toString());
    
    // If disabling developer mode, also disable floating panel and debug mode
    if (!enabled) {
      setShowFloatingPanel(false);
      setDebugMode(false);
      localStorage.setItem('developer_floating_panel', 'false');
      localStorage.setItem('developer_debug_mode', 'false');
    }
  };

  const setShowFloatingPanelWrapper = (show: boolean) => {
    setShowFloatingPanel(show);
    localStorage.setItem('developer_floating_panel', show.toString());
  };

  const setDebugModeWrapper = (enabled: boolean) => {
    setDebugMode(enabled);
    localStorage.setItem('developer_debug_mode', enabled.toString());
  };

  const setRolePreview = (enabled: boolean) => {
    setIsRolePreview(enabled);
    // When exiting role preview, clear the original role
    if (!enabled) {
      setOriginalRole(null);
    }
  };

  const value: DeveloperContextType = {
    isDeveloperMode,
    setDeveloperMode,
    showFloatingPanel,
    setShowFloatingPanel: setShowFloatingPanelWrapper,
    debugMode,
    setDebugMode: setDebugModeWrapper,
    isRolePreview,
    setRolePreview,
    originalRole,
    setOriginalRole
  };

  return <DeveloperContext.Provider value={value}>{children}</DeveloperContext.Provider>;
};