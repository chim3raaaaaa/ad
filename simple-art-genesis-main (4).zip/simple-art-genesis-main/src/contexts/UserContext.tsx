import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService, type AuthUser, type AuthSession } from '@/services/auth/authService';

export type UserRole = 'admin' | 'lab_manager' | 'lab_technician' | 'other';

export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  fullName: string;
  department?: string;
}

interface UserContextType {
  user: User | null;
  session: AuthSession | null;
  setUser: (user: User | null) => void;
  signOut: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
  isAdmin: () => boolean;
  isLabManager: () => boolean;
  canAccessPasswordPolicy: () => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<AuthSession | null>(null);

  useEffect(() => {
    const unsubscribe = authService.onAuthStateChange(async (session) => {
      setSession(session);
      
      if (session?.user) {
        const profile = await authService.getUserProfile();
        if (profile) {
          const mappedUser: User = {
            id: session.user.id,
            username: profile.name || session.user.email?.split('@')[0] || '',
            email: session.user.email || '',
            role: (profile.role as UserRole) || 'lab_technician',
            fullName: profile.name || 'User',
            department: profile.department
          };
          setUser(mappedUser);
        }
      } else {
        setUser(null);
      }
    });

    return unsubscribe;
  }, []);

  const signOut = async () => {
    await authService.signOut();
    setUser(null);
    setSession(null);
  };

  const hasPermission = (permission: string): boolean => {
    console.log('Checking permission:', { permission, user: user?.role, userExists: !!user });
    if (!user) return false;
    
    // Enhanced role permissions using the new RBAC system
    const rolePermissions: Record<UserRole, string[]> = {
      admin: [
        'system.full_access', 
        'system.developer_mode',
        'users.view', 'users.create', 'users.edit', 'users.delete',
        'tests.view', 'tests.create', 'tests.edit', 'tests.approve', 'tests.procedures.manage',
        'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
        'reports.view', 'reports.advanced', 'reports.export',
        'settings.view', 'settings.password_policy'
      ],
      lab_manager: [
        'users.view', 'users.edit',
        'tests.view', 'tests.create', 'tests.edit', 'tests.approve', 'tests.procedures.manage',
        'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
        'reports.view', 'reports.advanced', 'reports.export',
        'settings.view', 'settings.password_policy'
      ],
      lab_technician: [
        'tests.view', 'tests.create', 'tests.edit',
        'memos.view', 'memos.create', 'memos.edit',
        'reports.view'
      ],
      other: ['reports.view']
    };
    
    const userPermissions = rolePermissions[user.role] || [];
    // Admin has all permissions
    return userPermissions.includes('system.full_access') || userPermissions.includes(permission);
  };

  const isAdmin = (): boolean => user?.role === 'admin';
  const isLabManager = (): boolean => user?.role === 'lab_manager';
  const canAccessPasswordPolicy = (): boolean => user?.role === 'admin' || user?.role === 'lab_manager';

  const value: UserContextType = {
    user, session, setUser, signOut, hasPermission, isAdmin, isLabManager, canAccessPasswordPolicy
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};