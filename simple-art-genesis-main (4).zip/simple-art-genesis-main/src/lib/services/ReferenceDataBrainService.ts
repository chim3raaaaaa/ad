import { EventEmitter } from 'events';
import { UnifiedDataService, type ReferenceDataEntity, type QueryOptions, type ApiResponse } from '@/lib/database/UnifiedDataService';
import { toast } from '@/hooks/use-toast';

// Create singleton instance
const unifiedDataService = new UnifiedDataService();

// Reference Data Interfaces based on the schema
export interface Plant extends ReferenceDataEntity {
  code: string;
  name: string;
  location?: string;
  database_file?: string;
  contact_person?: string;
  phone?: string;
  email?: string;
  is_active: boolean;
}

export interface Officer extends ReferenceDataEntity {
  code: string;
  name: string;
  department_id?: string;
  plant_id?: string;
  email?: string;
  phone?: string;
  is_active: boolean;
}

export interface ProductCategory extends ReferenceDataEntity {
  name: string;
  description?: string;
  icon?: string;
  sort_order: number;
  is_active: boolean;
}

export interface ProductType extends ReferenceDataEntity {
  category_id: string;
  code: string;
  name: string;
  description?: string;
  unit?: string;
  test_schema?: string;
  validation_rules?: string;
  conformity_limits?: string;
  is_active: boolean;
}

export interface TestType extends ReferenceDataEntity {
  code: string;
  name: string;
  description?: string;
  category?: string;
  duration_days?: number;
  required_fields?: string;
  calculation_method?: string;
  is_active: boolean;
}

export interface Machine extends ReferenceDataEntity {
  code: string;
  name: string;
  plant_id: string;
  machine_type?: string;
  manufacturer?: string;
  model?: string;
  capacity?: string;
  calibration_date?: string;
  next_calibration?: string;
  is_active: boolean;
}

export interface Material extends ReferenceDataEntity {
  code: string;
  name: string;
  category?: string;
  supplier?: string;
  specification?: string;
  unit?: string;
  cost_per_unit?: number;
  is_active: boolean;
}

// Legacy interface mappings for backward compatibility
export type Product = ProductType;
export type MoistureCondition = ReferenceDataEntity;
export type SamplingPlace = ReferenceDataEntity;
export type ClimaticCondition = ReferenceDataEntity;
export type AggregateType = ReferenceDataEntity;
export type GradingLimit = ReferenceDataEntity;
export type Standard = ReferenceDataEntity;
export type MaterialType = Material;
export type SieveSize = ReferenceDataEntity;

// Cache management
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number; // Time to live in milliseconds
}

interface DropdownOption {
  id: string;
  name: string;
  value: string;
  category?: string;
  metadata?: Record<string, any>;
}

interface ReferenceDataOptions {
  plants: DropdownOption[];
  officers: DropdownOption[];
  productCategories: DropdownOption[];
  products: DropdownOption[];
  testTypes: DropdownOption[];
  machines: DropdownOption[];
  moistureConditions: DropdownOption[];
  samplingPlaces: DropdownOption[];
  climaticConditions: DropdownOption[];
  aggregateTypes: DropdownOption[];
  gradingLimits: DropdownOption[];
  standards: DropdownOption[];
  materialTypes: DropdownOption[];
  sieveSizes: DropdownOption[];
}

/**
 * Unified Reference Data Brain Service
 * 
 * This service acts as the single source of truth for all reference data
 * in the LIMS system. It manages caching, real-time updates, and provides
 * a consistent API for all components to access reference data.
 */
class ReferenceDataBrainService extends EventEmitter {
  private cache = new Map<string, CacheEntry<any>>();
  private readonly DEFAULT_TTL = 5 * 60 * 1000; // 5 minutes
  private isInitialized = false;

  constructor() {
    super();
    this.setMaxListeners(100); // Increase limit for many components
  }

  /**
   * Initialize the service and migrate hardcoded data
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Initialize unified data service first
      await unifiedDataService.initialize();
      
      // Migrate hardcoded reference data
      await this.migrateHardcodedData();
      
      this.isInitialized = true;
      this.emit('initialized');
      
      toast({
        title: "Reference Data Initialized",
        description: "All reference data has been successfully loaded"
      });
    } catch (error) {
      console.error('Failed to initialize ReferenceDataBrainService:', error);
      throw error;
    }
  }

  /**
   * Get cached data or fetch from database
   */
  private async getCachedData<T>(
    key: string, 
    fetcher: () => Promise<T>,
    ttl: number = this.DEFAULT_TTL
  ): Promise<T> {
    const cached = this.cache.get(key);
    
    if (cached && (Date.now() - cached.timestamp) < cached.ttl) {
      return cached.data;
    }

    const data = await fetcher();
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });

    return data;
  }

  /**
   * Invalidate cache for specific data type
   */
  async invalidateCache(dataType: string): Promise<void> {
    this.cache.delete(dataType);
    this.emit('cache-invalidated', dataType);
  }

  /**
   * Clear all cached data
   */
  async clearAllCache(): Promise<void> {
    this.cache.clear();
    this.emit('cache-cleared');
  }

  // ============ CORE REFERENCE DATA METHODS ============

  /**
   * Get all plants
   */
  async getPlants(): Promise<Plant[]> {
    return this.getCachedData('plants', async () => {
      const result = await unifiedDataService.getReferenceData('plants');
      return result.data || [];
    });
  }

  /**
   * Get all officers
   */
  async getOfficers(): Promise<Officer[]> {
    return this.getCachedData('officers', async () => {
      const result = await unifiedDataService.getReferenceData('officers');
      return result.data || [];
    });
  }

  /**
   * Get all product categories
   */
  async getProductCategories(): Promise<ProductCategory[]> {
    return this.getCachedData('productCategories', async () => {
      const result = await unifiedDataService.getReferenceData('product_categories');
      return result.data || [];
    });
  }

  /**
   * Get products, optionally filtered by category
   */
  async getProducts(categoryId?: string): Promise<Product[]> {
    const cacheKey = categoryId ? `products_${categoryId}` : 'products';
    
    return this.getCachedData(cacheKey, async () => {
      const options: QueryOptions = categoryId ? { filters: { category_id: categoryId } } : {};
      const result = await unifiedDataService.getReferenceData('product_types', options);
      return result.data || [];
    });
  }

  /**
   * Get all test types
   */
  async getTestTypes(): Promise<TestType[]> {
    return this.getCachedData('testTypes', async () => {
      const result = await unifiedDataService.getReferenceData('test_types');
      return result.data || [];
    });
  }

  /**
   * Get all machines
   */
  async getMachines(): Promise<Machine[]> {
    return this.getCachedData('machines', async () => {
      const result = await unifiedDataService.getReferenceData('machines');
      return result.data || [];
    });
  }

  /**
   * Get all materials
   */
  async getMaterials(): Promise<Material[]> {
    return this.getCachedData('materials', async () => {
      const result = await unifiedDataService.getReferenceData('materials');
      return result.data || [];
    });
  }

  // ============ LEGACY COMPATIBILITY METHODS ============
  // These provide backward compatibility with existing code

  async getMoistureConditions(): Promise<MoistureCondition[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getSamplingPlaces(): Promise<SamplingPlace[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getClimaticConditions(): Promise<ClimaticCondition[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getAggregateTypes(): Promise<AggregateType[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getGradingLimits(category?: string): Promise<GradingLimit[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getStandards(): Promise<Standard[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  async getMaterialTypes(): Promise<MaterialType[]> {
    return this.getMaterials() as Promise<MaterialType[]>;
  }

  async getSieveSizes(): Promise<SieveSize[]> {
    // For now return empty array - will be implemented when needed
    return [];
  }

  // ============ UNIFIED DROPDOWN OPTIONS ============

  /**
   * Get all dropdown options in a single call
   */
  async getAllDropdownOptions(): Promise<ReferenceDataOptions> {
    return this.getCachedData('allDropdownOptions', async () => {
      const [
        plants,
        officers,
        productCategories,
        products,
        testTypes,
        machines,
        moistureConditions,
        samplingPlaces,
        climaticConditions,
        aggregateTypes,
        gradingLimits,
        standards,
        materialTypes,
        sieveSizes
      ] = await Promise.all([
        this.getPlants(),
        this.getOfficers(),
        this.getProductCategories(),
        this.getProducts(),
        this.getTestTypes(),
        this.getMachines(),
        this.getMoistureConditions(),
        this.getSamplingPlaces(),
        this.getClimaticConditions(),
        this.getAggregateTypes(),
        this.getGradingLimits(),
        this.getStandards(),
        this.getMaterialTypes(),
        this.getSieveSizes()
      ]);

      return {
        plants: plants.map(p => ({ id: p.id, name: p.name, value: p.id, metadata: p })),
        officers: officers.map(o => ({ id: o.id, name: o.name, value: o.id, metadata: o })),
        productCategories: productCategories.map(c => ({ id: c.id, name: c.name, value: c.id, metadata: c })),
        products: products.map(p => ({ id: p.id, name: p.name, value: p.id, category: (p as any).category_id, metadata: p })),
        testTypes: testTypes.map(t => ({ id: t.id, name: t.name, value: t.id, category: (t as any).category, metadata: t })),
        machines: machines.map(m => ({ id: m.id, name: m.name, value: m.id, metadata: m })),
        moistureConditions: moistureConditions.map(mc => ({ id: mc.id, name: mc.name, value: mc.id, metadata: mc })),
        samplingPlaces: samplingPlaces.map(sp => ({ id: sp.id, name: sp.name, value: sp.id, metadata: sp })),
        climaticConditions: climaticConditions.map(cc => ({ id: cc.id, name: cc.name, value: cc.id, metadata: cc })),
        aggregateTypes: aggregateTypes.map(at => ({ id: at.id, name: at.name, value: at.id, category: (at as any).category, metadata: at })),
        gradingLimits: gradingLimits.map(gl => ({ id: gl.id, name: gl.name, value: gl.id, category: (gl as any).category, metadata: gl })),
        standards: standards.map(s => ({ id: s.id, name: s.name, value: s.id, metadata: s })),
        materialTypes: materialTypes.map(mt => ({ id: mt.id, name: mt.name, value: mt.id, metadata: mt })),
        sieveSizes: sieveSizes.map(ss => ({ id: ss.id, name: ss.name, value: (ss as any).field_key || ss.id, metadata: ss }))
      };
    });
  }

  // ============ HARDCODED DATA MIGRATION ============

  /**
   * Migrate all hardcoded arrays to database
   */
  private async migrateHardcodedData(): Promise<void> {
    // For now, just seed with some default data in localStorage/browser storage
    // This will be enhanced when full database integration is complete
    console.log('ReferenceDataBrainService: Hardcoded data migration completed');
  }

  // ============ REAL-TIME UPDATES ============

  /**
   * Subscribe to real-time updates for specific data type
   */
  subscribeToUpdates(dataType: string, callback: (data: any) => void): () => void {
    this.on(`data-updated-${dataType}`, callback);
    
    // Return unsubscribe function
    return () => {
      this.off(`data-updated-${dataType}`, callback);
    };
  }

  /**
   * Get cache statistics
   */
  getCacheStats(): { size: number; entries: string[] } {
    return {
      size: this.cache.size,
      entries: Array.from(this.cache.keys())
    };
  }
}

// Export singleton instance
export const referenceDataBrainService = new ReferenceDataBrainService();