// Database schema definitions for TestDataExplorer advanced features
export const TEST_DATA_SCHEMA = `
-- Enhanced test data entries table with plant-specific support
CREATE TABLE IF NOT EXISTS test_data_entries (
  id TEXT PRIMARY KEY,
  module_id TEXT NOT NULL,
  test_type TEXT NOT NULL,
  batch_id TEXT,
  product_type TEXT,
  test_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  site TEXT,
  plant_id TEXT,
  memo_reference TEXT,
  operator TEXT,
  machine_used TEXT,
  test_results TEXT NOT NULL, -- JSON string with test values
  calculated_fields TEXT, -- JSON string with derived values
  pass_fail_status TEXT CHECK(pass_fail_status IN ('pass', 'fail', 'pending')) DEFAULT 'pending',
  source TEXT DEFAULT 'manual' CHECK(source IN ('manual', 'imported', 'liveshare')),
  raw_data TEXT, -- JSON string for original imported data
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT
);

-- Test data comparisons table for side-by-side analysis
CREATE TABLE IF NOT EXISTS test_data_comparisons (
  id TEXT PRIMARY KEY,
  test_ids TEXT NOT NULL, -- JSON array of test entry IDs
  compared_by TEXT NOT NULL,
  compared_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  summary TEXT, -- JSON string with comparison summary
  differences TEXT, -- JSON string with highlighted differences
  notes TEXT
);

-- Test conformity checks table for standards compliance
CREATE TABLE IF NOT EXISTS test_conformity_checks (
  id TEXT PRIMARY KEY,
  test_id TEXT NOT NULL,
  check_result TEXT CHECK(check_result IN ('pass', 'fail', 'warning')) NOT NULL,
  failed_fields TEXT, -- JSON array of fields that failed
  rule_set TEXT NOT NULL, -- BS, RDA, UBP, etc.
  rule_details TEXT, -- JSON string with rule specifications
  checked_by TEXT NOT NULL,
  checked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (test_id) REFERENCES test_data_entries(id) ON DELETE CASCADE
);

-- Plant-specific database tables
CREATE TABLE IF NOT EXISTS plants (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  location TEXT,
  database_file TEXT, -- Path to plant-specific SQLite file
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Machines table for filtering by equipment
CREATE TABLE IF NOT EXISTS machines (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  plant_id TEXT,
  machine_type TEXT,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (plant_id) REFERENCES plants(id)
);

-- Test standards and rules for conformity checking
CREATE TABLE IF NOT EXISTS test_standards (
  id TEXT PRIMARY KEY,
  standard_name TEXT NOT NULL, -- BS, RDA, UBP, etc.
  product_type TEXT NOT NULL,
  test_type TEXT NOT NULL,
  rules TEXT NOT NULL, -- JSON string with validation rules
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Performance analytics cache table
CREATE TABLE IF NOT EXISTS test_performance_analytics (
  id TEXT PRIMARY KEY,
  plant_id TEXT,
  product_type TEXT,
  test_type TEXT,
  period_start DATETIME NOT NULL,
  period_end DATETIME NOT NULL,
  total_tests INTEGER DEFAULT 0,
  passed_tests INTEGER DEFAULT 0,
  failed_tests INTEGER DEFAULT 0,
  conformity_percentage REAL DEFAULT 0,
  average_result REAL,
  trend_direction TEXT, -- 'improving', 'declining', 'stable'
  generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (plant_id) REFERENCES plants(id)
);

-- Data import/export log
CREATE TABLE IF NOT EXISTS test_data_import_log (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  file_type TEXT NOT NULL, -- csv, excel
  rows_imported INTEGER DEFAULT 0,
  rows_failed INTEGER DEFAULT 0,
  status TEXT CHECK(status IN ('success', 'error', 'partial')) NOT NULL,
  error_details TEXT, -- JSON string with error information
  column_mapping TEXT, -- JSON string with mapping used
  imported_by TEXT,
  import_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Predictive analytics data
CREATE TABLE IF NOT EXISTS test_predictions (
  id TEXT PRIMARY KEY,
  test_id TEXT NOT NULL,
  prediction_type TEXT NOT NULL, -- 'failure_risk', 'quality_score', etc.
  prediction_value REAL NOT NULL,
  confidence_level REAL NOT NULL, -- 0-1 scale
  prediction_factors TEXT, -- JSON string with contributing factors
  recommendation TEXT,
  prediction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  model_version TEXT DEFAULT '1.0',
  FOREIGN KEY (test_id) REFERENCES test_data_entries(id) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_test_data_entries_plant_date ON test_data_entries(plant_id, test_date);
CREATE INDEX IF NOT EXISTS idx_test_data_entries_type ON test_data_entries(test_type);
CREATE INDEX IF NOT EXISTS idx_test_data_entries_status ON test_data_entries(pass_fail_status);
CREATE INDEX IF NOT EXISTS idx_test_conformity_checks_test_id ON test_conformity_checks(test_id);
CREATE INDEX IF NOT EXISTS idx_test_performance_analytics_plant_period ON test_performance_analytics(plant_id, period_start, period_end);
`;

// Default data for test standards
export const DEFAULT_TEST_STANDARDS = [
  {
    id: 'std-bs-aggregates-silt',
    standard_name: 'BS',
    product_type: 'Aggregates',
    test_type: 'Silt & Clay content',
    rules: JSON.stringify({
      silt_content: { min: 0, max: 3, unit: '%', description: 'Silt content by mass' },
      clay_content: { min: 0, max: 2, unit: '%', description: 'Clay content by mass' },
      total_fines: { min: 0, max: 5, unit: '%', description: 'Total fines content' }
    })
  },
  {
    id: 'std-bs-concrete-compressive',
    standard_name: 'BS',
    product_type: 'Concrete',
    test_type: 'Compressive Strength',
    rules: JSON.stringify({
      compressive_strength: { min: 25, max: 100, unit: 'MPa', description: '28-day compressive strength' },
      density: { min: 2200, max: 2600, unit: 'kg/m³', description: 'Concrete density' }
    })
  },
  {
    id: 'std-ubp-blocks-density',
    standard_name: 'UBP',
    product_type: 'Blocks',
    test_type: 'Density Test',
    rules: JSON.stringify({
      density: { min: 1800, max: 2400, unit: 'kg/m³', description: 'Block density' },
      compressive_strength: { min: 15, max: 50, unit: 'MPa', description: 'Block compressive strength' }
    })
  }
];

// Default plants data
export const DEFAULT_PLANTS = [
  {
    id: 'plant-ubp-main',
    code: 'UBP-001',
    name: 'UBP Main Plant',
    location: 'Port Louis, Mauritius',
    database_file: 'ubp_main.db'
  },
  {
    id: 'plant-ubp-north',
    code: 'UBP-002', 
    name: 'UBP North Plant',
    location: 'Goodlands, Mauritius',
    database_file: 'ubp_north.db'
  },
  {
    id: 'plant-ubp-central',
    code: 'UBP-003',
    name: 'UBP Central Lab',
    location: 'Curepipe, Mauritius',
    database_file: 'ubp_central.db'
  }
];

// Default machines data
export const DEFAULT_MACHINES = [
  { id: 'machine-001', code: 'MIX-001', name: 'Concrete Mixer 1', plant_id: 'plant-ubp-main', machine_type: 'mixer' },
  { id: 'machine-002', code: 'MIX-002', name: 'Concrete Mixer 2', plant_id: 'plant-ubp-main', machine_type: 'mixer' },
  { id: 'machine-003', code: 'PRESS-001', name: 'Block Press 1', plant_id: 'plant-ubp-north', machine_type: 'press' },
  { id: 'machine-004', code: 'CRUSH-001', name: 'Aggregate Crusher', plant_id: 'plant-ubp-central', machine_type: 'crusher' },
  { id: 'machine-005', code: 'SIEVE-001', name: 'Sieve Shaker', plant_id: 'plant-ubp-central', machine_type: 'analyzer' }
];