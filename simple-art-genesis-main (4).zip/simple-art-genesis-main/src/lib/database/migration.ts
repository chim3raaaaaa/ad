// Database Migration Utilities
import { unifiedDataService } from './UnifiedDataService';

export interface MigrationStep {
  id: string;
  description: string;
  execute: () => Promise<void>;
  rollback?: () => Promise<void>;
}

export class DatabaseMigration {
  private migrations: MigrationStep[] = [];

  constructor() {
    this.setupMigrations();
  }

  private setupMigrations(): void {
    // Migration 1: Move data from legacy services to unified schema
    this.migrations.push({
      id: '001_unify_test_data',
      description: 'Migrate test data from legacy services to unified test_entries table',
      execute: async () => {
        await this.migrateTestData();
      },
      rollback: async () => {
        console.warn('Rollback not implemented for test data migration');
      }
    });

    // Migration 2: Migrate memos from localStorage to unified schema
    this.migrations.push({
      id: '002_migrate_memos',
      description: 'Migrate memos from localStorage to unified memos table',
      execute: async () => {
        await this.migrateMemos();
      }
    });

    // Migration 3: Create default admin user
    this.migrations.push({
      id: '003_create_admin_user',
      description: 'Create default admin user and assign permissions',
      execute: async () => {
        await this.createDefaultAdmin();
      }
    });
  }

  async runMigrations(): Promise<{ success: boolean; results: any[] }> {
    const results: any[] = [];

    try {
      await unifiedDataService.initialize();

      for (const migration of this.migrations) {
        console.log(`Running migration: ${migration.description}`);
        
        try {
          await migration.execute();
          results.push({
            id: migration.id,
            status: 'success',
            description: migration.description
          });
          console.log(`✓ Migration ${migration.id} completed successfully`);
        } catch (error) {
          console.error(`✗ Migration ${migration.id} failed:`, error);
          results.push({
            id: migration.id,
            status: 'failed',
            description: migration.description,
            error: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      return { success: true, results };
    } catch (error) {
      console.error('Migration process failed:', error);
      return { 
        success: false, 
        results: [
          ...results,
          {
            id: 'migration_process',
            status: 'failed',
            description: 'Migration process failed',
            error: error instanceof Error ? error.message : 'Unknown error'
          }
        ]
      };
    }
  }

  private async migrateTestData(): Promise<void> {
    // Check for existing data in localStorage or legacy tables
    const legacyTables = [
      'aggregate_tests',
      'concrete_tests', 
      'block_tests',
      'direct_input_results'
    ];

    for (const tableName of legacyTables) {
      try {
        // Try to get data from localStorage first
        const localData = localStorage.getItem(`lims_${tableName}`);
        if (localData) {
          const entries = JSON.parse(localData);
          console.log(`Found ${entries.length} entries in localStorage ${tableName}`);
          
          for (const entry of entries) {
            await this.migrateTestEntry(entry, tableName);
          }
        }

        // TODO: Also check for data in SQLite legacy tables if they exist
        
      } catch (error) {
        console.warn(`Could not migrate data from ${tableName}:`, error);
      }
    }
  }

  private async migrateTestEntry(legacyEntry: any, sourceTable: string): Promise<void> {
    try {
      // Map legacy entry to unified format
      const unifiedEntry = {
        plant_id: legacyEntry.plant_id || legacyEntry.plantId || 'default_plant',
        product_type_id: this.mapProductType(sourceTable, legacyEntry),
        officer_id: legacyEntry.officer_id || legacyEntry.operator || 'default_officer',
        test_date: legacyEntry.test_date || legacyEntry.testDate || new Date().toISOString(),
        production_date: legacyEntry.production_date || legacyEntry.productionDate,
        batch_number: legacyEntry.batch_number || legacyEntry.batchNumber,
        sample_id: legacyEntry.sample_id || legacyEntry.sampleId || legacyEntry.id,
        age_days: legacyEntry.age_days || legacyEntry.ageDays,
        status: this.mapStatus(legacyEntry.status),
        grading_conformity: legacyEntry.grading_conformity || legacyEntry.gradingConformity,
        cleanliness_conformity: legacyEntry.cleanliness_conformity,
        overall_conformity: legacyEntry.overall_conformity || legacyEntry.conformity,
        test_data: this.extractTestData(legacyEntry),
        comments: legacyEntry.comments || legacyEntry.notes,
        created_by: legacyEntry.created_by || legacyEntry.createdBy || 'migration_user',
        updated_by: legacyEntry.updated_by || 'migration_user'
      };

      await unifiedDataService.createTestEntry(unifiedEntry);
    } catch (error) {
      console.error(`Failed to migrate entry from ${sourceTable}:`, error);
    }
  }

  private mapProductType(sourceTable: string, entry: any): string {
    // Map source table to product type
    const mapping: Record<string, string> = {
      'aggregate_tests': 'aggregates',
      'concrete_tests': 'concrete_cubes',
      'block_tests': 'blocks',
      'direct_input_results': entry.product_type || 'unknown'
    };

    return mapping[sourceTable] || 'unknown';
  }

  private mapStatus(legacyStatus: any): 'draft' | 'completed' | 'approved' | 'rejected' {
    if (!legacyStatus) return 'draft';
    
    const status = legacyStatus.toLowerCase();
    if (status.includes('approved') || status === 'approved') return 'approved';
    if (status.includes('rejected') || status === 'rejected') return 'rejected';
    if (status.includes('completed') || status === 'completed') return 'completed';
    if (status === 'pass' || status === 'fail') return 'completed';
    
    return 'draft';
  }

  private extractTestData(legacyEntry: any): Record<string, any> {
    // Extract test-specific data, excluding metadata fields
    const excludeFields = [
      'id', 'plant_id', 'plantId', 'officer_id', 'operator', 'test_date', 'testDate',
      'production_date', 'productionDate', 'batch_number', 'batchNumber',
      'sample_id', 'sampleId', 'age_days', 'ageDays', 'status', 'comments', 'notes',
      'created_at', 'updated_at', 'created_by', 'createdBy', 'updated_by'
    ];

    const testData: Record<string, any> = {};
    
    Object.entries(legacyEntry).forEach(([key, value]) => {
      if (!excludeFields.includes(key) && value !== null && value !== undefined) {
        testData[key] = value;
      }
    });

    return testData;
  }

  private async migrateMemos(): Promise<void> {
    try {
      const localMemos = localStorage.getItem('lims_memos');
      if (localMemos) {
        const memos = JSON.parse(localMemos);
        console.log(`Found ${memos.length} memos in localStorage`);
        
        for (const memo of memos) {
          const unifiedMemo = {
            reference: memo.reference || `MEMO-${Date.now()}`,
            title: memo.title || 'Migrated Memo',
            description: memo.description,
            plant_id: memo.plant_id || memo.plantId || 'default_plant',
            officer_id: memo.officer_id || memo.officerId || 'default_officer',
            priority: memo.priority || 'normal',
            status: memo.status || 'draft',
            requested_by: memo.requested_by || memo.requestedBy || 'migration_user',
            assigned_to: memo.assigned_to || memo.assignedTo,
            due_date: memo.due_date || memo.dueDate,
            notes: memo.notes
          };

          await unifiedDataService.createMemo(unifiedMemo);
        }
      }
    } catch (error) {
      console.error('Failed to migrate memos:', error);
    }
  }

  private async createDefaultAdmin(): Promise<void> {
    try {
      // Check if admin user already exists
      const existingUsers = await unifiedDataService['querySQL']('SELECT id FROM users WHERE username = ?', ['admin']);
      
      if (existingUsers.length === 0) {
        const adminUser = {
          username: 'admin',
          email: 'admin@lab.com',
          password_hash: 'admin123', // In production, this should be properly hashed
          full_name: 'Laboratory Administrator',
          status: 'active' as const
        };

        const result = await unifiedDataService['executeSQL'](
          `INSERT INTO users (id, username, email, password_hash, full_name, status, created_at, updated_at, version)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            'admin-user-id',
            adminUser.username,
            adminUser.email,
            adminUser.password_hash,
            adminUser.full_name,
            adminUser.status,
            new Date().toISOString(),
            new Date().toISOString(),
            1
          ]
        );

        // Assign admin role
        const adminRole = await unifiedDataService['querySQL']('SELECT id FROM roles WHERE name = ?', ['lab_admin']);
        if (adminRole.length > 0) {
          await unifiedDataService['executeSQL'](
            'INSERT INTO user_roles (id, user_id, role_id, assigned_by, assigned_at) VALUES (?, ?, ?, ?, ?)',
            ['admin-role-assignment', 'admin-user-id', adminRole[0].id, 'system', new Date().toISOString()]
          );
        }

        console.log('Default admin user created successfully');
      } else {
        console.log('Admin user already exists, skipping creation');
      }
    } catch (error) {
      console.error('Failed to create default admin user:', error);
    }
  }

  async checkMigrationStatus(): Promise<{ needsMigration: boolean; details: any }> {
    try {
      await unifiedDataService.initialize();
      
      const userCount = await unifiedDataService['querySQL']('SELECT COUNT(*) as count FROM users');
      const testCount = await unifiedDataService['querySQL']('SELECT COUNT(*) as count FROM test_entries');
      const memoCount = await unifiedDataService['querySQL']('SELECT COUNT(*) as count FROM memos');

      // Check for legacy data
      const legacyData = {
        localStorage: {
          memos: localStorage.getItem('lims_memos') ? JSON.parse(localStorage.getItem('lims_memos')!).length : 0,
          aggregateTests: localStorage.getItem('lims_aggregate_tests') ? JSON.parse(localStorage.getItem('lims_aggregate_tests')!).length : 0,
          concreteTests: localStorage.getItem('lims_concrete_tests') ? JSON.parse(localStorage.getItem('lims_concrete_tests')!).length : 0
        }
      };

      const hasLegacyData = Object.values(legacyData.localStorage).some(count => count > 0);
      const hasUnifiedData = userCount[0].count > 0 || testCount[0].count > 0 || memoCount[0].count > 0;

      return {
        needsMigration: hasLegacyData && !hasUnifiedData,
        details: {
          unified: {
            users: userCount[0].count,
            tests: testCount[0].count,
            memos: memoCount[0].count
          },
          legacy: legacyData
        }
      };
    } catch (error) {
      return {
        needsMigration: true,
        details: { error: error instanceof Error ? error.message : 'Unknown error' }
      };
    }
  }
}

export const databaseMigration = new DatabaseMigration();