// Unified Data Service - Single point of access for all database operations
import { v4 as uuidv4 } from 'uuid';
import { UNIFIED_SCHEMA, DEFAULT_PERMISSIONS, DEFAULT_ROLES } from './schema';

// Base interfaces
export interface BaseEntity {
  id: string;
  created_at?: string;
  updated_at?: string;
  version?: number;
}

export interface User extends BaseEntity {
  username: string;
  email: string;
  password_hash: string;
  full_name: string;
  department_id?: string;
  status: 'active' | 'inactive' | 'suspended';
  last_login?: string;
  session_token?: string;
}

export interface Memo extends BaseEntity {
  reference: string;
  title: string;
  description?: string;
  plant_id: string;
  officer_id: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'draft' | 'submitted' | 'in_progress' | 'completed' | 'approved' | 'rejected';
  requested_by: string;
  assigned_to?: string;
  due_date?: string;
  completed_at?: string;
  approved_by?: string;
  approved_at?: string;
  notes?: string;
  attachments?: string;
}

export interface TestEntry extends BaseEntity {
  assignment_id?: string;
  memo_id?: string;
  plant_id: string;
  product_type_id: string;
  test_type_id?: string;
  officer_id: string;
  machine_id?: string;
  test_date: string;
  production_date?: string;
  batch_number?: string;
  sample_id?: string;
  age_days?: number;
  status: 'draft' | 'completed' | 'approved' | 'rejected';
  grading_conformity?: 'pass' | 'fail' | 'pending';
  cleanliness_conformity?: 'pass' | 'fail' | 'pending';
  overall_conformity?: 'pass' | 'fail' | 'pending';
  test_data: Record<string, any>;
  calculations?: Record<string, any>;
  comments?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  approved_by?: string;
  approved_at?: string;
  created_by: string;
  updated_by: string;
}

export interface ReferenceDataEntity extends BaseEntity {
  code: string;
  name: string;
  description?: string;
  is_active: boolean;
}

// Query options
export interface QueryOptions {
  limit?: number;
  offset?: number;
  orderBy?: string;
  orderDirection?: 'ASC' | 'DESC';
  filters?: Record<string, any>;
  search?: string;
}

// API Response format
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  total?: number;
}

// Main Unified Data Service
export class UnifiedDataService {
  private isElectron: boolean;
  private isInitialized: boolean = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && (window as any).electronAPI;
  }

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        // Initialize SQLite database
        await this.executeSQL(UNIFIED_SCHEMA);
        await this.seedDefaultData();
      } else {
        // Browser fallback - use IndexedDB or localStorage
        await this.initializeBrowserStorage();
      }
      
      this.isInitialized = true;
      console.log('UnifiedDataService initialized successfully');
    } catch (error) {
      console.error('Failed to initialize UnifiedDataService:', error);
      throw error;
    }
  }

  private async seedDefaultData(): Promise<void> {
    // Seed permissions
    for (const permission of DEFAULT_PERMISSIONS) {
      await this.executeSQL(
        'INSERT OR IGNORE INTO permissions (id, name, resource, action, description) VALUES (?, ?, ?, ?, ?)',
        [uuidv4(), permission.name, permission.resource, permission.action, permission.description]
      );
    }

    // Seed roles
    for (const role of DEFAULT_ROLES) {
      const roleId = uuidv4();
      await this.executeSQL(
        'INSERT OR IGNORE INTO roles (id, name, description, is_system) VALUES (?, ?, ?, ?)',
        [roleId, role.name, role.description, 1]
      );

      // Assign permissions to role
      for (const permissionName of role.permissions) {
        const permission = await this.querySQL(
          'SELECT id FROM permissions WHERE name = ?',
          [permissionName]
        );
        
        if (permission.length > 0) {
          await this.executeSQL(
            'INSERT OR IGNORE INTO role_permissions (id, role_id, permission_id, granted_by) VALUES (?, ?, ?, ?)',
            [uuidv4(), roleId, permission[0].id, 'system']
          );
        }
      }
    }
  }

  private async initializeBrowserStorage(): Promise<void> {
    // Initialize browser-based storage (IndexedDB/localStorage)
    const tables = this.extractTableNames(UNIFIED_SCHEMA);
    for (const table of tables) {
      const existingData = localStorage.getItem(`lims_${table}`);
      if (!existingData) {
        localStorage.setItem(`lims_${table}`, JSON.stringify([]));
      }
    }
  }

  // ============================================================================
  // CORE DATABASE OPERATIONS
  // ============================================================================

  private async executeSQL(sql: string, params: any[] = []): Promise<any> {
    if (this.isElectron) {
      return await (window as any).electronAPI.dbRun(sql, params);
    } else {
      // Browser fallback
      return this.executeBrowserSQL(sql, params);
    }
  }

  private async querySQL(sql: string, params: any[] = []): Promise<any[]> {
    if (this.isElectron) {
      return await (window as any).electronAPI.dbQuery(sql, params);
    } else {
      // Browser fallback
      return this.queryBrowserSQL(sql, params);
    }
  }

  private executeBrowserSQL(sql: string, params: any[]): Promise<any> {
    // Simple browser implementation - in production would use IndexedDB
    return Promise.resolve({ success: true });
  }

  private queryBrowserSQL(sql: string, params: any[]): Promise<any[]> {
    // Simple browser implementation - in production would use IndexedDB
    const tableName = this.extractTableNameFromQuery(sql);
    const data = JSON.parse(localStorage.getItem(`lims_${tableName}`) || '[]');
    return Promise.resolve(data);
  }

  // ============================================================================
  // RBAC OPERATIONS
  // ============================================================================

  async hasPermission(userId: string, permission: string): Promise<boolean> {
    if (!this.isInitialized) await this.initialize();

    const sql = `
      SELECT COUNT(*) as count FROM user_roles ur
      JOIN role_permissions rp ON ur.role_id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE ur.user_id = ? AND p.name = ?
      AND (ur.expires_at IS NULL OR ur.expires_at > datetime('now'))
    `;

    const result = await this.querySQL(sql, [userId, permission]);
    return result[0]?.count > 0;
  }

  async getUserPermissions(userId: string): Promise<string[]> {
    if (!this.isInitialized) await this.initialize();

    const sql = `
      SELECT DISTINCT p.name FROM user_roles ur
      JOIN role_permissions rp ON ur.role_id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE ur.user_id = ?
      AND (ur.expires_at IS NULL OR ur.expires_at > datetime('now'))
    `;

    const result = await this.querySQL(sql, [userId]);
    return result.map(row => row.name);
  }

  // ============================================================================
  // MEMO OPERATIONS
  // ============================================================================

  async createMemo(memo: Omit<Memo, 'id' | 'created_at' | 'updated_at' | 'version'>): Promise<ApiResponse<Memo>> {
    try {
      if (!this.isInitialized) await this.initialize();

      const id = uuidv4();
      const now = new Date().toISOString();
      const newMemo: Memo = {
        ...memo,
        id,
        created_at: now,
        updated_at: now,
        version: 1
      };

      const sql = `
        INSERT INTO memos (
          id, reference, title, description, plant_id, officer_id, priority, status,
          requested_by, assigned_to, due_date, notes, attachments, created_at, updated_at, version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await this.executeSQL(sql, [
        newMemo.id, newMemo.reference, newMemo.title, newMemo.description,
        newMemo.plant_id, newMemo.officer_id, newMemo.priority, newMemo.status,
        newMemo.requested_by, newMemo.assigned_to, newMemo.due_date,
        newMemo.notes, newMemo.attachments, newMemo.created_at, newMemo.updated_at, newMemo.version
      ]);

      await this.logAudit(newMemo.requested_by, 'CREATE', 'memo', newMemo.id, null, newMemo);

      return { success: true, data: newMemo };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getMemos(options: QueryOptions = {}): Promise<ApiResponse<Memo[]>> {
    try {
      if (!this.isInitialized) await this.initialize();

      let sql = 'SELECT * FROM memos WHERE 1=1';
      const params: any[] = [];

      if (options.filters) {
        Object.entries(options.filters).forEach(([key, value]) => {
          sql += ` AND ${key} = ?`;
          params.push(value);
        });
      }

      if (options.search) {
        sql += ' AND (title LIKE ? OR description LIKE ? OR reference LIKE ?)';
        params.push(`%${options.search}%`, `%${options.search}%`, `%${options.search}%`);
      }

      if (options.orderBy) {
        sql += ` ORDER BY ${options.orderBy} ${options.orderDirection || 'ASC'}`;
      } else {
        sql += ' ORDER BY created_at DESC';
      }

      if (options.limit) {
        sql += ` LIMIT ${options.limit}`;
        if (options.offset) {
          sql += ` OFFSET ${options.offset}`;
        }
      }

      const results = await this.querySQL(sql, params);
      return { success: true, data: results, total: results.length };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // ============================================================================
  // TEST ENTRY OPERATIONS
  // ============================================================================

  async createTestEntry(entry: Omit<TestEntry, 'id' | 'created_at' | 'updated_at' | 'version'>): Promise<ApiResponse<TestEntry>> {
    try {
      if (!this.isInitialized) await this.initialize();

      const id = uuidv4();
      const now = new Date().toISOString();
      const newEntry: TestEntry = {
        ...entry,
        id,
        created_at: now,
        updated_at: now,
        version: 1
      };

      const sql = `
        INSERT INTO test_entries (
          id, assignment_id, memo_id, plant_id, product_type_id, test_type_id, officer_id,
          machine_id, test_date, production_date, batch_number, sample_id, age_days,
          status, grading_conformity, cleanliness_conformity, overall_conformity,
          test_data, calculations, comments, created_by, updated_by, created_at, updated_at, version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await this.executeSQL(sql, [
        newEntry.id, newEntry.assignment_id, newEntry.memo_id, newEntry.plant_id,
        newEntry.product_type_id, newEntry.test_type_id, newEntry.officer_id,
        newEntry.machine_id, newEntry.test_date, newEntry.production_date,
        newEntry.batch_number, newEntry.sample_id, newEntry.age_days,
        newEntry.status, newEntry.grading_conformity, newEntry.cleanliness_conformity,
        newEntry.overall_conformity, JSON.stringify(newEntry.test_data),
        JSON.stringify(newEntry.calculations || {}), newEntry.comments,
        newEntry.created_by, newEntry.updated_by, newEntry.created_at, newEntry.updated_at, newEntry.version
      ]);

      await this.logAudit(newEntry.created_by, 'CREATE', 'test_entry', newEntry.id, null, newEntry);

      return { success: true, data: newEntry };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getTestEntries(options: QueryOptions = {}): Promise<ApiResponse<TestEntry[]>> {
    try {
      if (!this.isInitialized) await this.initialize();

      let sql = 'SELECT * FROM test_entries WHERE 1=1';
      const params: any[] = [];

      if (options.filters) {
        Object.entries(options.filters).forEach(([key, value]) => {
          sql += ` AND ${key} = ?`;
          params.push(value);
        });
      }

      if (options.search) {
        sql += ' AND (comments LIKE ? OR batch_number LIKE ? OR sample_id LIKE ?)';
        params.push(`%${options.search}%`, `%${options.search}%`, `%${options.search}%`);
      }

      sql += ' ORDER BY test_date DESC, created_at DESC';

      if (options.limit) {
        sql += ` LIMIT ${options.limit}`;
        if (options.offset) {
          sql += ` OFFSET ${options.offset}`;
        }
      }

      const results = await this.querySQL(sql, params);
      const entries = results.map(row => ({
        ...row,
        test_data: JSON.parse(row.test_data || '{}'),
        calculations: JSON.parse(row.calculations || '{}')
      }));

      return { success: true, data: entries, total: entries.length };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // ============================================================================
  // REFERENCE DATA OPERATIONS
  // ============================================================================

  async getReferenceData(tableName: string, options: QueryOptions = {}): Promise<ApiResponse<any[]>> {
    try {
      if (!this.isInitialized) await this.initialize();

      let sql = `SELECT * FROM ${tableName} WHERE 1=1`;
      const params: any[] = [];

      if (options.filters) {
        Object.entries(options.filters).forEach(([key, value]) => {
          sql += ` AND ${key} = ?`;
          params.push(value);
        });
      }

      // Default to active records only
      if (!options.filters?.is_active) {
        sql += ' AND is_active = 1';
      }

      sql += ' ORDER BY name ASC';

      const results = await this.querySQL(sql, params);
      return { success: true, data: results, total: results.length };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // ============================================================================
  // AUDIT LOGGING
  // ============================================================================

  private async logAudit(
    userId: string,
    action: string,
    entityType: string,
    entityId: string,
    oldValues: any = null,
    newValues: any = null
  ): Promise<void> {
    try {
      const sql = `
        INSERT INTO audit_logs (id, user_id, action, entity_type, entity_id, old_values, new_values, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await this.executeSQL(sql, [
        uuidv4(),
        userId,
        action,
        entityType,
        entityId,
        oldValues ? JSON.stringify(oldValues) : null,
        newValues ? JSON.stringify(newValues) : null,
        new Date().toISOString()
      ]);
    } catch (error) {
      console.error('Failed to log audit entry:', error);
    }
  }

  // ============================================================================
  // UTILITY METHODS
  // ============================================================================

  private extractTableNames(schema: string): string[] {
    const matches = schema.match(/CREATE TABLE IF NOT EXISTS (\w+)/g);
    return matches ? matches.map(match => match.split(' ').pop()!) : [];
  }

  private extractTableNameFromQuery(sql: string): string {
    const match = sql.match(/FROM\s+(\w+)/i);
    return match ? match[1] : 'unknown';
  }

  // ============================================================================
  // HEALTH CHECK
  // ============================================================================

  async healthCheck(): Promise<{ status: string; details: any }> {
    try {
      if (!this.isInitialized) await this.initialize();

      const tables = await this.querySQL("SELECT name FROM sqlite_master WHERE type='table'");
      const userCount = await this.querySQL("SELECT COUNT(*) as count FROM users");
      const memoCount = await this.querySQL("SELECT COUNT(*) as count FROM memos");
      const testCount = await this.querySQL("SELECT COUNT(*) as count FROM test_entries");

      return {
        status: 'healthy',
        details: {
          isElectron: this.isElectron,
          isInitialized: this.isInitialized,
          tableCount: tables.length,
          userCount: userCount[0]?.count || 0,
          memoCount: memoCount[0]?.count || 0,
          testCount: testCount[0]?.count || 0
        }
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        details: { error: error instanceof Error ? error.message : 'Unknown error' }
      };
    }
  }
}

// Export singleton instance
export const unifiedDataService = new UnifiedDataService();