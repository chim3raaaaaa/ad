// Unified Database Schema for Laboratory Management System
// This is the single source of truth for all database tables

export const UNIFIED_SCHEMA = `
-- ============================================================================
-- CORE SYSTEM TABLES
-- ============================================================================

-- Users and Authentication
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  department_id TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  last_login TEXT,
  session_token TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (department_id) REFERENCES departments(id)
);

-- Roles and Permissions
CREATE TABLE IF NOT EXISTS roles (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  is_system BOOLEAN DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS permissions (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  resource TEXT NOT NULL,
  action TEXT NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS role_permissions (
  id TEXT PRIMARY KEY,
  role_id TEXT NOT NULL,
  permission_id TEXT NOT NULL,
  granted_by TEXT NOT NULL,
  granted_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
  FOREIGN KEY (granted_by) REFERENCES users(id),
  UNIQUE(role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS user_roles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  assigned_by TEXT NOT NULL,
  assigned_at TEXT DEFAULT (datetime('now')),
  expires_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES users(id),
  UNIQUE(user_id, role_id)
);

-- ============================================================================
-- REFERENCE DATA TABLES ("THE BRAIN")
-- ============================================================================

-- Organizational Structure
CREATE TABLE IF NOT EXISTS departments (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  manager_id TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (manager_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS plants (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  location TEXT,
  database_file TEXT,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS officers (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  department_id TEXT,
  plant_id TEXT,
  email TEXT,
  phone TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (department_id) REFERENCES departments(id),
  FOREIGN KEY (plant_id) REFERENCES plants(id)
);

-- Product Categories and Types
CREATE TABLE IF NOT EXISTS product_categories (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS product_types (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  unit TEXT,
  test_schema TEXT, -- JSON schema for test fields
  validation_rules TEXT, -- JSON validation rules
  conformity_limits TEXT, -- JSON conformity limits
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (category_id) REFERENCES product_categories(id)
);

-- Test Types and Standards
CREATE TABLE IF NOT EXISTS test_types (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT,
  duration_days INTEGER,
  required_fields TEXT, -- JSON array of required field names
  calculation_method TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS test_standards (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  authority TEXT, -- BS, UBP, ASTM, etc.
  version TEXT,
  product_type_id TEXT,
  test_type_id TEXT,
  specification TEXT, -- JSON specification details
  limits TEXT, -- JSON limits and thresholds
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version_number INTEGER DEFAULT 1,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (test_type_id) REFERENCES test_types(id)
);

-- Materials and Components
CREATE TABLE IF NOT EXISTS materials (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  category TEXT,
  supplier TEXT,
  specification TEXT,
  unit TEXT,
  cost_per_unit REAL,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1
);

-- Machines and Equipment
CREATE TABLE IF NOT EXISTS machines (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  plant_id TEXT NOT NULL,
  machine_type TEXT,
  manufacturer TEXT,
  model TEXT,
  capacity TEXT,
  calibration_date TEXT,
  next_calibration TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (plant_id) REFERENCES plants(id)
);

-- System Settings and Configuration
CREATE TABLE IF NOT EXISTS app_settings (
  id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT,
  data_type TEXT DEFAULT 'string' CHECK (data_type IN ('string', 'number', 'boolean', 'json')),
  description TEXT,
  is_encrypted BOOLEAN DEFAULT 0,
  updated_by TEXT,
  updated_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (updated_by) REFERENCES users(id),
  UNIQUE(category, key)
);

-- ============================================================================
-- OPERATIONAL TABLES
-- ============================================================================

-- Memos and Test Requests
CREATE TABLE IF NOT EXISTS memos (
  id TEXT PRIMARY KEY,
  reference TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  plant_id TEXT NOT NULL,
  officer_id TEXT NOT NULL,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'in_progress', 'completed', 'approved', 'rejected')),
  requested_by TEXT NOT NULL,
  assigned_to TEXT,
  due_date TEXT,
  completed_at TEXT,
  approved_by TEXT,
  approved_at TEXT,
  notes TEXT,
  attachments TEXT, -- JSON array of file paths
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (plant_id) REFERENCES plants(id),
  FOREIGN KEY (officer_id) REFERENCES officers(id),
  FOREIGN KEY (requested_by) REFERENCES users(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Test Assignments linked to memos
CREATE TABLE IF NOT EXISTS test_assignments (
  id TEXT PRIMARY KEY,
  memo_id TEXT NOT NULL,
  product_type_id TEXT NOT NULL,
  test_type_id TEXT NOT NULL,
  quantity INTEGER DEFAULT 1,
  scheduled_date TEXT,
  assigned_to TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  instructions TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (memo_id) REFERENCES memos(id) ON DELETE CASCADE,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (test_type_id) REFERENCES test_types(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id)
);

-- Unified Test Results (THE CORE TABLE)
CREATE TABLE IF NOT EXISTS test_entries (
  id TEXT PRIMARY KEY,
  assignment_id TEXT,
  memo_id TEXT,
  plant_id TEXT NOT NULL,
  product_type_id TEXT NOT NULL,
  test_type_id TEXT,
  officer_id TEXT NOT NULL,
  machine_id TEXT,
  test_date TEXT NOT NULL,
  production_date TEXT,
  batch_number TEXT,
  sample_id TEXT,
  age_days INTEGER,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'completed', 'approved', 'rejected')),
  grading_conformity TEXT CHECK (grading_conformity IN ('pass', 'fail', 'pending')),
  cleanliness_conformity TEXT CHECK (cleanliness_conformity IN ('pass', 'fail', 'pending')),
  overall_conformity TEXT CHECK (overall_conformity IN ('pass', 'fail', 'pending')),
  test_data TEXT DEFAULT '{}', -- JSON test results
  calculations TEXT DEFAULT '{}', -- JSON calculated values
  comments TEXT,
  reviewed_by TEXT,
  reviewed_at TEXT,
  approved_by TEXT,
  approved_at TEXT,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (assignment_id) REFERENCES test_assignments(id),
  FOREIGN KEY (memo_id) REFERENCES memos(id),
  FOREIGN KEY (plant_id) REFERENCES plants(id),
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (test_type_id) REFERENCES test_types(id),
  FOREIGN KEY (officer_id) REFERENCES officers(id),
  FOREIGN KEY (machine_id) REFERENCES machines(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (updated_by) REFERENCES users(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- ============================================================================
-- MIX DESIGN MANAGEMENT
-- ============================================================================

CREATE TABLE IF NOT EXISTS mix_designs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT UNIQUE NOT NULL,
  product_type_id TEXT NOT NULL,
  target_strength REAL,
  target_slump REAL,
  cement_type TEXT,
  aggregate_type TEXT,
  design_data TEXT DEFAULT '{}', -- JSON mix proportions
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived', 'superseded')),
  version_number INTEGER DEFAULT 1,
  parent_design_id TEXT,
  is_template BOOLEAN DEFAULT 0,
  template_name TEXT,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (parent_design_id) REFERENCES mix_designs(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (updated_by) REFERENCES users(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS mix_design_trials (
  id TEXT PRIMARY KEY,
  mix_design_id TEXT NOT NULL,
  test_entry_id TEXT NOT NULL,
  trial_batch TEXT,
  performance_rating TEXT,
  compliance_status TEXT CHECK (compliance_status IN ('compliant', 'non_compliant', 'marginal')),
  adjustments_needed TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (mix_design_id) REFERENCES mix_designs(id) ON DELETE CASCADE,
  FOREIGN KEY (test_entry_id) REFERENCES test_entries(id)
);

-- ============================================================================
-- REPORTING AND ANALYTICS
-- ============================================================================

CREATE TABLE IF NOT EXISTS report_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  description TEXT,
  template_data TEXT DEFAULT '{}', -- JSON template definition
  parameters TEXT DEFAULT '{}', -- JSON parameter definitions
  is_default BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS user_charts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  chart_type TEXT NOT NULL,
  data_source TEXT,
  filters TEXT DEFAULT '{}', -- JSON filter definitions
  chart_config TEXT DEFAULT '{}', -- JSON chart configuration
  is_shared BOOLEAN DEFAULT 0,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- ============================================================================
-- NOTIFICATIONS AND COMMUNICATIONS
-- ============================================================================

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  related_entity_type TEXT,
  related_entity_id TEXT,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  is_read BOOLEAN DEFAULT 0,
  read_at TEXT,
  actions TEXT DEFAULT '[]', -- JSON array of available actions
  created_at TEXT DEFAULT (datetime('now')),
  expires_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS email_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  template_type TEXT NOT NULL,
  variables TEXT DEFAULT '[]', -- JSON array of template variables
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now')),
  version INTEGER DEFAULT 1,
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS email_logs (
  id TEXT PRIMARY KEY,
  template_id TEXT,
  recipient TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'bounced')),
  sent_at TEXT,
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  created_by TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (template_id) REFERENCES email_templates(id),
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- ============================================================================
-- AUDIT AND VERSION CONTROL
-- ============================================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  old_values TEXT, -- JSON old values
  new_values TEXT, -- JSON new values
  ip_address TEXT,
  user_agent TEXT,
  session_id TEXT,
  timestamp TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sync_operations (
  id TEXT PRIMARY KEY,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
  data TEXT, -- JSON data payload
  device_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  local_timestamp TEXT NOT NULL,
  server_timestamp TEXT,
  sync_status TEXT DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'conflict', 'failed')),
  conflict_data TEXT, -- JSON conflict resolution data
  retry_count INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- User and Role indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON user_roles(role_id);

-- Reference data indexes
CREATE INDEX IF NOT EXISTS idx_plants_code ON plants(code);
CREATE INDEX IF NOT EXISTS idx_plants_active ON plants(is_active);
CREATE INDEX IF NOT EXISTS idx_officers_plant ON officers(plant_id);
CREATE INDEX IF NOT EXISTS idx_product_types_category ON product_types(category_id);
CREATE INDEX IF NOT EXISTS idx_product_types_active ON product_types(is_active);

-- Operational data indexes
CREATE INDEX IF NOT EXISTS idx_memos_plant ON memos(plant_id);
CREATE INDEX IF NOT EXISTS idx_memos_status ON memos(status);
CREATE INDEX IF NOT EXISTS idx_memos_reference ON memos(reference);
CREATE INDEX IF NOT EXISTS idx_test_assignments_memo ON test_assignments(memo_id);
CREATE INDEX IF NOT EXISTS idx_test_assignments_status ON test_assignments(status);
CREATE INDEX IF NOT EXISTS idx_test_entries_plant ON test_entries(plant_id);
CREATE INDEX IF NOT EXISTS idx_test_entries_product_type ON test_entries(product_type_id);
CREATE INDEX IF NOT EXISTS idx_test_entries_date ON test_entries(test_date);
CREATE INDEX IF NOT EXISTS idx_test_entries_status ON test_entries(status);
CREATE INDEX IF NOT EXISTS idx_test_entries_memo ON test_entries(memo_id);

-- Audit and sync indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_sync_operations_status ON sync_operations(sync_status);
CREATE INDEX IF NOT EXISTS idx_sync_operations_table ON sync_operations(table_name);

-- ============================================================================
-- TRIGGERS FOR AUTOMATIC UPDATES
-- ============================================================================

-- Update timestamp triggers
CREATE TRIGGER IF NOT EXISTS update_users_timestamp 
  AFTER UPDATE ON users 
  FOR EACH ROW 
  BEGIN 
    UPDATE users SET updated_at = datetime('now'), version = version + 1 WHERE id = NEW.id; 
  END;

CREATE TRIGGER IF NOT EXISTS update_memos_timestamp 
  AFTER UPDATE ON memos 
  FOR EACH ROW 
  BEGIN 
    UPDATE memos SET updated_at = datetime('now'), version = version + 1 WHERE id = NEW.id; 
  END;

CREATE TRIGGER IF NOT EXISTS update_test_entries_timestamp 
  AFTER UPDATE ON test_entries 
  FOR EACH ROW 
  BEGIN 
    UPDATE test_entries SET updated_at = datetime('now'), version = version + 1 WHERE id = NEW.id; 
  END;
`;

// Default permissions for RBAC system
export const DEFAULT_PERMISSIONS = [
  // User management
  { name: 'users.view', resource: 'users', action: 'view', description: 'View user profiles' },
  { name: 'users.create', resource: 'users', action: 'create', description: 'Create new users' },
  { name: 'users.edit', resource: 'users', action: 'edit', description: 'Edit user profiles' },
  { name: 'users.delete', resource: 'users', action: 'delete', description: 'Delete users' },
  
  // Test management
  { name: 'tests.view', resource: 'tests', action: 'view', description: 'View test results' },
  { name: 'tests.create', resource: 'tests', action: 'create', description: 'Create test entries' },
  { name: 'tests.edit', resource: 'tests', action: 'edit', description: 'Edit test results' },
  { name: 'tests.approve', resource: 'tests', action: 'approve', description: 'Approve test results' },
  { name: 'tests.delete', resource: 'tests', action: 'delete', description: 'Delete test entries' },
  
  // Memo management
  { name: 'memos.view', resource: 'memos', action: 'view', description: 'View memos' },
  { name: 'memos.create', resource: 'memos', action: 'create', description: 'Create memos' },
  { name: 'memos.edit', resource: 'memos', action: 'edit', description: 'Edit memos' },
  { name: 'memos.approve', resource: 'memos', action: 'approve', description: 'Approve memos' },
  
  // Reference data
  { name: 'reference.view', resource: 'reference', action: 'view', description: 'View reference data' },
  { name: 'reference.edit', resource: 'reference', action: 'edit', description: 'Edit reference data' },
  
  // Reports
  { name: 'reports.view', resource: 'reports', action: 'view', description: 'View reports' },
  { name: 'reports.create', resource: 'reports', action: 'create', description: 'Create reports' },
  { name: 'reports.export', resource: 'reports', action: 'export', description: 'Export reports' },
  
  // Analytics
  { name: 'analytics.view', resource: 'analytics', action: 'view', description: 'View analytics' },
  { name: 'analytics.advanced', resource: 'analytics', action: 'advanced', description: 'Access advanced analytics' },
  
  // System administration
  { name: 'system.settings', resource: 'system', action: 'settings', description: 'Manage system settings' },
  { name: 'system.audit', resource: 'system', action: 'audit', description: 'View audit logs' },
  { name: 'system.developer', resource: 'system', action: 'developer', description: 'Developer mode access' }
];

// Default roles
export const DEFAULT_ROLES = [
  {
    name: 'lab_admin',
    description: 'Laboratory Administrator - Full system access',
    permissions: DEFAULT_PERMISSIONS.map(p => p.name)
  },
  {
    name: 'lab_manager',
    description: 'Laboratory Manager - Management access without developer tools',
    permissions: DEFAULT_PERMISSIONS.filter(p => !p.name.includes('system.developer')).map(p => p.name)
  },
  {
    name: 'lab_technician',
    description: 'Laboratory Technician - Test and memo operations',
    permissions: [
      'tests.view', 'tests.create', 'tests.edit',
      'memos.view', 'memos.create',
      'reference.view',
      'reports.view'
    ]
  },
  {
    name: 'plant_officer',
    description: 'Plant Officer - Limited to memo creation and status tracking',
    permissions: [
      'memos.view', 'memos.create',
      'tests.view',
      'reports.view'
    ]
  }
];