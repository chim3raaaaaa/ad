// API client for backend calculations and business logic
const API_BASE_URL = 'http://localhost:5000/api';

// Mock token for development - replace with real authentication
const getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': 'Bearer mock-token'
});

export class ApiClient {
  
  static async calculateProgress(completed: number, total: number): Promise<number> {
    try {
      const response = await fetch(`${API_BASE_URL}/calculations/progress`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ completed, total })
      });
      
      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }
      
      const data = await response.json();
      return data.progress;
    } catch (error) {
      console.warn('API calculation failed, using fallback:', error);
      // Fallback calculation
      if (total === 0) return 0;
      return Math.round((completed / total) * 100);
    }
  }

  static async checkOverdue(dueDate: string): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/calculations/overdue`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ due_date: dueDate })
      });
      
      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }
      
      const data = await response.json();
      return data.is_overdue;
    } catch (error) {
      console.warn('API overdue check failed, using fallback:', error);
      // Fallback calculation
      return new Date(dueDate) < new Date();
    }
  }

  static async approveMemo(memoId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/workflow/approve-memo`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ memo_id: memoId })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { success: false, error: data.error || 'Approval failed' };
      }
      
      return { success: true };
    } catch (error) {
      console.warn('API approval failed:', error);
      return { success: false, error: 'Network error during approval' };
    }
  }
}