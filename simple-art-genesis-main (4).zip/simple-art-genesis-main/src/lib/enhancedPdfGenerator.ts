import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface ConformityResult {
  sieve: string;
  actualValue: number;
  limitValue: number;
  status: 'pass' | 'fail' | 'warning';
  deviation: number;
}

interface ConformityReport {
  overall_status: 'pass' | 'fail' | 'warning';
  conformity_percentage: number;
  material_type: string;
  standard: string;
  results: ConformityResult[];
  checked_at: string;
}

interface TestResult {
  memo_ref: string;
  product_type: string;
  test_data: any;
  conformity_report?: ConformityReport;
  grading_conformity?: ConformityReport;
}

export class EnhancedReportGenerator {
  static async generateTestReportWithConformity(testResult: TestResult): Promise<void> {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.width;
    let yPosition = 20;

    // Header
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Laboratory Test Report', pageWidth / 2, yPosition, { align: 'center' });
    
    yPosition += 15;
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Report Date: ${new Date().toLocaleDateString()}`, pageWidth / 2, yPosition, { align: 'center' });
    
    yPosition += 20;

    // Test Information
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Test Information', 20, yPosition);
    yPosition += 10;

    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    const testInfo = [
      ['Memo Reference:', testResult.memo_ref],
      ['Product Type:', testResult.product_type],
      ['Test Date:', testResult.test_data.test_date || 'N/A'],
      ['Tested By:', testResult.test_data.tested_by || 'N/A'],
      ['Plant:', testResult.test_data.plant || 'N/A']
    ];

    pdf.autoTable({
      startY: yPosition,
      head: [],
      body: testInfo,
      theme: 'plain',
      styles: { fontSize: 10, cellPadding: 2 },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 40 },
        1: { cellWidth: 100 }
      }
    });

    yPosition = (pdf as any).lastAutoTable.finalY + 15;

    // Test Results
    if (testResult.test_data) {
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Test Results', 20, yPosition);
      yPosition += 10;

      const testData = Object.entries(testResult.test_data)
        .filter(([key, value]) => key !== 'memo_ref' && key !== 'id' && value !== null && value !== undefined)
        .map(([key, value]) => [
          key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          String(value)
        ]);

      pdf.autoTable({
        startY: yPosition,
        head: [['Parameter', 'Value']],
        body: testData,
        theme: 'striped',
        headStyles: { fillColor: [41, 128, 185] },
        styles: { fontSize: 9 }
      });

      yPosition = (pdf as any).lastAutoTable.finalY + 15;
    }

    // Grading Conformity Results
    if (testResult.grading_conformity) {
      const conformity = testResult.grading_conformity;
      
      // Check if we need a new page
      if (yPosition > 250) {
        pdf.addPage();
        yPosition = 20;
      }

      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Grading Conformity Analysis', 20, yPosition);
      yPosition += 10;

    // Overall Status
    pdf.setFontSize(12);
    const statusColor = conformity.overall_status === 'pass' ? [0, 128, 0] as const : 
                       conformity.overall_status === 'fail' ? [255, 0, 0] as const : [255, 165, 0] as const;
    pdf.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
      pdf.setFont('helvetica', 'bold');
      pdf.text(`Overall Status: ${conformity.overall_status.toUpperCase()}`, 20, yPosition);
      
      pdf.setTextColor(0, 0, 0);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Conformity: ${conformity.conformity_percentage}%`, 120, yPosition);
      yPosition += 8;

      pdf.setFontSize(10);
      pdf.text(`Material Type: ${conformity.material_type}`, 20, yPosition);
      pdf.text(`Standard: ${conformity.standard}`, 120, yPosition);
      yPosition += 15;

      // Detailed Results Table
      const conformityTableData = conformity.results.map(result => [
        result.sieve,
        `${result.actualValue}%`,
        `${result.limitValue}%`,
        `${result.deviation > 0 ? '+' : ''}${result.deviation.toFixed(2)}%`,
        result.status.toUpperCase()
      ]);

      pdf.autoTable({
        startY: yPosition,
        head: [['Sieve Size', 'Actual (%)', 'Limit (%)', 'Deviation', 'Status']],
        body: conformityTableData,
        theme: 'striped',
        headStyles: { fillColor: [41, 128, 185] },
        styles: { fontSize: 8 },
        didParseCell: function(data) {
          // Color code the status column
          if (data.column.index === 4) {
            const status = data.cell.text[0].toLowerCase();
            if (status === 'pass') {
              data.cell.styles.textColor = [0, 128, 0];
              data.cell.styles.fontStyle = 'bold';
            } else if (status === 'fail') {
              data.cell.styles.textColor = [255, 0, 0];
              data.cell.styles.fontStyle = 'bold';
            } else if (status === 'warning') {
              data.cell.styles.textColor = [255, 165, 0];
              data.cell.styles.fontStyle = 'bold';
            }
          }
        }
      });

      yPosition = (pdf as any).lastAutoTable.finalY + 15;

      // Non-conformity Summary
      const failedResults = conformity.results.filter(r => r.status === 'fail');
      const warningResults = conformity.results.filter(r => r.status === 'warning');

      if (failedResults.length > 0 || warningResults.length > 0) {
        pdf.setFontSize(12);
        pdf.setFont('helvetica', 'bold');
        pdf.text('Non-Conformity Summary', 20, yPosition);
        yPosition += 10;

        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'normal');

        if (failedResults.length > 0) {
          pdf.setTextColor(255, 0, 0);
          pdf.text(`Critical Failures (${failedResults.length}):`, 20, yPosition);
          yPosition += 6;
          pdf.setTextColor(0, 0, 0);
          
          failedResults.forEach(result => {
            pdf.text(`• ${result.sieve}: ${result.actualValue}% vs ${result.limitValue}% limit`, 25, yPosition);
            yPosition += 5;
          });
          yPosition += 5;
        }

        if (warningResults.length > 0) {
          pdf.setTextColor(255, 165, 0);
          pdf.text(`Warnings (${warningResults.length}):`, 20, yPosition);
          yPosition += 6;
          pdf.setTextColor(0, 0, 0);
          
          warningResults.forEach(result => {
            pdf.text(`• ${result.sieve}: ${result.actualValue}% vs ${result.limitValue}% limit`, 25, yPosition);
            yPosition += 5;
          });
        }
      }
    }

    // Footer
    const totalPages = pdf.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Page ${i} of ${totalPages}`, pageWidth - 30, pdf.internal.pageSize.height - 10);
      pdf.text('Generated by UBP LIMS', 20, pdf.internal.pageSize.height - 10);
    }

    // Save the PDF
    const fileName = `test_report_${testResult.memo_ref}_${new Date().toISOString().split('T')[0]}.pdf`;
    pdf.save(fileName);
  }

  static async generateConformityBatchReport(conformityResults: ConformityReport[]): Promise<void> {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.width;
    let yPosition = 20;

    // Header
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Batch Conformity Report', pageWidth / 2, yPosition, { align: 'center' });
    
    yPosition += 15;
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Generated: ${new Date().toLocaleDateString()}`, pageWidth / 2, yPosition, { align: 'center' });
    pdf.text(`Total Tests: ${conformityResults.length}`, pageWidth / 2, yPosition + 6, { align: 'center' });
    
    yPosition += 25;

    // Summary Statistics
    const passCount = conformityResults.filter(r => r.overall_status === 'pass').length;
    const failCount = conformityResults.filter(r => r.overall_status === 'fail').length;
    const warningCount = conformityResults.filter(r => r.overall_status === 'warning').length;
    const avgConformity = conformityResults.reduce((sum, r) => sum + r.conformity_percentage, 0) / conformityResults.length;

    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Summary Statistics', 20, yPosition);
    yPosition += 10;

    const summaryData = [
      ['Passed Tests:', `${passCount} (${((passCount / conformityResults.length) * 100).toFixed(1)}%)`],
      ['Failed Tests:', `${failCount} (${((failCount / conformityResults.length) * 100).toFixed(1)}%)`],
      ['Warning Tests:', `${warningCount} (${((warningCount / conformityResults.length) * 100).toFixed(1)}%)`],
      ['Average Conformity:', `${avgConformity.toFixed(1)}%`]
    ];

    pdf.autoTable({
      startY: yPosition,
      head: [],
      body: summaryData,
      theme: 'plain',
      styles: { fontSize: 10, cellPadding: 3 },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 50 },
        1: { cellWidth: 80 }
      }
    });

    yPosition = (pdf as any).lastAutoTable.finalY + 15;

    // Detailed Results
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Detailed Results', 20, yPosition);
    yPosition += 10;

    const detailedData = conformityResults.map(result => [
      result.material_type,
      result.standard,
      `${result.conformity_percentage}%`,
      result.overall_status.toUpperCase(),
      new Date(result.checked_at).toLocaleDateString()
    ]);

    pdf.autoTable({
      startY: yPosition,
      head: [['Material Type', 'Standard', 'Conformity', 'Status', 'Date']],
      body: detailedData,
      theme: 'striped',
      headStyles: { fillColor: [41, 128, 185] },
      styles: { fontSize: 9 },
      didParseCell: function(data) {
        // Color code the status column
        if (data.column.index === 3) {
          const status = data.cell.text[0].toLowerCase();
          if (status === 'pass') {
            data.cell.styles.textColor = [0, 128, 0];
            data.cell.styles.fontStyle = 'bold';
          } else if (status === 'fail') {
            data.cell.styles.textColor = [255, 0, 0];
            data.cell.styles.fontStyle = 'bold';
          } else if (status === 'warning') {
            data.cell.styles.textColor = [255, 165, 0];
            data.cell.styles.fontStyle = 'bold';
          }
        }
      }
    });

    // Save the PDF
    const fileName = `batch_conformity_report_${new Date().toISOString().split('T')[0]}.pdf`;
    pdf.save(fileName);
  }
}