import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import JSZip from 'jszip';

interface ReportData {
  title: string;
  memoId: string;
  reference: string;
  site: string;
  testDate: string;
  technician: string;
  testType: string;
  productions?: Array<{
    productionDate: string;
    testDate: string;
    productionNo: string;
    age: number;
    product: string;
    grade: number;
    machineNo: string;
    mouldRef: string;
    production: string;
    samplesForTest: number;
    blockPosNo: string;
  }>;
  extractedData?: any;
  templateData?: any;
  analyticsCharts?: any[];
  watermark?: string;
  password?: string;
  signature?: string;
}

export class PDFGenerator {
  static async generateTestReport(reportData: ReportData): Promise<Blob> {
    const pdf = new jsPDF();
    let yPosition = 20;

    // Add watermark if specified
    if (reportData.watermark) {
      this.addWatermark(pdf, reportData.watermark);
    }

    // Header
    pdf.setFontSize(18);
    pdf.setFont("helvetica", "bold");
    pdf.text(reportData.title || "Laboratory Test Report", 20, yPosition);
    yPosition += 20;

    // Lab Information
    pdf.setFontSize(12);
    pdf.setFont("helvetica", "normal");
    pdf.text("UBP Mauritius Laboratory", 20, yPosition);
    yPosition += 8;
    pdf.text("Port Louis, Mauritius", 20, yPosition);
    yPosition += 8;
    pdf.text("Tel: +230 123 4567", 20, yPosition);
    yPosition += 20;

    // Report Details
    pdf.setFont("helvetica", "bold");
    pdf.text("Report Details:", 20, yPosition);
    yPosition += 10;

    pdf.setFont("helvetica", "normal");
    const reportDetails = [
      [`Report Title:`, reportData.title],
      [`Memo Reference:`, reportData.reference],
      [`Site:`, reportData.site],
      [`Test Date:`, reportData.testDate],
      [`Technician:`, reportData.technician],
      [`Test Type:`, reportData.testType],
      [`Generated:`, new Date().toLocaleDateString()]
    ];

    reportDetails.forEach(([label, value]) => {
      pdf.text(`${label} ${value}`, 20, yPosition);
      yPosition += 8;
    });

    yPosition += 10;

    // Production Data Table
    if (reportData.productions && reportData.productions.length > 0) {
      pdf.setFont("helvetica", "bold");
      pdf.text("Production Test Results:", 20, yPosition);
      yPosition += 15;

      // Table headers
      const headers = ["Production No", "Age (days)", "Product", "Grade (MPa)", "Samples"];
      const columnWidths = [35, 25, 40, 25, 25];
      let xPosition = 20;

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      headers.forEach((header, index) => {
        pdf.text(header, xPosition, yPosition);
        xPosition += columnWidths[index];
      });
      yPosition += 8;

      // Table rows
      pdf.setFont("helvetica", "normal");
      reportData.productions.forEach((production) => {
        if (yPosition > 250) {
          pdf.addPage();
          yPosition = 20;
        }

        xPosition = 20;
        const rowData = [
          production.productionNo,
          production.age.toString(),
          production.product,
          production.grade.toString(),
          production.samplesForTest.toString()
        ];

        rowData.forEach((data, index) => {
          pdf.text(data, xPosition, yPosition);
          xPosition += columnWidths[index];
        });
        yPosition += 8;
      });
    }

    // Summary and Notes
    yPosition += 20;
    if (yPosition > 250) {
      pdf.addPage();
      yPosition = 20;
    }

    pdf.setFont("helvetica", "bold");
    pdf.text("Test Summary:", 20, yPosition);
    yPosition += 10;

    pdf.setFont("helvetica", "normal");
    const totalSamples = reportData.productions?.reduce((sum, p) => sum + p.samplesForTest, 0) || 0;
    const avgGrade = reportData.productions?.length 
      ? (reportData.productions.reduce((sum, p) => sum + p.grade, 0) / reportData.productions.length).toFixed(2)
      : 'N/A';

    pdf.text(`Total Samples Tested: ${totalSamples}`, 20, yPosition);
    yPosition += 8;
    pdf.text(`Average Grade: ${avgGrade} MPa`, 20, yPosition);
    yPosition += 8;
    pdf.text(`Test Status: Completed`, 20, yPosition);
    yPosition += 20;

    // Add signature if specified
    if (reportData.signature) {
      yPosition += 10;
      pdf.setFont("helvetica", "bold");
      pdf.text("Digital Signature:", 20, yPosition);
      yPosition += 8;
      pdf.setFont("helvetica", "normal");
      pdf.text(reportData.signature, 20, yPosition);
    }

    // Footer
    pdf.setFontSize(8);
    pdf.text("This report was generated automatically by the Lab Management System", 20, 280);
    pdf.text(`Generated on: ${new Date().toLocaleString()}`, 20, 288);

    const blob = pdf.output('blob');
    
    // Add password protection if specified
    if (reportData.password) {
      // Note: jsPDF doesn't support password protection directly
      // This would require a different library or server-side processing
      console.log('Password protection requested but not supported in browser');
    }

    return blob;
  }

  static async generateDashboardReport(dashboardData: any): Promise<Blob> {
    const pdf = new jsPDF();
    let yPosition = 20;

    // Header
    pdf.setFontSize(18);
    pdf.setFont("helvetica", "bold");
    pdf.text("Dashboard Analytics Report", 20, yPosition);
    yPosition += 20;

    // Summary Statistics
    pdf.setFontSize(14);
    pdf.text("Laboratory Performance Summary", 20, yPosition);
    yPosition += 15;

    pdf.setFontSize(12);
    pdf.setFont("helvetica", "normal");
    const summaryData = [
      [`Active Memos:`, dashboardData.activeMemos?.toString() || '0'],
      [`Pending Tests:`, dashboardData.pendingTests?.toString() || '0'],
      [`Tests in Progress:`, dashboardData.testsInProgress?.toString() || '0'],
      [`Completed Today:`, dashboardData.completedToday?.toString() || '0'],
      [`Report Generated:`, new Date().toLocaleDateString()]
    ];

    summaryData.forEach(([label, value]) => {
      pdf.text(`${label} ${value}`, 20, yPosition);
      yPosition += 8;
    });

    yPosition += 20;

    // Monthly Trends
    if (dashboardData.monthlyTrendsData && dashboardData.monthlyTrendsData.length > 0) {
      pdf.setFont("helvetica", "bold");
      pdf.text("Monthly Performance Trends:", 20, yPosition);
      yPosition += 15;

      const headers = ["Month", "Total Tests", "Completion Rate"];
      const columnWidths = [40, 30, 40];
      let xPosition = 20;

      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      headers.forEach((header, index) => {
        pdf.text(header, xPosition, yPosition);
        xPosition += columnWidths[index];
      });
      yPosition += 8;

      pdf.setFont("helvetica", "normal");
      dashboardData.monthlyTrendsData.forEach((month: any) => {
        xPosition = 20;
        const rowData = [
          month.month,
          month.tests?.toString() || '0',
          `${month.compliance || 0}%`
        ];

        rowData.forEach((data, index) => {
          pdf.text(data, xPosition, yPosition);
          xPosition += columnWidths[index];
        });
        yPosition += 8;
      });
    }

    // Footer
    yPosition = 280;
    pdf.setFontSize(8);
    pdf.text("This dashboard report was generated automatically", 20, yPosition);
    pdf.text(`Generated on: ${new Date().toLocaleString()}`, 20, yPosition + 8);

    return pdf.output('blob');
  }

  static async captureElementAsPDF(elementId: string, filename: string): Promise<void> {
    const element = document.getElementById(elementId);
    if (!element) {
      throw new Error(`Element with ID ${elementId} not found`);
    }

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF();
    const imgWidth = 210;
    const pageHeight = 295;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(filename);
  }

  static downloadBlob(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // Generate batch reports and create ZIP file
  static async generateBatchReports(reports: ReportData[]): Promise<Blob> {
    const zip = new JSZip();
    
    for (let i = 0; i < reports.length; i++) {
      const report = reports[i];
      const pdfBlob = await this.generateTestReport(report);
      const filename = `${report.reference || `Report_${i + 1}`}.pdf`;
      zip.file(filename, pdfBlob);
    }
    
    return await zip.generateAsync({ type: 'blob' });
  }

  // Generate report from template (DEPRECATED - Use TemplateToPdfService instead)
  static async generateFromTemplate(templateData: any, reportData: ReportData): Promise<Blob> {
    console.warn('PDFGenerator.generateFromTemplate is deprecated. Use TemplateToPdfService instead.');
    
    const pdf = new jsPDF();
    let yPosition = 20;

    // Add watermark
    if (reportData.watermark) {
      this.addWatermark(pdf, reportData.watermark);
    }

    // Basic template processing for backward compatibility
    if (templateData?.blocks) {
      for (const block of templateData.blocks) {
        switch (block.type) {
          case 'text':
          case 'static':
            pdf.setFontSize(parseInt(block.styles?.fontSize) || 12);
            pdf.text(block.content || '', block.x * 0.264583, block.y * 0.264583);
            break;
          case 'field':
            const fieldValue = this.getFieldValue(block.fieldName, reportData);
            pdf.text(fieldValue, block.x * 0.264583, block.y * 0.264583);
            break;
          case 'chart':
            // Basic placeholder for chart
            pdf.rect(
              block.x * 0.264583, 
              block.y * 0.264583, 
              block.width * 0.264583, 
              block.height * 0.264583
            );
            pdf.text(`[${block.chartType || 'Chart'}]`, 
              block.x * 0.264583 + 5, 
              block.y * 0.264583 + 10
            );
            break;
          case 'attachment':
          case 'image':
            // Basic placeholder for attachments
            pdf.rect(
              block.x * 0.264583, 
              block.y * 0.264583, 
              block.width * 0.264583, 
              block.height * 0.264583
            );
            pdf.text('[Attachment]', 
              block.x * 0.264583 + 5, 
              block.y * 0.264583 + 10
            );
            break;
        }
      }
    }

    return pdf.output('blob');
  }

  // Add watermark to PDF
  private static addWatermark(pdf: jsPDF, text: string): void {
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    pdf.saveGraphicsState();
    // Set transparency for watermark
    pdf.setTextColor(128, 128, 128);
    pdf.setFontSize(60);
    pdf.text(text, pageWidth / 2, pageHeight / 2, {
      angle: 45,
      align: 'center'
    });
    pdf.restoreGraphicsState();
  }

  // Get field value from report data
  private static getFieldValue(fieldName: string, reportData: ReportData): string {
    const fieldMap: { [key: string]: string } = {
      memo_ref: reportData.reference,
      officer: reportData.technician,
      plant: reportData.site,
      sampling_date: reportData.testDate,
      test_type: reportData.testType,
      // Add more field mappings as needed
    };
    
    return fieldMap[fieldName] || `[${fieldName}]`;
  }

  // Encrypt PDF (placeholder - would need server-side implementation)
  static async encryptPDF(pdfBlob: Blob, password: string): Promise<Blob> {
    // This would typically be done server-side with libraries like PDF-lib
    console.log('PDF encryption requested but requires server-side implementation');
    return pdfBlob;
  }
}