import Tesseract from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export interface ProductionRecord {
  productionNumber: string;
  productionDate?: string;
  testDate?: string;
  age?: string;
  product?: string;
  grade?: string;
  machineNo?: string;
  mouldRef?: string;
  blockPositions?: string[];
  numberOfSamples?: string;
  blockPositionNumbers?: string[];
  remarks?: string;
  officer?: string;
  site?: string;
  typeOfTest?: string;
  [key: string]: any; // For additional dynamic fields
}

export interface MemoData {
  globalFields: {
    referenceNo?: string;
    date?: string;
    officer?: string;
    lorry?: string;
    remarks?: string;
    [key: string]: any;
  };
  productions: ProductionRecord[];
  missingFields: string[];
  extractionMethod: 'direct-parse' | 'ocr' | 'hybrid';
}

export class ProductionPdfExtractor {
  private static readonly PRODUCTION_PATTERN = /production\s+(\d+)/gi;
  private static readonly FIELD_PATTERNS = {
    productionDate: /production\s+date[:\s]*([^\n\r]+)/gi,
    testDate: /test\s+date[:\s]*([^\n\r]+)/gi,
    age: /age[:\s]*(\d+\s*days?)/gi,
    product: /product[:\s]*([^\n\r]+)/gi,
    grade: /grade[:\s]*([^\n\r]+(?:mpa)?)/gi,
    machineNo: /machine\s+no[:\s]*([^\n\r]+)/gi,
    mouldRef: /mould\s+ref[:\s]*([^\n\r]+)/gi,
    numberOfSamples: /no\.?\s+of\s+samples[:\s]*(\d+)/gi,
    blockPositions: /block\s+position[s]?[:\s]*([^\n\r]+)/gi,
    officer: /officer[:\s]*([^\n\r]+)/gi,
    referenceNo: /reference\s+no[:\s]*([^\n\r]+)/gi,
    date: /date[:\s]*([^\n\r]+)/gi,
    lorry: /lorry[:\s]*([^\n\r]+)/gi,
    remarks: /remarks[:\s]*([^\n\r]+)/gi,
    site: /site[:\s]*([^\n\r]+)/gi,
    typeOfTest: /type\s+of\s+test[:\s]*([^\n\r]+)/gi
  };

  /**
   * Main extraction method - tries PDF parsing first, then OCR
   */
  static async extractProductionData(file: File): Promise<MemoData> {
    try {
      console.log('Starting PDF extraction...');
      
      // First try direct PDF text extraction
      try {
        const pdfResult = await this.tryPdfParsing(file);
        if (pdfResult.globalFields && Object.keys(pdfResult.globalFields).length > 0 || 
            pdfResult.productions.length > 0) {
          return { ...pdfResult, extractionMethod: 'direct-parse' };
        }
      } catch (error) {
        console.warn('PDF parsing failed, trying OCR:', error);
      }

      // Fall back to OCR if PDF parsing fails
      const ocrResult = await this.tryOCRExtraction(file);
      return { ...ocrResult, extractionMethod: 'ocr' };
      
    } catch (error) {
      console.error('All extraction methods failed:', error);
      // Return a basic structure with error info
      return {
        globalFields: { error: 'Extraction failed' },
        productions: [],
        missingFields: ['Extraction failed - please check PDF format'],
        extractionMethod: 'direct-parse'
      };
    }
  }

  /**
   * Try direct PDF text extraction using PDF.js
   */
  private static async tryPdfParsing(file: File): Promise<MemoData> {
    try {
      console.log('Attempting PDF text extraction with PDF.js...');
      
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      let fullText = '';
      
      // Extract text from all pages
      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        
        fullText += pageText + '\n';
      }
      
      if (!fullText || fullText.trim().length === 0) {
        throw new Error('No text found in PDF');
      }

      console.log('PDF text extracted successfully, parsing content...');
      console.log('Extracted text preview:', fullText.substring(0, 500));
      
      return this.parseTextContent(fullText);
    } catch (error) {
      console.error('PDF parsing failed:', error);
      throw error;
    }
  }

  /**
   * Try OCR extraction - skip for now since it requires image conversion
   */
  private static async tryOCRExtraction(file: File): Promise<MemoData> {
    console.log('OCR extraction not supported for PDFs - returning empty result');
    return {
      globalFields: { 
        error: 'OCR extraction requires image conversion (not implemented)',
        filename: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`
      },
      productions: [],
      missingFields: ['OCR not available for PDF files'],
      extractionMethod: 'ocr'
    };
  }

  /**
   * Parse extracted text content to identify productions and fields
   */
  private static parseTextContent(text: string): MemoData {
    const cleanText = this.cleanText(text);
    const productions = this.extractProductions(cleanText);
    const globalFields = this.extractGlobalFields(cleanText, productions);
    const missingFields = this.identifyMissingFields(productions, globalFields);

    return {
      globalFields,
      productions,
      missingFields,
      extractionMethod: 'direct-parse'
    };
  }

  /**
   * Clean and normalize text
   */
  private static cleanText(text: string): string {
    return text
      .replace(/\s+/g, ' ') // Normalize whitespace
      .replace(/[^\x20-\x7E\n\r]/g, '') // Remove non-printable characters
      .trim();
  }

  /**
   * Extract all production sections
   */
  private static extractProductions(text: string): ProductionRecord[] {
    const productions: ProductionRecord[] = [];
    const productionMatches = Array.from(text.matchAll(this.PRODUCTION_PATTERN));

    for (let i = 0; i < productionMatches.length; i++) {
      const match = productionMatches[i];
      const productionNumber = match[1];
      const startIndex = match.index!;
      const endIndex = i < productionMatches.length - 1 
        ? productionMatches[i + 1].index! 
        : text.length;

      const productionText = text.substring(startIndex, endIndex);
      const productionData = this.extractProductionFields(productionText, productionNumber);
      
      productions.push(productionData);
    }

    return productions;
  }

  /**
   * Extract fields for a specific production section
   */
  private static extractProductionFields(text: string, productionNumber: string): ProductionRecord {
    const production: ProductionRecord = {
      productionNumber
    };

    // Extract each field using patterns
    for (const [fieldName, pattern] of Object.entries(this.FIELD_PATTERNS)) {
      const matches = Array.from(text.matchAll(pattern));
      if (matches.length > 0) {
        const value = matches[0][1].trim();
        if (value) {
          // Special handling for arrays
          if (fieldName === 'blockPositions' || fieldName === 'blockPositionNumbers') {
            production[fieldName] = this.parseArrayField(value);
          } else {
            production[fieldName] = value;
          }
        }
      }
    }

    // Extract any additional fields that might be present
    this.extractAdditionalFields(text, production);

    return production;
  }

  /**
   * Extract global fields that are not within production sections
   */
  private static extractGlobalFields(text: string, productions: ProductionRecord[]): Record<string, any> {
    const globalFields: Record<string, any> = {};

    // Remove production sections from text to get global content
    let globalText = text;
    const productionMatches = Array.from(text.matchAll(this.PRODUCTION_PATTERN));
    
    for (let i = productionMatches.length - 1; i >= 0; i--) {
      const match = productionMatches[i];
      const startIndex = match.index!;
      const endIndex = i < productionMatches.length - 1 
        ? productionMatches[i + 1].index! 
        : text.length;
      
      globalText = globalText.substring(0, startIndex) + globalText.substring(endIndex);
    }

    // Extract global fields
    for (const [fieldName, pattern] of Object.entries(this.FIELD_PATTERNS)) {
      const matches = Array.from(globalText.matchAll(pattern));
      if (matches.length > 0) {
        const value = matches[0][1].trim();
        if (value) {
          globalFields[fieldName] = value;
        }
      }
    }

    return globalFields;
  }

  /**
   * Parse array fields like block positions
   */
  private static parseArrayField(value: string): string[] {
    return value
      .split(/[,;]/)
      .map(item => item.trim())
      .filter(item => item.length > 0);
  }

  /**
   * Extract additional fields that don't match standard patterns
   */
  private static extractAdditionalFields(text: string, production: ProductionRecord): void {
    // Look for any field:value patterns that we might have missed
    const additionalPattern = /([a-zA-Z\s]+):\s*([^\n\r:]+)/g;
    const matches = Array.from(text.matchAll(additionalPattern));

    for (const match of matches) {
      const fieldName = match[1].trim().toLowerCase().replace(/\s+/g, '');
      const value = match[2].trim();

      // Only add if not already captured and not empty
      if (value && !production[fieldName] && !this.isStandardField(fieldName)) {
        production[fieldName] = value;
      }
    }
  }

  /**
   * Check if field is already handled by standard patterns
   */
  private static isStandardField(fieldName: string): boolean {
    const standardFields = Object.keys(this.FIELD_PATTERNS).map(f => f.toLowerCase());
    return standardFields.includes(fieldName) || fieldName === 'productionnumber';
  }

  /**
   * Identify missing or incomplete fields
   */
  private static identifyMissingFields(productions: ProductionRecord[], globalFields: Record<string, any>): string[] {
    const missingFields: string[] = [];
    const requiredFields = ['productionDate', 'testDate', 'product', 'grade'];
    const requiredGlobalFields = ['referenceNo', 'date', 'officer'];

    // Check global fields
    for (const field of requiredGlobalFields) {
      if (!globalFields[field]) {
        missingFields.push(`Global: ${field}`);
      }
    }

    // Check each production
    productions.forEach((production, index) => {
      for (const field of requiredFields) {
        if (!production[field]) {
          missingFields.push(`Production ${production.productionNumber}: ${field}`);
        }
      }
    });

    return missingFields;
  }

  /**
   * Format extracted data for display or export
   */
  static formatForDisplay(memoData: MemoData): string {
    const lines: string[] = [];
    
    lines.push('=== EXTRACTED MEMO DATA ===\n');
    
    // Global fields
    lines.push('GLOBAL FIELDS:');
    for (const [key, value] of Object.entries(memoData.globalFields)) {
      lines.push(`  ${key}: ${value}`);
    }
    lines.push('');

    // Productions
    lines.push(`PRODUCTIONS (${memoData.productions.length} found):`);
    memoData.productions.forEach((production, index) => {
      lines.push(`\n--- Production ${production.productionNumber} ---`);
      for (const [key, value] of Object.entries(production)) {
        if (key !== 'productionNumber') {
          const displayValue = Array.isArray(value) ? value.join(', ') : value;
          lines.push(`  ${key}: ${displayValue}`);
        }
      }
    });

    // Missing fields
    if (memoData.missingFields.length > 0) {
      lines.push('\nMISSING/UNCLEAR FIELDS:');
      memoData.missingFields.forEach(field => {
        lines.push(`  ⚠️ ${field}`);
      });
    }

    lines.push(`\nExtraction method: ${memoData.extractionMethod}`);

    return lines.join('\n');
  }
}