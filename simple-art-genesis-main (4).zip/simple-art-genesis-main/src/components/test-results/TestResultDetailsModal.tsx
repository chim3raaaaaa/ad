import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AggregateTestEntry } from "@/services/database/aggregateTestService";
import { ConcreteTestResult } from "@/services/api/testResultsAPI";
import { TestResultsAPI } from "@/services/api/testResultsAPI";
import { useToast } from "@/hooks/use-toast";
import { Edit3, Save, X, FileText, Download } from "lucide-react";

interface TestResultDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  testResult: AggregateTestEntry | ConcreteTestResult | null;
  testType: 'aggregate' | 'concrete';
  onUpdate?: () => void;
}

export function TestResultDetailsModal({
  isOpen,
  onClose,
  testResult,
  testType,
  onUpdate
}: TestResultDetailsModalProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<any>({});
  const [isLoading, setIsLoading] = useState(false);

  const handleEdit = () => {
    setEditData({ ...testResult });
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setEditData({});
    setIsEditing(false);
  };

  const handleSave = async () => {
    if (!testResult?.id) return;

    setIsLoading(true);
    try {
      let result;
      if (testType === 'aggregate') {
        result = await TestResultsAPI.updateAggregateTest(testResult.id, editData);
      } else {
        result = await TestResultsAPI.updateConcreteTest(testResult.id, editData);
      }

      if (result.success) {
        toast({
          title: "Test Updated",
          description: "Test result has been updated successfully"
        });
        setIsEditing(false);
        onUpdate?.();
        onClose();
      } else {
        toast({
          title: "Update Failed",
          description: result.error || "Failed to update test result",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "An error occurred while updating the test result",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateReport = () => {
    // TODO: Implement report generation
    toast({
      title: "Report Generation",
      description: "Report generation feature coming soon",
    });
  };

  const handleExportPDF = () => {
    // TODO: Implement PDF export
    toast({
      title: "PDF Export",
      description: "PDF export feature coming soon",
    });
  };

  if (!testResult) return null;

  const isAggregate = testType === 'aggregate';
  const aggregateData = testResult as AggregateTestEntry;
  const concreteData = testResult as ConcreteTestResult;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {isAggregate ? 'Aggregate' : 'Concrete'} Test Details
              {isEditing && <Badge variant="outline">Editing</Badge>}
            </DialogTitle>
            <div className="flex items-center gap-2">
              {!isEditing ? (
                <>
                  <Button variant="outline" size="sm" onClick={handleEdit}>
                    <Edit3 className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleGenerateReport}>
                    <FileText className="h-4 w-4 mr-2" />
                    Report
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportPDF}>
                    <Download className="h-4 w-4 mr-2" />
                    Export PDF
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleCancelEdit}
                    disabled={isLoading}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={handleSave}
                    disabled={isLoading}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                </>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General Information</TabsTrigger>
            <TabsTrigger value="results">Test Results</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
          </TabsList>

          {/* General Information Tab */}
          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="memo_reference">Memo Reference</Label>
                  {isEditing ? (
                    <Input
                      id="memo_reference"
                      value={editData.memo_reference || ''}
                      onChange={(e) => setEditData({...editData, memo_reference: e.target.value})}
                    />
                  ) : (
                    <p className="mt-1 text-sm">{testResult.memo_reference || 'N/A'}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="test_date">Test Date</Label>
                  {isEditing ? (
                    <Input
                      id="test_date"
                      type="date"
                      value={editData.test_date || ''}
                      onChange={(e) => setEditData({...editData, test_date: e.target.value})}
                    />
                  ) : (
                    <p className="mt-1 text-sm">
                      {testResult.test_date ? new Date(testResult.test_date).toLocaleDateString() : 'N/A'}
                    </p>
                  )}
                </div>

                {isAggregate ? (
                  <>
                    <div>
                      <Label htmlFor="plant_id">Plant</Label>
                      {isEditing ? (
                        <Input
                          id="plant_id"
                          value={editData.plant_id || ''}
                          onChange={(e) => setEditData({...editData, plant_id: e.target.value})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.plant_id || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="officer_id">Officer</Label>
                      {isEditing ? (
                        <Input
                          id="officer_id"
                          value={editData.officer_id || ''}
                          onChange={(e) => setEditData({...editData, officer_id: e.target.value})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.officer_id || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="aggregate_type_id">Aggregate Type</Label>
                      {isEditing ? (
                        <Input
                          id="aggregate_type_id"
                          value={editData.aggregate_type_id || ''}
                          onChange={(e) => setEditData({...editData, aggregate_type_id: e.target.value})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.aggregate_type_id || 'N/A'}</p>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <Label htmlFor="operator_name">Operator</Label>
                      {isEditing ? (
                        <Input
                          id="operator_name"
                          value={editData.operator_name || ''}
                          onChange={(e) => setEditData({...editData, operator_name: e.target.value})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{concreteData.operator_name || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="machine_no">Machine No</Label>
                      {isEditing ? (
                        <Input
                          id="machine_no"
                          value={editData.machine_no || ''}
                          onChange={(e) => setEditData({...editData, machine_no: e.target.value})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{concreteData.machine_no || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="age_days">Age (Days)</Label>
                      {isEditing ? (
                        <Input
                          id="age_days"
                          type="number"
                          value={editData.age_days || ''}
                          onChange={(e) => setEditData({...editData, age_days: parseInt(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{concreteData.age_days || 'N/A'}</p>
                      )}
                    </div>
                  </>
                )}

                <div className="col-span-2">
                  <Label htmlFor="remarks">Remarks</Label>
                  {isEditing ? (
                    <Textarea
                      id="remarks"
                      value={editData.observations || editData.remarks || ''}
                      onChange={(e) => setEditData({...editData, observations: e.target.value, remarks: e.target.value})}
                      rows={3}
                    />
                  ) : (
                    <p className="mt-1 text-sm">
                      {(isAggregate ? aggregateData.observations : concreteData.product) || 'No remarks'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Test Results Tab */}
          <TabsContent value="results" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Results</CardTitle>
              </CardHeader>
              <CardContent>
                {isAggregate ? (
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="moisture_content">Moisture Content (%)</Label>
                      {isEditing ? (
                        <Input
                          id="moisture_content"
                          type="number"
                          step="0.01"
                          value={editData.moisture_content || ''}
                          onChange={(e) => setEditData({...editData, moisture_content: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.moisture_content || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="sand_equivalent">Sand Equivalent</Label>
                      {isEditing ? (
                        <Input
                          id="sand_equivalent"
                          type="number"
                          step="0.01"
                          value={editData.sand_equivalent || ''}
                          onChange={(e) => setEditData({...editData, sand_equivalent: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.sand_equivalent || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="fineness_modulus">Fineness Modulus</Label>
                      {isEditing ? (
                        <Input
                          id="fineness_modulus"
                          type="number"
                          step="0.01"
                          value={editData.fineness_modulus || ''}
                          onChange={(e) => setEditData({...editData, fineness_modulus: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{aggregateData.fineness_modulus || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="grading_conformity">Grading Conformity</Label>
                      {isEditing ? (
                        <Select
                          value={editData.grading_conformity || ''}
                          onValueChange={(value) => setEditData({...editData, grading_conformity: value})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select conformity" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pass">Pass</SelectItem>
                            <SelectItem value="fail">Fail</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant={aggregateData.grading_conformity === 'pass' ? 'default' : 
                                     aggregateData.grading_conformity === 'fail' ? 'destructive' : 'secondary'}>
                          {aggregateData.grading_conformity || 'Pending'}
                        </Badge>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="load_kn">Load (kN)</Label>
                      {isEditing ? (
                        <Input
                          id="load_kn"
                          type="number"
                          step="0.01"
                          value={editData.load_kn || ''}
                          onChange={(e) => setEditData({...editData, load_kn: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{concreteData.load_kn || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="weight_kg">Weight (kg)</Label>
                      {isEditing ? (
                        <Input
                          id="weight_kg"
                          type="number"
                          step="0.01"
                          value={editData.weight_kg || ''}
                          onChange={(e) => setEditData({...editData, weight_kg: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm">{concreteData.weight_kg || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="strength_mpa">Strength (MPa)</Label>
                      {isEditing ? (
                        <Input
                          id="strength_mpa"
                          type="number"
                          step="0.01"
                          value={editData.strength_mpa || ''}
                          onChange={(e) => setEditData({...editData, strength_mpa: parseFloat(e.target.value)})}
                        />
                      ) : (
                        <p className="mt-1 text-sm font-semibold">{concreteData.strength_mpa || 'N/A'}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="status">Status</Label>
                      {isEditing ? (
                        <Select
                          value={editData.status || ''}
                          onValueChange={(value) => setEditData({...editData, status: value})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pass">Pass</SelectItem>
                            <SelectItem value="fail">Fail</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge variant={concreteData.status === 'pass' ? 'default' : 
                                     concreteData.status === 'fail' ? 'destructive' : 'secondary'}>
                          {concreteData.status || 'Pending'}
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analysis Tab */}
          <TabsContent value="analysis" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Created Date</Label>
                      <p className="mt-1 text-sm">
                        {testResult.created_at ? new Date(testResult.created_at).toLocaleString() : 'N/A'}
                      </p>
                    </div>
                    <div>
                      <Label>Last Updated</Label>
                      <p className="mt-1 text-sm">
                        {testResult.updated_at ? new Date(testResult.updated_at).toLocaleString() : 'N/A'}
                      </p>
                    </div>
                  </div>

                  {!isAggregate && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Data Source</Label>
                        <p className="mt-1 text-sm">
                          <Badge variant="outline">
                            {concreteData.data_source || 'Manual'}
                          </Badge>
                        </p>
                      </div>
                      <div>
                        <Label>Sync Status</Label>
                        <p className="mt-1 text-sm">
                          <Badge variant="outline">
                            {concreteData.sync_status || 'Local'}
                          </Badge>
                        </p>
                      </div>
                    </div>
                  )}

                  <div>
                    <Label>Test ID</Label>
                    <p className="mt-1 text-sm text-muted-foreground font-mono">{testResult.id}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}