// Dynamic form builder for Test Result Manager using product definitions
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  TestTube, 
  Calculator, 
  Save, 
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Info
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { TestModulesAPI } from '@/services/api/testModulesAPI';
import { unifiedTestService } from '@/services/database/unifiedTestService';
import { referenceDataIntegration } from '@/services/integration/referenceDataIntegration';

interface DynamicTestFormProps {
  productTypeId?: string;
  memoId?: string;
  existingEntry?: any;
  onSuccess: () => void;
  onCancel: () => void;
}

interface ProductField {
  id: string;
  field_name: string;
  field_type: string;
  is_required: boolean;
  default_value?: any;
  validation_rules?: string;
  field_options?: string[];
  units?: string;
  category?: string;
}

interface FormData {
  [key: string]: any;
}

interface ValidationErrors {
  [key: string]: string;
}

export const DynamicTestForm: React.FC<DynamicTestFormProps> = ({
  productTypeId,
  memoId,
  existingEntry,
  onSuccess,
  onCancel
}) => {
  const { toast } = useToast();
  const [productTypes, setProductTypes] = useState<any[]>([]);
  const [selectedProductType, setSelectedProductType] = useState<string>(productTypeId || '');
  const [productFields, setProductFields] = useState<ProductField[]>([]);
  const [formData, setFormData] = useState<FormData>({});
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  
  // Reference data
  const [plants, setPlants] = useState<any[]>([]);
  const [officers, setOfficers] = useState<any[]>([]);
  const [memos, setMemos] = useState<any[]>([]);

  const isEditing = !!existingEntry;

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedProductType) {
      loadProductFields(selectedProductType);
    } else {
      setProductFields([]);
      setFormData({});
    }
  }, [selectedProductType]);

  useEffect(() => {
    if (existingEntry) {
      populateFormFromEntry(existingEntry);
    }
  }, [existingEntry, productFields]);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [
        productTypesData,
        plantsData,
        officersData,
        memosData
      ] = await Promise.all([
        TestModulesAPI.getProductTypes(),
        referenceDataIntegration.getModuleReferenceData('test-modules', 'plants'),
        referenceDataIntegration.getModuleReferenceData('test-modules', 'officers'),
        referenceDataIntegration.getModuleReferenceData('test-modules', 'memos') || []
      ]);

      setProductTypes(productTypesData);
      setPlants(plantsData);
      setOfficers(officersData);
      setMemos(memosData);

    } catch (error) {
      toast({
        title: "Loading Error",
        description: "Failed to load form data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadProductFields = async (productTypeId: string) => {
    try {
      const fields = await TestModulesAPI.getProductFields(productTypeId);
      // Map API fields to local interface
      const mappedFields = fields.map((f: any) => ({
        id: f.id,
        field_name: f.field_name,
        field_type: f.field_type,
        is_required: f.is_required,
        default_value: f.default_value || undefined,
        validation_rules: JSON.stringify(f.validation_rules || {}),
        field_options: f.field_options || [],
        units: f.units || undefined,
        category: f.category || 'General'
      }));
      setProductFields(mappedFields);
      
      // Initialize form data with default values
      const initialData: FormData = {
        plant_id: '',
        officer_id: '',
        memo_id: memoId || '',
        test_date: new Date().toISOString().split('T')[0],
        status: 'draft',
        notes: ''
      };

      mappedFields.forEach(field => {
        const fieldName = field.field_name;
        if (field.default_value !== undefined) {
          initialData[fieldName] = field.default_value;
        } else {
          switch (field.field_type) {
            case 'number':
              initialData[fieldName] = '';
              break;
            case 'boolean':
              initialData[fieldName] = false;
              break;
            case 'date':
              initialData[fieldName] = new Date().toISOString().split('T')[0];
              break;
            default:
              initialData[fieldName] = '';
          }
        }
      });

      setFormData(initialData);
      setValidationErrors({});

    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load product fields",
        variant: "destructive"
      });
    }
  };

  const populateFormFromEntry = (entry: any) => {
    if (!productFields.length) return;

    const populatedData: FormData = {
      plant_id: entry.plant_id || '',
      officer_id: entry.officer_id || '',
      memo_id: entry.memo_id || '',
      test_date: entry.test_date ? entry.test_date.split('T')[0] : '',
      status: entry.status || 'draft',
      notes: entry.notes || '',
      ...entry.test_data
    };

    setFormData(populatedData);
  };

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));

    // Clear validation error for this field
    if (validationErrors[fieldName]) {
      setValidationErrors(prev => {
        const { [fieldName]: removed, ...rest } = prev;
        return rest;
      });
    }
  };

  const validateForm = (): boolean => {
    const errors: ValidationErrors = {};

    // Validate required core fields
    if (!formData.plant_id) errors.plant_id = 'Plant is required';
    if (!formData.officer_id) errors.officer_id = 'Officer is required';
    if (!formData.test_date) errors.test_date = 'Test date is required';

    // Validate product fields
    productFields.forEach(field => {
      const fieldName = field.field_name;
      const value = formData[fieldName];
      
      if (field.is_required && (!value || value === '')) {
        errors[fieldName] = `${fieldName} is required`;
      }

      if (value && field.validation_rules) {
        // Apply validation rules
        const rules = JSON.parse(field.validation_rules || '{}');
        
        if (rules.min && Number(value) < rules.min) {
          errors[fieldName] = `Minimum value is ${rules.min}`;
        }
        
        if (rules.max && Number(value) > rules.max) {
          errors[fieldName] = `Maximum value is ${rules.max}`;
        }
        
        if (rules.pattern && !new RegExp(rules.pattern).test(value)) {
          errors[fieldName] = rules.message || 'Invalid format';
        }
      }
    });

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors before submitting",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      // Separate core fields from test data
      const { plant_id, officer_id, memo_id, test_date, status, notes, ...testData } = formData;

      const entryData = {
        plant_id,
        product_type_id: selectedProductType,
        memo_id: memo_id || undefined,
        officer_id,
        test_date,
        status,
        notes,
        test_data: testData,
        created_by: 'current_user',
        updated_by: 'current_user'
      };

      if (isEditing) {
        // For editing, we'd need to implement updateTestEntry method
        toast({
          title: "Not Implemented",
          description: "Update functionality coming soon",
          variant: "destructive"
        });
        return;
      } else {
        await unifiedTestService.createTestEntry(entryData);
        toast({
          title: "Success", 
          description: "Test entry created successfully"
        });
      }

      onSuccess();

    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save test entry",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const renderField = (field: ProductField) => {
    const fieldName = field.field_name;
    const value = formData[fieldName] || '';
    const hasError = !!validationErrors[fieldName];

    const fieldProps = {
      id: fieldName,
      value,
      onChange: (e: any) => handleFieldChange(fieldName, e.target.value),
      className: hasError ? 'border-destructive' : ''
    };

    switch (field.field_type) {
      case 'number':
        return (
          <div className="flex items-center space-x-2">
            <Input
              {...fieldProps}
              type="number"
              step="any"
              placeholder={`Enter ${fieldName}`}
              className="flex-1"
            />
            {field.units && (
              <Badge variant="outline">{field.units}</Badge>
            )}
          </div>
        );

      case 'select':
        return (
          <Select value={value} onValueChange={(val) => handleFieldChange(fieldName, val)}>
            <SelectTrigger className={hasError ? 'border-destructive' : ''}>
              <SelectValue placeholder={`Select ${fieldName}`} />
            </SelectTrigger>
            <SelectContent>
              {field.field_options?.map(option => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              id={fieldName}
              checked={!!value}
              onCheckedChange={(checked) => handleFieldChange(fieldName, checked)}
            />
            <Label htmlFor={fieldName}>Yes</Label>
          </div>
        );

      case 'date':
        return (
          <Input
            {...fieldProps}
            type="date"
          />
        );

      case 'textarea':
        return (
          <Textarea
            {...fieldProps}
            placeholder={`Enter ${fieldName}`}
            rows={3}
          />
        );

      default:
        return (
          <Input
            {...fieldProps}
            type="text"
            placeholder={`Enter ${fieldName}`}
          />
        );
    }
  };

  const groupFieldsByCategory = (fields: ProductField[]) => {
    const grouped = fields.reduce((acc, field) => {
      const category = field.category || 'General';
      if (!acc[category]) acc[category] = [];
      acc[category].push(field);
      return acc;
    }, {} as Record<string, ProductField[]>);

    return grouped;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <RefreshCw className="w-6 h-6 animate-spin mr-2" />
          Loading form...
        </CardContent>
      </Card>
    );
  }

  const groupedFields = groupFieldsByCategory(productFields);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TestTube className="w-5 h-5 mr-2" />
            {isEditing ? 'Edit Test Entry' : 'New Test Entry'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Product Type Selection */}
          {!isEditing && (
            <div className="space-y-2">
              <Label htmlFor="product_type">Product Type *</Label>
              <Select value={selectedProductType} onValueChange={setSelectedProductType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.map(pt => (
                    <SelectItem key={pt.id} value={pt.id}>
                      {pt.name} ({pt.category})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Core Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plant_id">Plant *</Label>
              <Select value={formData.plant_id} onValueChange={(val) => handleFieldChange('plant_id', val)}>
                <SelectTrigger className={validationErrors.plant_id ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select plant" />
                </SelectTrigger>
                <SelectContent>
                  {plants.map(plant => (
                    <SelectItem key={plant.id} value={plant.id}>
                      {plant.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {validationErrors.plant_id && (
                <p className="text-sm text-destructive">{validationErrors.plant_id}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="officer_id">Officer *</Label>
              <Select value={formData.officer_id} onValueChange={(val) => handleFieldChange('officer_id', val)}>
                <SelectTrigger className={validationErrors.officer_id ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select officer" />
                </SelectTrigger>
                <SelectContent>
                  {officers.map(officer => (
                    <SelectItem key={officer.id} value={officer.id}>
                      {officer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {validationErrors.officer_id && (
                <p className="text-sm text-destructive">{validationErrors.officer_id}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="test_date">Test Date *</Label>
              <Input
                type="date"
                value={formData.test_date}
                onChange={(e) => handleFieldChange('test_date', e.target.value)}
                className={validationErrors.test_date ? 'border-destructive' : ''}
              />
              {validationErrors.test_date && (
                <p className="text-sm text-destructive">{validationErrors.test_date}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="memo_id">Memo Reference</Label>
              <Select value={formData.memo_id} onValueChange={(val) => handleFieldChange('memo_id', val)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select memo (optional)" />
                </SelectTrigger>
                <SelectContent>
                  {memos.map(memo => (
                    <SelectItem key={memo.id} value={memo.id}>
                      {memo.reference}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => handleFieldChange('notes', e.target.value)}
              placeholder="Additional notes or observations"
              rows={2}
            />
          </div>

          {selectedProductType && productFields.length > 0 && (
            <>
              <Separator />
              
              {/* Dynamic Product Fields */}
              {Object.entries(groupedFields).map(([category, fields]) => (
                <div key={category} className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Calculator className="w-4 h-4" />
                    <h3 className="text-lg font-semibold">{category}</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {fields.map(field => {
                      const fieldName = field.field_name;
                      return (
                        <div key={field.id} className="space-y-2">
                        <Label htmlFor={fieldName}>
                          {fieldName}
                          {field.is_required && <span className="text-destructive ml-1">*</span>}
                        </Label>
                        {renderField(field)}
                        {validationErrors[fieldName] && (
                          <p className="text-sm text-destructive">{validationErrors[fieldName]}</p>
                        )}
                      </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Validation Summary */}
          {Object.keys(validationErrors).length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                Please fix {Object.keys(validationErrors).length} validation error(s) before submitting.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={saving || !selectedProductType}>
          {saving && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
          <Save className="w-4 h-4 mr-2" />
          {isEditing ? 'Update' : 'Save'} Test Entry
        </Button>
      </div>
    </div>
  );
};