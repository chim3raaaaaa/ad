import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TestResultsAPI, TabletConnection } from "@/services/api/testResultsAPI";
import { useToast } from "@/hooks/use-toast";
import { 
  Tablet, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Plus, 
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle
} from "lucide-react";

interface TabletConnectionPanelProps {
  onDataReceived?: () => void;
}

export function TabletConnectionPanel({ onDataReceived }: TabletConnectionPanelProps) {
  const { toast } = useToast();
  const [connections, setConnections] = useState<TabletConnection[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newDevice, setNewDevice] = useState({
    device_id: '',
    device_name: '',
    operator_name: '',
    location: ''
  });

  useEffect(() => {
    loadConnections();
    
    // Start connection monitoring
    const interval = setInterval(() => {
      checkConnectionHealth();
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const loadConnections = async () => {
    setIsLoading(true);
    try {
      const result = await TestResultsAPI.getTabletConnections();
      if (result.success) {
        setConnections(result.data || []);
      } else {
        toast({
          title: "Failed to Load Connections",
          description: result.error || "Could not load tablet connections",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Connection Error",
        description: "Failed to load tablet connections",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const checkConnectionHealth = async () => {
    // Simulate connection health check
    const updatedConnections = connections.map(conn => {
      const timeSinceLastPing = new Date().getTime() - new Date(conn.last_ping).getTime();
      const isStale = timeSinceLastPing > 60000; // 1 minute threshold
      
      if (isStale && conn.status === 'online') {
        TestResultsAPI.updateTabletStatus(conn.device_id, 'offline');
        return { ...conn, status: 'offline' as const };
      }
      
      return conn;
    });
    
    setConnections(updatedConnections);
  };

  const handleAddDevice = async () => {
    if (!newDevice.device_id || !newDevice.device_name) {
      toast({
        title: "Invalid Device Info",
        description: "Device ID and name are required",
        variant: "destructive"
      });
      return;
    }

    try {
      const result = await TestResultsAPI.registerTabletDevice(newDevice);
      if (result.success) {
        toast({
          title: "Device Registered",
          description: `Tablet ${newDevice.device_name} has been registered`
        });
        setShowAddDialog(false);
        setNewDevice({ device_id: '', device_name: '', operator_name: '', location: '' });
        loadConnections();
      } else {
        toast({
          title: "Registration Failed",
          description: result.error || "Failed to register tablet device",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Registration Error",
        description: "An error occurred while registering the device",
        variant: "destructive"
      });
    }
  };

  const handleTestConnection = async (deviceId: string) => {
    try {
      // Simulate connection test
      const success = Math.random() > 0.2; // 80% success rate for demo
      
      if (success) {
        await TestResultsAPI.updateTabletStatus(deviceId, 'online');
        toast({
          title: "Connection Test Successful",
          description: "Tablet is responding normally"
        });
      } else {
        await TestResultsAPI.updateTabletStatus(deviceId, 'offline');
        toast({
          title: "Connection Test Failed",
          description: "Tablet is not responding",
          variant: "destructive"
        });
      }
      
      loadConnections();
    } catch (error) {
      toast({
        title: "Test Failed",
        description: "Could not test tablet connection",
        variant: "destructive"
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'offline':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'online':
        return 'default';
      case 'offline':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const onlineCount = connections.filter(c => c.status === 'online').length;
  const totalCount = connections.length;
  const healthPercentage = totalCount > 0 ? (onlineCount / totalCount) * 100 : 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Tablet className="h-5 w-5" />
            Tablet Connections
            <Badge variant="outline">{onlineCount}/{totalCount} Online</Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={loadConnections} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Device
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Register New Tablet Device</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="device_id">Device ID</Label>
                    <Input
                      id="device_id"
                      placeholder="e.g., TAB001"
                      value={newDevice.device_id}
                      onChange={(e) => setNewDevice({...newDevice, device_id: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="device_name">Device Name</Label>
                    <Input
                      id="device_name"
                      placeholder="e.g., Production Tablet 1"
                      value={newDevice.device_name}
                      onChange={(e) => setNewDevice({...newDevice, device_name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="operator_name">Operator Name</Label>
                    <Input
                      id="operator_name"
                      placeholder="e.g., John Smith"
                      value={newDevice.operator_name}
                      onChange={(e) => setNewDevice({...newDevice, operator_name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      placeholder="e.g., Plant A - Production Line 1"
                      value={newDevice.location}
                      onChange={(e) => setNewDevice({...newDevice, location: e.target.value})}
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddDevice}>
                      Register Device
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Health Status Alert */}
        <Alert className={`mb-4 ${healthPercentage >= 80 ? 'border-green-200 bg-green-50' : 
                                healthPercentage >= 50 ? 'border-yellow-200 bg-yellow-50' : 
                                'border-red-200 bg-red-50'}`}>
          <Activity className="h-4 w-4" />
          <AlertDescription>
            Network Health: {healthPercentage.toFixed(0)}% ({onlineCount} of {totalCount} tablets online)
            {healthPercentage < 50 && (
              <span className="block mt-1 text-sm text-red-600">
                Warning: Low tablet connectivity detected. Check network connection.
              </span>
            )}
          </AlertDescription>
        </Alert>

        {/* Connections Table */}
        {connections.length === 0 ? (
          <div className="text-center py-8">
            <Tablet className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
            <p className="text-muted-foreground">No tablet devices registered</p>
            <Button variant="outline" className="mt-2" onClick={() => setShowAddDialog(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Register First Tablet
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Device</TableHead>
                <TableHead>Operator</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Ping</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {connections.map((connection) => (
                <TableRow key={connection.device_id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(connection.status)}
                      <div>
                        <p className="font-medium">{connection.device_name}</p>
                        <p className="text-sm text-muted-foreground">{connection.device_id}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{connection.operator_name || 'N/A'}</TableCell>
                  <TableCell>{connection.location || 'N/A'}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(connection.status)}>
                      {connection.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">
                      {connection.last_ping ? new Date(connection.last_ping).toLocaleString() : 'Never'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleTestConnection(connection.device_id)}
                    >
                      {connection.status === 'online' ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}