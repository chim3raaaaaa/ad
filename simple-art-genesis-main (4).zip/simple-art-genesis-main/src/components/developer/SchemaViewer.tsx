import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ReactFlow,
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  MiniMap,
  Background,
  MarkerType
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Database, Table, Link, Eye, Download, RefreshCw } from "lucide-react";

// Define custom node types
const TableNode = ({ data }: { data: any }) => {
  return (
    <div className="bg-background border border-border rounded-lg shadow-lg min-w-48">
      <div className="bg-primary text-primary-foreground px-3 py-2 rounded-t-lg flex items-center gap-2">
        <Table className="w-4 h-4" />
        <span className="font-medium text-sm">{data.name}</span>
      </div>
      <div className="p-2 space-y-1">
        {data.columns.map((column: any, index: number) => (
          <div key={index} className="flex items-center justify-between text-xs">
            <span className={column.primary ? "font-bold" : ""}>{column.name}</span>
            <div className="flex gap-1">
              <Badge variant="outline" className="text-xs">
                {column.type}
              </Badge>
              {column.primary && <Badge variant="destructive" className="text-xs">PK</Badge>}
              {column.foreign_key && <Badge variant="secondary" className="text-xs">FK</Badge>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const nodeTypes = {
  table: TableNode,
};

export function SchemaViewer() {
  const [selectedView, setSelectedView] = useState<string>('full');
  const [isGenerating, setIsGenerating] = useState(false);

  // Mock data removed - using empty arrays
  const mockTables: any[] = [];

  const mockRelationships: any[] = [];

  // Generate nodes and edges for React Flow
  const generateFlowData = () => {
    const nodes: Node[] = mockTables.map((table, index) => ({
      id: table.name,
      type: 'table',
      position: table.position,
      data: table,
    }));

    const edges: Edge[] = mockRelationships.map((rel, index) => ({
      id: `${rel.from}-${rel.to}-${index}`,
      source: rel.from,
      target: rel.to,
      type: 'smoothstep',
      markerEnd: {
        type: MarkerType.ArrowClosed,
      },
      label: `${rel.fromField} → ${rel.toField}`,
      labelStyle: { fontSize: 10, fill: '#666' },
    }));

    return { nodes, edges };
  };

  const { nodes: initialNodes, edges: initialEdges } = generateFlowData();
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const regenerateSchema = async () => {
    setIsGenerating(true);
    // Simulate loading
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const { nodes: newNodes, edges: newEdges } = generateFlowData();
    setNodes(newNodes);
    setEdges(newEdges);
    setIsGenerating(false);
  };

  const exportSchema = () => {
    const schemaData = {
      tables: mockTables,
      relationships: mockRelationships,
      exported_at: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(schemaData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `database_schema_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Database className="w-4 h-4" />
              Schema Viewer
            </CardTitle>
            
            <div className="flex items-center gap-2">
              <Select value={selectedView} onValueChange={setSelectedView}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full">Full Schema</SelectItem>
                  <SelectItem value="core">Core Tables</SelectItem>
                  <SelectItem value="user">User Management</SelectItem>
                  <SelectItem value="testing">Testing Module</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="sm" onClick={regenerateSchema} disabled={isGenerating}>
                {isGenerating ? (
                  <RefreshCw className="w-3 h-3 animate-spin" />
                ) : (
                  <RefreshCw className="w-3 h-3" />
                )}
              </Button>
              
              <Button variant="outline" size="sm" onClick={exportSchema}>
                <Download className="w-3 h-3 mr-1" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div style={{ height: '500px', width: '100%' }}>
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              nodeTypes={nodeTypes}
              fitView
              fitViewOptions={{ padding: 0.2 }}
              style={{ backgroundColor: '#f8f9fa' }}
            >
              <Controls />
              <MiniMap 
                nodeStrokeColor={(n) => '#333'}
                nodeColor={(n) => '#f0f0f0'}
                nodeBorderRadius={8}
              />
              <Background gap={12} size={1} />
            </ReactFlow>
          </div>
        </CardContent>
      </Card>

      {/* Schema Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{mockTables.length}</div>
            <p className="text-xs text-muted-foreground">Tables</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{mockRelationships.length}</div>
            <p className="text-xs text-muted-foreground">Relationships</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {mockTables.reduce((acc, table) => acc + table.columns.length, 0)}
            </div>
            <p className="text-xs text-muted-foreground">Total Fields</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {mockTables.reduce((acc, table) => 
                acc + table.columns.filter((col: any) => col.foreign_key).length, 0)}
            </div>
            <p className="text-xs text-muted-foreground">Foreign Keys</p>
          </CardContent>
        </Card>
      </div>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Legend</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Badge variant="destructive" className="text-xs">PK</Badge>
                <span>Primary Key</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">FK</Badge>
                <span>Foreign Key</span>
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-4 h-1 bg-gray-400 rounded"></div>
                <span>Relationship</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-3 h-3" />
                <span>Click & drag to explore</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}