import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { PLACEMENT_OPTIONS, type PlacementOption } from '@/types/developer';
import { MapPin, Route, Settings } from 'lucide-react';

interface PlacementSelectorProps {
  selectedPlacement: string;
  onPlacementChange: (placement: string) => void;
  moduleId?: string;
  onModuleIdChange?: (moduleId: string) => void;
  customRoute?: string;
  onCustomRouteChange?: (route: string) => void;
  className?: string;
}

export function PlacementSelector({
  selectedPlacement,
  onPlacementChange,
  moduleId,
  onModuleIdChange,
  customRoute,
  onCustomRouteChange,
  className
}: PlacementSelectorProps) {
  const selectedOption = PLACEMENT_OPTIONS.find(opt => opt.id === selectedPlacement);
  const isCustomRoute = selectedPlacement === 'custom-route';

  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base">
          <MapPin className="h-4 w-4" />
          Placement Configuration
        </CardTitle>
        <CardDescription>
          Choose where this item will appear in the application
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="placement">Display Location</Label>
          <Select value={selectedPlacement} onValueChange={onPlacementChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select where to display this item..." />
            </SelectTrigger>
            <SelectContent>
              {PLACEMENT_OPTIONS.map((option) => (
                <SelectItem key={option.id} value={option.id}>
                  <div className="flex flex-col">
                    <span className="font-medium">{option.label}</span>
                    <span className="text-xs text-muted-foreground">{option.description}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedOption && !isCustomRoute && (
          <div className="rounded-lg bg-muted p-3">
            <div className="flex items-center gap-2 text-sm font-medium mb-1">
              <Route className="h-3 w-3" />
              Target Location
            </div>
            <p className="text-sm text-muted-foreground">
              Will appear in: <span className="font-medium">{selectedOption.label}</span>
            </p>
            {selectedOption.route && (
              <p className="text-xs text-muted-foreground mt-1">
                Route: {selectedOption.route}
              </p>
            )}
          </div>
        )}

        {isCustomRoute && onCustomRouteChange && (
          <div className="space-y-2">
            <Label htmlFor="custom-route">Custom Route Path</Label>
            <Input
              id="custom-route"
              placeholder="/my-custom-page"
              value={customRoute || ''}
              onChange={(e) => onCustomRouteChange(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Enter the route path for your custom page (e.g., /my-custom-page)
            </p>
          </div>
        )}

        {onModuleIdChange && (
          <div className="space-y-2">
            <Label htmlFor="module-id">
              <span className="flex items-center gap-2">
                <Settings className="h-3 w-3" />
                Module ID (Optional)
              </span>
            </Label>
            <Input
              id="module-id"
              placeholder="module-identifier"
              value={moduleId || ''}
              onChange={(e) => onModuleIdChange(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Link this item to a specific module for better organization
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}