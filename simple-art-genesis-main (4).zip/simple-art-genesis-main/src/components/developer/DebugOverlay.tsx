import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Eye, EyeOff } from "lucide-react";

interface DebugInfo {
  element: HTMLElement;
  id?: string;
  className?: string;
  tagName: string;
  fieldName?: string;
  dataAttributes: Record<string, string>;
  position: { x: number; y: number };
}

export function DebugOverlay() {
  const [debugElements, setDebugElements] = useState<DebugInfo[]>([]);
  const [showOverlay, setShowOverlay] = useState(true);
  const [hoveredElement, setHoveredElement] = useState<HTMLElement | null>(null);

  useEffect(() => {
    const handleMouseOver = (e: MouseEvent) => {
      if (!showOverlay) return;
      
      const target = e.target as HTMLElement;
      
      // Skip if hovering over debug overlay elements
      if (target.closest('[data-debug-overlay]')) return;
      
      setHoveredElement(target);
    };

    const handleMouseOut = () => {
      setHoveredElement(null);
    };

    const handleClick = (e: MouseEvent) => {
      if (!showOverlay) return;
      
      const target = e.target as HTMLElement;
      
      // Skip if clicking on debug overlay elements
      if (target.closest('[data-debug-overlay]')) return;
      
      e.preventDefault();
      e.stopPropagation();
      
      const rect = target.getBoundingClientRect();
      const dataAttributes: Record<string, string> = {};
      
      // Extract data attributes
      Array.from(target.attributes).forEach(attr => {
        if (attr.name.startsWith('data-') || attr.name.includes('id') || attr.name.includes('name')) {
          dataAttributes[attr.name] = attr.value;
        }
      });

      // Try to determine field name from various sources
      let fieldName = target.getAttribute('name') || 
                     target.getAttribute('data-field') ||
                     target.getAttribute('id') ||
                     target.getAttribute('placeholder') ||
                     target.textContent?.trim() ||
                     'Unknown';

      const debugInfo: DebugInfo = {
        element: target,
        id: target.id || undefined,
        className: target.className || undefined,
        tagName: target.tagName.toLowerCase(),
        fieldName: fieldName.length > 50 ? fieldName.substring(0, 50) + '...' : fieldName,
        dataAttributes,
        position: { x: rect.left + rect.width / 2, y: rect.top }
      };

      setDebugElements(prev => {
        // Remove any existing debug info for this element
        const filtered = prev.filter(item => item.element !== target);
        return [...filtered, debugInfo];
      });
    };

    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mouseout', handleMouseOut);
    document.addEventListener('click', handleClick, true);

    return () => {
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('mouseout', handleMouseOut);
      document.removeEventListener('click', handleClick, true);
    };
  }, [showOverlay]);

  const removeDebugInfo = (element: HTMLElement) => {
    setDebugElements(prev => prev.filter(item => item.element !== element));
  };

  const clearAll = () => {
    setDebugElements([]);
  };

  return (
    <>
      {/* Hovered element highlight */}
      {showOverlay && hoveredElement && (
        <div
          style={{
            position: 'fixed',
            top: hoveredElement.getBoundingClientRect().top,
            left: hoveredElement.getBoundingClientRect().left,
            width: hoveredElement.getBoundingClientRect().width,
            height: hoveredElement.getBoundingClientRect().height,
            border: '2px solid #ff6b6b',
            backgroundColor: 'rgba(255, 107, 107, 0.1)',
            pointerEvents: 'none',
            zIndex: 9998,
            borderRadius: '4px'
          }}
        />
      )}

      {/* Debug info overlays */}
      {debugElements.map((debugInfo, index) => (
        <Card
          key={index}
          data-debug-overlay
          style={{
            position: 'fixed',
            top: debugInfo.position.y - 10,
            left: debugInfo.position.x,
            transform: 'translateX(-50%)',
            zIndex: 9999,
            maxWidth: '300px',
            fontSize: '12px'
          }}
          className="p-2 shadow-lg border-2 border-blue-500 bg-blue-50/95 backdrop-blur-sm"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-1 min-w-0">
              <div className="flex items-center gap-1 flex-wrap">
                <Badge variant="outline" className="text-xs">
                  {debugInfo.tagName}
                </Badge>
                {debugInfo.id && (
                  <Badge variant="secondary" className="text-xs">
                    #{debugInfo.id}
                  </Badge>
                )}
              </div>
              
              <div className="text-xs font-medium truncate">
                {debugInfo.fieldName}
              </div>
              
              {debugInfo.className && (
                <div className="text-xs text-muted-foreground truncate">
                  .{debugInfo.className.split(' ').slice(0, 2).join(' ')}
                </div>
              )}
              
              {Object.keys(debugInfo.dataAttributes).length > 0 && (
                <div className="text-xs text-muted-foreground">
                  {Object.entries(debugInfo.dataAttributes)
                    .slice(0, 2)
                    .map(([key, value]) => (
                      <div key={key} className="truncate">
                        {key}: {value.substring(0, 20)}
                      </div>
                    ))}
                </div>
              )}
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="h-4 w-4 p-0"
              onClick={() => removeDebugInfo(debugInfo.element)}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </Card>
      ))}

      {/* Debug control panel */}
      <Card
        data-debug-overlay
        style={{
          position: 'fixed',
          top: 20,
          right: 20,
          zIndex: 10000
        }}
        className="p-2 shadow-lg border-red-500 bg-red-50/95 backdrop-blur-sm"
      >
        <div className="flex items-center gap-2">
          <Badge variant="destructive" className="text-xs">
            DEBUG MODE
          </Badge>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowOverlay(!showOverlay)}
            className="h-6 w-6 p-0"
          >
            {showOverlay ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
          </Button>
          
          {debugElements.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAll}
              className="h-6 px-2 text-xs"
            >
              Clear ({debugElements.length})
            </Button>
          )}
        </div>
        
        {showOverlay && (
          <div className="text-xs text-muted-foreground mt-1">
            Click elements to inspect
          </div>
        )}
      </Card>
    </>
  );
}