import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Download, Upload, FileJson, Database, Code, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SchemaExportData {
  version: string;
  exported_at: string;
  forms: any[];
  tables: any[];
  components: any[];
  workflows: any[];
  api_endpoints: any[];
  relationships: any[];
  themes: any[];
  audit_logs?: any[];
}

interface ExportOptions {
  includeForms: boolean;
  includeTables: boolean;
  includeComponents: boolean;
  includeWorkflows: boolean;
  includeAPIEndpoints: boolean;
  includeRelationships: boolean;
  includeThemes: boolean;
  includeAuditLogs: boolean;
  includeData: boolean;
  format: 'json' | 'sql' | 'csv';
}

export function SchemaExporter() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [exportPreview, setExportPreview] = useState<SchemaExportData | null>(null);
  const [importData, setImportData] = useState('');
  const [showImportDialog, setShowImportDialog] = useState(false);
  
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    includeForms: true,
    includeTables: true,
    includeComponents: true,
    includeWorkflows: true,
    includeAPIEndpoints: true,
    includeRelationships: true,
    includeThemes: true,
    includeAuditLogs: false,
    includeData: false,
    format: 'json'
  });

  const isElectron = () => window.electronAPI !== undefined;

  const executeQuery = async <T,>(sql: string, params: any[] = []): Promise<T[]> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  };

  const executeRun = async (sql: string, params: any[] = []): Promise<any> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  };

  const exportSchema = async (): Promise<SchemaExportData> => {
    const exportData: SchemaExportData = {
      version: '1.0',
      exported_at: new Date().toISOString(),
      forms: [],
      tables: [],
      components: [],
      workflows: [],
      api_endpoints: [],
      relationships: [],
      themes: [],
      audit_logs: []
    };

    try {
      // Export forms
      if (exportOptions.includeForms) {
        const forms = await executeQuery('SELECT * FROM form_definitions ORDER BY created_at');
        exportData.forms = forms.map((form: any) => ({
          ...form,
          fields: JSON.parse(form.fields || '[]')
        }));
      }

      // Export tables
      if (exportOptions.includeTables) {
        const tables = await executeQuery('SELECT * FROM table_definitions ORDER BY created_at');
        exportData.tables = tables.map((table: any) => ({
          ...table,
          columns: JSON.parse(table.columns || '[]'),
          features: JSON.parse(table.features || '{}')
        }));
      }

      // Export components
      if (exportOptions.includeComponents) {
        const components = await executeQuery('SELECT * FROM component_definitions ORDER BY created_at');
        exportData.components = components.map((component: any) => ({
          ...component,
          props_schema: component.props_schema ? JSON.parse(component.props_schema) : undefined
        }));
      }

      // Export workflows
      if (exportOptions.includeWorkflows) {
        const workflows = await executeQuery('SELECT * FROM workflow_definitions ORDER BY created_at');
        exportData.workflows = workflows.map((workflow: any) => ({
          ...workflow,
          trigger_config: JSON.parse(workflow.trigger_config || '{}'),
          steps: JSON.parse(workflow.steps || '[]')
        }));
      }

      // Export API endpoints
      if (exportOptions.includeAPIEndpoints) {
        const endpoints = await executeQuery('SELECT * FROM api_endpoint_definitions ORDER BY created_at');
        exportData.api_endpoints = endpoints.map((endpoint: any) => ({
          ...endpoint,
          request_schema: endpoint.request_schema ? JSON.parse(endpoint.request_schema) : undefined,
          response_schema: endpoint.response_schema ? JSON.parse(endpoint.response_schema) : undefined
        }));
      }

      // Export relationships
      if (exportOptions.includeRelationships) {
        const relationships = await executeQuery('SELECT * FROM data_relationships ORDER BY created_at').catch(() => []);
        exportData.relationships = relationships;
      }

      // Export themes
      if (exportOptions.includeThemes) {
        const themes = await executeQuery('SELECT * FROM custom_themes ORDER BY created_at').catch(() => []);
        exportData.themes = themes.map((theme: any) => ({
          ...theme,
          colors: JSON.parse(theme.colors || '{}')
        }));
      }

      // Export audit logs (if requested)
      if (exportOptions.includeAuditLogs) {
        const auditLogs = await executeQuery('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 1000').catch(() => []);
        exportData.audit_logs = auditLogs.map((log: any) => ({
          ...log,
          old_data: log.old_data ? JSON.parse(log.old_data) : null,
          new_data: log.new_data ? JSON.parse(log.new_data) : null
        }));
      }

      return exportData;
    } catch (error) {
      console.error('Error exporting schema:', error);
      throw error;
    }
  };

  const downloadExport = async () => {
    try {
      setIsLoading(true);
      const schemaData = await exportSchema();
      
      let content: string;
      let filename: string;
      let mimeType: string;

      switch (exportOptions.format) {
        case 'json':
          content = JSON.stringify(schemaData, null, 2);
          filename = `schema_export_${new Date().toISOString().slice(0, 10)}.json`;
          mimeType = 'application/json';
          break;
          
        case 'sql':
          content = generateSQLExport(schemaData);
          filename = `schema_export_${new Date().toISOString().slice(0, 10)}.sql`;
          mimeType = 'application/sql';
          break;
          
        case 'csv':
          content = generateCSVExport(schemaData);
          filename = `schema_export_${new Date().toISOString().slice(0, 10)}.csv`;
          mimeType = 'text/csv';
          break;
          
        default:
          throw new Error('Unsupported export format');
      }

      // Create download
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `Schema exported as ${filename}`
      });

    } catch (error) {
      console.error('Error downloading export:', error);
      toast({
        title: "Export Error",
        description: error instanceof Error ? error.message : "Failed to export schema",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generatePreview = async () => {
    try {
      setIsLoading(true);
      const schemaData = await exportSchema();
      setExportPreview(schemaData);
    } catch (error) {
      console.error('Error generating preview:', error);
      toast({
        title: "Preview Error",
        description: "Failed to generate export preview",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateSQLExport = (schemaData: SchemaExportData): string => {
    let sql = `-- Schema Export Generated on ${schemaData.exported_at}\n\n`;

    // Export table definitions
    if (schemaData.tables.length > 0) {
      sql += "-- TABLE DEFINITIONS\n";
      schemaData.tables.forEach(table => {
        const tableName = `custom_${table.name.toLowerCase().replace(/\s+/g, '_')}`;
        sql += `\nCREATE TABLE IF NOT EXISTS ${tableName} (\n`;
        sql += "  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),\n";
        
        table.columns.forEach((col: any) => {
          const nullable = col.nullable ? '' : ' NOT NULL';
          const defaultVal = col.default_value ? ` DEFAULT '${col.default_value}'` : '';
          sql += `  ${col.name.replace(/\s+/g, '_')} ${col.type}${nullable}${defaultVal},\n`;
        });
        
        sql += "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,\n";
        sql += "  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP\n";
        sql += ");\n";
      });
    }

    // Export form definitions as INSERT statements
    if (schemaData.forms.length > 0) {
      sql += "\n-- FORM DEFINITIONS\n";
      schemaData.forms.forEach(form => {
        sql += `INSERT INTO form_definitions (id, name, description, fields, placement, module_id, custom_route, created_at, updated_at, created_by) VALUES (\n`;
        sql += `  '${form.id}',\n`;
        sql += `  '${form.name.replace(/'/g, "''")}',\n`;
        sql += `  '${(form.description || '').replace(/'/g, "''")}',\n`;
        sql += `  '${JSON.stringify(form.fields).replace(/'/g, "''")}',\n`;
        sql += `  '${form.placement}',\n`;
        sql += `  ${form.module_id ? `'${form.module_id}'` : 'NULL'},\n`;
        sql += `  ${form.custom_route ? `'${form.custom_route}'` : 'NULL'},\n`;
        sql += `  '${form.created_at}',\n`;
        sql += `  '${form.updated_at}',\n`;
        sql += `  '${form.created_by}'\n`;
        sql += ");\n";
      });
    }

    return sql;
  };

  const generateCSVExport = (schemaData: SchemaExportData): string => {
    let csv = "Type,Name,Description,Details,Created_At\n";

    // Export forms
    schemaData.forms.forEach(form => {
      csv += `Form,"${form.name}","${form.description || ''}","${form.fields.length} fields","${form.created_at}"\n`;
    });

    // Export tables
    schemaData.tables.forEach(table => {
      csv += `Table,"${table.name}","${table.description || ''}","${table.columns.length} columns","${table.created_at}"\n`;
    });

    // Export components
    schemaData.components.forEach(component => {
      csv += `Component,"${component.name}","${component.description || ''}","${component.placement}","${component.created_at}"\n`;
    });

    // Export workflows
    schemaData.workflows.forEach(workflow => {
      csv += `Workflow,"${workflow.name}","${workflow.description || ''}","${workflow.steps.length} steps","${workflow.created_at}"\n`;
    });

    return csv;
  };

  const importSchema = async () => {
    try {
      if (!importData.trim()) {
        toast({
          title: "Import Error",
          description: "Please provide schema data to import",
          variant: "destructive"
        });
        return;
      }

      setIsLoading(true);
      const schemaData: SchemaExportData = JSON.parse(importData);

      if (!schemaData.version) {
        throw new Error('Invalid schema format');
      }

      let importedCount = 0;

      // Import forms
      if (schemaData.forms && schemaData.forms.length > 0) {
        for (const form of schemaData.forms) {
          try {
            await executeRun(
              `INSERT OR REPLACE INTO form_definitions (id, name, description, fields, placement, module_id, custom_route, created_at, updated_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                form.id || crypto.randomUUID(),
                form.name,
                form.description || '',
                JSON.stringify(form.fields),
                form.placement || 'dashboard',
                form.module_id || null,
                form.custom_route || null,
                form.created_at || new Date().toISOString(),
                new Date().toISOString(),
                form.created_by || 'imported'
              ]
            );
            importedCount++;
          } catch (error) {
            console.error('Error importing form:', form.name, error);
          }
        }
      }

      // Import tables
      if (schemaData.tables && schemaData.tables.length > 0) {
        for (const table of schemaData.tables) {
          try {
            await executeRun(
              `INSERT OR REPLACE INTO table_definitions (id, name, description, columns, data_source, features, placement, module_id, custom_route, created_at, updated_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                table.id || crypto.randomUUID(),
                table.name,
                table.description || '',
                JSON.stringify(table.columns),
                table.data_source || 'manual',
                JSON.stringify(table.features || {}),
                table.placement || 'dashboard',
                table.module_id || null,
                table.custom_route || null,
                table.created_at || new Date().toISOString(),
                new Date().toISOString(),
                table.created_by || 'imported'
              ]
            );
            importedCount++;
          } catch (error) {
            console.error('Error importing table:', table.name, error);
          }
        }
      }

      // Import components
      if (schemaData.components && schemaData.components.length > 0) {
        for (const component of schemaData.components) {
          try {
            await executeRun(
              `INSERT OR REPLACE INTO component_definitions (id, name, description, component_code, props_schema, placement, module_id, custom_route, created_at, updated_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                component.id || crypto.randomUUID(),
                component.name,
                component.description || '',
                component.component_code,
                JSON.stringify(component.props_schema || {}),
                component.placement || 'dashboard',
                component.module_id || null,
                component.custom_route || null,
                component.created_at || new Date().toISOString(),
                new Date().toISOString(),
                component.created_by || 'imported'
              ]
            );
            importedCount++;
          } catch (error) {
            console.error('Error importing component:', component.name, error);
          }
        }
      }

      // Log import event
      await executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, new_data, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          'current_user',
          'import_schema',
          'schema',
          'bulk_import',
          JSON.stringify({ importedCount, version: schemaData.version }),
          new Date().toISOString()
        ]
      );

      setShowImportDialog(false);
      setImportData('');

      toast({
        title: "Import Successful",
        description: `Successfully imported ${importedCount} items`
      });

    } catch (error) {
      console.error('Error importing schema:', error);
      toast({
        title: "Import Error",
        description: error instanceof Error ? error.message : "Failed to import schema",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getExportSummary = () => {
    if (!exportPreview) return null;

    const summary = [
      { label: 'Forms', count: exportPreview.forms.length, included: exportOptions.includeForms },
      { label: 'Tables', count: exportPreview.tables.length, included: exportOptions.includeTables },
      { label: 'Components', count: exportPreview.components.length, included: exportOptions.includeComponents },
      { label: 'Workflows', count: exportPreview.workflows.length, included: exportOptions.includeWorkflows },
      { label: 'API Endpoints', count: exportPreview.api_endpoints.length, included: exportOptions.includeAPIEndpoints },
      { label: 'Relationships', count: exportPreview.relationships.length, included: exportOptions.includeRelationships },
      { label: 'Themes', count: exportPreview.themes.length, included: exportOptions.includeThemes }
    ];

    return summary.filter(item => item.included && item.count > 0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Schema Exporter</h3>
          <p className="text-sm text-muted-foreground">Export and import your complete application schema</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Import Schema
          </Button>
          <Button onClick={generatePreview} disabled={isLoading}>
            <FileJson className="w-4 h-4 mr-2" />
            Generate Preview
          </Button>
        </div>
      </div>

      <Tabs defaultValue="export" className="space-y-4">
        <TabsList>
          <TabsTrigger value="export">Export Configuration</TabsTrigger>
          <TabsTrigger value="preview">Export Preview</TabsTrigger>
          <TabsTrigger value="import">Import Schema</TabsTrigger>
        </TabsList>

        <TabsContent value="export">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Export Options
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    { key: 'includeForms', label: 'Forms' },
                    { key: 'includeTables', label: 'Tables' },
                    { key: 'includeComponents', label: 'Components' },
                    { key: 'includeWorkflows', label: 'Workflows' },
                    { key: 'includeAPIEndpoints', label: 'API Endpoints' },
                    { key: 'includeRelationships', label: 'Relationships' },
                    { key: 'includeThemes', label: 'Themes' },
                    { key: 'includeAuditLogs', label: 'Audit Logs' }
                  ].map(option => (
                    <div key={option.key} className="flex items-center space-x-2">
                      <Switch
                        checked={exportOptions[option.key as keyof ExportOptions] as boolean}
                        onCheckedChange={(checked) => 
                          setExportOptions(prev => ({ ...prev, [option.key]: checked }))
                        }
                      />
                      <Label>{option.label}</Label>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label>Export Format</Label>
                  <Select
                    value={exportOptions.format}
                    onValueChange={(value) => setExportOptions(prev => ({ ...prev, format: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="sql">SQL</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    checked={exportOptions.includeData}
                    onCheckedChange={(checked) => 
                      setExportOptions(prev => ({ ...prev, includeData: checked }))
                    }
                  />
                  <Label>Include Data (not just schema)</Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Export Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={downloadExport} 
                  disabled={isLoading}
                  className="w-full"
                >
                  <Download className="w-4 h-4 mr-2" />
                  {isLoading ? 'Exporting...' : `Download ${exportOptions.format.toUpperCase()}`}
                </Button>

                {exportPreview && (
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Export Summary:</div>
                    {getExportSummary()?.map(item => (
                      <div key={item.label} className="flex justify-between text-sm">
                        <span>{item.label}:</span>
                        <Badge variant="outline">{item.count}</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>Export Preview</CardTitle>
            </CardHeader>
            <CardContent>
              {exportPreview ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { label: 'Forms', count: exportPreview.forms.length, icon: Database },
                      { label: 'Tables', count: exportPreview.tables.length, icon: Database },
                      { label: 'Components', count: exportPreview.components.length, icon: Code },
                      { label: 'Workflows', count: exportPreview.workflows.length, icon: Settings }
                    ].map(item => (
                      <Card key={item.label}>
                        <CardContent className="p-4 text-center">
                          <item.icon className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
                          <div className="text-2xl font-bold">{item.count}</div>
                          <div className="text-sm text-muted-foreground">{item.label}</div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      {JSON.stringify(exportPreview, null, 2).slice(0, 1000)}
                      {JSON.stringify(exportPreview, null, 2).length > 1000 && '...'}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  Click "Generate Preview" to see export data
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import">
          <Card>
            <CardHeader>
              <CardTitle>Import Schema</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Schema JSON Data</Label>
                <Textarea
                  value={importData}
                  onChange={(e) => setImportData(e.target.value)}
                  placeholder="Paste your exported schema JSON here..."
                  rows={15}
                  className="font-mono text-sm"
                />
              </div>
              
              <Button 
                onClick={importSchema} 
                disabled={isLoading || !importData.trim()}
                className="w-full"
              >
                {isLoading ? 'Importing...' : 'Import Schema'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}