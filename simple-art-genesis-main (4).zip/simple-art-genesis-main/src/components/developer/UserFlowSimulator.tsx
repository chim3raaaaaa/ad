import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useUser } from '@/contexts/UserContext';
import { useDeveloperMode } from '@/hooks/useDeveloperMode';
import { developerStateService } from '@/services/database/developerStateService';
import { Users, Eye, Lock, Unlock, ArrowRight, Settings } from 'lucide-react';
import { toast } from 'sonner';

interface UserRole {
  id: string;
  name: string;
  description: string;
  permissions: string[];
}

interface SimulationResult {
  page: string;
  accessible: boolean;
  reason?: string;
  features: {
    name: string;
    accessible: boolean;
    reason?: string;
  }[];
}

export const UserFlowSimulator: React.FC = () => {
  const { user } = useUser();
  const { setRolePreview, originalRole, isRolePreview } = useDeveloperMode();
  const [selectedRole, setSelectedRole] = useState<string>('');
  const [simulationResults, setSimulationResults] = useState<SimulationResult[]>([]);
  const [isSimulating, setIsSimulating] = useState(false);

  const userRoles: UserRole[] = [
    {
      id: 'admin',
      name: 'Admin',
      description: 'Full system access',
      permissions: ['*']
    },
    {
      id: 'lab_admin',
      name: 'Lab Admin',
      description: 'Lab management and configuration',
      permissions: ['lab_management', 'user_management', 'test_configuration', 'reports', 'analytics']
    },
    {
      id: 'manager',
      name: 'Manager',
      description: 'Oversight and reporting',
      permissions: ['reports', 'analytics', 'memo_approval', 'user_view']
    },
    {
      id: 'lab_technician',
      name: 'Lab Technician',
      description: 'Test execution and data entry',
      permissions: ['test_entry', 'memo_create', 'data_view']
    },
    {
      id: 'plant_officer',
      name: 'Plant Officer',
      description: 'Plant operations and memo creation',
      permissions: ['memo_create', 'memo_track', 'production_view']
    }
  ];

  const pages = [
    { name: 'Dashboard', path: '/dashboard', requiredPermissions: [] },
    { name: 'Test Modules', path: '/test-modules', requiredPermissions: ['test_entry'] },
    { name: 'Test Calendar', path: '/test-calendar', requiredPermissions: ['test_entry', 'lab_management'] },
    { name: 'Analytics', path: '/analytics', requiredPermissions: ['analytics'] },
    { name: 'Reports', path: '/reports', requiredPermissions: ['reports'] },
    { name: 'Users', path: '/users', requiredPermissions: ['user_management'] },
    { name: 'Settings', path: '/settings', requiredPermissions: ['lab_management'] },
    { name: 'Developer', path: '/developer', requiredPermissions: ['*'] },
    { name: 'Reference Data', path: '/reference-data', requiredPermissions: ['test_configuration', 'lab_management'] },
    { name: 'Test Data Explorer', path: '/test-data-explorer', requiredPermissions: ['data_view', 'analytics'] }
  ];

  const pageFeatures = {
    '/dashboard': [
      { name: 'Overview Widgets', permissions: [] },
      { name: 'KPI Metrics', permissions: ['analytics'] },
      { name: 'Recent Tests', permissions: ['test_entry'] },
      { name: 'System Notifications', permissions: [] }
    ],
    '/test-modules': [
      { name: 'Create Test Entry', permissions: ['test_entry'] },
      { name: 'View Test History', permissions: ['data_view'] },
      { name: 'Test Configuration', permissions: ['test_configuration'] },
      { name: 'Validation Rules', permissions: ['lab_management'] }
    ],
    '/analytics': [
      { name: 'Charts & Graphs', permissions: ['analytics'] },
      { name: 'Trend Analysis', permissions: ['analytics'] },
      { name: 'Export Data', permissions: ['reports'] },
      { name: 'Advanced Filters', permissions: ['analytics'] }
    ],
    '/users': [
      { name: 'View Users', permissions: ['user_management'] },
      { name: 'Create Users', permissions: ['user_management'] },
      { name: 'Edit Roles', permissions: ['user_management'] },
      { name: 'Password Management', permissions: ['user_management'] }
    ],
    '/developer': [
      { name: 'Form Builder', permissions: ['*'] },
      { name: 'Component Builder', permissions: ['*'] },
      { name: 'SQLite Console', permissions: ['*'] },
      { name: 'Audit Trail', permissions: ['*'] }
    ]
  };

  const simulateUserFlow = async () => {
    if (!selectedRole) return;

    setIsSimulating(true);
    
    try {
      // Log the simulation action
      await developerStateService.logAction(
        user?.id || 'unknown',
        'user-flow-simulator',
        'simulate_role',
        `Simulating role: ${selectedRole}`
      );

      const role = userRoles.find(r => r.id === selectedRole);
      if (!role) return;

      const results: SimulationResult[] = [];

      for (const page of pages) {
        const hasAccess = checkPageAccess(role.permissions, page.requiredPermissions);
        const features = (pageFeatures[page.path as keyof typeof pageFeatures] || []).map(feature => ({
          name: feature.name,
          accessible: checkFeatureAccess(role.permissions, feature.permissions),
          reason: !checkFeatureAccess(role.permissions, feature.permissions) ? 
            `Missing permission: ${feature.permissions.join(', ')}` : undefined
        }));

        results.push({
          page: page.name,
          accessible: hasAccess,
          reason: !hasAccess ? `Missing permission: ${page.requiredPermissions.join(', ')}` : undefined,
          features
        });
      }

      setSimulationResults(results);
      toast.success(`Simulation completed for ${role.name}`);
    } catch (error) {
      toast.error('Simulation failed');
      console.error('Simulation error:', error);
    } finally {
      setIsSimulating(false);
    }
  };

  const checkPageAccess = (userPermissions: string[], requiredPermissions: string[]): boolean => {
    if (userPermissions.includes('*')) return true;
    if (requiredPermissions.length === 0) return true;
    return requiredPermissions.some(permission => userPermissions.includes(permission));
  };

  const checkFeatureAccess = (userPermissions: string[], requiredPermissions: string[]): boolean => {
    if (userPermissions.includes('*')) return true;
    if (requiredPermissions.length === 0) return true;
    return requiredPermissions.every(permission => userPermissions.includes(permission));
  };

  const startRolePreview = () => {
    if (selectedRole && !isRolePreview) {
      setRolePreview(true, selectedRole);
      toast.success(`Started role preview as ${userRoles.find(r => r.id === selectedRole)?.name}`);
    }
  };

  const stopRolePreview = () => {
    if (isRolePreview) {
      setRolePreview(false);
      toast.success(`Stopped role preview, returned to ${originalRole}`);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            User Flow Simulator
          </CardTitle>
          <CardDescription>
            Simulate different user roles to test access controls and user experience flows.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Role to Simulate</label>
            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a user role..." />
              </SelectTrigger>
              <SelectContent>
                {userRoles.map(role => (
                  <SelectItem key={role.id} value={role.id}>
                    <div className="flex flex-col">
                      <span className="font-medium">{role.name}</span>
                      <span className="text-xs text-muted-foreground">{role.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedRole && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">
                  {userRoles.find(r => r.id === selectedRole)?.name} Permissions
                </h4>
              </div>
              <div className="flex flex-wrap gap-1">
                {userRoles.find(r => r.id === selectedRole)?.permissions.map(permission => (
                  <Badge key={permission} variant="secondary" className="text-xs">
                    {permission}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Button 
              onClick={simulateUserFlow}
              disabled={!selectedRole || isSimulating}
              className="flex items-center gap-2"
            >
              <Eye className="h-4 w-4" />
              {isSimulating ? 'Simulating...' : 'Run Simulation'}
            </Button>
            
            {selectedRole && !isRolePreview && (
              <Button 
                onClick={startRolePreview}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Settings className="h-4 w-4" />
                Start Live Preview
              </Button>
            )}
            
            {isRolePreview && (
              <Button 
                onClick={stopRolePreview}
                variant="destructive"
                className="flex items-center gap-2"
              >
                <ArrowRight className="h-4 w-4" />
                Stop Preview
              </Button>
            )}
          </div>

          {isRolePreview && (
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <div className="flex items-center gap-2 text-primary">
                <Eye className="h-4 w-4" />
                <span className="font-medium">
                  Live Preview Active: {userRoles.find(r => r.id === selectedRole)?.name}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                You are now viewing the application as this role. Navigation and features will reflect their permissions.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Simulation Results */}
      {simulationResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Simulation Results</CardTitle>
            <CardDescription>
              Access overview for {userRoles.find(r => r.id === selectedRole)?.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {simulationResults.map((result, index) => (
                  <div key={index} className="border rounded p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium flex items-center gap-2">
                        {result.accessible ? (
                          <Unlock className="h-4 w-4 text-green-500" />
                        ) : (
                          <Lock className="h-4 w-4 text-destructive" />
                        )}
                        {result.page}
                      </h4>
                      <Badge variant={result.accessible ? 'default' : 'destructive'}>
                        {result.accessible ? 'Accessible' : 'Restricted'}
                      </Badge>
                    </div>

                    {result.reason && (
                      <p className="text-sm text-destructive mb-3">
                        {result.reason}
                      </p>
                    )}

                    {result.features.length > 0 && (
                      <div className="space-y-2">
                        <h5 className="text-sm font-medium">Features</h5>
                        <div className="grid grid-cols-2 gap-2">
                          {result.features.map((feature, featureIndex) => (
                            <div 
                              key={featureIndex}
                              className={`flex items-center justify-between p-2 rounded text-sm ${
                                feature.accessible 
                                  ? 'bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300' 
                                  : 'bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                              }`}
                            >
                              <span className="flex items-center gap-1">
                                {feature.accessible ? (
                                  <Unlock className="h-3 w-3" />
                                ) : (
                                  <Lock className="h-3 w-3" />
                                )}
                                {feature.name}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
};