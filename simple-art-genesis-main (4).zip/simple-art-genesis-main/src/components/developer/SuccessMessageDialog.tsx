import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Database, MapPin, ExternalLink } from 'lucide-react';
import { type SuccessMessage } from '@/types/developer';
import { useNavigate } from 'react-router-dom';

interface SuccessMessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  message: SuccessMessage | null;
}

export function SuccessMessageDialog({ open, onOpenChange, message }: SuccessMessageDialogProps) {
  const navigate = useNavigate();

  if (!message) return null;

  const handleGoToModule = () => {
    if (message.action_button?.route) {
      navigate(message.action_button.route);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            {message.title}
          </DialogTitle>
          <DialogDescription>
            {message.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-lg border bg-muted/50 p-3">
            <div className="flex items-center gap-2 text-sm font-medium mb-2">
              <Database className="h-4 w-4" />
              Saved Location
            </div>
            <p className="text-sm text-muted-foreground">
              {message.saved_location}
            </p>
          </div>

          {message.view_location && (
            <div className="rounded-lg border bg-muted/50 p-3">
              <div className="flex items-center gap-2 text-sm font-medium mb-2">
                <MapPin className="h-4 w-4" />
                Display Location
              </div>
              <Badge variant="secondary" className="text-xs">
                {message.view_location}
              </Badge>
            </div>
          )}
        </div>

        <DialogFooter className="flex justify-between">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Continue Building
          </Button>
          {message.action_button && (
            <Button onClick={handleGoToModule} className="flex items-center gap-2">
              <ExternalLink className="h-4 w-4" />
              {message.action_button.label}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}