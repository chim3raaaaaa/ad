import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  X, 
  Minimize2, 
  Maximize2, 
  Move,
  Code, 
  Database, 
  Layout, 
  Settings, 
  Eye,
  FileJson,
  Bug
} from "lucide-react";
import { FormBuilder } from "@/components/lab/FormBuilder";

import { WorkflowBuilder } from "@/components/lab/WorkflowBuilder";
import { FieldInspector } from "@/components/lab/FieldInspector";
import { JSONExporter } from "./JSONExporter";
import { DebugOverlay } from "./DebugOverlay";
import { RolePreviewMode } from "./RolePreviewMode";
import { ElectronDataManager } from "@/components/lab/ElectronDataManager";
import { useDeveloperMode } from "@/hooks/useDeveloperMode";

interface Position {
  x: number;
  y: number;
}

interface Size {
  width: number;
  height: number;
}

export function FloatingDeveloperPanel() {
  const { showFloatingPanel, setShowFloatingPanel, debugMode, toggleDebugMode } = useDeveloperMode();
  const [position, setPosition] = useState<Position>({ x: 100, y: 100 });
  const [size, setSize] = useState<Size>({ width: 800, height: 600 });
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragStart, setDragStart] = useState<Position>({ x: 0, y: 0 });
  const panelRef = useRef<HTMLDivElement>(null);

  if (!showFloatingPanel) return null;

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget || (e.target as HTMLElement).closest('.drag-handle')) {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - position.x,
        y: e.clientY - position.y
      });
    }
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  // Add event listeners for mouse move and up
  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, dragStart]);

  const handleClose = () => {
    setShowFloatingPanel(false);
  };

  const handleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const panelStyle: React.CSSProperties = {
    position: 'fixed',
    left: position.x,
    top: position.y,
    width: isMinimized ? 300 : size.width,
    height: isMinimized ? 60 : size.height,
    zIndex: 9999,
    cursor: isDragging ? 'grabbing' : 'default',
    userSelect: isDragging ? 'none' : 'auto'
  };

  return (
    <>
      {debugMode && <DebugOverlay />}
      
      <Card 
        ref={panelRef}
        style={panelStyle}
        className="shadow-2xl border-2 border-primary/20 bg-background/95 backdrop-blur-sm"
      >
        {/* Header with drag handle */}
        <CardHeader 
          className="pb-2 cursor-move drag-handle bg-primary/5 rounded-t-lg"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Move className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-sm">Developer Panel</CardTitle>
              <Badge variant="secondary" className="text-xs">
                <Code className="w-3 h-3 mr-1" />
                Dev Mode
              </Badge>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDebugMode}
                className={debugMode ? "bg-red-500/20 text-red-600" : ""}
              >
                <Bug className="w-3 h-3" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleMinimize}>
                {isMinimized ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
              </Button>
              <Button variant="ghost" size="sm" onClick={handleClose}>
                <X className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 h-full overflow-hidden">
            <Tabs defaultValue="preview" className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-6 rounded-none border-b">
                <TabsTrigger value="preview" className="text-xs">
                  <Eye className="w-3 h-3 mr-1" />
                  Preview
                </TabsTrigger>
                <TabsTrigger value="forms" className="text-xs">
                  <Layout className="w-3 h-3 mr-1" />
                  Forms
                </TabsTrigger>
                <TabsTrigger value="inspector" className="text-xs">
                  <Settings className="w-3 h-3 mr-1" />
                  Inspector
                </TabsTrigger>
                <TabsTrigger value="workflows" className="text-xs">
                  <Code className="w-3 h-3 mr-1" />
                  Workflows
                </TabsTrigger>
                <TabsTrigger value="export" className="text-xs">
                  <FileJson className="w-3 h-3 mr-1" />
                  Export
                </TabsTrigger>
                <TabsTrigger value="database" className="text-xs">
                  <Database className="w-3 h-3 mr-1" />
                  Database
                </TabsTrigger>
              </TabsList>

              <div className="flex-1 overflow-auto">
                <TabsContent value="preview" className="h-full m-0 p-4">
                  <RolePreviewMode />
                </TabsContent>

                <TabsContent value="forms" className="h-full m-0 p-4">
                  <FormBuilder />
                </TabsContent>


                <TabsContent value="inspector" className="h-full m-0 p-4">
                  <FieldInspector />
                </TabsContent>

                <TabsContent value="workflows" className="h-full m-0 p-4">
                  <WorkflowBuilder />
                </TabsContent>

                <TabsContent value="export" className="h-full m-0 p-4">
                  <JSONExporter />
                </TabsContent>

                <TabsContent value="database" className="h-full m-0 p-4">
                  <ElectronDataManager />
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        )}

        {/* Resize handle */}
        {!isMinimized && (
          <div
            className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize bg-primary/20 hover:bg-primary/40 transition-colors"
            onMouseDown={(e) => {
              e.preventDefault();
              setIsResizing(true);
              setDragStart({ x: e.clientX - size.width, y: e.clientY - size.height });
            }}
          >
            <div className="absolute bottom-1 right-1 w-2 h-2 border-r border-b border-primary/60"></div>
          </div>
        )}
      </Card>
    </>
  );
}