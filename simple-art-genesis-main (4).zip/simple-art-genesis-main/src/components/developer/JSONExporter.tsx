import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Download, 
  Copy, 
  FileJson, 
  Database, 
  Settings, 
  Layout,
  CheckCircle,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SchemaData {
  tables: any[];
  relationships: any[];
  forms: any[];
  workflows: any[];
  settings: any;
}

export function JSONExporter() {
  const { toast } = useToast();
  const [selectedExportType, setSelectedExportType] = useState<string>('schema');
  const [exportData, setExportData] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Mock data generators
  const generateSchemaData = (): SchemaData => {
    return {
      tables: [
        {
          name: 'memos',
          columns: [
            { name: 'id', type: 'uuid', primary: true },
            { name: 'ref', type: 'string', required: true },
            { name: 'created_at', type: 'timestamp' },
            { name: 'production_data', type: 'json' },
            { name: 'user_id', type: 'uuid', foreign_key: 'user_profiles.id' }
          ]
        },
        {
          name: 'test_requests',
          columns: [
            { name: 'id', type: 'uuid', primary: true },
            { name: 'client_name', type: 'string', required: true },
            { name: 'sample_description', type: 'string' },
            { name: 'test_type', type: 'string', required: true },
            { name: 'priority', type: 'enum', values: ['low', 'medium', 'high', 'urgent'] },
            { name: 'status', type: 'enum', values: ['pending', 'in_progress', 'completed', 'cancelled'] },
            { name: 'assigned_to', type: 'uuid', foreign_key: 'user_profiles.id' },
            { name: 'user_id', type: 'uuid', foreign_key: 'user_profiles.id' }
          ]
        },
        {
          name: 'user_profiles',
          columns: [
            { name: 'id', type: 'uuid', primary: true },
            { name: 'user_id', type: 'uuid', unique: true },
            { name: 'name', type: 'string', required: true },
            { name: 'email', type: 'string', required: true, unique: true },
            { name: 'role', type: 'enum', values: ['admin', 'lab_manager', 'lab_technician', 'other'] },
            { name: 'department', type: 'string' }
          ]
        }
      ],
      relationships: [
        {
          name: 'test_request_to_user',
          source_table: 'test_requests',
          source_field: 'user_id',
          target_table: 'user_profiles',
          target_field: 'id',
          type: 'many_to_one',
          cascade_delete: false
        },
        {
          name: 'memo_to_user',
          source_table: 'memos',
          source_field: 'user_id',
          target_table: 'user_profiles',
          target_field: 'id',
          type: 'many_to_one',
          cascade_delete: false
        }
      ],
      forms: [
        {
          id: 'test_request_form',
          name: 'Test Request Form',
          fields: [
            { name: 'client_name', type: 'text', required: true, label: 'Client Name' },
            { name: 'sample_description', type: 'textarea', label: 'Sample Description' },
            { name: 'test_type', type: 'select', required: true, options: ['Concrete', 'Steel', 'Soil'] },
            { name: 'priority', type: 'select', options: ['Low', 'Medium', 'High', 'Urgent'] }
          ],
          validation_rules: [
            { field: 'client_name', rule: 'min_length', value: 2 },
            { field: 'sample_description', rule: 'max_length', value: 500 }
          ]
        }
      ],
      workflows: [
        {
          id: 'test_approval_workflow',
          name: 'Test Approval Workflow',
          steps: [
            { id: 'submit', name: 'Submit Request', type: 'form_submission' },
            { id: 'review', name: 'Manager Review', type: 'approval', role: 'lab_manager' },
            { id: 'test', name: 'Conduct Test', type: 'manual', role: 'lab_technician' },
            { id: 'complete', name: 'Mark Complete', type: 'status_change' }
          ],
          transitions: [
            { from: 'submit', to: 'review', condition: 'auto' },
            { from: 'review', to: 'test', condition: 'approved' },
            { from: 'test', to: 'complete', condition: 'manual' }
          ]
        }
      ],
      settings: {
        app_name: 'UBP Mauritius Lab',
        version: '1.0.0',
        database_version: '1',
        features: {
          developer_mode: true,
          audit_logging: true,
          role_based_access: true
        },
        permissions: {
          admin: ['system.full_access', 'system.developer_mode'],
          lab_manager: ['users.view', 'tests.approve'],
          lab_technician: ['tests.view', 'tests.create'],
          other: ['reports.view']
        }
      }
    };
  };

  const generateFormData = () => {
    return {
      forms: [
        {
          id: 'quality_control_form',
          name: 'Quality Control Inspection',
          description: 'Standard quality control inspection form',
          fields: [
            {
              id: 'inspector_name',
              type: 'text',
              label: 'Inspector Name',
              required: true,
              validation: { min_length: 2 }
            },
            {
              id: 'inspection_date',
              type: 'date',
              label: 'Inspection Date',
              required: true,
              default_value: 'today'
            },
            {
              id: 'sample_batch',
              type: 'text',
              label: 'Sample Batch Number',
              required: true,
              pattern: '^[A-Z]{2}[0-9]{4}$'
            },
            {
              id: 'test_results',
              type: 'number',
              label: 'Test Results (MPa)',
              required: true,
              validation: { min: 0, max: 100 }
            },
            {
              id: 'pass_fail',
              type: 'select',
              label: 'Result',
              options: ['Pass', 'Fail', 'Retest Required'],
              required: true
            },
            {
              id: 'comments',
              type: 'textarea',
              label: 'Additional Comments',
              validation: { max_length: 500 }
            }
          ],
          layout: {
            columns: 2,
            sections: [
              {
                title: 'Inspector Information',
                fields: ['inspector_name', 'inspection_date']
              },
              {
                title: 'Sample Information',
                fields: ['sample_batch', 'test_results', 'pass_fail']
              },
              {
                title: 'Additional Information',
                fields: ['comments']
              }
            ]
          }
        }
      ]
    };
  };

  const generateUserData = () => {
    return {
      users: [
        {
          id: '1',
          username: 'admin',
          email: 'admin@ubp-lab.mu',
          role: 'admin',
          fullName: 'Lab Administrator',
          department: 'Administration',
          permissions: ['system.full_access', 'system.developer_mode'],
          created_at: '2024-01-01T00:00:00Z'
        },
        {
          id: '2',
          username: 'manager',
          email: 'manager@ubp-lab.mu',
          role: 'lab_manager',
          fullName: 'Lab Manager',
          department: 'Quality Control',
          permissions: ['users.view', 'tests.approve', 'memos.create'],
          created_at: '2024-01-01T00:00:00Z'
        }
      ],
      roles: [
        {
          id: 'admin',
          name: 'Administrator',
          description: 'Full system access',
          permissions: ['system.full_access', 'system.developer_mode'],
          user_count: 1
        },
        {
          id: 'lab_manager',
          name: 'Lab Manager',
          description: 'Manage laboratory operations',
          permissions: ['users.view', 'tests.approve', 'memos.create'],
          user_count: 1
        }
      ]
    };
  };

  const generateExportData = async (type: string) => {
    setIsGenerating(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    let data: any;
    
    switch (type) {
      case 'schema':
        data = generateSchemaData();
        break;
      case 'forms':
        data = generateFormData();
        break;
      case 'users':
        data = generateUserData();
        break;
      case 'all':
        data = {
          ...generateSchemaData(),
          ...generateFormData(),
          ...generateUserData(),
          exported_at: new Date().toISOString(),
          export_version: '1.0'
        };
        break;
      default:
        data = { error: 'Unknown export type' };
    }
    
    setExportData(JSON.stringify(data, null, 2));
    setIsGenerating(false);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(exportData);
      toast({
        title: "Copied to Clipboard",
        description: "JSON data has been copied to your clipboard"
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard",
        variant: "destructive"
      });
    }
  };

  const downloadJSON = () => {
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `lab_export_${selectedExportType}_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Started",
      description: `${selectedExportType} data exported successfully`
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <FileJson className="w-4 h-4" />
            JSON Data Exporter
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Export Type:</label>
              <Select value={selectedExportType} onValueChange={setSelectedExportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="schema">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4" />
                      Database Schema
                    </div>
                  </SelectItem>
                  <SelectItem value="forms">
                    <div className="flex items-center gap-2">
                      <Layout className="w-4 h-4" />
                      Forms & Fields
                    </div>
                  </SelectItem>
                  <SelectItem value="users">
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      Users & Roles
                    </div>
                  </SelectItem>
                  <SelectItem value="all">
                    <div className="flex items-center gap-2">
                      <FileJson className="w-4 h-4" />
                      Complete Export
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button 
                onClick={() => generateExportData(selectedExportType)}
                disabled={isGenerating}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <FileJson className="w-4 h-4 mr-2" />
                    Generate Export
                  </>
                )}
              </Button>
            </div>
          </div>

          {exportData && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Generated
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {exportData.split('\n').length} lines, {(exportData.length / 1024).toFixed(1)} KB
                  </span>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copyToClipboard}>
                    <Copy className="w-3 h-3 mr-1" />
                    Copy
                  </Button>
                  <Button size="sm" onClick={downloadJSON}>
                    <Download className="w-3 h-3 mr-1" />
                    Download
                  </Button>
                </div>
              </div>

              <ScrollArea className="h-64 w-full rounded border">
                <Textarea
                  value={exportData}
                  readOnly
                  className="min-h-full resize-none border-0 font-mono text-xs"
                  placeholder="Generated JSON will appear here..."
                />
              </ScrollArea>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Export Templates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Export Templates</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="schema">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="schema">Schema</TabsTrigger>
              <TabsTrigger value="forms">Forms</TabsTrigger>
              <TabsTrigger value="config">Config</TabsTrigger>
            </TabsList>
            
            <TabsContent value="schema" className="space-y-2">
              <div className="text-xs text-muted-foreground">
                <strong>Database Schema Export includes:</strong>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>Table definitions with columns and types</li>
                  <li>Relationships and foreign keys</li>
                  <li>Indexes and constraints</li>
                  <li>Data validation rules</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="forms" className="space-y-2">
              <div className="text-xs text-muted-foreground">
                <strong>Forms Export includes:</strong>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>Form definitions and field configurations</li>
                  <li>Validation rules and constraints</li>
                  <li>Layout and styling information</li>
                  <li>Workflow integrations</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="config" className="space-y-2">
              <div className="text-xs text-muted-foreground">
                <strong>Configuration Export includes:</strong>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>User roles and permissions</li>
                  <li>System settings and preferences</li>
                  <li>Integration configurations</li>
                  <li>Custom field definitions</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}