import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Trash2, Link, Database, ArrowRight, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TableRelationship {
  id: string;
  name: string;
  description?: string;
  source_table: string;
  source_column: string;
  target_table: string;
  target_column: string;
  relationship_type: 'one_to_one' | 'one_to_many' | 'many_to_one' | 'many_to_many';
  cascade_delete: boolean;
  enforce_referential_integrity: boolean;
  created_at: string;
  created_by: string;
}

interface TableInfo {
  id: string;
  name: string;
  columns: Array<{
    id: string;
    name: string;
    type: string;
  }>;
}

interface DataRelationshipManagerProps {
  onRelationshipChange?: (relationships: TableRelationship[]) => void;
}

export function DataRelationshipManager({ onRelationshipChange }: DataRelationshipManagerProps) {
  const { toast } = useToast();
  const [relationships, setRelationships] = useState<TableRelationship[]>([]);
  const [availableTables, setAvailableTables] = useState<TableInfo[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const [newRelationship, setNewRelationship] = useState({
    name: '',
    description: '',
    source_table: '',
    source_column: '',
    target_table: '',
    target_column: '',
    relationship_type: 'one_to_many' as const,
    cascade_delete: false,
    enforce_referential_integrity: true
  });

  useEffect(() => {
    loadRelationships();
    loadAvailableTables();
  }, []);

  const isElectron = () => typeof window !== 'undefined' && window.electronAPI !== undefined;

  const executeQuery = async <T,>(sql: string, params: any[] = []): Promise<T[]> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await (window as any).electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  };

  const executeRun = async (sql: string, params: any[] = []): Promise<any> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await (window as any).electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  };

  const initializeRelationshipsTable = async () => {
    try {
      const createTableSQL = `
        CREATE TABLE IF NOT EXISTS data_relationships (
          id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
          name TEXT NOT NULL,
          description TEXT,
          source_table TEXT NOT NULL,
          source_column TEXT NOT NULL,
          target_table TEXT NOT NULL,
          target_column TEXT NOT NULL,
          relationship_type TEXT CHECK(relationship_type IN ('one_to_one', 'one_to_many', 'many_to_one', 'many_to_many')) NOT NULL,
          cascade_delete BOOLEAN DEFAULT FALSE,
          enforce_referential_integrity BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          created_by TEXT DEFAULT 'current_user'
        )
      `;
      
      await executeRun(createTableSQL);
    } catch (error) {
      console.error('Error initializing relationships table:', error);
    }
  };

  const loadRelationships = async () => {
    try {
      setIsLoading(true);
      await initializeRelationshipsTable();
      
      const relationshipData = await executeQuery<any>('SELECT * FROM data_relationships ORDER BY created_at DESC');
      
      const loadedRelationships: TableRelationship[] = relationshipData.map(rel => ({
        id: rel.id,
        name: rel.name,
        description: rel.description,
        source_table: rel.source_table,
        source_column: rel.source_column,
        target_table: rel.target_table,
        target_column: rel.target_column,
        relationship_type: rel.relationship_type,
        cascade_delete: rel.cascade_delete,
        enforce_referential_integrity: rel.enforce_referential_integrity,
        created_at: rel.created_at,
        created_by: rel.created_by
      }));
      
      setRelationships(loadedRelationships);
      
      if (onRelationshipChange) {
        onRelationshipChange(loadedRelationships);
      }
    } catch (error) {
      console.error('Error loading relationships:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadAvailableTables = async () => {
    try {
      // Load custom tables from table definitions
      const customTables = await executeQuery<any>('SELECT * FROM table_definitions');
      
      // Also check for existing tables in the database
      const existingTables = await executeQuery<any>(`
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name NOT LIKE 'sqlite_%'
        AND name NOT LIKE '%_definitions' AND name NOT LIKE '%_logs'
        ORDER BY name
      `);
      
      const tableInfos: TableInfo[] = [];
      
      // Process custom tables
      for (const table of customTables) {
        const columns = JSON.parse(table.columns || '[]');
        tableInfos.push({
          id: table.id,
          name: table.name,
          columns: columns.map((col: any) => ({
            id: col.id,
            name: col.name,
            type: col.type
          }))
        });
      }
      
      // Process existing SQLite tables
      for (const table of existingTables) {
        const tableInfo = await executeQuery<any>(`PRAGMA table_info(${table.name})`);
        
        tableInfos.push({
          id: table.name,
          name: table.name,
          columns: tableInfo.map((col: any) => ({
            id: col.name,
            name: col.name,
            type: col.type
          }))
        });
      }
      
      setAvailableTables(tableInfos);
    } catch (error) {
      console.error('Error loading available tables:', error);
    }
  };

  const createRelationship = async () => {
    try {
      if (!newRelationship.name.trim()) {
        toast({
          title: "Validation Error",
          description: "Relationship name is required",
          variant: "destructive"
        });
        return;
      }

      if (!newRelationship.source_table || !newRelationship.target_table) {
        toast({
          title: "Validation Error",
          description: "Source and target tables are required",
          variant: "destructive"
        });
        return;
      }

      const relationshipId = crypto.randomUUID();
      const now = new Date().toISOString();

      await executeRun(
        `INSERT INTO data_relationships (id, name, description, source_table, source_column, target_table, target_column, relationship_type, cascade_delete, enforce_referential_integrity, created_at, updated_at, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          relationshipId,
          newRelationship.name,
          newRelationship.description,
          newRelationship.source_table,
          newRelationship.source_column,
          newRelationship.target_table,
          newRelationship.target_column,
          newRelationship.relationship_type,
          newRelationship.cascade_delete,
          newRelationship.enforce_referential_integrity,
          now,
          now,
          'current_user'
        ]
      );

      // Create actual foreign key constraint if enforcement is enabled
      if (newRelationship.enforce_referential_integrity) {
        await createForeignKeyConstraint(newRelationship);
      }

      // Log audit event
      await executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, new_data, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          'current_user',
          'create_relationship',
          'table_relationship',
          relationshipId,
          JSON.stringify(newRelationship),
          now
        ]
      );

      await loadRelationships();
      setShowCreateDialog(false);
      setNewRelationship({
        name: '',
        description: '',
        source_table: '',
        source_column: '',
        target_table: '',
        target_column: '',
        relationship_type: 'one_to_many',
        cascade_delete: false,
        enforce_referential_integrity: true
      });

      toast({
        title: "Success",
        description: "Relationship created successfully"
      });

    } catch (error) {
      console.error('Error creating relationship:', error);
      toast({
        title: "Error",
        description: `Failed to create relationship: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const createForeignKeyConstraint = async (relationship: typeof newRelationship) => {
    try {
      // Note: SQLite has limited ALTER TABLE support for foreign keys
      // In a production system, you might need to recreate tables with proper constraints
      // For now, we'll create a virtual constraint that can be enforced in application logic
      
      console.log('Creating virtual foreign key constraint:', {
        source: `${relationship.source_table}.${relationship.source_column}`,
        target: `${relationship.target_table}.${relationship.target_column}`,
        type: relationship.relationship_type,
        cascade: relationship.cascade_delete
      });

      // Store constraint metadata for application-level enforcement
      const constraintId = crypto.randomUUID();
      await executeRun(
        `INSERT OR IGNORE INTO sqlite_master_constraints (
          id, constraint_type, source_table, source_column, target_table, target_column, 
          cascade_delete, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          constraintId,
          'foreign_key',
          relationship.source_table,
          relationship.source_column,
          relationship.target_table,
          relationship.target_column,
          relationship.cascade_delete,
          new Date().toISOString()
        ]
      ).catch(() => {
        // Table might not exist, create it
        return executeRun(`
          CREATE TABLE IF NOT EXISTS sqlite_master_constraints (
            id TEXT PRIMARY KEY,
            constraint_type TEXT NOT NULL,
            source_table TEXT NOT NULL,
            source_column TEXT NOT NULL,
            target_table TEXT NOT NULL,
            target_column TEXT NOT NULL,
            cascade_delete BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `).then(() => executeRun(
          `INSERT INTO sqlite_master_constraints (
            id, constraint_type, source_table, source_column, target_table, target_column, 
            cascade_delete, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            constraintId,
            'foreign_key',
            relationship.source_table,
            relationship.source_column,
            relationship.target_table,
            relationship.target_column,
            relationship.cascade_delete,
            new Date().toISOString()
          ]
        ));
      });

    } catch (error) {
      console.error('Error creating foreign key constraint:', error);
      // Don't throw - this is a nice-to-have feature
    }
  };

  const deleteRelationship = async (relationshipId: string) => {
    if (!confirm('Are you sure you want to delete this relationship?')) return;

    try {
      const relationship = relationships.find(r => r.id === relationshipId);
      if (!relationship) return;

      await executeRun('DELETE FROM data_relationships WHERE id = ?', [relationshipId]);

      // Remove virtual constraint if it exists
      await executeRun(
        'DELETE FROM sqlite_master_constraints WHERE source_table = ? AND source_column = ? AND target_table = ? AND target_column = ?',
        [relationship.source_table, relationship.source_column, relationship.target_table, relationship.target_column]
      ).catch(() => {
        // Table might not exist, ignore error
      });

      // Log audit event
      await executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, old_data, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          'current_user',
          'delete_relationship',
          'table_relationship',
          relationshipId,
          JSON.stringify(relationship),
          new Date().toISOString()
        ]
      );

      await loadRelationships();

      toast({
        title: "Success",
        description: "Relationship deleted successfully"
      });

    } catch (error) {
      console.error('Error deleting relationship:', error);
      toast({
        title: "Error",
        description: "Failed to delete relationship",
        variant: "destructive"
      });
    }
  };

  const validateRelationship = async (sourceTable: string, sourceColumn: string, targetTable: string, targetColumn: string): Promise<{ isValid: boolean; errors: string[] }> => {
    const errors: string[] = [];

    try {
      // Check if tables exist
      const sourceTableExists = availableTables.some(t => t.name === sourceTable);
      const targetTableExists = availableTables.some(t => t.name === targetTable);

      if (!sourceTableExists) {
        errors.push(`Source table "${sourceTable}" does not exist`);
      }

      if (!targetTableExists) {
        errors.push(`Target table "${targetTable}" does not exist`);
      }

      // Check if columns exist
      const sourceTableInfo = availableTables.find(t => t.name === sourceTable);
      const targetTableInfo = availableTables.find(t => t.name === targetTable);

      if (sourceTableInfo && !sourceTableInfo.columns.some(c => c.name === sourceColumn)) {
        errors.push(`Source column "${sourceColumn}" does not exist in table "${sourceTable}"`);
      }

      if (targetTableInfo && !targetTableInfo.columns.some(c => c.name === targetColumn)) {
        errors.push(`Target column "${targetColumn}" does not exist in table "${targetTable}"`);
      }

      // Check for duplicate relationships
      const duplicate = relationships.find(r => 
        r.source_table === sourceTable && 
        r.source_column === sourceColumn && 
        r.target_table === targetTable && 
        r.target_column === targetColumn
      );

      if (duplicate) {
        errors.push('A relationship already exists between these tables and columns');
      }

    } catch (error) {
      errors.push('Failed to validate relationship');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  };

  const getRelationshipTypeIcon = (type: string) => {
    switch (type) {
      case 'one_to_one': return '1:1';
      case 'one_to_many': return '1:N';
      case 'many_to_one': return 'N:1';
      case 'many_to_many': return 'N:N';
      default: return '?';
    }
  };

  const getTableColumns = (tableName: string) => {
    const table = availableTables.find(t => t.name === tableName);
    return table ? table.columns : [];
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading data relationships...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Data Relationship Manager</h3>
          <p className="text-sm text-muted-foreground">Create and manage table relationships with foreign key constraints</p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Relationship
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Data Relationship</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Relationship Name</Label>
                  <Input
                    value={newRelationship.name}
                    onChange={(e) => setNewRelationship(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter relationship name"
                  />
                </div>
                <div>
                  <Label>Relationship Type</Label>
                  <Select
                    value={newRelationship.relationship_type}
                    onValueChange={(value) => setNewRelationship(prev => ({ ...prev, relationship_type: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="one_to_one">One to One (1:1)</SelectItem>
                      <SelectItem value="one_to_many">One to Many (1:N)</SelectItem>
                      <SelectItem value="many_to_one">Many to One (N:1)</SelectItem>
                      <SelectItem value="many_to_many">Many to Many (N:N)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Description</Label>
                <Input
                  value={newRelationship.description}
                  onChange={(e) => setNewRelationship(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Optional description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Source Table</Label>
                  <Select
                    value={newRelationship.source_table}
                    onValueChange={(value) => setNewRelationship(prev => ({ ...prev, source_table: value, source_column: '' }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source table" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTables.map(table => (
                        <SelectItem key={table.id} value={table.name}>
                          {table.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Source Column</Label>
                  <Select
                    value={newRelationship.source_column}
                    onValueChange={(value) => setNewRelationship(prev => ({ ...prev, source_column: value }))}
                    disabled={!newRelationship.source_table}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select source column" />
                    </SelectTrigger>
                    <SelectContent>
                      {getTableColumns(newRelationship.source_table).map(column => (
                        <SelectItem key={column.id} value={column.name}>
                          {column.name} ({column.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-center">
                <ArrowRight className="w-6 h-6 text-muted-foreground" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Target Table</Label>
                  <Select
                    value={newRelationship.target_table}
                    onValueChange={(value) => setNewRelationship(prev => ({ ...prev, target_table: value, target_column: '' }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select target table" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTables.map(table => (
                        <SelectItem key={table.id} value={table.name}>
                          {table.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Target Column</Label>
                  <Select
                    value={newRelationship.target_column}
                    onValueChange={(value) => setNewRelationship(prev => ({ ...prev, target_column: value }))}
                    disabled={!newRelationship.target_table}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select target column" />
                    </SelectTrigger>
                    <SelectContent>
                      {getTableColumns(newRelationship.target_table).map(column => (
                        <SelectItem key={column.id} value={column.name}>
                          {column.name} ({column.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={newRelationship.enforce_referential_integrity}
                    onCheckedChange={(checked) => setNewRelationship(prev => ({ ...prev, enforce_referential_integrity: checked }))}
                  />
                  <Label>Enforce Referential Integrity</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={newRelationship.cascade_delete}
                    onCheckedChange={(checked) => setNewRelationship(prev => ({ ...prev, cascade_delete: checked }))}
                  />
                  <Label>Cascade Delete</Label>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={createRelationship}>
                  Create Relationship
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="relationships" className="space-y-4">
        <TabsList>
          <TabsTrigger value="relationships">Relationships ({relationships.length})</TabsTrigger>
          <TabsTrigger value="tables">Available Tables ({availableTables.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="relationships">
          {relationships.length === 0 ? (
            <Card>
              <CardContent className="p-6">
                <div className="text-center text-muted-foreground">
                  No relationships defined yet. Create your first relationship to get started.
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {relationships.map(relationship => (
                <Card key={relationship.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-base">{relationship.name}</CardTitle>
                        {relationship.description && (
                          <p className="text-sm text-muted-foreground">{relationship.description}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {getRelationshipTypeIcon(relationship.relationship_type)}
                        </Badge>
                        {relationship.cascade_delete && (
                          <Badge variant="destructive">Cascade</Badge>
                        )}
                        {relationship.enforce_referential_integrity && (
                          <Badge variant="default">Enforced</Badge>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteRelationship(relationship.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <div className="font-medium">{relationship.source_table}</div>
                          <div className="text-sm text-muted-foreground">{relationship.source_column}</div>
                        </div>
                        <ArrowRight className="w-4 h-4" />
                        <div className="text-center">
                          <div className="font-medium">{relationship.target_table}</div>
                          <div className="text-sm text-muted-foreground">{relationship.target_column}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="tables">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableTables.map(table => (
              <Card key={table.id}>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    {table.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Columns:</div>
                    <div className="space-y-1">
                      {table.columns.map(column => (
                        <div key={column.id} className="flex justify-between text-sm">
                          <span>{column.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {column.type}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}