import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User, UserRole, useUser } from "@/contexts/UserContext";
import { useDeveloperMode } from "@/hooks/useDeveloperMode";
import { Users, Shield, Settings, FlaskConical, Eye, RotateCcw, AlertTriangle } from "lucide-react";

const previewRoles: User[] = [
  {
    id: 'preview_admin',
    username: 'admin_preview',
    email: 'admin@preview.dev',
    role: 'admin',
    fullName: 'Admin (Preview)',
    department: 'Administration'
  },
  {
    id: 'preview_manager',
    username: 'manager_preview',
    email: 'manager@preview.dev',
    role: 'lab_manager',
    fullName: 'Lab Manager (Preview)',
    department: 'Quality Control'
  },
  {
    id: 'preview_tech',
    username: 'tech_preview',
    email: 'tech@preview.dev',
    role: 'lab_technician',
    fullName: 'Lab Technician (Preview)',
    department: 'Testing'
  },
  {
    id: 'preview_other',
    username: 'other_preview',
    email: 'other@preview.dev',
    role: 'other',
    fullName: 'General User (Preview)',
    department: 'Support'
  }
];

const getRoleIcon = (role: UserRole) => {
  switch (role) {
    case 'admin':
      return <Shield className="h-4 w-4" />;
    case 'lab_manager':
      return <Settings className="h-4 w-4" />;
    case 'lab_technician':
      return <FlaskConical className="h-4 w-4" />;
    default:
      return <Users className="h-4 w-4" />;
  }
};

const getRoleColor = (role: UserRole) => {
  switch (role) {
    case 'admin':
      return 'destructive';
    case 'lab_manager':
      return 'default';
    case 'lab_technician':
      return 'secondary';
    default:
      return 'outline';
  }
};

export function RolePreviewMode() {
  const { user, setUser } = useUser();
  const { isRolePreview, originalRole, startRolePreview, exitRolePreview } = useDeveloperMode();

  const handleRolePreview = (selectedRole: string) => {
    const previewUser = previewRoles.find(u => u.role === selectedRole);
    if (previewUser && !isRolePreview) {
      startRolePreview(previewUser.role);
      setUser(previewUser);
    }
  };

  const handleExitPreview = () => {
    if (isRolePreview && originalRole) {
      // Find the original user role and restore it
      const originalUser = previewRoles.find(u => u.role === originalRole);
      if (originalUser) {
        // Create a real user object (not preview)
        const restoredUser: User = {
          ...originalUser,
          id: `real_${originalRole}`,
          username: originalRole,
          email: `${originalRole}@ubp-lab.mu`,
          fullName: originalUser.fullName.replace(' (Preview)', ''),
        };
        setUser(restoredUser);
      }
      exitRolePreview();
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Role Preview Mode
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isRolePreview && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="flex items-center justify-between">
                <span>
                  You are currently previewing as: <strong>{user?.fullName}</strong>
                </span>
                <Button size="sm" variant="outline" onClick={handleExitPreview}>
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Exit Preview
                </Button>
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Current User:</span>
              {user && (
                <>
                  <Badge variant={getRoleColor(user.role)} className="flex items-center gap-1">
                    {getRoleIcon(user.role)}
                    {user.role.replace('_', ' ').toUpperCase()}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {user.fullName}
                  </span>
                  {isRolePreview && (
                    <Badge variant="outline" className="text-xs">
                      PREVIEW MODE
                    </Badge>
                  )}
                </>
              )}
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Preview as Role:</label>
              <Select 
                onValueChange={handleRolePreview}
                disabled={isRolePreview}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a role to preview..." />
                </SelectTrigger>
                <SelectContent>
                  {previewRoles.map((previewUser) => (
                    <SelectItem key={previewUser.id} value={previewUser.role}>
                      <div className="flex items-center gap-2">
                        {getRoleIcon(previewUser.role)}
                        <div>
                          <div className="font-medium">{previewUser.fullName}</div>
                          <div className="text-xs text-muted-foreground">
                            {previewUser.role.replace('_', ' ').toUpperCase()}
                          </div>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="text-xs text-muted-foreground p-3 bg-muted rounded-lg">
            <strong>Role Preview:</strong> Test how the UI appears for different user roles. 
            Changes are temporary and do not affect real user permissions. 
            Use "Exit Preview" to return to your actual role.
          </div>
        </CardContent>
      </Card>

      {/* Current Permissions Display */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Current Role Permissions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {user && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="space-y-1">
                  <div className="font-medium">System Access:</div>
                  <div className="text-muted-foreground">
                    {user.role === 'admin' ? '✅ Full Access' : '❌ Limited Access'}
                  </div>
                  <div className="text-muted-foreground">
                    {['admin', 'lab_manager'].includes(user.role) ? '✅ Advanced Features' : '❌ Basic Features Only'}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="font-medium">Permissions:</div>
                  <div className="text-muted-foreground">
                    {user.role === 'admin' ? '✅ User Management' : '❌ No User Management'}
                  </div>
                  <div className="text-muted-foreground">
                    {['admin', 'lab_manager'].includes(user.role) ? '✅ Test Approval' : '❌ No Test Approval'}
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}