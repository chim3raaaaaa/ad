import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useUser } from '@/contexts/UserContext';
import { developerStateService, DevBuilderTemplate } from '@/services/database/developerStateService';
import { 
  FileText, 
  Save, 
  Upload, 
  Download, 
  Copy, 
  Trash2, 
  Eye, 
  Share,
  Code,
  Layers
} from 'lucide-react';
import { toast } from 'sonner';

interface TemplatePreview {
  template: DevBuilderTemplate;
  isValid: boolean;
  parsedData?: any;
  error?: string;
}

export const TemplateComposer: React.FC = () => {
  const { user } = useUser();
  const [templates, setTemplates] = useState<DevBuilderTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<DevBuilderTemplate | null>(null);
  const [templateName, setTemplateName] = useState('');
  const [templateType, setTemplateType] = useState<'form' | 'component' | 'workflow' | 'api'>('form');
  const [templateData, setTemplateData] = useState('{}');
  const [isShared, setIsShared] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [previewData, setPreviewData] = useState<TemplatePreview | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [showSharedOnly, setShowSharedOnly] = useState(false);

  useEffect(() => {
    loadTemplates();
  }, [filterType, showSharedOnly]);

  const loadTemplates = async () => {
    try {
      const loadedTemplates = await developerStateService.getTemplates(
        filterType === 'all' ? undefined : filterType as any,
        showSharedOnly ? true : undefined
      );
      setTemplates(loadedTemplates);
    } catch (error) {
      console.error('Failed to load templates:', error);
      toast.error('Failed to load templates');
    }
  };

  const validateTemplate = (data: string): TemplatePreview | null => {
    try {
      const parsed = JSON.parse(data);
      return {
        template: selectedTemplate!,
        isValid: true,
        parsedData: parsed
      };
    } catch (error: any) {
      return {
        template: selectedTemplate!,
        isValid: false,
        error: error.message
      };
    }
  };

  const handleSaveTemplate = async () => {
    if (!templateName.trim() || !templateData.trim()) {
      toast.error('Template name and data are required');
      return;
    }

    try {
      const validation = validateTemplate(templateData);
      if (!validation?.isValid) {
        toast.error('Invalid JSON: ' + validation?.error);
        return;
      }

      if (isEditing && selectedTemplate) {
        // Update existing template (would need update method in service)
        toast.info('Template update functionality not yet implemented');
      } else {
        // Create new template
        await developerStateService.saveTemplate({
          name: templateName,
          type: templateType,
          template_data: templateData,
          created_by: user?.id || 'unknown',
          is_shared: isShared
        });

        // Log the action
        await developerStateService.logAction(
          user?.id || 'unknown',
          'template-composer',
          'save_template',
          `Saved template: ${templateName} (${templateType})`
        );

        toast.success('Template saved successfully');
        resetForm();
        loadTemplates();
      }
    } catch (error) {
      console.error('Failed to save template:', error);
      toast.error('Failed to save template');
    }
  };

  const handleLoadTemplate = (template: DevBuilderTemplate) => {
    setSelectedTemplate(template);
    setTemplateName(template.name);
    setTemplateType(template.type);
    setTemplateData(template.template_data);
    setIsShared(template.is_shared);
    setIsEditing(true);

    // Generate preview
    const preview = validateTemplate(template.template_data);
    setPreviewData(preview);
  };

  const handleExportTemplate = (template: DevBuilderTemplate) => {
    try {
      const exportData = {
        name: template.name,
        type: template.type,
        data: JSON.parse(template.template_data),
        metadata: {
          created_at: template.created_at,
          version: '1.0'
        }
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json'
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${template.name.replace(/\s+/g, '_')}_template.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('Template exported');
    } catch (error) {
      toast.error('Failed to export template');
    }
  };

  const handleImportTemplate = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        const importData = JSON.parse(text);
        
        if (importData.name && importData.type && importData.data) {
          setTemplateName(importData.name + ' (Imported)');
          setTemplateType(importData.type);
          setTemplateData(JSON.stringify(importData.data, null, 2));
          setIsShared(false);
          setIsEditing(false);
          setSelectedTemplate(null);
          
          toast.success('Template imported successfully');
        } else {
          toast.error('Invalid template file format');
        }
      } catch (error) {
        toast.error('Failed to import template');
      }
    };
    
    input.click();
  };

  const handleCopyTemplate = (template: DevBuilderTemplate) => {
    setTemplateName(template.name + ' (Copy)');
    setTemplateType(template.type);
    setTemplateData(template.template_data);
    setIsShared(false);
    setIsEditing(false);
    setSelectedTemplate(null);
    
    toast.success('Template copied to editor');
  };

  const resetForm = () => {
    setTemplateName('');
    setTemplateType('form');
    setTemplateData('{}');
    setIsShared(false);
    setIsEditing(false);
    setSelectedTemplate(null);
    setPreviewData(null);
  };

  const getTemplateIcon = (type: string) => {
    switch (type) {
      case 'form': return <FileText className="h-4 w-4" />;
      case 'component': return <Layers className="h-4 w-4" />;
      case 'workflow': return <Code className="h-4 w-4" />;
      case 'api': return <Upload className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const predefinedTemplates = {
    form: {
      title: 'Basic Form Template',
      fields: [
        { name: 'name', type: 'text', label: 'Name', required: true },
        { name: 'email', type: 'email', label: 'Email', required: true },
        { name: 'notes', type: 'textarea', label: 'Notes', required: false }
      ],
      validation: {
        name: { minLength: 2 },
        email: { pattern: '^[^@]+@[^@]+\\.[^@]+$' }
      }
    },
    component: {
      name: 'DataCard',
      props: {
        title: 'string',
        value: 'string | number',
        icon: 'string',
        variant: 'default | success | warning | error'
      },
      template: '<div class="card"><h3>{title}</h3><div class="value">{value}</div></div>'
    },
    workflow: {
      trigger: 'test_completed',
      steps: [
        { type: 'validation', rules: ['required_fields'] },
        { type: 'notification', recipients: ['lab_manager'] },
        { type: 'storage', table: 'test_results' }
      ]
    },
    api: {
      endpoint: '/api/test-results',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body_schema: {
        test_id: 'string',
        results: 'object',
        metadata: 'object'
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Template Composer
          </CardTitle>
          <CardDescription>
            Create, manage, and share reusable templates across forms, components, workflows, and APIs.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Template Editor */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Template Editor</h4>
                <div className="flex gap-2">
                  <Button 
                    onClick={handleImportTemplate}
                    variant="outline" 
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <Upload className="h-3 w-3" />
                    Import
                  </Button>
                  <Button 
                    onClick={resetForm}
                    variant="outline" 
                    size="sm"
                  >
                    Clear
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="template-name">Template Name</Label>
                  <Input
                    id="template-name"
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                    placeholder="Enter template name..."
                  />
                </div>

                <div>
                  <Label htmlFor="template-type">Template Type</Label>
                  <Select value={templateType} onValueChange={(value: any) => setTemplateType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="form">Form</SelectItem>
                      <SelectItem value="component">Component</SelectItem>
                      <SelectItem value="workflow">Workflow</SelectItem>
                      <SelectItem value="api">API</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="shared-template"
                    checked={isShared}
                    onCheckedChange={setIsShared}
                  />
                  <Label htmlFor="shared-template">Share with team</Label>
                </div>

                <div>
                  <Label htmlFor="template-data">Template Data (JSON)</Label>
                  <Textarea
                    id="template-data"
                    value={templateData}
                    onChange={(e) => setTemplateData(e.target.value)}
                    placeholder="Enter template JSON data..."
                    rows={12}
                    className="font-mono text-sm"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={() => setTemplateData(JSON.stringify(predefinedTemplates[templateType], null, 2))}>
                    Load Example
                  </Button>
                  <Button onClick={handleSaveTemplate} className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    {isEditing ? 'Update' : 'Save'} Template
                  </Button>
                </div>
              </div>
            </div>

            {/* Preview Panel */}
            <div className="space-y-4">
              <h4 className="font-medium">Preview & Validation</h4>
              
              {templateData && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">JSON Structure</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-64">
                      {(() => {
                        try {
                          const parsed = JSON.parse(templateData);
                          return (
                            <pre className="text-xs bg-muted p-2 rounded">
                              {JSON.stringify(parsed, null, 2)}
                            </pre>
                          );
                        } catch (error: any) {
                          return (
                            <div className="text-destructive text-sm">
                              <strong>Invalid JSON:</strong> {error.message}
                            </div>
                          );
                        }
                      })()}
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          <Separator />

          {/* Template Library */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Template Library</h4>
              <div className="flex items-center gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="show-shared"
                    checked={showSharedOnly}
                    onCheckedChange={setShowSharedOnly}
                  />
                  <Label htmlFor="show-shared" className="text-sm">Shared only</Label>
                </div>
                
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="form">Forms</SelectItem>
                    <SelectItem value="component">Components</SelectItem>
                    <SelectItem value="workflow">Workflows</SelectItem>
                    <SelectItem value="api">APIs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <ScrollArea className="h-64">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {templates.map((template) => (
                  <Card key={template.id} className="relative">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getTemplateIcon(template.type)}
                          <span className="font-medium text-sm">{template.name}</span>
                        </div>
                        {template.is_shared && (
                          <Badge variant="secondary" className="text-xs">
                            <Share className="h-3 w-3 mr-1" />
                            Shared
                          </Badge>
                        )}
                      </div>
                      <Badge variant="outline" className="w-fit text-xs">
                        {template.type}
                      </Badge>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex gap-1 flex-wrap">
                        <Button
                          onClick={() => handleLoadTemplate(template)}
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-1"
                        >
                          <Eye className="h-3 w-3" />
                          Load
                        </Button>
                        <Button
                          onClick={() => handleCopyTemplate(template)}
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-1"
                        >
                          <Copy className="h-3 w-3" />
                          Copy
                        </Button>
                        <Button
                          onClick={() => handleExportTemplate(template)}
                          size="sm"
                          variant="outline"
                          className="flex items-center gap-1"
                        >
                          <Download className="h-3 w-3" />
                          Export
                        </Button>
                      </div>
                      
                      <div className="text-xs text-muted-foreground mt-2">
                        Created {new Date(template.created_at).toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};