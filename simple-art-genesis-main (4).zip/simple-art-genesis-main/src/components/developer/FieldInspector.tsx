import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Edit, Save, X, Plus, Trash2, Eye, Settings, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FormField {
  id: string;
  type: string;
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
  validation?: any;
}

interface TableColumn {
  id: string;
  name: string;
  type: string;
  nullable: boolean;
  default_value?: any;
  unique?: boolean;
}

interface FormDefinition {
  id: string;
  name: string;
  description?: string;
  fields: FormField[];
  placement: string;
  module_id?: string;
}

interface TableDefinition {
  id: string;
  name: string;
  description?: string;
  columns: TableColumn[];
  placement: string;
  module_id?: string;
}

interface FieldInspectorProps {
  onFieldUpdate?: (fieldId: string, updates: any) => void;
}

export function FieldInspector({ onFieldUpdate }: FieldInspectorProps) {
  const { toast } = useToast();
  const [forms, setForms] = useState<FormDefinition[]>([]);
  const [tables, setTables] = useState<TableDefinition[]>([]);
  const [selectedItem, setSelectedItem] = useState<{ type: 'form' | 'table'; id: string } | null>(null);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadFormDefinitions();
    loadTableDefinitions();
  }, []);

  const isElectron = () => window.electronAPI !== undefined;

  const executeQuery = async <T,>(sql: string, params: any[] = []): Promise<T[]> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  };

  const executeRun = async (sql: string, params: any[] = []): Promise<any> => {
    if (!isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  };

  const loadFormDefinitions = async () => {
    try {
      setIsLoading(true);
      const formData = await executeQuery<any>('SELECT * FROM form_definitions ORDER BY name');
      
      const formDefs: FormDefinition[] = formData.map(form => ({
        id: form.id,
        name: form.name,
        description: form.description,
        fields: JSON.parse(form.fields || '[]'),
        placement: form.placement,
        module_id: form.module_id
      }));
      
      setForms(formDefs);
    } catch (error) {
      console.error('Error loading form definitions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTableDefinitions = async () => {
    try {
      const tableData = await executeQuery<any>('SELECT * FROM table_definitions ORDER BY name');
      
      const tableDefs: TableDefinition[] = tableData.map(table => ({
        id: table.id,
        name: table.name,
        description: table.description,
        columns: JSON.parse(table.columns || '[]'),
        placement: table.placement,
        module_id: table.module_id
      }));
      
      setTables(tableDefs);
    } catch (error) {
      console.error('Error loading table definitions:', error);
    }
  };

  const updateFormField = async (formId: string, fieldId: string, updates: Partial<FormField>) => {
    try {
      const form = forms.find(f => f.id === formId);
      if (!form) return;

      const updatedFields = form.fields.map(field => 
        field.id === fieldId ? { ...field, ...updates } : field
      );

      await executeRun(
        'UPDATE form_definitions SET fields = ?, updated_at = ? WHERE id = ?',
        [JSON.stringify(updatedFields), new Date().toISOString(), formId]
      );

      // Update local state
      setForms(prev => prev.map(f => 
        f.id === formId ? { ...f, fields: updatedFields } : f
      ));

      // Log audit event
      await executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, old_data, new_data, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          'current_user',
          'update_form_field',
          'form_field',
          fieldId,
          JSON.stringify({ formId, fieldId }),
          JSON.stringify(updates),
          new Date().toISOString()
        ]
      );

      toast({
        title: "Success",
        description: "Field updated successfully"
      });

      if (onFieldUpdate) {
        onFieldUpdate(fieldId, updates);
      }

    } catch (error) {
      console.error('Error updating form field:', error);
      toast({
        title: "Error",
        description: "Failed to update field",
        variant: "destructive"
      });
    }
  };

  const updateTableColumn = async (tableId: string, columnId: string, updates: Partial<TableColumn>) => {
    try {
      const table = tables.find(t => t.id === tableId);
      if (!table) return;

      const updatedColumns = table.columns.map(column => 
        column.id === columnId ? { ...column, ...updates } : column
      );

      await executeRun(
        'UPDATE table_definitions SET columns = ?, updated_at = ? WHERE id = ?',
        [JSON.stringify(updatedColumns), new Date().toISOString(), tableId]
      );

      // Update local state
      setTables(prev => prev.map(t => 
        t.id === tableId ? { ...t, columns: updatedColumns } : t
      ));

      // Update actual SQLite table structure if needed
      if (updates.type || updates.nullable !== undefined) {
        await updateTableStructure(table.name, columnId, updates);
      }

      // Log audit event
      await executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, old_data, new_data, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          'current_user',
          'update_table_column',
          'table_column',
          columnId,
          JSON.stringify({ tableId, columnId }),
          JSON.stringify(updates),
          new Date().toISOString()
        ]
      );

      toast({
        title: "Success",
        description: "Column updated successfully"
      });

    } catch (error) {
      console.error('Error updating table column:', error);
      toast({
        title: "Error",
        description: "Failed to update column",
        variant: "destructive"
      });
    }
  };

  const updateTableStructure = async (tableName: string, columnId: string, updates: Partial<TableColumn>) => {
    try {
      const actualTableName = `custom_${tableName.toLowerCase().replace(/\s+/g, '_')}`;
      const actualColumnName = columnId.replace(/[^a-zA-Z0-9]/g, '_');

      if (updates.type) {
        // SQLite doesn't support ALTER COLUMN TYPE, so we need to recreate the table
        // For now, just log this as it's a complex operation
        console.warn('Table column type change requires manual intervention:', {
          table: actualTableName,
          column: actualColumnName,
          newType: updates.type
        });
      }

      if (updates.nullable !== undefined) {
        // SQLite doesn't support changing NOT NULL constraint directly
        console.warn('Table column nullable constraint change requires manual intervention:', {
          table: actualTableName,
          column: actualColumnName,
          nullable: updates.nullable
        });
      }
    } catch (error) {
      console.error('Error updating table structure:', error);
    }
  };

  const addFormField = async (formId: string) => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      type: 'text',
      label: 'New Field',
      required: false
    };

    const form = forms.find(f => f.id === formId);
    if (!form) return;

    const updatedFields = [...form.fields, newField];

    try {
      await executeRun(
        'UPDATE form_definitions SET fields = ?, updated_at = ? WHERE id = ?',
        [JSON.stringify(updatedFields), new Date().toISOString(), formId]
      );

      setForms(prev => prev.map(f => 
        f.id === formId ? { ...f, fields: updatedFields } : f
      ));

      toast({
        title: "Success",
        description: "Field added successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add field",
        variant: "destructive"
      });
    }
  };

  const removeFormField = async (formId: string, fieldId: string) => {
    const form = forms.find(f => f.id === formId);
    if (!form) return;

    const updatedFields = form.fields.filter(field => field.id !== fieldId);

    try {
      await executeRun(
        'UPDATE form_definitions SET fields = ?, updated_at = ? WHERE id = ?',
        [JSON.stringify(updatedFields), new Date().toISOString(), formId]
      );

      setForms(prev => prev.map(f => 
        f.id === formId ? { ...f, fields: updatedFields } : f
      ));

      toast({
        title: "Success",
        description: "Field removed successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove field",
        variant: "destructive"
      });
    }
  };

  const renderFormFieldEditor = (form: FormDefinition, field: FormField) => {
    const isEditing = editingField === field.id;

    return (
      <TableRow key={field.id}>
        <TableCell>
          {isEditing ? (
            <Input
              value={field.label}
              onChange={(e) => updateFormField(form.id, field.id, { label: e.target.value })}
              className="w-full"
            />
          ) : (
            field.label
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Select
              value={field.type}
              onValueChange={(value) => updateFormField(form.id, field.id, { type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="number">Number</SelectItem>
                <SelectItem value="textarea">Textarea</SelectItem>
                <SelectItem value="select">Select</SelectItem>
                <SelectItem value="checkbox">Checkbox</SelectItem>
                <SelectItem value="date">Date</SelectItem>
              </SelectContent>
            </Select>
          ) : (
            <Badge variant="outline">{field.type}</Badge>
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Switch
              checked={field.required}
              onCheckedChange={(checked) => updateFormField(form.id, field.id, { required: checked })}
            />
          ) : (
            field.required ? 'Yes' : 'No'
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Input
              value={field.placeholder || ''}
              onChange={(e) => updateFormField(form.id, field.id, { placeholder: e.target.value })}
              placeholder="Enter placeholder"
            />
          ) : (
            field.placeholder || 'N/A'
          )}
        </TableCell>
        <TableCell>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setEditingField(isEditing ? null : field.id)}
            >
              {isEditing ? <Save className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => removeFormField(form.id, field.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </TableCell>
      </TableRow>
    );
  };

  const renderTableColumnEditor = (table: TableDefinition, column: TableColumn) => {
    const isEditing = editingField === column.id;

    return (
      <TableRow key={column.id}>
        <TableCell>
          {isEditing ? (
            <Input
              value={column.name}
              onChange={(e) => updateTableColumn(table.id, column.id, { name: e.target.value })}
              className="w-full"
            />
          ) : (
            column.name
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Select
              value={column.type}
              onValueChange={(value) => updateTableColumn(table.id, column.id, { type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TEXT">Text</SelectItem>
                <SelectItem value="INTEGER">Integer</SelectItem>
                <SelectItem value="REAL">Real</SelectItem>
                <SelectItem value="BOOLEAN">Boolean</SelectItem>
                <SelectItem value="DATETIME">DateTime</SelectItem>
                <SelectItem value="BLOB">Blob</SelectItem>
              </SelectContent>
            </Select>
          ) : (
            <Badge variant="outline">{column.type}</Badge>
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Switch
              checked={!column.nullable}
              onCheckedChange={(checked) => updateTableColumn(table.id, column.id, { nullable: !checked })}
            />
          ) : (
            column.nullable ? 'No' : 'Yes'
          )}
        </TableCell>
        <TableCell>
          {isEditing ? (
            <Input
              value={column.default_value || ''}
              onChange={(e) => updateTableColumn(table.id, column.id, { default_value: e.target.value })}
              placeholder="Default value"
            />
          ) : (
            column.default_value || 'N/A'
          )}
        </TableCell>
        <TableCell>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setEditingField(isEditing ? null : column.id)}
            >
              {isEditing ? <Save className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
            </Button>
          </div>
        </TableCell>
      </TableRow>
    );
  };

  const filteredForms = forms.filter(form =>
    form.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    form.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredTables = tables.filter(table =>
    table.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    table.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading field inspector...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Field Inspector</h3>
          <p className="text-sm text-muted-foreground">Live editing of form fields and table columns</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search forms and tables..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>
      </div>

      <Tabs defaultValue="forms" className="space-y-4">
        <TabsList>
          <TabsTrigger value="forms">Forms ({filteredForms.length})</TabsTrigger>
          <TabsTrigger value="tables">Tables ({filteredTables.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="forms">
          <div className="space-y-4">
            {filteredForms.map(form => (
              <Card key={form.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{form.name}</CardTitle>
                      {form.description && (
                        <p className="text-sm text-muted-foreground">{form.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{form.placement}</Badge>
                      <Button
                        size="sm"
                        onClick={() => addFormField(form.id)}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Field
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Label</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Required</TableHead>
                        <TableHead>Placeholder</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {form.fields.map(field => renderFormFieldEditor(form, field))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tables">
          <div className="space-y-4">
            {filteredTables.map(table => (
              <Card key={table.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{table.name}</CardTitle>
                      {table.description && (
                        <p className="text-sm text-muted-foreground">{table.description}</p>
                      )}
                    </div>
                    <Badge variant="outline">{table.placement}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Required</TableHead>
                        <TableHead>Default</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {table.columns.map(column => renderTableColumnEditor(table, column))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}