import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { notificationStartupService } from '@/services/notifications/notificationStartupService';
import { useEnhancedNotifications } from '@/hooks/useEnhancedNotifications';
import { Bell, CheckCircle, XCircle, AlertTriangle, RefreshCw } from 'lucide-react';

export const NotificationServiceStatus = () => {
  const [status, setStatus] = useState(notificationStartupService.getStatus());
  const [isCreatingTests, setIsCreatingTests] = useState(false);
  const { notifications, unreadCount } = useEnhancedNotifications();

  const refreshStatus = () => {
    setStatus(notificationStartupService.getStatus());
  };

  const createTestNotifications = async () => {
    try {
      setIsCreatingTests(true);
      await notificationStartupService.createTestNotifications();
      refreshStatus();
    } catch (error) {
      console.error('Failed to create test notifications:', error);
    } finally {
      setIsCreatingTests(false);
    }
  };

  useEffect(() => {
    const interval = setInterval(refreshStatus, 5000); // Refresh every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (isActive: boolean) => {
    return isActive ? (
      <CheckCircle className="w-4 h-4 text-green-500" />
    ) : (
      <XCircle className="w-4 h-4 text-red-500" />
    );
  };

  const getStatusBadge = (isActive: boolean) => {
    return (
      <Badge variant={isActive ? "default" : "destructive"}>
        {isActive ? "Active" : "Inactive"}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notification Service Status
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshStatus}
            className="ml-auto"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Status */}
        <div className="flex items-center justify-between">
          <span className="font-medium">System Status:</span>
          {getStatusBadge(status.isInitialized)}
        </div>

        {/* Error Display */}
        {status.error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{status.error}</AlertDescription>
          </Alert>
        )}

        {/* Service Details */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm">Service Components:</h4>
          <div className="space-y-1 text-sm">
            <div className="flex items-center justify-between">
              <span>Enhanced Notification Service</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(status.services.enhancedNotificationService)}
                {getStatusBadge(status.services.enhancedNotificationService)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span>Integration Service</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(status.services.notificationIntegrationService)}
                {getStatusBadge(status.services.notificationIntegrationService)}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span>Periodic Checks</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(status.services.periodicChecks)}
                {getStatusBadge(status.services.periodicChecks)}
              </div>
            </div>
          </div>
        </div>

        {/* Notification Stats */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm">Current Notifications:</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex justify-between">
              <span>Total:</span>
              <Badge variant="outline">{notifications.length}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Unread:</span>
              <Badge variant={unreadCount > 0 ? "default" : "outline"}>
                {unreadCount}
              </Badge>
            </div>
          </div>
        </div>

        {/* Test Actions */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm">Testing:</h4>
          <Button
            onClick={createTestNotifications}
            disabled={!status.isInitialized || isCreatingTests}
            size="sm"
            className="w-full"
          >
            {isCreatingTests ? "Creating..." : "Create Test Notifications"}
          </Button>
        </div>

        {/* System Info */}
        {status.isInitialized && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              Notification system is running and monitoring for alerts.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};