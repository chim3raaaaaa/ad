import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useUser } from '@/contexts/UserContext';
import { developerStateService } from '@/services/database/developerStateService';
import { Play, Save, History, Database, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface QueryResult {
  query: string;
  result: any[];
  error?: string;
  executionTime: number;
  timestamp: string;
}

export const SQLiteConsole: React.FC = () => {
  const { user } = useUser();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<QueryResult[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const executeQuery = async () => {
    if (!query.trim()) return;

    setIsExecuting(true);
    const startTime = Date.now();

    try {
      // Log the action
      await developerStateService.logAction(
        user?.id || 'unknown',
        'sqlite-console',
        'execute_query',
        query.substring(0, 100) + (query.length > 100 ? '...' : '')
      );

      const result = await window.electronAPI.dbQuery(query);
      const executionTime = Date.now() - startTime;

      const newResult: QueryResult = {
        query,
        result,
        executionTime,
        timestamp: new Date().toISOString()
      };

      setResults(prev => [newResult, ...prev.slice(0, 9)]); // Keep last 10 results
      toast.success(`Query executed successfully in ${executionTime}ms`);
    } catch (error: any) {
      const executionTime = Date.now() - startTime;
      const newResult: QueryResult = {
        query,
        result: [],
        error: error.message || 'Query execution failed',
        executionTime,
        timestamp: new Date().toISOString()
      };

      setResults(prev => [newResult, ...prev.slice(0, 9)]);
      toast.error('Query failed: ' + error.message);
    } finally {
      setIsExecuting(false);
    }
  };

  const saveToFavorites = () => {
    if (query.trim() && !favorites.includes(query)) {
      setFavorites(prev => [...prev, query]);
      toast.success('Query saved to favorites');
    }
  };

  const loadFavoriteQuery = (favoriteQuery: string) => {
    setQuery(favoriteQuery);
  };

  const predefinedQueries = [
    'SELECT name FROM sqlite_master WHERE type=\'table\';',
    'SELECT * FROM dev_user_states LIMIT 10;',
    'SELECT * FROM dev_audit_logs ORDER BY timestamp DESC LIMIT 10;',
    'SELECT tool_id, role, is_visible FROM dev_tool_visibility WHERE role = \'admin\';',
    'SELECT COUNT(*) as total_tables FROM sqlite_master WHERE type=\'table\';'
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            SQLite Console
          </CardTitle>
          <CardDescription>
            Execute SQL queries directly against the SQLite database. Use with caution.
          </CardDescription>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <span className="text-sm text-destructive">
              Admin only - Modify data at your own risk
            </span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">SQL Query</label>
            <Textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter your SQL query here..."
              rows={6}
              className="font-mono text-sm"
            />
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={executeQuery} 
              disabled={isExecuting || !query.trim()}
              className="flex items-center gap-2"
            >
              <Play className="h-4 w-4" />
              {isExecuting ? 'Executing...' : 'Execute'}
            </Button>
            <Button 
              variant="outline" 
              onClick={saveToFavorites}
              disabled={!query.trim()}
              className="flex items-center gap-2"
            >
              <Save className="h-4 w-4" />
              Save
            </Button>
          </div>

          {/* Predefined Queries */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Quick Queries</label>
            <div className="flex flex-wrap gap-2">
              {predefinedQueries.map((predefined, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => setQuery(predefined)}
                  className="text-xs"
                >
                  {predefined.length > 30 ? predefined.substring(0, 30) + '...' : predefined}
                </Button>
              ))}
            </div>
          </div>

          {/* Favorites */}
          {favorites.length > 0 && (
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <History className="h-4 w-4" />
                Favorites
              </label>
              <div className="space-y-1">
                {favorites.map((favorite, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    onClick={() => loadFavoriteQuery(favorite)}
                    className="justify-start text-xs w-full"
                  >
                    {favorite.length > 50 ? favorite.substring(0, 50) + '...' : favorite}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Query Results</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {results.map((result, index) => (
                  <div key={index} className="border rounded p-4">
                    <div className="flex items-center justify-between mb-2">
                      <code className="text-sm bg-muted px-2 py-1 rounded">
                        {result.query.length > 100 ? result.query.substring(0, 100) + '...' : result.query}
                      </code>
                      <div className="flex items-center gap-2">
                        <Badge variant={result.error ? 'destructive' : 'default'}>
                          {result.error ? 'Error' : 'Success'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {result.executionTime}ms
                        </span>
                      </div>
                    </div>

                    {result.error ? (
                      <div className="text-destructive text-sm font-mono bg-destructive/10 p-2 rounded">
                        {result.error}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="text-sm text-muted-foreground">
                          {result.result.length} rows returned
                        </div>
                        
                        {result.result.length > 0 ? (
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b">
                                  {Object.keys(result.result[0]).map(key => (
                                    <th key={key} className="text-left p-2 font-medium">
                                      {key}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {result.result.slice(0, 50).map((row, rowIndex) => (
                                  <tr key={rowIndex} className="border-b">
                                    {Object.values(row).map((value: any, cellIndex) => (
                                      <td key={cellIndex} className="p-2 font-mono text-xs">
                                        {typeof value === 'string' && value.length > 50
                                          ? value.substring(0, 50) + '...'
                                          : String(value)}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                            {result.result.length > 50 && (
                              <div className="text-xs text-muted-foreground mt-2">
                                Showing first 50 rows of {result.result.length}
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="text-muted-foreground text-sm italic">
                            No rows returned
                          </div>
                        )}
                      </div>
                    )}

                    <Separator className="my-2" />
                    <div className="text-xs text-muted-foreground">
                      Executed at {new Date(result.timestamp).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
};