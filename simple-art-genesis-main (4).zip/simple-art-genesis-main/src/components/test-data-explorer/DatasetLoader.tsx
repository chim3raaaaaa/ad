import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileSpreadsheet, Upload, Download, CheckCircle, AlertTriangle, X, FileText, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface DatasetLoaderProps {
  onDataImported: () => void;
}

interface ColumnMapping {
  csvColumn: string;
  dbField: string;
  required: boolean;
  dataType: 'text' | 'number' | 'date' | 'json';
  transform?: string;
}

interface ImportPreview {
  headers: string[];
  sampleRows: any[][];
  totalRows: number;
}

interface ValidationError {
  row: number;
  column: string;
  value: any;
  error: string;
}

export default function DatasetLoader({ onDataImported }: DatasetLoaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [importPreview, setImportPreview] = useState<ImportPreview | null>(null);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [step, setStep] = useState<'upload' | 'mapping' | 'validation' | 'import'>('upload');

  // Available database fields for mapping
  const availableFields = [
    { key: 'test_type', label: 'Test Type', required: true, type: 'text' },
    { key: 'batch_id', label: 'Batch ID', required: false, type: 'text' },
    { key: 'product_type', label: 'Product Type', required: true, type: 'text' },
    { key: 'test_date', label: 'Test Date', required: true, type: 'date' },
    { key: 'site', label: 'Site', required: false, type: 'text' },
    { key: 'plant_id', label: 'Plant ID', required: false, type: 'text' },
    { key: 'operator', label: 'Operator', required: false, type: 'text' },
    { key: 'machine_used', label: 'Machine Used', required: false, type: 'text' },
    { key: 'test_results', label: 'Test Results (JSON)', required: true, type: 'json' },
    { key: 'notes', label: 'Notes', required: false, type: 'text' },
    { key: 'memo_reference', label: 'Memo Reference', required: false, type: 'text' }
  ];

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (!uploadedFile) return;

    const fileExtension = uploadedFile.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(fileExtension || '')) {
      toast.error('Please upload a CSV or Excel file');
      return;
    }

    setFile(uploadedFile);

    try {
      let data: any[][];
      
      if (fileExtension === 'csv') {
        const text = await uploadedFile.text();
        const lines = text.split('\n').filter(line => line.trim());
        data = lines.map(line => line.split(',').map(cell => cell.trim().replace(/^"|"$/g, '')));
      } else {
        const buffer = await uploadedFile.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        data = jsonData as any[][];
      }

      if (data.length === 0) {
        toast.error('File appears to be empty');
        return;
      }

      const headers = data[0] as string[];
      const sampleRows = data.slice(1, 6); // First 5 data rows
      
      setImportPreview({
        headers,
        sampleRows,
        totalRows: data.length - 1
      });

      // Initialize column mappings
      const initialMappings: ColumnMapping[] = headers.map(header => {
        // Try to auto-match common column names
        const lowerHeader = header.toLowerCase();
        let matchedField = '';
        
        if (lowerHeader.includes('test') && lowerHeader.includes('type')) matchedField = 'test_type';
        else if (lowerHeader.includes('batch')) matchedField = 'batch_id';
        else if (lowerHeader.includes('product')) matchedField = 'product_type';
        else if (lowerHeader.includes('date')) matchedField = 'test_date';
        else if (lowerHeader.includes('site')) matchedField = 'site';
        else if (lowerHeader.includes('operator')) matchedField = 'operator';
        else if (lowerHeader.includes('machine')) matchedField = 'machine_used';
        else if (lowerHeader.includes('result')) matchedField = 'test_results';
        else if (lowerHeader.includes('note')) matchedField = 'notes';
        else if (lowerHeader.includes('memo')) matchedField = 'memo_reference';

        const field = availableFields.find(f => f.key === matchedField);
        
        return {
          csvColumn: header,
          dbField: matchedField,
          required: field?.required || false,
          dataType: field?.type as any || 'text'
        };
      });

      setColumnMappings(initialMappings);
      setStep('mapping');
      
    } catch (error) {
      console.error('Error reading file:', error);
      toast.error('Failed to read file. Please check the format.');
    }
  }, []);

  const updateColumnMapping = (csvColumn: string, dbField: string) => {
    setColumnMappings(prev => prev.map(mapping => {
      if (mapping.csvColumn === csvColumn) {
        const field = availableFields.find(f => f.key === dbField);
        return {
          ...mapping,
          dbField,
          required: field?.required || false,
          dataType: field?.type as any || 'text'
        };
      }
      return mapping;
    }));
  };

  const validateData = async () => {
    if (!file || !importPreview) return;

    const errors: ValidationError[] = [];
    const requiredMappings = columnMappings.filter(m => m.required && m.dbField);
    
    // Check required field mappings
    const mappedFields = columnMappings.filter(m => m.dbField).map(m => m.dbField);
    const missingRequired = availableFields
      .filter(f => f.required)
      .filter(f => !mappedFields.includes(f.key));

    if (missingRequired.length > 0) {
      toast.error(`Missing required field mappings: ${missingRequired.map(f => f.label).join(', ')}`);
      return;
    }

    // Read and validate all data
    try {
      let allData: any[][];
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      
      if (fileExtension === 'csv') {
        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim());
        allData = lines.map(line => line.split(',').map(cell => cell.trim().replace(/^"|"$/g, '')));
      } else {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        allData = jsonData as any[][];
      }

      const headers = allData[0] as string[];
      const dataRows = allData.slice(1);

      // Validate each row
      dataRows.forEach((row, rowIndex) => {
        columnMappings.forEach((mapping, colIndex) => {
          if (!mapping.dbField) return;

          const value = row[colIndex];
          
          // Check required fields
          if (mapping.required && (!value || value.toString().trim() === '')) {
            errors.push({
              row: rowIndex + 2, // +2 because 0-indexed and header row
              column: mapping.csvColumn,
              value,
              error: 'Required field is empty'
            });
          }

          // Validate data types
          if (value && value.toString().trim() !== '') {
            switch (mapping.dataType) {
              case 'number':
                if (isNaN(parseFloat(value))) {
                  errors.push({
                    row: rowIndex + 2,
                    column: mapping.csvColumn,
                    value,
                    error: 'Not a valid number'
                  });
                }
                break;
              case 'date':
                if (isNaN(Date.parse(value))) {
                  errors.push({
                    row: rowIndex + 2,
                    column: mapping.csvColumn,
                    value,
                    error: 'Not a valid date'
                  });
                }
                break;
              case 'json':
                try {
                  JSON.parse(value);
                } catch {
                  // Try to convert to JSON if it's not already
                  if (typeof value === 'string' && !value.startsWith('{')) {
                    // Convert simple value to JSON - skip validation for now
                    return;
                  }
                  errors.push({
                    row: rowIndex + 2,
                    column: mapping.csvColumn,
                    value,
                    error: 'Not valid JSON format'
                  });
                }
                break;
            }
          }
        });
      });

      setValidationErrors(errors);
      setStep('validation');
      
      if (errors.length === 0) {
        toast.success('Data validation passed! Ready to import.');
      } else {
        toast.warning(`Found ${errors.length} validation errors. Review before importing.`);
      }
      
    } catch (error) {
      console.error('Validation error:', error);
      toast.error('Failed to validate data');
    }
  };

  const importData = async () => {
    if (!file || !window.electronAPI) return;

    setImporting(true);
    setImportProgress(0);
    setStep('import');

    try {
      // Read all data
      let allData: any[][];
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      
      if (fileExtension === 'csv') {
        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim());
        allData = lines.map(line => line.split(',').map(cell => cell.trim().replace(/^"|"$/g, '')));
      } else {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        allData = jsonData as any[][];
      }

      const headers = allData[0] as string[];
      const dataRows = allData.slice(1);
      
      let successCount = 0;
      let errorCount = 0;
      const importErrors: string[] = [];

      // Process each row
      for (let i = 0; i < dataRows.length; i++) {
        const row = dataRows[i];
        setImportProgress(Math.round(((i + 1) / dataRows.length) * 100));

        try {
          const entryData: any = {
            id: `imported-${Date.now()}-${i}`,
            module_id: 'test-data-explorer',
            source: 'imported',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            created_by: 'current_user'
          };

          // Map columns to database fields
          columnMappings.forEach((mapping, colIndex) => {
            if (!mapping.dbField) return;

            let value = row[colIndex];
            
            if (value && value.toString().trim() !== '') {
              switch (mapping.dataType) {
                case 'number':
                  value = parseFloat(value);
                  break;
                case 'date':
                  value = new Date(value).toISOString();
                  break;
                case 'json':
                  if (typeof value === 'string' && !value.startsWith('{')) {
                    // Convert simple value to JSON object
                    value = JSON.stringify({ value: value });
                  } else {
                    try {
                      JSON.parse(value); // Validate JSON
                    } catch {
                      value = JSON.stringify({ value: value });
                    }
                  }
                  break;
                default:
                  value = value.toString();
              }

              entryData[mapping.dbField] = value;
            }
          });

          // Set default pass_fail_status
          entryData.pass_fail_status = 'pending';

          // Insert into database
          await window.electronAPI.dbRun(`
            INSERT INTO test_data_entries (
              id, module_id, test_type, batch_id, product_type, test_date,
              site, plant_id, operator, machine_used, test_results,
              pass_fail_status, source, notes, memo_reference,
              created_at, updated_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            entryData.id,
            entryData.module_id,
            entryData.test_type || null,
            entryData.batch_id || null,
            entryData.product_type || null,
            entryData.test_date || new Date().toISOString(),
            entryData.site || null,
            entryData.plant_id || null,
            entryData.operator || null,
            entryData.machine_used || null,
            entryData.test_results || '{}',
            entryData.pass_fail_status,
            entryData.source,
            entryData.notes || null,
            entryData.memo_reference || null,
            entryData.created_at,
            entryData.updated_at,
            entryData.created_by
          ]);

          successCount++;
        } catch (error) {
          errorCount++;
          importErrors.push(`Row ${i + 2}: ${error}`);
          console.error(`Error importing row ${i + 2}:`, error);
        }
      }

      // Log import results
      const logId = `import-${Date.now()}`;
      await window.electronAPI.dbRun(`
        INSERT INTO test_data_import_log (
          id, filename, file_type, rows_imported, rows_failed, status, error_details, imported_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        logId,
        file.name,
        fileExtension,
        successCount,
        errorCount,
        errorCount === 0 ? 'success' : (successCount > 0 ? 'partial' : 'error'),
        JSON.stringify(importErrors),
        'current_user'
      ]);

      toast.success(`Import completed! ${successCount} rows imported successfully${errorCount > 0 ? `, ${errorCount} failed` : ''}`);
      
      if (successCount > 0) {
        onDataImported();
      }
      
      setIsOpen(false);
      resetState();

    } catch (error) {
      console.error('Import failed:', error);
      toast.error('Import failed: ' + error);
    } finally {
      setImporting(false);
    }
  };

  const resetState = () => {
    setFile(null);
    setImportPreview(null);
    setColumnMappings([]);
    setValidationErrors([]);
    setImportProgress(0);
    setStep('upload');
  };

  const downloadTemplate = () => {
    const templateData = [
      ['Test Type', 'Product Type', 'Test Date', 'Batch ID', 'Site', 'Operator', 'Machine Used', 'Test Results (JSON)', 'Notes'],
      ['Compressive Strength', 'Concrete', '2024-01-15', 'BATCH-001', 'Plant A', 'John Doe', 'MIX-001', '{"compressive_strength": 30.5, "density": 2400}', 'Sample test data'],
      ['Silt Content', 'Aggregates', '2024-01-16', 'BATCH-002', 'Plant B', 'Jane Smith', 'SIEVE-001', '{"silt_content": 2.1, "clay_content": 1.8}', 'Quality control test']
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Test Data Template');
    XLSX.writeFile(workbook, 'test_data_template.xlsx');
    
    toast.success('Template downloaded successfully');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
          <Upload className="h-4 w-4 mr-2" />
          Import Dataset (CSV/Excel)
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Dataset Loader
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step Indicator */}
          <div className="flex items-center space-x-4">
            {['upload', 'mapping', 'validation', 'import'].map((stepName, index) => (
              <div key={stepName} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step === stepName ? 'bg-primary text-primary-foreground' :
                  ['upload', 'mapping', 'validation', 'import'].indexOf(step) > index ? 'bg-green-500 text-white' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {['upload', 'mapping', 'validation', 'import'].indexOf(step) > index ? '✓' : index + 1}
                </div>
                <span className="ml-2 text-sm capitalize">{stepName}</span>
                {index < 3 && <div className="w-8 h-px bg-muted-foreground/20 ml-4" />}
              </div>
            ))}
          </div>

          {/* Step Content */}
          {step === 'upload' && (
            <Card>
              <CardHeader>
                <CardTitle>Upload Dataset</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-4">
                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8">
                    <FileSpreadsheet className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <div className="space-y-2">
                      <p className="text-lg font-medium">Upload CSV or Excel File</p>
                      <p className="text-sm text-muted-foreground">
                        Select a file containing test data to import
                      </p>
                    </div>
                    <div className="mt-4">
                      <Input
                        type="file"
                        accept=".csv,.xlsx,.xls"
                        onChange={handleFileUpload}
                        className="max-w-sm mx-auto"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <Button variant="outline" onClick={downloadTemplate}>
                      <Download className="h-4 w-4 mr-2" />
                      Download Template
                    </Button>
                  </div>
                </div>

                {importPreview && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">File Preview</h4>
                      <Badge variant="secondary">
                        {importPreview.totalRows} rows
                      </Badge>
                    </div>
                    
                    <div className="border rounded-lg overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            {importPreview.headers.map((header, index) => (
                              <TableHead key={index} className="font-medium">
                                {header}
                              </TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {importPreview.sampleRows.map((row, rowIndex) => (
                            <TableRow key={rowIndex}>
                              {row.map((cell, cellIndex) => (
                                <TableCell key={cellIndex} className="max-w-[150px] truncate">
                                  {cell || '-'}
                                </TableCell>
                              ))}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>

                    <div className="flex justify-end">
                      <Button onClick={() => setStep('mapping')}>
                        Next: Map Columns
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {step === 'mapping' && importPreview && (
            <Card>
              <CardHeader>
                <CardTitle>Column Mapping</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Map your CSV/Excel columns to database fields. Required fields are marked with *.
                </p>
                
                <div className="space-y-3">
                  {columnMappings.map((mapping, index) => (
                    <div key={index} className="flex items-center gap-4 p-3 border rounded-lg">
                      <div className="flex-1">
                        <Label className="font-medium">{mapping.csvColumn}</Label>
                        <div className="text-xs text-muted-foreground">
                          Sample: {importPreview.sampleRows[0]?.[index] || 'N/A'}
                        </div>
                      </div>
                      
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      
                      <div className="flex-1">
                        <Select
                          value={mapping.dbField}
                          onValueChange={(value) => updateColumnMapping(mapping.csvColumn, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select field..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="">Don't import</SelectItem>
                            {availableFields.map(field => (
                              <SelectItem key={field.key} value={field.key}>
                                {field.label} {field.required && '*'}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep('upload')}>
                    Back
                  </Button>
                  <Button onClick={validateData}>
                    Next: Validate Data
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 'validation' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Data Validation
                  {validationErrors.length === 0 ? (
                    <Badge variant="default" className="bg-green-100 text-green-800">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Passed
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      {validationErrors.length} Errors
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {validationErrors.length === 0 ? (
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
                    <p className="text-lg font-medium">Data validation passed!</p>
                    <p className="text-sm text-muted-foreground">
                      All required fields are mapped and data format is valid.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Please review and fix the following errors before importing:
                    </p>
                    
                    <div className="max-h-60 overflow-y-auto space-y-2">
                      {validationErrors.map((error, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          <div className="flex-1 text-sm">
                            <span className="font-medium">Row {error.row}</span>
                            {' • '}
                            <span className="text-muted-foreground">{error.column}:</span>
                            {' '}
                            <span className="font-medium">{error.error}</span>
                            {error.value && (
                              <span className="text-xs text-muted-foreground block">
                                Value: "{error.value}"
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep('mapping')}>
                    Back to Mapping
                  </Button>
                  <Button 
                    onClick={importData}
                    disabled={validationErrors.length > 0}
                  >
                    Import Data
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 'import' && (
            <Card>
              <CardHeader>
                <CardTitle>Importing Data</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-8">
                  <div className="space-y-4">
                    <div className="text-lg font-medium">
                      {importing ? 'Importing data...' : 'Import completed!'}
                    </div>
                    <Progress value={importProgress} className="w-full max-w-md mx-auto" />
                    <div className="text-sm text-muted-foreground">
                      {importProgress}% complete
                    </div>
                  </div>
                </div>

                {!importing && (
                  <div className="flex justify-center">
                    <Button onClick={() => setIsOpen(false)}>
                      Close
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}