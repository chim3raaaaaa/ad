import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { GitCompare, Save, X, AlertTriangle, CheckCircle, Minus } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface ComparisonViewerProps {
  selectedEntries: string[];
  allEntries: any[];
  onClearSelection: () => void;
}

interface ComparisonData {
  id: string;
  test_ids: string[];
  compared_by: string;
  compared_at: string;
  summary: any;
  differences: any;
  notes?: string;
}

export default function ComparisonViewer({ 
  selectedEntries, 
  allEntries, 
  onClearSelection 
}: ComparisonViewerProps) {
  const [comparisonData, setComparisonData] = useState<any>(null);
  const [comparisonNotes, setComparisonNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedComparisons, setSavedComparisons] = useState<ComparisonData[]>([]);

  // Get selected test entries
  const selectedTestEntries = allEntries.filter(entry => 
    selectedEntries.includes(entry.id)
  );

  useEffect(() => {
    if (selectedTestEntries.length >= 2) {
      generateComparison();
    }
  }, [selectedTestEntries]);

  useEffect(() => {
    loadSavedComparisons();
  }, []);

  const loadSavedComparisons = async () => {
    if (!window.electronAPI) return;

    try {
      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_data_comparisons 
        ORDER BY compared_at DESC 
        LIMIT 10
      `);

      if (result.data) {
        setSavedComparisons(result.data.map((comp: any) => ({
          ...comp,
          test_ids: JSON.parse(comp.test_ids),
          summary: JSON.parse(comp.summary),
          differences: JSON.parse(comp.differences)
        })));
      }
    } catch (error) {
      console.error('Failed to load saved comparisons:', error);
    }
  };

  const generateComparison = () => {
    if (selectedTestEntries.length < 2) return;

    const baseEntry = selectedTestEntries[0];
    const differences: any = {};
    const summary: any = {
      total_compared: selectedTestEntries.length,
      fields_compared: [],
      identical_fields: [],
      different_fields: [],
      comparison_date: new Date().toISOString()
    };

    // Compare test results
    const allFields = new Set<string>();
    selectedTestEntries.forEach(entry => {
      if (entry.test_results) {
        Object.keys(entry.test_results).forEach(field => allFields.add(field));
      }
    });

    allFields.forEach(field => {
      summary.fields_compared.push(field);
      
      const values = selectedTestEntries.map(entry => ({
        id: entry.id,
        batch_id: entry.batch_id,
        value: entry.test_results?.[field],
        date: entry.test_date
      }));

      const uniqueValues = [...new Set(values.map(v => v.value))];
      
      if (uniqueValues.length === 1) {
        summary.identical_fields.push(field);
      } else {
        summary.different_fields.push(field);
        differences[field] = {
          field_name: field,
          values: values,
          variance: calculateVariance(values.map(v => v.value).filter(v => typeof v === 'number')),
          status: 'different'
        };
      }
    });

    // Compare metadata
    const metadataFields = ['operator', 'machine_used', 'site', 'pass_fail_status'];
    metadataFields.forEach(field => {
      const values = selectedTestEntries.map(entry => ({
        id: entry.id,
        batch_id: entry.batch_id,
        value: entry[field],
        date: entry.test_date
      }));

      const uniqueValues = [...new Set(values.map(v => v.value))];
      
      if (uniqueValues.length > 1) {
        differences[field] = {
          field_name: field,
          values: values,
          status: 'metadata_different'
        };
      }
    });

    setComparisonData({ summary, differences });
  };

  const calculateVariance = (values: number[]) => {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    return Math.sqrt(variance); // Standard deviation
  };

  const saveComparison = async () => {
    if (!comparisonData || !window.electronAPI) return;

    setSaving(true);
    try {
      const comparisonId = `comp-${Date.now()}`;
      
      await window.electronAPI.dbRun(`
        INSERT INTO test_data_comparisons 
        (id, test_ids, compared_by, compared_at, summary, differences, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        comparisonId,
        JSON.stringify(selectedEntries),
        'current_user', // Should get from auth context
        new Date().toISOString(),
        JSON.stringify(comparisonData.summary),
        JSON.stringify(comparisonData.differences),
        comparisonNotes
      ]);

      toast.success('Comparison saved successfully');
      setComparisonNotes('');
      loadSavedComparisons();
    } catch (error) {
      console.error('Failed to save comparison:', error);
      toast.error('Failed to save comparison');
    } finally {
      setSaving(false);
    }
  };

  const renderDifferenceValue = (value: any, status: 'same' | 'different' | 'missing') => {
    if (value === null || value === undefined) {
      return <span className="text-muted-foreground italic">N/A</span>;
    }

    const displayValue = typeof value === 'number' ? value.toFixed(3) : String(value);

    switch (status) {
      case 'same':
        return <span className="text-green-600">{displayValue}</span>;
      case 'different':
        return <span className="text-red-600 font-medium">{displayValue}</span>;
      case 'missing':
        return <span className="text-muted-foreground italic">Missing</span>;
      default:
        return <span>{displayValue}</span>;
    }
  };

  const getDifferenceStatus = (values: any[], currentValue: any) => {
    const uniqueValues = [...new Set(values.map(v => v.value))];
    if (uniqueValues.length === 1) return 'same';
    if (currentValue === null || currentValue === undefined) return 'missing';
    return 'different';
  };

  if (selectedTestEntries.length < 2) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitCompare className="h-5 w-5" />
            Side-by-Side Comparison
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <GitCompare className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Select 2 or more test entries to compare them side-by-side</p>
            <p className="text-sm mt-2">
              Currently selected: {selectedEntries.length} entries
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Comparison Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GitCompare className="h-5 w-5" />
              Comparing {selectedTestEntries.length} Test Entries
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={saveComparison}
                disabled={saving || !comparisonData}
              >
                <Save className="h-4 w-4 mr-2" />
                Save Comparison
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onClearSelection}
              >
                <X className="h-4 w-4 mr-2" />
                Clear Selection
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        
        {comparisonData && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {comparisonData.summary.identical_fields.length}
                </div>
                <div className="text-sm text-muted-foreground">Identical Fields</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {comparisonData.summary.different_fields.length}
                </div>
                <div className="text-sm text-muted-foreground">Different Fields</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {comparisonData.summary.fields_compared.length}
                </div>
                <div className="text-sm text-muted-foreground">Total Fields</div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Comparison Notes</Label>
              <Textarea
                placeholder="Add notes about this comparison..."
                value={comparisonNotes}
                onChange={(e) => setComparisonNotes(e.target.value)}
                rows={3}
              />
            </div>
          </CardContent>
        )}
      </Card>

      {/* Comparison Table */}
      {comparisonData && (
        <Card>
          <CardHeader>
            <CardTitle>Detailed Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-medium">Field</th>
                    {selectedTestEntries.map(entry => (
                      <th key={entry.id} className="text-center p-3 font-medium min-w-[150px]">
                        <div>
                          <div className="font-medium">{entry.batch_id || entry.id.slice(0, 8)}</div>
                          <div className="text-xs text-muted-foreground">
                            {format(new Date(entry.test_date), 'MMM dd, yyyy')}
                          </div>
                        </div>
                      </th>
                    ))}
                    <th className="text-center p-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Test Results Fields */}
                  {comparisonData.summary.fields_compared.map((field: string) => {
                    const difference = comparisonData.differences[field];
                    const isIdentical = comparisonData.summary.identical_fields.includes(field);
                    
                    return (
                      <tr key={field} className="border-b hover:bg-muted/50">
                        <td className="p-3 font-medium">{field}</td>
                        {selectedTestEntries.map(entry => {
                          const value = entry.test_results?.[field];
                          const status = isIdentical ? 'same' : 
                            (value === null || value === undefined) ? 'missing' : 'different';
                          
                          return (
                            <td key={entry.id} className="p-3 text-center">
                              {renderDifferenceValue(value, status)}
                            </td>
                          );
                        })}
                        <td className="p-3 text-center">
                          {isIdentical ? (
                            <Badge variant="outline" className="text-green-600 border-green-200">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Same
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-red-600 border-red-200">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Different
                            </Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {/* Metadata Fields */}
                  {Object.entries(comparisonData.differences).filter(([key]) => 
                    !comparisonData.summary.fields_compared.includes(key)
                  ).map(([field, difference]: [string, any]) => (
                    <tr key={field} className="border-b hover:bg-muted/50 bg-blue-50/50">
                      <td className="p-3 font-medium">{field.replace('_', ' ')}</td>
                      {selectedTestEntries.map(entry => {
                        const value = entry[field];
                        return (
                          <td key={entry.id} className="p-3 text-center">
                            {renderDifferenceValue(value, 'different')}
                          </td>
                        );
                      })}
                      <td className="p-3 text-center">
                        <Badge variant="outline" className="text-blue-600 border-blue-200">
                          <Minus className="h-3 w-3 mr-1" />
                          Metadata
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Saved Comparisons */}
      {savedComparisons.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Comparisons</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {savedComparisons.slice(0, 5).map(comparison => (
                <div key={comparison.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">
                      {comparison.test_ids.length} entries compared
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {format(new Date(comparison.compared_at), 'MMM dd, yyyy HH:mm')}
                      {comparison.notes && ` • ${comparison.notes.slice(0, 50)}...`}
                    </div>
                  </div>
                  <Badge variant="secondary">
                    {comparison.summary.different_fields.length} differences
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}