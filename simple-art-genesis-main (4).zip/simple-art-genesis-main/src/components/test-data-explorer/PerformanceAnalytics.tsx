import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Minus, BarChart3, PieChart, Activity, Calendar, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, Area, AreaChart } from 'recharts';
import { format, subDays, subMonths, parseISO } from 'date-fns';

interface PerformanceAnalyticsProps {
  entries: any[];
}

interface AnalyticsData {
  period: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  conformity_percentage: number;
  average_result: number;
  trend_direction: 'improving' | 'declining' | 'stable';
}

interface FailurePattern {
  field: string;
  failure_count: number;
  percentage: number;
  recent_trend: 'increasing' | 'decreasing' | 'stable';
}

export default function PerformanceAnalytics({ entries }: PerformanceAnalyticsProps) {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [groupBy, setGroupBy] = useState<'day' | 'week' | 'month'>('week');
  const [selectedPlant, setSelectedPlant] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<string>('all');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData[]>([]);
  const [failurePatterns, setFailurePatterns] = useState<FailurePattern[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    generateAnalytics();
  }, [entries, timeRange, groupBy, selectedPlant, selectedProduct]);

  const generateAnalytics = () => {
    setLoading(true);
    
    try {
      // Filter entries based on selections
      let filteredEntries = entries;
      
      if (selectedPlant !== 'all') {
        filteredEntries = filteredEntries.filter(e => e.plant_id === selectedPlant);
      }
      
      if (selectedProduct !== 'all') {
        filteredEntries = filteredEntries.filter(e => e.product_type === selectedProduct);
      }

      // Filter by time range
      const now = new Date();
      const startDate = timeRange === '7d' ? subDays(now, 7) :
                       timeRange === '30d' ? subDays(now, 30) :
                       timeRange === '90d' ? subDays(now, 90) :
                       subDays(now, 365);

      filteredEntries = filteredEntries.filter(e => 
        new Date(e.test_date) >= startDate
      );

      // Group data by time period
      const groupedData = groupDataByPeriod(filteredEntries);
      setAnalyticsData(groupedData);

      // Analyze failure patterns
      const patterns = analyzeFailurePatterns(filteredEntries);
      setFailurePatterns(patterns);

    } catch (error) {
      console.error('Error generating analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const groupDataByPeriod = (entries: any[]): AnalyticsData[] => {
    const grouped: { [key: string]: any[] } = {};

    entries.forEach(entry => {
      const date = new Date(entry.test_date);
      let periodKey: string;

      switch (groupBy) {
        case 'day':
          periodKey = format(date, 'yyyy-MM-dd');
          break;
        case 'week':
          const weekStart = new Date(date);
          weekStart.setDate(date.getDate() - date.getDay());
          periodKey = format(weekStart, 'yyyy-MM-dd');
          break;
        case 'month':
          periodKey = format(date, 'yyyy-MM');
          break;
        default:
          periodKey = format(date, 'yyyy-MM-dd');
      }

      if (!grouped[periodKey]) {
        grouped[periodKey] = [];
      }
      grouped[periodKey].push(entry);
    });

    // Convert to analytics data
    const analyticsData: AnalyticsData[] = Object.entries(grouped).map(([period, periodEntries]) => {
      const totalTests = periodEntries.length;
      const passedTests = periodEntries.filter(e => e.pass_fail_status === 'pass').length;
      const failedTests = periodEntries.filter(e => e.pass_fail_status === 'fail').length;
      const conformityPercentage = totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0;

      // Calculate average result (for numeric tests)
      const numericResults = periodEntries
        .map(e => {
          const results = e.test_results;
          if (results?.compressive_strength) return parseFloat(results.compressive_strength);
          if (results?.density) return parseFloat(results.density);
          if (results?.value) return parseFloat(results.value);
          return null;
        })
        .filter(v => v !== null);

      const averageResult = numericResults.length > 0 
        ? numericResults.reduce((a, b) => a + b, 0) / numericResults.length
        : 0;

      return {
        period,
        total_tests: totalTests,
        passed_tests: passedTests,
        failed_tests: failedTests,
        conformity_percentage: conformityPercentage,
        average_result: Math.round(averageResult * 100) / 100,
        trend_direction: 'stable' as const // Will be calculated later
      };
    }).sort((a, b) => a.period.localeCompare(b.period));

    // Calculate trend directions
    analyticsData.forEach((data, index) => {
      if (index > 0) {
        const prevConformity = analyticsData[index - 1].conformity_percentage;
        const currentConformity = data.conformity_percentage;
        
        if (currentConformity > prevConformity + 5) {
          data.trend_direction = 'improving';
        } else if (currentConformity < prevConformity - 5) {
          data.trend_direction = 'declining';
        } else {
          data.trend_direction = 'stable';
        }
      }
    });

    return analyticsData;
  };

  const analyzeFailurePatterns = (entries: any[]): FailurePattern[] => {
    const failedEntries = entries.filter(e => e.pass_fail_status === 'fail');
    const fieldFailures: { [field: string]: number } = {};

    failedEntries.forEach(entry => {
      if (entry.test_results) {
        Object.keys(entry.test_results).forEach(field => {
          fieldFailures[field] = (fieldFailures[field] || 0) + 1;
        });
      }
    });

    const patterns: FailurePattern[] = Object.entries(fieldFailures)
      .map(([field, count]) => ({
        field,
        failure_count: count,
        percentage: Math.round((count / failedEntries.length) * 100),
        recent_trend: 'stable' as const // Simplified for now
      }))
      .sort((a, b) => b.failure_count - a.failure_count)
      .slice(0, 10); // Top 10 failure patterns

    return patterns;
  };

  const getUniquePlants = () => {
    const plants = [...new Set(entries.map(e => e.plant_id).filter(Boolean))];
    return plants;
  };

  const getUniqueProductTypes = () => {
    const products = [...new Set(entries.map(e => e.product_type).filter(Boolean))];
    return products;
  };

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case 'improving':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'declining':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      default:
        return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const chartData = analyticsData.map(data => ({
    ...data,
    displayPeriod: groupBy === 'day' ? format(parseISO(data.period), 'MMM dd') :
                   groupBy === 'week' ? format(parseISO(data.period), 'MMM dd') :
                   format(parseISO(data.period + '-01'), 'MMM yyyy')
  }));

  const pieChartData = failurePatterns.slice(0, 5).map((pattern, index) => ({
    name: pattern.field.replace('_', ' '),
    value: pattern.failure_count,
    percentage: pattern.percentage
  }));

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

  const currentConformity = analyticsData.length > 0 
    ? analyticsData[analyticsData.length - 1]?.conformity_percentage || 0
    : 0;

  const totalTests = analyticsData.reduce((sum, data) => sum + data.total_tests, 0);
  const totalPassed = analyticsData.reduce((sum, data) => sum + data.passed_tests, 0);
  const totalFailed = analyticsData.reduce((sum, data) => sum + data.failed_tests, 0);

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Performance Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Time Range</Label>
              <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                  <SelectItem value="1y">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Group By</Label>
              <Select value={groupBy} onValueChange={(value: any) => setGroupBy(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Daily</SelectItem>
                  <SelectItem value="week">Weekly</SelectItem>
                  <SelectItem value="month">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Plant</Label>
              <Select value={selectedPlant} onValueChange={setSelectedPlant}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All plants</SelectItem>
                  {getUniquePlants().map(plant => (
                    <SelectItem key={plant} value={plant}>{plant}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Product Type</Label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All products</SelectItem>
                  {getUniqueProductTypes().map(product => (
                    <SelectItem key={product} value={product}>{product}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Tests</p>
                <p className="text-2xl font-bold">{totalTests}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Conformity Rate</p>
                <p className="text-2xl font-bold">{currentConformity}%</p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Passed Tests</p>
                <p className="text-2xl font-bold text-green-600">{totalPassed}</p>
              </div>
              <div className="flex items-center">
                {getTrendIcon('improving')}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Failed Tests</p>
                <p className="text-2xl font-bold text-red-600">{totalFailed}</p>
              </div>
              <div className="flex items-center">
                {getTrendIcon('declining')}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="conformity" className="space-y-4">
        <TabsList>
          <TabsTrigger value="conformity">Conformity Trends</TabsTrigger>
          <TabsTrigger value="volume">Test Volume</TabsTrigger>
          <TabsTrigger value="failures">Failure Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="conformity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Conformity Percentage Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="displayPeriod" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip 
                    formatter={(value: any, name: string) => [`${value}%`, 'Conformity Rate']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="conformity_percentage" 
                    stroke="#8884d8" 
                    fill="#8884d8" 
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="volume" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Volume Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="displayPeriod" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="passed_tests" stackId="a" fill="#82ca9d" name="Passed" />
                  <Bar dataKey="failed_tests" stackId="a" fill="#ff7c7c" name="Failed" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="failures" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Failure Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={pieChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name}: ${percentage}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Failure Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {failurePatterns.slice(0, 8).map((pattern, index) => (
                    <div key={pattern.field} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium">{pattern.field.replace('_', ' ')}</div>
                        <div className="text-sm text-muted-foreground">
                          {pattern.failure_count} failures
                        </div>
                      </div>
                      <Badge variant="secondary">
                        {pattern.percentage}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}