import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Filter, X, Search, Calendar, Building, User, Settings, Download } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronRight } from 'lucide-react';

interface AdvancedFilteringProps {
  filters: any;
  onFilterChange: (key: string, value: string) => void;
  onClearFilters: () => void;
  onExport: (format: 'csv' | 'excel' | 'pdf') => void;
  loading?: boolean;
}

interface FilterOptions {
  plants: any[];
  productTypes: any[];
  machines: any[];
  operators: any[];
  testTypes: any[];
}

export default function AdvancedFiltering({ 
  filters, 
  onFilterChange, 
  onClearFilters, 
  onExport,
  loading = false 
}: AdvancedFilteringProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    plants: [],
    productTypes: [],
    machines: [],
    operators: [],
    testTypes: []
  });

  // Load filter options from database
  useEffect(() => {
    loadFilterOptions();
  }, []);

  const loadFilterOptions = async () => {
    if (!window.electronAPI) return;

    try {
      const [plantsResult, machinesResult, testDataResult] = await Promise.all([
        window.electronAPI.dbQuery('SELECT * FROM plants WHERE is_active = 1'),
        window.electronAPI.dbQuery('SELECT * FROM machines WHERE is_active = 1'),
        window.electronAPI.dbQuery(`
          SELECT DISTINCT 
            product_type,
            operator,
            test_type
          FROM test_data_entries 
          WHERE product_type IS NOT NULL 
            AND operator IS NOT NULL 
            AND test_type IS NOT NULL
        `)
      ]);

      const uniqueProductTypes = [...new Set(
        testDataResult.data?.map((item: any) => item.product_type).filter(Boolean) || []
      )];
      
      const uniqueOperators = [...new Set(
        testDataResult.data?.map((item: any) => item.operator).filter(Boolean) || []
      )];
      
      const uniqueTestTypes = [...new Set(
        testDataResult.data?.map((item: any) => item.test_type).filter(Boolean) || []
      )];

      setFilterOptions({
        plants: plantsResult.data || [],
        productTypes: uniqueProductTypes,
        machines: machinesResult.data || [],
        operators: uniqueOperators,
        testTypes: uniqueTestTypes
      });
    } catch (error) {
      console.error('Failed to load filter options:', error);
    }
  };

  // Count active filters
  const activeFilterCount = Object.entries(filters).filter(([key, value]) => 
    value && value !== '' && value !== 'all' && key !== 'moduleId'
  ).length;

  const hasActiveFilters = activeFilterCount > 0;

  return (
    <Card>
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger asChild>
          <CardHeader className="pb-4 cursor-pointer hover:bg-muted/50 transition-colors">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Advanced Filters
                {hasActiveFilters && (
                  <Badge variant="secondary" className="ml-2">
                    {activeFilterCount} active
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                {hasActiveFilters && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={(e) => {
                      e.stopPropagation();
                      onClearFilters();
                    }}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear
                  </Button>
                )}
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </div>
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <CardContent className="space-y-6">
            {/* Basic Filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="plant-filter">Plant</Label>
                <Select 
                  value={filters.plant || 'all'} 
                  onValueChange={(value) => onFilterChange('plant', value)}
                >
                  <SelectTrigger id="plant-filter">
                    <SelectValue placeholder="Select plant..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All plants</SelectItem>
                    {filterOptions.plants.map(plant => (
                      <SelectItem key={plant.id} value={plant.id}>
                        <div className="flex items-center gap-2">
                          <Building className="h-4 w-4" />
                          {plant.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="product-type-filter">Product Type</Label>
                <Select 
                  value={filters.productType || 'all'} 
                  onValueChange={(value) => onFilterChange('productType', value)}
                >
                  <SelectTrigger id="product-type-filter">
                    <SelectValue placeholder="Select product..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    {filterOptions.productTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="test-type-filter">Test Type</Label>
                <Select 
                  value={filters.testType || 'all'} 
                  onValueChange={(value) => onFilterChange('testType', value)}
                >
                  <SelectTrigger id="test-type-filter">
                    <SelectValue placeholder="Select test type..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All test types</SelectItem>
                    {filterOptions.testTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="machine-filter">Machine Used</Label>
                <Select 
                  value={filters.machine || 'all'} 
                  onValueChange={(value) => onFilterChange('machine', value)}
                >
                  <SelectTrigger id="machine-filter">
                    <SelectValue placeholder="Select machine..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All machines</SelectItem>
                    {filterOptions.machines.map(machine => (
                      <SelectItem key={machine.id} value={machine.code}>
                        <div className="flex items-center gap-2">
                          <Settings className="h-4 w-4" />
                          {machine.name} ({machine.code})
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            {/* Date and Operator Filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-date-filter">Start Date</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="start-date-filter"
                    type="date"
                    value={filters.startDate || ''}
                    onChange={(e) => onFilterChange('startDate', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-date-filter">End Date</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="end-date-filter"
                    type="date"
                    value={filters.endDate || ''}
                    onChange={(e) => onFilterChange('endDate', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="operator-filter">Operator</Label>
                <Select 
                  value={filters.operator || 'all'} 
                  onValueChange={(value) => onFilterChange('operator', value)}
                >
                  <SelectTrigger id="operator-filter">
                    <SelectValue placeholder="Select operator..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All operators</SelectItem>
                    {filterOptions.operators.map(operator => (
                      <SelectItem key={operator} value={operator}>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4" />
                          {operator}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pass-fail-filter">Pass/Fail Status</Label>
                <Select 
                  value={filters.passFail || 'all'} 
                  onValueChange={(value) => onFilterChange('passFail', value)}
                >
                  <SelectTrigger id="pass-fail-filter">
                    <SelectValue placeholder="Select status..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All statuses</SelectItem>
                    <SelectItem value="pass">Pass</SelectItem>
                    <SelectItem value="fail">Fail</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            {/* Advanced Result Range Filters */}
            <div className="space-y-4">
              <Label className="text-sm font-medium">Result Range Filters</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="compressive-strength-min" className="text-xs">
                    Compressive Strength (MPa)
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="compressive-strength-min"
                      type="number"
                      placeholder="Min"
                      value={filters.compressiveStrengthMin || ''}
                      onChange={(e) => onFilterChange('compressiveStrengthMin', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Max"
                      value={filters.compressiveStrengthMax || ''}
                      onChange={(e) => onFilterChange('compressiveStrengthMax', e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="density-min" className="text-xs">
                    Density (kg/m³)
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="density-min"
                      type="number"
                      placeholder="Min"
                      value={filters.densityMin || ''}
                      onChange={(e) => onFilterChange('densityMin', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Max"
                      value={filters.densityMax || ''}
                      onChange={(e) => onFilterChange('densityMax', e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="silt-content-max" className="text-xs">
                    Silt Content (%)
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="silt-content-min"
                      type="number"
                      placeholder="Min"
                      value={filters.siltContentMin || ''}
                      onChange={(e) => onFilterChange('siltContentMin', e.target.value)}
                    />
                    <Input
                      type="number"
                      placeholder="Max"
                      value={filters.siltContentMax || ''}
                      onChange={(e) => onFilterChange('siltContentMax', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Search and Export */}
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1 space-y-2">
                <Label htmlFor="search-filter">Search</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search-filter"
                    placeholder="Search in memo reference, batch ID, notes..."
                    value={filters.search || ''}
                    onChange={(e) => onFilterChange('search', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onExport('csv')}
                  disabled={loading}
                >
                  <Download className="h-4 w-4 mr-2" />
                  CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onExport('excel')}
                  disabled={loading}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Excel
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onExport('pdf')}
                  disabled={loading}
                >
                  <Download className="h-4 w-4 mr-2" />
                  PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}