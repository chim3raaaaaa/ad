import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Brain, TrendingUp, AlertTriangle, CheckCircle, Lightbulb, Target, Zap, Activity } from 'lucide-react';
import { toast } from 'sonner';

interface PredictiveAssistantProps {
  entries: any[];
  selectedEntries: string[];
}

interface Prediction {
  id: string;
  test_id: string;
  prediction_type: 'failure_risk' | 'quality_score' | 'trend_forecast';
  prediction_value: number;
  confidence_level: number;
  prediction_factors: string[];
  recommendation: string;
  prediction_date: string;
}

interface Recommendation {
  type: 'action' | 'investigation' | 'monitoring';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  title: string;
  description: string;
  entry_id?: string;
  confidence: number;
}

export default function PredictiveAssistant({ entries, selectedEntries }: PredictiveAssistantProps) {
  const [enabled, setEnabled] = useState(true);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [modelVersion, setModelVersion] = useState('1.0');

  useEffect(() => {
    if (enabled && entries.length > 0) {
      runPredictiveAnalysis();
    }
  }, [entries, enabled]);

  const runPredictiveAnalysis = async () => {
    setAnalyzing(true);
    
    try {
      // Get entries to analyze
      const entriesToAnalyze = selectedEntries.length > 0
        ? entries.filter(e => selectedEntries.includes(e.id))
        : entries.slice(-20); // Last 20 entries if none selected

      const newPredictions: Prediction[] = [];
      const newRecommendations: Recommendation[] = [];

      // Run different prediction models
      for (const entry of entriesToAnalyze) {
        // Failure Risk Prediction
        const failureRisk = calculateFailureRisk(entry);
        if (failureRisk.value > 0.3) {
          newPredictions.push({
            id: `pred-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            test_id: entry.id,
            prediction_type: 'failure_risk',
            prediction_value: failureRisk.value,
            confidence_level: failureRisk.confidence,
            prediction_factors: failureRisk.factors,
            recommendation: failureRisk.recommendation,
            prediction_date: new Date().toISOString()
          });
        }

        // Quality Score Prediction
        const qualityScore = calculateQualityScore(entry);
        newPredictions.push({
          id: `pred-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          test_id: entry.id,
          prediction_type: 'quality_score',
          prediction_value: qualityScore.value,
          confidence_level: qualityScore.confidence,
          prediction_factors: qualityScore.factors,
          recommendation: qualityScore.recommendation,
          prediction_date: new Date().toISOString()
        });
      }

      // Generate system-wide recommendations
      const systemRecommendations = generateSystemRecommendations(entries);
      newRecommendations.push(...systemRecommendations);

      setPredictions(newPredictions);
      setRecommendations(newRecommendations);

      // Save predictions to database
      await savePredictionsToDatabase(newPredictions);

    } catch (error) {
      console.error('Error running predictive analysis:', error);
      toast.error('Failed to run predictive analysis');
    } finally {
      setAnalyzing(false);
    }
  };

  const calculateFailureRisk = (entry: any) => {
    const factors: string[] = [];
    let riskScore = 0;
    let confidence = 0.7;

    const testResults = entry.test_results || {};

    // Check for historical failure patterns
    if (entry.pass_fail_status === 'fail') {
      riskScore += 0.4;
      factors.push('Previous failure recorded');
    }

    // Check test result values against thresholds
    Object.entries(testResults).forEach(([key, value]: [string, any]) => {
      if (typeof value === 'number') {
        // Simplified rule-based risk assessment
        if (key.includes('strength') && value < 25) {
          riskScore += 0.3;
          factors.push('Low compressive strength detected');
        }
        if (key.includes('density') && (value < 2000 || value > 2600)) {
          riskScore += 0.2;
          factors.push('Density outside normal range');
        }
        if (key.includes('silt') && value > 3) {
          riskScore += 0.25;
          factors.push('High silt content');
        }
      }
    });

    // Check operator consistency
    const operatorHistory = entries.filter(e => e.operator === entry.operator);
    const operatorFailureRate = operatorHistory.filter(e => e.pass_fail_status === 'fail').length / operatorHistory.length;
    if (operatorFailureRate > 0.2) {
      riskScore += 0.15;
      factors.push('Operator has higher failure rate');
    }

    // Check machine reliability
    if (entry.machine_used) {
      const machineHistory = entries.filter(e => e.machine_used === entry.machine_used);
      const machineFailureRate = machineHistory.filter(e => e.pass_fail_status === 'fail').length / machineHistory.length;
      if (machineFailureRate > 0.3) {
        riskScore += 0.1;
        factors.push('Machine reliability concerns');
      }
    }

    // Cap risk score at 1.0
    riskScore = Math.min(riskScore, 1.0);

    let recommendation = '';
    if (riskScore > 0.7) {
      recommendation = 'High risk detected. Recommend immediate re-testing and quality review.';
    } else if (riskScore > 0.5) {
      recommendation = 'Moderate risk. Consider additional quality checks and monitoring.';
    } else if (riskScore > 0.3) {
      recommendation = 'Low to moderate risk. Continue monitoring and ensure proper procedures.';
    } else {
      recommendation = 'Low risk. Test results within expected parameters.';
    }

    return {
      value: riskScore,
      confidence,
      factors,
      recommendation
    };
  };

  const calculateQualityScore = (entry: any) => {
    const factors: string[] = [];
    let qualityScore = 0.5; // Base score
    let confidence = 0.8;

    const testResults = entry.test_results || {};

    // Positive quality indicators
    if (entry.pass_fail_status === 'pass') {
      qualityScore += 0.3;
      factors.push('Test passed conformity check');
    }

    // Check result consistency
    Object.entries(testResults).forEach(([key, value]: [string, any]) => {
      if (typeof value === 'number') {
        // Award points for results within optimal ranges
        if (key.includes('strength') && value >= 30 && value <= 50) {
          qualityScore += 0.2;
          factors.push('Excellent compressive strength');
        }
        if (key.includes('density') && value >= 2300 && value <= 2500) {
          qualityScore += 0.15;
          factors.push('Optimal density achieved');
        }
        if (key.includes('silt') && value <= 1.5) {
          qualityScore += 0.1;
          factors.push('Low silt content - excellent');
        }
      }
    });

    // Check batch consistency
    const batchEntries = entries.filter(e => e.batch_id === entry.batch_id);
    if (batchEntries.length > 1) {
      const passRate = batchEntries.filter(e => e.pass_fail_status === 'pass').length / batchEntries.length;
      if (passRate >= 0.9) {
        qualityScore += 0.1;
        factors.push('Consistent batch quality');
      }
    }

    // Cap quality score at 1.0
    qualityScore = Math.min(qualityScore, 1.0);

    let recommendation = '';
    if (qualityScore >= 0.8) {
      recommendation = 'Excellent quality. Use as reference standard for future tests.';
    } else if (qualityScore >= 0.6) {
      recommendation = 'Good quality. Minor improvements possible through process optimization.';
    } else if (qualityScore >= 0.4) {
      recommendation = 'Average quality. Review testing procedures and material sources.';
    } else {
      recommendation = 'Poor quality detected. Immediate investigation and corrective action required.';
    }

    return {
      value: qualityScore,
      confidence,
      factors,
      recommendation
    };
  };

  const generateSystemRecommendations = (allEntries: any[]): Recommendation[] => {
    const recommendations: Recommendation[] = [];

    // Analyze overall trends
    const recentEntries = allEntries.slice(-30); // Last 30 entries
    const recentFailureRate = recentEntries.filter(e => e.pass_fail_status === 'fail').length / recentEntries.length;

    if (recentFailureRate > 0.2) {
      recommendations.push({
        type: 'investigation',
        priority: 'high',
        title: 'Elevated Failure Rate Detected',
        description: `Recent failure rate is ${Math.round(recentFailureRate * 100)}%, which is above the 20% threshold. Investigate common causes and review quality control procedures.`,
        confidence: 0.9
      });
    }

    // Check for machine-specific issues
    const machinePerformance = new Map<string, { total: number; failures: number }>();
    allEntries.forEach(entry => {
      if (entry.machine_used) {
        const current = machinePerformance.get(entry.machine_used) || { total: 0, failures: 0 };
        current.total++;
        if (entry.pass_fail_status === 'fail') current.failures++;
        machinePerformance.set(entry.machine_used, current);
      }
    });

    machinePerformance.forEach((performance, machine) => {
      const failureRate = performance.failures / performance.total;
      if (failureRate > 0.3 && performance.total >= 10) {
        recommendations.push({
          type: 'action',
          priority: 'medium',
          title: `Machine ${machine} Performance Issue`,
          description: `Machine ${machine} has a failure rate of ${Math.round(failureRate * 100)}%. Consider maintenance or calibration.`,
          confidence: 0.8
        });
      }
    });

    // Check for operator training needs
    const operatorPerformance = new Map<string, { total: number; failures: number }>();
    allEntries.forEach(entry => {
      if (entry.operator) {
        const current = operatorPerformance.get(entry.operator) || { total: 0, failures: 0 };
        current.total++;
        if (entry.pass_fail_status === 'fail') current.failures++;
        operatorPerformance.set(entry.operator, current);
      }
    });

    operatorPerformance.forEach((performance, operator) => {
      const failureRate = performance.failures / performance.total;
      if (failureRate > 0.25 && performance.total >= 15) {
        recommendations.push({
          type: 'action',
          priority: 'medium',
          title: `Training Needed for ${operator}`,
          description: `${operator} has a higher than average failure rate (${Math.round(failureRate * 100)}%). Consider additional training or procedure review.`,
          confidence: 0.7
        });
      }
    });

    // Seasonal or temporal patterns
    const currentMonth = new Date().getMonth();
    const currentMonthEntries = allEntries.filter(e => new Date(e.test_date).getMonth() === currentMonth);
    if (currentMonthEntries.length >= 20) {
      const monthlyFailureRate = currentMonthEntries.filter(e => e.pass_fail_status === 'fail').length / currentMonthEntries.length;
      if (monthlyFailureRate > 0.3) {
        recommendations.push({
          type: 'monitoring',
          priority: 'low',
          title: 'Seasonal Quality Pattern',
          description: `Current month shows elevated failure rate (${Math.round(monthlyFailureRate * 100)}%). Monitor for seasonal environmental factors affecting quality.`,
          confidence: 0.6
        });
      }
    }

    return recommendations;
  };

  const savePredictionsToDatabase = async (predictions: Prediction[]) => {
    if (!window.electronAPI) return;

    try {
      for (const prediction of predictions) {
        await window.electronAPI.dbRun(`
          INSERT INTO test_predictions (
            id, test_id, prediction_type, prediction_value, confidence_level,
            prediction_factors, recommendation, prediction_date, model_version
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          prediction.id,
          prediction.test_id,
          prediction.prediction_type,
          prediction.prediction_value,
          prediction.confidence_level,
          JSON.stringify(prediction.prediction_factors),
          prediction.recommendation,
          prediction.prediction_date,
          modelVersion
        ]);
      }
    } catch (error) {
      console.error('Failed to save predictions:', error);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent': return <AlertTriangle className="h-4 w-4" />;
      case 'high': return <TrendingUp className="h-4 w-4" />;
      case 'medium': return <Target className="h-4 w-4" />;
      case 'low': return <Activity className="h-4 w-4" />;
      default: return <CheckCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Predictive Assistant
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="ai-assistant"
                  checked={enabled}
                  onCheckedChange={setEnabled}
                />
                <Label htmlFor="ai-assistant">Enable AI Analysis</Label>
              </div>
              <Button
                onClick={runPredictiveAnalysis}
                disabled={!enabled || analyzing}
                size="sm"
              >
                <Zap className="h-4 w-4 mr-2" />
                {analyzing ? 'Analyzing...' : 'Analyze'}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {enabled && (
        <Tabs defaultValue="predictions" className="space-y-4">
          <TabsList>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="predictions" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {predictions.map(prediction => (
                <Card key={prediction.id}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="capitalize">
                        {prediction.prediction_type.replace('_', ' ')}
                      </Badge>
                      <Badge variant="secondary">
                        {Math.round(prediction.confidence_level * 100)}% confident
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {prediction.prediction_type === 'failure_risk' ? 'Failure Risk' :
                           prediction.prediction_type === 'quality_score' ? 'Quality Score' :
                           'Trend Forecast'}
                        </span>
                        <span className="text-lg font-bold">
                          {Math.round(prediction.prediction_value * 100)}%
                        </span>
                      </div>
                      <Progress 
                        value={prediction.prediction_value * 100} 
                        className={`h-2 ${
                          prediction.prediction_type === 'failure_risk' 
                            ? prediction.prediction_value > 0.7 ? 'bg-red-100' : 'bg-yellow-100'
                            : 'bg-green-100'
                        }`}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium">Contributing Factors:</div>
                      <div className="space-y-1">
                        {prediction.prediction_factors.map((factor, index) => (
                          <div key={index} className="text-xs text-muted-foreground flex items-center gap-2">
                            <div className="w-1 h-1 bg-current rounded-full" />
                            {factor}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="text-sm font-medium mb-1">Recommendation:</div>
                      <div className="text-sm text-muted-foreground">
                        {prediction.recommendation}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {predictions.length === 0 && !analyzing && (
              <Card>
                <CardContent className="text-center py-8">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No predictions available</p>
                  <p className="text-sm text-muted-foreground">
                    Run analysis to generate predictions for your test data
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            <div className="space-y-3">
              {recommendations.map((recommendation, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0">
                        <Badge variant="outline" className={getPriorityColor(recommendation.priority)}>
                          {getPriorityIcon(recommendation.priority)}
                          {recommendation.priority.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="font-medium">{recommendation.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {recommendation.description}
                        </div>
                        <div className="flex items-center gap-2 pt-1">
                          <Badge variant="secondary" className="text-xs">
                            {recommendation.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(recommendation.confidence * 100)}% confidence
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {recommendations.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <Lightbulb className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No recommendations at this time</p>
                  <p className="text-sm text-muted-foreground">
                    The system will provide recommendations as patterns are detected
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="insights" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {predictions.filter(p => p.prediction_type === 'failure_risk' && p.prediction_value > 0.5).length}
                  </div>
                  <div className="text-sm text-muted-foreground">High Risk Tests</div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {predictions.filter(p => p.prediction_type === 'quality_score' && p.prediction_value > 0.8).length}
                  </div>
                  <div className="text-sm text-muted-foreground">High Quality Tests</div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {recommendations.filter(r => r.priority === 'high' || r.priority === 'urgent').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Priority Actions</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>AI Model Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Model Version:</span> {modelVersion}
                  </div>
                  <div>
                    <span className="font-medium">Last Analysis:</span> {analyzing ? 'Running...' : 'Just now'}
                  </div>
                  <div>
                    <span className="font-medium">Predictions Generated:</span> {predictions.length}
                  </div>
                  <div>
                    <span className="font-medium">Data Points Analyzed:</span> {entries.length}
                  </div>
                </div>
                
                <div className="text-xs text-muted-foreground pt-2 border-t">
                  <p>
                    This predictive assistant uses rule-based analysis and pattern recognition to identify potential quality issues and provide recommendations. 
                    Predictions are based on historical data patterns and should be used as guidance alongside expert judgment.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {!enabled && (
        <Card>
          <CardContent className="text-center py-8">
            <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-lg font-medium">AI Assistant Disabled</p>
            <p className="text-sm text-muted-foreground">
              Enable the AI assistant to get predictions and recommendations for your test data
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}