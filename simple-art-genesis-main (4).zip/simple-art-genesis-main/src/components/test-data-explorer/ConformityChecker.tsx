import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, AlertTriangle, XCircle, Info, Zap, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface ConformityCheckerProps {
  entries: any[];
  selectedEntries: string[];
}

interface ConformityCheck {
  id: string;
  test_id: string;
  check_result: 'pass' | 'fail' | 'warning';
  failed_fields: string[];
  rule_set: string;
  rule_details: any;
  checked_by: string;
  checked_at: string;
}

interface TestStandard {
  id: string;
  standard_name: string;
  product_type: string;
  test_type: string;
  rules: any;
}

export default function ConformityChecker({ entries, selectedEntries }: ConformityCheckerProps) {
  const [standards, setStandards] = useState<TestStandard[]>([]);
  const [selectedStandard, setSelectedStandard] = useState<string>('');
  const [conformityResults, setConformityResults] = useState<ConformityCheck[]>([]);
  const [checking, setChecking] = useState(false);
  const [autoCheck, setAutoCheck] = useState(true);

  useEffect(() => {
    loadTestStandards();
    loadExistingChecks();
  }, []);

  useEffect(() => {
    if (autoCheck && selectedStandard && entries.length > 0) {
      runConformityChecks();
    }
  }, [selectedStandard, entries, autoCheck]);

  const loadTestStandards = async () => {
    if (!window.electronAPI) return;

    try {
      // First, ensure default standards exist
      await initializeDefaultStandards();
      
      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_standards 
        WHERE is_active = 1
        ORDER BY standard_name, product_type
      `);

      if (result.data) {
        setStandards(result.data.map((std: any) => ({
          ...std,
          rules: JSON.parse(std.rules)
        })));
      }
    } catch (error) {
      console.error('Failed to load test standards:', error);
    }
  };

  const initializeDefaultStandards = async () => {
    if (!window.electronAPI) return;

    const defaultStandards = [
      {
        id: 'std-bs-aggregates-silt',
        standard_name: 'BS',
        product_type: 'Aggregates',
        test_type: 'Silt & Clay content',
        rules: {
          silt_content: { min: 0, max: 3, unit: '%', description: 'Silt content by mass' },
          clay_content: { min: 0, max: 2, unit: '%', description: 'Clay content by mass' },
          total_fines: { min: 0, max: 5, unit: '%', description: 'Total fines content' }
        }
      },
      {
        id: 'std-bs-concrete-compressive',
        standard_name: 'BS',
        product_type: 'Concrete',
        test_type: 'Compressive Strength',
        rules: {
          compressive_strength: { min: 25, max: 100, unit: 'MPa', description: '28-day compressive strength' },
          density: { min: 2200, max: 2600, unit: 'kg/m³', description: 'Concrete density' }
        }
      },
      {
        id: 'std-ubp-blocks-density',
        standard_name: 'UBP',
        product_type: 'Blocks',
        test_type: 'Density Test',
        rules: {
          density: { min: 1800, max: 2400, unit: 'kg/m³', description: 'Block density' },
          compressive_strength: { min: 15, max: 50, unit: 'MPa', description: 'Block compressive strength' }
        }
      }
    ];

    for (const standard of defaultStandards) {
      try {
        await window.electronAPI.dbRun(`
          INSERT OR IGNORE INTO test_standards 
          (id, standard_name, product_type, test_type, rules, is_active)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [
          standard.id,
          standard.standard_name,
          standard.product_type,
          standard.test_type,
          JSON.stringify(standard.rules),
          1
        ]);
      } catch (error) {
        console.error('Failed to insert default standard:', error);
      }
    }
  };

  const loadExistingChecks = async () => {
    if (!window.electronAPI) return;

    try {
      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_conformity_checks 
        ORDER BY checked_at DESC
      `);

      if (result.data) {
        setConformityResults(result.data.map((check: any) => ({
          ...check,
          failed_fields: JSON.parse(check.failed_fields || '[]'),
          rule_details: JSON.parse(check.rule_details || '{}')
        })));
      }
    } catch (error) {
      console.error('Failed to load existing conformity checks:', error);
    }
  };

  const runConformityChecks = async () => {
    if (!selectedStandard || entries.length === 0) return;

    setChecking(true);
    try {
      const standard = standards.find(s => s.id === selectedStandard);
      if (!standard) return;

      const entriesToCheck = selectedEntries.length > 0 
        ? entries.filter(e => selectedEntries.includes(e.id))
        : entries;

      const newResults: ConformityCheck[] = [];

      for (const entry of entriesToCheck) {
        const checkResult = checkConformity(entry, standard);
        
        // Save to database
        const checkId = `check-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        await window.electronAPI.dbRun(`
          INSERT OR REPLACE INTO test_conformity_checks 
          (id, test_id, check_result, failed_fields, rule_set, rule_details, checked_by, checked_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          checkId,
          entry.id,
          checkResult.result,
          JSON.stringify(checkResult.failedFields),
          standard.standard_name,
          JSON.stringify(standard.rules),
          'current_user', // Should get from auth context
          new Date().toISOString()
        ]);

        newResults.push({
          id: checkId,
          test_id: entry.id,
          check_result: checkResult.result,
          failed_fields: checkResult.failedFields,
          rule_set: standard.standard_name,
          rule_details: standard.rules,
          checked_by: 'current_user',
          checked_at: new Date().toISOString()
        });
      }

      setConformityResults(prev => [
        ...newResults,
        ...prev.filter(r => !newResults.find(nr => nr.test_id === r.test_id))
      ]);

      toast.success(`Conformity check completed for ${newResults.length} entries`);
    } catch (error) {
      console.error('Failed to run conformity checks:', error);
      toast.error('Failed to run conformity checks');
    } finally {
      setChecking(false);
    }
  };

  const checkConformity = (entry: any, standard: TestStandard) => {
    const failedFields: string[] = [];
    const warnings: string[] = [];
    let result: 'pass' | 'fail' | 'warning' = 'pass';

    const testResults = entry.test_results || {};

    Object.entries(standard.rules).forEach(([fieldName, rule]: [string, any]) => {
      const value = testResults[fieldName];
      
      if (value === null || value === undefined) {
        warnings.push(fieldName);
        if (result !== 'fail') result = 'warning';
        return;
      }

      const numValue = parseFloat(value);
      if (isNaN(numValue)) {
        warnings.push(fieldName);
        if (result !== 'fail') result = 'warning';
        return;
      }

      if (rule.min !== undefined && numValue < rule.min) {
        failedFields.push(fieldName);
        result = 'fail';
      }

      if (rule.max !== undefined && numValue > rule.max) {
        failedFields.push(fieldName);
        result = 'fail';
      }

      // Check for warning thresholds (within 10% of limits)
      if (rule.min !== undefined && numValue < rule.min * 1.1 && !failedFields.includes(fieldName)) {
        warnings.push(fieldName);
        if (result !== 'fail') result = 'warning';
      }

      if (rule.max !== undefined && numValue > rule.max * 0.9 && !failedFields.includes(fieldName)) {
        warnings.push(fieldName);
        if (result !== 'fail') result = 'warning';
      }
    });

    return {
      result,
      failedFields: [...failedFields, ...warnings],
      details: {
        failed: failedFields,
        warnings,
        standard: standard.standard_name
      }
    };
  };

  const getConformityResultForEntry = (entryId: string) => {
    return conformityResults.find(r => r.test_id === entryId);
  };

  const renderConformityBadge = (entry: any) => {
    const result = getConformityResultForEntry(entry.id);
    
    if (!result) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <Badge variant="secondary">
                <Info className="h-3 w-3 mr-1" />
                Not Checked
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Conformity not checked yet</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    const icon = result.check_result === 'pass' ? CheckCircle :
                 result.check_result === 'warning' ? AlertTriangle : XCircle;

    const variant = result.check_result === 'pass' ? 'default' :
                   result.check_result === 'warning' ? 'secondary' : 'destructive';

    const IconComponent = icon;

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <Badge variant={variant} className={
              result.check_result === 'pass' ? 'bg-green-100 text-green-800 border-green-300' :
              result.check_result === 'warning' ? 'bg-yellow-100 text-yellow-800 border-yellow-300' :
              'bg-red-100 text-red-800 border-red-300'
            }>
              <IconComponent className="h-3 w-3 mr-1" />
              {result.check_result.toUpperCase()}
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <div className="space-y-1">
              <p className="font-medium">{result.rule_set} Standard Check</p>
              {result.failed_fields.length > 0 && (
                <p>Failed fields: {result.failed_fields.join(', ')}</p>
              )}
              <p className="text-xs">
                Checked: {format(new Date(result.checked_at), 'MMM dd, HH:mm')}
              </p>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };

  const calculateOverallConformity = () => {
    if (conformityResults.length === 0) return 0;
    
    const passCount = conformityResults.filter(r => r.check_result === 'pass').length;
    return Math.round((passCount / conformityResults.length) * 100);
  };

  return (
    <div className="space-y-6">
      {/* Conformity Checker Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Conformity Checker
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Test Standard</Label>
              <Select value={selectedStandard} onValueChange={setSelectedStandard}>
                <SelectTrigger>
                  <SelectValue placeholder="Select standard..." />
                </SelectTrigger>
                <SelectContent>
                  {standards.map(standard => (
                    <SelectItem key={standard.id} value={standard.id}>
                      {standard.standard_name} - {standard.product_type} ({standard.test_type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end gap-2">
              <Button 
                onClick={runConformityChecks}
                disabled={!selectedStandard || checking}
                className="flex-1"
              >
                <Zap className="h-4 w-4 mr-2" />
                {checking ? 'Checking...' : 'Run Check'}
              </Button>
            </div>
          </div>

          {/* Overall Conformity Stats */}
          {conformityResults.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {conformityResults.filter(r => r.check_result === 'pass').length}
                </div>
                <div className="text-sm text-muted-foreground">Passed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">
                  {conformityResults.filter(r => r.check_result === 'warning').length}
                </div>
                <div className="text-sm text-muted-foreground">Warnings</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {conformityResults.filter(r => r.check_result === 'fail').length}
                </div>
                <div className="text-sm text-muted-foreground">Failed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {calculateOverallConformity()}%
                </div>
                <div className="text-sm text-muted-foreground">Conformity</div>
              </div>
            </div>
          )}

          {/* Conformity Progress Bar */}
          {conformityResults.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Conformity</span>
                <span>{calculateOverallConformity()}%</span>
              </div>
              <Progress value={calculateOverallConformity()} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Conformity Results for Each Entry */}
      <Card>
        <CardHeader>
          <CardTitle>Test Entry Conformity Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {entries.map(entry => (
              <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="font-medium">
                    {entry.batch_id || entry.id.slice(0, 8)} - {entry.test_type}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {format(new Date(entry.test_date), 'MMM dd, yyyy')} • {entry.operator}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {renderConformityBadge(entry)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Selected Standard Rules */}
      {selectedStandard && (
        <Card>
          <CardHeader>
            <CardTitle>Standard Rules</CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const standard = standards.find(s => s.id === selectedStandard);
              if (!standard) return null;

              return (
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground mb-3">
                    {standard.standard_name} - {standard.product_type} ({standard.test_type})
                  </div>
                  {Object.entries(standard.rules).map(([field, rule]: [string, any]) => (
                    <div key={field} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium">{field.replace('_', ' ')}</div>
                        <div className="text-sm text-muted-foreground">{rule.description}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-sm">
                          {rule.min !== undefined && rule.max !== undefined 
                            ? `${rule.min} - ${rule.max} ${rule.unit}`
                            : rule.min !== undefined 
                              ? `≥ ${rule.min} ${rule.unit}`
                              : `≤ ${rule.max} ${rule.unit}`
                          }
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}
    </div>
  );
}