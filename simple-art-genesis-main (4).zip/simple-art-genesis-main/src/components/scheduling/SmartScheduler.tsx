import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  CalendarDays, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Calendar as CalendarIcon,
  Zap,
  Users,
  Wrench
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { smartSchedulingService, type TestScheduleRequest, type ScheduledTest } from '@/services/scheduling/smartSchedulingService';
import { toast } from '@/hooks/use-toast';

interface SmartSchedulerProps {
  memoId?: string;
  onScheduled?: (scheduledTest: ScheduledTest) => void;
}

export function SmartScheduler({ memoId, onScheduled }: SmartSchedulerProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [scheduleRequest, setScheduleRequest] = useState<Partial<TestScheduleRequest>>({
    priority: 'medium',
    estimatedDuration: 2
  });
  const [suggestedDate, setSuggestedDate] = useState<Date>();
  const [scheduledTests, setScheduledTests] = useState<ScheduledTest[]>([]);

  useEffect(() => {
    if (open) {
      loadScheduledTests();
    }
  }, [open]);

  const loadScheduledTests = async () => {
    try {
      const today = new Date();
      const nextWeek = new Date();
      nextWeek.setDate(today.getDate() + 7);
      
      const tests = await smartSchedulingService.getScheduleForDateRange(
        today.toISOString().split('T')[0],
        nextWeek.toISOString().split('T')[0]
      );
      setScheduledTests(tests);
    } catch (error) {
      console.error('Error loading scheduled tests:', error);
    }
  };

  const handleSchedule = async () => {
    if (!scheduleRequest.memoId || !scheduleRequest.testType || !scheduleRequest.productionDate) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const result = await smartSchedulingService.scheduleTest(scheduleRequest as TestScheduleRequest);
      if (result) {
        onScheduled?.(result);
        setOpen(false);
        setScheduleRequest({ priority: 'medium', estimatedDuration: 2 });
        toast({
          title: 'Test Scheduled',
          description: `Test scheduled for ${result.scheduledDate} at ${result.scheduledTime}`,
        });
      }
    } catch (error) {
      console.error('Error scheduling test:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBatchSchedule = async () => {
    setLoading(true);
    try {
      const result = await smartSchedulingService.batchScheduleFromMemos();
      toast({
        title: 'Batch Scheduling Complete',
        description: `Scheduled ${result.scheduled} tests, ${result.failed} failed`,
      });
      loadScheduledTests();
    } catch (error) {
      console.error('Error in batch scheduling:', error);
    } finally {
      setLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'in_progress': return Clock;
      case 'scheduled': return CalendarDays;
      default: return AlertTriangle;
    }
  };

  return (
    <div className="space-y-4">
      {/* Quick Actions */}
      <div className="flex gap-2">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Zap className="h-4 w-4" />
              Smart Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Smart Test Scheduler
              </DialogTitle>
              <DialogDescription>
                AI-powered scheduling based on lab capacity and priority
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="memoId">Memo ID</Label>
                <Input
                  id="memoId"
                  value={scheduleRequest.memoId || memoId || ''}
                  onChange={(e) => setScheduleRequest(prev => ({ ...prev, memoId: e.target.value }))}
                  placeholder="Enter memo ID"
                />
              </div>

              <div>
                <Label htmlFor="testType">Test Type</Label>
                <Select onValueChange={(value) => setScheduleRequest(prev => ({ ...prev, testType: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select test type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compression">Compression Test</SelectItem>
                    <SelectItem value="flexural">Flexural Test</SelectItem>
                    <SelectItem value="aggregate">Aggregate Analysis</SelectItem>
                    <SelectItem value="concrete">Concrete Test</SelectItem>
                    <SelectItem value="block">Block Test</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Production Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !scheduleRequest.productionDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {scheduleRequest.productionDate ? (
                        format(new Date(scheduleRequest.productionDate), 'PPP')
                      ) : (
                        <span>Pick production date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={scheduleRequest.productionDate ? new Date(scheduleRequest.productionDate) : undefined}
                      onSelect={(date) => setScheduleRequest(prev => ({ 
                        ...prev, 
                        productionDate: date?.toISOString().split('T')[0] 
                      }))}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select 
                  value={scheduleRequest.priority} 
                  onValueChange={(value: any) => setScheduleRequest(prev => ({ ...prev, priority: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="duration">Estimated Duration (hours)</Label>
                <Input
                  id="duration"
                  type="number"
                  min="1"
                  max="8"
                  value={scheduleRequest.estimatedDuration || 2}
                  onChange={(e) => setScheduleRequest(prev => ({ 
                    ...prev, 
                    estimatedDuration: Number(e.target.value) 
                  }))}
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSchedule} disabled={loading}>
                  {loading ? 'Scheduling...' : 'Schedule Test'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Button variant="outline" onClick={handleBatchSchedule} disabled={loading} className="gap-2">
          <Users className="h-4 w-4" />
          Batch Schedule
        </Button>
      </div>

      {/* Upcoming Tests */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <CalendarDays className="h-5 w-5" />
            Upcoming Tests (Next 7 Days)
          </CardTitle>
          <CardDescription>
            Smart-scheduled tests based on production dates and lab capacity
          </CardDescription>
        </CardHeader>
        <CardContent>
          {scheduledTests.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarDays className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No tests scheduled</p>
              <p className="text-sm">Use Smart Schedule to automatically plan tests</p>
            </div>
          ) : (
            <div className="space-y-3">
              {scheduledTests.map((test) => {
                const StatusIcon = getStatusIcon(test.status);
                return (
                  <div
                    key={test.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <StatusIcon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="font-medium">{test.testType}</div>
                        <div className="text-sm text-muted-foreground">
                          Memo: {test.memoId}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={getPriorityColor(test.priority) as any}>
                        {test.priority}
                      </Badge>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {format(new Date(test.scheduledDate), 'MMM dd')}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {test.scheduledTime}
                        </div>
                      </div>
                      {test.autoScheduled && (
                        <Zap className="h-3 w-3 text-primary" />
                      )}
                      {test.conflictLevel !== 'none' && (
                        <AlertTriangle 
                          className={cn(
                            "h-3 w-3",
                            test.conflictLevel === 'major' ? 'text-destructive' : 'text-warning'
                          )} 
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}