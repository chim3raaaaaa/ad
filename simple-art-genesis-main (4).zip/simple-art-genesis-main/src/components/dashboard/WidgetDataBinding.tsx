import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertTriangle, BarChart3, PieChart, LineChart, TrendingUp, Gauge, Grid, GitBranch } from 'lucide-react';
import type { DashboardWidget } from '@/types/dashboard';

interface WidgetConfig {
  widget_type: 'kpi' | 'bar' | 'pie' | 'line' | 'scatter' | 'gauge' | 'heatmap';
  source_table: string;
  x_field?: string;
  y_field?: string;
  aggregation?: 'count' | 'sum' | 'avg' | 'max' | 'min';
  filters?: Record<string, string>;
  group_by?: string;
  label?: string;
  // Additional fields for advanced widgets
  z_field?: string; // For heatmaps and scatter plots
  min_value?: number; // For gauges
  max_value?: number; // For gauges
  thresholds?: { low: number; medium: number; high: number }; // For gauges
}

interface WidgetDataBindingProps {
  widgetType: 'kpi' | 'bar' | 'pie' | 'line' | 'scatter' | 'gauge' | 'heatmap';
  onSave: (widget: DashboardWidget) => void;
  onCancel: () => void;
}

export function WidgetDataBinding({ widgetType, onSave, onCancel }: WidgetDataBindingProps) {
  const [config, setConfig] = useState<WidgetConfig>({
    widget_type: widgetType,
    source_table: '',
    aggregation: 'count'
  });
  const [availableTables, setAvailableTables] = useState<string[]>([]);
  const [availableColumns, setAvailableColumns] = useState<string[]>([]);
  const [preview, setPreview] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAvailableTables();
  }, []);

  useEffect(() => {
    if (config.source_table) {
      loadTableColumns(config.source_table);
    }
  }, [config.source_table]);

  const loadAvailableTables = async () => {
    try {
      // Get list of tables from SQLite
      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      
      if (isElectron) {
        const result = await window.electronAPI.dbQuery(
          "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'", 
          []
        );
        if (result.success) {
          setAvailableTables(result.data.map((row: any) => row.name));
        }
      } else {
        // Fallback for browser - use known tables
        setAvailableTables(['memos', 'test_results', 'test_requests', 'reference_data']);
      }
    } catch (error) {
      console.error('Error loading tables:', error);
      setAvailableTables(['memos', 'test_results', 'test_requests']);
    }
  };

  const loadTableColumns = async (tableName: string) => {
    try {
      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      
      if (isElectron) {
        const result = await window.electronAPI.dbQuery(`PRAGMA table_info(${tableName})`, []);
        if (result.success) {
          setAvailableColumns(result.data.map((row: any) => row.name));
        }
      } else {
        // Fallback column names based on table
        const fallbackColumns: Record<string, string[]> = {
          memos: ['id', 'title', 'content', 'created_at', 'user_id', 'status'],
          test_results: ['id', 'test_type', 'result', 'value', 'created_at', 'status'],
          test_requests: ['id', 'product', 'test_type', 'priority', 'created_at', 'status'],
          reference_data: ['id', 'category', 'value', 'created_at']
        };
        setAvailableColumns(fallbackColumns[tableName] || ['id', 'created_at']);
      }
    } catch (error) {
      console.error('Error loading columns:', error);
      setAvailableColumns(['id', 'created_at']);
    }
  };

  const generatePreview = async () => {
    if (!config.source_table) return;

    setLoading(true);
    setError(null);
    
    try {
      let query = '';
      
      if (config.widget_type === 'kpi') {
        // KPI query
        if (config.aggregation === 'count') {
          query = `SELECT COUNT(*) as value FROM ${config.source_table}`;
        } else if (config.y_field) {
          query = `SELECT ${config.aggregation?.toUpperCase()}(${config.y_field}) as value FROM ${config.source_table}`;
        }
      } else {
        // Chart queries
        const xField = config.x_field || 'created_at';
        const yField = config.y_field || 'id';
        const agg = config.aggregation || 'count';
        
        if (agg === 'count') {
          query = `SELECT ${xField} as name, COUNT(*) as value FROM ${config.source_table} GROUP BY ${xField} LIMIT 10`;
        } else {
          query = `SELECT ${xField} as name, ${agg.toUpperCase()}(${yField}) as value FROM ${config.source_table} GROUP BY ${xField} LIMIT 10`;
        }
      }

      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      
      if (isElectron) {
        const result = await window.electronAPI.dbQuery(query, []);
        if (result.success && result.data.length > 0) {
          setPreview(result.data);
        } else {
          setError('No data returned from query. Check your table and field selections.');
        }
      } else {
        // Mock preview data for browser
        if (config.widget_type === 'kpi') {
          setPreview([{ value: 42 }]);
        } else {
          setPreview([
            { name: 'Sample 1', value: 10 },
            { name: 'Sample 2', value: 25 },
            { name: 'Sample 3', value: 15 }
          ]);
        }
      }
    } catch (error) {
      console.error('Preview error:', error);
      setError('Failed to generate preview. Please check your selections.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    // Reset error
    setError(null);
    
    // Validate source table
    if (!config.source_table) {
      setError('Please select a source table');
      return;
    }

    // Validate chart-specific fields
    if (config.widget_type !== 'kpi' && !config.x_field) {
      setError('Please select an X-axis field for charts');
      return;
    }

    // Validate aggregation fields
    if (config.aggregation !== 'count' && !config.y_field) {
      setError('Please select a value field for non-count aggregations');
      return;
    }

    // Validate widget label
    if (!config.label || config.label.trim() === '') {
      setError('Please enter a widget label');
      return;
    }

    const widget: DashboardWidget = {
      id: `${config.widget_type}-${Date.now()}`,
      type: config.widget_type,
      title: config.label || `${config.widget_type.toUpperCase()} - ${config.source_table}`,
      x: 0,
      y: 0,
      w: config.widget_type === 'kpi' ? 3 : 6,
      h: config.widget_type === 'kpi' ? 2 : 4,
      minW: config.widget_type === 'kpi' ? 2 : 4,
      minH: config.widget_type === 'kpi' ? 2 : 3,
      enabled: true,
      data: {
        config,
        preview
      }
    };

    onSave(widget);
  };

  const getIcon = () => {
    switch (widgetType) {
      case 'kpi': return TrendingUp;
      case 'bar': return BarChart3;
      case 'pie': return PieChart;
      case 'line': return LineChart;
      case 'scatter': return GitBranch;
      case 'gauge': return Gauge;
      case 'heatmap': return Grid;
      default: return BarChart3;
    }
  };

  const Icon = getIcon();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Icon className="h-6 w-6 text-primary" />
        <h3 className="text-lg font-semibold">Configure {widgetType.toUpperCase()} Widget</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Configuration Form */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Widget Label</Label>
            <Input
              id="label"
              placeholder={`My ${widgetType.toUpperCase()} Widget`}
              value={config.label || ''}
              onChange={(e) => setConfig(prev => ({ ...prev, label: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="table">Source Table</Label>
            <Select onValueChange={(value) => setConfig(prev => ({ ...prev, source_table: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select a table" />
              </SelectTrigger>
              <SelectContent>
                {availableTables.map(table => (
                  <SelectItem key={table} value={table}>{table}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {config.widget_type !== 'kpi' && (
            <>
              <div>
                <Label htmlFor="xfield">
                  {config.widget_type === 'heatmap' ? 'X-Axis Field' : 
                   config.widget_type === 'scatter' ? 'X Value Field' : 'X-Axis Field'}
                </Label>
                <Select onValueChange={(value) => setConfig(prev => ({ ...prev, x_field: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select X-axis field" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableColumns.map(column => (
                      <SelectItem key={column} value={column}>{column}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {config.widget_type === 'gauge' && (
            <>
              <div>
                <Label htmlFor="minvalue">Minimum Value</Label>
                <Input
                  id="minvalue"
                  type="number"
                  placeholder="0"
                  value={config.min_value || ''}
                  onChange={(e) => setConfig(prev => ({ ...prev, min_value: Number(e.target.value) }))}
                />
              </div>
              <div>
                <Label htmlFor="maxvalue">Maximum Value</Label>
                <Input
                  id="maxvalue"
                  type="number"
                  placeholder="100"
                  value={config.max_value || ''}
                  onChange={(e) => setConfig(prev => ({ ...prev, max_value: Number(e.target.value) }))}
                />
              </div>
            </>
          )}

          <div>
            <Label htmlFor="aggregation">Aggregation</Label>
            <Select 
              value={config.aggregation}
              onValueChange={(value: any) => setConfig(prev => ({ ...prev, aggregation: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="count">Count</SelectItem>
                <SelectItem value="sum">Sum</SelectItem>
                <SelectItem value="avg">Average</SelectItem>
                <SelectItem value="max">Maximum</SelectItem>
                <SelectItem value="min">Minimum</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(config.aggregation !== 'count' || config.widget_type === 'scatter' || config.widget_type === 'heatmap') && (
            <div>
              <Label htmlFor="yfield">
                {config.widget_type === 'heatmap' ? 'Y-Axis Field' : 
                 config.widget_type === 'scatter' ? 'Y Value Field' : 'Value Field'}
              </Label>
              <Select onValueChange={(value) => setConfig(prev => ({ ...prev, y_field: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select value field" />
                </SelectTrigger>
                <SelectContent>
                  {availableColumns.filter(col => col !== config.x_field).map(column => (
                    <SelectItem key={column} value={column}>{column}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {config.widget_type === 'heatmap' && (
            <div>
              <Label htmlFor="zfield">Value (Z) Field</Label>
              <Select onValueChange={(value) => setConfig(prev => ({ ...prev, z_field: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select value field" />
                </SelectTrigger>
                <SelectContent>
                  {availableColumns.filter(col => col !== config.x_field && col !== config.y_field).map(column => (
                    <SelectItem key={column} value={column}>{column}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={generatePreview} disabled={!config.source_table || loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Preview Data
            </Button>
          </div>
        </div>

        {/* Preview */}
        <div>
          <Label>Preview</Label>
          <Card className="h-64">
            <CardContent className="p-4 h-full">
              {error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              {loading && (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              )}
              
              {preview && !loading && !error && (
                <div className="h-full flex items-center justify-center">
                  {config.widget_type === 'kpi' ? (
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary">{preview[0]?.value || 0}</div>
                      <div className="text-sm text-muted-foreground">{config.label || 'KPI Value'}</div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground mb-2">Sample Chart Data:</div>
                      {preview.slice(0, 3).map((item: any, index: number) => (
                        <div key={index} className="text-xs">
                          {item.name}: {item.value}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              
              {!preview && !loading && !error && (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  Click "Preview Data" to see results
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={!config.source_table || loading}>
          Save Widget
        </Button>
      </div>
    </div>
  );
}