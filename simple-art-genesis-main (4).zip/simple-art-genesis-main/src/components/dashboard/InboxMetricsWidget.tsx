import { useState, useEffect } from "react";
import { Clock, Inbox, CheckCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import { memoInboxService, type MemoInboxEntry } from "@/services/database/memoInboxService";
import { useMemoContext } from "@/contexts/MemoContext";

interface InboxMetrics {
  pendingCount: number;
  acknowledgedToday: number;
  flaggedCount: number;
  averageAcknowledgmentTime: number;
  overdueCount: number;
  totalProcessed: number;
}

export function InboxMetricsWidget() {
  const { hasPermission } = useAuth();
  const { memos } = useMemoContext();
  const [metrics, setMetrics] = useState<InboxMetrics>({
    pendingCount: 0,
    acknowledgedToday: 0,
    flaggedCount: 0,
    averageAcknowledgmentTime: 0,
    overdueCount: 0,
    totalProcessed: 0
  });
  const [inboxEntries, setInboxEntries] = useState<MemoInboxEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (hasPermission('memo.manage_inbox')) {
      loadMetrics();
    }
  }, [hasPermission]);

  const loadMetrics = async () => {
    try {
      setLoading(true);
      const [pendingEntries, allEntries] = await Promise.all([
        memoInboxService.getInboxEntries('pending'),
        memoInboxService.getInboxEntries()
      ]);

      setInboxEntries(allEntries);

      const today = new Date().toISOString().split('T')[0];
      const acknowledgedToday = allEntries.filter(entry => 
        entry.status === 'acknowledged' && 
        entry.acknowledged_at?.startsWith(today)
      ).length;

      const flaggedCount = allEntries.filter(entry => entry.status === 'flagged').length;
      
      // Calculate average acknowledgment time
      const acknowledgedEntries = allEntries.filter(entry => 
        entry.status === 'acknowledged' && entry.acknowledged_at
      );
      
      let averageTime = 0;
      if (acknowledgedEntries.length > 0) {
        const totalTime = acknowledgedEntries.reduce((sum, entry) => {
          const submitted = new Date(entry.submitted_at).getTime();
          const acknowledged = new Date(entry.acknowledged_at!).getTime();
          return sum + (acknowledged - submitted);
        }, 0);
        averageTime = totalTime / acknowledgedEntries.length / (1000 * 60 * 60); // Convert to hours
      }

      // Calculate overdue (pending more than 24 hours)
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const overdueCount = pendingEntries.filter(entry => 
        new Date(entry.submitted_at) < twentyFourHoursAgo
      ).length;

      setMetrics({
        pendingCount: pendingEntries.length,
        acknowledgedToday,
        flaggedCount,
        averageAcknowledgmentTime: Math.round(averageTime * 10) / 10,
        overdueCount,
        totalProcessed: allEntries.length
      });
    } catch (error) {
      console.error('Error loading inbox metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!hasPermission('memo.manage_inbox')) {
    return null;
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Inbox className="h-5 w-5" />
            Memo Inbox Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const acknowledgmentProgress = metrics.totalProcessed > 0 
    ? ((metrics.totalProcessed - metrics.pendingCount) / metrics.totalProcessed) * 100 
    : 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Inbox className="h-5 w-5" />
          Memo Inbox Metrics
        </CardTitle>
        <CardDescription>
          Real-time performance metrics for memo acknowledgment process
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg border border-amber-200">
              <div>
                <p className="text-sm text-amber-700">Pending Review</p>
                <p className="text-2xl font-bold text-amber-800">{metrics.pendingCount}</p>
              </div>
              <Clock className="h-8 w-8 text-amber-600" />
            </div>

            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
              <div>
                <p className="text-sm text-green-700">Acknowledged Today</p>
                <p className="text-2xl font-bold text-green-800">{metrics.acknowledgedToday}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>

            {metrics.flaggedCount > 0 && (
              <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                <div>
                  <p className="text-sm text-red-700">Flagged Issues</p>
                  <p className="text-2xl font-bold text-red-800">{metrics.flaggedCount}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-600" />
              </div>
            )}

            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div>
                <p className="text-sm text-blue-700">Avg. Time</p>
                <p className="text-2xl font-bold text-blue-800">{metrics.averageAcknowledgmentTime}h</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-600" />
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Acknowledgment Progress</span>
              <span>{Math.round(acknowledgmentProgress)}%</span>
            </div>
            <Progress value={acknowledgmentProgress} className="h-2" />
          </div>

          {/* Alerts */}
          {metrics.overdueCount > 0 && (
            <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <span className="text-sm text-orange-700">
                {metrics.overdueCount} memo(s) overdue for acknowledgment
              </span>
              <Badge variant="destructive" className="ml-auto">
                Action Required
              </Badge>
            </div>
          )}

          {/* Quick Stats */}
          <div className="pt-3 border-t">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Total Processed</span>
              <span>{metrics.totalProcessed}</span>
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Success Rate</span>
              <span>
                {metrics.totalProcessed > 0 
                  ? Math.round(((metrics.totalProcessed - metrics.flaggedCount) / metrics.totalProcessed) * 100)
                  : 100}%
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}