import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { DatabaseInitializationService } from '@/services/database/tableInitializationService';
import { 
  Database, 
  Shield, 
  Archive, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Activity,
  Users,
  Calendar,
  TrendingUp,
  RefreshCw,
  Loader2
} from 'lucide-react';

interface SystemHealth {
  validationRules: {
    total: number;
    enabled: number;
    disabled: number;
  };
  datasets: {
    total: number;
    active: number;
    templates: number;
  };
  backups: {
    lastBackup: string | null;
    status: 'healthy' | 'warning' | 'error';
  };
  issues: {
    validationErrors: number;
    mappingIssues: number;
    dbIntegrityIssues: number;
  };
  recentActivity: {
    logins: number;
    dataChanges: number;
    testsRun: number;
  };
}

export function OverviewDashboard() {
  const [healthData, setHealthData] = useState<SystemHealth | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const loadSystemHealth = async () => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        // Load validation rules count
        const validationRulesResult = await window.electronAPI.dbQuery(`
          SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END) as enabled,
            SUM(CASE WHEN active = 0 THEN 1 ELSE 0 END) as disabled
          FROM validation_rules
        `).catch(() => [{ total: 0, enabled: 0, disabled: 0 }]);

        // Load table count (excluding system tables)
        const tablesResult = await window.electronAPI.dbQuery(`
          SELECT COUNT(*) as total 
          FROM sqlite_master 
          WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'version_%'
        `).catch(() => [{ total: 0 }]);

        // Load template metadata count
        const templatesResult = await window.electronAPI.dbQuery(`
          SELECT COUNT(*) as total FROM table_metadata
        `).catch(() => [{ total: 0 }]);

        // Load last backup info
        const backupResult = await window.electronAPI.dbQuery(`
          SELECT created_at FROM version_control 
          ORDER BY created_at DESC LIMIT 1
        `).catch(() => []);

        // Load recent activity from audit logs
        const activityResult = await window.electronAPI.dbQuery(`
          SELECT 
            COUNT(*) as total_activity,
            SUM(CASE WHEN action = 'LOGIN' THEN 1 ELSE 0 END) as logins,
            SUM(CASE WHEN action IN ('CREATE', 'UPDATE', 'DELETE') THEN 1 ELSE 0 END) as data_changes
          FROM audit_logs 
          WHERE timestamp >= datetime('now', '-24 hours')
        `).catch(() => [{ total_activity: 0, logins: 0, data_changes: 0 }]);

        // Simulate validation errors check
        const validationErrorsResult = await window.electronAPI.dbQuery(`
          SELECT COUNT(*) as errors FROM test_result_validations WHERE passed = 0
        `).catch(() => [{ errors: 0 }]);

        const health: SystemHealth = {
          validationRules: {
            total: validationRulesResult[0]?.total || 0,
            enabled: validationRulesResult[0]?.enabled || 0,
            disabled: validationRulesResult[0]?.disabled || 0
          },
          datasets: {
            total: tablesResult[0]?.total || 0,
            active: tablesResult[0]?.total || 0,
            templates: templatesResult[0]?.total || 0
          },
          backups: {
            lastBackup: backupResult[0]?.created_at || null,
            status: backupResult.length > 0 ? 'healthy' : 'warning'
          },
          issues: {
            validationErrors: validationErrorsResult[0]?.errors || 0,
            mappingIssues: 0, // Could be calculated from actual mapping logic
            dbIntegrityIssues: 0 // Could be calculated from integrity checks
          },
          recentActivity: {
            logins: activityResult[0]?.logins || 0,
            dataChanges: activityResult[0]?.data_changes || 0,
            testsRun: 0 // No sample data
          }
        };

        setHealthData(health);
      } else {
        // Clean prototype - no sample data
        setHealthData({
          validationRules: { total: 0, enabled: 0, disabled: 0 },
          datasets: { total: 0, active: 0, templates: 0 },
          backups: { lastBackup: null, status: 'warning' },
          issues: { validationErrors: 0, mappingIssues: 0, dbIntegrityIssues: 0 },
          recentActivity: { logins: 0, dataChanges: 0, testsRun: 0 }
        });
      }
    } catch (error) {
      console.error('Error loading system health:', error);
      toast({
        title: "Error",
        description: "Failed to load system health data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const runSystemValidation = async () => {
    setIsProcessing(true);
    try {
      if (!window.electronAPI) {
        toast({
          title: "Validation Complete",
          description: "System validation completed successfully (browser mode)",
          variant: "default"
        });
        return;
      }

      // Run validation checks
      const validationCount = await window.electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM validation_rules WHERE active = 1',
        []
      );

      DatabaseInitializationService.logAuditEntry(
        'System',
        'VALIDATE',
        'system_validation',
        `System validation run - ${validationCount[0]?.count || 0} rules checked`
      );

      toast({
        title: "Validation Complete",
        description: `System validation completed. ${validationCount[0]?.count || 0} rules checked.`,
        variant: "default"
      });

      // Refresh data
      loadSystemHealth();
    } catch (error) {
      console.error('Validation failed:', error);
      toast({
        title: "Validation Failed",
        description: "An error occurred during system validation",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const createSystemBackup = async () => {
    setIsProcessing(true);
    try {
      if (!window.electronAPI) {
        toast({
          title: "Backup Created",
          description: "System backup created successfully (browser mode)",
          variant: "default"
        });
        return;
      }

      // Create version control snapshot
      const tables = await window.electronAPI.dbQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
        []
      );

      for (const table of tables) {
        const data = await window.electronAPI.dbQuery(`SELECT * FROM ${table.name}`, []);
        await window.electronAPI.dbRun(
          'INSERT INTO version_control (table_name, snapshot_data, version_number, description, created_by) VALUES (?, ?, ?, ?, ?)',
          [table.name, JSON.stringify(data), Date.now(), 'System backup', 'System']
        );
      }

      DatabaseInitializationService.logAuditEntry(
        'System',
        'BACKUP',
        'system_backup',
        `System backup created - ${tables.length} tables backed up`
      );

      toast({
        title: "Backup Created",
        description: `System backup created successfully. ${tables.length} tables backed up.`,
        variant: "default"
      });

      // Refresh data
      loadSystemHealth();
    } catch (error) {
      console.error('Backup failed:', error);
      toast({
        title: "Backup Failed",
        description: "An error occurred during system backup",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const runHealthCheck = async () => {
    setIsProcessing(true);
    try {
      if (!window.electronAPI) {
        toast({
          title: "Health Check Complete",
          description: "Database health check completed (browser mode)",
          variant: "default"
        });
        return;
      }

      // Check database integrity
      const integrityCheck = await window.electronAPI.dbQuery('PRAGMA integrity_check', []);
      const isHealthy = integrityCheck[0]?.integrity_check === 'ok';

      DatabaseInitializationService.logAuditEntry(
        'System',
        'HEALTH_CHECK',
        'database_health',
        `Database health check: ${isHealthy ? 'PASSED' : 'FAILED'}`
      );

      toast({
        title: "Health Check Complete",
        description: `Database health check ${isHealthy ? 'passed' : 'found issues'}`,
        variant: isHealthy ? "default" : "destructive"
      });

      // Refresh data
      loadSystemHealth();
    } catch (error) {
      console.error('Health check failed:', error);
      toast({
        title: "Health Check Failed",
        description: "An error occurred during database health check",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    loadSystemHealth();
  }, []);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!healthData) return null;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-500" />;
      default: return <Activity className="w-5 h-5 text-gray-500" />;
    }
  };

  const validationHealth = healthData.validationRules.total > 0 
    ? (healthData.validationRules.enabled / healthData.validationRules.total) * 100 
    : 0;

  const overallIssues = healthData.issues.validationErrors + 
                       healthData.issues.mappingIssues + 
                       healthData.issues.dbIntegrityIssues;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">System Overview</h2>
          <p className="text-muted-foreground">
            Real-time status of your LIMS environment
          </p>
        </div>
        <Button 
          onClick={loadSystemHealth} 
          variant="outline" 
          size="sm"
          disabled={isProcessing}
        >
          {isProcessing ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {/* Validation Rules */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Validation Rules</CardTitle>
            <Shield className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{healthData.validationRules.total}</div>
            <div className="flex items-center justify-between mt-2">
              <Badge variant="default" className="text-xs">
                {healthData.validationRules.enabled} active
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {healthData.validationRules.disabled} disabled
              </Badge>
            </div>
            <Progress value={validationHealth} className="mt-3" />
            <p className="text-xs text-muted-foreground mt-1">
              {validationHealth.toFixed(0)}% enabled
            </p>
          </CardContent>
        </Card>

        {/* Datasets */}
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Datasets</CardTitle>
            <Database className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{healthData.datasets.total}</div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-sm text-muted-foreground">Tables</span>
              <Badge variant="outline" className="text-xs">
                {healthData.datasets.templates} templates
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              All datasets operational
            </p>
          </CardContent>
        </Card>

        {/* Backup Status */}
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Last Backup</CardTitle>
            <Archive className="w-4 h-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {getStatusIcon(healthData.backups.status)}
              <span className="text-sm font-medium capitalize">{healthData.backups.status}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {healthData.backups.lastBackup 
                ? new Date(healthData.backups.lastBackup).toLocaleString()
                : 'No backups found'
              }
            </p>
          </CardContent>
        </Card>

        {/* System Issues */}
        <Card className="border-l-4 border-l-red-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Issues</CardTitle>
            <AlertTriangle className="w-4 h-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallIssues}</div>
            <div className="space-y-1 mt-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Validation errors</span>
                <span>{healthData.issues.validationErrors}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Mapping issues</span>
                <span>{healthData.issues.mappingIssues}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">DB integrity</span>
                <span>{healthData.issues.dbIntegrityIssues}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Activity Overview */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Recent Activity (24h)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-blue-500" />
                <span className="text-sm">User Logins</span>
              </div>
              <Badge variant="outline">{healthData.recentActivity.logins}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-green-500" />
                <span className="text-sm">Data Changes</span>
              </div>
              <Badge variant="outline">{healthData.recentActivity.dataChanges}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-purple-500" />
                <span className="text-sm">Tests Run</span>
              </div>
              <Badge variant="outline">{healthData.recentActivity.testsRun}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={runSystemValidation}
            >
              <Shield className="w-4 h-4 mr-2" />
              Run System Validation
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={createSystemBackup}
            >
              <Archive className="w-4 h-4 mr-2" />
              Create System Backup
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={runHealthCheck}
            >
              <Database className="w-4 h-4 mr-2" />
              Database Health Check
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}