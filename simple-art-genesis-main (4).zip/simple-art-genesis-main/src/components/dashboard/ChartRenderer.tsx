import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, ScatterChart, Scatter } from 'recharts';
import { TrendingUp, BarChart3, Activity, Calendar, AlertTriangle } from 'lucide-react';
import { analyticsService } from '@/services/analytics/analyticsService';
import type { DashboardWidget } from '@/types/dashboard';
import { ScatterChartWidget } from './widgets/ScatterChartWidget';
import { GaugeWidget } from './widgets/GaugeWidget';
import { HeatmapWidget } from './widgets/HeatmapWidget';
import { CalendarWidget } from './widgets/CalendarWidget';

interface ChartRendererProps {
  widget: DashboardWidget;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe'];

export function ChartRenderer({ widget }: ChartRendererProps) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadWidgetData();
  }, [widget.id, widget.data]);

  const loadWidgetData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Handle different widget data sources
      if (widget.data?.config) {
        // New data-bound widgets with SQL configuration
        const result = await executeWidgetQuery(widget.data.config);
        setData(result);
      } else if (widget.type === 'analytics_chart' && widget.data?.chartId) {
        // Analytics charts from saved charts
        const chartData = await analyticsService.executeChart(widget.data.chartId);
        setData(chartData.data);
      } else {
        // Fallback to mock data for legacy widgets
        setData(getMockData(widget.type));
      }
    } catch (err) {
      console.error('Error loading widget data:', err);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const executeWidgetQuery = async (config: any) => {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      // Browser fallback with mock data
      return getMockDataForConfig(config);
    }

    try {
      let query = '';
      
      if (config.widget_type === 'kpi') {
        if (config.aggregation === 'count') {
          query = `SELECT COUNT(*) as value FROM ${config.source_table}`;
        } else if (config.y_field && config.aggregation) {
          query = `SELECT ${config.aggregation.toUpperCase()}(${config.y_field}) as value FROM ${config.source_table}`;
        }
      } else {
        // Chart queries
        const xField = config.x_field || 'created_at';
        const agg = config.aggregation || 'count';
        
        if (agg === 'count') {
          query = `SELECT ${xField} as name, COUNT(*) as value FROM ${config.source_table} GROUP BY ${xField} ORDER BY value DESC LIMIT 10`;
        } else if (config.y_field) {
          query = `SELECT ${xField} as name, ${agg.toUpperCase()}(${config.y_field}) as value FROM ${config.source_table} GROUP BY ${xField} ORDER BY value DESC LIMIT 10`;
        }
      }

      if (!query) {
        throw new Error('Invalid query configuration');
      }

      const result = await window.electronAPI.dbQuery(query, []);
      
      if (!result.success) {
        throw new Error(result.error || 'Query failed');
      }

      return result.data;
    } catch (error) {
      console.error('SQL query error:', error);
      throw error;
    }
  };

  const getMockDataForConfig = (config: any) => {
    // Return empty data for clean prototype
    if (config.widget_type === 'kpi') {
      return [{ value: 0 }];
    }
    
    // Return empty arrays for all chart types
    return [];
  };

  const getMockData = (type: string) => {
    // Return empty data for clean prototype - no sample data
    switch (type) {
      case 'kpi':
        return [{ value: 0 }];
      default:
        return [];
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-4">
        <AlertTriangle className="h-8 w-8 text-destructive mb-2" />
        <p className="text-sm text-destructive">{error}</p>
        <p className="text-xs text-muted-foreground mt-1">Check data source configuration</p>
      </div>
    );
  }

  if (!data || (Array.isArray(data) && data.length === 0)) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <p className="text-sm">No data available</p>
      </div>
    );
  }

  // Render KPI widget
  if (widget.type === 'kpi') {
    const value = Array.isArray(data) ? data[0]?.value : data?.value;
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <div className="text-3xl font-bold text-primary">{value || '0'}</div>
        <div className="text-sm text-muted-foreground mt-1">
          {widget.data?.config?.label || widget.title}
        </div>
      </div>
    );
  }

  // Render Bar Chart
  if (widget.type === 'bar' || widget.type === 'bar_chart' || (widget.type === 'analytics_chart' && widget.data?.chartType === 'bar')) {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" fontSize={11} />
          <YAxis fontSize={11} />
          <Tooltip />
          <Bar dataKey="value" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  // Render Pie Chart
  if (widget.type === 'pie' || widget.type === 'pie_chart' || (widget.type === 'analytics_chart' && widget.data?.chartType === 'pie')) {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={Math.min(80, 60)}
            fill="#8884d8"
            dataKey="value"
          >
            {data?.map((entry: any, index: number) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    );
  }

  // Render Line Chart
  if (widget.type === 'line' || widget.type === 'line_chart' || (widget.type === 'analytics_chart' && widget.data?.chartType === 'line')) {
    return (
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" fontSize={11} />
          <YAxis fontSize={11} />
          <Tooltip />
          <Line type="monotone" dataKey="value" stroke="#8884d8" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    );
  }

  // Render Scatter Chart
  if (widget.type === 'scatter' || widget.type === 'scatter_chart') {
    return (
      <ScatterChartWidget
        title={widget.title}
        description={widget.description}
        data={data}
        xAxisLabel="X Value"
        yAxisLabel="Y Value"
      />
    );
  }

  // Render Gauge Widget
  if (widget.type === 'gauge') {
    const value = Array.isArray(data) ? data[0]?.value : data?.value || 0;
    return (
      <GaugeWidget
        title={widget.title}
        value={value}
        min={widget.data?.min || 0}
        max={widget.data?.max || 100}
        unit={widget.data?.unit || ''}
        thresholds={widget.data?.thresholds || { warning: 70, critical: 90 }}
        description={widget.description}
      />
    );
  }

  // Render Heatmap Widget
  if (widget.type === 'heatmap') {
    return (
      <HeatmapWidget
        title={widget.title}
        description={widget.description}
        data={data}
        xAxisLabel="X"
        yAxisLabel="Y"
      />
    );
  }

  // Render Calendar Widget
  if (widget.type === 'calendar') {
    return (
      <CalendarWidget
        events={data || []}
      />
    );
  }

  return (
    <div className="flex items-center justify-center h-full">
      <p className="text-muted-foreground">Unsupported widget type: {widget.type}</p>
    </div>
  );
}