import React from 'react';
import { Responsive, WidthProvider, Layout } from "react-grid-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, GripVertical } from "lucide-react";
import { ChartRenderer } from "./ChartRenderer";
import type { DashboardWidget } from '@/types/dashboard';

const ResponsiveGridLayout = WidthProvider(Responsive);

interface DashboardGridProps {
  widgets: DashboardWidget[];
  onLayoutChange: (layout: Layout[]) => void;
  onRemoveWidget: (widgetId: string) => void;
  canEdit: boolean;
}

export function DashboardGrid({ widgets, onLayoutChange, onRemoveWidget, canEdit }: DashboardGridProps) {
  const layouts: Layout[] = widgets.map(widget => ({
    i: widget.id,
    x: widget.x,
    y: widget.y,
    w: widget.w,
    h: widget.h,
    minW: widget.minW || 2,
    minH: widget.minH || 2
  }));

  const renderWidget = (widget: DashboardWidget) => {
    return (
      <div key={widget.id} className="relative">
        <Card className="h-full shadow-sm border-border/50 hover:shadow-md transition-shadow">
          {canEdit && (
            <>
              <div className="drag-handle absolute top-2 left-2 cursor-grab opacity-60 hover:opacity-100 z-10">
                <GripVertical className="h-4 w-4" />
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-1 right-1 h-6 w-6 p-0 opacity-60 hover:opacity-100 hover:bg-destructive hover:text-destructive-foreground z-10"
                onClick={() => onRemoveWidget(widget.id)}
              >
                <X className="h-3 w-3" />
              </Button>
            </>
          )}
          
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium truncate pr-8">
              {widget.title}
            </CardTitle>
            {widget.description && (
              <CardDescription className="text-xs">
                {widget.description}
              </CardDescription>
            )}
          </CardHeader>
          
          <CardContent className="pt-0 h-[calc(100%-4rem)]">
            <ChartRenderer widget={widget} />
          </CardContent>
        </Card>
      </div>
    );
  };

  if (widgets.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 border-2 border-dashed border-border rounded-lg">
        <div className="text-center space-y-2">
          <p className="text-muted-foreground">No widgets added yet</p>
          <p className="text-sm text-muted-foreground">
            Add charts and analytics from your data to get started
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      <ResponsiveGridLayout
        className="layout"
        layouts={{ lg: layouts }}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
        cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
        rowHeight={60}
        onLayoutChange={onLayoutChange}
        isDraggable={canEdit}
        isResizable={canEdit}
        margin={[16, 16]}
        containerPadding={[0, 0]}
        draggableHandle=".drag-handle"
      >
        {widgets.map(renderWidget)}
      </ResponsiveGridLayout>
    </div>
  );
}