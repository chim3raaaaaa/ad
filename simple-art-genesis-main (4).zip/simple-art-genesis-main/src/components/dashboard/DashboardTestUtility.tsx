import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  TestTube, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Download,
  Filter,
  Bell,
  BarChart3,
  RotateCcw,
  Play,
  Bug
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useDashboardWidgets } from '@/hooks/useDashboardWidgets';
import { dataExportService } from '@/services/export/dataExportService';
import { analyticsService } from '@/services/analytics/analyticsService';
import { enhancedNotificationService } from '@/services/notifications/enhancedNotificationService';

interface TestResult {
  component: string;
  test: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  details?: string;
}

export function DashboardTestUtility() {
  const [isOpen, setIsOpen] = useState(false);
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<TestResult[]>([]);
  const { widgets, addWidget, removeWidget, updateWidgetPositions } = useDashboardWidgets();

  const runAllTests = async () => {
    setTesting(true);
    setResults([]);
    const testResults: TestResult[] = [];

    // Test 1: Widget Management
    try {
      const testWidget = {
        id: 'test-widget-' + Date.now(),
        type: 'kpi' as const,
        title: 'Test KPI',
        x: 0, y: 0, w: 3, h: 2,
        minW: 2, minH: 2,
        enabled: true,
        data: { config: { label: 'Test Value', source_table: 'memos', aggregation: 'count' } }
      };
      
      addWidget(testWidget);
      await new Promise(resolve => setTimeout(resolve, 100));
      
      if (widgets.find(w => w.id === testWidget.id)) {
        testResults.push({
          component: 'Widget Management',
          test: 'Add Widget',
          status: 'pass',
          message: 'Successfully added test widget'
        });
        
        // Test removal
        removeWidget(testWidget.id);
        await new Promise(resolve => setTimeout(resolve, 100));
        
        testResults.push({
          component: 'Widget Management',
          test: 'Remove Widget',
          status: 'pass',
          message: 'Successfully removed test widget'
        });
      } else {
        testResults.push({
          component: 'Widget Management',
          test: 'Add Widget',
          status: 'fail',
          message: 'Failed to add widget to dashboard'
        });
      }
    } catch (error) {
      testResults.push({
        component: 'Widget Management',
        test: 'Widget Operations',
        status: 'fail',
        message: 'Error in widget operations',
        details: String(error)
      });
    }

    // Test 2: Export Functionality
    try {
      const mockWidget = {
        id: 'mock-export-test',
        type: 'bar' as const,
        title: 'Export Test Chart',
        x: 0, y: 0, w: 6, h: 4,
        enabled: true
      };
      
      await dataExportService.exportWidget(mockWidget, { format: 'json' });
      testResults.push({
        component: 'Export Service',
        test: 'Widget Export',
        status: 'pass',
        message: 'Export functionality working'
      });
    } catch (error) {
      testResults.push({
        component: 'Export Service',
        test: 'Widget Export',
        status: 'fail',
        message: 'Export failed',
        details: String(error)
      });
    }

    // Test 3: Analytics Service
    try {
      const charts = await analyticsService.getUserCharts('test-user');
      if (Array.isArray(charts)) {
        testResults.push({
          component: 'Analytics Service',
          test: 'Get User Charts',
          status: 'pass',
          message: `Found ${charts.length} charts`
        });
      } else {
        testResults.push({
          component: 'Analytics Service',
          test: 'Get User Charts',
          status: 'warning',
          message: 'Charts data format unexpected'
        });
      }
    } catch (error) {
      testResults.push({
        component: 'Analytics Service',
        test: 'Get User Charts',
        status: 'fail',
        message: 'Analytics service error',
        details: String(error)
      });
    }

    // Test 4: Notification System
    try {
      await enhancedNotificationService.createNotification({
        type: 'info',
        category: 'system',
        title: 'Test Notification',
        message: 'This is a test notification from the dashboard test utility',
        priority: 'normal'
      });
      
      const notifications = await enhancedNotificationService.loadNotifications();
      if (notifications.some(n => n.title === 'Test Notification')) {
        testResults.push({
          component: 'Notification System',
          test: 'Create & Load Notifications',
          status: 'pass',
          message: 'Notification system working correctly'
        });
      } else {
        testResults.push({
          component: 'Notification System',
          test: 'Create & Load Notifications',
          status: 'warning',
          message: 'Notification created but not found in list'
        });
      }
    } catch (error) {
      testResults.push({
        component: 'Notification System',
        test: 'Create & Load Notifications',
        status: 'fail',
        message: 'Notification system error',
        details: String(error)
      });
    }

    // Test 5: Database Connectivity (Electron)
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        const result = await window.electronAPI.dbQuery('SELECT COUNT(*) as count FROM sqlite_master WHERE type="table"');
        if (result.success) {
          testResults.push({
            component: 'Database Connectivity',
            test: 'SQLite Connection',
            status: 'pass',
            message: `Database connected - ${result.data[0]?.count || 0} tables found`
          });
        } else {
          testResults.push({
            component: 'Database Connectivity',
            test: 'SQLite Connection',
            status: 'fail',
            message: 'Database query failed',
            details: result.error
          });
        }
      } catch (error) {
        testResults.push({
          component: 'Database Connectivity',
          test: 'SQLite Connection',
          status: 'fail',
          message: 'Database connection error',
          details: String(error)
        });
      }
    } else {
      testResults.push({
        component: 'Database Connectivity',
        test: 'SQLite Connection',
        status: 'warning',
        message: 'Running in browser mode - using localStorage fallback'
      });
    }

    // Test 6: Local Storage
    try {
      const testKey = 'dashboard-test-' + Date.now();
      const testData = { test: 'value', timestamp: Date.now() };
      
      localStorage.setItem(testKey, JSON.stringify(testData));
      const retrieved = JSON.parse(localStorage.getItem(testKey) || '{}');
      localStorage.removeItem(testKey);
      
      if (retrieved.test === testData.test) {
        testResults.push({
          component: 'Local Storage',
          test: 'Storage Operations',
          status: 'pass',
          message: 'Local storage working correctly'
        });
      } else {
        testResults.push({
          component: 'Local Storage',
          test: 'Storage Operations',
          status: 'fail',
          message: 'Data retrieval mismatch'
        });
      }
    } catch (error) {
      testResults.push({
        component: 'Local Storage',
        test: 'Storage Operations',
        status: 'fail',
        message: 'Local storage error',
        details: String(error)
      });
    }

    setResults(testResults);
    setTesting(false);

    // Show summary toast
    const passed = testResults.filter(r => r.status === 'pass').length;
    const failed = testResults.filter(r => r.status === 'fail').length;
    const warnings = testResults.filter(r => r.status === 'warning').length;

    toast({
      title: 'Dashboard Tests Complete',
      description: `${passed} passed, ${failed} failed, ${warnings} warnings`,
      variant: failed > 0 ? 'destructive' : 'default'
    });
  };

  const getStatusIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: TestResult['status']) => {
    switch (status) {
      case 'pass': return 'border-green-200 bg-green-50';
      case 'fail': return 'border-red-200 bg-red-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
    }
  };

  const testComponentButtons = () => {
    // Test various dashboard interactions
    const tests = [
      {
        name: 'Test Widget Selector',
        action: () => {
          // This would normally open the widget selector
          toast({ title: 'Widget Selector', description: 'Would open widget selector modal' });
        }
      },
      {
        name: 'Test Export Modal',
        action: async () => {
          try {
            await dataExportService.exportDashboard(widgets.slice(0, 1), { format: 'json' });
            toast({ title: 'Export Test', description: 'Export functionality working' });
          } catch (error) {
            toast({ title: 'Export Test', description: 'Export failed', variant: 'destructive' });
          }
        }
      },
      {
        name: 'Test Notification Creation',
        action: async () => {
          await enhancedNotificationService.createNotification({
            type: 'success',
            category: 'system',
            title: 'Test Success',
            message: 'This is a test notification created from the test utility',
            priority: 'normal'
          });
          toast({ title: 'Notification Test', description: 'Test notification created' });
        }
      },
      {
        name: 'Test Dashboard Refresh',
        action: () => {
          // Simulate refresh
          window.location.reload();
        }
      }
    ];

    return (
      <div className="space-y-2">
        <h4 className="font-medium text-sm">Component Tests</h4>
        <div className="grid grid-cols-2 gap-2">
          {tests.map((test, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={test.action}
              className="text-xs"
            >
              {test.name}
            </Button>
          ))}
        </div>
      </div>
    );
  };

  const summary = results.length > 0 ? {
    total: results.length,
    passed: results.filter(r => r.status === 'pass').length,
    failed: results.filter(r => r.status === 'fail').length,
    warnings: results.filter(r => r.status === 'warning').length
  } : null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Bug className="h-4 w-4" />
          Test Dashboard
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5" />
            Dashboard Functionality Test
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Test Controls */}
          <div className="flex items-center gap-2">
            <Button 
              onClick={runAllTests} 
              disabled={testing}
              className="gap-2"
            >
              {testing ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              ) : (
                <Play className="h-4 w-4" />
              )}
              {testing ? 'Running Tests...' : 'Run All Tests'}
            </Button>
            
            {summary && (
              <div className="flex items-center gap-2 ml-4">
                <Badge variant="secondary">{summary.total} Total</Badge>
                <Badge variant="default" className="bg-green-500">{summary.passed} Passed</Badge>
                {summary.failed > 0 && (
                  <Badge variant="destructive">{summary.failed} Failed</Badge>
                )}
                {summary.warnings > 0 && (
                  <Badge variant="secondary" className="bg-yellow-500">{summary.warnings} Warnings</Badge>
                )}
              </div>
            )}
          </div>

          <Separator />

          {/* Test Results */}
          <ScrollArea className="h-64">
            {results.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <TestTube className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No tests run yet</p>
                <p className="text-sm">Click "Run All Tests" to start testing</p>
              </div>
            ) : (
              <div className="space-y-2">
                {results.map((result, index) => (
                  <Card key={index} className={`${getStatusColor(result.status)} border`}>
                    <CardContent className="p-3">
                      <div className="flex items-start gap-2">
                        {getStatusIcon(result.status)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{result.component}</span>
                            <span className="text-xs text-muted-foreground">•</span>
                            <span className="text-sm">{result.test}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {result.message}
                          </p>
                          {result.details && (
                            <details className="mt-2">
                              <summary className="text-xs cursor-pointer text-muted-foreground">
                                Show details
                              </summary>
                              <pre className="text-xs mt-1 p-2 bg-muted rounded overflow-x-auto">
                                {result.details}
                              </pre>
                            </details>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>

          <Separator />

          {/* Component Tests */}
          {testComponentButtons()}
        </div>
      </DialogContent>
    </Dialog>
  );
}