import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DashboardWidgetProps {
  id: string;
  title: string;
  type: string;
  children: React.ReactNode;
  onRemove?: () => void;
  canEdit?: boolean;
  className?: string;
}

export function DashboardWidget({ 
  id, 
  title, 
  type, 
  children, 
  onRemove, 
  canEdit = true,
  className 
}: DashboardWidgetProps) {
  return (
    <Card className={cn("h-full relative group", className)}>
      {canEdit && (
        <>
          <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
            <div className="flex items-center gap-1">
              <GripVertical className="h-4 w-4 text-muted-foreground cursor-move drag-handle" />
            </div>
          </div>
          {onRemove && (
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onRemove}
                className="h-6 w-6 p-0 hover:bg-destructive hover:text-destructive-foreground"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          )}
        </>
      )}
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0 h-full">
        {children}
      </CardContent>
    </Card>
  );
}