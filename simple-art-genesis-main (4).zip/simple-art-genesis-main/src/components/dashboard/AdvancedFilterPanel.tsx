import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { 
  Filter, 
  X, 
  Calendar as CalendarIcon, 
  Search, 
  ChevronRight,
  RotateCcw,
  ArrowLeft
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useAdvancedFiltering, type FilterCriteria } from '@/hooks/useAdvancedFiltering';

interface AdvancedFilterPanelProps {
  onFilterChange?: (filters: FilterCriteria) => void;
  availableOptions?: {
    status?: string[];
    priority?: string[];
    testType?: string[];
    plant?: string[];
  };
  className?: string;
}

export function AdvancedFilterPanel({ onFilterChange, availableOptions, className }: AdvancedFilterPanelProps) {
  const {
    filterState,
    applyFilter,
    clearFilter,
    drillDown,
    drillUp,
    getFilterSummary,
    hasActiveFilters,
    getBreadcrumbs
  } = useAdvancedFiltering();

  const [dateRange, setDateRange] = useState<{ from: Date; to?: Date } | undefined>();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string[]>([]);
  const [selectedPriority, setSelectedPriority] = useState<string[]>([]);
  const [selectedTestType, setSelectedTestType] = useState<string[]>([]);
  const [selectedPlant, setSelectedPlant] = useState<string[]>([]);

  // Default options
  const defaultOptions = {
    status: ['pending', 'in_progress', 'completed', 'failed', 'cancelled'],
    priority: ['low', 'medium', 'high', 'critical'],
    testType: ['compression', 'flexural', 'aggregate', 'concrete', 'block'],
    plant: ['Plant A', 'Plant B', 'Plant C', 'Central Lab']
  };

  const options = { ...defaultOptions, ...availableOptions };

  useEffect(() => {
    // Notify parent of filter changes
    onFilterChange?.(filterState.activeFilters);
  }, [filterState.activeFilters, onFilterChange]);

  const handleApplyDateRange = () => {
    if (dateRange?.from) {
      applyFilter({
        dateRange: {
          start: format(dateRange.from, 'yyyy-MM-dd'),
          end: dateRange.to ? format(dateRange.to, 'yyyy-MM-dd') : format(dateRange.from, 'yyyy-MM-dd')
        }
      });
    }
  };

  const handleApplySearch = () => {
    if (searchTerm.trim()) {
      applyFilter({ searchTerm: searchTerm.trim() });
    }
  };

  const handleStatusChange = (status: string, checked: boolean) => {
    const newStatus = checked 
      ? [...selectedStatus, status]
      : selectedStatus.filter(s => s !== status);
    
    setSelectedStatus(newStatus);
    applyFilter({ status: newStatus.length > 0 ? newStatus : undefined });
  };

  const handlePriorityChange = (priority: string, checked: boolean) => {
    const newPriority = checked 
      ? [...selectedPriority, priority]
      : selectedPriority.filter(p => p !== priority);
    
    setSelectedPriority(newPriority);
    applyFilter({ priority: newPriority.length > 0 ? newPriority : undefined });
  };

  const handleTestTypeChange = (testType: string, checked: boolean) => {
    const newTestType = checked 
      ? [...selectedTestType, testType]
      : selectedTestType.filter(t => t !== testType);
    
    setSelectedTestType(newTestType);
    applyFilter({ testType: newTestType.length > 0 ? newTestType : undefined });
  };

  const handlePlantChange = (plant: string, checked: boolean) => {
    const newPlant = checked 
      ? [...selectedPlant, plant]
      : selectedPlant.filter(p => p !== plant);
    
    setSelectedPlant(newPlant);
    applyFilter({ plant: newPlant.length > 0 ? newPlant : undefined });
  };

  const handleClearAll = () => {
    clearFilter();
    setDateRange(undefined);
    setSearchTerm('');
    setSelectedStatus([]);
    setSelectedPriority([]);
    setSelectedTestType([]);
    setSelectedPlant([]);
  };

  return (
    <div className={cn('space-y-4', className)}>
      {/* Breadcrumb Navigation */}
      {getBreadcrumbs.length > 1 && (
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <Breadcrumb>
                <BreadcrumbList>
                  {getBreadcrumbs.map((crumb, index) => (
                    <React.Fragment key={crumb.level}>
                      <BreadcrumbItem>
                        <BreadcrumbLink
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            if (crumb.level >= 0) {
                              drillUp(crumb.level);
                            }
                          }}
                          className={crumb.level === getBreadcrumbs.length - 1 ? 'font-semibold' : ''}
                        >
                          {crumb.title}
                        </BreadcrumbLink>
                      </BreadcrumbItem>
                      {index < getBreadcrumbs.length - 1 && <BreadcrumbSeparator />}
                    </React.Fragment>
                  ))}
                </BreadcrumbList>
              </Breadcrumb>
              {getBreadcrumbs.length > 1 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => drillUp(0)}
                  className="gap-1"
                >
                  <ArrowLeft className="h-3 w-3" />
                  Back to Top
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filter Controls */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Advanced Filters
              </CardTitle>
              <CardDescription>
                Filter and drill down into your data
              </CardDescription>
            </div>
            {hasActiveFilters && (
              <Button variant="outline" size="sm" onClick={handleClearAll} className="gap-2">
                <RotateCcw className="h-4 w-4" />
                Clear All
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div>
            <Label htmlFor="search">Search</Label>
            <div className="flex gap-2">
              <Input
                id="search"
                placeholder="Search memos, tests, products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleApplySearch()}
              />
              <Button size="sm" onClick={handleApplySearch}>
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Date Range */}
          <div>
            <Label>Date Range</Label>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'justify-start text-left font-normal',
                      !dateRange?.from && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, 'LLL dd, y')} -{' '}
                          {format(dateRange.to, 'LLL dd, y')}
                        </>
                      ) : (
                        format(dateRange.from, 'LLL dd, y')
                      )
                    ) : (
                      <span>Pick a date range</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                    className="pointer-events-auto"
                  />
                  <div className="p-3 border-t">
                    <Button size="sm" onClick={handleApplyDateRange} className="w-full">
                      Apply Date Range
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Multi-select Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Status Filter */}
            <div>
              <Label>Status</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {options.status.map((status) => (
                  <div key={status} className="flex items-center space-x-2">
                    <Checkbox
                      id={`status-${status}`}
                      checked={selectedStatus.includes(status)}
                      onCheckedChange={(checked) => handleStatusChange(status, !!checked)}
                    />
                    <Label htmlFor={`status-${status}`} className="text-sm font-normal capitalize">
                      {status.replace('_', ' ')}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Priority Filter */}
            <div>
              <Label>Priority</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {options.priority.map((priority) => (
                  <div key={priority} className="flex items-center space-x-2">
                    <Checkbox
                      id={`priority-${priority}`}
                      checked={selectedPriority.includes(priority)}
                      onCheckedChange={(checked) => handlePriorityChange(priority, !!checked)}
                    />
                    <Label htmlFor={`priority-${priority}`} className="text-sm font-normal capitalize">
                      {priority}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Test Type Filter */}
            <div>
              <Label>Test Type</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {options.testType.map((testType) => (
                  <div key={testType} className="flex items-center space-x-2">
                    <Checkbox
                      id={`testType-${testType}`}
                      checked={selectedTestType.includes(testType)}
                      onCheckedChange={(checked) => handleTestTypeChange(testType, !!checked)}
                    />
                    <Label htmlFor={`testType-${testType}`} className="text-sm font-normal capitalize">
                      {testType}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Plant Filter */}
            <div>
              <Label>Plant/Lab</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {options.plant.map((plant) => (
                  <div key={plant} className="flex items-center space-x-2">
                    <Checkbox
                      id={`plant-${plant}`}
                      checked={selectedPlant.includes(plant)}
                      onCheckedChange={(checked) => handlePlantChange(plant, !!checked)}
                    />
                    <Label htmlFor={`plant-${plant}`} className="text-sm font-normal">
                      {plant}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Filters Summary */}
      {hasActiveFilters && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Active Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {getFilterSummary.map((filter, index) => (
                <Badge key={index} variant="secondary" className="gap-1">
                  {filter}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto p-0 hover:bg-transparent"
                    onClick={() => {
                      // Extract filter type and clear it
                      const filterType = filter.split(':')[0].toLowerCase();
                      if (filterType.includes('date')) clearFilter('dateRange');
                      else if (filterType.includes('status')) clearFilter('status');
                      else if (filterType.includes('priority')) clearFilter('priority');
                      else if (filterType.includes('test type')) clearFilter('testType');
                      else if (filterType.includes('plant')) clearFilter('plant');
                      else if (filterType.includes('search')) clearFilter('searchTerm');
                    }}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}