import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Download, FileText, Table, Database, AlertTriangle } from 'lucide-react';
import { dataExportService, type ExportOptions } from '@/services/export/dataExportService';
import { DashboardWidget } from '@/types/dashboard';
import { toast } from '@/hooks/use-toast';

interface ExportWidgetProps {
  widgets: DashboardWidget[];
  selectedWidget?: DashboardWidget;
  trigger?: React.ReactNode;
}

export function ExportWidget({ widgets, selectedWidget, trigger }: ExportWidgetProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [options, setOptions] = useState<ExportOptions>({
    format: 'excel',
    includeCharts: true
  });

  const handleExport = async () => {
    setLoading(true);
    setError(null);

    try {
      const exportWidgets = selectedWidget ? [selectedWidget] : widgets;
      
      if (exportWidgets.length === 0) {
        setError('No widgets available to export');
        return;
      }

      await dataExportService.exportDashboard(exportWidgets, options);
      
      toast({
        title: 'Export Successful',
        description: `Dashboard exported as ${options.format.toUpperCase()}`,
      });
      
      setOpen(false);
    } catch (err) {
      console.error('Export error:', err);
      setError('Failed to export dashboard. Please try again.');
      
      toast({
        title: 'Export Failed',
        description: 'There was an error exporting the dashboard',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const getFormatIcon = (format: string) => {
    switch (format) {
      case 'pdf': return FileText;
      case 'excel': return Table;
      case 'csv': return Table;
      case 'json': return Database;
      default: return Download;
    }
  };

  const exportFormats = [
    { value: 'excel', label: 'Excel (.xlsx)', description: 'Spreadsheet with multiple sheets' },
    { value: 'pdf', label: 'PDF Document', description: 'Formatted document with charts' },
    { value: 'csv', label: 'CSV Files', description: 'Comma-separated values' },
    { value: 'json', label: 'JSON Data', description: 'Raw data in JSON format' }
  ];

  const defaultTrigger = (
    <Button variant="outline" size="sm" className="gap-2">
      <Download className="h-4 w-4" />
      Export
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Dashboard
          </DialogTitle>
          <DialogDescription>
            Export your dashboard data in various formats for analysis or reporting.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div>
            <Label htmlFor="format">Export Format</Label>
            <Select 
              value={options.format} 
              onValueChange={(value: any) => setOptions(prev => ({ ...prev, format: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {exportFormats.map((format) => {
                  const Icon = getFormatIcon(format.value);
                  return (
                    <SelectItem key={format.value} value={format.value}>
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <div>
                          <div className="font-medium">{format.label}</div>
                          <div className="text-xs text-muted-foreground">{format.description}</div>
                        </div>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="filename">Filename (optional)</Label>
            <Input
              id="filename"
              placeholder="dashboard-export"
              value={options.filename || ''}
              onChange={(e) => setOptions(prev => ({ ...prev, filename: e.target.value }))}
            />
          </div>

          <div className="text-sm text-muted-foreground">
            {selectedWidget ? (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                Exporting: {selectedWidget.title}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                Exporting: {widgets.length} widget{widgets.length !== 1 ? 's' : ''}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
              Cancel
            </Button>
            <Button onClick={handleExport} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}