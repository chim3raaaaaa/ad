import React from 'react';
import { Grid } from 'lucide-react';

interface HeatmapData {
  x: string | number;
  y: string | number;
  value: number;
  label?: string;
}

interface HeatmapWidgetProps {
  title: string;
  description?: string;
  data: HeatmapData[];
  xAxisLabel?: string;
  yAxisLabel?: string;
  colorScale?: {
    min: string;
    max: string;
  };
  className?: string;
}

export function HeatmapWidget({
  title,
  description,
  data,
  xAxisLabel = "X",
  yAxisLabel = "Y",
  colorScale = { min: "#f0f9ff", max: "#1e40af" },
  className
}: HeatmapWidgetProps) {
  // Get unique x and y values
  const xValues = [...new Set(data.map(d => d.x))].sort();
  const yValues = [...new Set(data.map(d => d.y))].sort();
  
  // Get min and max values for color scaling
  const values = data.map(d => d.value);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  
  // Helper function to get color intensity
  const getColorIntensity = (value: number) => {
    if (maxValue === minValue) return 0.5;
    return (value - minValue) / (maxValue - minValue);
  };

  // Helper function to interpolate color
  const interpolateColor = (intensity: number) => {
    // Convert hex to RGB
    const hexToRgb = (hex: string) => {
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : { r: 0, g: 0, b: 0 };
    };

    const minRgb = hexToRgb(colorScale.min);
    const maxRgb = hexToRgb(colorScale.max);

    const r = Math.round(minRgb.r + (maxRgb.r - minRgb.r) * intensity);
    const g = Math.round(minRgb.g + (maxRgb.g - minRgb.g) * intensity);
    const b = Math.round(minRgb.b + (maxRgb.b - minRgb.b) * intensity);

    return `rgb(${r}, ${g}, ${b})`;
  };

  // Get data point for specific x,y coordinates
  const getDataPoint = (x: string | number, y: string | number) => {
    return data.find(d => d.x === x && d.y === y);
  };

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Heatmap Grid */}
      <div className="overflow-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="text-xs p-1 border"></th>
              {xValues.map(x => (
                <th key={x} className="text-xs p-1 border bg-muted/50 min-w-8">
                  {String(x).slice(0, 8)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {yValues.map(y => (
              <tr key={y}>
                <td className="text-xs p-1 border bg-muted/50 font-medium">
                  {String(y).slice(0, 8)}
                </td>
                {xValues.map(x => {
                  const dataPoint = getDataPoint(x, y);
                  const value = dataPoint?.value ?? 0;
                  const intensity = getColorIntensity(value);
                  const backgroundColor = interpolateColor(intensity);
                  
                  return (
                    <td
                      key={`${x}-${y}`}
                      className="text-xs p-1 border text-center cursor-pointer transition-all hover:scale-110 min-w-8 h-8"
                      style={{ backgroundColor }}
                      title={`${xAxisLabel}: ${x}, ${yAxisLabel}: ${y}, Value: ${value}${dataPoint?.label ? `, ${dataPoint.label}` : ''}`}
                    >
                      <div className="flex items-center justify-center h-full">
                        {value !== 0 && (
                          <span className={intensity > 0.5 ? 'text-white' : 'text-black'}>
                            {value.toFixed(1)}
                          </span>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Color Legend */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <div
            className="w-4 h-3 border"
            style={{ backgroundColor: colorScale.min }}
          ></div>
          <span>{minValue.toFixed(1)}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>{maxValue.toFixed(1)}</span>
          <div
            className="w-4 h-3 border"
            style={{ backgroundColor: colorScale.max }}
          ></div>
        </div>
      </div>
    </div>
  );
}