import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, startOfWeek, endOfWeek } from 'date-fns';

interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  type: 'test' | 'inspection' | 'maintenance' | 'meeting';
  priority?: 'low' | 'medium' | 'high';
}

interface CalendarWidgetProps {
  events?: CalendarEvent[];
  onEventClick?: (event: CalendarEvent) => void;
  onDateClick?: (date: Date) => void;
  onAddEvent?: (date: Date) => void;
  className?: string;
}

export function CalendarWidget({
  events = [],
  onEventClick,
  onDateClick,
  onAddEvent,
  className
}: CalendarWidgetProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  // Generate calendar days
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 }); // Monday start
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Get events for a specific date
  const getEventsForDate = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return events.filter(event => event.date === dateStr);
  };

  // Navigation functions
  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    onDateClick?.(date);
  };

  const getEventTypeColor = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'test': return 'bg-blue-500';
      case 'inspection': return 'bg-yellow-500';
      case 'maintenance': return 'bg-red-500';
      case 'meeting': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority?: CalendarEvent['priority']) => {
    switch (priority) {
      case 'high': return 'border-l-red-500';
      case 'medium': return 'border-l-yellow-500';
      case 'low': return 'border-l-green-500';
      default: return 'border-l-gray-300';
    }
  };

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Month/Year Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm">
          {format(currentDate, 'MMMM yyyy')}
        </h3>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={previousMonth} className="h-6 w-6 p-0">
            <ChevronLeft className="h-3 w-3" />
          </Button>
          <Button variant="ghost" size="sm" onClick={nextMonth} className="h-6 w-6 p-0">
            <ChevronRight className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 text-xs">
        {/* Day headers */}
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, index) => (
          <div key={index} className="text-center p-1 font-medium text-muted-foreground">
            {day}
          </div>
        ))}
        
        {/* Calendar days */}
        {calendarDays.map((day, index) => {
          const dayEvents = getEventsForDate(day);
          const isCurrentMonth = isSameMonth(day, currentDate);
          const isTodayDate = isToday(day);
          const isSelected = selectedDate && format(day, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');

          return (
            <div
              key={index}
              className={`
                relative p-1 min-h-8 cursor-pointer border rounded transition-colors
                ${isCurrentMonth ? 'text-foreground' : 'text-muted-foreground'}
                ${isTodayDate ? 'bg-primary/10 border-primary' : 'border-transparent hover:bg-muted/50'}
                ${isSelected ? 'bg-primary/20 border-primary' : ''}
              `}
              onClick={() => handleDateClick(day)}
            >
              <div className="text-center text-xs font-medium">
                {format(day, 'd')}
              </div>
              
              {/* Event indicators */}
              {dayEvents.length > 0 && (
                <div className="absolute bottom-0 left-0 right-0 flex justify-center">
                  <div className="flex gap-0.5">
                    {dayEvents.slice(0, 3).map((event, eventIndex) => (
                      <div
                        key={eventIndex}
                        className={`w-1 h-1 rounded-full ${getEventTypeColor(event.type)}`}
                        title={event.title}
                      />
                    ))}
                    {dayEvents.length > 3 && (
                      <div className="w-1 h-1 rounded-full bg-gray-400" title={`+${dayEvents.length - 3} more`} />
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Selected date events */}
      {selectedDate && (
        <div className="border-t pt-2">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-medium">
              {format(selectedDate, 'MMM d, yyyy')}
            </h4>
            {onAddEvent && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onAddEvent(selectedDate)}
                className="h-5 w-5 p-0"
              >
                <Plus className="h-3 w-3" />
              </Button>
            )}
          </div>
          
          <div className="space-y-1 max-h-20 overflow-y-auto">
            {getEventsForDate(selectedDate).map((event) => (
              <div
                key={event.id}
                className={`text-xs p-1 border-l-2 bg-muted/30 cursor-pointer hover:bg-muted/50 ${getPriorityColor(event.priority)}`}
                onClick={() => onEventClick?.(event)}
              >
                <div className="font-medium truncate">{event.title}</div>
                <div className="flex items-center gap-1">
                  <Badge variant="outline" className="text-xs px-1 py-0">
                    {event.type}
                  </Badge>
                  {event.priority && (
                    <Badge variant="outline" className="text-xs px-1 py-0">
                      {event.priority}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
            
            {getEventsForDate(selectedDate).length === 0 && (
              <div className="text-xs text-muted-foreground text-center py-2">
                No events scheduled
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}