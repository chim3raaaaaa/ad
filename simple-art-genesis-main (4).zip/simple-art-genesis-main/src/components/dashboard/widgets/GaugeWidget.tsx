import React from 'react';
import { Gauge } from 'lucide-react';

interface GaugeWidgetProps {
  title: string;
  value: number;
  min?: number;
  max?: number;
  unit?: string;
  thresholds?: {
    warning: number;
    critical: number;
  };
  description?: string;
  className?: string;
}

export function GaugeWidget({
  title,
  value,
  min = 0,
  max = 100,
  unit = "",
  thresholds = { warning: 70, critical: 90 },
  description,
  className
}: GaugeWidgetProps) {
  // Calculate percentage for gauge fill
  const percentage = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
  
  // Determine color based on thresholds
  const getColor = () => {
    if (value >= thresholds.critical) return "text-red-600";
    if (value >= thresholds.warning) return "text-yellow-600";
    return "text-green-600";
  };

  const getGaugeColor = () => {
    if (value >= thresholds.critical) return "stroke-red-500";
    if (value >= thresholds.warning) return "stroke-yellow-500";
    return "stroke-green-500";
  };

  // SVG gauge parameters
  const size = 120;
  const strokeWidth = 8;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * Math.PI; // Half circle
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className={`flex flex-col items-center justify-center h-full ${className}`}>
      <div className="relative">
        <svg width={size} height={size / 2 + 20} className="transform -rotate-180">
          {/* Background arc */}
          <path
            d={`M ${strokeWidth / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - strokeWidth / 2} ${size / 2}`}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />
          {/* Progress arc */}
          <path
            d={`M ${strokeWidth / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - strokeWidth / 2} ${size / 2}`}
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className={`transition-all duration-1000 ${getGaugeColor()}`}
          />
        </svg>
        
        {/* Center value */}
        <div className="absolute inset-0 flex flex-col items-center justify-center transform rotate-180">
          <div className={`text-2xl font-bold ${getColor()}`}>
            {typeof value === 'number' ? value.toFixed(1) : '0.0'}
          </div>
          <div className="text-xs text-muted-foreground">{unit}</div>
        </div>
      </div>

      {/* Percentage display */}
      <div className="mt-2 text-center">
        <div className="text-sm font-medium">{percentage.toFixed(1)}%</div>
        <div className="flex justify-between text-xs text-muted-foreground w-20">
          <span>{min}</span>
          <span>{max}</span>
        </div>
      </div>
    </div>
  );
}