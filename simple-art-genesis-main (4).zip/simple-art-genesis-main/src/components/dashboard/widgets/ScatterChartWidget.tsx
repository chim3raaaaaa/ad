import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

interface ScatterChartWidgetProps {
  title: string;
  description?: string;
  data: Array<{ x: number; y: number; name?: string }>;
  xAxisLabel?: string;
  yAxisLabel?: string;
  className?: string;
}

export function ScatterChartWidget({ 
  title, 
  description, 
  data, 
  xAxisLabel = "X", 
  yAxisLabel = "Y",
  className 
}: ScatterChartWidgetProps) {
  // Transform data for scatter chart
  const scatterData = data.map((point, index) => ({
    x: point.x,
    y: point.y,
    name: point.name || `Point ${index + 1}`
  }));

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border rounded-lg p-2 shadow-md">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm text-muted-foreground">
            {xAxisLabel}: {data.x}
          </p>
          <p className="text-sm text-muted-foreground">
            {yAxisLabel}: {data.y}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart data={scatterData} margin={{ top: 10, right: 10, bottom: 20, left: 10 }}>
          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
          <XAxis 
            type="number" 
            dataKey="x" 
            name={xAxisLabel}
            fontSize={10}
          />
          <YAxis 
            type="number" 
            dataKey="y" 
            name={yAxisLabel}
            fontSize={10}
          />
          <Tooltip content={<CustomTooltip />} />
          <Scatter 
            dataKey="y" 
            fill="hsl(var(--primary))" 
            fillOpacity={0.8}
          />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}