import React from 'react';
import { LucideIcon } from 'lucide-react';

interface KPIWidgetProps {
  title: string;
  value: string | number;
  description?: string;
  icon?: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  color?: string;
}

export function KPIWidget({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend = 'neutral',
  color = 'text-primary'
}: KPIWidgetProps) {
  return (
    <div className="flex flex-col justify-between h-full">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
        {Icon && <Icon className={`h-4 w-4 ${color}`} />}
      </div>
      <div className="flex-1 flex items-center">
        <div className={`text-2xl font-bold ${color}`}>
          {value}
        </div>
      </div>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}
    </div>
  );
}