import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, BarChart3, PieChart, LineChart, TrendingUp, Activity, ArrowLeft, Gauge, Grid, GitBranch } from 'lucide-react';
import { analyticsService, type AnalyticsChart } from '@/services/analytics/analyticsService';
import { WidgetDataBinding } from './WidgetDataBinding';
import type { DashboardWidget } from '@/types/dashboard';

interface WidgetSelectorProps {
  onAddWidget: (widget: DashboardWidget) => void;
  disabled?: boolean;
  userId: string;
}

const quickWidgetTypes = [
  {
    id: 'kpi',
    type: 'kpi' as const,
    title: 'KPI Metric',
    description: 'Display key performance indicators from your data',
    icon: TrendingUp
  },
  {
    id: 'bar',
    type: 'bar' as const,
    title: 'Bar Chart',
    description: 'Compare values across categories',
    icon: BarChart3
  },
  {
    id: 'pie',
    type: 'pie' as const,
    title: 'Pie Chart',
    description: 'Show proportions and percentages',
    icon: PieChart
  },
  {
    id: 'line',
    type: 'line' as const,
    title: 'Line Chart',
    description: 'Display trends over time',
    icon: LineChart
  },
  {
    id: 'scatter',
    type: 'scatter' as const,
    title: 'Scatter Plot',
    description: 'Analyze correlations between variables',
    icon: GitBranch
  },
  {
    id: 'gauge',
    type: 'gauge' as const,
    title: 'Gauge Meter',
    description: 'Show progress towards targets with thresholds',
    icon: Gauge
  },
  {
    id: 'heatmap',
    type: 'heatmap' as const,
    title: 'Heatmap',
    description: 'Visualize data density and patterns',
    icon: Grid
  }
];

export function WidgetSelector({ onAddWidget, disabled = false, userId }: WidgetSelectorProps) {
  const [open, setOpen] = useState(false);
  const [analyticsCharts, setAnalyticsCharts] = useState<AnalyticsChart[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedWidgetType, setSelectedWidgetType] = useState<'kpi' | 'bar' | 'pie' | 'line' | 'scatter' | 'gauge' | 'heatmap' | null>(null);

  useEffect(() => {
    if (open) {
      loadAnalyticsCharts();
    }
  }, [open, userId]);

  const loadAnalyticsCharts = async () => {
    setLoading(true);
    try {
      const charts = await analyticsService.getUserCharts(userId);
      setAnalyticsCharts(charts);
    } catch (error) {
      console.error('Error loading analytics charts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickWidgetSelect = (widgetType: 'kpi' | 'bar' | 'pie' | 'line' | 'scatter' | 'gauge' | 'heatmap') => {
    setSelectedWidgetType(widgetType);
  };

  const handleAddAnalyticsChart = (chart: AnalyticsChart) => {
    const newWidget: DashboardWidget = {
      id: `analytics-${chart.id}-${Date.now()}`,
      type: 'analytics_chart',
      title: chart.chart_name,
      x: 0,
      y: 0,
      w: 6,
      h: 4,
      minW: 4,
      minH: 3,
      enabled: true,
      data: {
        chartId: chart.id,
        chartType: chart.chart_type
      }
    };
    
    onAddWidget(newWidget);
    setOpen(false);
  };

  const handleWidgetSave = (widget: DashboardWidget) => {
    onAddWidget(widget);
    setOpen(false);
    setSelectedWidgetType(null);
  };

  const handleCancel = () => {
    setSelectedWidgetType(null);
  };

  const handleDialogClose = (isOpen: boolean) => {
    setOpen(isOpen);
    if (!isOpen) {
      setSelectedWidgetType(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleDialogClose}>
      <DialogTrigger asChild>
        <Button disabled={disabled} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Widget
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {selectedWidgetType && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setSelectedWidgetType(null)}
                className="mr-2"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            Add Dashboard Widget
          </DialogTitle>
          <DialogDescription>
            {selectedWidgetType 
              ? `Configure your ${selectedWidgetType.toUpperCase()} widget with real data`
              : 'Choose from quick widgets or add your saved analytics charts'
            }
          </DialogDescription>
        </DialogHeader>
        
        {selectedWidgetType ? (
          <WidgetDataBinding 
            widgetType={selectedWidgetType}
            onSave={handleWidgetSave}
            onCancel={handleCancel}
          />
        ) : (
          <Tabs defaultValue="quick" className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="quick">Quick Widgets</TabsTrigger>
              <TabsTrigger value="analytics">Analytics Charts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="quick" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {quickWidgetTypes.map((widget) => (
                  <Card 
                    key={widget.id} 
                    className="cursor-pointer transition-all hover:scale-105 hover:shadow-md border-2 hover:border-primary/50"
                    onClick={() => handleQuickWidgetSelect(widget.type)}
                  >
                    <CardHeader className="text-center pb-2">
                      <widget.icon className="h-10 w-10 mx-auto text-primary mb-3" />
                      <CardTitle className="text-lg">{widget.title}</CardTitle>
                      <CardDescription className="text-sm">
                        {widget.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0 text-center">
                      <Button variant="outline" size="sm" className="w-full">
                        Configure Data →
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="space-y-4">
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading your analytics charts...</p>
                </div>
              ) : analyticsCharts.length === 0 ? (
                <div className="text-center py-8">
                  <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No analytics charts found.</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Create charts in the Analytics page to add them here.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {analyticsCharts.map((chart) => {
                    const IconComponent = chart.chart_type === 'bar' ? BarChart3 :
                                        chart.chart_type === 'pie' ? PieChart : LineChart;
                    
                    return (
                      <Card 
                        key={chart.id} 
                        className="cursor-pointer transition-all hover:scale-105 hover:shadow-md"
                        onClick={() => handleAddAnalyticsChart(chart)}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2">
                            <IconComponent className="h-5 w-5 text-primary" />
                            <CardTitle className="text-sm">{chart.chart_name}</CardTitle>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <CardDescription className="text-xs">
                            {chart.chart_type.toUpperCase()} • {chart.data_source}
                          </CardDescription>
                          <div className="mt-2 text-xs text-muted-foreground">
                            {new Date(chart.created_at).toLocaleDateString()}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}