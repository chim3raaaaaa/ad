import { useState, useEffect } from "react";
import { Filter, X, CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { format } from "date-fns";
import type { TestCalendarFilters as CalendarFilters } from "@/services/database/realTimeTestCalendarService";
import { testCalendarDataService } from "@/services/calendar/testCalendarDataService";

interface Props {
  filters: CalendarFilters;
  onFiltersChange: (filters: CalendarFilters) => void;
}

export const TestCalendarFilters = ({ filters, onFiltersChange }: Props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [referenceData, setReferenceData] = useState<{
    lab_sites: string[];
    products: string[];
    test_types: string[];
  }>({
    lab_sites: [],
    products: [],
    test_types: []
  });

  useEffect(() => {
    // Load reference data for filters
    loadReferenceData();
  }, []);

  const loadReferenceData = async () => {
    try {
      const isElectron = typeof window !== 'undefined' && !!window.electronAPI;
      
      if (isElectron) {
        try {
          const options = await testCalendarDataService.getFilterOptions();
          setReferenceData({
            lab_sites: options.labSites,
            products: options.products,
            test_types: options.testTypes
          });
          
          console.log('Filter options loaded:', {
            labSites: options.labSites.length,
            products: options.products.length,
            testTypes: options.testTypes.length
          });
        } catch (error) {
          console.error('Error loading filter options:', error);
          setReferenceData({
            lab_sites: [],
            products: [],
            test_types: []
          });
        }
      } else {
        throw new Error('Electron environment required for Test Calendar');
      }
    } catch (error) {
      console.error("Test Calendar requires Electron environment:", error);
      setReferenceData({
        lab_sites: [],
        products: [],
        test_types: []
      });
    }
  };

  const updateFilter = (key: keyof CalendarFilters, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const clearFilter = (key: keyof CalendarFilters) => {
    const newFilters = { ...filters };
    delete newFilters[key];
    onFiltersChange(newFilters);
  };

  const clearAllFilters = () => {
    onFiltersChange({});
  };

  const activeFilterCount = Object.keys(filters).filter(key => 
    filters[key as keyof CalendarFilters] !== undefined && 
    filters[key as keyof CalendarFilters] !== ""
  ).length;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="flex items-center justify-between">
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
        </CollapsibleTrigger>

        {activeFilterCount > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllFilters}>
            Clear All
          </Button>
        )}
      </div>

      <CollapsibleContent>
        <Card className="p-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Lab Site Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Lab Site</label>
              <div className="flex gap-2">
                <Select
                  value={filters.labSite || "__all__"}
                  onValueChange={(value) => updateFilter("labSite", value === "__all__" ? undefined : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All sites" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">All sites</SelectItem>
                    {referenceData.lab_sites.map(site => (
                      <SelectItem key={site} value={site}>{site}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {filters.labSite && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => clearFilter("labSite")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>

            {/* Product Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Product</label>
              <div className="flex gap-2">
                <Select
                  value={filters.product || "__all__"}
                  onValueChange={(value) => updateFilter("product", value === "__all__" ? undefined : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All products" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">All products</SelectItem>
                    {referenceData.products.map(product => (
                      <SelectItem key={product} value={product}>{product}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {filters.product && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => clearFilter("product")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>

            {/* Test Type Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Test Type</label>
              <div className="flex gap-2">
                <Select
                  value={filters.testType || "__all__"}
                  onValueChange={(value) => updateFilter("testType", value === "__all__" ? undefined : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All tests" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">All tests</SelectItem>
                    {referenceData.test_types.map(testType => (
                      <SelectItem key={testType} value={testType}>{testType}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {filters.testType && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => clearFilter("testType")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>

            {/* Status Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <div className="flex gap-2">
                <Select
                  value={filters.status || "__all__"}
                  onValueChange={(value) => updateFilter("status", value === "__all__" ? undefined : value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">All statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
                {filters.status && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => clearFilter("status")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Date Range Filter */}
          <div className="mt-4 pt-4 border-t">
            <label className="text-sm font-medium mb-2 block">Date Range</label>
            <div className="flex flex-col sm:flex-row gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.startDate ? (
                      format(new Date(filters.startDate), "PPP")
                    ) : (
                      <span>Start date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={filters.startDate ? new Date(filters.startDate) : undefined}
                    onSelect={(date) => 
                      updateFilter("startDate", date?.toISOString().split('T')[0] || "")
                    }
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.endDate ? (
                      format(new Date(filters.endDate), "PPP")
                    ) : (
                      <span>End date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={filters.endDate ? new Date(filters.endDate) : undefined}
                    onSelect={(date) => 
                      updateFilter("endDate", date?.toISOString().split('T')[0] || "")
                    }
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              
              {(filters.startDate || filters.endDate) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    clearFilter("startDate");
                    clearFilter("endDate");
                  }}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          </div>
        </Card>
      </CollapsibleContent>
    </Collapsible>
  );
};