import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowLeft, 
  ArrowRight, 
  ExternalLink, 
  Filter, 
  Search, 
  Eye, 
  Database,
  Link as LinkIcon,
  ChevronRight,
  Home
} from 'lucide-react';
import { dataService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import type { TableRelationship, NavigationPath } from '@/services/api/types';

interface LinkedTableViewsProps {
  tableName: string;
  recordId: string;
  onNavigate?: (tableName: string, recordId: string) => void;
}

export default function LinkedTableViews({ tableName, recordId, onNavigate }: LinkedTableViewsProps) {
  const [relationships, setRelationships] = useState<TableRelationship[]>([]);
  const [relatedData, setRelatedData] = useState<Record<string, any[]>>({});
  const [navigationPath, setNavigationPath] = useState<NavigationPath[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerms, setSearchTerms] = useState<Record<string, string>>({});
  const [filterValues, setFilterValues] = useState<Record<string, string>>({});
  const { toast } = useToast();

  useEffect(() => {
    loadRelationships();
    loadNavigationPath();
  }, [tableName, recordId]);

  useEffect(() => {
    if (relationships.length > 0) {
      loadRelatedData();
    }
  }, [relationships]);

  const loadRelationships = async () => {
    try {
      const response = await dataService.getTableRelationships(tableName);
      setRelationships(response.data);
    } catch (error) {
      console.error('Failed to load relationships:', error);
    }
  };

  const loadNavigationPath = async () => {
    try {
      const response = await dataService.getNavigationPath(tableName, recordId);
      setNavigationPath(response.data);
    } catch (error) {
      console.error('Failed to load navigation path:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadRelatedData = async () => {
    const data: Record<string, any[]> = {};
    
    for (const relationship of relationships) {
      try {
        const response = await dataService.getRelatedRecords(tableName, recordId, relationship.id);
        data[relationship.id] = response.data;
      } catch (error) {
        console.error(`Failed to load related data for ${relationship.child_table}:`, error);
        data[relationship.id] = [];
      }
    }
    
    setRelatedData(data);
  };

  const handleNavigateToRecord = (targetTable: string, targetRecordId: string, displayName: string) => {
    // Add to navigation path
    const newPath: NavigationPath = {
      table: targetTable,
      record_id: targetRecordId,
      display_name: displayName
    };
    
    setNavigationPath([...navigationPath, newPath]);
    
    if (onNavigate) {
      onNavigate(targetTable, targetRecordId);
    }
  };

  const handleBreadcrumbClick = (index: number) => {
    const targetPath = navigationPath[index];
    const newPath = navigationPath.slice(0, index + 1);
    setNavigationPath(newPath);
    
    if (onNavigate) {
      onNavigate(targetPath.table, targetPath.record_id);
    }
  };

  const filterRelatedData = (relationshipId: string, data: any[]) => {
    const searchTerm = searchTerms[relationshipId]?.toLowerCase() || '';
    const filterValue = filterValues[relationshipId];
    
    return data.filter(record => {
      // Search filter
      if (searchTerm) {
        const searchableFields = Object.values(record).join(' ').toLowerCase();
        if (!searchableFields.includes(searchTerm)) {
          return false;
        }
      }
      
      // Additional filters would go here
      if (filterValue && filterValue !== 'all') {
        // Apply specific filter logic based on the filter value
        return true;
      }
      
      return true;
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Navigation Breadcrumbs */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Linked Data Navigation
            </CardTitle>
            
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink onClick={() => handleBreadcrumbClick(-1)} className="cursor-pointer">
                    <Home className="w-4 h-4" />
                  </BreadcrumbLink>
                </BreadcrumbItem>
                
                {navigationPath.map((path, index) => (
                  <React.Fragment key={index}>
                    <BreadcrumbSeparator>
                      <ChevronRight className="w-4 h-4" />
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                      {index === navigationPath.length - 1 ? (
                        <BreadcrumbPage>{path.display_name}</BreadcrumbPage>
                      ) : (
                        <BreadcrumbLink 
                          onClick={() => handleBreadcrumbClick(index)}
                          className="cursor-pointer"
                        >
                          {path.display_name}
                        </BreadcrumbLink>
                      )}
                    </BreadcrumbItem>
                  </React.Fragment>
                ))}
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Database className="w-4 h-4" />
              Current Table: <span className="font-medium">{tableName}</span>
            </div>
            <div className="flex items-center gap-1">
              <LinkIcon className="w-4 h-4" />
              Record ID: <span className="font-medium">{recordId}</span>
            </div>
            <div className="flex items-center gap-1">
              <ArrowRight className="w-4 h-4" />
              Related Tables: <span className="font-medium">{relationships.length}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Related Tables */}
      {relationships.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Database className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No related tables found</h3>
            <p className="text-muted-foreground">
              This record doesn't have any configured relationships to other tables
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {relationships.map((relationship) => {
            const data = relatedData[relationship.id] || [];
            const filteredData = filterRelatedData(relationship.id, data);
            
            return (
              <Card key={relationship.id}>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">
                        {relationship.child_table.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </CardTitle>
                      <Badge variant="outline">
                        {relationship.relationship_type}
                      </Badge>
                      <Badge variant="secondary">
                        {filteredData.length} records
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          placeholder="Search records..."
                          value={searchTerms[relationship.id] || ''}
                          onChange={(e) => setSearchTerms({
                            ...searchTerms,
                            [relationship.id]: e.target.value
                          })}
                          className="pl-8 w-64"
                        />
                      </div>
                      
                      <Select 
                        value={filterValues[relationship.id] || 'all'} 
                        onValueChange={(value) => setFilterValues({
                          ...filterValues,
                          [relationship.id]: value
                        })}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="recent">Recent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  {filteredData.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Database className="w-8 h-8 mx-auto mb-2" />
                      <p>No related records found</p>
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            {Object.keys(filteredData[0] || {}).slice(0, 5).map((column) => (
                              <TableHead key={column} className="capitalize">
                                {column.replace(/_/g, ' ')}
                              </TableHead>
                            ))}
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredData.slice(0, 10).map((record, index) => (
                            <TableRow key={index} className="hover:bg-muted/50">
                              {Object.entries(record).slice(0, 5).map(([key, value]) => (
                                <TableCell key={key}>
                                  {typeof value === 'string' && value.length > 50 
                                    ? `${value.substring(0, 50)}...`
                                    : typeof value === 'object' 
                                      ? JSON.stringify(value).substring(0, 30) + '...'
                                      : String(value)
                                  }
                                </TableCell>
                              ))}
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleNavigateToRecord(
                                      relationship.child_table,
                                      record.id,
                                      record[relationship.display_field] || record.id
                                    )}
                                  >
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleNavigateToRecord(
                                      relationship.child_table,
                                      record.id,
                                      record[relationship.display_field] || record.id
                                    )}
                                  >
                                    <ExternalLink className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      
                      {filteredData.length > 10 && (
                        <div className="p-4 border-t bg-muted/25 text-center">
                          <p className="text-sm text-muted-foreground">
                            Showing 10 of {filteredData.length} records
                          </p>
                          <Button variant="outline" size="sm" className="mt-2">
                            Load More
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Quick Navigation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowRight className="w-5 h-5" />
            Quick Navigation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Dynamic navigation based on available tables */}
            {window.electronAPI ? (
              <>
                <Button
                  variant="outline"
                  className="h-20 flex-col"
                  onClick={() => handleNavigateToRecord('mix_designs', 'auto', 'Mix Designs')}
                >
                  <Database className="w-6 h-6 mb-2" />
                  Mix Designs
                </Button>
                
                <Button
                  variant="outline"
                  className="h-20 flex-col"
                  onClick={() => handleNavigateToRecord('test_batches', 'auto', 'Test Batches')}
                >
                  <Database className="w-6 h-6 mb-2" />
                  Test Batches
                </Button>
                
                <Button
                  variant="outline"
                  className="h-20 flex-col"
                  onClick={() => handleNavigateToRecord('reports', 'auto', 'Reports')}
                >
                  <Database className="w-6 h-6 mb-2" />
                  Reports
                </Button>
                
                <Button
                  variant="outline"
                  className="h-20 flex-col"
                  onClick={() => handleNavigateToRecord('samples', 'auto', 'Samples')}
                >
                  <Database className="w-6 h-6 mb-2" />
                  Samples
                </Button>
              </>
            ) : (
              <div className="col-span-4 text-center text-muted-foreground py-8">
                Database navigation available in full application
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Navigation Hook for easy integration
export function useLinkedTableNavigation() {
  const [currentTable, setCurrentTable] = useState<string>('');
  const [currentRecord, setCurrentRecord] = useState<string>('');
  const [navigationHistory, setNavigationHistory] = useState<NavigationPath[]>([]);

  const navigateTo = (tableName: string, recordId: string, displayName?: string) => {
    const newPath: NavigationPath = {
      table: tableName,
      record_id: recordId,
      display_name: displayName || recordId
    };

    setCurrentTable(tableName);
    setCurrentRecord(recordId);
    setNavigationHistory(prev => [...prev, newPath]);
  };

  const goBack = () => {
    if (navigationHistory.length > 1) {
      const newHistory = navigationHistory.slice(0, -1);
      const previousPath = newHistory[newHistory.length - 1];
      
      setNavigationHistory(newHistory);
      setCurrentTable(previousPath.table);
      setCurrentRecord(previousPath.record_id);
    }
  };

  const goToPath = (index: number) => {
    if (index >= 0 && index < navigationHistory.length) {
      const targetPath = navigationHistory[index];
      const newHistory = navigationHistory.slice(0, index + 1);
      
      setNavigationHistory(newHistory);
      setCurrentTable(targetPath.table);
      setCurrentRecord(targetPath.record_id);
    }
  };

  return {
    currentTable,
    currentRecord,
    navigationHistory,
    navigateTo,
    goBack,
    goToPath,
    canGoBack: navigationHistory.length > 1
  };
}