import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Shield, 
  Download, 
  Search, 
  Filter,
  Eye,
  Calendar,
  User,
  Database,
  FileText,
  Clock,
  AlertTriangle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  resource: string;
  details?: string;
  ip: string;
  severity: 'info' | 'warning' | 'critical';
}

export function AuditTrail() {
  const { toast } = useToast();
  
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AuditLogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [resourceFilter, setResourceFilter] = useState<string>('all');
  const [userFilter, setUserFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load audit logs
  const loadAuditLogs = useCallback(async () => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        // Create audit_logs table if it doesn't exist
        const createAuditTableSQL = `
          CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            user TEXT NOT NULL,
            action TEXT NOT NULL,
            resource TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            severity TEXT DEFAULT 'info'
          )
        `;
        await window.electronAPI.dbRun(createAuditTableSQL);
        
        // Load actual logs from database
        const result = await window.electronAPI.dbQuery(`
          SELECT * FROM audit_logs 
          ORDER BY timestamp DESC 
          LIMIT 100
        `);
        
        const logs = result.map(row => ({
          id: row.id.toString(),
          timestamp: row.timestamp,
          user: row.user,
          action: row.action,
          resource: row.resource,
          details: row.details,
          ip: row.ip_address,
          severity: row.severity
        }));
        
        setLogs(logs);
      } else {
        // Fallback mock data
        const mockLogs: AuditLogEntry[] = [
          {
            id: '1',
            timestamp: new Date().toISOString(),
            user: 'System',
            action: 'INFO',
            resource: 'audit_trail',
            details: 'Audit system initialized (no database connection)',
            ip: '127.0.0.1',
            severity: 'info'
          }
        ];
        setLogs(mockLogs);
      }
    } catch (error) {
      console.error('Error loading audit logs:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAuditLogs();
  }, [loadAuditLogs]);

  // Apply filters
  useEffect(() => {
    let filtered = logs;

    if (searchTerm) {
      filtered = filtered.filter(log => 
        log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.resource?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.action.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (actionFilter !== 'all') {
      filtered = filtered.filter(log => log.action === actionFilter);
    }

    if (resourceFilter !== 'all') {
      filtered = filtered.filter(log => log.resource === resourceFilter);
    }

    if (userFilter !== 'all') {
      filtered = filtered.filter(log => log.user === userFilter);
    }

    if (severityFilter !== 'all') {
      filtered = filtered.filter(log => log.severity === severityFilter);
    }

    setFilteredLogs(filtered);
  }, [logs, searchTerm, actionFilter, resourceFilter, userFilter, severityFilter]);

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'create': return <Database className="w-4 h-4" />;
      case 'update': return <FileText className="w-4 h-4" />;
      case 'delete': return <AlertTriangle className="w-4 h-4" />;
      case 'view': return <Eye className="w-4 h-4" />;
      case 'export': return <Download className="w-4 h-4" />;
      case 'login': return <User className="w-4 h-4" />;
      case 'logout': return <User className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'create': return 'bg-green-100 text-green-800';
      case 'update': return 'bg-blue-100 text-blue-800';
      case 'delete': return 'bg-red-100 text-red-800';
      case 'view': return 'bg-gray-100 text-gray-800';
      case 'export': return 'bg-purple-100 text-purple-800';
      case 'login': return 'bg-indigo-100 text-indigo-800';
      case 'logout': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'info': return 'bg-blue-100 text-blue-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const exportAuditLog = (format: 'csv' | 'json') => {
    const data = format === 'json' 
      ? JSON.stringify(filteredLogs, null, 2)
      : [
          ['Timestamp', 'User', 'Action', 'Resource', 'Details', 'IP Address'].join(','),
            ...filteredLogs.map(log => [
              log.timestamp,
              log.user,
              log.action,
              log.resource,
              log.details || '',
              log.ip
            ].map(field => `"${field}"`).join(','))
        ].join('\n');

    const blob = new Blob([data], { type: format === 'json' ? 'application/json' : 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `audit_log_${new Date().toISOString().split('T')[0]}.${format}`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: `Audit log exported as ${format.toUpperCase()}`
    });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setActionFilter('all');
    setResourceFilter('all');
    setUserFilter('all');
    setSeverityFilter('all');
  };

  const uniqueActions = Array.from(new Set(logs.map(log => log.action)));
  const uniqueResources = Array.from(new Set(logs.map(log => log.resource)));
  const uniqueUsers = Array.from(new Set(logs.map(log => log.user)));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Audit Trail
          </h3>
          <p className="text-sm text-muted-foreground">Track all system activities and changes</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => exportAuditLog('csv')}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button variant="outline" onClick={() => exportAuditLog('json')}>
            <Download className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
        </div>
      </div>

      <Tabs defaultValue="logs" className="space-y-4">
        <TabsList>
          <TabsTrigger value="logs">Audit Logs</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="logs" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
                <div className="lg:col-span-2">
                  <Label>Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search logs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                
                <div>
                  <Label>Action</Label>
                  <Select value={actionFilter} onValueChange={setActionFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Actions</SelectItem>
                      {uniqueActions.map(action => (
                        <SelectItem key={action} value={action}>
                          {action.charAt(0).toUpperCase() + action.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Resource</Label>
                  <Select value={resourceFilter} onValueChange={setResourceFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Resources</SelectItem>
                      {uniqueResources.map(resource => (
                        <SelectItem key={resource} value={resource}>
                          {resource.replace('_', ' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>User</Label>
                  <Select value={userFilter} onValueChange={setUserFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                       {uniqueUsers.map((user, index) => (
                          <SelectItem key={`${user}_${index}`} value={user}>
                            {user}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Severity</Label>
                  <Select value={severityFilter} onValueChange={setSeverityFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing {filteredLogs.length} of {logs.length} entries
                </div>
                <Button variant="outline" size="sm" onClick={clearFilters}>
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Audit Log Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Resource</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map(log => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-xs">
                        {new Date(log.timestamp).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-muted-foreground" />
                          {log.user}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getActionColor(log.action)}>
                          <div className="flex items-center gap-1">
                            {getActionIcon(log.action)}
                            {log.action}
                          </div>
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{log.resource}</div>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate" title={log.details}>
                          {log.details}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getSeverityColor(log.severity)}>
                          {log.severity}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {log.ip}
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm" onClick={() => setSelectedLog(log)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Audit Log Details</DialogTitle>
                            </DialogHeader>
                            {selectedLog && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label>Timestamp</Label>
                                    <p className="text-sm font-mono">{new Date(selectedLog.timestamp).toLocaleString()}</p>
                                  </div>
                                   <div>
                                     <Label>ID</Label>
                                     <p className="text-sm font-mono">{selectedLog.id}</p>
                                   </div>
                                </div>

                                 <div className="grid grid-cols-2 gap-4">
                                   <div>
                                     <Label>User</Label>
                                     <p className="text-sm">{selectedLog.user}</p>
                                   </div>
                                   <div>
                                     <Label>IP Address</Label>
                                     <p className="text-sm font-mono">{selectedLog.ip}</p>
                                   </div>
                                 </div>

                                 <div className="grid grid-cols-3 gap-4">
                                   <div>
                                     <Label>Action</Label>
                                     <Badge className={getActionColor(selectedLog.action)}>
                                       {selectedLog.action}
                                     </Badge>
                                   </div>
                                   <div>
                                     <Label>Resource</Label>
                                     <p className="text-sm">{selectedLog.resource}</p>
                                   </div>
                                   <div>
                                     <Label>Severity</Label>
                                     <Badge className={getSeverityColor(selectedLog.severity)}>
                                       {selectedLog.severity}
                                     </Badge>
                                   </div>
                                 </div>

                                 {selectedLog.details && (
                                   <div>
                                     <Label>Details</Label>
                                     <p className="text-sm">{selectedLog.details}</p>
                                   </div>
                                 )}
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{logs.length}</div>
                <p className="text-xs text-muted-foreground">Total Entries</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-red-600">
                  {logs.filter(log => log.severity === 'critical').length}
                </div>
                <p className="text-xs text-muted-foreground">Critical Events</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-orange-600">
                  {logs.filter(log => log.severity === 'warning').length}
                </div>
                <p className="text-xs text-muted-foreground">Warnings</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-green-600">
                  {uniqueUsers.length}
                </div>
                <p className="text-xs text-muted-foreground">Active Users</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Audit Trail Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Audit Logging</Label>
                  <p className="text-sm text-muted-foreground">Track all system activities</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Log Data Changes</Label>
                  <p className="text-sm text-muted-foreground">Store before/after data for updates</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Log User Sessions</Label>
                  <p className="text-sm text-muted-foreground">Track login/logout activities</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div>
                <Label>Retention Period (days)</Label>
                <Input type="number" defaultValue="365" className="w-32" />
              </div>

              <Button>Save Configuration</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Export missing icons
import { Plus, Edit, Trash2, LogIn, LogOut } from "lucide-react";