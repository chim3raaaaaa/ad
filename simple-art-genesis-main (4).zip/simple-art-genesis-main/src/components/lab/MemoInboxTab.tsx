import { useState, useEffect } from "react";
import { Clock, AlertTriangle, CheckCircle, User, Calendar, Flag, Eye, MessageSquare } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { memoInboxService, type MemoInboxEntry, type AcknowledgmentChecklist, type ChecklistItem } from "@/services/database/memoInboxService";
import { useMemoContext } from "@/contexts/MemoContext";
import { useAuth } from "@/contexts/AuthContext";
import { notificationIntegrationService } from "@/services/notifications/notificationIntegrationService";
import { EmptyState } from "@/components/ui/empty-state";

export function MemoInboxTab() {
  const { toast } = useToast();
  const { memos } = useMemoContext();
  const { user, hasPermission } = useAuth();
  const [inboxEntries, setInboxEntries] = useState<MemoInboxEntry[]>([]);
  const [checklists, setChecklists] = useState<AcknowledgmentChecklist[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<MemoInboxEntry | null>(null);
  const [selectedChecklist, setSelectedChecklist] = useState<AcknowledgmentChecklist | null>(null);
  const [checklistResponses, setChecklistResponses] = useState<Record<string, boolean | string>>({});
  const [acknowledgmentNotes, setAcknowledgmentNotes] = useState("");
  const [discrepancyNotes, setDiscrepancyNotes] = useState("");
  const [discrepancyCategory, setDiscrepancyCategory] = useState("");
  const [discrepancyPriority, setDiscrepancyPriority] = useState<'minor' | 'major' | 'critical'>('minor');
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [showDiscrepancyDialog, setShowDiscrepancyDialog] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInboxData();
  }, []);

  const loadInboxData = async () => {
    try {
      setLoading(true);
      const [entries, checklistData] = await Promise.all([
        memoInboxService.getInboxEntries('pending'),
        memoInboxService.getChecklists()
      ]);
      setInboxEntries(entries);
      setChecklists(checklistData);
    } catch (error) {
      console.error('Error loading inbox data:', error);
      toast({
        title: "Error",
        description: "Failed to load inbox data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'acknowledged': return 'bg-green-100 text-green-800 border-green-200';
      case 'flagged': return 'bg-red-100 text-red-800 border-red-200';
      case 'revision_required': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'critical': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'high': return <Flag className="h-4 w-4 text-orange-500" />;
      case 'normal': return <Clock className="h-4 w-4 text-blue-500" />;
      default: return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getMemoData = (memoId: string) => {
    return memos.find(memo => memo.id === memoId);
  };

  const handleReviewMemo = (entry: MemoInboxEntry) => {
    setSelectedEntry(entry);
    const categoryChecklists = checklists.filter(c => c.category === entry.category);
    if (categoryChecklists.length > 0) {
      setSelectedChecklist(categoryChecklists[0]);
      // Initialize responses
      const responses: Record<string, boolean | string> = {};
      categoryChecklists[0].checklist_items.forEach(item => {
        responses[item.id] = item.required ? false : true;
      });
      setChecklistResponses(responses);
    }
    setShowReviewDialog(true);
  };

  const handleAcknowledgeMemo = async () => {
    if (!selectedEntry || !selectedChecklist) return;

    try {
      // Validate required items
      const requiredItems = selectedChecklist.checklist_items.filter(item => item.required);
      const missingRequired = requiredItems.filter(item => !checklistResponses[item.id]);
      
      if (missingRequired.length > 0) {
        toast({
          title: "Validation Error",
          description: "Please complete all required checklist items",
          variant: "destructive"
        });
        return;
      }

      await memoInboxService.acknowledgeMemo(
        selectedEntry.id,
        user?.id || 'unknown-user',
        selectedChecklist.id,
        checklistResponses,
        acknowledgmentNotes
      );

      // Trigger notification
      const memoData = getMemoData(selectedEntry.memo_id);
      if (memoData) {
        notificationIntegrationService.triggerMemoAcknowledged({
          id: selectedEntry.memo_id,
          reference: selectedEntry.memo_reference,
          status: 'acknowledged',
          plant: memoData.labSite || 'Unknown',
          createdAt: selectedEntry.submitted_at,
          updatedAt: new Date().toISOString(),
          acknowledgedBy: user?.id || 'Unknown User'
        });
      }

      toast({
        title: "Success",
        description: "Memo acknowledged successfully",
      });

      setShowReviewDialog(false);
      setAcknowledgmentNotes("");
      setChecklistResponses({});
      loadInboxData();
    } catch (error) {
      console.error('Error acknowledging memo:', error);
      toast({
        title: "Error",
        description: "Failed to acknowledge memo",
        variant: "destructive"
      });
    }
  };

  const handleFlagDiscrepancy = async () => {
    if (!selectedEntry || !discrepancyCategory || !discrepancyNotes) return;

    try {
      await memoInboxService.flagMemoDiscrepancy(
        selectedEntry.id,
        user?.id || 'unknown-user',
        discrepancyCategory,
        discrepancyNotes,
        discrepancyPriority
      );

      // Trigger notification
      const memoData = getMemoData(selectedEntry.memo_id);
      if (memoData) {
        notificationIntegrationService.triggerMemoFlagged({
          id: selectedEntry.memo_id,
          reference: selectedEntry.memo_reference,
          status: 'flagged',
          plant: memoData.labSite || 'Unknown',
          createdAt: selectedEntry.submitted_at,
          updatedAt: new Date().toISOString(),
          flaggedBy: user?.id || 'Unknown User',
          reason: discrepancyNotes,
          priority: discrepancyPriority
        });
      }

      toast({
        title: "Success",
        description: "Discrepancy flagged successfully",
      });

      setShowDiscrepancyDialog(false);
      setDiscrepancyNotes("");
      setDiscrepancyCategory("");
      setDiscrepancyPriority('minor');
      loadInboxData();
    } catch (error) {
      console.error('Error flagging discrepancy:', error);
      toast({
        title: "Error",
        description: "Failed to flag discrepancy",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Memo Inbox</CardTitle>
          <CardDescription>Loading inbox entries...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (inboxEntries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Memo Inbox</CardTitle>
          <CardDescription>Review and acknowledge incoming memos</CardDescription>
        </CardHeader>
        <CardContent>
          <EmptyState
            icon={CheckCircle}
            title="No pending memos"
            description="All memos have been reviewed and acknowledged"
          />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Memo Inbox
            <Badge variant="secondary" className="ml-auto">
              {inboxEntries.length} pending
            </Badge>
          </CardTitle>
          <CardDescription>
            Review and acknowledge incoming memos before they enter the main workflow
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Priority</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Submitted By</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inboxEntries.map((entry) => {
                const memoData = getMemoData(entry.memo_id);
                return (
                  <TableRow key={entry.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getPriorityIcon(entry.priority_level)}
                        <span className="text-sm capitalize">{entry.priority_level}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {entry.memo_reference}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {entry.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {entry.submitted_by}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {new Date(entry.submitted_at).toLocaleDateString()}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(entry.status)}>
                        {entry.status.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleReviewMemo(entry)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          Review
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => {
                            setSelectedEntry(entry);
                            setShowDiscrepancyDialog(true);
                          }}
                        >
                          <Flag className="h-4 w-4 mr-1" />
                          Flag
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Memo - {selectedEntry?.memo_reference}</DialogTitle>
          </DialogHeader>
          
          {selectedEntry && (
            <div className="space-y-6">
              {/* Memo Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Memo Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const memoData = getMemoData(selectedEntry.memo_id);
                    return memoData ? (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Reference</Label>
                          <p className="font-medium">{memoData.reference}</p>
                        </div>
                        <div>
                          <Label>Category</Label>
                          <p className="font-medium capitalize">{selectedEntry.category}</p>
                        </div>
                        <div>
                          <Label>Officer</Label>
                          <p className="font-medium">{memoData.extractedData.officer}</p>
                        </div>
                        <div>
                          <Label>Site</Label>
                          <p className="font-medium">{memoData.extractedData.site}</p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-muted-foreground">Memo data not found</p>
                    );
                  })()}
                </CardContent>
              </Card>

              {/* Acknowledgment Checklist */}
              {selectedChecklist && (
                <Card>
                  <CardHeader>
                    <CardTitle>Acknowledgment Checklist</CardTitle>
                    <CardDescription>{selectedChecklist.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {selectedChecklist.checklist_items.map((item) => (
                        <div key={item.id} className="flex items-start space-x-3">
                          <Checkbox
                            id={item.id}
                            checked={!!checklistResponses[item.id]}
                            onCheckedChange={(checked) => {
                              setChecklistResponses(prev => ({
                                ...prev,
                                [item.id]: checked
                              }));
                            }}
                          />
                          <div className="grid gap-1.5 leading-none">
                            <Label
                              htmlFor={item.id}
                              className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${
                                item.required ? 'text-red-600' : ''
                              }`}
                            >
                              {item.name} {item.required && '*'}
                            </Label>
                            <p className="text-xs text-muted-foreground">
                              {item.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Acknowledgment Notes */}
              <div className="space-y-2">
                <Label htmlFor="acknowledgment-notes">Acknowledgment Notes</Label>
                <Textarea
                  id="acknowledgment-notes"
                  placeholder="Add any notes about this acknowledgment..."
                  value={acknowledgmentNotes}
                  onChange={(e) => setAcknowledgmentNotes(e.target.value)}
                />
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowReviewDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAcknowledgeMemo}>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Acknowledge Memo
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Discrepancy Dialog */}
      <Dialog open={showDiscrepancyDialog} onOpenChange={setShowDiscrepancyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Flag Discrepancy - {selectedEntry?.memo_reference}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="discrepancy-category">Discrepancy Category</Label>
              <Select value={discrepancyCategory} onValueChange={setDiscrepancyCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical">Technical Issues</SelectItem>
                  <SelectItem value="documentation">Documentation Issues</SelectItem>
                  <SelectItem value="safety">Safety Concerns</SelectItem>
                  <SelectItem value="compliance">Compliance Issues</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="discrepancy-priority">Priority Level</Label>
              <Select value={discrepancyPriority} onValueChange={(value: 'minor' | 'major' | 'critical') => setDiscrepancyPriority(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="minor">Minor</SelectItem>
                  <SelectItem value="major">Major</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="discrepancy-notes">Description</Label>
              <Textarea
                id="discrepancy-notes"
                placeholder="Describe the discrepancy and required actions..."
                value={discrepancyNotes}
                onChange={(e) => setDiscrepancyNotes(e.target.value)}
                required
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDiscrepancyDialog(false)}>
                Cancel
              </Button>
              <Button 
                variant="destructive" 
                onClick={handleFlagDiscrepancy}
                disabled={!discrepancyCategory || !discrepancyNotes}
              >
                <Flag className="h-4 w-4 mr-2" />
                Flag Discrepancy
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}