import React, { useState, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Save, 
  Upload, 
  Download, 
  Eye, 
  Move, 
  Type, 
  Image, 
  BarChart3, 
  FileText,
  Plus,
  Trash2,
  Copy
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TemplateElement {
  id: string;
  type: 'text' | 'placeholder' | 'image' | 'chart' | 'table';
  content: string;
  x: number;
  y: number;
  width: number;
  height: number;
  style: {
    fontSize?: number;
    fontWeight?: string;
    color?: string;
    backgroundColor?: string;
    textAlign?: string;
    borderStyle?: string;
    borderWidth?: number;
    borderColor?: string;
    padding?: number;
    margin?: number;
  };
}

interface TemplateDesignerProps {
  isOpen: boolean;
  onClose: () => void;
  templateId?: string;
  onSave: (template: any) => void;
}

const PLACEHOLDER_TYPES = [
  { value: 'memo_ref', label: 'Memo Reference' },
  { value: 'date', label: 'Date' },
  { value: 'officer', label: 'Officer Name' },
  { value: 'plant', label: 'Plant Location' },
  { value: 'test_table', label: 'Test Results Table' },
  { value: 'test_summary', label: 'Test Summary' },
  { value: 'conformity_status', label: 'Conformity Status' },
  { value: 'charts', label: 'Analytics Charts' },
  { value: 'company_logo', label: 'Company Logo' },
  { value: 'signature', label: 'Digital Signature' },
  { value: 'watermark', label: 'Watermark' },
  { value: 'notes', label: 'Notes/Comments' },
  { value: 'methodology', label: 'Test Methodology' },
  { value: 'project_brief', label: 'Project Brief' },
];

export function TemplateDesigner({ isOpen, onClose, templateId, onSave }: TemplateDesignerProps) {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  const [templateCategory, setTemplateCategory] = useState('');
  const [plant, setPlant] = useState('');
  const [isDefault, setIsDefault] = useState(false);
  const [elements, setElements] = useState<TemplateElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [draggedElement, setDraggedElement] = useState<string | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  // Sample data for preview
  const previewData = {
    memo_ref: 'UBP-AGG-2024-001',
    date: new Date().toLocaleDateString(),
    officer: 'John Smith',
    plant: 'Rose Hill Plant',
    test_table: '[ Test Results Table ]',
    test_summary: 'All tests passed within acceptable limits',
    conformity_status: 'CONFORMING',
    charts: '[ Analytics Chart Placeholder ]',
    company_logo: '[ Company Logo ]',
    signature: '[ Digital Signature ]',
    watermark: 'UBP INTERNAL USE',
    notes: 'Sample notes and comments section',
    methodology: 'BS EN 12620:2013 Standards Applied',
    project_brief: 'Aggregate testing for concrete production'
  };

  const addElement = useCallback((type: string, placeholderType?: string) => {
    const newElement: TemplateElement = {
      id: `element-${Date.now()}`,
      type: type as any,
      content: type === 'placeholder' ? placeholderType || 'memo_ref' : 'Sample Text',
      x: 50,
      y: 50,
      width: type === 'table' ? 400 : type === 'chart' ? 300 : 200,
      height: type === 'table' ? 200 : type === 'chart' ? 200 : 40,
      style: {
        fontSize: 14,
        fontWeight: 'normal',
        color: '#000000',
        backgroundColor: 'transparent',
        textAlign: 'left',
        padding: 8,
        margin: 4
      }
    };

    setElements(prev => [...prev, newElement]);
    setSelectedElement(newElement.id);
  }, []);

  const updateElement = useCallback((id: string, updates: Partial<TemplateElement>) => {
    setElements(prev => prev.map(el => 
      el.id === id ? { ...el, ...updates } : el
    ));
  }, []);

  const deleteElement = useCallback((id: string) => {
    setElements(prev => prev.filter(el => el.id !== id));
    setSelectedElement(null);
  }, []);

  const duplicateElement = useCallback((id: string) => {
    const element = elements.find(el => el.id === id);
    if (element) {
      const newElement = {
        ...element,
        id: `element-${Date.now()}`,
        x: element.x + 20,
        y: element.y + 20
      };
      setElements(prev => [...prev, newElement]);
    }
  }, [elements]);

  const handleDragStart = useCallback((e: React.DragEvent, elementId: string) => {
    setDraggedElement(elementId);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedElement || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    updateElement(draggedElement, { x, y });
    setDraggedElement(null);
  }, [draggedElement, updateElement]);

  const handleSave = useCallback(async () => {
    if (!templateName.trim()) {
      toast({ 
        title: "Validation Error", 
        description: "Template name is required",
        variant: "destructive"
      });
      return;
    }

    const template = {
      id: templateId || `template-${Date.now()}`,
      name: templateName,
      description: templateDescription,
      category: templateCategory,
      plant,
      is_default: isDefault,
      template_data: JSON.stringify({
        elements,
        canvas: {
          width: 800,
          height: 1000
        }
      }),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    try {
      onSave(template);
      toast({ 
        title: "Success", 
        description: "Template saved successfully" 
      });
      onClose();
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Failed to save template",
        variant: "destructive"
      });
    }
  }, [templateName, templateDescription, templateCategory, plant, isDefault, elements, templateId, onSave, onClose, toast]);

  const handleExport = useCallback(() => {
    const template = {
      name: templateName,
      description: templateDescription,
      elements,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${templateName || 'template'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [templateName, templateDescription, elements]);

  const handleImport = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const template = JSON.parse(event.target?.result as string);
        setTemplateName(template.name || '');
        setTemplateDescription(template.description || '');
        setElements(template.elements || []);
        toast({ 
          title: "Success", 
          description: "Template imported successfully" 
        });
      } catch (error) {
        toast({ 
          title: "Error", 
          description: "Invalid template file",
          variant: "destructive"
        });
      }
    };
    reader.readAsText(file);
  }, [toast]);

  const selectedElementData = selectedElement ? elements.find(el => el.id === selectedElement) : null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Template Designer
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-4 h-[80vh]">
          {/* Left Panel - Tools and Properties */}
          <div className="w-80 space-y-4 overflow-y-auto">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="elements">Elements</TabsTrigger>
                <TabsTrigger value="properties">Properties</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Template Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label htmlFor="template-name">Name</Label>
                      <Input
                        id="template-name"
                        value={templateName}
                        onChange={(e) => setTemplateName(e.target.value)}
                        placeholder="Enter template name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="template-description">Description</Label>
                      <Textarea
                        id="template-description"
                        value={templateDescription}
                        onChange={(e) => setTemplateDescription(e.target.value)}
                        placeholder="Template description"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="template-category">Category</Label>
                      <Select value={templateCategory} onValueChange={setTemplateCategory}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="aggregates">Aggregates</SelectItem>
                          <SelectItem value="concrete">Concrete</SelectItem>
                          <SelectItem value="blocks">Blocks</SelectItem>
                          <SelectItem value="pavers">Pavers</SelectItem>
                          <SelectItem value="general">General</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="template-plant">Plant</Label>
                      <Select value={plant} onValueChange={setPlant}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select plant" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Plants</SelectItem>
                          <SelectItem value="rose-hill">Rose Hill</SelectItem>
                          <SelectItem value="port-louis">Port Louis</SelectItem>
                          <SelectItem value="central">Central Plant</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button 
                      onClick={handleSave} 
                      className="w-full"
                      size="sm"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Template
                    </Button>
                    <Button 
                      onClick={handleExport} 
                      variant="outline" 
                      className="w-full"
                      size="sm"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export JSON
                    </Button>
                    <div>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".json"
                        onChange={handleImport}
                        className="hidden"
                      />
                      <Button 
                        onClick={() => fileInputRef.current?.click()} 
                        variant="outline" 
                        className="w-full"
                        size="sm"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Import JSON
                      </Button>
                    </div>
                    <Button 
                      onClick={() => setIsPreviewMode(!isPreviewMode)} 
                      variant={isPreviewMode ? "default" : "outline"} 
                      className="w-full"
                      size="sm"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      {isPreviewMode ? 'Exit Preview' : 'Preview Mode'}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="elements" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Add Elements</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button 
                      onClick={() => addElement('text')} 
                      variant="outline" 
                      className="w-full justify-start"
                      size="sm"
                    >
                      <Type className="h-4 w-4 mr-2" />
                      Text Block
                    </Button>
                    <Button 
                      onClick={() => addElement('image')} 
                      variant="outline" 
                      className="w-full justify-start"
                      size="sm"
                    >
                      <Image className="h-4 w-4 mr-2" />
                      Image/Logo
                    </Button>
                    <Button 
                      onClick={() => addElement('chart')} 
                      variant="outline" 
                      className="w-full justify-start"
                      size="sm"
                    >
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Chart
                    </Button>
                    <Button 
                      onClick={() => addElement('table')} 
                      variant="outline" 
                      className="w-full justify-start"
                      size="sm"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Table
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Data Placeholders</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 max-h-60 overflow-y-auto">
                    {PLACEHOLDER_TYPES.map((placeholder) => (
                      <Button
                        key={placeholder.value}
                        onClick={() => addElement('placeholder', placeholder.value)}
                        variant="outline"
                        className="w-full justify-start text-xs"
                        size="sm"
                      >
                        <Plus className="h-3 w-3 mr-2" />
                        {placeholder.label}
                      </Button>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="properties" className="space-y-4">
                {selectedElementData && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Element Properties</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">{selectedElementData.type}</Badge>
                        <div className="flex gap-1">
                          <Button
                            onClick={() => duplicateElement(selectedElementData.id)}
                            size="sm"
                            variant="outline"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button
                            onClick={() => deleteElement(selectedElementData.id)}
                            size="sm"
                            variant="destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>

                      {selectedElementData.type === 'text' && (
                        <div>
                          <Label>Content</Label>
                          <Textarea
                            value={selectedElementData.content}
                            onChange={(e) => updateElement(selectedElementData.id, { content: e.target.value })}
                            rows={3}
                          />
                        </div>
                      )}

                      {selectedElementData.type === 'placeholder' && (
                        <div>
                          <Label>Placeholder Type</Label>
                          <Select 
                            value={selectedElementData.content} 
                            onValueChange={(value) => updateElement(selectedElementData.id, { content: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {PLACEHOLDER_TYPES.map((placeholder) => (
                                <SelectItem key={placeholder.value} value={placeholder.value}>
                                  {placeholder.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>X Position</Label>
                          <Input
                            type="number"
                            value={selectedElementData.x}
                            onChange={(e) => updateElement(selectedElementData.id, { x: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label>Y Position</Label>
                          <Input
                            type="number"
                            value={selectedElementData.y}
                            onChange={(e) => updateElement(selectedElementData.id, { y: Number(e.target.value) })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>Width</Label>
                          <Input
                            type="number"
                            value={selectedElementData.width}
                            onChange={(e) => updateElement(selectedElementData.id, { width: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label>Height</Label>
                          <Input
                            type="number"
                            value={selectedElementData.height}
                            onChange={(e) => updateElement(selectedElementData.id, { height: Number(e.target.value) })}
                          />
                        </div>
                      </div>

                      <div>
                        <Label>Font Size</Label>
                        <Input
                          type="number"
                          value={selectedElementData.style.fontSize || 14}
                          onChange={(e) => updateElement(selectedElementData.id, { 
                            style: { ...selectedElementData.style, fontSize: Number(e.target.value) }
                          })}
                        />
                      </div>

                      <div>
                        <Label>Text Color</Label>
                        <Input
                          type="color"
                          value={selectedElementData.style.color || '#000000'}
                          onChange={(e) => updateElement(selectedElementData.id, { 
                            style: { ...selectedElementData.style, color: e.target.value }
                          })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Center Panel - Canvas */}
          <div className="flex-1 bg-white border-2 border-dashed border-gray-300 relative overflow-auto">
            <div
              ref={canvasRef}
              className="relative w-full min-h-[1000px] bg-white"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              style={{ width: '800px', margin: '0 auto' }}
            >
              {elements.map((element) => (
                <div
                  key={element.id}
                  draggable={!isPreviewMode}
                  onDragStart={(e) => handleDragStart(e, element.id)}
                  onClick={() => setSelectedElement(element.id)}
                  className={`absolute border cursor-move select-none ${
                    selectedElement === element.id && !isPreviewMode ? 'border-blue-500 border-2' : 'border-gray-300'
                  } ${isPreviewMode ? 'cursor-default' : 'hover:border-blue-400'}`}
                  style={{
                    left: element.x,
                    top: element.y,
                    width: element.width,
                    height: element.height,
                    fontSize: element.style.fontSize,
                    fontWeight: element.style.fontWeight,
                    color: element.style.color,
                    backgroundColor: element.style.backgroundColor,
                    textAlign: element.style.textAlign as any,
                    padding: element.style.padding,
                    margin: element.style.margin,
                    display: 'flex',
                    alignItems: element.type === 'table' ? 'flex-start' : 'center',
                    justifyContent: element.style.textAlign === 'center' ? 'center' : 'flex-start',
                    overflow: 'hidden'
                  }}
                >
                  {isPreviewMode && element.type === 'placeholder' 
                    ? (previewData as any)[element.content] || `[${element.content}]`
                    : element.type === 'placeholder' 
                    ? `{${element.content}}` 
                    : element.content
                  }
                  {element.type === 'chart' && (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center text-gray-500 text-sm">
                      📊 Chart Placeholder
                    </div>
                  )}
                  {element.type === 'table' && (
                    <div className="w-full h-full bg-gray-50 border p-2 text-xs">
                      <div className="font-semibold mb-1">Test Results</div>
                      <div className="text-gray-600">Table data will be inserted here</div>
                    </div>
                  )}
                  {element.type === 'image' && (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center text-gray-500 text-sm">
                      🖼️ Image Placeholder
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}