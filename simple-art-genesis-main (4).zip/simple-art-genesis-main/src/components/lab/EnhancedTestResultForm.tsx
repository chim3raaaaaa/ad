import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, Loader2, AlertCircle, CheckCircle, FileUp, Save, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { EnhancedTestResultService } from "@/services/database/enhancedTestResultService";

interface EnhancedTestResultFormProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  memoId?: string;
  initialData?: any;
  onSuccess?: () => void;
}

export function EnhancedTestResultForm({ 
  isOpen, 
  onOpenChange, 
  memoId, 
  initialData,
  onSuccess 
}: EnhancedTestResultFormProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [testType, setTestType] = useState<string>('aggregates');
  const [priority, setPriority] = useState<string>('medium');
  const [dueDate, setDueDate] = useState<Date>();
  const [officerId, setOfficerId] = useState<string>('');
  const [testData, setTestData] = useState<Record<string, any>>({});
  const [schema, setSchema] = useState<any>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [kpis, setKpis] = useState<Record<string, any>>({});
  const [attachments, setAttachments] = useState<File[]>([]);
  const [officers, setOfficers] = useState<any[]>([]);

  // Load officers and schema when modal opens
  useEffect(() => {
    if (isOpen) {
      loadOfficers();
      loadSchema();
    }
  }, [isOpen, testType]);

  // Compute KPIs when test data changes
  useEffect(() => {
    if (testType && testData) {
      const computedKPIs = EnhancedTestResultService.computeKPIs(testType, testData);
      setKpis(computedKPIs);
    }
  }, [testType, testData]);

  const loadOfficers = async () => {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery('SELECT * FROM officers WHERE active = 1');
        if (result.success) {
          setOfficers(result.data);
        }
      }
    } catch (error) {
      console.error('Failed to load officers:', error);
    }
  };

  const loadSchema = async () => {
    try {
      const schemaData = await EnhancedTestResultService.getTestTypeSchema(testType);
      setSchema(schemaData);
      // Reset test data when schema changes
      setTestData({});
      setValidationErrors({});
    } catch (error) {
      console.error('Failed to load schema:', error);
    }
  };

  const validateField = async (fieldName: string, value: any) => {
    if (!schema) return;

    const field = schema.fields.find((f: any) => f.name === fieldName);
    if (!field) return;

    const tempData = { ...testData, [fieldName]: value };
    const validation = await EnhancedTestResultService.validateTestData(testType, tempData);
    
    setValidationErrors(prev => ({
      ...prev,
      [fieldName]: validation.errors[fieldName] || ''
    }));
  };

  const handleFieldChange = async (fieldName: string, value: any) => {
    setTestData(prev => ({ ...prev, [fieldName]: value }));
    await validateField(fieldName, value);
  };

  const handleSaveDraft = async () => {
    setIsLoading(true);
    try {
      if (!officerId) {
        toast({
          title: "Missing Officer",
          description: "Please select an officer",
          variant: "destructive"
        });
        return;
      }

      const id = await EnhancedTestResultService.saveTestResultDraft({
        memo_id: memoId || '',
        test_type: testType as any,
        status: 'draft',
        priority: priority as any,
        due_date: dueDate?.toISOString(),
        officer_id: officerId,
        test_data: testData,
        validation_results: kpis
      });

      // Handle file attachments
      for (const file of attachments) {
        const filePath = `uploads/test_results/${id}/${file.name}`;
        await EnhancedTestResultService.addAttachment(id, {
          file_name: file.name,
          file_path: filePath,
          file_type: file.type,
          uploaded_by: officerId
        });
      }

      toast({
        title: "Draft Saved",
        description: "Test result saved as draft successfully"
      });

      onSuccess?.();
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save draft",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      // Validate all data
      const validation = await EnhancedTestResultService.validateTestData(testType, testData);
      if (!validation.isValid) {
        setValidationErrors(validation.errors);
        toast({
          title: "Validation Errors",
          description: "Please fix the validation errors before submitting",
          variant: "destructive"
        });
        return;
      }

      if (!officerId) {
        toast({
          title: "Missing Officer",
          description: "Please select an officer",
          variant: "destructive"
        });
        return;
      }

      // Save as draft first
      const id = await EnhancedTestResultService.saveTestResultDraft({
        memo_id: memoId || '',
        test_type: testType as any,
        status: 'draft',
        priority: priority as any,
        due_date: dueDate?.toISOString(),
        officer_id: officerId,
        test_data: testData,
        validation_results: kpis
      });

      // Then submit
      await EnhancedTestResultService.submitTestResult(id, officerId);

      // Handle file attachments
      for (const file of attachments) {
        const filePath = `uploads/test_results/${id}/${file.name}`;
        await EnhancedTestResultService.addAttachment(id, {
          file_name: file.name,
          file_path: filePath,
          file_type: file.type,
          uploaded_by: officerId
        });
      }

      toast({
        title: "Test Submitted",
        description: "Test result submitted successfully"
      });

      onSuccess?.();
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit test result",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderField = (field: any) => {
    const hasError = validationErrors[field.name];
    const value = testData[field.name] || '';

    switch (field.type) {
      case 'number':
        return (
          <div key={field.name}>
            <Label htmlFor={field.name}>
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={field.name}
              type="number"
              value={value}
              min={field.min}
              max={field.max}
              step="0.01"
              onChange={(e) => handleFieldChange(field.name, parseFloat(e.target.value) || '')}
              className={cn(hasError && "border-destructive")}
              placeholder={`Enter ${field.label.toLowerCase()}`}
            />
            {hasError && (
              <div className="flex items-center mt-1 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 mr-1" />
                {hasError}
              </div>
            )}
            {field.min !== undefined && field.max !== undefined && (
              <div className="text-xs text-muted-foreground mt-1">
                Valid range: {field.min} - {field.max}
              </div>
            )}
          </div>
        );

      case 'select':
        return (
          <div key={field.name}>
            <Label htmlFor={field.name}>
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Select value={value} onValueChange={(val) => handleFieldChange(field.name, val)}>
              <SelectTrigger className={cn(hasError && "border-destructive")}>
                <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((option: any) => (
                  <SelectItem key={option} value={option.toString()}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasError && (
              <div className="flex items-center mt-1 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 mr-1" />
                {hasError}
              </div>
            )}
          </div>
        );

      default:
        return (
          <div key={field.name}>
            <Label htmlFor={field.name}>
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={field.name}
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              className={cn(hasError && "border-destructive")}
              placeholder={`Enter ${field.label.toLowerCase()}`}
            />
            {hasError && (
              <div className="flex items-center mt-1 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 mr-1" />
                {hasError}
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Enhanced Test Result Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Test Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="testType">Test Type *</Label>
                  <Select value={testType} onValueChange={setTestType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="aggregates">Aggregates</SelectItem>
                      <SelectItem value="cubes">Cubes</SelectItem>
                      <SelectItem value="pavers">Pavers</SelectItem>
                      <SelectItem value="blocks">Blocks</SelectItem>
                      <SelectItem value="kerbs">Kerbs</SelectItem>
                      <SelectItem value="flagstones">Flagstones</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="officer">Officer *</Label>
                  <Select value={officerId} onValueChange={setOfficerId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select officer" />
                    </SelectTrigger>
                    <SelectContent>
                      {officers.map((officer) => (
                        <SelectItem key={officer.id} value={officer.id}>
                          {officer.name} - {officer.role}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Due Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !dueDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dueDate ? format(dueDate, "PPP") : <span>Pick due date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={dueDate}
                        onSelect={setDueDate}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="p-3 pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Dynamic Test Fields */}
          {schema && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {testType.charAt(0).toUpperCase() + testType.slice(1)} Test Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {schema.fields?.map(renderField)}
                </div>
              </CardContent>
            </Card>
          )}

          {/* KPI Summary */}
          {Object.keys(kpis).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Result Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  {Object.entries(kpis).map(([key, value]) => (
                    <div key={key} className="text-center">
                      <div className="text-sm text-muted-foreground">
                        {key.replace(/_/g, ' ').toUpperCase()}
                      </div>
                      <div className="text-lg font-semibold">
                        {typeof value === 'string' ? (
                          <Badge variant={value === 'Pass' ? 'default' : 'destructive'}>
                            {value}
                          </Badge>
                        ) : (
                          value.toFixed(2)
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* File Attachments */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <FileUp className="h-5 w-5 mr-2" />
                Attachments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <input
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png,.csv,.xlsx"
                onChange={(e) => setAttachments(Array.from(e.target.files || []))}
                className="hidden"
                id="file-upload"
              />
              <Label htmlFor="file-upload" className="cursor-pointer">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-muted-foreground/50 transition-colors">
                  <FileUp className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    Click to upload machine logs, photos, or calculation sheets
                  </p>
                </div>
              </Label>
              {attachments.length > 0 && (
                <div className="mt-4 space-y-2">
                  {attachments.map((file, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <FileUp className="h-4 w-4" />
                      <span>{file.name}</span>
                      <Badge variant="outline">{file.type}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button variant="outline" onClick={handleSaveDraft} disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Save Draft
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Submit
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}