import { useState } from "react";
import { ChevronLeft, ChevronRight, Clock, AlertTriangle, CheckCircle, Plus, Filter, Calendar, List, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { TestCalendarEvent } from "@/types";

interface TestCalendarViewProps {
  events: TestCalendarEvent[];
  onMarkDone: (eventId: string) => void;
  selectedEvents?: string[];
  onSelectEvent?: (eventId: string, selected: boolean) => void;
  showSelection?: boolean;
  onAddTest?: (date: Date) => void;
  onFilterByDate?: (date: Date) => void;
  viewMode?: 'month' | 'week' | 'day';
  onViewModeChange?: (mode: 'month' | 'week' | 'day') => void;
  onViewMemoDetails?: (memoId: string) => void;
}

export const TestCalendarView = ({ 
  events, 
  onMarkDone, 
  selectedEvents = [], 
  onSelectEvent, 
  showSelection = false,
  onAddTest,
  onFilterByDate,
  viewMode = 'month',
  onViewModeChange,
  onViewMemoDetails
}: TestCalendarViewProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<TestCalendarEvent | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const goToPrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const getDaysInMonth = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }

    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }

    return days;
  };

  const getWeekDays = () => {
    const startOfWeek = new Date(currentDate);
    const dayOfWeek = startOfWeek.getDay();
    startOfWeek.setDate(startOfWeek.getDate() - dayOfWeek);

    const weekDays: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      weekDays.push(day);
    }
    return weekDays;
  };

  const getDayView = () => {
    return [currentDate];
  };

  const getEventsForDate = (date: Date) => {
    if (!date) return [];
    const dateStr = date.toISOString().split('T')[0];
    return events.filter(event => event.due_date === dateStr);
  };

  const getEventStatusColor = (event: TestCalendarEvent) => {
    const today = new Date().toISOString().split('T')[0];
    const eventDate = event.due_date;
    
    if (event.status === 'completed') {
      return 'bg-green-100 border-green-300 text-green-800 dark:bg-green-900/20 dark:border-green-700 dark:text-green-300';
    }
    if (today > eventDate) {
      return 'bg-red-100 border-red-300 text-red-800 dark:bg-red-900/20 dark:border-red-700 dark:text-red-300';
    }
    if (today === eventDate) {
      return 'bg-orange-100 border-orange-300 text-orange-800 dark:bg-orange-900/20 dark:border-orange-700 dark:text-orange-300';
    }
    return 'bg-blue-100 border-blue-300 text-blue-800 dark:bg-blue-900/20 dark:border-blue-700 dark:text-blue-300';
  };

  const getEventIcon = (event: TestCalendarEvent) => {
    if (event.status === 'completed') return <CheckCircle className="h-3 w-3" />;
    if (event.status === 'overdue') return <AlertTriangle className="h-3 w-3" />;
    return <Clock className="h-3 w-3" />;
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
  };

  const getSelectedDateEvents = () => {
    if (!selectedDate) return [];
    return getEventsForDate(selectedDate);
  };

  const days = viewMode === 'month' ? getDaysInMonth() : 
               viewMode === 'week' ? getWeekDays() : 
               getDayView();
               
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <TooltipProvider>
      <div className="flex gap-6">
        <Card className="flex-1 p-6">
        {/* View Toggle UI */}
        {onViewModeChange && (
          <div className="flex justify-center mb-4">
            <div className="inline-flex rounded-lg border border-border bg-background p-1">
              <Button
                variant={viewMode === 'month' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => onViewModeChange('month')}
                className="rounded-md"
              >
                <Calendar className="h-4 w-4 mr-2" />
                Month
              </Button>
              <Button
                variant={viewMode === 'week' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => onViewModeChange('week')}
                className="rounded-md"
              >
                <List className="h-4 w-4 mr-2" />
                Week
              </Button>
              <Button
                variant={viewMode === 'day' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => onViewModeChange('day')}
                className="rounded-md"
              >
                <Eye className="h-4 w-4 mr-2" />
                Day
              </Button>
            </div>
          </div>
        )}

        {/* Calendar Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">
            {viewMode === 'month' ? `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}` :
             viewMode === 'week' ? `Week of ${currentDate.toLocaleDateString()}` :
             `${currentDate.toLocaleDateString()}`}
          </h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={goToPrevMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className={`grid gap-1 ${
          viewMode === 'month' ? 'grid-cols-7' : 
          viewMode === 'week' ? 'grid-cols-7' : 
          'grid-cols-1'
        }`}>
          {/* Day headers - only show for month and week view */}
          {viewMode !== 'day' && dayNames.map(day => (
            <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
              {day}
            </div>
          ))}

          {/* Calendar days */}
          {days.map((date, index) => {
            const dayEvents = date ? getEventsForDate(date) : [];
            const isToday = date && date.toDateString() === new Date().toDateString();
            const isCurrentMonth = viewMode === 'month' ? (date && date.getMonth() === currentDate.getMonth()) : true;

            return (
              <div
                key={index}
                className={cn(
                  viewMode === 'day' ? "min-h-[400px] p-4" : "min-h-[100px] p-2",
                  "border border-border rounded-md transition-colors",
                  date ? "cursor-pointer hover:bg-accent/50" : "bg-muted/20",
                  isToday && "ring-2 ring-primary/50",
                  selectedDate && date && selectedDate.toDateString() === date.toDateString() && 
                    "ring-2 ring-secondary bg-secondary/10",
                  !isCurrentMonth && "opacity-50"
                )}
                onClick={() => date && handleDateClick(date)}
              >
                {date && (
                  <>
                    <div className={cn(
                      "text-sm font-medium mb-2",
                      isToday && "text-primary font-bold"
                    )}>
                      {date.getDate()}
                    </div>
                    
                    <div className="space-y-1">
                      {dayEvents.slice(0, 3).map(event => (
                        <Tooltip key={event.id}>
                          <TooltipTrigger asChild>
                            <div
                              className={cn(
                                "p-1 rounded text-xs border cursor-pointer hover:opacity-80 transition-opacity",
                                getEventStatusColor(event)
                              )}
                              onClick={() => setSelectedEvent(event)}
                            >
                              <div className="flex items-center gap-1 truncate">
                                {getEventIcon(event)}
                                <span className="truncate">{event.product}</span>
                              </div>
                              <div className="truncate text-xs opacity-75">
                                {event.test_type}
                              </div>
                            </div>
                          </TooltipTrigger>
                           <TooltipContent className="max-w-xs">
                             <div className="space-y-2">
                               <div className="font-medium text-sm">Memo: {event.memo_id || event.id}</div>
                               <div className="text-sm">{event.product} - {event.test_type}</div>
                               <div className="text-sm">Lab: {event.plant_location || 'N/A'}</div>
                               {event.batch_number && (
                                 <div className="text-sm">Batch: {event.batch_number}</div>
                               )}
                               {event.assigned_to && (
                                 <div className="text-sm">Officer: {event.assigned_to}</div>
                               )}
                               <div className="text-sm">
                                 Production: {event.production_date ? new Date(event.production_date).toLocaleDateString() : 'N/A'}
                               </div>
                               {event.status === 'overdue' ? (
                                 <div className="text-red-500 font-medium text-sm">
                                   Overdue by {Math.abs(event.remaining_days || 0)} days
                                 </div>
                               ) : (event.remaining_days || 0) === 0 ? (
                                 <div className="text-orange-500 font-medium text-sm">Due today</div>
                               ) : (
                                 <div className="text-blue-500 text-sm">Due in {event.remaining_days || 0} days</div>
                               )}
                             </div>
                           </TooltipContent>
                        </Tooltip>
                      ))}
                      
                      {dayEvents.length > 3 && (
                        <div className="text-xs text-muted-foreground text-center">
                          +{dayEvents.length - 3} more
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 mt-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-primary/20 border border-primary/50"></div>
            <span>Upcoming</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-warning/20 border border-warning/50"></div>
            <span>Due Today</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-destructive/20 border border-destructive/50"></div>
            <span>Overdue</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-success/20 border border-success/50"></div>
            <span>Completed</span>
          </div>
        </div>
      </Card>

      {/* Selected Date Panel */}
      {selectedDate && (
        <Card className="w-80 p-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">
                {selectedDate.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedDate(null)}
              >
                ×
              </Button>
            </div>

            <div className="flex gap-2">
              {onAddTest && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onAddTest(selectedDate)}
                  className="flex-1"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Test
                </Button>
              )}
              {onFilterByDate && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onFilterByDate(selectedDate)}
                  className="flex-1"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              )}
            </div>

            <Separator />

            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground">
                Events ({getSelectedDateEvents().length})
              </h4>
              
              {getSelectedDateEvents().length === 0 ? (
                <div className="text-sm text-muted-foreground text-center py-4">
                  No events scheduled for this date
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {getSelectedDateEvents().map(event => (
                    <div
                      key={event.id}
                      className={cn(
                        "p-3 rounded-md border cursor-pointer hover:opacity-80 transition-opacity",
                        getEventStatusColor(event)
                      )}
                      onClick={() => setSelectedEvent(event)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {getEventIcon(event)}
                            <span className="text-sm font-medium truncate">
                              {event.memo_id || event.id}
                            </span>
                          </div>
                          <div className="text-sm truncate">{event.product}</div>
                          <div className="text-xs opacity-75 truncate">{event.test_type}</div>
                        </div>
                        
                        {showSelection && onSelectEvent && (
                          <input
                            type="checkbox"
                            checked={selectedEvents.includes(event.id)}
                            onChange={(e) => onSelectEvent(event.id, e.target.checked)}
                            className="ml-2"
                          />
                        )}
                      </div>
                      
                      <div className="mt-2">
                        <Badge
                          variant={event.status === 'overdue' ? "destructive" : 
                                  (event.remaining_days || 0) === 0 ? "secondary" : "default"}
                          className="text-xs"
                        >
                          {event.status === 'overdue' 
                            ? `Overdue ${Math.abs(event.remaining_days || 0)}d`
                            : (event.remaining_days || 0) === 0 
                            ? "Due today"
                            : `${event.remaining_days || 0}d left`
                          }
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </Card>
      )}
      </div>

      {/* Event Details Dialog */}
      <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Test Details</DialogTitle>
          </DialogHeader>
          
          {selectedEvent && (
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">{selectedEvent.memo_id || selectedEvent.id}</h3>
                <div className="space-y-2 text-sm">
                  <div><strong>Product:</strong> {selectedEvent.product}</div>
                  <div><strong>Test Type:</strong> {selectedEvent.test_type}</div>
                  <div><strong>Lab Site:</strong> {selectedEvent.plant_location || selectedEvent.location || 'N/A'}</div>
                  <div><strong>Due Date:</strong> {selectedEvent.due_date}</div>
                  {selectedEvent.production_date && (
                    <div><strong>Production Date:</strong> {selectedEvent.production_date}</div>
                  )}
                  
                  {selectedEvent.batch_number && (
                    <div><strong>Batch Number:</strong> {selectedEvent.batch_number}</div>
                  )}
                  {selectedEvent.assigned_to && (
                    <div><strong>Assigned To:</strong> {selectedEvent.assigned_to}</div>
                  )}
                  {selectedEvent.notes && (
                    <div><strong>Notes:</strong> {selectedEvent.notes}</div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant={selectedEvent.status === 'overdue' ? "destructive" : 
                              (selectedEvent.remaining_days || 0) === 0 ? "secondary" : "default"}>
                  {selectedEvent.status === 'overdue' 
                    ? `Overdue by ${Math.abs(selectedEvent.remaining_days || 0)} days`
                    : (selectedEvent.remaining_days || 0) === 0 
                    ? "Due today"
                    : `Due in ${selectedEvent.remaining_days || 0} days`
                  }
                </Badge>
              </div>

              {selectedEvent.status !== 'completed' && (
                <div className="flex gap-2 pt-2">
                  <Button 
                    onClick={() => {
                      onMarkDone(selectedEvent.id);
                      setSelectedEvent(null);
                    }}
                    className="flex-1"
                  >
                    Mark as Done
                  </Button>
                  {onViewMemoDetails && selectedEvent.memo_id && (
                    <Button 
                      variant="outline"
                      onClick={() => {
                        onViewMemoDetails(selectedEvent.memo_id);
                        setSelectedEvent(null);
                      }}
                      className="flex-1"
                    >
                      View Memo Details
                    </Button>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
};