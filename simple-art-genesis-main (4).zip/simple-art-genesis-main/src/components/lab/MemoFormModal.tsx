import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Toggle } from "@/components/ui/toggle";
import { Plus, Trash2, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMemoContext } from "@/contexts/MemoContext";
import { MemoData } from "@/contexts/MemoContext";
import { memoApiService, MemoReferenceData, ProductionSubmissionData } from "@/services/api/memoApiService";
import { MemoCounterService } from "@/services/database/memoCounterService";
import { useMemoTestSystem } from "@/hooks/useMemoTestSystem";


interface MemoFormModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  selectedCategory?: string;
}

interface ProductionData {
  productionDate: string;
  testDate: string;
  ageDays: number;
  category: string;
  product: string;
  gradeMpa: string;
  machineNo: string;
  mouldRef: string;
  sampleCount: number;
  blockPosition: string;
  testPerformed: string;
  remarks: string;
}

export function MemoFormModal({ isOpen, onOpenChange, selectedCategory }: MemoFormModalProps) {
  const { toast } = useToast();
  const { addMemo } = useMemoContext();
  const { createMemoWithTests } = useMemoTestSystem();

  // Form state
  const [formData, setFormData] = useState({
    reference: '',
    labSite: '',
    officerInCharge: '',
    lorry: '',
    blocksCount: 0,
    typeOfTest: 'Standard',
    testPerformed: '',
    testRemarks: '',
    remarks: '',
    date: new Date().toISOString().split('T')[0],
    retest: 'No',
    postedBy: ''
  });

  const [productions, setProductions] = useState<ProductionData[]>([
    {
      productionDate: new Date().toISOString().split('T')[0],
      testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      ageDays: 7,
      category: '',
      product: '',
      gradeMpa: '',
      machineNo: '',
      mouldRef: '',
      sampleCount: 0,
      blockPosition: '',
      testPerformed: '',
      remarks: ''
    }
  ]);

  // Loading states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [isGeneratingRef, setIsGeneratingRef] = useState(false);

  // Reference data
  const [referenceData, setReferenceData] = useState<MemoReferenceData>({
    categories: [],
    products: {},
    labTests: {},
    machines: {},
    moulds: {},
    officers: [],
    labSites: []
  });

  // Initialize reference data and counter table on mount
  useEffect(() => {
    const initializeData = async () => {
      setIsLoadingData(true);
      try {
        // Initialize counter table
        await MemoCounterService.initializeCounterTable();
        
        // Load reference data
        const data = await memoApiService.loadReferenceData();
        setReferenceData(data);

        // Set default lab site and posted by from current user
        if (data.labSites.length > 0) {
          setFormData(prev => ({ 
            ...prev, 
            labSite: data.labSites[0],
            postedBy: 'Current User' // TODO: Get from auth context
          }));
        }
      } catch (error) {
        console.error('Failed to initialize form data:', error);
        toast({
          title: "Warning",
          description: "Failed to load reference data. Some dropdowns may be empty.",
          variant: "destructive"
        });
      } finally {
        setIsLoadingData(false);
      }
    };

    if (isOpen) {
      initializeData();
    }
  }, [isOpen, toast]);

  // Separate effect to handle category changes
  useEffect(() => {
    if (selectedCategory) {
      setProductions(prev => prev.map(production => ({
        ...production,
        category: selectedCategory
      })));
    }
  }, [selectedCategory]);

  // Generate reference number
  const generateReference = async () => {
    setIsGeneratingRef(true);
    try {
      const reference = await memoApiService.generateNextReference();
      setFormData(prev => ({ ...prev, reference }));
      toast({
        title: "Reference Generated",
        description: `Generated reference: ${reference}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate reference number",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingRef(false);
    }
  };

  const addProduction = () => {
    setProductions([...productions, {
      productionDate: new Date().toISOString().split('T')[0],
      testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      ageDays: 7,
      category: selectedCategory || '',
      product: '',
      gradeMpa: '',
      machineNo: '',
      mouldRef: '',
      sampleCount: 0,
      blockPosition: '',
      testPerformed: '',
      remarks: ''
    }]);
  };

  const removeProduction = (index: number) => {
    if (productions.length > 1) {
      setProductions(productions.filter((_, i) => i !== index));
    }
  };

  const updateProduction = (index: number, field: keyof ProductionData, value: any) => {
    const updated = [...productions];
    updated[index] = { ...updated[index], [field]: value };
    
    // Auto-calculate age if both dates are present
    if (field === 'productionDate' || field === 'testDate') {
      const prodDate = field === 'productionDate' ? value : updated[index].productionDate;
      const testDate = field === 'testDate' ? value : updated[index].testDate;
      
      if (prodDate && testDate) {
        updated[index].ageDays = memoApiService.calculateAge(prodDate, testDate);
      }
    }
    
    // Auto-populate grade when product changes
    if (field === 'product') {
      const category = updated[index].category;
      const productInfo = referenceData.products[category]?.find(p => p.code === value || p.name === value);
      if (productInfo) {
        updated[index].gradeMpa = productInfo.grade.toString();
      }
    }
    
    // Handle block position toggle array
    if (field === 'blockPosition' && Array.isArray(value)) {
      updated[index].blockPosition = value.join(', ');
    }
    
    setProductions(updated);
  };

  const handleSubmit = async () => {
    if (!formData.reference || !formData.labSite || !formData.officerInCharge) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in Reference, Lab Site, and Officer In Charge.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Submit via API service
      const submissionData = {
        reference: formData.reference,
        date: formData.date,
        labSite: formData.labSite,
        officerInCharge: formData.officerInCharge,
        lorry: formData.lorry,
        blocksCount: formData.blocksCount,
        typeOfTest: formData.typeOfTest,
        testPerformed: formData.testPerformed,
        retest: formData.retest,
        postedBy: formData.postedBy,
        productions: productions,
        testRemarks: formData.testRemarks,
        remarks: formData.remarks
      };

      const result = await memoApiService.submitMemo(submissionData);
      
      if (!result.success) {
        toast({
          title: "Submission Failed",
          description: result.error || "Failed to submit memo",
          variant: "destructive"
        });
        return;
      }

      // Create memo with tests in new system
      const tests = productions
        .filter(prod => prod.testPerformed && prod.category)
        .map((prod, index) => ({
          test_type: prod.testPerformed,
          test_category: prod.category
        }));

      if (tests.length > 0) {
        await createMemoWithTests({
          memo: {
            memo_ref: formData.reference,
            plant: formData.labSite,
            officer: formData.officerInCharge,
            category: productions[0]?.category || 'general',
            remarks: formData.remarks
          },
          tests
        });
      }

      // Create memo for context (legacy compatibility)
      const newMemo: MemoData = {
        id: result.id || `memo-${Date.now()}`,
        reference: formData.reference,
        filename: undefined,
        sender: formData.postedBy,
        subject: `Test Request - ${formData.testPerformed}`,
        status: 'pending',
        extractedData: {
          date: formData.date,
          site: formData.labSite,
          officer: formData.officerInCharge,
          testType: formData.typeOfTest,
          product: productions[0]?.product || '',
          clientName: undefined,
          sampleType: undefined,
          siteSupervisor: undefined,
          blocksRequired: formData.blocksCount,
          lorry: formData.lorry
        },
        labSite: formData.labSite,
        officerInCharge: formData.officerInCharge,
        lorry: formData.lorry,
        blocksCount: formData.blocksCount,
        testPerformed: formData.testPerformed,
        retest: formData.retest,
        postedBy: formData.postedBy,
        productions: productions.map(prod => ({
          productionDate: prod.productionDate,
          testDate: prod.testDate,
          ageDays: prod.ageDays,
          product: prod.product,
          gradeMpa: prod.gradeMpa,
          machineNo: prod.machineNo,
          mouldRef: prod.mouldRef,
          sampleCount: prod.sampleCount,
          blockPosition: prod.blockPosition,
          additionalRemarks: prod.remarks
        })),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      addMemo(newMemo);
      
      toast({
        title: "Memo Created",
        description: `Memo ${formData.reference} has been created successfully.`
      });

      // Reset form
      setFormData({
        reference: '',
        labSite: referenceData.labSites[0] || '',
        officerInCharge: '',
        lorry: '',
        blocksCount: 0,
        typeOfTest: 'Standard',
        testPerformed: '',
        testRemarks: '',
        remarks: '',
        date: new Date().toISOString().split('T')[0],
        retest: 'No',
        postedBy: 'Current User'
      });
      
      setProductions([{
        productionDate: new Date().toISOString().split('T')[0],
        testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        ageDays: 7,
        category: '',
        product: '',
        gradeMpa: '',
        machineNo: '',
        mouldRef: '',
        sampleCount: 0,
        blockPosition: '',
        testPerformed: '',
        remarks: ''
      }]);

      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create memo. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Memo</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Memo Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="reference">Reference *</Label>
                <div className="flex gap-2">
                  <Input
                    id="reference"
                    value={formData.reference}
                    onChange={(e) => setFormData({...formData, reference: e.target.value})}
                    placeholder="RTB240725001"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={generateReference}
                    disabled={isGeneratingRef}
                  >
                    {isGeneratingRef ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="labSite">Lab Site *</Label>
                <Select 
                  value={formData.labSite} 
                  onValueChange={(value) => setFormData({...formData, labSite: value})}
                  disabled={isLoadingData}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select lab site" />
                  </SelectTrigger>
                  <SelectContent>
                    {referenceData.labSites.map(site => (
                      <SelectItem key={site} value={site}>
                        {site}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="officerInCharge">Officer In Charge *</Label>
                <Select 
                  value={formData.officerInCharge} 
                  onValueChange={(value) => setFormData({...formData, officerInCharge: value})}
                  disabled={!formData.labSite || isLoadingData}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select officer" />
                  </SelectTrigger>
                  <SelectContent>
                    {referenceData.officers
                      .filter(officer => !formData.labSite || officer.labSite === formData.labSite)
                      .map(officer => (
                      <SelectItem key={officer.id} value={officer.name}>
                        {officer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="lorry">Lorry</Label>
                <Input
                  id="lorry"
                  value={formData.lorry}
                  onChange={(e) => setFormData({...formData, lorry: e.target.value})}
                  placeholder="8965AG23"
                />
              </div>
              <div>
                <Label htmlFor="blocksCount">No. Blocks Sent</Label>
                <Input
                  id="blocksCount"
                  type="number"
                  value={formData.blocksCount}
                  onChange={(e) => setFormData({...formData, blocksCount: parseInt(e.target.value) || 0})}
                  placeholder="12"
                />
              </div>
              <div>
                <Label htmlFor="typeOfTest">Type of Test</Label>
                <Select value={formData.typeOfTest} onValueChange={(value) => setFormData({...formData, typeOfTest: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Express">Express</SelectItem>
                    <SelectItem value="Special">Special</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="retest">Retest</Label>
                <Select value={formData.retest} onValueChange={(value) => setFormData({...formData, retest: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Yes">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="postedBy">Posted By</Label>
                <Input
                  id="postedBy"
                  value={formData.postedBy}
                  readOnly
                  className="bg-muted"
                  placeholder="Auto-filled"
                />
              </div>
            </CardContent>
          </Card>

          {/* Production Details */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Production Details</CardTitle>
              <Button onClick={addProduction} size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Production
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {productions.map((production, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">Production {index + 1}</Badge>
                    {productions.length > 1 && (
                      <Button
                        onClick={() => removeProduction(index)}
                        size="sm"
                        variant="ghost"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Production Date</Label>
                      <Input
                        type="date"
                        value={production.productionDate}
                        onChange={(e) => updateProduction(index, 'productionDate', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Test Date</Label>
                      <Input
                        type="date"
                        value={production.testDate}
                        onChange={(e) => updateProduction(index, 'testDate', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Age (days)</Label>
                      <Input
                        type="number"
                        value={production.ageDays}
                        readOnly
                        className="bg-muted"
                      />
                    </div>
                    <div>
                      <Label>Category</Label>
                      <Select 
                        value={production.category} 
                        onValueChange={(value) => updateProduction(index, 'category', value)}
                        disabled={isLoadingData}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {referenceData.categories.map(category => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Product</Label>
                      <Select 
                        value={production.product} 
                        onValueChange={(value) => updateProduction(index, 'product', value)}
                        disabled={!production.category || isLoadingData}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select product" />
                        </SelectTrigger>
                        <SelectContent>
                          {(referenceData.products[production.category] || []).map(product => (
                            <SelectItem key={product.code} value={product.code}>
                              {product.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Grade (MPA)</Label>
                      <Input
                        value={production.gradeMpa}
                        readOnly
                        className="bg-muted"
                        placeholder="Auto-filled"
                      />
                    </div>
                    <div>
                      <Label>Test Performed</Label>
                      <Select 
                        value={production.testPerformed} 
                        onValueChange={(value) => updateProduction(index, 'testPerformed', value)}
                        disabled={!production.product || isLoadingData}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select test" />
                        </SelectTrigger>
                        <SelectContent>
                          {(referenceData.labTests[production.product] || []).map(test => (
                            <SelectItem key={test.code} value={test.name}>
                              {test.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Machine No.</Label>
                      <Select 
                        value={production.machineNo} 
                        onValueChange={(value) => updateProduction(index, 'machineNo', value)}
                        disabled={!formData.labSite || isLoadingData}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select machine" />
                        </SelectTrigger>
                        <SelectContent>
                          {(referenceData.machines[formData.labSite] || []).map(machine => (
                            <SelectItem key={machine.code} value={machine.code}>
                              {machine.name || machine.code}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Mould Ref</Label>
                      <Select 
                        value={production.mouldRef} 
                        onValueChange={(value) => updateProduction(index, 'mouldRef', value)}
                        disabled={!production.machineNo || isLoadingData}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select mould" />
                        </SelectTrigger>
                        <SelectContent>
                          {(referenceData.moulds[production.machineNo] || []).map(mould => (
                            <SelectItem key={mould.code} value={mould.code}>
                              {mould.name || mould.code}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>No. Samples for Test</Label>
                      <Input
                        type="number"
                        value={production.sampleCount}
                        onChange={(e) => updateProduction(index, 'sampleCount', parseInt(e.target.value) || 0)}
                        placeholder="6"
                      />
                    </div>
                    <div className="col-span-3">
                      <Label>Block Position No.</Label>
                      <div className="grid grid-cols-4 gap-2 mt-2">
                        {Array.from({length: 16}, (_, i) => i + 1).map(num => {
                          const selectedPositions = production.blockPosition.split(', ').filter(p => p.trim()).map(p => parseInt(p.trim()));
                          const isSelected = selectedPositions.includes(num);
                          
                          return (
                            <Toggle
                              key={num}
                              pressed={isSelected}
                              onPressedChange={(pressed) => {
                                const currentPositions = production.blockPosition.split(', ').filter(p => p.trim()).map(p => parseInt(p.trim()));
                                let newPositions;
                                
                                if (pressed) {
                                  newPositions = [...currentPositions, num].sort((a, b) => a - b);
                                } else {
                                  newPositions = currentPositions.filter(p => p !== num);
                                }
                                
                                updateProduction(index, 'blockPosition', newPositions);
                              }}
                              className="h-10 w-full"
                              variant={isSelected ? "default" : "outline"}
                            >
                              {num}
                            </Toggle>
                          );
                        })}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Selected: {production.blockPosition || 'None'}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Additional Remarks</Label>
                    <Textarea
                      value={production.remarks}
                      onChange={(e) => updateProduction(index, 'remarks', e.target.value)}
                      placeholder="Additional remarks for this production..."
                      rows={2}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Test Remarks and General Remarks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Additional Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="testRemarks">Test Remarks</Label>
                <Textarea
                  id="testRemarks"
                  value={formData.testRemarks}
                  onChange={(e) => setFormData({...formData, testRemarks: e.target.value})}
                  placeholder="Test specific remarks..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="remarks">General Remarks</Label>
                <Textarea
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => setFormData({...formData, remarks: e.target.value})}
                  placeholder="General remarks..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Memo"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}