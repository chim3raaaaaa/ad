import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Play, Pause, GitBranch, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useDeveloperData } from "@/hooks/useDeveloperData";

interface WorkflowStep {
  id: string;
  name: string;
  type: 'action' | 'condition' | 'delay' | 'notification' | 'approval';
  config: Record<string, any>;
  position: { x: number; y: number };
  connections: string[];
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  trigger: {
    type: 'manual' | 'schedule' | 'event' | 'webhook';
    config: Record<string, any>;
  };
  steps: WorkflowStep[];
  isActive: boolean;
  created_at: string;
  last_run?: string;
  run_count: number;
}

interface WorkflowExecution {
  id: string;
  workflowId: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  startTime: string;
  endTime?: string;
  currentStep?: string;
  logs: Array<{
    stepId: string;
    timestamp: string;
    message: string;
    level: 'info' | 'warning' | 'error';
  }>;
}

export function WorkflowBuilder() {
  const { toast } = useToast();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [currentWorkflow, setCurrentWorkflow] = useState<Workflow>({
    id: '',
    name: '',
    description: '',
    trigger: { type: 'manual', config: {} },
    steps: [],
    isActive: false,
    created_at: new Date().toISOString(),
    run_count: 0
  });
  const [executions, setExecutions] = useState<WorkflowExecution[]>([]);
  const [selectedStep, setSelectedStep] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const triggerTypes = [
    { value: 'manual', label: 'Manual Trigger', icon: '🔘' },
    { value: 'schedule', label: 'Scheduled', icon: '⏰' },
    { value: 'event', label: 'Event Based', icon: '⚡' },
    { value: 'webhook', label: 'Webhook', icon: '🔗' }
  ];

  const stepTypes = [
    { value: 'action', label: 'Action', icon: '⚙️', color: 'bg-blue-500' },
    { value: 'condition', label: 'Condition', icon: '🔀', color: 'bg-yellow-500' },
    { value: 'delay', label: 'Delay', icon: '⏳', color: 'bg-gray-500' },
    { value: 'notification', label: 'Notification', icon: '📧', color: 'bg-green-500' },
    { value: 'approval', label: 'Approval', icon: '✋', color: 'bg-purple-500' }
  ];

  const addStep = (type: WorkflowStep['type']) => {
    const newStep: WorkflowStep = {
      id: `step_${Date.now()}`,
      name: `New ${type}`,
      type,
      config: {},
      position: { 
        x: 100 + currentWorkflow.steps.length * 200, 
        y: 100 
      },
      connections: []
    };
    
    setCurrentWorkflow(prev => ({
      ...prev,
      steps: [...prev.steps, newStep]
    }));
    
    setSelectedStep(newStep.id);
  };

  const updateStep = (stepId: string, updates: Partial<WorkflowStep>) => {
    setCurrentWorkflow(prev => ({
      ...prev,
      steps: prev.steps.map(step => 
        step.id === stepId ? { ...step, ...updates } : step
      )
    }));
  };

  const removeStep = (stepId: string) => {
    setCurrentWorkflow(prev => ({
      ...prev,
      steps: prev.steps.filter(step => step.id !== stepId)
        .map(step => ({
          ...step,
          connections: step.connections.filter(conn => conn !== stepId)
        }))
    }));
    
    if (selectedStep === stepId) {
      setSelectedStep(null);
    }
  };

  const connectSteps = (fromStepId: string, toStepId: string) => {
    updateStep(fromStepId, {
      connections: [...(currentWorkflow.steps.find(s => s.id === fromStepId)?.connections || []), toStepId]
    });
  };

  const saveWorkflow = () => {
    if (!currentWorkflow.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Workflow name is required",
        variant: "destructive"
      });
      return;
    }

    const workflowToSave = {
      ...currentWorkflow,
      id: currentWorkflow.id || `workflow_${Date.now()}`,
      created_at: currentWorkflow.created_at || new Date().toISOString()
    };

    setWorkflows(prev => {
      const existing = prev.find(w => w.id === workflowToSave.id);
      if (existing) {
        return prev.map(w => w.id === workflowToSave.id ? workflowToSave : w);
      }
      return [...prev, workflowToSave];
    });

    toast({
      title: "Workflow Saved",
      description: `"${workflowToSave.name}" has been saved successfully`
    });

    setIsEditing(false);
    resetForm();
  };

  const loadWorkflow = (workflow: Workflow) => {
    setCurrentWorkflow(workflow);
    setSelectedStep(null);
    setIsEditing(true);
  };

  const deleteWorkflow = (workflowId: string) => {
    setWorkflows(prev => prev.filter(w => w.id !== workflowId));
    setExecutions(prev => prev.filter(e => e.workflowId !== workflowId));
    
    if (currentWorkflow.id === workflowId) {
      resetForm();
      setIsEditing(false);
    }

    toast({
      title: "Workflow Deleted",
      description: "Workflow has been removed"
    });
  };

  const toggleWorkflowStatus = (workflowId: string) => {
    setWorkflows(prev => prev.map(workflow => 
      workflow.id === workflowId 
        ? { ...workflow, isActive: !workflow.isActive }
        : workflow
    ));
  };

  const executeWorkflow = async (workflow: Workflow) => {
    const executionId = `exec_${Date.now()}`;
    
    const execution: WorkflowExecution = {
      id: executionId,
      workflowId: workflow.id,
      status: 'running',
      startTime: new Date().toISOString(),
      logs: [{
        stepId: 'system',
        timestamp: new Date().toISOString(),
        message: 'Workflow execution started',
        level: 'info'
      }]
    };
    
    setExecutions(prev => [execution, ...prev]);
    
    // Simulate workflow execution
    let currentExecution = { ...execution };
    
    for (const step of workflow.steps) {
      currentExecution.currentStep = step.id;
      
      // Add step start log
      currentExecution.logs.push({
        stepId: step.id,
        timestamp: new Date().toISOString(),
        message: `Executing step: ${step.name}`,
        level: 'info'
      });
      
      setExecutions(prev => prev.map(e => 
        e.id === executionId ? currentExecution : e
      ));
      
      // Simulate step execution time
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));
      
      // Simulate step completion
      currentExecution.logs.push({
        stepId: step.id,
        timestamp: new Date().toISOString(),
        message: `Step completed: ${step.name}`,
        level: 'info'
      });
    }
    
    currentExecution.status = 'completed';
    currentExecution.endTime = new Date().toISOString();
    currentExecution.currentStep = undefined;
    
    currentExecution.logs.push({
      stepId: 'system',
      timestamp: new Date().toISOString(),
      message: 'Workflow execution completed successfully',
      level: 'info'
    });
    
    setExecutions(prev => prev.map(e => 
      e.id === executionId ? currentExecution : e
    ));
    
    // Update workflow run count
    setWorkflows(prev => prev.map(w => 
      w.id === workflow.id 
        ? { ...w, run_count: w.run_count + 1, last_run: new Date().toISOString() }
        : w
    ));

    toast({
      title: "Workflow Completed",
      description: `"${workflow.name}" executed successfully`
    });
  };

  const resetForm = () => {
    setCurrentWorkflow({
      id: '',
      name: '',
      description: '',
      trigger: { type: 'manual', config: {} },
      steps: [],
      isActive: false,
      created_at: new Date().toISOString(),
      run_count: 0
    });
  };

  const getStepColor = (type: string) => {
    return stepTypes.find(s => s.value === type)?.color || 'bg-gray-500';
  };

  const getStepIcon = (type: string) => {
    return stepTypes.find(s => s.value === type)?.icon || '⚙️';
  };

  const selectedStepData = currentWorkflow.steps.find(s => s.id === selectedStep);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Workflow Builder</h3>
          <p className="text-sm text-muted-foreground">Create automated business processes</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={() => {
              resetForm();
              setIsEditing(!isEditing);
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Workflow
          </Button>
        </div>
      </div>

      <Tabs defaultValue="workflows" className="space-y-4">
        <TabsList>
          <TabsTrigger value="workflows">Workflows ({workflows.length})</TabsTrigger>
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="executions">Executions</TabsTrigger>
        </TabsList>

        <TabsContent value="workflows">
          <div className="space-y-4">
            {workflows.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <GitBranch className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Workflows</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    Create your first workflow to automate business processes
                  </p>
                  <Button onClick={() => setIsEditing(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Workflow
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {workflows.map(workflow => (
                  <Card key={workflow.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{workflow.name}</CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant={workflow.isActive ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {workflow.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                          <Switch
                            checked={workflow.isActive}
                            onCheckedChange={() => toggleWorkflowStatus(workflow.id)}
                          />
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {workflow.steps.length} steps • Run {workflow.run_count} times
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-muted-foreground">{workflow.description}</p>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {triggerTypes.find(t => t.value === workflow.trigger.type)?.icon} 
                          {triggerTypes.find(t => t.value === workflow.trigger.type)?.label}
                        </Badge>
                      </div>

                      {workflow.last_run && (
                        <p className="text-xs text-muted-foreground">
                          Last run: {new Date(workflow.last_run).toLocaleString()}
                        </p>
                      )}
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm"
                          onClick={() => executeWorkflow(workflow)}
                          disabled={!workflow.isActive}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Run
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => loadWorkflow(workflow)}>
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => deleteWorkflow(workflow.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="builder">
          {isEditing ? (
            <div className="space-y-6">
              {/* Workflow Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Workflow Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="workflow-name">Name</Label>
                      <Input
                        id="workflow-name"
                        value={currentWorkflow.name}
                        onChange={(e) => setCurrentWorkflow(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="My Workflow"
                      />
                    </div>
                    
                    <div>
                      <Label>Trigger Type</Label>
                      <Select
                        value={currentWorkflow.trigger.type}
                        onValueChange={(value) => setCurrentWorkflow(prev => ({ 
                          ...prev, 
                          trigger: { ...prev.trigger, type: value as Workflow['trigger']['type'] }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {triggerTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.icon} {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="workflow-description">Description</Label>
                    <Textarea
                      id="workflow-description"
                      value={currentWorkflow.description}
                      onChange={(e) => setCurrentWorkflow(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Workflow description"
                      rows={2}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Active</Label>
                    <Switch
                      checked={currentWorkflow.isActive}
                      onCheckedChange={(checked) => setCurrentWorkflow(prev => ({ ...prev, isActive: checked }))}
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Step Palette */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Add Steps</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {stepTypes.map(type => (
                      <Button
                        key={type.value}
                        variant="outline"
                        className="w-full justify-start"
                        onClick={() => addStep(type.value as WorkflowStep['type'])}
                      >
                        <span className="mr-2">{type.icon}</span>
                        {type.label}
                      </Button>
                    ))}
                  </CardContent>
                </Card>

                {/* Workflow Canvas */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Workflow Canvas</CardTitle>
                      <Badge variant="outline">
                        {currentWorkflow.steps.length} steps
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="relative border border-dashed border-gray-300 rounded-lg overflow-hidden min-h-96 bg-gray-50/50">
                      {currentWorkflow.steps.length === 0 ? (
                        <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                          <div className="text-center">
                            <GitBranch className="w-12 h-12 mx-auto mb-2" />
                            <p>Add steps to build your workflow</p>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4">
                          {/* Render workflow steps */}
                          <div className="flex items-center gap-4">
                            {currentWorkflow.steps.map((step, index) => (
                              <div key={step.id} className="flex items-center gap-2">
                                <div
                                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                                    selectedStep === step.id ? 'ring-2 ring-primary' : ''
                                  } ${getStepColor(step.type)} text-white`}
                                  onClick={() => setSelectedStep(step.id)}
                                >
                                  <div className="text-center">
                                    <div className="text-lg mb-1">{getStepIcon(step.type)}</div>
                                    <div className="text-xs">{step.name}</div>
                                  </div>
                                </div>
                                {index < currentWorkflow.steps.length - 1 && (
                                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Step Properties */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Step Properties</CardTitle>
                      {selectedStepData && (
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => removeStep(selectedStepData.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {selectedStepData ? (
                      <div className="space-y-4">
                        <div>
                          <Label>Step Name</Label>
                          <Input
                            value={selectedStepData.name}
                            onChange={(e) => updateStep(selectedStepData.id, { name: e.target.value })}
                          />
                        </div>
                        
                        <div>
                          <Label>Step Type</Label>
                          <Select
                            value={selectedStepData.type}
                            onValueChange={(value) => updateStep(selectedStepData.id, { type: value as WorkflowStep['type'] })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {stepTypes.map(type => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.icon} {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Step-specific configuration */}
                        {selectedStepData.type === 'delay' && (
                          <div>
                            <Label>Delay Duration (seconds)</Label>
                            <Input
                              type="number"
                              value={selectedStepData.config.duration || 60}
                              onChange={(e) => updateStep(selectedStepData.id, {
                                config: { ...selectedStepData.config, duration: parseInt(e.target.value) }
                              })}
                            />
                          </div>
                        )}

                        {selectedStepData.type === 'notification' && (
                          <div className="space-y-2">
                            <div>
                              <Label>Notification Type</Label>
                              <Select
                                value={selectedStepData.config.type || 'email'}
                                onValueChange={(value) => updateStep(selectedStepData.id, {
                                  config: { ...selectedStepData.config, type: value }
                                })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="email">Email</SelectItem>
                                  <SelectItem value="sms">SMS</SelectItem>
                                  <SelectItem value="slack">Slack</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label>Message</Label>
                              <Textarea
                                value={selectedStepData.config.message || ''}
                                onChange={(e) => updateStep(selectedStepData.id, {
                                  config: { ...selectedStepData.config, message: e.target.value }
                                })}
                                placeholder="Notification message"
                              />
                            </div>
                          </div>
                        )}

                        {selectedStepData.type === 'condition' && (
                          <div className="space-y-2">
                            <div>
                              <Label>Condition</Label>
                              <Input
                                value={selectedStepData.config.condition || ''}
                                onChange={(e) => updateStep(selectedStepData.id, {
                                  config: { ...selectedStepData.config, condition: e.target.value }
                                })}
                                placeholder="e.g., status == 'approved'"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground py-8">
                        <GitBranch className="w-8 h-8 mx-auto mb-2" />
                        <p>Select a step to configure</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-2">
                <Button onClick={saveWorkflow} className="flex-1">
                  Save Workflow
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => executeWorkflow(currentWorkflow)}
                  disabled={currentWorkflow.steps.length === 0}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Test Run
                </Button>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <GitBranch className="w-12 h-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Workflow Selected</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Select a workflow to edit or create a new one
                </p>
                <Button onClick={() => setIsEditing(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Workflow
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="executions">
          <div className="space-y-4">
            {executions.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Play className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Executions</h3>
                  <p className="text-muted-foreground text-center">
                    Run workflows to see execution history here
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {executions.map(execution => {
                  const workflow = workflows.find(w => w.id === execution.workflowId);
                  if (!workflow) return null;
                  
                  return (
                    <Card key={execution.id}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-base">{workflow.name}</CardTitle>
                            <p className="text-sm text-muted-foreground">
                              Started: {new Date(execution.startTime).toLocaleString()}
                              {execution.endTime && (
                                <> • Duration: {Math.round((new Date(execution.endTime).getTime() - new Date(execution.startTime).getTime()) / 1000)}s</>
                              )}
                            </p>
                          </div>
                          <Badge 
                            variant={
                              execution.status === 'completed' ? 'default' :
                              execution.status === 'running' ? 'secondary' :
                              execution.status === 'failed' ? 'destructive' : 'outline'
                            }
                          >
                            {execution.status === 'running' && <span className="animate-spin mr-1">⚪</span>}
                            {execution.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {execution.logs.map((log, index) => (
                            <div key={index} className="flex items-start gap-2 text-sm">
                              <span className="text-xs text-muted-foreground min-w-16">
                                {new Date(log.timestamp).toLocaleTimeString()}
                              </span>
                              <span className={`w-2 h-2 rounded-full mt-1.5 ${
                                log.level === 'error' ? 'bg-red-500' :
                                log.level === 'warning' ? 'bg-yellow-500' : 'bg-green-500'
                              }`} />
                              <span className="flex-1">{log.message}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}