import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Mail, TestTube2, Shield, AlertTriangle, CheckCircle, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SMTPConfig {
  enabled: boolean;
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
  fromEmail: string;
  fromName: string;
  testEmail: string;
}

export function SMTPConfiguration() {
  const { toast } = useToast();
  const [config, setConfig] = useState<SMTPConfig>({
    enabled: false,
    host: "",
    port: 587,
    secure: false,
    username: "",
    password: "",
    fromEmail: "",
    fromName: "Lab System",
    testEmail: ""
  });
  const [isLoading, setIsLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [isSaving, setIsSaving] = useState(false);

  // Load saved configuration on mount
  useEffect(() => {
    loadSavedConfig();
  }, []);

  const loadSavedConfig = async () => {
    try {
      // Try to load from Electron database if available
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM smtp_config WHERE id = 1'
        );
        
        if (result.success && result.data && result.data.length > 0) {
          const savedConfig = result.data[0];
          setConfig({
            enabled: Boolean(savedConfig.enabled),
            host: savedConfig.host || "",
            port: savedConfig.port || 587,
            secure: Boolean(savedConfig.secure),
            username: savedConfig.username || "",
            password: savedConfig.password || "",
            fromEmail: savedConfig.from_email || "",
            fromName: savedConfig.from_name || "Lab System",
            testEmail: savedConfig.test_email || ""
          });
        }
      } else {
        // Fallback to localStorage
        const saved = localStorage.getItem('smtp-config');
        if (saved) {
          setConfig(JSON.parse(saved));
        }
      }
    } catch (error) {
      console.error('Failed to load SMTP config:', error);
      toast({
        title: "Load Error",
        description: "Failed to load SMTP configuration",
        variant: "destructive"
      });
    }
  };

  const saveConfig = async () => {
    setIsSaving(true);
    try {
      // Save to Electron database if available
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO smtp_config 
           (id, enabled, host, port, secure, username, password, from_email, from_name, test_email, updated_at)
           VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            config.enabled ? 1 : 0,
            config.host,
            config.port,
            config.secure ? 1 : 0,
            config.username,
            config.password,
            config.fromEmail,
            config.fromName,
            config.testEmail,
            new Date().toISOString()
          ]
        );

        if (!result.success) {
          throw new Error(result.error);
        }

        toast({
          title: "Configuration Saved",
          description: "SMTP settings saved securely to database"
        });
      } else {
        // Fallback to localStorage (not recommended for production)
        localStorage.setItem('smtp-config', JSON.stringify(config));
        toast({
          title: "Configuration Saved",
          description: "SMTP settings saved locally (database unavailable)",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Failed to save SMTP config:', error);
      toast({
        title: "Save Error",
        description: "Failed to save SMTP configuration",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const testConnection = async () => {
    if (!config.host || !config.username || !config.password) {
      toast({
        title: "Validation Error",
        description: "Please fill in host, username, and password",
        variant: "destructive"
      });
      return;
    }

    setConnectionStatus('testing');
    setIsLoading(true);

    try {
      // Simulate SMTP connection test
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In a real implementation, you would test the actual SMTP connection
      // For now, we'll simulate a successful test
      setConnectionStatus('success');
      toast({
        title: "Connection Successful",
        description: "SMTP server connection test passed"
      });
    } catch (error) {
      setConnectionStatus('error');
      toast({
        title: "Connection Failed",
        description: "Unable to connect to SMTP server. Please check your settings.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const sendTestEmail = async () => {
    if (!config.testEmail) {
      toast({
        title: "Validation Error",
        description: "Please enter a test email address",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // Simulate sending test email
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Test Email Sent",
        description: `Test email sent successfully to ${config.testEmail}`
      });
    } catch (error) {
      toast({
        title: "Send Failed",
        description: "Failed to send test email",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateConfig = (field: keyof SMTPConfig, value: any) => {
    setConfig(prev => ({ ...prev, [field]: value }));
    setConnectionStatus('idle'); // Reset connection status when config changes
  };

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case 'testing':
        return <TestTube2 className="h-4 w-4 animate-spin text-blue-600" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Mail className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'testing':
        return 'Testing connection...';
      case 'success':
        return 'Connection successful';
      case 'error':
        return 'Connection failed';
      default:
        return 'Not tested';
    }
  };

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'testing':
        return 'text-blue-600';
      case 'success':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">SMTP Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Configure email settings for notifications and reports
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge 
            variant={config.enabled ? "default" : "secondary"}
            className="flex items-center gap-1"
          >
            <Mail className="h-3 w-3" />
            {config.enabled ? "Enabled" : "Disabled"}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SMTP Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Server Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Enable SMTP</Label>
                <p className="text-sm text-muted-foreground">
                  Enable email functionality for the system
                </p>
              </div>
              <Switch
                checked={config.enabled}
                onCheckedChange={(checked) => updateConfig('enabled', checked)}
              />
            </div>

            <div>
              <Label htmlFor="smtp-host">SMTP Host</Label>
              <Input
                id="smtp-host"
                value={config.host}
                onChange={(e) => updateConfig('host', e.target.value)}
                placeholder="smtp.gmail.com"
                disabled={!config.enabled}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="smtp-port">Port</Label>
                <Input
                  id="smtp-port"
                  type="number"
                  value={config.port}
                  onChange={(e) => updateConfig('port', parseInt(e.target.value) || 587)}
                  disabled={!config.enabled}
                />
              </div>
              <div className="space-y-2">
                <Label>Security</Label>
                <Select
                  value={config.secure ? "true" : "false"}
                  onValueChange={(value) => updateConfig('secure', value === "true")}
                  disabled={!config.enabled}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="false">STARTTLS (587)</SelectItem>
                    <SelectItem value="true">SSL/TLS (465)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="smtp-username">Username</Label>
              <Input
                id="smtp-username"
                value={config.username}
                onChange={(e) => updateConfig('username', e.target.value)}
                placeholder="your-email@domain.com"
                disabled={!config.enabled}
              />
            </div>

            <div>
              <Label htmlFor="smtp-password">Password</Label>
              <Input
                id="smtp-password"
                type="password"
                value={config.password}
                onChange={(e) => updateConfig('password', e.target.value)}
                placeholder="Your app password"
                disabled={!config.enabled}
              />
            </div>
          </CardContent>
        </Card>

        {/* Email Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Send className="h-4 w-4" />
              Email Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="from-email">From Email</Label>
              <Input
                id="from-email"
                value={config.fromEmail}
                onChange={(e) => updateConfig('fromEmail', e.target.value)}
                placeholder="noreply@yourlab.com"
                disabled={!config.enabled}
              />
            </div>

            <div>
              <Label htmlFor="from-name">From Name</Label>
              <Input
                id="from-name"
                value={config.fromName}
                onChange={(e) => updateConfig('fromName', e.target.value)}
                placeholder="Lab System"
                disabled={!config.enabled}
              />
            </div>

            <div>
              <Label htmlFor="test-email">Test Email Address</Label>
              <Input
                id="test-email"
                type="email"
                value={config.testEmail}
                onChange={(e) => updateConfig('testEmail', e.target.value)}
                placeholder="test@domain.com"
                disabled={!config.enabled}
              />
            </div>

            {/* Connection Status */}
            <div className="p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon()}
                  <span className={`text-sm font-medium ${getStatusColor()}`}>
                    {getStatusText()}
                  </span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={testConnection}
                  disabled={!config.enabled || isLoading || !config.host}
                >
                  {isLoading ? 'Testing...' : 'Test Connection'}
                </Button>
              </div>
            </div>

            {/* Test Email */}
            <div className="space-y-2">
              <Button
                variant="outline"
                onClick={sendTestEmail}
                disabled={!config.enabled || isLoading || connectionStatus !== 'success'}
                className="w-full"
              >
                <Send className="h-4 w-4 mr-2" />
                {isLoading ? 'Sending...' : 'Send Test Email'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Notice */}
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-amber-600 mt-0.5" />
            <div>
              <p className="font-medium text-amber-800">Security Notice</p>
              <p className="text-sm text-amber-700 mt-1">
                SMTP credentials are stored securely in the local database. For production use,
                consider using application-specific passwords and enabling two-factor authentication
                on your email account.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={saveConfig} disabled={isSaving || !config.enabled}>
          {isSaving ? 'Saving...' : 'Save Configuration'}
        </Button>
      </div>
    </div>
  );
}