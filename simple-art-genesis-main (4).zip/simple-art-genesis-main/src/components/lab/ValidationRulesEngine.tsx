import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Play, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Code, 
  Settings,
  Save,
  X
} from 'lucide-react';
import { dataService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import type { ValidationRule, ValidationResult } from '@/services/api/types';

const ruleTypes = [
  { value: 'threshold', label: 'Threshold (Min/Max)', description: 'Validate values within numeric ranges' },
  { value: 'cross_field', label: 'Cross-Field', description: 'Validate consistency between multiple fields' },
  { value: 'formula', label: 'Custom Formula', description: 'Validate using custom JavaScript expressions' },
  { value: 'pattern', label: 'Pattern Match', description: 'Validate using regular expressions' }
];

const severityColors = {
  error: 'destructive',
  warning: 'secondary',
  info: 'outline'
};

export default function ValidationRulesEngine() {
  const [rules, setRules] = useState<ValidationRule[]>([]);
  const [results, setResults] = useState<ValidationResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingRule, setEditingRule] = useState<ValidationRule | null>(null);
  const [showRuleBuilder, setShowRuleBuilder] = useState(false);
  const [testData, setTestData] = useState('');
  const { toast } = useToast();

  // Load rules from dataService instead of just mock data
  useEffect(() => {
    const loadRules = async () => {
      try {
        const response = await dataService.getValidationRules();
        if (response.data && response.data.length > 0) {
          setRules(response.data);
        } else {
          // Initialize with sample rules if none exist
          const mockRules: ValidationRule[] = [
            {
              id: 'rule_001',
              name: 'Compressive Strength Minimum',
              description: 'Ensure compressive strength meets minimum requirements',
              table_name: 'test_results',
              field_name: 'compressive_strength',
              rule_type: 'threshold',
              configuration: {
                min_value: 20,
                max_value: 60,
                error_message: 'Compressive strength must be between 20-60 MPa',
                warning_message: 'Compressive strength is approaching limits'
              },
              severity: 'error',
              active: true,
              created_by: 'system',
              created_at: '2024-01-15T10:00:00Z',
              updated_at: '2024-01-15T10:00:00Z'
            },
            {
              id: 'rule_002',
              name: 'Slump Value Range',
              description: 'Verify slump values are within acceptable range',
              table_name: 'fresh_concrete_tests',
              field_name: 'slump_value',
              rule_type: 'threshold',
              configuration: {
                min_value: 25,
                max_value: 100,
                error_message: 'Slump value must be between 25-100mm',
                warning_message: 'Slump value is approaching limits'
              },
              severity: 'warning',
              active: true,
              created_by: 'system',
              created_at: '2024-01-15T10:00:00Z',
              updated_at: '2024-01-15T10:00:00Z'
            }
          ];
          setRules(mockRules);
          // Save initial rules to storage
          for (const rule of mockRules) {
            await dataService.createValidationRule(rule);
          }
        }
        
        // Sample validation results
        const mockResults: ValidationResult[] = [
          { 
            id: 'result_001', 
            rule_id: 'rule_001', 
            table_name: 'test_results', 
            record_id: 'test_123', 
            field_name: 'compressive_strength', 
            status: 'fail', 
            message: 'Below minimum threshold', 
            actual_value: 15.2, 
            expected_value: '20-60', 
            validated_at: '2024-02-01T12:00:00Z' 
          }
        ];
        setResults(mockResults);
      } catch (error) {
        console.error('Error loading validation rules:', error);
        toast({
          title: 'Error',
          description: 'Failed to load validation rules',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    };

    loadRules();
  }, []);

  const handleSaveRule = async (ruleData: Partial<ValidationRule>) => {
    try {
      if (editingRule) {
        await dataService.updateValidationRule(editingRule.id, ruleData);
        toast({
          title: 'Success',
          description: 'Validation rule updated successfully'
        });
      } else {
        await dataService.createValidationRule(ruleData as Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>);
        toast({
          title: 'Success',
          description: 'Validation rule created successfully'
        });
      }
      
      setShowRuleBuilder(false);
      setEditingRule(null);
      
      // Refresh rules list
      const response = await dataService.getValidationRules();
      if (response.data) {
        setRules(response.data);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save validation rule',
        variant: 'destructive'
      });
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    try {
      await dataService.deleteValidationRule(ruleId);
      toast({
        title: 'Success',
        description: 'Validation rule deleted successfully'
      });
      
      // Refresh rules list
      const response = await dataService.getValidationRules();
      if (response.data) {
        setRules(response.data);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete validation rule',
        variant: 'destructive'
      });
    }
  };

  const handleTestValidation = async () => {
    if (!testData) {
      toast({
        title: 'Error',
        description: 'Please enter test data',
        variant: 'destructive'
      });
      return;
    }

    try {
      const data = JSON.parse(testData);
      const response = await dataService.validateRecord('test_table', 'test_record', data);
      
      toast({
        title: 'Validation Complete',
        description: `Found ${response.data.length} validation results`
      });
      
      // Show results in the results tab
      setResults(response.data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Invalid JSON data or validation failed',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Validation Rules Engine</h2>
          <p className="text-muted-foreground">
            Create and manage data validation rules with real-time checking
          </p>
        </div>
        
        <Button onClick={() => setShowRuleBuilder(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Rule
        </Button>
      </div>

      <Tabs defaultValue="rules" className="space-y-4">
        <TabsList>
          <TabsTrigger value="rules">
            <Settings className="w-4 h-4 mr-2" />
            Rules ({rules.length})
          </TabsTrigger>
          <TabsTrigger value="results">
            <CheckCircle className="w-4 h-4 mr-2" />
            Results ({results.length})
          </TabsTrigger>
          <TabsTrigger value="test">
            <Play className="w-4 h-4 mr-2" />
            Test Validator
          </TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-4">
          {rules.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Settings className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No validation rules</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first validation rule to start automatic data checking
                </p>
                <Button onClick={() => setShowRuleBuilder(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Rule
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {rules.map((rule) => (
                <Card key={rule.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{rule.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">
                          {rule.table_name}.{rule.field_name}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={severityColors[rule.severity] as any}>
                          {rule.severity}
                        </Badge>
                        <Badge variant={rule.active ? 'default' : 'secondary'}>
                          {rule.active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      {rule.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">
                        {rule.rule_type}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">
                        Created: {new Date(rule.created_at).toLocaleDateString()}
                      </span>
                      
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingRule(rule);
                            setShowRuleBuilder(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteRule(rule.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <div className="grid gap-4">
            {results.map((result) => (
              <Alert key={result.id} className={result.status === 'fail' ? 'border-destructive' : result.status === 'warning' ? 'border-yellow-500' : 'border-green-500'}>
                <div className="flex items-center gap-2">
                  {result.status === 'fail' && <AlertTriangle className="h-4 w-4 text-destructive" />}
                  {result.status === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-500" />}
                  {result.status === 'pass' && <CheckCircle className="h-4 w-4 text-green-500" />}
                  <div className="flex-1">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">
                        {result.table_name}.{result.field_name}
                      </span>
                      <Badge variant={result.status === 'fail' ? 'destructive' : result.status === 'warning' ? 'secondary' : 'default'}>
                        {result.status}
                      </Badge>
                    </div>
                    <AlertDescription className="mt-1">
                      {result.message}
                      {result.actual_value && (
                        <span className="block mt-1 text-xs">
                          Actual: {JSON.stringify(result.actual_value)}
                          {result.expected_value && ` | Expected: ${JSON.stringify(result.expected_value)}`}
                        </span>
                      )}
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="test" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Validation Rules</CardTitle>
              <p className="text-sm text-muted-foreground">
                Enter JSON data to test against your validation rules
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="testData">Test Data (JSON)</Label>
                <Textarea
                  id="testData"
                  placeholder='{"field1": 100, "field2": "test value", "field3": 25.5}'
                  value={testData}
                  onChange={(e) => setTestData(e.target.value)}
                  rows={8}
                  className="font-mono text-sm"
                />
              </div>
              
              <Button onClick={handleTestValidation} className="w-full">
                <Play className="w-4 h-4 mr-2" />
                Run Validation Test
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Rule Builder Dialog */}
      <RuleBuilderDialog
        open={showRuleBuilder}
        onOpenChange={setShowRuleBuilder}
        rule={editingRule}
        onSave={handleSaveRule}
        onCancel={() => {
          setShowRuleBuilder(false);
          setEditingRule(null);
        }}
      />
    </div>
  );
}

// Rule Builder Dialog Component
function RuleBuilderDialog({ 
  open, 
  onOpenChange, 
  rule, 
  onSave, 
  onCancel 
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rule: ValidationRule | null;
  onSave: (rule: Partial<ValidationRule>) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<any>({
    name: '',
    description: '',
    table_name: '',
    field_name: '',
    rule_type: 'threshold',
    configuration: {
      min_value: '',
      max_value: '',
      related_fields: [],
      formula: '',
      pattern: '',
      error_message: '',
      warning_message: ''
    },
    severity: 'error',
    active: true,
    created_by: 'current_user'
  });

  useEffect(() => {
    if (rule) {
      setFormData({
        name: rule.name,
        description: rule.description,
        table_name: rule.table_name,
        field_name: rule.field_name,
        rule_type: rule.rule_type,
        configuration: { ...rule.configuration },
        severity: rule.severity,
        active: rule.active,
        created_by: rule.created_by
      });
    } else {
      // Reset form
      setFormData({
        name: '',
        description: '',
        table_name: '',
        field_name: '',
        rule_type: 'threshold',
        configuration: {
          min_value: '',
          max_value: '',
          related_fields: [],
          formula: '',
          pattern: '',
          error_message: '',
          warning_message: ''
        },
        severity: 'error',
        active: true,
        created_by: 'current_user'
      });
    }
  }, [rule, open]);

  const handleSave = () => {
    const ruleData = {
      ...formData,
      configuration: {
        ...formData.configuration,
        min_value: formData.configuration.min_value ? Number(formData.configuration.min_value) : undefined,
        max_value: formData.configuration.max_value ? Number(formData.configuration.max_value) : undefined
      }
    };
    onSave(ruleData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {rule ? 'Edit Validation Rule' : 'Create Validation Rule'}
          </DialogTitle>
          <DialogDescription>
            Configure data validation rules with custom logic and thresholds
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Rule Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Strength Range Check"
              />
            </div>
            
            <div>
              <Label htmlFor="severity">Severity</Label>
              <Select value={formData.severity} onValueChange={(value: any) => setFormData({ ...formData, severity: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="error">Error (Blocks Save)</SelectItem>
                  <SelectItem value="warning">Warning (Shows Alert)</SelectItem>
                  <SelectItem value="info">Info (Notification Only)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what this rule validates..."
            />
          </div>

          {/* Target Configuration */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="table_name">Table Name</Label>
              <Input
                id="table_name"
                value={formData.table_name}
                onChange={(e) => setFormData({ ...formData, table_name: e.target.value })}
                placeholder="e.g., cube_tests"
              />
            </div>
            
            <div>
              <Label htmlFor="field_name">Field Name</Label>
              <Input
                id="field_name"
                value={formData.field_name}
                onChange={(e) => setFormData({ ...formData, field_name: e.target.value })}
                placeholder="e.g., strength_mpa"
              />
            </div>
          </div>

          {/* Rule Type */}
          <div>
            <Label htmlFor="rule_type">Rule Type</Label>
            <Select value={formData.rule_type} onValueChange={(value: any) => setFormData({ ...formData, rule_type: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ruleTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <div>
                      <div className="font-medium">{type.label}</div>
                      <div className="text-xs text-muted-foreground">{type.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Rule Configuration */}
          {formData.rule_type === 'threshold' && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="min_value">Minimum Value</Label>
                <Input
                  id="min_value"
                  type="number"
                  value={formData.configuration.min_value}
                  onChange={(e) => setFormData({
                    ...formData,
                    configuration: { ...formData.configuration, min_value: e.target.value }
                  })}
                  placeholder="0"
                />
              </div>
              
              <div>
                <Label htmlFor="max_value">Maximum Value</Label>
                <Input
                  id="max_value"
                  type="number"
                  value={formData.configuration.max_value}
                  onChange={(e) => setFormData({
                    ...formData,
                    configuration: { ...formData.configuration, max_value: e.target.value }
                  })}
                  placeholder="100"
                />
              </div>
            </div>
          )}

          {formData.rule_type === 'formula' && (
            <div>
              <Label htmlFor="formula">Custom Formula (JavaScript)</Label>
              <Textarea
                id="formula"
                value={formData.configuration.formula}
                onChange={(e) => setFormData({
                  ...formData,
                  configuration: { ...formData.configuration, formula: e.target.value }
                })}
                placeholder="value > 0 && value <= (record.target_strength * 1.2)"
                className="font-mono text-sm"
                rows={3}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Use 'value' for current field, 'record' for full record data
              </p>
            </div>
          )}

          {formData.rule_type === 'pattern' && (
            <div>
              <Label htmlFor="pattern">Regular Expression Pattern</Label>
              <Input
                id="pattern"
                value={formData.configuration.pattern}
                onChange={(e) => setFormData({
                  ...formData,
                  configuration: { ...formData.configuration, pattern: e.target.value }
                })}
                placeholder="^[A-Z]{2}-\d{4}$"
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Enter a regex pattern to validate the field format
              </p>
            </div>
          )}

          {/* Messages */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="error_message">Error Message</Label>
              <Input
                id="error_message"
                value={formData.configuration.error_message}
                onChange={(e) => setFormData({
                  ...formData,
                  configuration: { ...formData.configuration, error_message: e.target.value }
                })}
                placeholder="Value must be between {min} and {max}"
              />
            </div>
            
            <div>
              <Label htmlFor="warning_message">Warning Message</Label>
              <Input
                id="warning_message"
                value={formData.configuration.warning_message}
                onChange={(e) => setFormData({
                  ...formData,
                  configuration: { ...formData.configuration, warning_message: e.target.value }
                })}
                placeholder="Value is outside recommended range"
              />
            </div>
          </div>

          {/* Active Toggle */}
          <div className="flex items-center space-x-2">
            <Switch
              id="active"
              checked={formData.active}
              onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
            />
            <Label htmlFor="active">Rule is active</Label>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              {rule ? 'Update Rule' : 'Create Rule'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}