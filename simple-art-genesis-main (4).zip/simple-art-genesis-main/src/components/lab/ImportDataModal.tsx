import React, { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { Upload, FileSpreadsheet, Check, X, AlertTriangle } from 'lucide-react';

interface ImportDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: (results: any) => void;
  moduleId?: string;
  testType?: string;
}

interface ColumnMapping {
  excelColumn: string;
  databaseField: string;
  required: boolean;
  dataType: 'text' | 'number' | 'date' | 'json';
}

interface ImportPreview {
  headers: string[];
  rows: any[][];
  totalRows: number;
}

export default function ImportDataModal({ 
  isOpen, 
  onClose, 
  onImportComplete, 
  moduleId, 
  testType 
}: ImportDataModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [step, setStep] = useState<'upload' | 'mapping' | 'preview' | 'importing' | 'complete'>('upload');
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [importProgress, setImportProgress] = useState(0);
  const [importResults, setImportResults] = useState<any>(null);

  const databaseFields = [
    { key: 'module_id', label: 'Module ID', required: true, dataType: 'text' as const },
    { key: 'test_type', label: 'Test Type', required: true, dataType: 'text' as const },
    { key: 'batch_id', label: 'Batch ID', required: false, dataType: 'text' as const },
    { key: 'product_type', label: 'Product Type', required: false, dataType: 'text' as const },
    { key: 'test_date', label: 'Test Date', required: true, dataType: 'date' as const },
    { key: 'site', label: 'Site', required: false, dataType: 'text' as const },
    { key: 'operator', label: 'Operator', required: false, dataType: 'text' as const },
    { key: 'test_results', label: 'Test Results (JSON)', required: true, dataType: 'json' as const },
    { key: 'pass_fail_status', label: 'Pass/Fail Status', required: false, dataType: 'text' as const },
    { key: 'notes', label: 'Notes', required: false, dataType: 'text' as const }
  ];

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.match(/\.(xlsx?|csv)$/i)) {
      toast.error('Please upload an Excel (.xlsx, .xls) or CSV file');
      return;
    }

    setFile(selectedFile);
    parseFile(selectedFile);
  }, []);

  const parseFile = async (file: File) => {
    try {
      const text = await file.text();
      let rows: string[][];
      
      if (file.name.endsWith('.csv')) {
        rows = text.split('\n').map(row => row.split(',').map(cell => cell.trim().replace(/^"|"$/g, '')));
      } else {
        // For Excel files, we'll simulate parsing (in a real app, you'd use SheetJS or similar)
        rows = text.split('\n').slice(0, 20).map(row => row.split('\t').map(cell => cell.trim()));
      }

      if (rows.length === 0) {
        toast.error('File appears to be empty');
        return;
      }

      const headers = rows[0];
      const dataRows = rows.slice(1).filter(row => row.some(cell => cell.length > 0));

      setPreview({
        headers,
        rows: dataRows.slice(0, 10), // Show first 10 rows for preview
        totalRows: dataRows.length
      });

      // Auto-suggest column mappings
      const autoMappings: ColumnMapping[] = [];
      headers.forEach(header => {
        const normalizedHeader = header.toLowerCase().replace(/[^a-z0-9]/g, '');
        const matchedField = databaseFields.find(field => 
          field.key.toLowerCase().includes(normalizedHeader) || 
          normalizedHeader.includes(field.key.toLowerCase()) ||
          field.label.toLowerCase().replace(/[^a-z0-9]/g, '').includes(normalizedHeader)
        );

        autoMappings.push({
          excelColumn: header,
          databaseField: matchedField?.key || '',
          required: matchedField?.required || false,
          dataType: matchedField?.dataType || 'text'
        });
      });

      setColumnMappings(autoMappings);
      setStep('mapping');
    } catch (error) {
      toast.error('Failed to parse file. Please check the file format.');
      console.error('File parsing error:', error);
    }
  };

  const handleMappingChange = (index: number, field: string) => {
    const updatedMappings = [...columnMappings];
    const dbField = databaseFields.find(f => f.key === field);
    updatedMappings[index] = {
      ...updatedMappings[index],
      databaseField: field,
      required: dbField?.required || false,
      dataType: dbField?.dataType || 'text'
    };
    setColumnMappings(updatedMappings);
  };

  const validateMappings = () => {
    const requiredFields = databaseFields.filter(f => f.required).map(f => f.key);
    const mappedFields = columnMappings.map(m => m.databaseField).filter(Boolean);
    const missingRequired = requiredFields.filter(field => !mappedFields.includes(field));
    
    if (missingRequired.length > 0) {
      toast.error(`Missing required fields: ${missingRequired.join(', ')}`);
      return false;
    }
    
    return true;
  };

  const handlePreview = () => {
    if (!validateMappings()) return;
    setStep('preview');
  };

  const handleImport = async () => {
    if (!preview || !file) return;

    setStep('importing');
    setImportProgress(0);

    try {
      const mappedData = preview.rows.map((row, index) => {
        const entry: any = {
          id: `import_${Date.now()}_${index}`,
          module_id: moduleId || '',
          test_type: testType || '',
          source: 'imported',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        columnMappings.forEach((mapping, colIndex) => {
          if (mapping.databaseField && mapping.databaseField !== "__skip__" && row[colIndex]) {
            let value = row[colIndex];
            
            // Data type conversion
            switch (mapping.dataType) {
              case 'number':
                value = parseFloat(value) || 0;
                break;
              case 'date':
                value = new Date(value).toISOString();
                break;
              case 'json':
                try {
                  value = JSON.parse(value);
                } catch {
                  // If not valid JSON, wrap in an object
                  value = { value: value };
                }
                break;
            }
            
            entry[mapping.databaseField] = value;
          }
        });

        return entry;
      });

      // Simulate import progress
      const batchSize = 10;
      let imported = 0;
      const results = { success: 0, failed: 0, errors: [] as string[] };

      for (let i = 0; i < mappedData.length; i += batchSize) {
        const batch = mappedData.slice(i, i + batchSize);
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Simulate some successes and failures
        batch.forEach((entry, index) => {
          if (Math.random() > 0.1) { // 90% success rate
            results.success++;
          } else {
            results.failed++;
            results.errors.push(`Row ${i + index + 2}: Validation error`);
          }
        });

        imported += batch.length;
        setImportProgress((imported / mappedData.length) * 100);
      }

      setImportResults(results);
      setStep('complete');
      
      if (results.success > 0) {
        toast.success(`Successfully imported ${results.success} records`);
        onImportComplete(results);
      }
      
      if (results.failed > 0) {
        toast.error(`${results.failed} records failed to import`);
      }

    } catch (error) {
      toast.error('Import failed. Please try again.');
      console.error('Import error:', error);
    }
  };

  const resetModal = () => {
    setFile(null);
    setStep('upload');
    setPreview(null);
    setColumnMappings([]);
    setImportProgress(0);
    setImportResults(null);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Import Test Data
          </DialogTitle>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Upload Excel or CSV File</h3>
                <p className="text-muted-foreground">
                  Select a file containing test data to import
                </p>
              </div>
              <Input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileUpload}
                className="mt-4 max-w-sm mx-auto"
              />
            </div>
            
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Supported formats: Excel (.xlsx, .xls) and CSV files. 
                First row should contain column headers.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {step === 'mapping' && preview && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Map Columns</h3>
              <Badge variant="secondary">{preview.totalRows} rows to import</Badge>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Column Mapping</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {columnMappings.map((mapping, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="flex-1">
                        <Label className="text-sm font-medium">
                          {mapping.excelColumn}
                        </Label>
                      </div>
                      <div className="flex-1">
                        <Select 
                          value={mapping.databaseField} 
                          onValueChange={(value) => handleMappingChange(index, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select database field" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__skip__">Skip this column</SelectItem>
                            {databaseFields.map(field => (
                              <SelectItem key={field.key} value={field.key}>
                                {field.label} {field.required && '*'}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-20">
                        {mapping.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep('upload')}>
                Back
              </Button>
              <Button onClick={handlePreview}>
                Preview Import
              </Button>
            </div>
          </div>
        )}

        {step === 'preview' && preview && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Import Preview</h3>
              <Badge variant="secondary">{preview.totalRows} rows</Badge>
            </div>

            <Card>
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {columnMappings
                        .filter(m => m.databaseField && m.databaseField !== "__skip__")
                        .map((mapping, index) => (
                          <TableHead key={index}>{mapping.databaseField}</TableHead>
                        ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.rows.slice(0, 5).map((row, rowIndex) => (
                      <TableRow key={rowIndex}>
                        {columnMappings
                          .filter(m => m.databaseField && m.databaseField !== "__skip__")
                          .map((mapping, colIndex) => {
                            const originalIndex = columnMappings.indexOf(mapping);
                            return (
                              <TableCell key={colIndex}>
                                {row[originalIndex] || '-'}
                              </TableCell>
                            );
                          })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {preview.rows.length > 5 && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Showing 5 of {preview.totalRows} rows
                  </p>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep('mapping')}>
                Back to Mapping
              </Button>
              <Button onClick={handleImport}>
                Start Import
              </Button>
            </div>
          </div>
        )}

        {step === 'importing' && (
          <div className="space-y-4 text-center">
            <h3 className="text-lg font-medium">Importing Data...</h3>
            <Progress value={importProgress} className="w-full" />
            <p className="text-muted-foreground">
              {importProgress.toFixed(0)}% complete
            </p>
          </div>
        )}

        {step === 'complete' && importResults && (
          <div className="space-y-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-4">
                {importResults.failed === 0 ? (
                  <Check className="h-16 w-16 text-green-500" />
                ) : (
                  <AlertTriangle className="h-16 w-16 text-yellow-500" />
                )}
              </div>
              <h3 className="text-lg font-medium">Import Complete</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {importResults.success}
                  </div>
                  <div className="text-sm text-muted-foreground">Successful</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {importResults.failed}
                  </div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </CardContent>
              </Card>
            </div>

            {importResults.errors.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Import Errors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {importResults.errors.map((error, index) => (
                      <div key={index} className="text-sm text-red-600">
                        {error}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-center">
              <Button onClick={handleClose}>
                Close
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}