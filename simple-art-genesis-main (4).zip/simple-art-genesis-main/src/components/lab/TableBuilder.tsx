import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Eye, Code, Filter, SortAsc, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useDataService } from "@/hooks/useDataService";
import { useEffect } from "react";
import { PlacementSelector } from "@/components/developer/PlacementSelector";
import { SuccessMessageDialog } from "@/components/developer/SuccessMessageDialog";
import type { SuccessMessage } from "@/types/developer";

interface TableColumn {
  id: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'boolean' | 'select' | 'custom';
  sortable: boolean;
  filterable: boolean;
  width?: string;
  format?: string;
  options?: string[];
}

export interface CustomTable {
  id: string;
  name: string;
  description: string;
  columns: TableColumn[];
  dataSource: 'static' | 'api' | 'database';
  apiEndpoint?: string;
  sampleData: Record<string, any>[];
  features: {
    sorting: boolean;
    filtering: boolean;
    search: boolean;
    pagination: boolean;
    export: boolean;
  };
  created_at: string;
}

export function TableBuilder() {
  const { toast } = useToast();
  const dataService = useDataService();
  const [currentTable, setCurrentTable] = useState<CustomTable>({
    id: '',
    name: '',
    description: '',
    columns: [],
    dataSource: 'static',
    sampleData: [],
    features: {
      sorting: true,
      filtering: true,
      search: true,
      pagination: true,
      export: false
    },
    created_at: new Date().toISOString()
  });
  const [previewMode, setPreviewMode] = useState(false);
  const [savedTables, setSavedTables] = useState<CustomTable[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Placement selector state
  const [selectedPlacement, setSelectedPlacement] = useState('dashboard');
  const [moduleId, setModuleId] = useState('');
  const [customRoute, setCustomRoute] = useState('');
  
  // Success dialog state
  const [successMessage, setSuccessMessage] = useState<SuccessMessage | null>(null);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  useEffect(() => {
    loadSavedTables();
  }, []);

  const loadSavedTables = async () => {
    try {
      if (window.electronAPI) {
        // Create table_metadata table if it doesn't exist
        const createMetadataTableSQL = `
          CREATE TABLE IF NOT EXISTS table_metadata (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            columns TEXT NOT NULL,
            data_source TEXT DEFAULT 'static',
            api_endpoint TEXT,
            features TEXT,
            placement TEXT DEFAULT 'main',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `;
        await window.electronAPI.dbRun(createMetadataTableSQL);
        
        // Load tables from database
        const result = await window.electronAPI.dbQuery('SELECT * FROM table_metadata ORDER BY created_at DESC');
        const tables = result.map(row => ({
          id: row.id.toString(),
          name: row.name,
          description: row.description || '',
          columns: JSON.parse(row.columns),
          dataSource: row.data_source || 'static',
          apiEndpoint: row.api_endpoint,
          sampleData: [],
          features: row.features ? JSON.parse(row.features) : {
            sorting: true,
            filtering: true,
            search: true,
            pagination: true,
            export: false
          },
          created_at: row.created_at
        }));
        setSavedTables(tables);
      } else {
        // Fallback to localStorage
        const saved = localStorage.getItem('custom_tables');
        if (saved) {
          setSavedTables(JSON.parse(saved));
        }
      }
    } catch (error) {
      console.error('Failed to load saved tables:', error);
    }
  };

  const columnTypes = [
    { value: 'text', label: 'Text' },
    { value: 'number', label: 'Number' },
    { value: 'date', label: 'Date' },
    { value: 'boolean', label: 'Boolean' },
    { value: 'select', label: 'Select' },
    { value: 'custom', label: 'Custom' }
  ];

  const addColumn = () => {
    const newColumn: TableColumn = {
      id: `col_${Date.now()}`,
      name: 'New Column',
      type: 'text',
      sortable: true,
      filterable: true
    };
    
    setCurrentTable(prev => ({
      ...prev,
      columns: [...prev.columns, newColumn]
    }));
  };

  const updateColumn = (columnId: string, updates: Partial<TableColumn>) => {
    setCurrentTable(prev => ({
      ...prev,
      columns: prev.columns.map(column => 
        column.id === columnId ? { ...column, ...updates } : column
      )
    }));
  };

  const removeColumn = (columnId: string) => {
    setCurrentTable(prev => ({
      ...prev,
      columns: prev.columns.filter(column => column.id !== columnId)
    }));
  };

  const generateSampleData = () => {
    const sampleRows = 5;
    const sampleData = [];
    
    for (let i = 0; i < sampleRows; i++) {
      const row: Record<string, any> = {};
      
      currentTable.columns.forEach(column => {
        switch (column.type) {
          case 'text':
            row[column.id] = `Sample ${column.name} ${i + 1}`;
            break;
          case 'number':
            row[column.id] = Math.floor(Math.random() * 100);
            break;
          case 'date':
            row[column.id] = new Date(Date.now() - Math.random() * 10000000000).toISOString().split('T')[0];
            break;
          case 'boolean':
            row[column.id] = Math.random() > 0.5;
            break;
          case 'select':
            const options = column.options || ['Option 1', 'Option 2', 'Option 3'];
            row[column.id] = options[Math.floor(Math.random() * options.length)];
            break;
          default:
            row[column.id] = `Value ${i + 1}`;
        }
      });
      
      sampleData.push(row);
    }
    
    setCurrentTable(prev => ({ ...prev, sampleData }));
  };

  const saveTable = async () => {
    if (!currentTable.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Table name is required",
        variant: "destructive"
      });
      return;
    }

    if (currentTable.columns.length === 0) {
      toast({
        title: "Validation Error", 
        description: "At least one column is required",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const tableToSave = {
        ...currentTable,
        id: currentTable.id || `table_${Date.now()}`,
        created_at: currentTable.created_at || new Date().toISOString()
      };

      if (window.electronAPI) {
        // Create actual database table
        const columnDefinitions = currentTable.columns.map(col => {
          let definition = `${col.name.replace(/\s+/g, '_')} ${col.type.toUpperCase()}`;
          if (col.type === 'text') definition = `${col.name.replace(/\s+/g, '_')} TEXT`;
          if (col.type === 'number') definition = `${col.name.replace(/\s+/g, '_')} REAL`;
          if (col.type === 'date') definition = `${col.name.replace(/\s+/g, '_')} DATE`;
          if (col.type === 'boolean') definition = `${col.name.replace(/\s+/g, '_')} BOOLEAN`;
          if (col.type === 'select') definition = `${col.name.replace(/\s+/g, '_')} TEXT`;
          return definition;
        }).join(', ');
        
        const tableName = currentTable.name.replace(/\s+/g, '_');
        const createTableSQL = `CREATE TABLE IF NOT EXISTS ${tableName} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ${columnDefinitions},
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`;

        await window.electronAPI.dbRun(createTableSQL);
        
        // Save metadata
        const metadataSQL = `INSERT OR REPLACE INTO table_metadata 
          (name, description, columns, data_source, api_endpoint, features, placement, created_at) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        
        await window.electronAPI.dbRun(metadataSQL, [
          currentTable.name,
          currentTable.description,
          JSON.stringify(currentTable.columns),
          currentTable.dataSource,
          currentTable.apiEndpoint || null,
          JSON.stringify(currentTable.features),
          selectedPlacement,
          new Date().toISOString()
        ]);

        toast({
          title: "Table Created",
          description: `Table "${currentTable.name}" created in database with ${currentTable.columns.length} columns`
        });
      } else {
        // Fallback to localStorage
        const savedTables = JSON.parse(localStorage.getItem('custom_tables') || '[]');
        const existing = savedTables.find(t => t.id === tableToSave.id);
        
        let updatedTables;
        if (existing) {
          updatedTables = savedTables.map(t => t.id === tableToSave.id ? tableToSave : t);
        } else {
          updatedTables = [...savedTables, tableToSave];
        }
        
        localStorage.setItem('custom_tables', JSON.stringify(updatedTables));
        setSavedTables(updatedTables);
        
        toast({
          title: "Table Saved",
          description: `"${currentTable.name}" saved to local storage`
        });
      }
      
      setCurrentTable(tableToSave);
      await loadSavedTables();
    } catch (error: any) {
      toast({
        title: "Save Failed",
        description: error.message || "Failed to save table",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadTable = (table: CustomTable) => {
    setCurrentTable(table);
    setPreviewMode(false);
  };

  const renderTableCell = (value: any, column: TableColumn) => {
    if (value === null || value === undefined) return '-';
    
    switch (column.type) {
      case 'boolean':
        return (
          <Badge variant={value ? 'default' : 'secondary'}>
            {value ? 'Yes' : 'No'}
          </Badge>
        );
      case 'date':
        return new Date(value).toLocaleDateString();
      case 'number':
        return typeof value === 'number' ? value.toLocaleString() : value;
      default:
        return String(value);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Table Builder</h3>
          <p className="text-sm text-muted-foreground">Create dynamic data tables and views</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setPreviewMode(!previewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Edit' : 'Preview'}
          </Button>
          <Button onClick={saveTable} disabled={isLoading}>
            {isLoading ? 'Saving...' : 'Save Table'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList>
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="tables">Saved Tables ({savedTables.length})</TabsTrigger>
          <TabsTrigger value="code">Generated Code</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-4">
          {!previewMode ? (
            <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Table Settings */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Table Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="table-name">Table Name</Label>
                      <Input
                        id="table-name"
                        value={currentTable.name}
                        onChange={(e) => setCurrentTable(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter table name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="table-description">Description</Label>
                      <Input
                        id="table-description"
                        value={currentTable.description}
                        onChange={(e) => setCurrentTable(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Table description"
                      />
                    </div>
                    <div>
                      <Label>Data Source</Label>
                      <Select
                        value={currentTable.dataSource}
                        onValueChange={(value) => setCurrentTable(prev => ({ ...prev, dataSource: value as CustomTable['dataSource'] }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="static">Static Data</SelectItem>
                          <SelectItem value="api">API Endpoint</SelectItem>
                          <SelectItem value="database">Database Query</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {currentTable.dataSource === 'api' && (
                      <div>
                        <Label htmlFor="api-endpoint">API Endpoint</Label>
                        <Input
                          id="api-endpoint"
                          value={currentTable.apiEndpoint || ''}
                          onChange={(e) => setCurrentTable(prev => ({ ...prev, apiEndpoint: e.target.value }))}
                          placeholder="https://api.example.com/data"
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Features</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {Object.entries(currentTable.features).map(([feature, enabled]) => (
                      <div key={feature} className="flex items-center justify-between">
                        <Label className="capitalize">{feature.replace(/([A-Z])/g, ' $1')}</Label>
                        <Switch
                          checked={enabled}
                          onCheckedChange={(checked) => 
                            setCurrentTable(prev => ({
                              ...prev,
                              features: { ...prev.features, [feature]: checked }
                            }))
                          }
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Column Configuration */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-base">Columns</CardTitle>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={generateSampleData}>
                      Generate Sample Data
                    </Button>
                    <Button size="sm" onClick={addColumn}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Column
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 max-h-96 overflow-y-auto">
                  {currentTable.columns.map((column, index) => (
                    <div key={column.id} className="p-3 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline">Column {index + 1}</Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeColumn(column.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>Name</Label>
                          <Input
                            value={column.name}
                            onChange={(e) => updateColumn(column.id, { name: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label>Type</Label>
                          <Select
                            value={column.type}
                            onValueChange={(value) => updateColumn(column.id, { type: value as TableColumn['type'] })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {columnTypes.map(type => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={column.sortable}
                            onCheckedChange={(checked) => updateColumn(column.id, { sortable: checked })}
                          />
                          <Label>Sortable</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={column.filterable}
                            onCheckedChange={(checked) => updateColumn(column.id, { filterable: checked })}
                          />
                          <Label>Filterable</Label>
                        </div>
                      </div>

                      {column.type === 'select' && (
                        <div>
                          <Label>Options (comma-separated)</Label>
                          <Input
                            value={column.options?.join(', ') || ''}
                            onChange={(e) => updateColumn(column.id, { 
                              options: e.target.value.split(',').map(o => o.trim()).filter(o => o)
                            })}
                            placeholder="Option 1, Option 2, Option 3"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
            
            {/* Placement Selector */}
            <PlacementSelector
              selectedPlacement={selectedPlacement}
              onPlacementChange={setSelectedPlacement}
              moduleId={moduleId}
              onModuleIdChange={setModuleId}
              customRoute={customRoute}
              onCustomRouteChange={setCustomRoute}
            />
            </>
          ) : (
            /* Preview Mode */
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{currentTable.name || 'Untitled Table'}</CardTitle>
                    {currentTable.description && (
                      <p className="text-sm text-muted-foreground mt-1">{currentTable.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {currentTable.features.search && (
                      <div className="flex items-center gap-2">
                        <Search className="w-4 h-4" />
                        <Input placeholder="Search..." className="w-48" />
                      </div>
                    )}
                    {currentTable.features.export && (
                      <Button variant="outline" size="sm">
                        Export
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {currentTable.columns.length > 0 && (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {currentTable.columns.map(column => (
                          <TableHead key={column.id} className="relative">
                            <div className="flex items-center gap-2">
                              {column.name}
                              {column.sortable && <SortAsc className="w-3 h-3" />}
                              {column.filterable && <Filter className="w-3 h-3" />}
                            </div>
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentTable.sampleData.length > 0 ? (
                        currentTable.sampleData.map((row, index) => (
                          <TableRow key={index}>
                            {currentTable.columns.map(column => (
                              <TableCell key={column.id}>
                                {renderTableCell(row[column.id], column)}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={currentTable.columns.length} className="text-center text-muted-foreground">
                            No data available. Generate sample data or configure data source.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
                
                {currentTable.features.pagination && currentTable.sampleData.length > 0 && (
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-sm text-muted-foreground">
                      Showing 1 to {currentTable.sampleData.length} of {currentTable.sampleData.length} entries
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" disabled>Previous</Button>
                      <Button variant="outline" size="sm" disabled>Next</Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="tables">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedTables.map(table => (
              <Card key={table.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{table.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {table.columns.length} columns • {new Date(table.created_at).toLocaleDateString()}
                  </p>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">{table.description}</p>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => loadTable(table)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Deploy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                <CardTitle>Generated React Component</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`// Generated table component for: ${currentTable.name}
import { useState, useMemo } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function ${currentTable.name.replace(/\s+/g, '')}Table() {
  const [data, setData] = useState([
${currentTable.sampleData.map(row => `    ${JSON.stringify(row)}`).join(',\n')}
  ]);
${currentTable.features.search ? '  const [search, setSearch] = useState("");' : ''}

${currentTable.features.search ? `  const filteredData = useMemo(() => {
    if (!search) return data;
    return data.filter(row => 
      Object.values(row).some(value => 
        String(value).toLowerCase().includes(search.toLowerCase())
      )
    );
  }, [data, search]);` : ''}

  return (
    <div className="space-y-4">
${currentTable.features.search ? `      <div className="flex justify-between items-center">
        <Input
          placeholder="Search..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
      </div>` : ''}
      
      <Table>
        <TableHeader>
          <TableRow>
${currentTable.columns.map(col => `            <TableHead>${col.name}</TableHead>`).join('\n')}
          </TableRow>
        </TableHeader>
        <TableBody>
          {${currentTable.features.search ? 'filteredData' : 'data'}.map((row, index) => (
            <TableRow key={index}>
${currentTable.columns.map(col => `              <TableCell>{row.${col.id}}</TableCell>`).join('\n')}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <SuccessMessageDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
        message={successMessage}
      />
    </div>
  );
}