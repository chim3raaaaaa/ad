import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarIcon, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useTestResults } from "@/contexts/TestResultContext";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface TestRequestFormProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  memoId?: string;
  initialData?: any;
}

export function TestRequestForm({ isOpen, onOpenChange, memoId, initialData }: TestRequestFormProps) {
  const { toast } = useToast();
  const { addTestResult } = useTestResults();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dueDate, setDueDate] = useState<Date>();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'compressive_strength',
    priority: 'medium',
    client_name: '',
    sample_description: '',
    test_method: '',
    expected_results: '',
    requested_by: 'Current User',
    assigned_to: ''
  });

  // Initialize form with memo data if provided
  useEffect(() => {
    if (initialData && isOpen) {
      setFormData(prev => ({
        ...prev,
        title: initialData.reference || `Test Request - ${Date.now()}`,
        description: `Test request for ${initialData.extractedData?.testType || 'laboratory analysis'}`,
        client_name: initialData.extractedData?.clientName || initialData.extractedData?.site || '',
        sample_description: initialData.extractedData?.product || 'Concrete samples',
        test_method: initialData.extractedData?.testType || 'Compressive Strength',
        type: initialData.extractedData?.testType?.toLowerCase().replace(/\s+/g, '_') || 'compressive_strength'
      }));
    }
  }, [initialData, isOpen]);

  const handleSubmit = async () => {
    if (!formData.title || !formData.description) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in title and description.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await addTestResult({
        title: formData.title,
        description: formData.description,
        type: formData.type,
        priority: formData.priority as 'low' | 'medium' | 'high' | 'urgent',
        status: 'pending',
        requested_by: formData.requested_by,
        assigned_to: formData.assigned_to,
        due_date: dueDate?.toISOString(),
        test_data: JSON.stringify({
          memo_id: memoId,
          client_name: formData.client_name,
          sample_description: formData.sample_description,
          test_method: formData.test_method,
          expected_results: formData.expected_results
        })
      });

      toast({
        title: "Test Request Created",
        description: `Test request "${formData.title}" has been created successfully.`
      });

      // Reset form
      setFormData({
        title: '',
        description: '',
        type: 'compressive_strength',
        priority: 'medium',
        client_name: '',
        sample_description: '',
        test_method: '',
        expected_results: '',
        requested_by: 'Current User',
        assigned_to: ''
      });
      setDueDate(undefined);
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create test request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Test Request</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Request Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="Test Request Title"
                />
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Detailed description of the test request"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Test Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="compressive_strength">Compressive Strength</SelectItem>
                      <SelectItem value="density_test">Density Test</SelectItem>
                      <SelectItem value="water_absorption">Water Absorption</SelectItem>
                      <SelectItem value="flexural_strength">Flexural Strength</SelectItem>
                      <SelectItem value="durability">Durability Test</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={formData.priority} onValueChange={(value) => setFormData({...formData, priority: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dueDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dueDate ? format(dueDate, "PPP") : <span>Pick a due date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dueDate}
                      onSelect={setDueDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
          </Card>

          {/* Sample Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sample Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="client_name">Client Name</Label>
                <Input
                  id="client_name"
                  value={formData.client_name}
                  onChange={(e) => setFormData({...formData, client_name: e.target.value})}
                  placeholder="Client or organization name"
                />
              </div>

              <div>
                <Label htmlFor="sample_description">Sample Description</Label>
                <Textarea
                  id="sample_description"
                  value={formData.sample_description}
                  onChange={(e) => setFormData({...formData, sample_description: e.target.value})}
                  placeholder="Description of samples to be tested"
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="test_method">Test Method</Label>
                <Input
                  id="test_method"
                  value={formData.test_method}
                  onChange={(e) => setFormData({...formData, test_method: e.target.value})}
                  placeholder="Specific test method or standard (e.g., ASTM C39)"
                />
              </div>

              <div>
                <Label htmlFor="expected_results">Expected Results</Label>
                <Textarea
                  id="expected_results"
                  value={formData.expected_results}
                  onChange={(e) => setFormData({...formData, expected_results: e.target.value})}
                  placeholder="Expected test results or acceptance criteria"
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          {/* Assignment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Assignment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="requested_by">Requested By</Label>
                <Input
                  id="requested_by"
                  value={formData.requested_by}
                  onChange={(e) => setFormData({...formData, requested_by: e.target.value})}
                  placeholder="Person requesting the test"
                />
              </div>

              <div>
                <Label htmlFor="assigned_to">Assigned To</Label>
                <Input
                  id="assigned_to"
                  value={formData.assigned_to}
                  onChange={(e) => setFormData({...formData, assigned_to: e.target.value})}
                  placeholder="Lab technician or engineer (optional)"
                />
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Request'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}