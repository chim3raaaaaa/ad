import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Upload, FileText, Settings, TestTube } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAggregatesIntegration } from "@/hooks/useAggregatesIntegration";
import { MemoInfoPanel } from "./MemoInfoPanel";
import { useMemoTestSystem } from "@/hooks/useMemoTestSystem";
import { CategoryToggle, AGGREGATE_CATEGORIES } from "@/components/aggregates/CategoryToggle";
import { GradingConformityChecker } from "@/components/aggregates/GradingConformityChecker";


// Enhanced schema for Aggregates test results
const enhancedAggregatesSchema = z.object({
  category: z.string().min(1, "Aggregate category is required"),
  memo_id: z.string().min(1, "Memo reference is required"),
  date_sampling: z.string().min(1, "Date of sampling is required"),
  date_testing: z.string().min(1, "Date of testing is required"), 
  date_production: z.string().min(1, "Date of production is required"),
  sampling_location: z.string().min(1, "Sampling location is required"),
  climatic_condition: z.string().min(1, "Climatic condition is required"),
  sampled_by: z.string().min(1, "Sampled by is required"),
  prepared_by: z.string().min(1, "Prepared by is required"),
  officer_in_charge: z.string().min(1, "Officer in charge is required"),
  aggregate_type: z.string().min(1, "Aggregate type is required"),
  machine_no: z.string().min(1, "Machine number is required"),
  remarks: z.string().optional(),
  calculation_sheet: z.any().optional(),
  // Dynamic sieve fields based on category
  sieve_20mm: z.number().min(0).max(100).optional(),
  sieve_14mm: z.number().min(0).max(100).optional(),
  sieve_10mm: z.number().min(0).max(100).optional(),
  sieve_5mm: z.number().min(0).max(100).optional(),
  sieve_2_36mm: z.number().min(0).max(100).optional(),
  sieve_1_18mm: z.number().min(0).max(100).optional(),
  sieve_600um: z.number().min(0).max(100).optional(),
  sieve_300um: z.number().min(0).max(100).optional(),
  sieve_150um: z.number().min(0).max(100).optional(),
  sieve_075um: z.number().min(0).max(100).optional(),
  // Physical properties
  moisture_content: z.number().min(0).max(100),
  fineness_modulus: z.number().min(0).optional(),
  sand_equivalent: z.number().min(0).optional(),
  blue_methylene_value: z.number().min(0).optional(),
  loose_bulk_density: z.number().min(0).optional(),
  compacted_bulk_density: z.number().min(0).optional(),
  surface_saturated_dry: z.number().min(0).optional(),
  apparent_density: z.number().min(0).optional(),
  oven_dried_density: z.number().min(0).optional(),
  water_absorption: z.number().min(0).optional(),
  organic_impurities: z.string().optional(),
  grading_conformity: z.boolean().optional(),
  cleanliness_conformity: z.boolean().optional(),
  observations: z.string().optional(),
  notes: z.string().optional()
});

type EnhancedAggregatesFormData = z.infer<typeof enhancedAggregatesSchema>;

interface EnhancedAggregatesModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: EnhancedAggregatesFormData) => Promise<void>;
  isLoading: boolean;
}

export function EnhancedAggregatesModal({ 
  isOpen, 
  onOpenChange, 
  onSubmit, 
  isLoading 
}: EnhancedAggregatesModalProps) {
  const { toast } = useToast();
  const { memoOptions, aggregateTypes, loading, dropdownOptions } = useAggregatesIntegration();
  const { getMemoByRef, submitTestResult } = useMemoTestSystem();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedMemoId, setSelectedMemoId] = useState<string>("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isGradingConform, setIsGradingConform] = useState<boolean>(false);

  const form = useForm<EnhancedAggregatesFormData>({
    resolver: zodResolver(enhancedAggregatesSchema),
    defaultValues: {
      category: '',
      memo_id: '',
      date_sampling: '',
      date_testing: '',
      date_production: '',
      sampling_location: '',
      climatic_condition: '',
      sampled_by: '',
      prepared_by: '',
      officer_in_charge: '',
      aggregate_type: '',
      machine_no: '',
      remarks: '',
      sieve_20mm: 0,
      sieve_14mm: 0,
      sieve_10mm: 0,
      sieve_5mm: 0,
      sieve_2_36mm: 0,
      sieve_1_18mm: 0,
      sieve_600um: 0,
      sieve_300um: 0,
      sieve_150um: 0,
      sieve_075um: 0,
      moisture_content: 0,
      fineness_modulus: 0,
      sand_equivalent: 0,
      blue_methylene_value: 0,
      loose_bulk_density: 0,
      compacted_bulk_density: 0,
      surface_saturated_dry: 0,
      apparent_density: 0,
      oven_dried_density: 0,
      water_absorption: 0,
      organic_impurities: '',
      grading_conformity: false,
      cleanliness_conformity: false,
      observations: '',
      notes: ''
    }
  });
  
  // Watch for form changes to get current sieve values
  const watchedValues = form.watch();

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      form.reset();
      setSelectedCategory('');
      setSelectedMemoId('');
      setUploadedFile(null);
      setIsGradingConform(false);
    }
  }, [isOpen]);

  // Update grading conformity in form when it changes
  useEffect(() => {
    form.setValue('grading_conformity', isGradingConform);
  }, [isGradingConform, form]);

  // Get sieve sizes for selected category
  const selectedCategoryData = AGGREGATE_CATEGORIES.find(cat => cat.id === selectedCategory);
  const currentSieveSizes = selectedCategoryData?.sieveSizes || [];

  const handleMemoChange = async (memoId: string) => {
    setSelectedMemoId(memoId);
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(`
          SELECT mp.machine, mp.details 
          FROM memo_productions mp 
          WHERE mp.memo_id = ? 
          LIMIT 1
        `, [memoId]);
        
        if (result.success && result.data.length > 0) {
          const machineNumber = result.data[0].machine || "N/A";
          form.setValue('machine_no', machineNumber);
        }
      }
    } catch (error) {
      console.error('Failed to load machine number:', error);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv',
        'application/pdf'
      ];
      
      if (allowedTypes.includes(file.type)) {
        setUploadedFile(file);
        form.setValue('calculation_sheet', file);
        toast({
          title: "File uploaded",
          description: `${file.name} attached successfully`
        });
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload .xlsx, .xls, .csv, or .pdf files only",
          variant: "destructive"
        });
      }
    }
  };

  const getSieveFieldsForAggregateType = (aggregateType: string) => {
    // Return all sieve fields for now - simplified approach
    return ['sieve_10mm', 'sieve_5mm', 'sieve_2_36mm', 'sieve_1_18mm', 'sieve_600um', 'sieve_300um', 'sieve_150um', 'sieve_075um'];
  };

  const handleFormSubmit = async (data: EnhancedAggregatesFormData) => {
    try {
      // Save using the proper aggregates service instead of duplicate database
      await onSubmit(data);
      
      if (!isLoading) {
        form.reset();
        setSelectedCategory("");
        setSelectedMemoId("");
        setUploadedFile(null);
      }
    } catch (error) {
      console.error('Failed to save test result:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save test result",
        variant: "destructive"
      });
    }
  };

  const activeSieveFields = currentSieveSizes.map(size => `sieve_${size.replace('.', '_').replace('μ', 'u')}`);;

  const getSieveLabel = (fieldName: string) => {
    const labels: Record<string, string> = {
      'sieve_20mm': '20mm',
      'sieve_14mm': '14mm',
      'sieve_10mm': '10mm',
      'sieve_5mm': '5mm',
      'sieve_2_36mm': '2.36mm',
      'sieve_1_18mm': '1.18mm',
      'sieve_600um': '600μm',
      'sieve_300um': '300μm',
      'sieve_150um': '150μm',
      'sieve_075um': '75μm'
    };
    return labels[fieldName] || fieldName;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <TestTube className="h-5 w-5 mr-2" />
            Enter Aggregates Test Results
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Memo Information Panel */}
          <div className="lg:col-span-1">
            <MemoInfoPanel memoId={selectedMemoId} />
          </div>
          
          {/* Form Section */}
          <div className="lg:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
                
                {/* Basic Information Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Basic Information</CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="memo_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Memo Reference *</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          field.onChange(value);
                          handleMemoChange(value);
                        }} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select memo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {memoOptions.map((memo) => (
                            <SelectItem key={memo.id} value={memo.id}>
                              <div className="flex flex-col gap-1">
                                <div className="font-medium text-foreground">
                                  {memo.title}
                                </div>
                                <div className="text-xs text-muted-foreground font-mono">
                                  REF: {memo.id} | Plant: {memo.plant_id} | Machine: {memo.machine_no} | Type: {memo.aggregate_type}
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="aggregate_type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Aggregate Type *</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select aggregate type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {aggregateTypes.map((agg) => (
                            <SelectItem key={agg.id} value={agg.id}>
                              {agg.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="machine_no"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Machine No. *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select machine" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.machines?.map((machine) => (
                            <SelectItem key={machine.id} value={machine.code}>
                              {machine.name} ({machine.code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div>
                  <FormLabel>Attach Calculation Sheet (Optional)</FormLabel>
                  <div className="flex items-center space-x-2 mt-1">
                    <Input
                      type="file"
                      accept=".xlsx,.xls,.csv,.pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="calculation-sheet"
                    />
                    <label htmlFor="calculation-sheet" className="cursor-pointer">
                      <Button type="button" variant="outline" size="sm" asChild>
                        <span>
                          <Upload className="h-4 w-4 mr-2" />
                          {uploadedFile ? uploadedFile.name : "Choose File"}
                        </span>
                      </Button>
                    </label>
                    {uploadedFile && (
                      <FileText className="h-4 w-4 text-green-600" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Category Toggle */}
            <CategoryToggle
              selectedCategory={selectedCategory}
              onCategoryChange={(category) => {
                setSelectedCategory(category);
                form.setValue('category', category);
              }}
            />

            {/* Dynamic Sieve Analysis Section */}
            {selectedCategory && (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      Sieve Analysis (%) - {selectedCategoryData?.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Sieve Size</TableHead>
                          <TableHead>% Passing</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentSieveSizes.map((sieveSize) => {
                          const fieldName = `sieve_${sieveSize.replace('.', '_').replace('μ', 'u')}` as keyof EnhancedAggregatesFormData;
                          return (
                            <TableRow key={sieveSize}>
                              <TableCell className="font-medium">{sieveSize}</TableCell>
                              <TableCell>
                                <FormField
                                  control={form.control}
                                  name={fieldName}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormControl>
                                        <Input 
                                          type="number" 
                                          step="0.1"
                                          min="0"
                                          max="100"
                                          {...field}
                                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                          className="w-20"
                                        />
                                      </FormControl>
                                    </FormItem>
                                  )}
                                />
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                {/* Grading Conformity Checker */}
                <GradingConformityChecker
                  category={selectedCategory}
                  gradingData={{
                    sieve_20mm: watchedValues.sieve_20mm || 0,
                    sieve_14mm: watchedValues.sieve_14mm || 0,
                    sieve_10mm: watchedValues.sieve_10mm || 0,
                    sieve_5mm: watchedValues.sieve_5mm || 0,
                    sieve_2_36mm: watchedValues.sieve_2_36mm || 0,
                    sieve_1_18mm: watchedValues.sieve_1_18mm || 0,
                    sieve_600um: watchedValues.sieve_600um || 0,
                    sieve_300um: watchedValues.sieve_300um || 0,
                    sieve_150um: watchedValues.sieve_150um || 0,
                    sieve_075um: watchedValues.sieve_075um || 0,
                  }}
                  onConformityChange={setIsGradingConform}
                />
              </>
            )}

            {/* Sampling Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sampling Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date_sampling"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Sampling *</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="date_testing"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Testing *</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="date_production"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Production *</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sampling_location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sampling Location *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select location" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.samplingLocations?.map((location) => (
                            <SelectItem key={location.id} value={location.name}>
                              {location.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="climatic_condition"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Climatic Condition *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select condition" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.climaticConditions?.map((condition) => (
                            <SelectItem key={condition.id} value={condition.name}>
                              {condition.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sampled_by"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sampled By *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select officer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.officers?.map((officer) => (
                            <SelectItem key={officer.id} value={officer.name}>
                              {officer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="prepared_by"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prepared By *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select officer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.officers?.map((officer) => (
                            <SelectItem key={officer.id} value={officer.name}>
                              {officer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="officer_in_charge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Officer in Charge *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select officer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownOptions?.officers?.map((officer) => (
                            <SelectItem key={officer.id} value={officer.name}>
                              {officer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
            
            {/* Physical Properties */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Physical Properties</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="moisture_content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Moisture Content (%) *</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sand_equivalent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sand Equivalent (Tarred)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="blue_methylene_value"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blue Methylene Value (g/kg)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="loose_bulk_density"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Loose Bulk Density</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="compacted_bulk_density"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Compacted Bulk Density</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="water_absorption"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Water Absorption (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Observations & Notes */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Observations & Notes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="organic_impurities"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Organic Impurities</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={2} placeholder="Describe organic impurities..." />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="observations"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Observations</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={2} placeholder="Test observations..." />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="remarks"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Remarks</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={2} placeholder="Additional remarks..." />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea {...field} rows={3} placeholder="Additional notes..." />
                  </FormControl>
                </FormItem>
              )}
            />

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => onOpenChange(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save Results"}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}