import React, { useState, useCallback } from 'react';
import { Upload, FileText, Check, X, Eye, Download, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';

interface UploadedFile {
  id: string;
  filename: string;
  fileSize: number;
  uploadStatus: 'pending' | 'uploading' | 'completed' | 'error';
  extractionStatus: 'pending' | 'processing' | 'completed' | 'error';
  uploadProgress: number;
  createdAt: string;
}

export function PDFUploadManager() {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const { toast } = useToast();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  }, []);

  const handleFiles = async (files: File[]) => {
    const pdfFiles = files.filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length !== files.length) {
      toast({
        title: "Invalid files",
        description: "Only PDF files are allowed",
        variant: "destructive"
      });
    }

    for (const file of pdfFiles) {
      const fileId = `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const newFile: UploadedFile = {
        id: fileId,
        filename: file.name,
        fileSize: file.size,
        uploadStatus: 'uploading',
        extractionStatus: 'pending',
        uploadProgress: 0,
        createdAt: new Date().toISOString()
      };

      setUploadedFiles(prev => [...prev, newFile]);

      try {
        // Check if running in Electron
        if (window.electronAPI) {
          // Use Electron file system
          const fileData = await file.arrayBuffer();
          const result = await window.electronAPI.saveFile(
            Buffer.from(fileData), 
            `uploads/${file.name}`
          );
          
          if (result.success) {
            // Simulate progress
            for (let progress = 0; progress <= 100; progress += 10) {
              await new Promise(resolve => setTimeout(resolve, 100));
              setUploadedFiles(prev => prev.map(f => 
                f.id === fileId ? { ...f, uploadProgress: progress } : f
              ));
            }

            // Update status
            setUploadedFiles(prev => prev.map(f => 
              f.id === fileId 
                ? { ...f, uploadStatus: 'completed', extractionStatus: 'processing' }
                : f
            ));

            // Simulate extraction processing
            setTimeout(() => {
              setUploadedFiles(prev => prev.map(f => 
                f.id === fileId ? { ...f, extractionStatus: 'completed' } : f
              ));
              
              toast({
                title: "File uploaded successfully",
                description: `${file.name} has been processed`
              });
            }, 2000);
          } else {
            throw new Error(result.error || 'Upload failed');
          }
        } else {
          // Browser fallback - store in memory/localStorage
          const reader = new FileReader();
          reader.onload = async (e) => {
            try {
              const fileData = e.target?.result as string;
              
              // Store in localStorage for demo purposes
              const storageKey = `pdf_${fileId}`;
              localStorage.setItem(storageKey, fileData);
              
              // Simulate progress
              for (let progress = 0; progress <= 100; progress += 20) {
                await new Promise(resolve => setTimeout(resolve, 200));
                setUploadedFiles(prev => prev.map(f => 
                  f.id === fileId ? { ...f, uploadProgress: progress } : f
                ));
              }

              setUploadedFiles(prev => prev.map(f => 
                f.id === fileId 
                  ? { ...f, uploadStatus: 'completed', extractionStatus: 'completed' }
                  : f
              ));

              toast({
                title: "File uploaded successfully",
                description: `${file.name} processed (browser mode)`
              });
            } catch (error) {
              setUploadedFiles(prev => prev.map(f => 
                f.id === fileId ? { ...f, uploadStatus: 'error' } : f
              ));
              toast({
                title: "Upload failed",
                description: error instanceof Error ? error.message : "Unknown error",
                variant: "destructive"
              });
            }
          };
          reader.readAsDataURL(file);
        }
      } catch (error) {
        setUploadedFiles(prev => prev.map(f => 
          f.id === fileId ? { ...f, uploadStatus: 'error' } : f
        ));
        toast({
          title: "Upload failed",
          description: error instanceof Error ? error.message : "Unknown error",
          variant: "destructive"
        });
      }
    }
  };

  const deleteFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
    
    // Clean up localStorage
    const storageKey = `pdf_${fileId}`;
    localStorage.removeItem(storageKey);
    
    toast({
      title: "File deleted",
      description: "File has been removed"
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusBadge = (uploadStatus: string, extractionStatus: string) => {
    if (uploadStatus === 'error') {
      return <Badge variant="destructive">Failed</Badge>;
    }
    if (uploadStatus === 'uploading') {
      return <Badge variant="secondary">Uploading</Badge>;
    }
    if (extractionStatus === 'processing') {
      return <Badge variant="secondary">Processing</Badge>;
    }
    if (extractionStatus === 'completed') {
      return <Badge variant="default">Ready</Badge>;
    }
    return <Badge variant="secondary">Pending</Badge>;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            PDF Document Upload
          </CardTitle>
          <CardDescription>
            Upload PDF documents for data extraction and processing
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:border-primary/50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Upload PDF Files</h3>
            <p className="text-muted-foreground mb-4">
              Drag and drop PDF files here, or click to select
            </p>
            <input
              type="file"
              multiple
              accept=".pdf"
              onChange={handleFileInput}
              className="hidden"
              id="pdf-upload"
            />
            <Button asChild>
              <label htmlFor="pdf-upload" className="cursor-pointer">
                Select PDF Files
              </label>
            </Button>
          </div>

          {uploadedFiles.length > 0 && (
            <div className="mt-6">
              <h4 className="font-semibold mb-4">Uploaded Files</h4>
              <div className="space-y-3">
                {uploadedFiles.map((file) => (
                  <div key={file.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3 flex-1">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{file.filename}</p>
                          <p className="text-sm text-muted-foreground">
                            {formatFileSize(file.fileSize)} • {new Date(file.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(file.uploadStatus, file.extractionStatus)}
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => deleteFile(file.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    {file.uploadStatus === 'uploading' && (
                      <div className="mt-2">
                        <Progress value={file.uploadProgress} className="h-2" />
                        <p className="text-sm text-muted-foreground mt-1">
                          Uploading... {file.uploadProgress}%
                        </p>
                      </div>
                    )}
                    
                    {file.extractionStatus === 'processing' && file.uploadStatus === 'completed' && (
                      <div className="mt-2">
                        <div className="flex items-center gap-2">
                          <div className="h-2 bg-secondary rounded-full flex-1 overflow-hidden">
                            <div className="h-full bg-primary rounded-full animate-pulse w-3/4"></div>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Processing document...
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}