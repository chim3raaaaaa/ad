import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, User, FileText, Settings, Package } from "lucide-react";
import { format } from "date-fns";

interface MemoInfo {
  id: string;
  title: string;
  content: any;
  created_at: string;
  author_id: string;
  production_data?: any;
}

interface MemoInfoPanelProps {
  memoId: string | null;
}

export function MemoInfoPanel({ memoId }: MemoInfoPanelProps) {
  const [memoInfo, setMemoInfo] = useState<MemoInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (memoId) {
      loadMemoInfo(memoId);
    } else {
      setMemoInfo(null);
    }
  }, [memoId]);

  const loadMemoInfo = async (id: string) => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(`
          SELECT 
            m.id, 
            m.title, 
            m.content, 
            m.created_at, 
            m.author_id,
            mp.details as production_data
          FROM memos m 
          LEFT JOIN memo_productions mp ON m.id = mp.memo_id 
          WHERE m.id = ? 
          LIMIT 1
        `, [id]);
        
        if (result.success && result.data.length > 0) {
          const memo = result.data[0];
          setMemoInfo({
            ...memo,
            content: typeof memo.content === 'string' ? JSON.parse(memo.content) : memo.content,
            production_data: memo.production_data ? 
              (typeof memo.production_data === 'string' ? JSON.parse(memo.production_data) : memo.production_data) 
              : null
          });
        }
      }
    } catch (error) {
      console.error('Failed to load memo info:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!memoId) {
    return (
      <Card className="bg-muted/50">
        <CardContent className="p-6 text-center text-muted-foreground">
          <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Select a memo to view details</p>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-muted rounded w-3/4 mx-auto"></div>
            <div className="h-4 bg-muted rounded w-1/2 mx-auto"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!memoInfo) {
    return (
      <Card className="border-destructive/50">
        <CardContent className="p-6 text-center text-destructive">
          <FileText className="h-8 w-8 mx-auto mb-2" />
          <p>Memo information not found</p>
        </CardContent>
      </Card>
    );
  }

  const content = memoInfo.content || {};
  const productionData = memoInfo.production_data || {};
  const productions = content.productions || [];

  // Extract production and sampling dates from the first production entry
  const firstProduction = productions[0];
  const productionDate = firstProduction?.productionDate;
  const samplingDate = firstProduction?.testDate;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <FileText className="h-5 w-5 mr-2" />
          Memo Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Basic Memo Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">Reference:</span>
              <Badge variant="secondary" className="ml-2 text-sm font-mono">{memoInfo.id || memoInfo.title}</Badge>
            </div>
            
            <div className="flex items-center text-sm">
              <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">Memo Date:</span>
              <span className="ml-2">
                {format(new Date(memoInfo.created_at), 'dd/MM/yyyy')}
              </span>
            </div>
            
            <div className="flex items-center text-sm">
              <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">Plant/Lab Site:</span>
              <span className="ml-2">{content.labSite || 'N/A'}</span>
            </div>
          </div>
          
          <div className="space-y-2">
            {productionDate && (
              <div className="flex items-center text-sm">
                <Package className="h-4 w-4 mr-2 text-muted-foreground" />
                <span className="font-medium">Production Date:</span>
                <span className="ml-2">
                  {format(new Date(productionDate), 'dd/MM/yyyy')}
                </span>
              </div>
            )}
            
            {samplingDate && (
              <div className="flex items-center text-sm">
                <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                <span className="font-medium">Sampling Date:</span>
                <span className="ml-2">
                  {format(new Date(samplingDate), 'dd/MM/yyyy')}
                </span>
              </div>
            )}
            
            <div className="flex items-center text-sm">
              <User className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="font-medium">Officer in Charge:</span>
              <span className="ml-2">{content.officerInCharge || memoInfo.author_id || 'N/A'}</span>
            </div>
          </div>
        </div>

        {/* Production Details */}
        {firstProduction && (
          <div className="space-y-2 pt-2 border-t">
            <h4 className="font-medium text-sm flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Production Details
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
              {firstProduction.machineNo && (
                <div>
                  <span className="font-medium">Machine No:</span> {firstProduction.machineNo}
                </div>
              )}
              {firstProduction.product && (
                <div>
                  <span className="font-medium">Product:</span> {firstProduction.product}
                </div>
              )}
              {firstProduction.gradeMpa && (
                <div>
                  <span className="font-medium">Grade:</span> {firstProduction.gradeMpa} MPa
                </div>
              )}
              {firstProduction.category && (
                <div>
                  <span className="font-medium">Category:</span> {firstProduction.category}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Test Information */}
        <div className="space-y-2 pt-2 border-t">
          <h4 className="font-medium text-sm">Test Information</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
            {content.typeOfTest && (
              <div>
                <span className="font-medium">Type of Test:</span> {content.typeOfTest}
              </div>
            )}
            {content.testPerformed && (
              <div>
                <span className="font-medium">Test Performed:</span> {content.testPerformed}
              </div>
            )}
            {content.blocksCount && (
              <div>
                <span className="font-medium">Blocks Count:</span> {content.blocksCount}
              </div>
            )}
            {content.lorry && (
              <div>
                <span className="font-medium">Lorry:</span> {content.lorry}
              </div>
            )}
          </div>
        </div>

        {/* Remarks */}
        {(content.remarks || content.testRemarks) && (
          <div className="space-y-2 pt-2 border-t">
            <h4 className="font-medium text-sm">Remarks</h4>
            <div className="text-sm text-muted-foreground space-y-1">
              {content.remarks && (
                <div>
                  <span className="font-medium">General:</span> {content.remarks}
                </div>
              )}
              {content.testRemarks && (
                <div>
                  <span className="font-medium">Test:</span> {content.testRemarks}
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}