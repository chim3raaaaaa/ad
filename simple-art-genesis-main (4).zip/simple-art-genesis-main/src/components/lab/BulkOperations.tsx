import React, { useState } from 'react';
import { CheckSquare, Square, Mail, CheckCircle, X, AlertTriangle, Download } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Textarea } from '../ui/textarea';
import { useToast } from '../../hooks/use-toast';

interface BulkOperationsProps {
  selectedItems: string[];
  onSelectAll: (checked: boolean) => void;
  onSelectItem: (itemId: string, checked: boolean) => void;
  totalItems: number;
  allSelected: boolean;
  onBulkApprove: (itemIds: string[]) => void;
  onBulkEmail: (itemIds: string[], message: string) => void;
  onBulkStatusChange: (itemIds: string[], status: string) => void;
  testRequests?: any[]; // Add testRequests to props for export functionality
}

export function BulkOperations({
  selectedItems,
  onSelectAll,
  onSelectItem,
  totalItems,
  allSelected,
  onBulkApprove,
  onBulkEmail,
  onBulkStatusChange,
  testRequests = [] // Default to empty array
}: BulkOperationsProps) {
  const [emailMessage, setEmailMessage] = useState('');
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false);
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleBulkApprove = () => {
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please select items to approve.",
        variant: "destructive"
      });
      return;
    }

    onBulkApprove(selectedItems);
    toast({
      title: "Bulk Approval Successful",
      description: `${selectedItems.length} test requests have been approved.`,
    });
  };

  const handleBulkEmail = () => {
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please select items to email.",
        variant: "destructive"
      });
      return;
    }

    if (!emailMessage.trim()) {
      toast({
        title: "Email message required",
        description: "Please enter a message for the email.",
        variant: "destructive"
      });
      return;
    }

    onBulkEmail(selectedItems, emailMessage);
    setEmailMessage('');
    setIsEmailDialogOpen(false);
    toast({
      title: "Bulk Email Sent",
      description: `Email notifications sent for ${selectedItems.length} test requests.`,
    });
  };

  const handleStatusChange = (status: string) => {
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please select items to update.",
        variant: "destructive"
      });
      return;
    }

    onBulkStatusChange(selectedItems, status);
    setIsStatusDialogOpen(false);
    toast({
      title: "Status Updated",
      description: `${selectedItems.length} test requests updated to ${status}.`,
    });
  };

  const handleExportSelected = async () => {
    console.log("Export Selected button clicked – implementing export functionality");
    
    try {
      // Create CSV content for selected items
      const csvHeader = "ID,Reference,Status,Type,Date\n";
      const csvContent = selectedItems.map(id => {
        const item = testRequests.find(req => req.id === id.toString());
        return item ? `${item.id},${item.reference || 'N/A'},${item.status || 'pending'},${item.testType || 'N/A'},${item.date || new Date().toISOString().split('T')[0]}` : `${id},N/A,pending,N/A,${new Date().toISOString().split('T')[0]}`;
      }).filter(Boolean).join('\n');
      
      const fullCsv = csvHeader + csvContent;
      const blob = new Blob([fullCsv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `selected-test-requests-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({ 
        title: "Export Complete", 
        description: `Successfully exported ${selectedItems.length} selected items to CSV.` 
      });
    } catch (error) {
      toast({ 
        title: "Export Failed", 
        description: "Failed to export selected items. Please try again.",
        variant: "destructive"
      });
    }
  };

  const statusOptions = [
    { value: 'pending', label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'processing', label: 'Processing', color: 'bg-blue-100 text-blue-800' },
    { value: 'completed', label: 'Completed', color: 'bg-green-100 text-green-800' },
    { value: 'on_hold', label: 'On Hold', color: 'bg-gray-100 text-gray-800' },
    { value: 'cancelled', label: 'Cancelled', color: 'bg-red-100 text-red-800' }
  ];

  if (selectedItems.length === 0) {
    return (
      <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onSelectAll(!allSelected)}
            className="h-8 w-8 p-0"
          >
            {allSelected ? (
              <CheckSquare className="h-4 w-4" />
            ) : (
              <Square className="h-4 w-4" />
            )}
          </Button>
          <span className="text-sm text-muted-foreground">
            Select items for bulk operations
          </span>
        </div>
        <Badge variant="outline">
          {totalItems} items
        </Badge>
      </div>
    );
  }

  return (
    <Card className="border-blue-200 bg-blue-50/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-blue-600" />
            Bulk Operations
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge className="bg-blue-100 text-blue-800">
              {selectedItems.length} selected
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onSelectAll(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {/* Bulk Approve */}
          <Button
            onClick={handleBulkApprove}
            className="bg-green-600 hover:bg-green-700"
            size="sm"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Approve ({selectedItems.length})
          </Button>

          {/* Bulk Email */}
          <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Mail className="h-4 w-4 mr-2" />
                Send Email
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Send Bulk Email</DialogTitle>
                <DialogDescription>
                  Send email notifications to {selectedItems.length} selected test requests.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email Message</label>
                  <Textarea
                    placeholder="Enter your message here..."
                    value={emailMessage}
                    onChange={(e) => setEmailMessage(e.target.value)}
                    rows={6}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsEmailDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleBulkEmail}>
                    Send Email
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Bulk Status Change */}
          <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Change Status
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Change Status</DialogTitle>
                <DialogDescription>
                  Update the status of {selectedItems.length} selected test requests.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-2">
                  {statusOptions.map((status) => (
                    <Button
                      key={status.value}
                      variant="outline"
                      onClick={() => handleStatusChange(status.value)}
                      className="justify-start"
                    >
                      <Badge className={status.color}>
                        {status.label}
                      </Badge>
                    </Button>
                  ))}
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Export Selected */}
          <Button 
            id="export-selected-btn"
            variant="outline" 
            size="sm" 
            onClick={handleExportSelected}
            aria-label="Export selected items"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}