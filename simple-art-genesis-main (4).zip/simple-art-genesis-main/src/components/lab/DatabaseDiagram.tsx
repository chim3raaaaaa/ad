import React, { useState, useCallback, useMemo } from 'react';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  Node,
  Handle,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  Database, 
  Link2, 
  Eye, 
  Save, 
  Trash2, 
  Plus,
  FileCode,
  Table as TableIcon,
  Users,
  ArrowRight
} from 'lucide-react';

interface TableNode {
  id: string;
  name: string;
  columns: Column[];
  position: { x: number; y: number };
}

interface Column {
  id: string;
  name: string;
  type: string;
  nullable: boolean;
  primaryKey: boolean;
  foreignKey?: {
    table: string;
    column: string;
  };
  unique: boolean;
  indexed: boolean;
  defaultValue?: string;
}

interface Relationship {
  id: string;
  type: '1:1' | '1:N' | 'N:1' | 'N:N';
  sourceTable: string;
  sourceColumn: string;
  targetTable: string;
  targetColumn: string;
}

const dataTypes = [
  'TEXT', 'INTEGER', 'REAL', 'BOOLEAN', 'DATE', 'DATETIME', 'JSON', 'BLOB'
];

const relationshipTypes = [
  { value: '1:1', label: 'One to One', color: 'bg-blue-500' },
  { value: '1:N', label: 'One to Many', color: 'bg-green-500' },
  { value: 'N:1', label: 'Many to One', color: 'bg-yellow-500' },
  { value: 'N:N', label: 'Many to Many', color: 'bg-purple-500' }
];

// Custom Node Component for Tables
const TableNode = ({ data }: { data: TableNode }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="bg-white border-2 border-gray-200 rounded-lg shadow-lg min-w-48">
      <div className="bg-blue-50 px-3 py-2 border-b border-gray-200 rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TableIcon className="w-4 h-4 text-blue-600" />
            <span className="font-semibold text-sm">{data.name}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="h-6 w-6 p-0"
          >
            {isExpanded ? '−' : '+'}
          </Button>
        </div>
      </div>
      
      {isExpanded && (
        <div className="p-2">
          {data.columns.map((column, index) => (
            <div key={column.id} className="flex items-center justify-between py-1 px-2 text-xs">
              <div className="flex items-center gap-2">
                <span className={column.primaryKey ? 'font-bold text-yellow-600' : ''}>
                  {column.name}
                </span>
                <Badge variant="outline" className="text-xs">
                  {column.type}
                </Badge>
                {column.primaryKey && <Badge className="text-xs bg-yellow-500">PK</Badge>}
                {column.foreignKey && <Badge className="text-xs bg-blue-500">FK</Badge>}
              </div>
              <Handle
                type="source"
                position={Position.Right}
                id={`${data.id}-${column.id}`}
                style={{ top: 40 + index * 24, right: -6 }}
                className="w-3 h-3"
              />
            </div>
          ))}
        </div>
      )}
      
      <Handle
        type="target"
        position={Position.Left}
        id={`${data.id}-target`}
        style={{ left: -6, top: '50%' }}
        className="w-3 h-3"
      />
    </div>
  );
};

const nodeTypes = {
  table: TableNode,
};

export function DatabaseDiagram() {
  const { toast } = useToast();
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [tables, setTables] = useState<TableNode[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [isCreatingTable, setIsCreatingTable] = useState(false);
  const [newTable, setNewTable] = useState({
    name: '',
    columns: [] as Column[]
  });

  const onConnect = useCallback((params: Connection) => {
    if (params.source && params.target && params.sourceHandle && params.targetHandle) {
      const sourceData = params.sourceHandle.split('-');
      const sourceTable = sourceData[0];
      const sourceColumn = sourceData[1];
      const targetTable = params.target;

      const newRelationship: Relationship = {
        id: `rel_${Date.now()}`,
        type: '1:N',
        sourceTable,
        sourceColumn,
        targetTable,
        targetColumn: 'id'
      };

      setRelationships(prev => [...prev, newRelationship]);
      
      const newEdge = {
        ...params,
        id: newRelationship.id,
        type: 'smoothstep',
        label: '1:N',
        style: { stroke: '#10B981' }
      };
      
      setEdges((eds) => addEdge(newEdge, eds));
      
      toast({
        title: "Relationship Created",
        description: `${sourceTable}.${sourceColumn} → ${targetTable}`
      });
    }
  }, [setEdges, toast]);

  const addTable = () => {
    if (!newTable.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Table name is required",
        variant: "destructive"
      });
      return;
    }

    const tableId = `table_${Date.now()}`;
    const position = { 
      x: Math.random() * 400 + 100, 
      y: Math.random() * 300 + 100 
    };

    const tableData: TableNode = {
      id: tableId,
      name: newTable.name,
      columns: newTable.columns.length > 0 ? newTable.columns : [{
        id: 'id',
        name: 'id',
        type: 'INTEGER',
        nullable: false,
        primaryKey: true,
        unique: true,
        indexed: true
      }],
      position
    };

    const node: Node = {
      id: tableId,
      type: 'table',
      position,
      data: tableData as any,
      draggable: true
    };

    setTables(prev => [...prev, tableData]);
    setNodes(prev => [...prev, node]);
    setNewTable({ name: '', columns: [] });
    setIsCreatingTable(false);
    
    toast({
      title: "Table Created",
      description: `Table "${newTable.name}" has been added to the diagram`
    });
  };

  const addColumn = () => {
    const newColumn: Column = {
      id: `col_${Date.now()}`,
      name: 'new_column',
      type: 'TEXT',
      nullable: true,
      primaryKey: false,
      unique: false,
      indexed: false
    };

    setNewTable(prev => ({
      ...prev,
      columns: [...prev.columns, newColumn]
    }));
  };

  const updateColumn = (columnId: string, updates: Partial<Column>) => {
    setNewTable(prev => ({
      ...prev,
      columns: prev.columns.map(col => 
        col.id === columnId ? { ...col, ...updates } : col
      )
    }));
  };

  const removeColumn = (columnId: string) => {
    setNewTable(prev => ({
      ...prev,
      columns: prev.columns.filter(col => col.id !== columnId)
    }));
  };

  const generateSQL = () => {
    let sql = '';
    
    tables.forEach(table => {
      sql += `CREATE TABLE ${table.name} (\n`;
      
      const columnDefs = table.columns.map(column => {
        let def = `  ${column.name} ${column.type}`;
        if (column.primaryKey) def += ' PRIMARY KEY';
        if (!column.nullable && !column.primaryKey) def += ' NOT NULL';
        if (column.unique && !column.primaryKey) def += ' UNIQUE';
        if (column.defaultValue) def += ` DEFAULT ${column.defaultValue}`;
        return def;
      });
      
      sql += columnDefs.join(',\n') + '\n);\n\n';
      
      // Add indexes
      table.columns.forEach(column => {
        if (column.indexed && !column.primaryKey) {
          sql += `CREATE INDEX idx_${table.name}_${column.name} ON ${table.name}(${column.name});\n`;
        }
      });
      
      sql += '\n';
    });

    // Add foreign key constraints
    relationships.forEach(rel => {
      sql += `ALTER TABLE ${rel.sourceTable} ADD CONSTRAINT fk_${rel.id} `;
      sql += `FOREIGN KEY (${rel.sourceColumn}) REFERENCES ${rel.targetTable}(${rel.targetColumn});\n`;
    });

    return sql;
  };

  const selectedTableData = selectedTable ? tables.find(t => t.id === selectedTable) : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Database Schema Designer</h3>
          <p className="text-sm text-muted-foreground">Visual database design with relationships</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setIsCreatingTable(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Table
          </Button>
          <Button variant="outline">
            <FileCode className="w-4 h-4 mr-2" />
            Export SQL
          </Button>
        </div>
      </div>

      <Tabs defaultValue="diagram" className="space-y-4">
        <TabsList>
          <TabsTrigger value="diagram">Visual Diagram</TabsTrigger>
          <TabsTrigger value="tables">Tables ({tables.length})</TabsTrigger>
          <TabsTrigger value="relationships">Relationships ({relationships.length})</TabsTrigger>
          <TabsTrigger value="sql">Generated SQL</TabsTrigger>
        </TabsList>

        <TabsContent value="diagram">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Table Creation Panel */}
            {isCreatingTable && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Create Table</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Table Name</Label>
                    <Input
                      value={newTable.name}
                      onChange={(e) => setNewTable(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="table_name"
                    />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label>Columns</Label>
                      <Button size="sm" onClick={addColumn}>
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {newTable.columns.map(column => (
                        <div key={column.id} className="p-2 border rounded space-y-2">
                          <div className="flex items-center justify-between">
                            <Input
                              value={column.name}
                              onChange={(e) => updateColumn(column.id, { name: e.target.value })}
                              className="text-xs"
                              placeholder="column_name"
                            />
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => removeColumn(column.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                          
                          <Select
                            value={column.type}
                            onValueChange={(value) => updateColumn(column.id, { type: value })}
                          >
                            <SelectTrigger className="text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {dataTypes.map(type => (
                                <SelectItem key={type} value={type}>{type}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          
                          <div className="flex gap-2 text-xs">
                            <div className="flex items-center space-x-1">
                              <Switch
                                checked={column.primaryKey}
                                onCheckedChange={(checked) => updateColumn(column.id, { primaryKey: checked })}
                              />
                              <Label className="text-xs">PK</Label>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Switch
                                checked={!column.nullable}
                                onCheckedChange={(checked) => updateColumn(column.id, { nullable: !checked })}
                              />
                              <Label className="text-xs">Required</Label>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button onClick={addTable} className="flex-1">
                      Create
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setIsCreatingTable(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Database Diagram */}
            <Card className={`${isCreatingTable ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Database Schema
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div style={{ height: '600px' }}>
                  <ReactFlow
                    nodes={nodes}
                    edges={edges}
                    onNodesChange={onNodesChange}
                    onEdgesChange={onEdgesChange}
                    onConnect={onConnect}
                    nodeTypes={nodeTypes}
                    fitView
                    attributionPosition="top-right"
                    className="bg-gray-50"
                  >
                    <Controls />
                    <MiniMap />
                    <Background color="#aaa" gap={16} />
                  </ReactFlow>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tables">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tables.map(table => (
              <Card key={table.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <TableIcon className="w-4 h-4" />
                    {table.name}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {table.columns.length} columns
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {table.columns.slice(0, 4).map(column => (
                      <div key={column.id} className="flex items-center justify-between text-sm">
                        <span className={column.primaryKey ? 'font-semibold' : ''}>
                          {column.name}
                        </span>
                        <div className="flex gap-1">
                          <Badge variant="outline" className="text-xs">
                            {column.type}
                          </Badge>
                          {column.primaryKey && <Badge className="text-xs bg-yellow-500">PK</Badge>}
                        </div>
                      </div>
                    ))}
                    {table.columns.length > 4 && (
                      <p className="text-xs text-muted-foreground">
                        +{table.columns.length - 4} more columns
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="relationships">
          <div className="space-y-4">
            {relationships.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Link2 className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Relationships</h3>
                  <p className="text-muted-foreground text-center">
                    Connect tables in the diagram view to create relationships
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {relationships.map(rel => (
                  <Card key={rel.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge 
                          className={relationshipTypes.find(t => t.value === rel.type)?.color}
                        >
                          {rel.type}
                        </Badge>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-mono bg-muted px-2 py-1 rounded">
                          {rel.sourceTable}.{rel.sourceColumn}
                        </span>
                        <ArrowRight className="w-3 h-3" />
                        <span className="font-mono bg-muted px-2 py-1 rounded">
                          {rel.targetTable}.{rel.targetColumn}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="sql">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Generated SQL Schema</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto font-mono">
                {generateSQL() || '-- No tables defined yet'}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}