import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Shield, Eye, EyeOff, Save, AlertTriangle } from "lucide-react";
import { useUser } from "@/contexts/UserContext";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface PasswordPolicy {
  minLength: number;
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
  preventReuse: boolean;
  reuseLimit: number;
  passwordExpiry: boolean;
  expiryDays: number;
  lockoutEnabled: boolean;
  maxAttempts: number;
  lockoutDuration: number;
}

export function PasswordPolicyManager() {
  const { user, canAccessPasswordPolicy } = useUser();
  const { toast } = useToast();
  
  const [policy, setPolicy] = useState<PasswordPolicy>({
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    preventReuse: true,
    reuseLimit: 5,
    passwordExpiry: true,
    expiryDays: 90,
    lockoutEnabled: true,
    maxAttempts: 3,
    lockoutDuration: 15
  });

  const [testPassword, setTestPassword] = useState("");
  const [showTestPassword, setShowTestPassword] = useState(false);

  // Check permissions
  if (!canAccessPasswordPolicy()) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <AlertTriangle className="h-12 w-12 mx-auto text-muted-foreground" />
            <div>
              <h3 className="text-lg font-semibold">Access Denied</h3>
              <p className="text-muted-foreground">
                You don't have permission to manage password policies. Only Administrators and Lab Managers can access this feature.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const validatePassword = (password: string) => {
    const checks = [
      { test: password.length >= policy.minLength, message: `At least ${policy.minLength} characters` },
      { test: !policy.requireUppercase || /[A-Z]/.test(password), message: "Uppercase letter" },
      { test: !policy.requireLowercase || /[a-z]/.test(password), message: "Lowercase letter" },
      { test: !policy.requireNumbers || /[0-9]/.test(password), message: "Number" },
      { test: !policy.requireSpecialChars || /[!@#$%^&*(),.?":{}|<>]/.test(password), message: "Special character" }
    ];

    return checks;
  };

  const passwordChecks = validatePassword(testPassword);
  const isPasswordValid = passwordChecks.every(check => check.test);

  const savePolicy = () => {
    // Log the policy change activity
    const logEntry = {
      userId: user?.id,
      username: user?.username,
      role: user?.role,
      action: 'password_policy_update',
      timestamp: new Date().toISOString(),
      details: 'Password policy updated',
      policySettings: policy
    };
    
    console.log("Password policy change logged:", logEntry);
    console.log("Saving password policy:", policy);
    
    toast({
      title: "Password Policy Updated",
      description: "Password policy has been saved and logged for security audit.",
    });
    
    // Here you would save to your data store
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Password Policy Management
          </h2>
          <p className="text-muted-foreground">Configure password requirements and security policies</p>
        </div>
        <Button onClick={savePolicy}>
          <Save className="h-4 w-4 mr-2" />
          Save Policy
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Password Requirements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="minLength">Minimum Length</Label>
              <Input
                id="minLength"
                type="number"
                value={policy.minLength}
                onChange={(e) => setPolicy(prev => ({ ...prev, minLength: parseInt(e.target.value) }))}
                min="1"
                max="50"
              />
            </div>

            <Separator />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Require Uppercase Letters</Label>
                  <p className="text-sm text-muted-foreground">At least one uppercase letter (A-Z)</p>
                </div>
                <Switch
                  checked={policy.requireUppercase}
                  onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, requireUppercase: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Require Lowercase Letters</Label>
                  <p className="text-sm text-muted-foreground">At least one lowercase letter (a-z)</p>
                </div>
                <Switch
                  checked={policy.requireLowercase}
                  onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, requireLowercase: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Require Numbers</Label>
                  <p className="text-sm text-muted-foreground">At least one number (0-9)</p>
                </div>
                <Switch
                  checked={policy.requireNumbers}
                  onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, requireNumbers: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Require Special Characters</Label>
                  <p className="text-sm text-muted-foreground">At least one special character (!@#$%^&*)</p>
                </div>
                <Switch
                  checked={policy.requireSpecialChars}
                  onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, requireSpecialChars: checked }))}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Security Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Prevent Password Reuse</Label>
                <p className="text-sm text-muted-foreground">Users cannot reuse recent passwords</p>
              </div>
              <Switch
                checked={policy.preventReuse}
                onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, preventReuse: checked }))}
              />
            </div>

            {policy.preventReuse && (
              <div className="space-y-2">
                <Label htmlFor="reuseLimit">Password History Limit</Label>
                <Input
                  id="reuseLimit"
                  type="number"
                  value={policy.reuseLimit}
                  onChange={(e) => setPolicy(prev => ({ ...prev, reuseLimit: parseInt(e.target.value) }))}
                  min="1"
                  max="20"
                />
              </div>
            )}

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Password Expiry</Label>
                <p className="text-sm text-muted-foreground">Passwords expire after specified days</p>
              </div>
              <Switch
                checked={policy.passwordExpiry}
                onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, passwordExpiry: checked }))}
              />
            </div>

            {policy.passwordExpiry && (
              <div className="space-y-2">
                <Label htmlFor="expiryDays">Expiry Days</Label>
                <Input
                  id="expiryDays"
                  type="number"
                  value={policy.expiryDays}
                  onChange={(e) => setPolicy(prev => ({ ...prev, expiryDays: parseInt(e.target.value) }))}
                  min="1"
                  max="365"
                />
              </div>
            )}

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Account Lockout</Label>
                <p className="text-sm text-muted-foreground">Lock accounts after failed attempts</p>
              </div>
              <Switch
                checked={policy.lockoutEnabled}
                onCheckedChange={(checked) => setPolicy(prev => ({ ...prev, lockoutEnabled: checked }))}
              />
            </div>

            {policy.lockoutEnabled && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="maxAttempts">Max Attempts</Label>
                  <Input
                    id="maxAttempts"
                    type="number"
                    value={policy.maxAttempts}
                    onChange={(e) => setPolicy(prev => ({ ...prev, maxAttempts: parseInt(e.target.value) }))}
                    min="1"
                    max="10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lockoutDuration">Lockout Duration (minutes)</Label>
                  <Input
                    id="lockoutDuration"
                    type="number"
                    value={policy.lockoutDuration}
                    onChange={(e) => setPolicy(prev => ({ ...prev, lockoutDuration: parseInt(e.target.value) }))}
                    min="1"
                    max="60"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Password Tester</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="testPassword">Test Password</Label>
              <div className="relative">
                <Input
                  id="testPassword"
                  type={showTestPassword ? "text" : "password"}
                  value={testPassword}
                  onChange={(e) => setTestPassword(e.target.value)}
                  placeholder="Enter password to test against current policy"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={() => setShowTestPassword(!showTestPassword)}
                >
                  {showTestPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Policy Compliance</Label>
              <div className="space-y-2">
                {passwordChecks.map((check, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Badge variant={check.test ? "default" : "destructive"}>
                      {check.test ? "✓" : "✗"}
                    </Badge>
                    <span className={`text-sm ${check.test ? 'text-green-600' : 'text-red-600'}`}>
                      {check.message}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 p-3 rounded-lg border">
                <div className="flex items-center space-x-2">
                  {isPasswordValid ? (
                    <Badge className="bg-green-100 text-green-800">
                      Password meets all requirements
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Password does not meet requirements
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}