import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Keyboard, Search, Settings, Save, Command } from "lucide-react";
import { useState, useEffect } from "react";

interface ShortcutGroup {
  category: string;
  shortcuts: {
    keys: string[];
    action: string;
    description: string;
  }[];
}

const defaultShortcuts: ShortcutGroup[] = [
  {
    category: "Navigation",
    shortcuts: [
      { keys: ["Ctrl", "D"], action: "dashboard", description: "Go to Dashboard" },
      { keys: ["Ctrl", "T"], action: "test_requests", description: "Go to Test Requests" },
      { keys: ["Ctrl", "R"], action: "reports", description: "Go to Reports" },
      { keys: ["Ctrl", "U"], action: "users", description: "Go to Users" },
      { keys: ["Ctrl", "S"], action: "settings", description: "Go to Settings" },
    ]
  },
  {
    category: "Actions",
    shortcuts: [
      { keys: ["Ctrl", "N"], action: "new_request", description: "Create New Test Request" },
      { keys: ["Ctrl", "Shift", "N"], action: "new_report", description: "Create New Report" },
      { keys: ["Ctrl", "E"], action: "export", description: "Export Data" },
      { keys: ["Ctrl", "P"], action: "print", description: "Print Current Page" },
      { keys: ["Ctrl", "F"], action: "search", description: "Search" },
    ]
  },
  {
    category: "General",
    shortcuts: [
      { keys: ["Ctrl", "Z"], action: "undo", description: "Undo Last Action" },
      { keys: ["Ctrl", "Y"], action: "redo", description: "Redo Last Action" },
      { keys: ["Ctrl", "S"], action: "save", description: "Save Current Work" },
      { keys: ["Esc"], action: "cancel", description: "Cancel Current Operation" },
      { keys: ["?"], action: "help", description: "Show Help" },
    ]
  }
];

export function KeyboardShortcuts() {
  const [shortcuts, setShortcuts] = useState(defaultShortcuts);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingShortcut, setEditingShortcut] = useState<{
    category: string;
    index: number;
    keys: string[];
  } | null>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const keys = [];
      if (event.ctrlKey) keys.push("Ctrl");
      if (event.shiftKey) keys.push("Shift");
      if (event.altKey) keys.push("Alt");
      if (event.metaKey) keys.push("Cmd");
      
      if (event.key && !["Control", "Shift", "Alt", "Meta"].includes(event.key)) {
        keys.push(event.key.toUpperCase());
      }

      // Find matching shortcut
      const matchingShortcut = shortcuts.find(group => 
        group.shortcuts.some(shortcut => 
          shortcut.keys.length === keys.length &&
          shortcut.keys.every(key => keys.includes(key))
        )
      );

      if (matchingShortcut) {
        const shortcut = matchingShortcut.shortcuts.find(s => 
          s.keys.length === keys.length &&
          s.keys.every(key => keys.includes(key))
        );
        
        if (shortcut) {
          event.preventDefault();
          executeAction(shortcut.action);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [shortcuts]);

  const executeAction = (action: string) => {
    switch (action) {
      case "dashboard":
        window.location.href = "/dashboard";
        break;
      case "test_requests":
        window.location.href = "/test-requests";
        break;
      case "reports":
        window.location.href = "/reports";
        break;
      case "users":
        window.location.href = "/users";
        break;
      case "settings":
        window.location.href = "/settings";
        break;
      case "new_request":
        console.log("Creating new test request");
        break;
      case "new_report":
        console.log("Creating new report");
        break;
      case "export":
        console.log("Exporting data");
        break;
      case "print":
        window.print();
        break;
      case "search":
        const searchInput = document.querySelector('input[type="search"]') as HTMLInputElement;
        if (searchInput) searchInput.focus();
        break;
      case "save":
        console.log("Saving work");
        break;
      case "help":
        console.log("Showing help");
        break;
      default:
        console.log(`Executing action: ${action}`);
    }
  };

  const filteredShortcuts = shortcuts.map(group => ({
    ...group,
    shortcuts: group.shortcuts.filter(shortcut => 
      shortcut.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shortcut.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shortcut.keys.some(key => key.toLowerCase().includes(searchTerm.toLowerCase()))
    )
  })).filter(group => group.shortcuts.length > 0);

  const formatKeys = (keys: string[]) => {
    return keys.map(key => {
      switch (key) {
        case "Ctrl": return "⌃";
        case "Shift": return "⇧";
        case "Alt": return "⌥";
        case "Cmd": return "⌘";
        default: return key;
      }
    }).join(" + ");
  };

  const saveShortcuts = () => {
    localStorage.setItem("keyboard_shortcuts", JSON.stringify(shortcuts));
    console.log("Keyboard shortcuts saved");
  };

  const resetShortcuts = () => {
    setShortcuts(defaultShortcuts);
    localStorage.removeItem("keyboard_shortcuts");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Keyboard className="h-6 w-6" />
            Keyboard Shortcuts
          </h2>
          <p className="text-muted-foreground">Manage and customize keyboard shortcuts for faster navigation</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={resetShortcuts} variant="outline">
            Reset to Default
          </Button>
          <Button onClick={saveShortcuts}>
            <Save className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      <Tabs defaultValue="shortcuts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="shortcuts">Shortcuts</TabsTrigger>
          <TabsTrigger value="customize">Customize</TabsTrigger>
        </TabsList>

        <TabsContent value="shortcuts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Available Shortcuts</CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search shortcuts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {filteredShortcuts.map((group, groupIndex) => (
                  <div key={groupIndex} className="space-y-3">
                    <h3 className="font-semibold text-lg">{group.category}</h3>
                    <div className="space-y-2">
                      {group.shortcuts.map((shortcut, shortcutIndex) => (
                        <div key={shortcutIndex} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex-1">
                            <div className="font-medium">{shortcut.description}</div>
                            <div className="text-sm text-muted-foreground">{shortcut.action}</div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {shortcut.keys.map((key, keyIndex) => (
                              <Badge key={keyIndex} variant="outline" className="font-mono">
                                {key}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customize" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Customize Shortcuts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newAction">Action</Label>
                  <Input
                    id="newAction"
                    placeholder="Enter action name"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newDescription">Description</Label>
                  <Input
                    id="newDescription"
                    placeholder="Enter description"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newKeys">Keyboard Combination</Label>
                  <Input
                    id="newKeys"
                    placeholder="Press the key combination"
                    onKeyDown={(e) => {
                      e.preventDefault();
                      const keys = [];
                      if (e.ctrlKey) keys.push("Ctrl");
                      if (e.shiftKey) keys.push("Shift");
                      if (e.altKey) keys.push("Alt");
                      if (e.metaKey) keys.push("Cmd");
                      
                      if (e.key && !["Control", "Shift", "Alt", "Meta"].includes(e.key)) {
                        keys.push(e.key.toUpperCase());
                      }
                      
                      (e.target as HTMLInputElement).value = keys.join(" + ");
                    }}
                  />
                </div>
                
                <Button>
                  <Settings className="h-4 w-4 mr-2" />
                  Add Custom Shortcut
                </Button>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="font-semibold">Tips</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>• Use Ctrl + key combinations for main actions</p>
                  <p>• Use Ctrl + Shift + key for secondary actions</p>
                  <p>• Avoid conflicts with browser shortcuts</p>
                  <p>• Keep shortcuts memorable and logical</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}