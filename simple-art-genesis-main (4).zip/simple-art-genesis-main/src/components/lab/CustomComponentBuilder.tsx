import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Plus, Trash2, Eye, Code, Palette, Layout, Move } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ComponentStyle {
  backgroundColor?: string;
  color?: string;
  padding?: number;
  margin?: number;
  borderRadius?: number;
  fontSize?: number;
  fontWeight?: string;
  textAlign?: 'left' | 'center' | 'right';
  border?: string;
  shadow?: string;
}

interface ComponentElement {
  id: string;
  type: 'text' | 'button' | 'image' | 'input' | 'card' | 'badge' | 'icon';
  content: string;
  styles: ComponentStyle;
  props?: Record<string, any>;
  position: { x: number; y: number };
  size: { width: number; height: number };
}

interface CustomComponent {
  id: string;
  name: string;
  description: string;
  elements: ComponentElement[];
  containerStyles: ComponentStyle;
  responsive: boolean;
  created_at: string;
}

export function CustomComponentBuilder() {
  const { toast } = useToast();
  const [currentComponent, setCurrentComponent] = useState<CustomComponent>({
    id: '',
    name: '',
    description: '',
    elements: [],
    containerStyles: {
      backgroundColor: '#ffffff',
      padding: 16,
      borderRadius: 8
    },
    responsive: true,
    created_at: new Date().toISOString()
  });
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [savedComponents, setSavedComponents] = useState<CustomComponent[]>([]);

  const elementTypes = [
    { value: 'text', label: 'Text', icon: '📝' },
    { value: 'button', label: 'Button', icon: '🔘' },
    { value: 'image', label: 'Image', icon: '🖼️' },
    { value: 'input', label: 'Input', icon: '📝' },
    { value: 'card', label: 'Card', icon: '🃏' },
    { value: 'badge', label: 'Badge', icon: '🏷️' },
    { value: 'icon', label: 'Icon', icon: '⭐' }
  ];

  const addElement = (type: ComponentElement['type']) => {
    const newElement: ComponentElement = {
      id: `element_${Date.now()}`,
      type,
      content: type === 'button' ? 'Click me' : type === 'text' ? 'Sample text' : 'Content',
      styles: {
        backgroundColor: type === 'button' ? '#3b82f6' : 'transparent',
        color: type === 'button' ? '#ffffff' : '#000000',
        padding: type === 'button' ? 12 : 8,
        borderRadius: type === 'button' ? 6 : 0,
        fontSize: 14
      },
      position: { x: 50 + currentComponent.elements.length * 20, y: 50 + currentComponent.elements.length * 20 },
      size: { width: type === 'button' ? 120 : 100, height: type === 'input' ? 40 : 30 }
    };
    
    setCurrentComponent(prev => ({
      ...prev,
      elements: [...prev.elements, newElement]
    }));
    
    setSelectedElement(newElement.id);
  };

  const updateElement = (elementId: string, updates: Partial<ComponentElement>) => {
    setCurrentComponent(prev => ({
      ...prev,
      elements: prev.elements.map(element => 
        element.id === elementId ? { ...element, ...updates } : element
      )
    }));
  };

  const updateElementStyles = (elementId: string, styleUpdates: Partial<ComponentStyle>) => {
    updateElement(elementId, {
      styles: { ...currentComponent.elements.find(e => e.id === elementId)?.styles, ...styleUpdates }
    });
  };

  const removeElement = (elementId: string) => {
    setCurrentComponent(prev => ({
      ...prev,
      elements: prev.elements.filter(element => element.id !== elementId)
    }));
    
    if (selectedElement === elementId) {
      setSelectedElement(null);
    }
  };

  const saveComponent = () => {
    if (!currentComponent.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Component name is required",
        variant: "destructive"
      });
      return;
    }

    const componentToSave = {
      ...currentComponent,
      id: currentComponent.id || `component_${Date.now()}`,
      created_at: currentComponent.created_at || new Date().toISOString()
    };

    setSavedComponents(prev => {
      const existing = prev.find(c => c.id === componentToSave.id);
      if (existing) {
        return prev.map(c => c.id === componentToSave.id ? componentToSave : c);
      }
      return [...prev, componentToSave];
    });

    toast({
      title: "Component Saved",
      description: `"${componentToSave.name}" has been saved successfully`
    });
  };

  const loadComponent = (component: CustomComponent) => {
    setCurrentComponent(component);
    setSelectedElement(null);
    setPreviewMode(false);
  };

  const renderElement = (element: ComponentElement) => {
    const styles: React.CSSProperties = {
      backgroundColor: element.styles.backgroundColor,
      color: element.styles.color,
      padding: `${element.styles.padding || 8}px`,
      margin: `${element.styles.margin || 0}px`,
      borderRadius: `${element.styles.borderRadius || 0}px`,
      fontSize: `${element.styles.fontSize || 14}px`,
      fontWeight: element.styles.fontWeight || 'normal',
      textAlign: element.styles.textAlign || 'left',
      border: element.styles.border || 'none',
      boxShadow: element.styles.shadow || 'none',
      width: `${element.size.width}px`,
      height: element.type === 'text' ? 'auto' : `${element.size.height}px`,
      position: 'absolute' as const,
      left: `${element.position.x}px`,
      top: `${element.position.y}px`,
      cursor: previewMode ? 'default' : 'move'
    };

    switch (element.type) {
      case 'button':
        return (
          <button 
            key={element.id}
            style={styles}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
          >
            {element.content}
          </button>
        );
      
      case 'text':
        return (
          <div 
            key={element.id}
            style={styles}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
          >
            {element.content}
          </div>
        );
      
      case 'input':
        return (
          <input 
            key={element.id}
            style={styles}
            placeholder={element.content}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
            disabled={!previewMode}
          />
        );
      
      case 'card':
        return (
          <div 
            key={element.id}
            style={{...styles, border: element.styles.border || '1px solid #e5e7eb'}}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
          >
            {element.content}
          </div>
        );
      
      case 'badge':
        return (
          <span 
            key={element.id}
            style={{...styles, display: 'inline-block'}}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
          >
            {element.content}
          </span>
        );
      
      default:
        return (
          <div 
            key={element.id}
            style={styles}
            onClick={() => !previewMode && setSelectedElement(element.id)}
            className={selectedElement === element.id ? 'ring-2 ring-blue-500' : ''}
          >
            {element.content}
          </div>
        );
    }
  };

  const selectedElementData = currentComponent.elements.find(e => e.id === selectedElement);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Component Builder</h3>
          <p className="text-sm text-muted-foreground">Create custom UI components visually</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setPreviewMode(!previewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Edit' : 'Preview'}
          </Button>
          <Button onClick={saveComponent}>
            Save Component
          </Button>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList>
          <TabsTrigger value="builder">Visual Builder</TabsTrigger>
          <TabsTrigger value="components">Saved Components ({savedComponents.length})</TabsTrigger>
          <TabsTrigger value="code">Generated Code</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Settings Panel */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Component Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="component-name">Name</Label>
                    <Input
                      id="component-name"
                      value={currentComponent.name}
                      onChange={(e) => setCurrentComponent(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Component name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="component-description">Description</Label>
                    <Textarea
                      id="component-description"
                      value={currentComponent.description}
                      onChange={(e) => setCurrentComponent(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Component description"
                      rows={3}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Responsive</Label>
                    <Switch
                      checked={currentComponent.responsive}
                      onCheckedChange={(checked) => setCurrentComponent(prev => ({ ...prev, responsive: checked }))}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Add Elements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {elementTypes.map(type => (
                    <Button
                      key={type.value}
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => addElement(type.value as ComponentElement['type'])}
                    >
                      <span className="mr-2">{type.icon}</span>
                      {type.label}
                    </Button>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Canvas */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">Canvas</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {currentComponent.elements.length} elements
                      </Badge>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setSelectedElement(null)}
                      >
                        <Layout className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div 
                    className="relative border border-dashed border-gray-300 rounded-lg overflow-hidden"
                    style={{
                      minHeight: '400px',
                      backgroundColor: currentComponent.containerStyles.backgroundColor,
                      padding: `${currentComponent.containerStyles.padding || 16}px`
                    }}
                  >
                    {currentComponent.elements.length === 0 && (
                      <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                        <div className="text-center">
                          <Layout className="w-12 h-12 mx-auto mb-2" />
                          <p>Add elements to start building</p>
                        </div>
                      </div>
                    )}
                    
                    {currentComponent.elements.map(element => renderElement(element))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Properties Panel */}
            <div className="space-y-4">
              {selectedElementData ? (
                <>
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">Element Properties</CardTitle>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeElement(selectedElementData.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label>Content</Label>
                        <Input
                          value={selectedElementData.content}
                          onChange={(e) => updateElement(selectedElementData.id, { content: e.target.value })}
                          placeholder="Element content"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>Width</Label>
                          <Input
                            type="number"
                            value={selectedElementData.size.width}
                            onChange={(e) => updateElement(selectedElementData.id, { 
                              size: { ...selectedElementData.size, width: parseInt(e.target.value) || 100 }
                            })}
                          />
                        </div>
                        <div>
                          <Label>Height</Label>
                          <Input
                            type="number"
                            value={selectedElementData.size.height}
                            onChange={(e) => updateElement(selectedElementData.id, { 
                              size: { ...selectedElementData.size, height: parseInt(e.target.value) || 30 }
                            })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>X Position</Label>
                          <Input
                            type="number"
                            value={selectedElementData.position.x}
                            onChange={(e) => updateElement(selectedElementData.id, { 
                              position: { ...selectedElementData.position, x: parseInt(e.target.value) || 0 }
                            })}
                          />
                        </div>
                        <div>
                          <Label>Y Position</Label>
                          <Input
                            type="number"
                            value={selectedElementData.position.y}
                            onChange={(e) => updateElement(selectedElementData.id, { 
                              position: { ...selectedElementData.position, y: parseInt(e.target.value) || 0 }
                            })}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Palette className="w-4 h-4" />
                        Styling
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label>Background Color</Label>
                        <Input
                          type="color"
                          value={selectedElementData.styles.backgroundColor || '#ffffff'}
                          onChange={(e) => updateElementStyles(selectedElementData.id, { backgroundColor: e.target.value })}
                        />
                      </div>
                      
                      <div>
                        <Label>Text Color</Label>
                        <Input
                          type="color"
                          value={selectedElementData.styles.color || '#000000'}
                          onChange={(e) => updateElementStyles(selectedElementData.id, { color: e.target.value })}
                        />
                      </div>

                      <div>
                        <Label>Font Size: {selectedElementData.styles.fontSize || 14}px</Label>
                        <Slider
                          value={[selectedElementData.styles.fontSize || 14]}
                          onValueChange={(value) => updateElementStyles(selectedElementData.id, { fontSize: value[0] })}
                          max={48}
                          min={8}
                          step={1}
                        />
                      </div>

                      <div>
                        <Label>Padding: {selectedElementData.styles.padding || 8}px</Label>
                        <Slider
                          value={[selectedElementData.styles.padding || 8]}
                          onValueChange={(value) => updateElementStyles(selectedElementData.id, { padding: value[0] })}
                          max={50}
                          min={0}
                          step={1}
                        />
                      </div>

                      <div>
                        <Label>Border Radius: {selectedElementData.styles.borderRadius || 0}px</Label>
                        <Slider
                          value={[selectedElementData.styles.borderRadius || 0]}
                          onValueChange={(value) => updateElementStyles(selectedElementData.id, { borderRadius: value[0] })}
                          max={30}
                          min={0}
                          step={1}
                        />
                      </div>

                      <div>
                        <Label>Text Align</Label>
                        <Select
                          value={selectedElementData.styles.textAlign || 'left'}
                          onValueChange={(value) => updateElementStyles(selectedElementData.id, { textAlign: value as 'left' | 'center' | 'right' })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="left">Left</SelectItem>
                            <SelectItem value="center">Center</SelectItem>
                            <SelectItem value="right">Right</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Move className="w-8 h-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Select an element to edit its properties</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="components">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedComponents.map(component => (
              <Card key={component.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{component.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {component.elements.length} elements • {new Date(component.created_at).toLocaleDateString()}
                  </p>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">{component.description}</p>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => loadComponent(component)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Export
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                <CardTitle>Generated React Component</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`// Generated component: ${currentComponent.name}
import React from 'react';

export function ${currentComponent.name.replace(/\s+/g, '')}() {
  return (
    <div className="relative" style={{
      backgroundColor: '${currentComponent.containerStyles.backgroundColor || '#ffffff'}',
      padding: '${currentComponent.containerStyles.padding || 16}px',
      borderRadius: '${currentComponent.containerStyles.borderRadius || 8}px'
    }}>
${currentComponent.elements.map(element => {
  const style = `{
        position: 'absolute',
        left: '${element.position.x}px',
        top: '${element.position.y}px',
        width: '${element.size.width}px',
        height: '${element.type === 'text' ? 'auto' : element.size.height + 'px'}',
        backgroundColor: '${element.styles.backgroundColor || 'transparent'}',
        color: '${element.styles.color || '#000000'}',
        padding: '${element.styles.padding || 8}px',
        borderRadius: '${element.styles.borderRadius || 0}px',
        fontSize: '${element.styles.fontSize || 14}px',
        textAlign: '${element.styles.textAlign || 'left'}'
      }`;

  switch (element.type) {
    case 'button':
      return `      <button style=${style}>
        ${element.content}
      </button>`;
    case 'input':
      return `      <input 
        style=${style}
        placeholder="${element.content}"
      />`;
    default:
      return `      <div style=${style}>
        ${element.content}
      </div>`;
  }
}).join('\n')}
    </div>
  );
}`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}