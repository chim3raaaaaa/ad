import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localReferenceDataService } from '@/services/storage/localReferenceDataService';

interface GradingLimit {
  id: number;
  material_type: string;
  standard: string;
  sieve_0_075?: number;
  sieve_0_15?: number;
  sieve_0_3?: number;
  sieve_0_6?: number;
  sieve_1_18?: number;
  sieve_2_36?: number;
  sieve_5?: number;
  sieve_10?: number;
  sieve_14?: number;
  sieve_16?: number;
  sieve_20?: number;
  sieve_31_5?: number;
  sieve_37_5?: number;
  sieve_45?: number;
  sieve_50?: number;
  sieve_63?: number;
  created_at: string;
  updated_at: string;
}

interface MaterialType {
  id: number;
  name: string;
}

interface Standard {
  id: number;
  name: string;
}

interface SieveSize {
  id: number;
  name: string;
  field_key: string;
  size_mm: number;
  display_order: number;
}

export function SieveGradingLimitsTab() {
  const [gradingLimits, setGradingLimits] = useState<GradingLimit[]>([]);
  const [materialTypes, setMaterialTypes] = useState<MaterialType[]>([]);
  const [standards, setStandards] = useState<Standard[]>([]);
  const [sieveSizes, setSieveSizes] = useState<SieveSize[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingLimit, setEditingLimit] = useState<GradingLimit | null>(null);

  // Form state
  const [materialType, setMaterialType] = useState('');
  const [standard, setStandard] = useState('');
  const [sieveValues, setSieveValues] = useState<Record<string, number | undefined>>({});

  const { toast } = useToast();

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    await Promise.all([
      loadGradingLimits(),
      loadMaterialTypes(),
      loadStandards(),
      loadSieveSizes()
    ]);
  };

  const loadMaterialTypes = async () => {
    try {
      const data = await localReferenceDataService.getMaterialTypes();
      setMaterialTypes(data);
    } catch (error) {
      console.error('Error loading material types:', error);
    }
  };

  const loadStandards = async () => {
    try {
      const data = await localReferenceDataService.getStandards();
      setStandards(data);
    } catch (error) {
      console.error('Error loading standards:', error);
    }
  };

  const loadSieveSizes = async () => {
    try {
      const data = await localReferenceDataService.getSieveSizes();
      setSieveSizes(data);
    } catch (error) {
      console.error('Error loading sieve sizes:', error);
    }
  };

  const loadGradingLimits = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM grading_limits ORDER BY material_type, standard',
          []
        );
        setGradingLimits(result || []);
      }
    } catch (error) {
      console.error('Error loading grading limits:', error);
      toast({
        title: "Error",
        description: "Failed to load grading limits",
        variant: "destructive"
      });
    }
  };

  const validateSieveInputs = (): boolean => {
    for (const [key, value] of Object.entries(sieveValues)) {
      if (value !== undefined && value !== null) {
        if (isNaN(value) || value < 0 || value > 100) {
          toast({
            title: "Validation Error",
            description: "Sieve values must be numbers between 0 and 100",
            variant: "destructive"
          });
          return false;
        }
      }
    }
    return true;
  };

  const resetForm = () => {
    setMaterialType('');
    setStandard('');
    setSieveValues({});
  };

  const createGradingLimit = async () => {
    if (!materialType || !standard) {
      toast({
        title: "Error",
        description: "Please select material type and standard",
        variant: "destructive"
      });
      return;
    }

    if (!validateSieveInputs()) {
      return;
    }

    setLoading(true);
    try {
      const columns = ['material_type', 'standard'];
      const values: any[] = [materialType, standard];
      const placeholders = ['?', '?'];

      sieveSizes.forEach(sieve => {
        if (sieveValues[sieve.field_key] !== undefined) {
          columns.push(sieve.field_key);
          values.push(sieveValues[sieve.field_key]!);
          placeholders.push('?');
        }
      });

      await window.electronAPI?.dbQuery(
        `INSERT INTO grading_limits (${columns.join(', ')}) VALUES (${placeholders.join(', ')})`,
        values
      );

      toast({
        title: "Success",
        description: "Grading limit created successfully"
      });

      resetForm();
      setShowCreateModal(false);
      loadGradingLimits();
    } catch (error) {
      console.error('Error creating grading limit:', error);
      toast({
        title: "Error",
        description: "Failed to create grading limit. This material type and standard combination may already exist.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateGradingLimit = async () => {
    if (!editingLimit || !materialType || !standard) {
      toast({
        title: "Error",
        description: "Please select material type and standard",
        variant: "destructive"
      });
      return;
    }

    if (!validateSieveInputs()) {
      return;
    }

    setLoading(true);
    try {
      const setParts = ['material_type = ?', 'standard = ?'];
      const values: any[] = [materialType, standard];

      sieveSizes.forEach(sieve => {
        setParts.push(`${sieve.field_key} = ?`);
        values.push(sieveValues[sieve.field_key] || null);
      });

      values.push(editingLimit.id.toString());

      await window.electronAPI?.dbQuery(
        `UPDATE grading_limits SET ${setParts.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        values
      );

      toast({
        title: "Success",
        description: "Grading limit updated successfully"
      });

      resetForm();
      setShowEditModal(false);
      setEditingLimit(null);
      loadGradingLimits();
    } catch (error) {
      console.error('Error updating grading limit:', error);
      toast({
        title: "Error",
        description: "Failed to update grading limit",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteGradingLimit = async (limit: GradingLimit) => {
    if (!confirm(`Are you sure you want to delete the grading limit for "${limit.material_type}" - "${limit.standard}"?`)) {
      return;
    }

    try {
      await window.electronAPI?.dbQuery(
        'DELETE FROM grading_limits WHERE id = ?',
        [limit.id.toString()]
      );

      toast({
        title: "Success",
        description: "Grading limit deleted successfully"
      });

      loadGradingLimits();
    } catch (error) {
      console.error('Error deleting grading limit:', error);
      toast({
        title: "Error",
        description: "Failed to delete grading limit",
        variant: "destructive"
      });
    }
  };

  const openEditModal = (limit: GradingLimit) => {
    setEditingLimit(limit);
    setMaterialType(limit.material_type);
    setStandard(limit.standard);
    
    const values: Record<string, number | undefined> = {};
    sieveSizes.forEach(sieve => {
      const value = limit[sieve.field_key as keyof GradingLimit] as number;
      if (value !== null && value !== undefined) {
        values[sieve.field_key] = value;
      }
    });
    setSieveValues(values);
    setShowEditModal(true);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Sieve Grading Limits Manager</CardTitle>
              <CardDescription>
                Manage grading limits per sieve size for each aggregate material type and standard
              </CardDescription>
            </div>
            <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
              <DialogTrigger asChild>
                <Button onClick={() => { resetForm(); setShowCreateModal(true); }}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add New Limit
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create New Grading Limit</DialogTitle>
                  <DialogDescription>
                    Define grading limits for a specific material type and standard
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="material-type">Material Type</Label>
                      <Select value={materialType} onValueChange={setMaterialType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select material type" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border">
                          {materialTypes.map((type) => (
                            <SelectItem key={type.id} value={type.name}>
                              {type.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="standard">Standard</Label>
                      <Select value={standard} onValueChange={setStandard}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select standard" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border">
                          {standards.map((std) => (
                            <SelectItem key={std.id} value={std.name}>
                              {std.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Sieve Size Limits (% Passing)</Label>
                    <div className="grid grid-cols-4 gap-3">
                      {sieveSizes.map(sieve => (
                        <div key={sieve.id} className="space-y-1">
                          <Label className="text-sm">{sieve.name}</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            placeholder="0-100"
                            value={sieveValues[sieve.field_key] || ''}
                            onChange={(e) => {
                              const value = e.target.value === '' ? undefined : parseFloat(e.target.value);
                              setSieveValues(prev => ({
                                ...prev,
                                [sieve.field_key]: value
                              }));
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createGradingLimit} disabled={loading}>
                    {loading ? 'Creating...' : 'Create Limit'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {gradingLimits.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No grading limits defined yet. Click "Add New Limit" to create one.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Material Type</TableHead>
                  <TableHead>Standard</TableHead>
                  <TableHead>Sieve Sizes Defined</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {gradingLimits.map((limit) => {
                  const definedSieves = sieveSizes.filter(sieve => 
                    limit[sieve.field_key as keyof GradingLimit] !== null && 
                    limit[sieve.field_key as keyof GradingLimit] !== undefined
                  ).length;

                  return (
                    <TableRow key={limit.id}>
                      <TableCell className="font-medium">{limit.material_type}</TableCell>
                      <TableCell>{limit.standard}</TableCell>
                      <TableCell>{definedSieves} of {sieveSizes.length} sieves</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openEditModal(limit)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => deleteGradingLimit(limit)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Grading Limit</DialogTitle>
            <DialogDescription>
              Modify grading limits for the selected material type and standard
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-material-type">Material Type</Label>
                <Select value={materialType} onValueChange={setMaterialType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select material type" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border">
                    {materialTypes.map((type) => (
                      <SelectItem key={type.id} value={type.name}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-standard">Standard</Label>
                <Select value={standard} onValueChange={setStandard}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select standard" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border">
                    {standards.map((std) => (
                      <SelectItem key={std.id} value={std.name}>
                        {std.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Sieve Size Limits (% Passing)</Label>
              <div className="grid grid-cols-4 gap-3">
                {sieveSizes.map(sieve => (
                  <div key={sieve.id} className="space-y-1">
                    <Label className="text-sm">{sieve.name}</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      placeholder="0-100"
                      value={sieveValues[sieve.field_key] || ''}
                      onChange={(e) => {
                        const value = e.target.value === '' ? undefined : parseFloat(e.target.value);
                        setSieveValues(prev => ({
                          ...prev,
                          [sieve.field_key]: value
                        }));
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditModal(false)}>
              Cancel
            </Button>
            <Button onClick={updateGradingLimit} disabled={loading}>
              {loading ? 'Updating...' : 'Update Limit'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}