import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Play, Copy, Globe, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface APIHeader {
  key: string;
  value: string;
  enabled: boolean;
}

interface APIEndpoint {
  id: string;
  name: string;
  description: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  url: string;
  headers: APIHeader[];
  body?: string;
  authentication: {
    type: 'none' | 'bearer' | 'api-key' | 'basic';
    token?: string;
    username?: string;
    password?: string;
    keyName?: string;
    keyValue?: string;
  };
  responseFormat: 'json' | 'xml' | 'text';
  timeout: number;
  retries: number;
  created_at: string;
}

interface APITest {
  endpointId: string;
  status: 'success' | 'error' | 'pending';
  statusCode?: number;
  responseTime?: number;
  response?: any;
  error?: string;
  timestamp: string;
}

export function APIEndpointManager() {
  const { toast } = useToast();
  const [endpoints, setEndpoints] = useState<APIEndpoint[]>([]);
  const [currentEndpoint, setCurrentEndpoint] = useState<APIEndpoint>({
    id: '',
    name: '',
    description: '',
    method: 'GET',
    url: '',
    headers: [],
    authentication: { type: 'none' },
    responseFormat: 'json',
    timeout: 30000,
    retries: 3,
    created_at: new Date().toISOString()
  });
  const [testResults, setTestResults] = useState<APITest[]>([]);
  const [isEditing, setIsEditing] = useState(false);

  const httpMethods = [
    { value: 'GET', label: 'GET', color: 'bg-green-500' },
    { value: 'POST', label: 'POST', color: 'bg-blue-500' },
    { value: 'PUT', label: 'PUT', color: 'bg-orange-500' },
    { value: 'DELETE', label: 'DELETE', color: 'bg-red-500' },
    { value: 'PATCH', label: 'PATCH', color: 'bg-purple-500' }
  ];

  const authTypes = [
    { value: 'none', label: 'No Authentication' },
    { value: 'bearer', label: 'Bearer Token' },
    { value: 'api-key', label: 'API Key' },
    { value: 'basic', label: 'Basic Auth' }
  ];

  const addHeader = () => {
    setCurrentEndpoint(prev => ({
      ...prev,
      headers: [...prev.headers, { key: '', value: '', enabled: true }]
    }));
  };

  const updateHeader = (index: number, updates: Partial<APIHeader>) => {
    setCurrentEndpoint(prev => ({
      ...prev,
      headers: prev.headers.map((header, i) => 
        i === index ? { ...header, ...updates } : header
      )
    }));
  };

  const removeHeader = (index: number) => {
    setCurrentEndpoint(prev => ({
      ...prev,
      headers: prev.headers.filter((_, i) => i !== index)
    }));
  };

  const saveEndpoint = () => {
    if (!currentEndpoint.name.trim() || !currentEndpoint.url.trim()) {
      toast({
        title: "Validation Error",
        description: "Name and URL are required",
        variant: "destructive"
      });
      return;
    }

    const endpointToSave = {
      ...currentEndpoint,
      id: currentEndpoint.id || `endpoint_${Date.now()}`,
      created_at: currentEndpoint.created_at || new Date().toISOString()
    };

    setEndpoints(prev => {
      const existing = prev.find(e => e.id === endpointToSave.id);
      if (existing) {
        return prev.map(e => e.id === endpointToSave.id ? endpointToSave : e);
      }
      return [...prev, endpointToSave];
    });

    toast({
      title: "Endpoint Saved",
      description: `"${endpointToSave.name}" has been saved successfully`
    });

    setIsEditing(false);
    resetForm();
  };

  const loadEndpoint = (endpoint: APIEndpoint) => {
    setCurrentEndpoint(endpoint);
    setIsEditing(true);
  };

  const deleteEndpoint = (endpointId: string) => {
    setEndpoints(prev => prev.filter(e => e.id !== endpointId));
    setTestResults(prev => prev.filter(t => t.endpointId !== endpointId));
    
    if (currentEndpoint.id === endpointId) {
      resetForm();
      setIsEditing(false);
    }

    toast({
      title: "Endpoint Deleted",
      description: "Endpoint has been removed"
    });
  };

  const resetForm = () => {
    setCurrentEndpoint({
      id: '',
      name: '',
      description: '',
      method: 'GET',
      url: '',
      headers: [],
      authentication: { type: 'none' },
      responseFormat: 'json',
      timeout: 30000,
      retries: 3,
      created_at: new Date().toISOString()
    });
  };

  const testEndpoint = async (endpoint: APIEndpoint) => {
    const testId = `test_${Date.now()}`;
    
    // Add pending test result
    const pendingTest: APITest = {
      endpointId: endpoint.id,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    
    setTestResults(prev => [pendingTest, ...prev]);

    try {
      const startTime = Date.now();
      
      // Prepare headers
      const headers: Record<string, string> = {};
      endpoint.headers.filter(h => h.enabled && h.key).forEach(header => {
        headers[header.key] = header.value;
      });

      // Add authentication headers
      if (endpoint.authentication.type === 'bearer' && endpoint.authentication.token) {
        headers['Authorization'] = `Bearer ${endpoint.authentication.token}`;
      } else if (endpoint.authentication.type === 'api-key' && endpoint.authentication.keyName && endpoint.authentication.keyValue) {
        headers[endpoint.authentication.keyName] = endpoint.authentication.keyValue;
      } else if (endpoint.authentication.type === 'basic' && endpoint.authentication.username && endpoint.authentication.password) {
        const credentials = btoa(`${endpoint.authentication.username}:${endpoint.authentication.password}`);
        headers['Authorization'] = `Basic ${credentials}`;
      }

      // Set content type for POST/PUT/PATCH requests
      if (['POST', 'PUT', 'PATCH'].includes(endpoint.method) && !headers['Content-Type']) {
        headers['Content-Type'] = 'application/json';
      }

      const requestOptions: RequestInit = {
        method: endpoint.method,
        headers
      };

      if (['POST', 'PUT', 'PATCH'].includes(endpoint.method) && endpoint.body) {
        requestOptions.body = endpoint.body;
      }

      const response = await fetch(endpoint.url, requestOptions);
      const responseTime = Date.now() - startTime;
      
      let responseData;
      const contentType = response.headers.get('content-type');
      
      if (contentType?.includes('application/json')) {
        responseData = await response.json();
      } else {
        responseData = await response.text();
      }

      const successTest: APITest = {
        endpointId: endpoint.id,
        status: response.ok ? 'success' : 'error',
        statusCode: response.status,
        responseTime,
        response: responseData,
        error: response.ok ? undefined : `HTTP ${response.status} ${response.statusText}`,
        timestamp: new Date().toISOString()
      };

      setTestResults(prev => prev.map(test => 
        test.endpointId === endpoint.id && test.status === 'pending' ? successTest : test
      ));

      toast({
        title: response.ok ? "Test Successful" : "Test Failed",
        description: `${endpoint.method} ${endpoint.url} - ${response.status} (${responseTime}ms)`,
        variant: response.ok ? "default" : "destructive"
      });

    } catch (error) {
      const errorTest: APITest = {
        endpointId: endpoint.id,
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      };

      setTestResults(prev => prev.map(test => 
        test.endpointId === endpoint.id && test.status === 'pending' ? errorTest : test
      ));

      toast({
        title: "Test Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const copyEndpoint = (endpoint: APIEndpoint) => {
    const copied = {
      ...endpoint,
      id: '',
      name: `${endpoint.name} (Copy)`,
      created_at: new Date().toISOString()
    };
    setCurrentEndpoint(copied);
    setIsEditing(true);
  };

  const getMethodColor = (method: string) => {
    return httpMethods.find(m => m.value === method)?.color || 'bg-gray-500';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">API Endpoint Manager</h3>
          <p className="text-sm text-muted-foreground">Configure and test API endpoints</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={() => {
              resetForm();
              setIsEditing(!isEditing);
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Endpoint
          </Button>
        </div>
      </div>

      <Tabs defaultValue="endpoints" className="space-y-4">
        <TabsList>
          <TabsTrigger value="endpoints">Endpoints ({endpoints.length})</TabsTrigger>
          <TabsTrigger value="editor">Editor</TabsTrigger>
          <TabsTrigger value="tests">Test Results</TabsTrigger>
        </TabsList>

        <TabsContent value="endpoints">
          <div className="space-y-4">
            {endpoints.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Globe className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Endpoints</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    Create your first API endpoint to get started
                  </p>
                  <Button onClick={() => setIsEditing(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Endpoint
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {endpoints.map(endpoint => {
                  const lastTest = testResults.find(t => t.endpointId === endpoint.id);
                  
                  return (
                    <Card key={endpoint.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="py-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 flex-1">
                            <Badge className={`${getMethodColor(endpoint.method)} text-white`}>
                              {endpoint.method}
                            </Badge>
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{endpoint.name}</h4>
                                {endpoint.authentication.type !== 'none' && (
                                  <Lock className="w-3 h-3 text-muted-foreground" />
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground font-mono">
                                {endpoint.url}
                              </p>
                              {endpoint.description && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {endpoint.description}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {lastTest && (
                              <Badge 
                                variant={lastTest.status === 'success' ? 'default' : 'destructive'}
                                className="text-xs"
                              >
                                {lastTest.status === 'success' 
                                  ? `${lastTest.statusCode} (${lastTest.responseTime}ms)`
                                  : lastTest.status === 'error' 
                                    ? 'Error' 
                                    : 'Testing...'
                                }
                              </Badge>
                            )}
                            
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => testEndpoint(endpoint)}
                            >
                              <Play className="w-3 h-3" />
                            </Button>
                            
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => copyEndpoint(endpoint)}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                            
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => loadEndpoint(endpoint)}
                            >
                              Edit
                            </Button>
                            
                            <Button 
                              size="sm" 
                              variant="ghost"
                              onClick={() => deleteEndpoint(endpoint.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="editor">
          {isEditing ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Endpoint Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="endpoint-name">Name</Label>
                      <Input
                        id="endpoint-name"
                        value={currentEndpoint.name}
                        onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="My API Endpoint"
                      />
                    </div>

                    <div>
                      <Label htmlFor="endpoint-description">Description</Label>
                      <Input
                        id="endpoint-description"
                        value={currentEndpoint.description}
                        onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Endpoint description"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label>Method</Label>
                        <Select
                          value={currentEndpoint.method}
                          onValueChange={(value) => setCurrentEndpoint(prev => ({ 
                            ...prev, 
                            method: value as APIEndpoint['method'] 
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {httpMethods.map(method => (
                              <SelectItem key={method.value} value={method.value}>
                                {method.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="col-span-2">
                        <Label htmlFor="endpoint-url">URL</Label>
                        <Input
                          id="endpoint-url"
                          value={currentEndpoint.url}
                          onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, url: e.target.value }))}
                          placeholder="https://api.example.com/endpoint"
                        />
                      </div>
                    </div>

                    {['POST', 'PUT', 'PATCH'].includes(currentEndpoint.method) && (
                      <div>
                        <Label htmlFor="request-body">Request Body</Label>
                        <Textarea
                          id="request-body"
                          value={currentEndpoint.body || ''}
                          onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, body: e.target.value }))}
                          placeholder='{"key": "value"}'
                          rows={4}
                          className="font-mono text-sm"
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Headers</CardTitle>
                      <Button size="sm" onClick={addHeader}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Header
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {currentEndpoint.headers.map((header, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          placeholder="Header key"
                          value={header.key}
                          onChange={(e) => updateHeader(index, { key: e.target.value })}
                        />
                        <Input
                          placeholder="Header value"
                          value={header.value}
                          onChange={(e) => updateHeader(index, { value: e.target.value })}
                        />
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => removeHeader(index)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Authentication</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Type</Label>
                      <Select
                        value={currentEndpoint.authentication.type}
                        onValueChange={(value) => setCurrentEndpoint(prev => ({ 
                          ...prev, 
                          authentication: { 
                            ...prev.authentication, 
                            type: value as APIEndpoint['authentication']['type']
                          } 
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {authTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {currentEndpoint.authentication.type === 'bearer' && (
                      <div>
                        <Label>Bearer Token</Label>
                        <Input
                          type="password"
                          value={currentEndpoint.authentication.token || ''}
                          onChange={(e) => setCurrentEndpoint(prev => ({ 
                            ...prev, 
                            authentication: { ...prev.authentication, token: e.target.value }
                          }))}
                          placeholder="Your bearer token"
                        />
                      </div>
                    )}

                    {currentEndpoint.authentication.type === 'api-key' && (
                      <div className="space-y-2">
                        <div>
                          <Label>Key Name</Label>
                          <Input
                            value={currentEndpoint.authentication.keyName || ''}
                            onChange={(e) => setCurrentEndpoint(prev => ({ 
                              ...prev, 
                              authentication: { ...prev.authentication, keyName: e.target.value }
                            }))}
                            placeholder="X-API-Key"
                          />
                        </div>
                        <div>
                          <Label>Key Value</Label>
                          <Input
                            type="password"
                            value={currentEndpoint.authentication.keyValue || ''}
                            onChange={(e) => setCurrentEndpoint(prev => ({ 
                              ...prev, 
                              authentication: { ...prev.authentication, keyValue: e.target.value }
                            }))}
                            placeholder="Your API key"
                          />
                        </div>
                      </div>
                    )}

                    {currentEndpoint.authentication.type === 'basic' && (
                      <div className="space-y-2">
                        <div>
                          <Label>Username</Label>
                          <Input
                            value={currentEndpoint.authentication.username || ''}
                            onChange={(e) => setCurrentEndpoint(prev => ({ 
                              ...prev, 
                              authentication: { ...prev.authentication, username: e.target.value }
                            }))}
                            placeholder="Username"
                          />
                        </div>
                        <div>
                          <Label>Password</Label>
                          <Input
                            type="password"
                            value={currentEndpoint.authentication.password || ''}
                            onChange={(e) => setCurrentEndpoint(prev => ({ 
                              ...prev, 
                              authentication: { ...prev.authentication, password: e.target.value }
                            }))}
                            placeholder="Password"
                          />
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Advanced Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Response Format</Label>
                      <Select
                        value={currentEndpoint.responseFormat}
                        onValueChange={(value) => setCurrentEndpoint(prev => ({ 
                          ...prev, 
                          responseFormat: value as APIEndpoint['responseFormat'] 
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="json">JSON</SelectItem>
                          <SelectItem value="xml">XML</SelectItem>
                          <SelectItem value="text">Text</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Timeout (ms)</Label>
                      <Input
                        type="number"
                        value={currentEndpoint.timeout}
                        onChange={(e) => setCurrentEndpoint(prev => ({ 
                          ...prev, 
                          timeout: parseInt(e.target.value) || 30000 
                        }))}
                        min={1000}
                        max={120000}
                      />
                    </div>

                    <div>
                      <Label>Retry Attempts</Label>
                      <Input
                        type="number"
                        value={currentEndpoint.retries}
                        onChange={(e) => setCurrentEndpoint(prev => ({ 
                          ...prev, 
                          retries: parseInt(e.target.value) || 0 
                        }))}
                        min={0}
                        max={10}
                      />
                    </div>
                  </CardContent>
                </Card>

                <div className="flex gap-2">
                  <Button onClick={saveEndpoint} className="flex-1">
                    Save Endpoint
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => testEndpoint(currentEndpoint)}
                    disabled={!currentEndpoint.url}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Test
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Globe className="w-12 h-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Endpoint Selected</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Select an endpoint to edit or create a new one
                </p>
                <Button onClick={() => setIsEditing(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Endpoint
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="tests">
          <div className="space-y-4">
            {testResults.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Play className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Test Results</h3>
                  <p className="text-muted-foreground text-center">
                    Test your endpoints to see results here
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {testResults.map((test, index) => {
                  const endpoint = endpoints.find(e => e.id === test.endpointId);
                  if (!endpoint) return null;
                  
                  return (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge className={`${getMethodColor(endpoint.method)} text-white`}>
                              {endpoint.method}
                            </Badge>
                            <span className="font-medium">{endpoint.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant={test.status === 'success' ? 'default' : 'destructive'}
                            >
                              {test.status}
                            </Badge>
                            {test.statusCode && (
                              <Badge variant="outline">{test.statusCode}</Badge>
                            )}
                            {test.responseTime && (
                              <Badge variant="outline">{test.responseTime}ms</Badge>
                            )}
                            <span className="text-xs text-muted-foreground">
                              {new Date(test.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="font-mono text-sm text-muted-foreground">
                          {endpoint.url}
                        </p>
                        
                        {test.error && (
                          <div className="p-3 bg-red-50 border border-red-200 rounded">
                            <p className="text-sm text-red-800 font-medium">Error:</p>
                            <p className="text-sm text-red-600">{test.error}</p>
                          </div>
                        )}
                        
                        {test.response && (
                          <div>
                            <p className="text-sm font-medium mb-2">Response:</p>
                            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto max-h-40">
                              {typeof test.response === 'string' 
                                ? test.response 
                                : JSON.stringify(test.response, null, 2)
                              }
                            </pre>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}