import React, { useState, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Type, 
  BarChart3, 
  Image, 
  MousePointer, 
  Trash2, 
  Move,
  Save,
  Upload,
  Download,
  Eye,
  Plus,
  Grid,
  Settings,
  PieChart,
  LineChart
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TemplateBlock {
  id: string;
  type: 'text' | 'chart' | 'image' | 'field';
  x: number;
  y: number;
  width: number;
  height: number;
  content?: string;
  fieldName?: string;
  chartType?: 'bar' | 'line' | 'pie';
  chartName?: string;
  styles?: Record<string, any>;
}

interface TemplateEditorProps {
  isOpen: boolean;
  onClose: () => void;
  templateId?: string;
  onSave?: (template: any) => void;
}

export function TemplateEditor({ isOpen, onClose, templateId, onSave }: TemplateEditorProps) {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLDivElement>(null);
  
  const [templateName, setTemplateName] = useState('');
  const [templateCategory, setTemplateCategory] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  const [blocks, setBlocks] = useState<TemplateBlock[]>([]);
  const [selectedBlock, setSelectedBlock] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [activeTab, setActiveTab] = useState('design');
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  // Available field placeholders
  const availableFields = [
    { name: 'memo_ref', label: 'Memo Reference', category: 'memo' },
    { name: 'officer', label: 'Testing Officer', category: 'memo' },
    { name: 'plant', label: 'Plant/Site', category: 'memo' },
    { name: 'product', label: 'Product Type', category: 'memo' },
    { name: 'sampling_date', label: 'Sampling Date', category: 'memo' },
    { name: 'remarks', label: 'Remarks', category: 'memo' },
    { name: 'compressive_strength', label: 'Compressive Strength', category: 'test' },
    { name: 'moisture', label: 'Moisture Content', category: 'test' },
    { name: 'fineness_modulus', label: 'Fineness Modulus', category: 'test' },
    { name: 'bulk_modulus', label: 'Bulk Modulus', category: 'test' },
    { name: 'specific_gravity', label: 'Specific Gravity', category: 'test' }
  ];

  // Available charts
  const availableCharts = [
    { name: 'StrengthOverTime', label: 'Strength Over Time', type: 'line' },
    { name: 'SieveAnalysis', label: 'Sieve Analysis', type: 'bar' },
    { name: 'ConformityChart', label: 'Conformity Distribution', type: 'pie' },
    { name: 'FinenessModulusTrend', label: 'Fineness Modulus Trend', type: 'line' },
    { name: 'MonthlyPerformance', label: 'Monthly Performance', type: 'bar' }
  ];

  const addTextBlock = useCallback(() => {
    const newBlock: TemplateBlock = {
      id: `text-${Date.now()}`,
      type: 'text',
      x: 50,
      y: 50,
      width: 200,
      height: 40,
      content: 'Sample Text',
      styles: { fontSize: '14px', fontWeight: 'normal', color: '#000000' }
    };
    setBlocks(prev => [...prev, newBlock]);
    setSelectedBlock(newBlock.id);
    toast({ title: "Text Block Added", description: "Drag to position and edit content." });
  }, [toast]);

  const addChartBlock = useCallback((chartType: 'bar' | 'line' | 'pie', chartName: string) => {
    const newBlock: TemplateBlock = {
      id: `chart-${Date.now()}`,
      type: 'chart',
      x: 100,
      y: 100,
      width: 300,
      height: 200,
      chartType,
      chartName,
      styles: { border: '1px solid #ccc', borderRadius: '4px' }
    };
    setBlocks(prev => [...prev, newBlock]);
    setSelectedBlock(newBlock.id);
    toast({ title: "Chart Block Added", description: `${chartName} chart added to template.` });
  }, [toast]);

  const addFieldBlock = useCallback((fieldName: string) => {
    const field = availableFields.find(f => f.name === fieldName);
    const newBlock: TemplateBlock = {
      id: `field-${Date.now()}`,
      type: 'field',
      x: 75,
      y: 75,
      width: 150,
      height: 30,
      fieldName,
      content: `<field name="${fieldName}" />`,
      styles: { fontSize: '12px', fontWeight: 'bold', color: '#333333' }
    };
    setBlocks(prev => [...prev, newBlock]);
    setSelectedBlock(newBlock.id);
    toast({ title: "Field Added", description: `${field?.label} field added to template.` });
  }, [toast]);

  const addImageBlock = useCallback(() => {
    const newBlock: TemplateBlock = {
      id: `image-${Date.now()}`,
      type: 'image',
      x: 125,
      y: 125,
      width: 150,
      height: 100,
      content: '/logo-placeholder.png',
      styles: { border: '1px dashed #ccc' }
    };
    setBlocks(prev => [...prev, newBlock]);
    setSelectedBlock(newBlock.id);
    toast({ title: "Image Block Added", description: "Click to upload an image or logo." });
  }, [toast]);

  const deleteBlock = useCallback((blockId: string) => {
    setBlocks(prev => prev.filter(block => block.id !== blockId));
    if (selectedBlock === blockId) {
      setSelectedBlock(null);
    }
    toast({ title: "Block Deleted", description: "Template block removed successfully." });
  }, [selectedBlock, toast]);

  const updateBlock = useCallback((blockId: string, updates: Partial<TemplateBlock>) => {
    setBlocks(prev => prev.map(block => 
      block.id === blockId ? { ...block, ...updates } : block
    ));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent, blockId: string) => {
    e.preventDefault();
    setSelectedBlock(blockId);
    setIsDragging(true);
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
      const block = blocks.find(b => b.id === blockId);
      if (block) {
        setDragOffset({
          x: e.clientX - rect.left - block.x,
          y: e.clientY - rect.top - block.y
        });
      }
    }
  }, [blocks]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !selectedBlock || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const newX = Math.max(0, e.clientX - rect.left - dragOffset.x);
    const newY = Math.max(0, e.clientY - rect.top - dragOffset.y);
    
    updateBlock(selectedBlock, { x: newX, y: newY });
  }, [isDragging, selectedBlock, dragOffset, updateBlock]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const saveTemplate = useCallback(async () => {
    if (!templateName.trim()) {
      toast({ 
        title: "Validation Error", 
        description: "Please enter a template name.",
        variant: "destructive"
      });
      return;
    }

    const templateData = {
      id: templateId || `template-${Date.now()}`,
      name: templateName,
      category: templateCategory,
      description: templateDescription,
      blocks,
      layout: {
        width: 800,
        height: 600
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    try {
      // Save to local storage for now
      const savedTemplates = JSON.parse(localStorage.getItem('custom_templates') || '[]');
      const existingIndex = savedTemplates.findIndex((t: any) => t.id === templateData.id);
      
      if (existingIndex >= 0) {
        savedTemplates[existingIndex] = templateData;
      } else {
        savedTemplates.push(templateData);
      }
      
      localStorage.setItem('custom_templates', JSON.stringify(savedTemplates));
      
      if (onSave) {
        onSave(templateData);
      }
      
      toast({ 
        title: "Template Saved", 
        description: `Template "${templateName}" saved successfully.` 
      });
      
      onClose();
    } catch (error) {
      toast({ 
        title: "Save Failed", 
        description: "Failed to save template. Please try again.",
        variant: "destructive"
      });
    }
  }, [templateName, templateCategory, templateDescription, blocks, templateId, onSave, onClose, toast]);

  const loadTemplate = useCallback((templateData: string) => {
    try {
      const data = JSON.parse(templateData);
      setTemplateName(data.name || '');
      setTemplateCategory(data.category || '');
      setTemplateDescription(data.description || '');
      setBlocks(data.blocks || []);
      toast({ title: "Template Loaded", description: "Template loaded successfully." });
    } catch (error) {
      toast({ 
        title: "Load Failed", 
        description: "Invalid template format.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const exportTemplate = useCallback(() => {
    const templateData = {
      name: templateName,
      category: templateCategory,
      description: templateDescription,
      blocks,
      layout: { width: 800, height: 600 }
    };
    
    const dataStr = JSON.stringify(templateData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${templateName || 'template'}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast({ title: "Export Complete", description: "Template exported as JSON file." });
  }, [templateName, templateCategory, templateDescription, blocks, toast]);

  const previewTemplate = useCallback(() => {
    setIsPreviewMode(!isPreviewMode);
    toast({ 
      title: isPreviewMode ? "Edit Mode" : "Preview Mode", 
      description: isPreviewMode ? "Returned to edit mode." : "Preview mode activated." 
    });
  }, [isPreviewMode, toast]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-7xl h-[90vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 border-b">
          <CardTitle className="flex items-center space-x-2">
            <Grid className="h-5 w-5" />
            <span>Template Editor</span>
            {isPreviewMode && <Badge variant="secondary">Preview Mode</Badge>}
          </CardTitle>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={previewTemplate}>
              <Eye className="h-4 w-4 mr-1" />
              {isPreviewMode ? 'Edit' : 'Preview'}
            </Button>
            <Button variant="outline" size="sm" onClick={exportTemplate}>
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
            <Button size="sm" onClick={saveTemplate}>
              <Save className="h-4 w-4 mr-1" />
              Save
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>

        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar - Tools */}
          <div className="w-80 border-r bg-muted/30 overflow-y-auto">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-3 mx-2 mt-2">
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="blocks">Blocks</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>

              <TabsContent value="design" className="flex-1 p-4 space-y-4">
                <div className="space-y-3">
                  <Label htmlFor="templateName">Template Name</Label>
                  <Input
                    id="templateName"
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                    placeholder="Enter template name"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="templateCategory">Category</Label>
                  <Select value={templateCategory} onValueChange={setTemplateCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Certificate">Certificate</SelectItem>
                      <SelectItem value="Summary">Summary</SelectItem>
                      <SelectItem value="Quality">Quality</SelectItem>
                      <SelectItem value="Analytics">Analytics</SelectItem>
                      <SelectItem value="Compliance">Compliance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="templateDescription">Description</Label>
                  <Textarea
                    id="templateDescription"
                    value={templateDescription}
                    onChange={(e) => setTemplateDescription(e.target.value)}
                    placeholder="Describe this template"
                    rows={3}
                  />
                </div>

                <div className="space-y-3">
                  <Label>Quick Actions</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm" onClick={addTextBlock}>
                      <Type className="h-4 w-4 mr-1" />
                      Text
                    </Button>
                    <Button variant="outline" size="sm" onClick={addImageBlock}>
                      <Image className="h-4 w-4 mr-1" />
                      Image
                    </Button>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="blocks" className="flex-1 p-4 space-y-4">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Data Fields</Label>
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {availableFields.map((field) => (
                        <Button
                          key={field.name}
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-xs"
                          onClick={() => addFieldBlock(field.name)}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          {field.label}
                          <Badge variant="outline" className="ml-auto text-xs">
                            {field.category}
                          </Badge>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">Charts</Label>
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {availableCharts.map((chart) => (
                        <Button
                          key={chart.name}
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-xs"
                          onClick={() => addChartBlock(chart.type as any, chart.name)}
                        >
                          {chart.type === 'bar' && <BarChart3 className="h-3 w-3 mr-1" />}
                          {chart.type === 'line' && <LineChart className="h-3 w-3 mr-1" />}
                          {chart.type === 'pie' && <PieChart className="h-3 w-3 mr-1" />}
                          {chart.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="settings" className="flex-1 p-4 space-y-4">
                {selectedBlock ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Selected Block</Label>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteBlock(selectedBlock)}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                    
                    {(() => {
                      const block = blocks.find(b => b.id === selectedBlock);
                      if (!block) return null;
                      
                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <Label className="text-xs">X Position</Label>
                              <Input
                                type="number"
                                value={block.x}
                                onChange={(e) => updateBlock(selectedBlock, { x: parseInt(e.target.value) || 0 })}
                                className="text-xs"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Y Position</Label>
                              <Input
                                type="number"
                                value={block.y}
                                onChange={(e) => updateBlock(selectedBlock, { y: parseInt(e.target.value) || 0 })}
                                className="text-xs"
                              />
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <Label className="text-xs">Width</Label>
                              <Input
                                type="number"
                                value={block.width}
                                onChange={(e) => updateBlock(selectedBlock, { width: parseInt(e.target.value) || 100 })}
                                className="text-xs"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Height</Label>
                              <Input
                                type="number"
                                value={block.height}
                                onChange={(e) => updateBlock(selectedBlock, { height: parseInt(e.target.value) || 50 })}
                                className="text-xs"
                              />
                            </div>
                          </div>

                          {block.type === 'text' && (
                            <div>
                              <Label className="text-xs">Content</Label>
                              <Textarea
                                value={block.content || ''}
                                onChange={(e) => updateBlock(selectedBlock, { content: e.target.value })}
                                className="text-xs"
                                rows={2}
                              />
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="text-center py-8">
                      <Settings className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                      <h3 className="font-medium text-muted-foreground">No Block Selected</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Select a block from the canvas to edit its properties
                      </p>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium">Template Statistics</Label>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div className="p-2 bg-muted rounded text-center">
                            <div className="text-lg font-bold">{blocks.length}</div>
                            <div className="text-xs text-muted-foreground">Total Blocks</div>
                          </div>
                          <div className="p-2 bg-muted rounded text-center">
                            <div className="text-lg font-bold">
                              {blocks.filter(b => b.type === 'text').length}
                            </div>
                            <div className="text-xs text-muted-foreground">Text Blocks</div>
                          </div>
                          <div className="p-2 bg-muted rounded text-center">
                            <div className="text-lg font-bold">
                              {blocks.filter(b => b.type === 'field').length}
                            </div>
                            <div className="text-xs text-muted-foreground">Data Fields</div>
                          </div>
                          <div className="p-2 bg-muted rounded text-center">
                            <div className="text-lg font-bold">
                              {blocks.filter(b => b.type === 'chart').length}
                            </div>
                            <div className="text-xs text-muted-foreground">Charts</div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <Label className="text-sm font-medium">Quick Actions</Label>
                        <div className="space-y-2 mt-2">
                          <Button variant="outline" size="sm" className="w-full justify-start" onClick={addTextBlock}>
                            <Type className="h-4 w-4 mr-2" />
                            Add Text Block
                          </Button>
                          <Button variant="outline" size="sm" className="w-full justify-start" onClick={addImageBlock}>
                            <Image className="h-4 w-4 mr-2" />
                            Add Image Block
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="w-full justify-start" 
                            onClick={() => addChartBlock('bar', 'Sample Chart')}
                          >
                            <BarChart3 className="h-4 w-4 mr-2" />
                            Add Chart Block
                          </Button>
                        </div>
                      </div>

                      <div>
                        <Label className="text-sm font-medium">Instructions</Label>
                        <div className="text-xs text-muted-foreground space-y-1 mt-2">
                          <p>• Add blocks from the Blocks tab</p>
                          <p>• Click on a block to select it</p>
                          <p>• Drag blocks to reposition them</p>
                          <p>• Use Settings to configure properties</p>
                          <p>• Preview your template before saving</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Main Canvas */}
          <div className="flex-1 p-4 overflow-auto bg-background">
            <div
              ref={canvasRef}
              className="relative w-full h-[600px] bg-white border-2 border-dashed border-muted-foreground/30 rounded-lg mx-auto"
              style={{ maxWidth: '800px' }}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {blocks.map((block) => (
                <div
                  key={block.id}
                  className={`absolute border cursor-pointer transition-all ${
                    selectedBlock === block.id
                      ? 'border-blue-500 bg-blue-50/50'
                      : 'border-gray-300 hover:border-gray-400'
                  } ${isPreviewMode ? 'cursor-default' : 'cursor-move'}`}
                  style={{
                    left: block.x,
                    top: block.y,
                    width: block.width,
                    height: block.height,
                    ...block.styles
                  }}
                  onMouseDown={(e) => !isPreviewMode && handleMouseDown(e, block.id)}
                >
                  <div className="w-full h-full p-2 text-xs overflow-hidden">
                    {block.type === 'text' && (
                      <div className="w-full h-full flex items-center">
                        {block.content || 'Text Block'}
                      </div>
                    )}
                    {block.type === 'field' && (
                      <div className="w-full h-full flex items-center font-mono text-blue-600">
                        {isPreviewMode ? `[${block.fieldName}]` : block.content}
                      </div>
                    )}
                    {block.type === 'chart' && (
                      <div className="w-full h-full flex items-center justify-center bg-gray-50 border rounded">
                        {block.chartType === 'bar' && <BarChart3 className="h-6 w-6 text-gray-400" />}
                        {block.chartType === 'line' && <LineChart className="h-6 w-6 text-gray-400" />}
                        {block.chartType === 'pie' && <PieChart className="h-6 w-6 text-gray-400" />}
                        <span className="ml-2 text-gray-500">{block.chartName}</span>
                      </div>
                    )}
                    {block.type === 'image' && (
                      <div className="w-full h-full flex items-center justify-center bg-gray-50 border rounded">
                        <Image className="h-6 w-6 text-gray-400" />
                        <span className="ml-2 text-gray-500">Logo/Image</span>
                      </div>
                    )}
                  </div>
                  
                  {!isPreviewMode && selectedBlock === block.id && (
                    <div className="absolute -top-1 -right-1">
                      <Button
                        variant="destructive"
                        size="sm"
                        className="h-5 w-5 p-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteBlock(block.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
              
              {blocks.length === 0 && !isPreviewMode && (
                <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <Grid className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-medium">Empty Template</p>
                    <p className="text-sm">Add blocks from the sidebar to start designing</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}