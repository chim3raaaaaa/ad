import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Save, X, Flag } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { EmptyState } from "@/components/ui/empty-state";

interface DiscrepancyCategory {
  id: string;
  name: string;
  description: string;
  priority: 'minor' | 'major' | 'critical';
  resolution_template: string;
  auto_assign_role?: string;
  escalation_rules?: string;
  is_active: boolean;
}

export function DiscrepancyCategoryManager() {
  const { toast } = useToast();
  const [categories, setCategories] = useState<DiscrepancyCategory[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<DiscrepancyCategory | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    description: string;
    priority: 'minor' | 'major' | 'critical';
    resolution_template: string;
    auto_assign_role: string;
    escalation_rules: string;
  }>({
    name: "",
    description: "",
    priority: "minor",
    resolution_template: "",
    auto_assign_role: "",
    escalation_rules: ""
  });
  const [loading, setLoading] = useState(false);

  // Default categories to populate initially
  const defaultCategories: Omit<DiscrepancyCategory, 'id'>[] = [
    {
      name: "Technical Issues",
      description: "Problems related to technical specifications, calculations, or test procedures",
      priority: "major",
      resolution_template: "Review technical specifications and verify calculations. Consult with technical team if needed.",
      auto_assign_role: "technical_lead",
      escalation_rules: "Escalate to engineering manager if not resolved within 24 hours",
      is_active: true
    },
    {
      name: "Documentation Issues",
      description: "Missing information, incomplete forms, or unclear documentation",
      priority: "minor",
      resolution_template: "Request complete documentation from memo creator. Provide clear guidelines for required information.",
      auto_assign_role: "lab_technician",
      escalation_rules: "Escalate to lab manager if documentation remains incomplete after 48 hours",
      is_active: true
    },
    {
      name: "Safety Concerns",
      description: "Safety-related issues that may pose risks to personnel or operations",
      priority: "critical",
      resolution_template: "Immediately address safety concerns. Halt operations if necessary until resolution.",
      auto_assign_role: "safety_officer",
      escalation_rules: "Immediate escalation to safety manager and operations director",
      is_active: true
    },
    {
      name: "Compliance Issues",
      description: "Violations of regulatory requirements or company standards",
      priority: "major",
      resolution_template: "Review compliance requirements and ensure full adherence to standards.",
      auto_assign_role: "compliance_officer",
      escalation_rules: "Escalate to compliance manager within 12 hours",
      is_active: true
    }
  ];

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      setLoading(true);
      // Try to load from localStorage first
      const storedCategories = localStorage.getItem('discrepancy-categories');
      
      if (storedCategories) {
        setCategories(JSON.parse(storedCategories));
      } else {
        // Initialize with default categories
        const categoriesWithIds = defaultCategories.map(cat => ({
          ...cat,
          id: crypto.randomUUID()
        }));
        setCategories(categoriesWithIds);
        localStorage.setItem('discrepancy-categories', JSON.stringify(categoriesWithIds));
      }
    } catch (error) {
      console.error('Error loading discrepancy categories:', error);
      toast({
        title: "Error",
        description: "Failed to load discrepancy categories",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      priority: "minor",
      resolution_template: "",
      auto_assign_role: "",
      escalation_rules: ""
    });
  };

  const handleCreateCategory = () => {
    resetForm();
    setEditingCategory(null);
    setShowCreateDialog(true);
  };

  const handleEditCategory = (category: DiscrepancyCategory) => {
    setFormData({
      name: category.name,
      description: category.description,
      priority: category.priority,
      resolution_template: category.resolution_template,
      auto_assign_role: category.auto_assign_role || "",
      escalation_rules: category.escalation_rules || ""
    });
    setEditingCategory(category);
    setShowCreateDialog(true);
  };

  const handleSaveCategory = async () => {
    if (!formData.name || !formData.description) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      const categoryData: DiscrepancyCategory = {
        id: editingCategory?.id || crypto.randomUUID(),
        name: formData.name,
        description: formData.description,
        priority: formData.priority,
        resolution_template: formData.resolution_template,
        auto_assign_role: formData.auto_assign_role || undefined,
        escalation_rules: formData.escalation_rules || undefined,
        is_active: true
      };

      let updatedCategories: DiscrepancyCategory[];
      
      if (editingCategory) {
        updatedCategories = categories.map(cat => 
          cat.id === editingCategory.id ? categoryData : cat
        );
      } else {
        updatedCategories = [...categories, categoryData];
      }

      setCategories(updatedCategories);
      localStorage.setItem('discrepancy-categories', JSON.stringify(updatedCategories));

      toast({
        title: "Success",
        description: editingCategory ? "Category updated successfully" : "Category created successfully"
      });

      setShowCreateDialog(false);
      resetForm();
      setEditingCategory(null);
    } catch (error) {
      console.error('Error saving category:', error);
      toast({
        title: "Error",
        description: "Failed to save category",
        variant: "destructive"
      });
    }
  };

  const handleDeleteCategory = (categoryId: string) => {
    const updatedCategories = categories.filter(cat => cat.id !== categoryId);
    setCategories(updatedCategories);
    localStorage.setItem('discrepancy-categories', JSON.stringify(updatedCategories));
    
    toast({
      title: "Success",
      description: "Category deleted successfully"
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'major': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'minor': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Discrepancy Categories</CardTitle>
          <CardDescription>Loading categories...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Discrepancy Categories</CardTitle>
            <CardDescription>
              Manage categories used for flagging memo discrepancies
            </CardDescription>
          </div>
          <Button onClick={handleCreateCategory}>
            <Plus className="h-4 w-4 mr-2" />
            Create Category
          </Button>
        </CardHeader>
        <CardContent>
          {categories.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <Flag className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No discrepancy categories configured</h3>
              <p className="text-muted-foreground mb-4">Create your first discrepancy category to get started</p>
              <Button onClick={handleCreateCategory}>
                <Plus className="h-4 w-4 mr-2" />
                Create Category
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Auto Assign</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell className="font-medium">{category.name}</TableCell>
                    <TableCell className="max-w-xs truncate">{category.description}</TableCell>
                    <TableCell>
                      <Badge className={getPriorityColor(category.priority)}>
                        {category.priority}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {category.auto_assign_role ? (
                        <Badge variant="outline">{category.auto_assign_role}</Badge>
                      ) : (
                        <span className="text-muted-foreground">Manual</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={category.is_active ? "default" : "secondary"}>
                        {category.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditCategory(category)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteCategory(category.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? "Edit Category" : "Create New Category"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Category Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter category name"
                />
              </div>
              <div>
                <Label htmlFor="priority">Priority Level</Label>
                <Select
                  value={formData.priority}
                  onValueChange={(value: 'minor' | 'major' | 'critical') => 
                    setFormData(prev => ({ ...prev, priority: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minor">Minor</SelectItem>
                    <SelectItem value="major">Major</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe when this category should be used"
              />
            </div>

            <div>
              <Label htmlFor="resolution_template">Resolution Template</Label>
              <Textarea
                id="resolution_template"
                value={formData.resolution_template}
                onChange={(e) => setFormData(prev => ({ ...prev, resolution_template: e.target.value }))}
                placeholder="Standard steps for resolving this type of discrepancy"
              />
            </div>

            <div>
              <Label htmlFor="auto_assign_role">Auto Assign Role (Optional)</Label>
              <Input
                id="auto_assign_role"
                value={formData.auto_assign_role}
                onChange={(e) => setFormData(prev => ({ ...prev, auto_assign_role: e.target.value }))}
                placeholder="e.g., technical_lead, safety_officer"
              />
            </div>

            <div>
              <Label htmlFor="escalation_rules">Escalation Rules (Optional)</Label>
              <Textarea
                id="escalation_rules"
                value={formData.escalation_rules}
                onChange={(e) => setFormData(prev => ({ ...prev, escalation_rules: e.target.value }))}
                placeholder="Define when and how to escalate this type of discrepancy"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowCreateDialog(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveCategory}>
                <Save className="h-4 w-4 mr-2" />
                {editingCategory ? "Update" : "Create"} Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}