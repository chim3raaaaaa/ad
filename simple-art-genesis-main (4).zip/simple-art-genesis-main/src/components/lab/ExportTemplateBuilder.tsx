import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText, 
  Download, 
  Upload, 
  Save, 
  Copy, 
  Trash2, 
  Eye, 
  Settings,
  Image,
  Type,
  BarChart3,
  Table,
  Calendar,
  Signature,
  MapPin,
  Star,
  Plus,
  Grip,
  Edit,
  Palette,
  Layout,
  Archive
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TemplateElement {
  id: string;
  type: 'text' | 'image' | 'table' | 'chart' | 'signature' | 'date' | 'header' | 'footer';
  content: any;
  position: { x: number; y: number; width: number; height: number };
  styling: {
    fontSize?: string;
    fontWeight?: string;
    color?: string;
    backgroundColor?: string;
    alignment?: 'left' | 'center' | 'right';
    padding?: string;
    margin?: string;
  };
}

interface ExportTemplate {
  id: string;
  name: string;
  description: string;
  category: 'certificate' | 'report' | 'label' | 'custom';
  format: 'pdf' | 'excel' | 'word';
  pageSize: 'A4' | 'A3' | 'Letter' | 'Legal';
  orientation: 'portrait' | 'landscape';
  elements: TemplateElement[];
  branding: {
    logo?: string;
    companyName?: string;
    colors: {
      primary: string;
      secondary: string;
      accent: string;
    };
  };
  metadata: {
    createdAt: string;
    updatedAt: string;
    version: string;
    author: string;
  };
}

interface DraggedElement {
  type: string;
  id: string;
}

const elementTypes = [
  { type: 'text', label: 'Text Block', icon: Type, description: 'Add custom text content' },
  { type: 'image', label: 'Image', icon: Image, description: 'Insert images or logos' },
  { type: 'table', label: 'Data Table', icon: Table, description: 'Display tabular data' },
  { type: 'chart', label: 'Chart', icon: BarChart3, description: 'Add charts and graphs' },
  { type: 'signature', label: 'Signature', icon: Signature, description: 'Digital signature field' },
  { type: 'date', label: 'Date/Time', icon: Calendar, description: 'Current date and time' },
  { type: 'header', label: 'Header', icon: Layout, description: 'Page header section' },
  { type: 'footer', label: 'Footer', icon: Layout, description: 'Page footer section' }
];

const CanvasArea: React.FC<{
  template: ExportTemplate;
  onElementAdd: (element: TemplateElement) => void;
  onElementUpdate: (elementId: string, updates: Partial<TemplateElement>) => void;
  onElementDelete: (elementId: string) => void;
  selectedElement: string | null;
  onElementSelect: (elementId: string | null) => void;
  onEditElement: () => void;
}> = ({ template, onElementAdd, onElementUpdate, onElementDelete, selectedElement, onElementSelect, onEditElement }) => {
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    console.log('Drop event triggered');
    
    if (!canvasRef.current) {
      console.error('Canvas ref not available');
      return;
    }

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    console.log('Drop position:', { x, y });

    // Get the dragged element type from dataTransfer
    const elementType = e.dataTransfer.getData('text/plain');
    console.log('Element type from drag data:', elementType);
    
    if (!elementType) {
      console.error('No element type found in drag data');
      return;
    }

    const newElement: TemplateElement = {
      id: `${elementType}_${Date.now()}`,
      type: elementType as any,
      content: getDefaultContent(elementType),
      position: { x, y, width: 200, height: 50 },
      styling: {
        fontSize: '14px',
        fontWeight: 'normal',
        color: '#000000',
        alignment: 'left'
      }
    };

    console.log('Creating new element:', newElement);
    onElementAdd(newElement);
  };

  const getDefaultContent = (type: string) => {
    switch (type) {
      case 'text': return 'Sample text content';
      case 'image': return { src: '/placeholder-image.png', alt: 'Placeholder' };
      case 'table': return { headers: ['Column 1', 'Column 2'], rows: [['Data 1', 'Data 2']] };
      case 'chart': return { type: 'bar', data: [] };
      case 'signature': return { placeholder: 'Digital Signature' };
      case 'date': return { format: 'YYYY-MM-DD' };
      case 'header': return 'Document Header';
      case 'footer': return 'Document Footer';
      default: return '';
    }
  };

  const renderElement = (element: TemplateElement) => {
    const isSelected = selectedElement === element.id;

    const elementContent = () => {
      switch (element.type) {
        case 'text':
        case 'header':
        case 'footer':
          return (
            <div 
              className="p-2 text-sm w-full h-full flex items-center"
              style={{
                fontSize: element.styling.fontSize,
                fontWeight: element.styling.fontWeight,
                color: element.styling.color,
                textAlign: element.styling.alignment,
                backgroundColor: element.styling.backgroundColor || 'transparent',
                overflow: 'hidden'
              }}
            >
              {element.content}
            </div>
          );
        
        case 'image':
          return (
            <div className="flex items-center justify-center h-full w-full bg-gray-100 border-2 border-dashed border-gray-300">
              <Image className="w-8 h-8 text-gray-400" />
              <span className="ml-2 text-xs text-gray-500">Image</span>
            </div>
          );
        
        case 'table':
          return (
            <div className="text-xs w-full h-full overflow-auto">
              <table className="w-full h-full border-collapse border border-gray-300">
                <thead>
                  <tr>
                    {element.content.headers?.map((header: string, idx: number) => (
                      <th key={idx} className="border border-gray-300 p-1 bg-gray-50 text-xs">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {element.content.rows?.map((row: string[], idx: number) => (
                    <tr key={idx}>
                      {row.map((cell, cellIdx) => (
                        <td key={cellIdx} className="border border-gray-300 p-1 text-xs">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        
        case 'chart':
          return (
            <div className="flex items-center justify-center h-full w-full bg-blue-50 border border-blue-200">
              <BarChart3 className="w-8 h-8 text-blue-500" />
              <span className="ml-2 text-sm text-blue-600">Chart</span>
            </div>
          );
        
        case 'signature':
          return (
            <div className="flex items-center justify-center h-full w-full border-b-2 border-gray-400">
              <Signature className="w-6 h-6 text-gray-500 mr-2" />
              <span className="text-sm text-gray-500">Signature</span>
            </div>
          );
        
        case 'date':
          return (
            <div className="flex items-center p-2 h-full w-full">
              <Calendar className="w-4 h-4 mr-2" />
              <span className="text-sm">
                {new Date().toLocaleDateString()}
              </span>
            </div>
          );
        
        default:
          return <div className="p-2 text-sm w-full h-full flex items-center">{element.content}</div>;
      }
    };

    return (
      <div
        key={element.id}
        className={cn(
          "absolute border cursor-move overflow-hidden bg-white",
          isSelected ? "border-blue-500 bg-blue-50/20 z-10" : "border-gray-300",
          "hover:border-blue-400"
        )}
        style={{
          left: element.position.x,
          top: element.position.y,
          width: element.position.width,
          height: element.position.height,
          minWidth: '50px',
          minHeight: '30px'
        }}
        onClick={(e) => {
          e.stopPropagation();
          onElementSelect(element.id);
        }}
        onMouseDown={(e) => {
          if (isSelected) {
            e.stopPropagation();
            // Handle dragging
            const startX = e.clientX - element.position.x;
            const startY = e.clientY - element.position.y;
            
            const handleMouseMove = (moveEvent: MouseEvent) => {
              const newX = moveEvent.clientX - startX;
              const newY = moveEvent.clientY - startY;
              
              onElementUpdate(element.id, {
                position: {
                  ...element.position,
                  x: Math.max(0, newX),
                  y: Math.max(0, newY)
                }
              });
            };
            
            const handleMouseUp = () => {
              document.removeEventListener('mousemove', handleMouseMove);
              document.removeEventListener('mouseup', handleMouseUp);
            };
            
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
          }
        }}
      >
        {elementContent()}
        
        {isSelected && (
          <div className="absolute -top-8 left-0 flex gap-1 z-20">
            <Button 
              size="sm" 
              variant="secondary" 
              className="h-6 px-2 text-xs"
              onClick={(e) => {
                e.stopPropagation();
                onEditElement();
              }}
            >
              <Edit className="w-3 h-3" />
            </Button>
            <Button 
              size="sm" 
              variant="destructive" 
              className="h-6 px-2 text-xs"
              onClick={(e) => {
                e.stopPropagation();
                onElementDelete(element.id);
              }}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        )}
        
        {isSelected && (
          <div 
            className="absolute bottom-0 right-0 w-3 h-3 bg-blue-500 cursor-se-resize z-20"
            onMouseDown={(e) => {
              e.stopPropagation();
              const startX = e.clientX;
              const startY = e.clientY;
              const startWidth = element.position.width;
              const startHeight = element.position.height;
              
              const handleMouseMove = (moveEvent: MouseEvent) => {
                const newWidth = Math.max(50, startWidth + (moveEvent.clientX - startX));
                const newHeight = Math.max(30, startHeight + (moveEvent.clientY - startY));
                
                onElementUpdate(element.id, {
                  position: {
                    ...element.position,
                    width: newWidth,
                    height: newHeight
                  }
                });
              };
              
              const handleMouseUp = () => {
                document.removeEventListener('mousemove', handleMouseMove);
                document.removeEventListener('mouseup', handleMouseUp);
              };
              
              document.addEventListener('mousemove', handleMouseMove);
              document.addEventListener('mouseup', handleMouseUp);
            }}
          />
        )}
      </div>
    );
  };

  return (
    <div 
      ref={canvasRef}
      className="relative w-full h-[600px] bg-white border border-gray-300 shadow-inner overflow-hidden"
      style={{ 
        aspectRatio: template.orientation === 'portrait' ? '210/297' : '297/210' 
      }}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={() => onElementSelect(null)}
    >
      {/* Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px'
        }}
      />
      
      {/* Render Elements */}
      {template.elements.map(renderElement)}
      
      {/* Page Info */}
      <div className="absolute top-2 left-2 text-xs text-gray-500 bg-white px-2 py-1 rounded shadow">
        {template.pageSize} - {template.orientation}
      </div>
    </div>
  );
};

export default function ExportTemplateBuilder() {
  const [templates, setTemplates] = useState<ExportTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<ExportTemplate | null>(null);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Initialize with comprehensive templates
  useEffect(() => {
    const mockTemplates: ExportTemplate[] = [
      {
        id: 'concrete-test-cert',
        name: 'Concrete Test Certificate',
        description: 'Official certificate for concrete strength test results',
        category: 'certificate',
        format: 'pdf',
        pageSize: 'A4',
        orientation: 'portrait',
        elements: [
          {
            id: 'header_1',
            type: 'header',
            content: 'CONCRETE TEST CERTIFICATE',
            position: { x: 20, y: 20, width: 550, height: 60 },
            styling: {
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#1a365d',
              alignment: 'center',
              backgroundColor: '#f7fafc'
            }
          },
          {
            id: 'logo_1',
            type: 'image',
            content: { src: '/company-logo.png', alt: 'Company Logo' },
            position: { x: 450, y: 30, width: 100, height: 40 },
            styling: {}
          },
          {
            id: 'test_details',
            type: 'table',
            content: {
              headers: ['Test Parameter', 'Result', 'Standard', 'Status'],
              rows: [
                ['Compressive Strength', '32.5 MPa', 'C30', 'PASS'],
                ['Slump Value', '95 mm', '75-125 mm', 'PASS'],
                ['Density', '2,450 kg/m³', '2,300-2,500', 'PASS']
              ]
            },
            position: { x: 50, y: 150, width: 500, height: 120 },
            styling: {}
          }
        ],
        branding: {
          companyName: 'Quality Testing Labs',
          colors: {
            primary: '#1a365d',
            secondary: '#2d3748',
            accent: '#3182ce'
          }
        },
        metadata: {
          createdAt: '2024-02-01T10:00:00Z',
          updatedAt: '2024-02-20T15:30:00Z',
          version: '1.2.0',
          author: 'System Admin'
        }
      },
      {
        id: 'test-report-summary',
        name: 'Test Report Summary',
        description: 'Comprehensive summary report for multiple tests',
        category: 'report',
        format: 'pdf',
        pageSize: 'A4',
        orientation: 'portrait',
        elements: [
          {
            id: 'title_1',
            type: 'text',
            content: 'LABORATORY TEST REPORT',
            position: { x: 50, y: 50, width: 500, height: 40 },
            styling: {
              fontSize: '20px',
              fontWeight: 'bold',
              alignment: 'center'
            }
          },
          {
            id: 'chart_1',
            type: 'chart',
            content: { type: 'bar', title: 'Test Results by Type' },
            position: { x: 50, y: 120, width: 250, height: 200 },
            styling: {}
          },
          {
            id: 'summary_table',
            type: 'table',
            content: {
              headers: ['Test Type', 'Total', 'Passed', 'Failed'],
              rows: [
                ['Cube Tests', '25', '23', '2'],
                ['Slump Tests', '15', '15', '0'],
                ['Density Tests', '20', '19', '1']
              ]
            },
            position: { x: 320, y: 120, width: 230, height: 100 },
            styling: {}
          }
        ],
        branding: {
          companyName: 'Advanced Testing Solutions',
          colors: {
            primary: '#2b6cb0',
            secondary: '#4a5568',
            accent: '#48bb78'
          }
        },
        metadata: {
          createdAt: '2024-01-15T14:00:00Z',
          updatedAt: '2024-02-18T11:20:00Z',
          version: '2.1.0',
          author: 'Report Manager'
        }
      },
      {
        id: 'sample-label',
        name: 'Sample Identification Label',
        description: 'Barcode label for sample tracking',
        category: 'label',
        format: 'pdf',
        pageSize: 'A4',
        orientation: 'landscape',
        elements: [
          {
            id: 'sample_id',
            type: 'text',
            content: 'SAMPLE ID: S-2024-001',
            position: { x: 20, y: 20, width: 200, height: 30 },
            styling: {
              fontSize: '16px',
              fontWeight: 'bold'
            }
          },
          {
            id: 'barcode_1',
            type: 'image',
            content: { src: '/barcode-placeholder.png', alt: 'Barcode' },
            position: { x: 20, y: 60, width: 150, height: 40 },
            styling: {}
          },
          {
            id: 'date_collected',
            type: 'date',
            content: { format: 'DD/MM/YYYY' },
            position: { x: 20, y: 110, width: 120, height: 25 },
            styling: {
              fontSize: '12px'
            }
          }
        ],
        branding: {
          companyName: 'Sample Tracking Co.',
          colors: {
            primary: '#38a169',
            secondary: '#2d3748',
            accent: '#ed8936'
          }
        },
        metadata: {
          createdAt: '2024-01-20T09:00:00Z',
          updatedAt: '2024-02-15T16:45:00Z',
          version: '1.0.0',
          author: 'Label Designer'
        }
      }
    ];

    setTemplates(mockTemplates);
    setSelectedTemplate(mockTemplates[0]);
  }, []);

  const createNewTemplate = () => {
    const newTemplate: ExportTemplate = {
      id: `template_${Date.now()}`,
      name: 'New Template',
      description: 'Custom export template',
      category: 'custom',
      format: 'pdf',
      pageSize: 'A4',
      orientation: 'portrait',
      elements: [],
      branding: {
        companyName: 'Your Company',
        colors: {
          primary: '#2563eb',
          secondary: '#64748b',
          accent: '#10b981'
        }
      },
      metadata: {
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        version: '1.0.0',
        author: 'Current User'
      }
    };

    setTemplates(prev => [...prev, newTemplate]);
    setSelectedTemplate(newTemplate);
  };

  const updateTemplate = (updates: Partial<ExportTemplate>) => {
    if (!selectedTemplate) return;
    
    const updatedTemplate = {
      ...selectedTemplate,
      ...updates,
      metadata: {
        ...selectedTemplate.metadata,
        updatedAt: new Date().toISOString()
      }
    };
    
    setSelectedTemplate(updatedTemplate);
    setTemplates(prev => prev.map(t => t.id === selectedTemplate.id ? updatedTemplate : t));
  };

  const addElement = (element: TemplateElement) => {
    if (!selectedTemplate) return;
    
    updateTemplate({
      elements: [...selectedTemplate.elements, element]
    });
  };

  const updateElement = (elementId: string, updates: Partial<TemplateElement>) => {
    if (!selectedTemplate) return;
    
    updateTemplate({
      elements: selectedTemplate.elements.map(el => 
        el.id === elementId ? { ...el, ...updates } : el
      )
    });
  };

  const deleteElement = (elementId: string) => {
    if (!selectedTemplate) return;
    
    updateTemplate({
      elements: selectedTemplate.elements.filter(el => el.id !== elementId)
    });
    setSelectedElement(null);
  };

  const duplicateTemplate = (template: ExportTemplate) => {
    const duplicated = {
      ...template,
      id: `${template.id}_copy_${Date.now()}`,
      name: `${template.name} (Copy)`,
      metadata: {
        ...template.metadata,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    };
    
    setTemplates(prev => [...prev, duplicated]);
  };

  const exportTemplate = async () => {
    if (!selectedTemplate) return;

    try {
      // Generate template data
      const templateData = {
        ...selectedTemplate,
        exportedAt: new Date().toISOString(),
        elements: selectedTemplate.elements.map(element => ({
          ...element,
          content: typeof element.content === 'object' ? JSON.stringify(element.content) : element.content
        }))
      };

      let content: string;
      let filename: string;
      let mimeType: string;

      switch (selectedTemplate.format) {
        case 'pdf':
          // Create a simple HTML representation for PDF
          content = generateHTMLContent(selectedTemplate);
          filename = `${selectedTemplate.name.replace(/\s+/g, '_')}.html`;
          mimeType = 'text/html';
          break;
        
        case 'excel':
          // Create CSV format for Excel compatibility
          content = generateCSVContent(selectedTemplate);
          filename = `${selectedTemplate.name.replace(/\s+/g, '_')}.csv`;
          mimeType = 'text/csv';
          break;
        
        case 'word':
          // Create RTF format for Word compatibility
          content = generateRTFContent(selectedTemplate);
          filename = `${selectedTemplate.name.replace(/\s+/g, '_')}.rtf`;
          mimeType = 'application/rtf';
          break;
        
        default:
          // JSON fallback
          content = JSON.stringify(templateData, null, 2);
          filename = `${selectedTemplate.name.replace(/\s+/g, '_')}.json`;
          mimeType = 'application/json';
      }

      // Create and download file
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      console.log(`Template exported successfully as ${filename}`);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const saveTemplate = () => {
    if (!selectedTemplate) return;
    
    // Update the template's updated timestamp
    updateTemplate({
      metadata: {
        ...selectedTemplate.metadata,
        updatedAt: new Date().toISOString()
      }
    });
    
    // In a real app, this would save to backend
    console.log('Template saved successfully:', selectedTemplate.name);
  };

  const generateHTMLContent = (template: ExportTemplate): string => {
    const elements = template.elements.map(element => {
      const style = `
        position: absolute;
        left: ${element.position.x}px;
        top: ${element.position.y}px;
        width: ${element.position.width}px;
        height: ${element.position.height}px;
        font-size: ${element.styling.fontSize || '14px'};
        font-weight: ${element.styling.fontWeight || 'normal'};
        color: ${element.styling.color || '#000000'};
        text-align: ${element.styling.alignment || 'left'};
        background-color: ${element.styling.backgroundColor || 'transparent'};
      `;

      let content = '';
      switch (element.type) {
        case 'text':
        case 'header':
        case 'footer':
          content = `<div style="${style}">${element.content}</div>`;
          break;
        case 'table':
          const tableContent = element.content as any;
          content = `<div style="${style}">
            <table border="1" style="width: 100%; border-collapse: collapse;">
              <thead>
                <tr>${tableContent.headers?.map((h: string) => `<th style="padding: 4px; background: #f0f0f0;">${h}</th>`).join('')}</tr>
              </thead>
              <tbody>
                ${tableContent.rows?.map((row: string[]) => 
                  `<tr>${row.map(cell => `<td style="padding: 4px;">${cell}</td>`).join('')}</tr>`
                ).join('')}
              </tbody>
            </table>
          </div>`;
          break;
        case 'date':
          content = `<div style="${style}">${new Date().toLocaleDateString()}</div>`;
          break;
        default:
          content = `<div style="${style}">[${element.type.toUpperCase()}]</div>`;
      }
      return content;
    }).join('');

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${template.name}</title>
          <style>
            body { margin: 0; padding: 20px; font-family: Arial, sans-serif; }
            .page { 
              position: relative; 
              width: ${template.orientation === 'portrait' ? '210mm' : '297mm'};
              height: ${template.orientation === 'portrait' ? '297mm' : '210mm'};
              margin: 0 auto;
              background: white;
              box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
          </style>
        </head>
        <body>
          <div class="page">
            ${elements}
          </div>
        </body>
      </html>
    `;
  };

  const generateCSVContent = (template: ExportTemplate): string => {
    const rows = [
      ['Element Type', 'Content', 'Position X', 'Position Y', 'Width', 'Height'],
      ...template.elements.map(element => [
        element.type,
        typeof element.content === 'object' ? JSON.stringify(element.content) : element.content,
        element.position.x.toString(),
        element.position.y.toString(),
        element.position.width.toString(),
        element.position.height.toString()
      ])
    ];
    
    return rows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
  };

  const generateRTFContent = (template: ExportTemplate): string => {
    const rtfElements = template.elements.map(element => {
      const content = typeof element.content === 'object' ? JSON.stringify(element.content) : element.content;
      return `\\par ${element.type.toUpperCase()}: ${content}`;
    }).join('');

    return `{\\rtf1\\ansi\\deff0 {\\fonttbl {\\f0 Times New Roman;}}
      \\f0\\fs24 ${template.name}\\par
      \\par
      ${rtfElements}
    }`;
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Export Template Builder
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Create custom templates for reports, certificates, and labels with drag-and-drop design
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Input
                placeholder="Search templates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="certificate">Certificates</SelectItem>
                  <SelectItem value="report">Reports</SelectItem>
                  <SelectItem value="label">Labels</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsPreviewOpen(true)}>
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button onClick={createNewTemplate}>
                <Plus className="w-4 h-4 mr-2" />
                New Template
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Template Library */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Templates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className={cn(
                  "p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md",
                  selectedTemplate?.id === template.id && "ring-2 ring-primary bg-primary/5"
                )}
                onClick={() => setSelectedTemplate(template)}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1 flex-1">
                    <h4 className="font-medium text-sm">{template.name}</h4>
                    <p className="text-xs text-muted-foreground">{template.description}</p>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline" className="text-xs">
                        {template.format.toUpperCase()}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {template.category}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      duplicateTemplate(template);
                    }}
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Element Palette */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Elements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {elementTypes.map((elementType) => {
              const Icon = elementType.icon;
              return (
                <div
                  key={elementType.type}
                  className="p-3 border rounded-lg cursor-grab hover:bg-muted/50 transition-colors"
                  draggable
                  onDragStart={(e) => {
                    console.log('Drag started for:', elementType.type);
                    e.dataTransfer.setData('text/plain', elementType.type);
                    e.dataTransfer.effectAllowed = 'copy';
                  }}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" />
                    <div>
                      <div className="font-medium text-sm">{elementType.label}</div>
                      <div className="text-xs text-muted-foreground">
                        {elementType.description}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Canvas */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Template Designer
              {selectedTemplate && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportTemplate}>
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                  <Button variant="outline" size="sm" onClick={saveTemplate}>
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </div>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedTemplate ? (
              <div className="space-y-4">
                {/* Template Settings */}
                <div className="flex gap-4 p-3 bg-muted/30 rounded-lg">
                  <div className="space-y-1">
                    <Label className="text-xs">Page Size</Label>
                    <Select
                      value={selectedTemplate.pageSize}
                      onValueChange={(value: any) => updateTemplate({ pageSize: value })}
                    >
                      <SelectTrigger className="w-24 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A4">A4</SelectItem>
                        <SelectItem value="A3">A3</SelectItem>
                        <SelectItem value="Letter">Letter</SelectItem>
                        <SelectItem value="Legal">Legal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-1">
                    <Label className="text-xs">Orientation</Label>
                    <Select
                      value={selectedTemplate.orientation}
                      onValueChange={(value: any) => updateTemplate({ orientation: value })}
                    >
                      <SelectTrigger className="w-28 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="portrait">Portrait</SelectItem>
                        <SelectItem value="landscape">Landscape</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-1">
                    <Label className="text-xs">Format</Label>
                    <Select
                      value={selectedTemplate.format}
                      onValueChange={(value: any) => updateTemplate({ format: value })}
                    >
                      <SelectTrigger className="w-20 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="excel">Excel</SelectItem>
                        <SelectItem value="word">Word</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Canvas */}
                <div className="border rounded-lg p-4 bg-gray-50">
                  <CanvasArea
                    template={selectedTemplate}
                    onElementAdd={addElement}
                    onElementUpdate={updateElement}
                    onElementDelete={deleteElement}
                    selectedElement={selectedElement}
                    onElementSelect={setSelectedElement}
                    onEditElement={() => setIsEditModalOpen(true)}
                  />
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                Select a template to start designing
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Template Preview</DialogTitle>
            <DialogDescription>
              Preview how your template will look when exported
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selectedTemplate && (
              <div className="bg-white p-8 border rounded-lg shadow-inner">
                <div 
                  className="mx-auto bg-white shadow-lg"
                  style={{
                    width: selectedTemplate.orientation === 'portrait' ? '210mm' : '297mm',
                    height: selectedTemplate.orientation === 'portrait' ? '297mm' : '210mm',
                    transform: 'scale(0.5)',
                    transformOrigin: 'top left'
                  }}
                >
                  {/* Render preview content */}
                  <div className="p-8">
                    <h2 className="text-2xl font-bold text-center mb-6">
                      {selectedTemplate.name}
                    </h2>
                    <p className="text-center text-gray-600 mb-8">
                      This is a preview of your template. Elements will be rendered according to your design.
                    </p>
                    <div className="space-y-4">
                      {selectedTemplate.elements.map((element) => (
                        <div key={element.id} className="p-2 border border-gray-200 rounded">
                          <span className="text-sm font-medium">{element.type}</span>
                          <div className="text-xs text-gray-500">
                            {typeof element.content === 'string' ? element.content : `[${element.type} content]`}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Element Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Element</DialogTitle>
            <DialogDescription>
              Customize the properties of your selected element
            </DialogDescription>
          </DialogHeader>
          {selectedElement && selectedTemplate && (() => {
            const element = selectedTemplate.elements.find(el => el.id === selectedElement);
            if (!element) return null;

            return (
              <div className="space-y-6">
                <Tabs defaultValue="content" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="content">Content</TabsTrigger>
                    <TabsTrigger value="styling">Styling</TabsTrigger>
                    <TabsTrigger value="position">Position</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="content" className="space-y-4">
                    {element.type === 'text' || element.type === 'header' || element.type === 'footer' ? (
                      <div className="space-y-2">
                        <Label>Text Content</Label>
                        <Textarea
                          value={element.content}
                          onChange={(e) => updateElement(element.id, { content: e.target.value })}
                          placeholder="Enter text content..."
                          rows={3}
                        />
                      </div>
                    ) : element.type === 'image' ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Image URL</Label>
                          <Input
                            value={element.content?.src || ''}
                            onChange={(e) => updateElement(element.id, { 
                              content: { ...element.content, src: e.target.value }
                            })}
                            placeholder="https://example.com/image.jpg or /local-image.png"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Alt Text</Label>
                          <Input
                            value={element.content?.alt || ''}
                            onChange={(e) => updateElement(element.id, { 
                              content: { ...element.content, alt: e.target.value }
                            })}
                            placeholder="Image description"
                          />
                        </div>
                        <div className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                          <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                          <p className="text-sm text-gray-600">
                            Upload an image file or enter a URL above
                          </p>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            id="image-upload"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const url = URL.createObjectURL(file);
                                updateElement(element.id, { 
                                  content: { ...element.content, src: url, alt: file.name }
                                });
                              }
                            }}
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2"
                            onClick={() => document.getElementById('image-upload')?.click()}
                          >
                            Choose File
                          </Button>
                        </div>
                      </div>
                    ) : element.type === 'table' ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Table Headers (comma-separated)</Label>
                          <Input
                            value={element.content?.headers?.join(', ') || ''}
                            onChange={(e) => updateElement(element.id, { 
                              content: { 
                                ...element.content, 
                                headers: e.target.value.split(',').map(h => h.trim())
                              }
                            })}
                            placeholder="Header 1, Header 2, Header 3"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Table Rows (one row per line, cells separated by commas)</Label>
                          <Textarea
                            value={element.content?.rows?.map((row: string[]) => row.join(', ')).join('\n') || ''}
                            onChange={(e) => updateElement(element.id, { 
                              content: { 
                                ...element.content, 
                                rows: e.target.value.split('\n').map(line => 
                                  line.split(',').map(cell => cell.trim())
                                ).filter(row => row.some(cell => cell))
                              }
                            })}
                            placeholder="Cell 1, Cell 2, Cell 3"
                            rows={4}
                          />
                        </div>
                      </div>
                    ) : element.type === 'signature' ? (
                      <div className="space-y-2">
                        <Label>Signature Placeholder</Label>
                        <Input
                          value={element.content?.placeholder || ''}
                          onChange={(e) => updateElement(element.id, { 
                            content: { ...element.content, placeholder: e.target.value }
                          })}
                          placeholder="Digital Signature"
                        />
                      </div>
                    ) : element.type === 'date' ? (
                      <div className="space-y-2">
                        <Label>Date Format</Label>
                        <Select
                          value={element.content?.format || 'YYYY-MM-DD'}
                          onValueChange={(value) => updateElement(element.id, { 
                            content: { ...element.content, format: value }
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="YYYY-MM-DD">2024-01-15</SelectItem>
                            <SelectItem value="DD/MM/YYYY">15/01/2024</SelectItem>
                            <SelectItem value="MM/DD/YYYY">01/15/2024</SelectItem>
                            <SelectItem value="DD-MM-YYYY">15-01-2024</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="text-sm text-gray-500">
                        No content options available for this element type.
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="styling" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Font Size</Label>
                        <Select
                          value={element.styling.fontSize || '14px'}
                          onValueChange={(value) => updateElement(element.id, { 
                            styling: { ...element.styling, fontSize: value }
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="10px">10px</SelectItem>
                            <SelectItem value="12px">12px</SelectItem>
                            <SelectItem value="14px">14px</SelectItem>
                            <SelectItem value="16px">16px</SelectItem>
                            <SelectItem value="18px">18px</SelectItem>
                            <SelectItem value="20px">20px</SelectItem>
                            <SelectItem value="24px">24px</SelectItem>
                            <SelectItem value="32px">32px</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Font Weight</Label>
                        <Select
                          value={element.styling.fontWeight || 'normal'}
                          onValueChange={(value) => updateElement(element.id, { 
                            styling: { ...element.styling, fontWeight: value }
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="normal">Normal</SelectItem>
                            <SelectItem value="bold">Bold</SelectItem>
                            <SelectItem value="lighter">Light</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Text Color</Label>
                        <Input
                          type="color"
                          value={element.styling.color || '#000000'}
                          onChange={(e) => updateElement(element.id, { 
                            styling: { ...element.styling, color: e.target.value }
                          })}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Background Color</Label>
                        <Input
                          type="color"
                          value={element.styling.backgroundColor || '#ffffff'}
                          onChange={(e) => updateElement(element.id, { 
                            styling: { ...element.styling, backgroundColor: e.target.value }
                          })}
                        />
                      </div>
                      
                      <div className="space-y-2 col-span-2">
                        <Label>Text Alignment</Label>
                        <Select
                          value={element.styling.alignment || 'left'}
                          onValueChange={(value: any) => updateElement(element.id, { 
                            styling: { ...element.styling, alignment: value }
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="left">Left</SelectItem>
                            <SelectItem value="center">Center</SelectItem>
                            <SelectItem value="right">Right</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="position" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>X Position</Label>
                        <Input
                          type="number"
                          value={element.position.x}
                          onChange={(e) => updateElement(element.id, { 
                            position: { ...element.position, x: parseInt(e.target.value) || 0 }
                          })}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Y Position</Label>
                        <Input
                          type="number"
                          value={element.position.y}
                          onChange={(e) => updateElement(element.id, { 
                            position: { ...element.position, y: parseInt(e.target.value) || 0 }
                          })}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Width</Label>
                        <Input
                          type="number"
                          value={element.position.width}
                          onChange={(e) => updateElement(element.id, { 
                            position: { ...element.position, width: parseInt(e.target.value) || 50 }
                          })}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Height</Label>
                        <Input
                          type="number"
                          value={element.position.height}
                          onChange={(e) => updateElement(element.id, { 
                            position: { ...element.position, height: parseInt(e.target.value) || 30 }
                          })}
                        />
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsEditModalOpen(false)}>
                    Done
                  </Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}