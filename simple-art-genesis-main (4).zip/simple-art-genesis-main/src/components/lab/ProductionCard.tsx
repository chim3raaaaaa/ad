import React from 'react';
import { Calendar, TestTube, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Button } from '../ui/button';

interface Production {
  id: number;
  productionNumber: number;
  productionDate: string;
  requiredBlockCount: number;
  siteCode: string;
  status: string;
  currentBlockCount: number;
  lastDataUpdate?: string;
  validationDate?: string;
}

interface ProductionCardProps {
  production: Production;
  type: 'production' | 'retest';
  onViewDetails: (production: Production) => void;
  onValidate?: (production: Production) => void;
}

export function ProductionCard({ production, type, onViewDetails, onValidate }: ProductionCardProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'validated': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'validating': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default: return <TestTube className="h-4 w-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'validated': return 'bg-green-100 text-green-800';
      case 'validating': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const progress = Math.min((production.currentBlockCount / production.requiredBlockCount) * 100, 100);

  return (
    <Card className="relative">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            {type === 'production' ? 'Production' : 'Retest'} {production.productionNumber}
          </CardTitle>
          <div className="flex items-center gap-2">
            {getStatusIcon(production.status)}
            <Badge className={getStatusColor(production.status)}>
              {production.status}
            </Badge>
          </div>
        </div>
        <CardDescription className="flex items-center gap-2">
          <Calendar className="h-4 w-4" />
          {production.productionDate} • Site: {production.siteCode}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Block Count Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Blocks Tested</span>
            <span>{production.currentBlockCount} / {production.requiredBlockCount}</span>
          </div>
          <Progress value={progress} className="h-2" />
          {production.status === 'validating' && progress < 100 && (
            <p className="text-xs text-muted-foreground">
              Waiting for {production.requiredBlockCount - production.currentBlockCount} more blocks
            </p>
          )}
        </div>

        {/* Status Information */}
        {production.status === 'validated' && production.validationDate && (
          <div className="flex items-center gap-2 text-sm text-green-600">
            <CheckCircle className="h-4 w-4" />
            <span>Validated on {new Date(production.validationDate).toLocaleDateString()}</span>
          </div>
        )}

        {production.lastDataUpdate && (
          <p className="text-xs text-muted-foreground">
            Last updated: {new Date(production.lastDataUpdate).toLocaleString()}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onViewDetails(production)}
            className="flex-1"
          >
            View Details
          </Button>
          {production.status === 'validating' && onValidate && (
            <Button 
              size="sm" 
              onClick={() => onValidate(production)}
              disabled={production.currentBlockCount < production.requiredBlockCount}
            >
              Force Validate
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}