import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Eye, Code, Rocket, Copy, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PlacementSelector } from "@/components/developer/PlacementSelector";
import { SuccessMessageDialog } from "@/components/developer/SuccessMessageDialog";
import type { SuccessMessage } from "@/types/developer";

interface FormField {
  id: string;
  type: 'text' | 'email' | 'number' | 'select' | 'textarea' | 'checkbox' | 'date';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
  validation?: string;
}

export interface CustomForm {
  id: string;
  name: string;
  description: string;
  fields: FormField[];
  created_at: string;
}

export function FormBuilder() {
  const { toast } = useToast();
  const [currentForm, setCurrentForm] = useState<CustomForm>({
    id: '',
    name: '',
    description: '',
    fields: [],
    created_at: new Date().toISOString()
  });
  const [previewMode, setPreviewMode] = useState(false);
  const [savedForms, setSavedForms] = useState<CustomForm[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Placement selector state
  const [selectedPlacement, setSelectedPlacement] = useState('dashboard');
  const [moduleId, setModuleId] = useState('');
  const [customRoute, setCustomRoute] = useState('');
  
  // Success dialog state
  const [successMessage, setSuccessMessage] = useState<SuccessMessage | null>(null);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  // Load saved forms from database on mount
  useEffect(() => {
    loadSavedForms();
  }, []);

  const loadSavedForms = async () => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery('SELECT * FROM custom_forms ORDER BY created_at DESC');
        if (result.success && result.data) {
          const forms = result.data.map(form => ({
            id: form.id,
            name: form.name,
            description: form.description || '',
            fields: form.fields ? JSON.parse(form.fields) : [],
            created_at: form.created_at
          }));
          setSavedForms(forms);
        }
      }
    } catch (error) {
      console.error('Failed to load saved forms:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fieldTypes = [
    { value: 'text', label: 'Text Input' },
    { value: 'email', label: 'Email' },
    { value: 'number', label: 'Number' },
    { value: 'select', label: 'Dropdown' },
    { value: 'textarea', label: 'Text Area' },
    { value: 'checkbox', label: 'Checkbox' },
    { value: 'date', label: 'Date' }
  ];

  const addField = () => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      type: 'text',
      label: 'New Field',
      placeholder: '',
      required: false,
      options: []
    };
    
    setCurrentForm(prev => ({
      ...prev,
      fields: [...prev.fields, newField]
    }));
  };

  const updateField = (fieldId: string, updates: Partial<FormField>) => {
    setCurrentForm(prev => ({
      ...prev,
      fields: prev.fields.map(field => 
        field.id === fieldId ? { ...field, ...updates } : field
      )
    }));
  };

  const removeField = (fieldId: string) => {
    setCurrentForm(prev => ({
      ...prev,
      fields: prev.fields.filter(field => field.id !== fieldId)
    }));
  };

  const saveForm = async () => {
    if (!currentForm.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Form name is required",
        variant: "destructive"
      });
      return;
    }

    const formToSave = {
      ...currentForm,
      id: currentForm.id || `form_${Date.now()}`,
      created_at: currentForm.created_at || new Date().toISOString(),
      placement: selectedPlacement,
      module_id: moduleId || null,
      custom_route: customRoute || null,
      schema: {
        fields: currentForm.fields,
        validation: currentForm.fields.map(field => ({
          field: field.id,
          required: field.required,
          type: field.type,
          validation: field.validation
        }))
      }
    };

    try {
      // Try to save to Electron database if available
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO form_definitions (id, name, description, fields, placement, module_id, custom_route, created_at, updated_at, created_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            formToSave.id,
            formToSave.name,
            formToSave.description || '',
            JSON.stringify(formToSave.fields),
            formToSave.placement,
            formToSave.module_id,
            formToSave.custom_route,
            formToSave.created_at,
            new Date().toISOString(),
            'current_user'
          ]
        );

        if (!result.success) {
          throw new Error(result.error);
        }
      }

      // Update local state
      setSavedForms(prev => {
        const existing = prev.find(f => f.id === formToSave.id);
        if (existing) {
          return prev.map(f => f.id === formToSave.id ? formToSave : f);
        }
        return [...prev, formToSave];
      });

      // Show success message
      const message: SuccessMessage = {
        title: 'Form Created Successfully!',
        description: `Form "${formToSave.name}" has been saved to the SQLite database.`,
        saved_location: 'SQLite Database → form_definitions table',
        view_location: selectedPlacement === 'custom-route' ? customRoute : `/${selectedPlacement}`,
        action_button: {
          label: `View in ${selectedPlacement}`,
          route: selectedPlacement === 'custom-route' ? customRoute || '/' : `/${selectedPlacement}`
        }
      };

      setSuccessMessage(message);
      setShowSuccessDialog(true);

    } catch (error) {
      console.error('Failed to save form to database:', error);
      // Fallback to local storage
      setSavedForms(prev => {
        const existing = prev.find(f => f.id === formToSave.id);
        if (existing) {
          return prev.map(f => f.id === formToSave.id ? formToSave : f);
        }
        return [...prev, formToSave];
      });

      toast({
        title: "Form Saved Locally",
        description: `"${formToSave.name}" saved locally (database unavailable)`,
        variant: "destructive"
      });
    }
  };

  const loadForm = (form: CustomForm) => {
    setCurrentForm(form);
    setPreviewMode(false);
  };

  const renderFormField = (field: FormField, isPreview: boolean = false) => {
    const commonProps = {
      id: field.id,
      placeholder: field.placeholder,
      required: field.required
    };

    switch (field.type) {
      case 'text':
      case 'email':
      case 'number':
        return (
          <Input 
            {...commonProps}
            type={field.type}
            disabled={!isPreview}
          />
        );
      
      case 'textarea':
        return (
          <Textarea 
            {...commonProps}
            disabled={!isPreview}
          />
        );
      
      case 'select':
        return (
          <Select disabled={!isPreview}>
            <SelectTrigger>
              <SelectValue placeholder={field.placeholder || "Select option"} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, idx) => (
                <SelectItem key={idx} value={option}>{option}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      
      case 'checkbox':
        return (
          <Switch disabled={!isPreview} />
        );
      
      case 'date':
        return (
          <Input 
            {...commonProps}
            type="date"
            disabled={!isPreview}
          />
        );
      
      default:
        return <Input {...commonProps} disabled={!isPreview} />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Form Builder</h3>
          <p className="text-sm text-muted-foreground">Create custom forms with validation</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setPreviewMode(!previewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Edit' : 'Preview'}
          </Button>
          <Button onClick={saveForm}>
            Save Form
          </Button>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList>
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="forms">Saved Forms ({savedForms.length})</TabsTrigger>
          <TabsTrigger value="deploy">🚀 Deploy & Use</TabsTrigger>
          <TabsTrigger value="code">Generated Code</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-4">
          {!previewMode ? (
            <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Form Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Form Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="form-name">Form Name</Label>
                    <Input
                      id="form-name"
                      value={currentForm.name}
                      onChange={(e) => setCurrentForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter form name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="form-description">Description</Label>
                    <Textarea
                      id="form-description"
                      value={currentForm.description}
                      onChange={(e) => setCurrentForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Form description"
                    />
                  </div>
                  <Button onClick={addField} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Field
                  </Button>
                </CardContent>
              </Card>

              {/* Field Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Field Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 max-h-96 overflow-y-auto">
                  {currentForm.fields.map((field, index) => (
                    <div key={field.id} className="p-3 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline">Field {index + 1}</Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeField(field.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>Type</Label>
                          <Select
                            value={field.type}
                            onValueChange={(value) => updateField(field.id, { type: value as FormField['type'] })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {fieldTypes.map(type => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={field.required}
                            onCheckedChange={(checked) => updateField(field.id, { required: checked })}
                          />
                          <Label>Required</Label>
                        </div>
                      </div>

                      <div>
                        <Label>Label</Label>
                        <Input
                          value={field.label}
                          onChange={(e) => updateField(field.id, { label: e.target.value })}
                        />
                      </div>

                      <div>
                        <Label>Placeholder</Label>
                        <Input
                          value={field.placeholder || ''}
                          onChange={(e) => updateField(field.id, { placeholder: e.target.value })}
                        />
                      </div>

                      {field.type === 'select' && (
                        <div>
                          <Label>Options (one per line)</Label>
                          <Textarea
                            value={field.options?.join('\n') || ''}
                            onChange={(e) => updateField(field.id, { 
                              options: e.target.value.split('\n').filter(o => o.trim()) 
                            })}
                            placeholder="Option 1&#10;Option 2&#10;Option 3"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Live Preview */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Live Preview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 max-h-96 overflow-y-auto">
                  <form className="space-y-4">
                    {currentForm.fields.map(field => (
                      <div key={field.id} className="space-y-2">
                        <Label>
                          {field.label}
                          {field.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                        {renderFormField(field)}
                      </div>
                    ))}
                    {currentForm.fields.length > 0 && (
                      <Button type="button" className="w-full" disabled>
                        Submit
                      </Button>
                    )}
                  </form>
                </CardContent>
              </Card>
            </div>
            
            {/* Placement Selector */}
            <PlacementSelector
              selectedPlacement={selectedPlacement}
              onPlacementChange={setSelectedPlacement}
              moduleId={moduleId}
              onModuleIdChange={setModuleId}
              customRoute={customRoute}
              onCustomRouteChange={setCustomRoute}
            />
            </>
          ) : (
            /* Full Preview Mode */
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>{currentForm.name || 'Untitled Form'}</CardTitle>
                {currentForm.description && (
                  <p className="text-sm text-muted-foreground">{currentForm.description}</p>
                )}
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  {currentForm.fields.map(field => (
                    <div key={field.id} className="space-y-2">
                      <Label>
                        {field.label}
                        {field.required && <span className="text-red-500 ml-1">*</span>}
                      </Label>
                      {renderFormField(field, true)}
                    </div>
                  ))}
                  {currentForm.fields.length > 0 && (
                    <Button type="submit" className="w-full">
                      Submit
                    </Button>
                  )}
                </form>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="forms">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedForms.map(form => (
              <Card key={form.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{form.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {form.fields.length} fields • {new Date(form.created_at).toLocaleDateString()}
                  </p>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">{form.description}</p>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => loadForm(form)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Deploy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="deploy" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* How to Use Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rocket className="w-5 h-5" />
                  How to Use Your Forms
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h4 className="font-semibold">1. 📋 Copy Generated Code</h4>
                  <p className="text-sm text-muted-foreground">
                    Switch to "Generated Code" tab and copy the React component
                  </p>
                  
                  <h4 className="font-semibold">2. 📁 Create Component File</h4>
                  <p className="text-sm text-muted-foreground">
                    Create a new file: <code className="bg-muted px-1 rounded">src/components/forms/{currentForm.name.replace(/\s+/g, '')}Form.tsx</code>
                  </p>
                  
                  <h4 className="font-semibold">3. 🔗 Import & Use</h4>
                  <div className="bg-muted p-3 rounded text-sm">
                    <code>{`import { ${currentForm.name.replace(/\s+/g, '')}Form } from '@/components/forms/${currentForm.name.replace(/\s+/g, '')}Form';

// Use anywhere in your app:
<${currentForm.name.replace(/\s+/g, '')}Form />`}</code>
                  </div>

                  <h4 className="font-semibold">4. ⚙️ Customize Behavior</h4>
                  <p className="text-sm text-muted-foreground">
                    Modify the handleSubmit function to save data, send emails, or integrate with APIs
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentForm.name && (
                  <>
                    <Button 
                      className="w-full" 
                      onClick={() => {
                        const componentCode = `// Generated form component for: ${currentForm.name}
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function ${currentForm.name.replace(/\s+/g, '')}Form() {
  const [formData, setFormData] = useState({
${currentForm.fields.map(field => `    ${field.id}: ''`).join(',\n')}
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // TODO: Add your custom logic here
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
${currentForm.fields.map(field => `      <div>
        <Label htmlFor="${field.id}">${field.label}${field.required ? ' *' : ''}</Label>
        <Input
          id="${field.id}"
          type="${field.type}"
          placeholder="${field.placeholder || ''}"
          ${field.required ? 'required' : ''}
          value={formData.${field.id}}
          onChange={(e) => setFormData(prev => ({ ...prev, ${field.id}: e.target.value }))}
        />
      </div>`).join('\n')}
      <Button type="submit" className="w-full">
        Submit
      </Button>
    </form>
  );
}`;
                        navigator.clipboard.writeText(componentCode);
                        toast({
                          title: "Code Copied!",
                          description: "React component code copied to clipboard"
                        });
                      }}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy React Component
                    </Button>

                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        const formConfig = JSON.stringify(currentForm, null, 2);
                        navigator.clipboard.writeText(formConfig);
                        toast({
                          title: "Config Copied!",
                          description: "Form configuration copied to clipboard"
                        });
                      }}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Form Config (JSON)
                    </Button>

                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        const blob = new Blob([JSON.stringify(currentForm, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `${currentForm.name.replace(/\s+/g, '')}-form.json`;
                        a.click();
                        URL.revokeObjectURL(url);
                      }}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download as JSON
                    </Button>
                  </>
                )}

                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-2">Integration Examples:</h4>
                  <div className="space-y-2 text-sm">
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      📧 Email form submissions
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      🗄️ Save to database
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      🔗 Send to API endpoint
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start">
                      📊 Add to analytics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Deployment Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>🚀 Production Deployment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">1. Add to Pages</h4>
                  <p className="text-sm text-muted-foreground">
                    Import your form component in any page where you need it (Dashboard, Settings, etc.)
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">2. Route Integration</h4>
                  <p className="text-sm text-muted-foreground">
                    Add routes in App.tsx to make your forms accessible via URLs
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">3. Navigation Links</h4>
                  <p className="text-sm text-muted-foreground">
                    Add navigation links in sidebars or menus to help users find your forms
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                <CardTitle>Generated React Component</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`// Generated form component for: ${currentForm.name}
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function ${currentForm.name.replace(/\s+/g, '')}Form() {
  const [formData, setFormData] = useState({
${currentForm.fields.map(field => `    ${field.id}: ''`).join(',\n')}
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
${currentForm.fields.map(field => `      <div>
        <Label htmlFor="${field.id}">${field.label}${field.required ? ' *' : ''}</Label>
        <Input
          id="${field.id}"
          type="${field.type}"
          placeholder="${field.placeholder || ''}"
          ${field.required ? 'required' : ''}
          value={formData.${field.id}}
          onChange={(e) => setFormData(prev => ({ ...prev, ${field.id}: e.target.value }))}
        />
      </div>`).join('\n')}
      <Button type="submit" className="w-full">
        Submit
      </Button>
    </form>
  );
}`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <SuccessMessageDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
        message={successMessage}
      />
    </div>
  );
}