import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle, XCircle, AlertTriangle, Download, Calendar as CalendarIcon, Play } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { conformityEngine } from '@/services/validation/conformityEngine';
import { EnhancedValidationService } from '@/services/validation/enhancedValidationService';
import { EnhancedReportGenerator } from '@/lib/enhancedPdfGenerator';

interface ConformityResult {
  id: string;
  memoRef: string;
  product: string;
  conformityResult: 'Pass' | 'Fail' | 'Manual';
  failedFields: string;
  reason: string;
  checkedBy: string;
  timestamp: string;
}

export function AutoConformityEngine() {
  const [category, setCategory] = useState<string>('');
  const [productType, setProductType] = useState<string>('');
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [plant, setPlant] = useState<string>('');
  const [officer, setOfficer] = useState<string>('');
  const [machine, setMachine] = useState<string>('');
  const [results, setResults] = useState<ConformityResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<string[]>([]);
  const [productTypes, setProductTypes] = useState<string[]>([]);
  const [plants, setPlants] = useState<string[]>([]);
  const [officers, setOfficers] = useState<string[]>([]);
  const [machines, setMachines] = useState<string[]>([]);
  
  const { toast } = useToast();

  useEffect(() => {
    initializeData();
    createConformityLogsTable();
  }, []);

  useEffect(() => {
    if (category) {
      loadProductTypes(category);
    }
  }, [category]);

  const createConformityLogsTable = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS conformity_check_logs (
            id TEXT PRIMARY KEY,
            memo_id TEXT,
            category TEXT,
            product TEXT,
            check_result TEXT,
            failed_fields TEXT,
            reason TEXT,
            checked_by TEXT,
            checked_at TEXT
          )
        `);
      }
    } catch (error) {
      console.error('Error creating conformity logs table:', error);
    }
  };

  const initializeData = async () => {
    try {
      // Load categories from validation service
      await EnhancedValidationService.initializeTables();
      const cats = await EnhancedValidationService.getProductCategories();
      setCategories(cats);

      // Load reference data for filters
      if (window.electronAPI?.dbQuery) {
        // Load plants
        const plantsResult = await window.electronAPI.dbQuery('SELECT DISTINCT plant FROM memos WHERE plant IS NOT NULL AND plant != ""', []);
        setPlants(plantsResult.map((row: any) => row.plant).filter((p: string) => p && p.trim() !== ''));

        // Load officers
        const officersResult = await window.electronAPI.dbQuery('SELECT DISTINCT officer FROM memos WHERE officer IS NOT NULL AND officer != ""', []);
        setOfficers(officersResult.map((row: any) => row.officer).filter((o: string) => o && o.trim() !== ''));

        // Load machines
        const machinesResult = await window.electronAPI.dbQuery('SELECT DISTINCT machine FROM memos WHERE machine IS NOT NULL AND machine != ""', []);
        setMachines(machinesResult.map((row: any) => row.machine).filter((m: string) => m && m.trim() !== ''));
      }
    } catch (error) {
      console.error('Error initializing data:', error);
      toast({
        title: "Error",
        description: "Failed to load initial data",
        variant: "destructive"
      });
    }
  };

  const loadProductTypes = async (selectedCategory: string) => {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          'SELECT DISTINCT product_type FROM memos WHERE category = ?',
          [selectedCategory]
        );
        setProductTypes(result.map((row: any) => row.product_type));
      }
    } catch (error) {
      console.error('Error loading product types:', error);
    }
  };

  // Enhanced grading conformity check using database limits
  const checkGradingConformityWithDatabase = async (testData: any) => {
    try {
      if (!window.electronAPI?.dbQuery) return null;
      
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM grading_limits WHERE material_type = ? AND standard = ?',
        [testData.material_type, testData.standard]
      );
      
      if (!result || result.length === 0) return null;
      
      const limits = result[0];
      const failedSieves: string[] = [];
      const sieveSizes = [
        '0_075', '0_15', '0_3', '0_6', '1_18', '2_36', '5', '10', 
        '14', '16', '20', '31_5', '37_5', '45', '50', '63'
      ];

      for (const sieve of sieveSizes) {
        const actualValue = testData[`sieve_${sieve}`];
        const limitValue = limits[`sieve_${sieve}`];
        
        if (actualValue !== undefined && limitValue !== undefined) {
          const isMinStandard = testData.standard?.includes('Min');
          const isMaxStandard = testData.standard?.includes('Max');
          
          if (isMinStandard && actualValue < limitValue) {
            failedSieves.push(`${sieve}mm (${actualValue}% < ${limitValue}%)`);
          } else if (isMaxStandard && actualValue > limitValue) {
            failedSieves.push(`${sieve}mm (${actualValue}% > ${limitValue}%)`);
          }
        }
      }

      return {
        overall_status: failedSieves.length > 0 ? 'fail' : 'pass',
        failed_sieves: failedSieves,
        reason: failedSieves.length > 0 ? `Grading non-conformity in sieves: ${failedSieves.join(', ')}` : 'Grading within limits'
      };
    } catch (error) {
      console.error('Error checking grading conformity:', error);
      return null;
    }
  };

  const runConformityChecks = async () => {
    if (!category) {
      toast({
        title: "Error",
        description: "Please select a category",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Build query filters
      let query = `
        SELECT m.*, tr.test_results 
        FROM memos m 
        LEFT JOIN test_results tr ON m.memo_ref = tr.memo_ref 
        WHERE m.category = ? AND m.status = 'completed'
      `;
      const params = [category];

      if (productType) {
        query += ' AND m.product_type = ?';
        params.push(productType);
      }

      if (dateFrom) {
        query += ' AND DATE(m.created_at) >= ?';
        params.push(format(dateFrom, 'yyyy-MM-dd'));
      }

      if (dateTo) {
        query += ' AND DATE(m.created_at) <= ?';
        params.push(format(dateTo, 'yyyy-MM-dd'));
      }

      if (plant && plant !== 'all') {
        query += ' AND m.plant = ?';
        params.push(plant);
      }

      if (officer && officer !== 'all') {
        query += ' AND m.officer = ?';
        params.push(officer);
      }

      if (machine && machine !== 'all') {
        query += ' AND m.machine = ?';
        params.push(machine);
      }

      const testResults = await window.electronAPI?.dbQuery(query, params) || [];
      
      const conformityResults: ConformityResult[] = [];

      for (const testResult of testResults) {
        if (!testResult.test_results) continue;

        try {
          const testData = JSON.parse(testResult.test_results);
          
          // Enhanced grading conformity check using database limits
          let gradingConformityResult = null;
          if (category === 'aggregates' && testData.material_type && testData.standard) {
            gradingConformityResult = await checkGradingConformityWithDatabase(testData);
          }

          const validationResult = await EnhancedValidationService.validateTestResult(testData, category);
          
          const failedValidations = validationResult.filter(v => !v.passed);
          const hasFailures = failedValidations.length > 0;
          const hasGradingFailure = gradingConformityResult && gradingConformityResult.overall_status === 'fail';
          
          let conformityStatus: 'Pass' | 'Fail' | 'Manual' = 'Pass';
          let failedFields = '';
          let reason = '';

          if (hasFailures || hasGradingFailure) {
            const criticalFailures = failedValidations.filter(v => v.severity === 'critical');
            conformityStatus = (criticalFailures.length > 0 || hasGradingFailure) ? 'Fail' : 'Manual';
            
            const validationFields = failedValidations.map(v => v.field);
            const gradingFields = gradingConformityResult?.failed_sieves || [];
            failedFields = [...validationFields, ...gradingFields].join(', ');
            
            if (hasGradingFailure) {
              reason = `Grading non-conformity: ${gradingConformityResult.reason}`;
            } else {
              reason = 'Failed validation checks';
            }
          }

          const result: ConformityResult = {
            id: `${testResult.memo_ref}_${Date.now()}`,
            memoRef: testResult.memo_ref,
            product: testResult.product_type || 'Unknown',
            conformityResult: conformityStatus,
            failedFields,
            reason,
            checkedBy: 'System',
            timestamp: new Date().toISOString()
          };

          conformityResults.push(result);

          // Save to database
          await window.electronAPI?.dbQuery(`
            INSERT INTO conformity_check_logs 
            (id, memo_id, category, product, check_result, failed_fields, reason, checked_by, checked_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            result.id,
            testResult.memo_ref,
            category,
            result.product,
            result.conformityResult,
            result.failedFields,
            result.reason,
            result.checkedBy,
            result.timestamp
          ]);

        } catch (parseError) {
          console.error('Error parsing test results:', parseError);
        }
      }

      setResults(conformityResults);
      toast({
        title: "Success",
        description: `Processed ${conformityResults.length} test results`,
      });

    } catch (error) {
      console.error('Error running conformity checks:', error);
      toast({
        title: "Error",
        description: "Failed to run conformity checks",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const exportResults = async (format: 'csv' | 'pdf') => {
    try {
      if (format === 'csv') {
        const csvContent = [
          ['Memo Ref', 'Product', 'Conformity Result', 'Failed Fields', 'Reason', 'Checked By', 'Timestamp'],
          ...results.map(r => [r.memoRef, r.product, r.conformityResult, r.failedFields, r.reason, r.checkedBy, r.timestamp])
        ].map(row => row.join(',')).join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `conformity_results_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (format === 'pdf') {
        // Generate enhanced PDF with conformity analysis
        const conformityReports = results.map(result => ({
          overall_status: result.conformityResult.toLowerCase() as 'pass' | 'fail' | 'warning',
          conformity_percentage: result.conformityResult === 'Pass' ? 100 : 0,
          material_type: result.product,
          standard: 'System Analysis',
          results: [],
          checked_at: result.timestamp
        }));
        
        await EnhancedReportGenerator.generateConformityBatchReport(conformityReports);
      }

      toast({
        title: "Success",
        description: `Results exported as ${format.toUpperCase()}`,
      });
    } catch (error) {
      console.error('Error exporting results:', error);
      toast({
        title: "Error",
        description: "Failed to export results",
        variant: "destructive"
      });
    }
  };

  const getResultIcon = (result: 'Pass' | 'Fail' | 'Manual') => {
    switch (result) {
      case 'Pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'Fail':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'Manual':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getResultBadge = (result: 'Pass' | 'Fail' | 'Manual') => {
    const variants = {
      Pass: 'default',
      Fail: 'destructive',
      Manual: 'secondary'
    } as const;

    return (
      <Badge variant={variants[result]} className="flex items-center gap-1">
        {getResultIcon(result)}
        {result}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Auto Conformity Engine</CardTitle>
          <CardDescription>
            Automatically evaluate test results against validation rules
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.filter(cat => cat && cat.trim() !== '').map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="productType">Product Type</Label>
              <Select value={productType} onValueChange={setProductType} disabled={!category}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.filter(type => type && type.trim() !== '').map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Date Range</Label>
              <div className="flex gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFrom ? format(dateFrom, 'PPP') : 'From'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateFrom}
                      onSelect={setDateFrom}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateTo ? format(dateTo, 'PPP') : 'To'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateTo}
                      onSelect={setDateTo}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plant">Plant (Optional)</Label>
              <Select value={plant} onValueChange={setPlant}>
                <SelectTrigger>
                  <SelectValue placeholder="Select plant" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Plants</SelectItem>
                  {plants.filter(p => p && p.trim() !== '').map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="officer">Officer (Optional)</Label>
              <Select value={officer} onValueChange={setOfficer}>
                <SelectTrigger>
                  <SelectValue placeholder="Select officer" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Officers</SelectItem>
                  {officers.filter(o => o && o.trim() !== '').map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="machine">Machine (Optional)</Label>
              <Select value={machine} onValueChange={setMachine}>
                <SelectTrigger>
                  <SelectValue placeholder="Select machine" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Machines</SelectItem>
                  {machines.filter(m => m && m.trim() !== '').map((m) => (
                    <SelectItem key={m} value={m}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={runConformityChecks} disabled={loading || !category}>
              <Play className="mr-2 h-4 w-4" />
              {loading ? 'Running Checks...' : 'Run Conformity Checks'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Conformity Results</CardTitle>
                <CardDescription>
                  {results.length} test results processed
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => exportResults('csv')}>
                  <Download className="mr-2 h-4 w-4" />
                  Export CSV
                </Button>
                <Button variant="outline" size="sm" onClick={() => exportResults('pdf')}>
                  <Download className="mr-2 h-4 w-4" />
                  Export PDF
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Memo Ref</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Result</TableHead>
                  <TableHead>Failed Fields</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Checked By</TableHead>
                  <TableHead>Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result) => (
                  <TableRow key={result.id}>
                    <TableCell className="font-medium">{result.memoRef}</TableCell>
                    <TableCell>{result.product}</TableCell>
                    <TableCell>{getResultBadge(result.conformityResult)}</TableCell>
                    <TableCell>{result.failedFields || '-'}</TableCell>
                    <TableCell className="max-w-xs truncate" title={result.reason}>
                      {result.reason || '-'}
                    </TableCell>
                    <TableCell>{result.checkedBy}</TableCell>
                    <TableCell>{format(new Date(result.timestamp), 'PPp')}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}