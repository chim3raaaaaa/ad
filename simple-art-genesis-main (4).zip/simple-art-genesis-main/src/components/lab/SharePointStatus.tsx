import React, { useState, useEffect } from 'react';
import { FileSpreadsheet, RefreshCw, CheckCircle, XCircle, Clock, Wifi, WifiOff } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { useToast } from '../../hooks/use-toast';

interface SharePointStatusProps {
  onSyncNow?: () => void;
}

export function SharePointStatus({ onSyncNow }: SharePointStatusProps) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [lastSync, setLastSync] = useState<Date | null>(new Date(Date.now() - 30 * 60 * 1000)); // 30 minutes ago
  const [syncInProgress, setSyncInProgress] = useState(false);
  const [syncStats, setSyncStats] = useState({
    testResults: 0,
    analyzedResults: 0,
    errors: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleSyncNow = async () => {
    if (!isOnline) {
      toast({
        title: "No Internet Connection",
        description: "Please check your internet connection and try again.",
        variant: "destructive"
      });
      return;
    }

    setSyncInProgress(true);
    
    try {
      // Simulate sync process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Simulate results
      const newStats = {
        testResults: Math.floor(Math.random() * 20) + 5,
        analyzedResults: Math.floor(Math.random() * 10) + 2,
        errors: Math.random() > 0.8 ? Math.floor(Math.random() * 3) : 0
      };
      
      setSyncStats(newStats);
      setLastSync(new Date());
      
      if (onSyncNow) {
        onSyncNow();
      }
      
      toast({
        title: "SharePoint Sync Completed",
        description: `Imported ${newStats.testResults} test results and ${newStats.analyzedResults} analyzed results.`,
      });
    } catch (error) {
      toast({
        title: "Sync Failed",
        description: "Failed to sync with SharePoint. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setSyncInProgress(false);
    }
  };

  const getTimeSinceLastSync = () => {
    if (!lastSync) return "Never";
    
    const now = new Date();
    const diffMs = now.getTime() - lastSync.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hours ago`;
    return `${Math.floor(diffMins / 1440)} days ago`;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            SharePoint Integration
          </CardTitle>
          <div className="flex items-center gap-2">
            {isOnline ? (
              <Wifi className="h-4 w-4 text-green-600" />
            ) : (
              <WifiOff className="h-4 w-4 text-red-600" />
            )}
            <Badge variant={isOnline ? "default" : "destructive"}>
              {isOnline ? "Online" : "Offline"}
            </Badge>
          </div>
        </div>
        <CardDescription>
          Automatic sync with SharePoint Excel files for test results
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Sync Status */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Last Sync:</span>
            <span className="text-muted-foreground">{getTimeSinceLastSync()}</span>
          </div>
          
          {syncInProgress && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Syncing with SharePoint...</span>
              </div>
              <Progress value={33} className="h-2" />
            </div>
          )}
        </div>

        {/* Sync Statistics */}
        {(syncStats.testResults > 0 || syncStats.analyzedResults > 0) && (
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="space-y-1">
              <p className="text-2xl font-bold text-blue-600">{syncStats.testResults}</p>
              <p className="text-xs text-muted-foreground">Test Results</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-green-600">{syncStats.analyzedResults}</p>
              <p className="text-xs text-muted-foreground">Analyzed Results</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-red-600">{syncStats.errors}</p>
              <p className="text-xs text-muted-foreground">Errors</p>
            </div>
          </div>
        )}

        {/* Sync Actions */}
        <div className="flex gap-2">
          <Button 
            onClick={handleSyncNow}
            disabled={!isOnline || syncInProgress}
            className="flex-1"
            size="sm"
          >
            {syncInProgress ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Sync Now
              </>
            )}
          </Button>
        </div>

        {/* Connection Info */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Automatic sync every 30 minutes</p>
          <p>• Validates batches after 15 minutes timeout</p>
          <p>• Offline mode: Local database only</p>
        </div>
      </CardContent>
    </Card>
  );
}