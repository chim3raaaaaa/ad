import { useState } from "react";
import { Clock, AlertTriangle, CheckCircle, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { TestCalendarEvent } from "@/types";
import { Checkbox } from "@/components/ui/checkbox";

interface TestListViewProps {
  events: TestCalendarEvent[];
  onMarkDone: (eventId: string) => void;
  selectedEvents?: string[];
  onSelectEvent?: (eventId: string, selected: boolean) => void;
  showSelection?: boolean;
}

export const TestListView = ({ 
  events, 
  onMarkDone, 
  selectedEvents = [], 
  onSelectEvent, 
  showSelection = false 
}: TestListViewProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"date" | "product" | "status">("date");
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "overdue" | "today">("all");

  const getFilteredAndSortedEvents = () => {
    let filtered = events;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(event => 
        (event.memo_id || event.id).toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.test_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.plant_location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.location?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply status filter
    if (filterStatus !== "all") {
      filtered = filtered.filter(event => {
        switch (filterStatus) {
          case "pending":
            return (event.status === 'scheduled' || event.status === 'pending') && (event.remaining_days || 0) > 0;
          case "overdue":
            return event.status === 'overdue';
          case "today":
            return (event.remaining_days || 0) === 0 && event.status !== 'overdue';
          default:
            return true;
        }
      });
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "date":
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        case "product":
          return a.product.localeCompare(b.product);
        case "status":
          if (a.status === 'overdue' && b.status !== 'overdue') return -1;
          if (a.status !== 'overdue' && b.status === 'overdue') return 1;
          if ((a.remaining_days || 0) === 0 && (b.remaining_days || 0) !== 0) return -1;
          if ((a.remaining_days || 0) !== 0 && (b.remaining_days || 0) === 0) return 1;
          return (a.remaining_days || 0) - (b.remaining_days || 0);
        default:
          return 0;
      }
    });

    return filtered;
  };

  const getEventIcon = (event: TestCalendarEvent) => {
    if (event.status === 'completed') return <CheckCircle className="h-4 w-4 text-success" />;
    if (event.status === 'overdue') return <AlertTriangle className="h-4 w-4 text-destructive" />;
    return <Clock className="h-4 w-4 text-primary" />;
  };

  const getStatusBadge = (event: TestCalendarEvent) => {
    if (event.status === 'completed') {
      return <Badge variant="secondary" className="bg-success/20 text-success-foreground">Completed</Badge>;
    }
    if (event.status === 'overdue') {
      return <Badge variant="destructive">Overdue ({Math.abs(event.remaining_days || 0)}d)</Badge>;
    }
    if ((event.remaining_days || 0) === 0) {
      return <Badge variant="secondary" className="bg-warning/20 text-warning-foreground">Due Today</Badge>;
    }
    return <Badge variant="outline">Due in {event.remaining_days || 0}d</Badge>;
  };

  const filteredEvents = getFilteredAndSortedEvents();

  return (
    <Card className="p-6">
      {/* Filters and Controls */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Input
          placeholder="Search tests..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
        />
        
        <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
          <SelectTrigger className="w-full sm:w-[150px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date">Date</SelectItem>
            <SelectItem value="product">Product</SelectItem>
            <SelectItem value="status">Status</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={(value: any) => setFilterStatus(value)}>
          <SelectTrigger className="w-full sm:w-[150px]">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Tests</SelectItem>
            <SelectItem value="today">Due Today</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
            <SelectItem value="pending">Upcoming</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Results Summary */}
      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filteredEvents.length} of {events.length} tests
      </div>

      {/* Events List */}
      <div className="space-y-3">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No tests found matching your criteria</p>
          </div>
        ) : (
          filteredEvents.map(event => (
            <Card key={event.id} className="p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1">
                  {showSelection && onSelectEvent && (
                    <Checkbox
                      checked={selectedEvents.includes(event.id)}
                      onCheckedChange={(checked) => onSelectEvent(event.id, !!checked)}
                      className="mt-1"
                    />
                  )}
                  {getEventIcon(event)}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium truncate">{event.memo_id || event.id}</h3>
                      {getStatusBadge(event)}
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-sm text-muted-foreground mb-2">
                      <div><strong>Product:</strong> {event.product}</div>
                      <div><strong>Test:</strong> {event.test_type}</div>
                      <div><strong>Lab:</strong> {event.plant_location || event.location || 'N/A'}</div>
                      <div><strong>Date:</strong> {new Date(event.due_date).toLocaleDateString()}</div>
                    </div>

                    {(event.batch_number || event.assigned_to) && (
                      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                        {event.batch_number && (
                          <span><strong>Batch:</strong> {event.batch_number}</span>
                        )}
                        {event.assigned_to && (
                          <span><strong>Assigned:</strong> {event.assigned_to}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {event.status !== 'completed' && (
                  <Button
                    size="sm"
                    onClick={() => onMarkDone(event.id)}
                    className="shrink-0"
                  >
                    Mark Done
                  </Button>
                )}
              </div>
            </Card>
          ))
        )}
      </div>
    </Card>
  );
};