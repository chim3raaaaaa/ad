import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  TrendingUp, 
  TrendingDown,
  Calendar,
  FileX,
  Activity,
  Bell,
  Target,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DashboardMetrics {
  pendingTests: number;
  overdueItems: number;
  failedValidations: number;
  completedToday: number;
  totalTests: number;
  averageCompletionTime: string;
  criticalAlerts: number;
  complianceRate: number;
}

interface StatusItem {
  id: string;
  title: string;
  status: 'pending' | 'overdue' | 'completed' | 'failed';
  priority: 'low' | 'medium' | 'high' | 'critical';
  dueDate: string;
  assignedTo: string;
  category: string;
}

const statusColors = {
  pending: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  overdue: 'bg-red-500/10 text-red-600 border-red-500/20',
  completed: 'bg-green-500/10 text-green-600 border-green-500/20',
  failed: 'bg-red-500/10 text-red-600 border-red-500/20'
};

const priorityColors = {
  low: 'bg-slate-100 text-slate-600',
  medium: 'bg-blue-100 text-blue-600',
  high: 'bg-orange-100 text-orange-600',
  critical: 'bg-red-100 text-red-600'
};

const StatusIndicator = ({ status }: { status: string }) => {
  const getStatusIcon = () => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'overdue': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="flex items-center gap-2">
      {getStatusIcon()}
      <span className="text-sm capitalize">{status}</span>
    </div>
  );
};

export default function StatusDrivenDashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    pendingTests: 0,
    overdueItems: 0,
    failedValidations: 0,
    completedToday: 0,
    totalTests: 0,
    averageCompletionTime: '0h',
    criticalAlerts: 0,
    complianceRate: 0
  });

  const [statusItems, setStatusItems] = useState<StatusItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Initialize with comprehensive mock data
  useEffect(() => {
    const mockMetrics: DashboardMetrics = {
      pendingTests: 12,
      overdueItems: 3,
      failedValidations: 2,
      completedToday: 8,
      totalTests: 25,
      averageCompletionTime: '2.5h',
      criticalAlerts: 1,
      complianceRate: 94.2
    };

    const mockStatusItems: StatusItem[] = [
      {
        id: '1',
        title: 'Concrete Cube Test - Batch A001',
        status: 'overdue',
        priority: 'critical',
        dueDate: '2024-02-20',
        assignedTo: 'John Smith',
        category: 'Compressive Strength'
      },
      {
        id: '2',
        title: 'Mix Design Validation - C30 Grade',
        status: 'pending',
        priority: 'high',
        dueDate: '2024-02-22',
        assignedTo: 'Sarah Johnson',
        category: 'Mix Design'
      },
      {
        id: '3',
        title: 'Slump Test - Fresh Concrete',
        status: 'failed',
        priority: 'medium',
        dueDate: '2024-02-21',
        assignedTo: 'Mike Davis',
        category: 'Fresh Properties'
      },
      {
        id: '4',
        title: 'Quality Report Generation',
        status: 'completed',
        priority: 'medium',
        dueDate: '2024-02-21',
        assignedTo: 'Lisa Wilson',
        category: 'Reporting'
      },
      {
        id: '5',
        title: 'Environmental Compliance Check',
        status: 'pending',
        priority: 'high',
        dueDate: '2024-02-23',
        assignedTo: 'Tom Brown',
        category: 'Compliance'
      }
    ];

    setMetrics(mockMetrics);
    setStatusItems(mockStatusItems);
    setLoading(false);
  }, []);

  const criticalItems = statusItems.filter(item => 
    item.status === 'overdue' || item.priority === 'critical'
  );

  const completionRate = metrics.totalTests > 0 
    ? Math.round((metrics.completedToday / metrics.totalTests) * 100)
    : 0;

  if (loading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="space-y-0 pb-2">
              <div className="h-4 bg-muted rounded w-3/4"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-muted rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Critical Alerts */}
      {criticalItems.length > 0 && (
        <Alert className="border-red-200 bg-red-50/50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertTitle className="text-red-800">Critical Items Require Attention</AlertTitle>
          <AlertDescription className="text-red-700">
            {criticalItems.length} items are overdue or marked as critical priority.
            <Button variant="link" className="p-0 ml-2 h-auto text-red-600">
              View Details →
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Status Metrics Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {/* Pending Tests */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Tests</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{metrics.pendingTests}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.pendingTests > 10 ? '🟡' : '🟢'} Awaiting execution
            </p>
          </CardContent>
        </Card>

        {/* Overdue Items */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{metrics.overdueItems}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.overdueItems > 0 ? '🔴' : '🟢'} Past due date
            </p>
          </CardContent>
        </Card>

        {/* Failed Validations */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed Validations</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{metrics.failedValidations}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.failedValidations > 0 ? '🔴' : '🟢'} Quality issues
            </p>
          </CardContent>
        </Card>

        {/* Compliance Rate */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Compliance Rate</CardTitle>
            <Target className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{metrics.complianceRate}%</div>
            <p className="text-xs text-muted-foreground">
              {metrics.complianceRate >= 95 ? '🟢' : metrics.complianceRate >= 85 ? '🟡' : '🔴'} Quality standard
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Overview */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Daily Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Tests Completed Today</span>
                <span>{metrics.completedToday}/{metrics.totalTests}</span>
              </div>
              <Progress value={completionRate} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {completionRate}% completion rate
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Average Completion Time</span>
                <span>{metrics.averageCompletionTime}</span>
              </div>
              {parseFloat(metrics.averageCompletionTime) > 3 ? (
                <div className="flex items-center gap-1 text-orange-600">
                  <TrendingUp className="w-3 h-3" />
                  <span className="text-xs">Above target time</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-green-600">
                  <TrendingDown className="w-3 h-3" />
                  <span className="text-xs">On target</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Status Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Status Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {statusItems.slice(0, 4).map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="space-y-1">
                    <div className="font-medium text-sm">{item.title}</div>
                    <div className="flex items-center gap-2">
                      <StatusIndicator status={item.status} />
                      <Badge variant="outline" className={cn("text-xs", priorityColors[item.priority])}>
                        {item.priority}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">{item.assignedTo}</div>
                    <div className="text-xs text-muted-foreground">Due: {item.dueDate}</div>
                  </div>
                </div>
              ))}
            </div>
            
            <Button variant="outline" className="w-full mt-4">
              View All Items
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Alert Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            System Alerts & Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-center gap-3 p-4 rounded-lg bg-yellow-50 border border-yellow-200">
              <Calendar className="w-8 h-8 text-yellow-600" />
              <div>
                <div className="font-medium text-yellow-800">Upcoming Deadlines</div>
                <div className="text-sm text-yellow-600">5 tests due this week</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg bg-red-50 border border-red-200">
              <FileX className="w-8 h-8 text-red-600" />
              <div>
                <div className="font-medium text-red-800">Quality Issues</div>
                <div className="text-sm text-red-600">2 validation failures</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg bg-green-50 border border-green-200">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <div className="font-medium text-green-800">Recent Completions</div>
                <div className="text-sm text-green-600">8 tests completed today</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}