import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAggregatesIntegration } from '@/hooks/useAggregatesIntegration';
import { EnhancedGradingConformityChecker } from '@/components/aggregates/EnhancedGradingConformityChecker';
import { EnhancedSieveAnalysis } from '@/components/aggregates/EnhancedSieveAnalysis';
import { MoistureContentInput } from '@/components/aggregates/MoistureContentInput';
import { SandEquivalentInput } from '@/components/aggregates/SandEquivalentInput';
import { MethyleneBlueInput } from '@/components/aggregates/MethyleneBlueInput';
import { AggregateTestEntry } from '@/services/database/aggregateTestService';
import { AggregateCalculationService } from '@/services/database/aggregateCalculationService';
import { CalculationFormulaService } from '@/services/database/calculationFormulaService';
import { TestTube, Calculator, Beaker, Save, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AggregatesTestEntryModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialData?: AggregateTestEntry;
  plantId?: string;
}

export function AggregatesTestEntryModal({
  open,
  onClose,
  onSuccess,
  initialData,
  plantId
}: AggregatesTestEntryModalProps) {
  const { memoOptions, aggregateTypes, loading: integrationLoading, dropdownOptions } = useAggregatesIntegration();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('basic');
  const [entryId, setEntryId] = useState<string>(initialData?.id || '');
  const [fineness_modulus, setFinenessModulus] = useState<number>(0);
  const [totalSampleMass, setTotalSampleMass] = useState<number>(100); // Default 100g sample

  const [formData, setFormData] = useState({
    memo_reference: '',
    sampling_date: '',
    material_type: '',
    officer_id: '',
    machine_no: '',
    location: '',
    sample_id: '',
    remarks: '',
    // Sieve analysis data - raw masses
    sieve_075_mass: '',
    sieve_150_mass: '',
    sieve_300_mass: '',
    sieve_600_mass: '',
    sieve_118_mass: '',
    sieve_236_mass: '',
    sieve_475_mass: '',
    sieve_950_mass: '',
    sieve_2_mass: '',
    sieve_5_mass: '',
    sieve_10_mass: '',
    sieve_14_mass: '',
    sieve_20_mass: '',
    sieve_28_mass: '',
    sieve_40_mass: '',
    // Physical properties
    specific_gravity: '',
    bulk_density: '',
    water_absorption: '',
    // Test results
    los_angeles_abrasion: '',
    aggregate_impact_value: '',
    aggregate_crushing_value: '',
    flakiness_index: '',
    elongation_index: '',
    soundness_test: ''
  });

  // Calculated percentages from raw masses
  const [sievePercentages, setSievePercentages] = useState<Record<string, number>>({});

  useEffect(() => {
    if (open && initialData) {
      setFormData({
        memo_reference: initialData.memo_reference || '',
        sampling_date: initialData.sampling_date || '',
        material_type: initialData.material_type || '',
        officer_id: initialData.officer_id || '',
        machine_no: initialData.machine_no || '',
        location: initialData.location || '',
        sample_id: initialData.sample_id || '',
        remarks: initialData.remarks || '',
        sieve_075_mass: '',
        sieve_150_mass: '',
        sieve_300_mass: '',
        sieve_600_mass: '',
        sieve_118_mass: '',
        sieve_236_mass: '',
        sieve_475_mass: '',
        sieve_950_mass: '',
        sieve_2_mass: '',
        sieve_5_mass: '',
        sieve_10_mass: '',
        sieve_14_mass: '',
        sieve_20_mass: '',
        sieve_28_mass: '',
        sieve_40_mass: '',
        specific_gravity: initialData.specific_gravity?.toString() || '',
        bulk_density: initialData.bulk_density?.toString() || '',
        water_absorption: initialData.water_absorption?.toString() || '',
        los_angeles_abrasion: initialData.los_angeles_abrasion?.toString() || '',
        aggregate_impact_value: initialData.aggregate_impact_value?.toString() || '',
        aggregate_crushing_value: initialData.aggregate_crushing_value?.toString() || '',
        flakiness_index: initialData.flakiness_index?.toString() || '',
        elongation_index: initialData.elongation_index?.toString() || '',
        soundness_test: initialData.soundness_test?.toString() || ''
      });
      setEntryId(initialData.id || '');
    }
  }, [open, initialData]);

  // Calculate percentages and fineness modulus when raw masses change
  useEffect(() => {
    calculateSievePercentages();
  }, [formData, totalSampleMass]);

  const calculateSievePercentages = async () => {
    if (totalSampleMass <= 0) return;

    const sieveSizes = ['075', '150', '300', '600', '118', '236', '475', '950', '2', '5', '10', '14', '20', '28', '40'];
    const newPercentages: Record<string, number> = {};
    let cumulativeRetained = 0;

    try {
      for (const size of sieveSizes) {
        const massKey = `sieve_${size}_mass`;
        const mass = parseFloat(formData[massKey]) || 0;
        cumulativeRetained += mass;

        // Calculate % passing using formula service
        const percentPassing = await CalculationFormulaService.evaluateFormula('Percent Passing', {
          cum_retained: cumulativeRetained,
          total_mass: totalSampleMass
        });

        newPercentages[size] = percentPassing;

        // Save to database if we have an entry ID
        if (entryId && mass > 0) {
          await AggregateCalculationService.saveSieveRawMass({
            test_entry_id: entryId,
            sieve_size: size.replace('_', '.'),
            cumulative_retained: cumulativeRetained,
            total_sample_mass: totalSampleMass
          });
        }
      }

      setSievePercentages(newPercentages);

      // Calculate fineness modulus
      if (entryId) {
        const fm = await AggregateCalculationService.calculateFinenessModulus(entryId);
        setFinenessModulus(fm);
      }
    } catch (error) {
      console.error('Error calculating sieve percentages:', error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.memo_reference || !formData.sampling_date || !formData.material_type || !formData.officer_id) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Create aggregate test entry
      const entryData = {
        memo_reference: formData.memo_reference,
        sampling_date: formData.sampling_date,
        material_type: formData.material_type,
        officer_id: formData.officer_id,
        machine_no: formData.machine_no,
        location: formData.location,
        sample_id: formData.sample_id,
        remarks: formData.remarks,
        production_date: new Date().toISOString(),
        test_date: new Date().toISOString(),
        plant_id: plantId || 'default',
        aggregate_type_id: formData.material_type,
        machine_id: formData.machine_no,
        sampling_place_id: formData.location,
        moisture_condition_id: 'normal',
        climatic_condition_id: 'normal',
        sampled_by_id: formData.officer_id,
        
        // Calculated sieve data (% passing)
        sieve_075: sievePercentages['075'] || null,
        sieve_150: sievePercentages['150'] || null,
        sieve_300: sievePercentages['300'] || null,
        sieve_600: sievePercentages['600'] || null,
        sieve_118: sievePercentages['118'] || null,
        sieve_236: sievePercentages['236'] || null,
        sieve_475: sievePercentages['475'] || null,
        sieve_950: sievePercentages['950'] || null,
        sieve_2: sievePercentages['2'] || null,
        sieve_5: sievePercentages['5'] || null,
        sieve_10: sievePercentages['10'] || null,
        sieve_14: sievePercentages['14'] || null,
        sieve_20: sievePercentages['20'] || null,
        sieve_28: sievePercentages['28'] || null,
        sieve_40: sievePercentages['40'] || null,
        
        // Physical properties
        specific_gravity: parseFloat(formData.specific_gravity) || null,
        bulk_density: parseFloat(formData.bulk_density) || null,
        water_absorption: parseFloat(formData.water_absorption) || null,
        
        // Test results
        los_angeles_abrasion: parseFloat(formData.los_angeles_abrasion) || null,
        aggregate_impact_value: parseFloat(formData.aggregate_impact_value) || null,
        aggregate_crushing_value: parseFloat(formData.aggregate_crushing_value) || null,
        flakiness_index: parseFloat(formData.flakiness_index) || null,
        elongation_index: parseFloat(formData.elongation_index) || null,
        soundness_test: parseFloat(formData.soundness_test) || null,
        
        // Calculated values
        fineness_modulus: fineness_modulus,
        
        // Default values
        moisture_content: null,
        sand_equivalent: null,
        methylene_blue: null,
        bulk_density_loose: null,
        bulk_density_compacted: null,
        bulk_density_ssd: null,
        bulk_density_apparent: null,
        bulk_density_oven_dried: null,
        organic_impurities: null,
        grading_conformity: 'pending' as const,
        cleanliness_conformity: 'pending' as const,
        test_performed: true,
        calculation_sheet_path: null
      };

      // Get or create plant database table
      const selectedMemo = memoOptions.find(memo => memo.id === formData.memo_reference);
      const tableName = `${plantId || selectedMemo?.plant_id || 'default'}_aggregates_tests`;
      
      // Create test entry
      const result = await AggregateCalculationService.createTestEntry(tableName, entryData);
      
      if (!entryId && result?.id) {
        setEntryId(result.id);
      }

      toast({
        title: "Success",
        description: "Aggregate test entry saved successfully."
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving test entry:', error);
      toast({
        title: "Save Error",
        description: "Failed to save aggregate test entry.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getSieveDisplayData = () => {
    const sieveSizes = [
      { key: '075', label: '0.075mm', mass_field: 'sieve_075_mass' },
      { key: '150', label: '0.150mm', mass_field: 'sieve_150_mass' },
      { key: '300', label: '0.300mm', mass_field: 'sieve_300_mass' },
      { key: '600', label: '0.600mm', mass_field: 'sieve_600_mass' },
      { key: '118', label: '1.18mm', mass_field: 'sieve_118_mass' },
      { key: '236', label: '2.36mm', mass_field: 'sieve_236_mass' },
      { key: '475', label: '4.75mm', mass_field: 'sieve_475_mass' },
      { key: '950', label: '9.50mm', mass_field: 'sieve_950_mass' },
      { key: '2', label: '2mm', mass_field: 'sieve_2_mass' },
      { key: '5', label: '5mm', mass_field: 'sieve_5_mass' },
      { key: '10', label: '10mm', mass_field: 'sieve_10_mass' },
      { key: '14', label: '14mm', mass_field: 'sieve_14_mass' },
      { key: '20', label: '20mm', mass_field: 'sieve_20_mass' },
      { key: '28', label: '28mm', mass_field: 'sieve_28_mass' },
      { key: '40', label: '40mm', mass_field: 'sieve_40_mass' }
    ];

    return sieveSizes.map(sieve => ({
      ...sieve,
      mass: parseFloat(formData[sieve.mass_field]) || 0,
      percentage: sievePercentages[sieve.key] || 0
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5" />
            {initialData ? 'Edit Aggregates Test Entry' : 'New Aggregates Test Entry'}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="sieve">Sieve Analysis</TabsTrigger>
            <TabsTrigger value="moisture">Moisture Content</TabsTrigger>
            <TabsTrigger value="sand">Sand Equivalent</TabsTrigger>
            <TabsTrigger value="methylene">Methylene Blue</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Test Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="memo_reference">Memo Reference *</Label>
                  <Select 
                    value={formData.memo_reference} 
                    onValueChange={(value) => handleInputChange('memo_reference', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select memo reference" />
                    </SelectTrigger>
                    <SelectContent>
                      {memoOptions.map((memo) => (
                        <SelectItem key={memo.id} value={memo.id}>
                          {memo.title} - {memo.plant_id} ({memo.machine_no})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sampling_date">Sampling Date *</Label>
                  <Input
                    id="sampling_date"
                    type="date"
                    value={formData.sampling_date}
                    onChange={(e) => handleInputChange('sampling_date', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="material_type">Material Type *</Label>
                  <Select 
                    value={formData.material_type} 
                    onValueChange={(value) => handleInputChange('material_type', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select material type" />
                    </SelectTrigger>
                    <SelectContent>
                      {aggregateTypes.map((type) => (
                        <SelectItem key={type.id} value={type.name}>
                          {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="officer_id">Officer *</Label>
                  <Select 
                    value={formData.officer_id} 
                    onValueChange={(value) => handleInputChange('officer_id', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select officer" />
                    </SelectTrigger>
                    <SelectContent>
                      {dropdownOptions?.officers?.map((officer) => (
                        <SelectItem key={officer.id} value={officer.id}>
                          {officer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="machine_no">Machine No.</Label>
                  <Input
                    id="machine_no"
                    value={formData.machine_no}
                    onChange={(e) => handleInputChange('machine_no', e.target.value)}
                    placeholder="Enter machine number"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    placeholder="Enter sampling location"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sample_id">Sample ID</Label>
                  <Input
                    id="sample_id"
                    value={formData.sample_id}
                    onChange={(e) => handleInputChange('sample_id', e.target.value)}
                    placeholder="Enter sample identifier"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Physical Properties */}
            <Card>
              <CardHeader>
                <CardTitle>Physical Properties</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="specific_gravity">Specific Gravity</Label>
                  <Input
                    id="specific_gravity"
                    type="number"
                    step="0.01"
                    value={formData.specific_gravity}
                    onChange={(e) => handleInputChange('specific_gravity', e.target.value)}
                    placeholder="Enter specific gravity"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bulk_density">Bulk Density (kg/m³)</Label>
                  <Input
                    id="bulk_density"
                    type="number"
                    step="0.1"
                    value={formData.bulk_density}
                    onChange={(e) => handleInputChange('bulk_density', e.target.value)}
                    placeholder="Enter bulk density"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                  <Input
                    id="water_absorption"
                    type="number"
                    step="0.1"
                    value={formData.water_absorption}
                    onChange={(e) => handleInputChange('water_absorption', e.target.value)}
                    placeholder="Enter water absorption"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Test Results */}
            <Card>
              <CardHeader>
                <CardTitle>Test Results</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="los_angeles_abrasion">Los Angeles Abrasion (%)</Label>
                  <Input
                    id="los_angeles_abrasion"
                    type="number"
                    step="0.1"
                    value={formData.los_angeles_abrasion}
                    onChange={(e) => handleInputChange('los_angeles_abrasion', e.target.value)}
                    placeholder="Enter LA abrasion"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="aggregate_impact_value">Aggregate Impact Value (%)</Label>
                  <Input
                    id="aggregate_impact_value"
                    type="number"
                    step="0.1"
                    value={formData.aggregate_impact_value}
                    onChange={(e) => handleInputChange('aggregate_impact_value', e.target.value)}
                    placeholder="Enter impact value"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="aggregate_crushing_value">Aggregate Crushing Value (%)</Label>
                  <Input
                    id="aggregate_crushing_value"
                    type="number"
                    step="0.1"
                    value={formData.aggregate_crushing_value}
                    onChange={(e) => handleInputChange('aggregate_crushing_value', e.target.value)}
                    placeholder="Enter crushing value"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="flakiness_index">Flakiness Index (%)</Label>
                  <Input
                    id="flakiness_index"
                    type="number"
                    step="0.1"
                    value={formData.flakiness_index}
                    onChange={(e) => handleInputChange('flakiness_index', e.target.value)}
                    placeholder="Enter flakiness index"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="elongation_index">Elongation Index (%)</Label>
                  <Input
                    id="elongation_index"
                    type="number"
                    step="0.1"
                    value={formData.elongation_index}
                    onChange={(e) => handleInputChange('elongation_index', e.target.value)}
                    placeholder="Enter elongation index"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="soundness_test">Soundness Test (%)</Label>
                  <Input
                    id="soundness_test"
                    type="number"
                    step="0.1"
                    value={formData.soundness_test}
                    onChange={(e) => handleInputChange('soundness_test', e.target.value)}
                    placeholder="Enter soundness test"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Remarks */}
            <Card>
              <CardHeader>
                <CardTitle>Remarks</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="remarks"
                  value={formData.remarks}
                  onChange={(e) => handleInputChange('remarks', e.target.value)}
                  placeholder="Enter any additional remarks"
                  rows={3}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sieve" className="space-y-6">
            {/* Sample Mass Input */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Sample Configuration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="total_sample_mass">Total Sample Mass (g)</Label>
                    <Input
                      id="total_sample_mass"
                      type="number"
                      step="0.1"
                      value={totalSampleMass}
                      onChange={(e) => setTotalSampleMass(parseFloat(e.target.value) || 100)}
                      placeholder="Enter total sample mass"
                    />
                  </div>
                  {fineness_modulus > 0 && (
                    <div className="flex items-center">
                      <div className="p-3 bg-muted rounded-lg">
                        <Label className="text-sm text-muted-foreground">Fineness Modulus</Label>
                        <div className="text-xl font-bold">{fineness_modulus.toFixed(2)}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Sieve Analysis with Live Graph */}
            <EnhancedSieveAnalysis
              testEntryId={entryId}
              aggregateType={formData.material_type}
              onDataChange={(data) => {
                // Update form data with sieve analysis results
                setFormData(prev => ({ ...prev, ...data }));
              }}
              onFinenessModulusChange={(fm) => {
                setFinenessModulus(fm);
              }}
            />
          </TabsContent>

          <TabsContent value="moisture">
            {entryId ? (
              <MoistureContentInput
                testEntryId={entryId}
                onDataChange={(data) => console.log('Moisture content saved:', data)}
              />
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <div className="text-center">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Save basic info first to enable moisture content testing</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="sand">
            {entryId ? (
              <SandEquivalentInput
                testEntryId={entryId}
                onDataChange={(data) => console.log('Sand equivalent saved:', data)}
              />
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <div className="text-center">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Save basic info first to enable sand equivalent testing</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="methylene">
            {entryId ? (
              <MethyleneBlueInput
                testEntryId={entryId}
                onDataChange={(data) => console.log('Methylene blue saved:', data)}
              />
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <div className="text-center">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Save basic info first to enable methylene blue testing</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="h-4 w-4 mr-2" />
            {loading ? 'Saving...' : (initialData ? 'Update Entry' : 'Create Entry')}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}