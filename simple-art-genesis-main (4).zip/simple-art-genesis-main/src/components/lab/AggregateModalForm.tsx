import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Plus, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';
import { memoApiService } from '@/services/api/memoApiService';

interface AggregateProductionEntry {
  id: string;
  aggregateType: string;
  machineNo: string;
  remarks: string;
}

interface AggregateModalFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  selectedCategory: string;
}

export const AggregateModalForm: React.FC<AggregateModalFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  selectedCategory
}) => {
  const { toast } = useToast();
  
  // Form state
  const [formData, setFormData] = useState({
    plant: '',
    officerInCharge: '',
    lorryNo: '',
    reference: '',
    dateOfMemo: new Date(),
    typeOfTest: '',
    remarks: '',
    climaticConditions: '',
    placeOfSampling: '',
    samplingDate: new Date(),
    productionDate: new Date(),
    sampledBy: '',
    receivedBy: '',
    sentBy: '',
    additionalRemarks: ''
  });

  // Reference data state
  const [plants, setPlants] = useState<any[]>([]);
  const [officers, setOfficers] = useState<any[]>([]);
  const [testTypes, setTestTypes] = useState<any[]>([]);
  const [climaticConditions, setClimaticConditions] = useState<any[]>([]);
  const [samplingPlaces, setSamplingPlaces] = useState<any[]>([]);
  const [sampledByOptions, setSampledByOptions] = useState<any[]>([]);
  const [machines, setMachines] = useState<any[]>([]);
  const [aggregateTypes, setAggregateTypes] = useState<any[]>([]);
  
  // Production entries state
  const [productionEntries, setProductionEntries] = useState<AggregateProductionEntry[]>([
    {
      id: '1',
      aggregateType: '',
      machineNo: '',
      remarks: ''
    }
  ]);

  const [loading, setLoading] = useState(false);

  // Load reference data on mount
  useEffect(() => {
    if (isOpen) {
      loadReferenceData();
      generateNewReference();
    }
  }, [isOpen]);

  // Filter machines based on selected plant
  useEffect(() => {
    if (formData.plant && machines.length > 0) {
      const filteredMachines = machines.filter(machine => 
        machine.plant_id === formData.plant
      );
      // Update machine selections in production entries if they're no longer valid
      setProductionEntries(prev => 
        prev.map(entry => ({
          ...entry,
          machineNo: filteredMachines.find(m => m.machine_id === entry.machineNo) ? entry.machineNo : ''
        }))
      );
    }
  }, [formData.plant, machines]);

  const loadReferenceData = async () => {
    try {
      setLoading(true);
      
      // Load existing reference data
      const [plantsData, officersData, testTypesData, machinesData, aggregateTypesData] = await Promise.all([
        enhancedReferenceDataService.getPlants(),
        enhancedReferenceDataService.getOfficers(),
        enhancedReferenceDataService.getTestTypes(),
        enhancedReferenceDataService.getMachines(),
        enhancedReferenceDataService.getAggregates()
      ]);

      setPlants(plantsData);
      setOfficers(officersData);
      setTestTypes(testTypesData);
      setMachines(machinesData);
      setAggregateTypes(aggregateTypesData);

      // Load additional reference data
      await loadAdditionalReferenceData();
      
    } catch (error) {
      console.error('Failed to load reference data:', error);
      toast({
        title: "Error",
        description: "Failed to load reference data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadAdditionalReferenceData = async () => {
    try {
      // Initialize tables without sample data for clean prototype
      await enhancedReferenceDataService.initializeAllReferenceTables();
      
      // Now load from the database
      const [climaticData, samplingPlacesData, sampledByData] = await Promise.all([
        enhancedReferenceDataService.getClimaticConditions(),
        enhancedReferenceDataService.getSamplingPlaces(),
        enhancedReferenceDataService.getSampledByOptions()
      ]);

      setClimaticConditions(climaticData);
      setSamplingPlaces(samplingPlacesData);
      setSampledByOptions(sampledByData);
    } catch (error) {
      console.error('Failed to load additional reference data:', error);
      // Fallback to hardcoded data
      setClimaticConditions([
        { climatic_id: '1', name: 'Cloudy / Rainy' },
        { climatic_id: '2', name: 'Sunny' },
        { climatic_id: '3', name: 'Partly Cloudy' },
        { climatic_id: '4', name: 'Overcast' }
      ]);

      setSamplingPlaces([
        { place_id: '1', name: 'Under Conveyor' },
        { place_id: '2', name: 'Storage Area' },
        { place_id: '3', name: 'Loading Point' },
        { place_id: '4', name: 'Stockpile' }
      ]);

      setSampledByOptions([
        { sampler_id: '1', name: 'Preetam Juliette' },
        { sampler_id: '2', name: 'Lab Technician' },
        { sampler_id: '3', name: 'Quality Control' },
        { sampler_id: '4', name: 'Site Engineer' }
      ]);
    }
  };

  const generateNewReference = async () => {
    try {
      const newRef = await memoApiService.generateNextReference();
      const rtaRef = `RTA${newRef.replace(/\D/g, '')}`;
      setFormData(prev => ({ ...prev, reference: rtaRef }));
    } catch (error) {
      console.error('Failed to generate reference:', error);
      const fallbackRef = `RTA${Date.now()}`;
      setFormData(prev => ({ ...prev, reference: fallbackRef }));
      toast({
        title: "Error",
        description: "Failed to generate reference number",
        variant: "destructive"
      });
    }
  };

  const handleFormChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addProductionEntry = () => {
    if (productionEntries.length < 6) {
      const newEntry: AggregateProductionEntry = {
        id: Date.now().toString(),
        aggregateType: '',
        machineNo: '',
        remarks: ''
      };
      setProductionEntries(prev => [...prev, newEntry]);
    }
  };

  const removeProductionEntry = (id: string) => {
    if (productionEntries.length > 1) {
      setProductionEntries(prev => prev.filter(entry => entry.id !== id));
    }
  };

  const updateProductionEntry = (id: string, field: string, value: string) => {
    setProductionEntries(prev =>
      prev.map(entry =>
        entry.id === id ? { ...entry, [field]: value } : entry
      )
    );
  };

  const getFilteredMachines = () => {
    if (!formData.plant) return machines;
    return machines.filter(machine => machine.plant_id === formData.plant);
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);

      // Validate required fields
      if (!formData.plant || !formData.officerInCharge || !formData.reference) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive"
        });
        return;
      }

      // Validate production entries
      const validEntries = productionEntries.filter(entry => 
        entry.aggregateType && entry.machineNo
      );

      if (validEntries.length === 0) {
        toast({
          title: "Validation Error",
          description: "Please add at least one production entry",
          variant: "destructive"
        });
        return;
      }

      const aggregateMemoData = {
        reference: formData.reference,
        date: formData.dateOfMemo.toISOString(),
        labSite: formData.plant,
        officerInCharge: formData.officerInCharge,
        lorry: formData.lorryNo,
        blocksCount: validEntries.length,
        typeOfTest: formData.typeOfTest,
        retest: 'No',
        postedBy: formData.sentBy,
        testPerformed: 'Yes', // Always yes for aggregates
        productions: validEntries.map((entry, index) => ({
          production: `AGG-${index + 1}`,
          testDate: formData.samplingDate.toISOString(),
          productionDate: formData.productionDate.toISOString(),
          ageDays: 0,
          category: 'aggregates',
          product: entry.aggregateType,
          grade: '',
          gradeMpa: '0',
          machineNo: entry.machineNo,
          mouldRef: '',
          sampleNo: `AGG-${index + 1}`,
          sampleCount: 1,
          blockPosition: '',
          testPerformed: true,
          remarks: entry.remarks
        })),
        // Additional aggregate-specific data
        aggregateFields: {
          climaticConditions: formData.climaticConditions,
          placeOfSampling: formData.placeOfSampling,
          samplingDate: formData.samplingDate.toISOString(),
          sampledBy: formData.sampledBy,
          receivedBy: formData.receivedBy,
          additionalRemarks: formData.additionalRemarks
        }
      };

      // Submit the memo
      const result = await memoApiService.submitMemo(aggregateMemoData);
      
      if (result.success) {
        toast({
          title: "Success",
          description: "Aggregate memo created successfully",
        });
        onSubmit(aggregateMemoData);
        onClose();
        resetForm();
      } else {
        throw new Error(result.error || 'Failed to submit memo');
      }

    } catch (error) {
      console.error('Failed to submit aggregate memo:', error);
      toast({
        title: "Error",
        description: "Failed to create aggregate memo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      plant: '',
      officerInCharge: '',
      lorryNo: '',
      reference: '',
      dateOfMemo: new Date(),
      typeOfTest: '',
      remarks: '',
      climaticConditions: '',
      placeOfSampling: '',
      samplingDate: new Date(),
      productionDate: new Date(),
      sampledBy: '',
      receivedBy: '',
      sentBy: '',
      additionalRemarks: ''
    });
    setProductionEntries([{
      id: '1',
      aggregateType: '',
      machineNo: '',
      remarks: ''
    }]);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            Aggregate Memo Form - {selectedCategory}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-muted-foreground">Loading reference data...</div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Header Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Plant */}
              <div className="space-y-2">
                <Label htmlFor="plant">Plant/Site *</Label>
                <Select value={formData.plant} onValueChange={(value) => handleFormChange('plant', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select plant" />
                  </SelectTrigger>
                  <SelectContent>
                    {plants.map((plant) => (
                      <SelectItem key={plant.plant_id} value={plant.plant_id}>
                        {plant.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Officer in Charge */}
              <div className="space-y-2">
                <Label htmlFor="officerInCharge">Officer in Charge *</Label>
                <Select value={formData.officerInCharge} onValueChange={(value) => handleFormChange('officerInCharge', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select officer" />
                  </SelectTrigger>
                  <SelectContent>
                    {officers.map((officer) => (
                      <SelectItem key={officer.officer_id} value={officer.officer_id}>
                        {officer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Lorry No */}
              <div className="space-y-2">
                <Label htmlFor="lorryNo">Lorry No.</Label>
                <Input
                  id="lorryNo"
                  value={formData.lorryNo}
                  onChange={(e) => handleFormChange('lorryNo', e.target.value)}
                  placeholder="e.g., 8965AG23"
                />
              </div>

              {/* Reference */}
              <div className="space-y-2">
                <Label htmlFor="reference">Reference *</Label>
                <Input
                  id="reference"
                  value={formData.reference}
                  onChange={(e) => handleFormChange('reference', e.target.value)}
                  placeholder="Auto-generated"
                  readOnly
                />
              </div>

              {/* Date of Memo */}
              <div className="space-y-2">
                <Label>Date of Memo</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.dateOfMemo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.dateOfMemo ? format(formData.dateOfMemo, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.dateOfMemo}
                      onSelect={(date) => handleFormChange('dateOfMemo', date)}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Type of Test */}
              <div className="space-y-2">
                <Label htmlFor="typeOfTest">Type of Test</Label>
                <Select value={formData.typeOfTest} onValueChange={(value) => handleFormChange('typeOfTest', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select test type" />
                  </SelectTrigger>
                  <SelectContent>
                    {testTypes.map((testType) => (
                      <SelectItem key={testType.test_type_id} value={testType.test_type_id}>
                        {testType.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Second row of fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Climatic Conditions */}
              <div className="space-y-2">
                <Label htmlFor="climaticConditions">Climatic Conditions</Label>
                <Select value={formData.climaticConditions} onValueChange={(value) => handleFormChange('climaticConditions', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select conditions" />
                  </SelectTrigger>
                  <SelectContent>
                    {climaticConditions.map((condition) => (
                      <SelectItem key={condition.climatic_id || condition.id} value={condition.climatic_id || condition.id}>
                        {condition.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Place of Sampling */}
              <div className="space-y-2">
                <Label htmlFor="placeOfSampling">Place of Sampling</Label>
                <Select value={formData.placeOfSampling} onValueChange={(value) => handleFormChange('placeOfSampling', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sampling place" />
                  </SelectTrigger>
                  <SelectContent>
                    {samplingPlaces.map((place) => (
                      <SelectItem key={place.place_id || place.id} value={place.place_id || place.id}>
                        {place.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sampled By */}
              <div className="space-y-2">
                <Label htmlFor="sampledBy">Sampled By</Label>
                <Select value={formData.sampledBy} onValueChange={(value) => handleFormChange('sampledBy', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sampler" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampledByOptions.map((sampler) => (
                      <SelectItem key={sampler.sampler_id || sampler.id} value={sampler.sampler_id || sampler.id}>
                        {sampler.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sampling Date */}
              <div className="space-y-2">
                <Label>Sampling Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.samplingDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.samplingDate ? format(formData.samplingDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.samplingDate}
                      onSelect={(date) => handleFormChange('samplingDate', date)}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Production Date */}
              <div className="space-y-2">
                <Label>Production Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.productionDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.productionDate ? format(formData.productionDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.productionDate}
                      onSelect={(date) => handleFormChange('productionDate', date)}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Additional text fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="receivedBy">Received By (Name)</Label>
                <Input
                  id="receivedBy"
                  value={formData.receivedBy}
                  onChange={(e) => handleFormChange('receivedBy', e.target.value)}
                  placeholder="Enter name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="sentBy">Sent By (Name)</Label>
                <Input
                  id="sentBy"
                  value={formData.sentBy}
                  onChange={(e) => handleFormChange('sentBy', e.target.value)}
                  placeholder="Enter name"
                />
              </div>
            </div>

            {/* Remarks */}
            <div className="space-y-2">
              <Label htmlFor="remarks">Remarks</Label>
              <Textarea
                id="remarks"
                value={formData.remarks}
                onChange={(e) => handleFormChange('remarks', e.target.value)}
                placeholder="Enter remarks..."
                rows={3}
              />
            </div>

            {/* Production Details Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Production Details</h3>
                <Button
                  type="button"
                  onClick={addProductionEntry}
                  disabled={productionEntries.length >= 6}
                  size="sm"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Entry
                </Button>
              </div>

              <div className="space-y-3">
                {productionEntries.map((entry, index) => (
                  <div key={entry.id} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Production Entry {index + 1}</h4>
                      {productionEntries.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeProductionEntry(entry.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {/* Aggregate Type */}
                      <div className="space-y-2">
                        <Label>Aggregate Type</Label>
                        <Select
                          value={entry.aggregateType}
                          onValueChange={(value) => updateProductionEntry(entry.id, 'aggregateType', value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select aggregate type" />
                          </SelectTrigger>
                          <SelectContent>
                            {aggregateTypes.map((aggType) => (
                              <SelectItem key={aggType.agg_type_id} value={aggType.agg_type_id}>
                                {aggType.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Machine No */}
                      <div className="space-y-2">
                        <Label>Machine No.</Label>
                        <Select
                          value={entry.machineNo}
                          onValueChange={(value) => updateProductionEntry(entry.id, 'machineNo', value)}
                          disabled={!formData.plant}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={formData.plant ? "Select machine" : "Select plant first"} />
                          </SelectTrigger>
                          <SelectContent>
                            {getFilteredMachines().map((machine) => (
                              <SelectItem key={machine.machine_id} value={machine.machine_id}>
                                {machine.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Remarks */}
                      <div className="space-y-2">
                        <Label>Remarks</Label>
                        <Input
                          value={entry.remarks}
                          onChange={(e) => updateProductionEntry(entry.id, 'remarks', e.target.value)}
                          placeholder="Optional remarks"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Additional Remarks */}
            <div className="space-y-2">
              <Label htmlFor="additionalRemarks">Additional Remarks</Label>
              <Textarea
                id="additionalRemarks"
                value={formData.additionalRemarks}
                onChange={(e) => handleFormChange('additionalRemarks', e.target.value)}
                placeholder="Enter additional remarks..."
                rows={3}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={onClose} disabled={loading}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={loading}>
                {loading ? 'Submitting...' : 'Create Aggregate Memo'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};