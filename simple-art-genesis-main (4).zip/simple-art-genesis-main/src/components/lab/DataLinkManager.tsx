import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Link, 
  Plus, 
  Trash2, 
  Eye, 
  Database, 
  ArrowRight,
  AlertTriangle,
  CheckCircle,
  Settings
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export interface DataLink {
  id: string;
  name: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  linkType: '1:1' | '1:N' | 'N:1' | 'N:N' | 'lookup';
  cascadeDelete: boolean;
  cascadeUpdate: boolean;
  enforceReferentialIntegrity: boolean;
  description?: string;
  created_at: string;
  created_by: string;
}

const LINK_TYPES = [
  { value: '1:1', label: 'One-to-One (1:1)', description: 'Each record in source links to exactly one record in target' },
  { value: '1:N', label: 'One-to-Many (1:N)', description: 'One source record can link to multiple target records' },
  { value: 'N:1', label: 'Many-to-One (N:1)', description: 'Multiple source records link to one target record' },
  { value: 'N:N', label: 'Many-to-Many (N:N)', description: 'Records can have multiple links in both directions' },
  { value: 'lookup', label: 'Lookup', description: 'Simple reference for display purposes only' }
];

const AVAILABLE_TABLES = [
  'memos',
  'test_requests',
  'user_profiles',
  'user_roles',
  'custom_forms',
  'custom_tables',
  'production_data',
  'test_results',
  'audit_logs'
];

const TABLE_FIELDS = {
  memos: ['id', 'ref', 'created_at', 'production_data', 'user_id'],
  test_requests: ['id', 'client_name', 'sample_description', 'test_type', 'priority', 'status', 'assigned_to', 'due_date', 'user_id'],
  user_profiles: ['id', 'user_id', 'name', 'email', 'role', 'department', 'status'],
  user_roles: ['id', 'name', 'description', 'permissions'],
  custom_forms: ['id', 'name', 'description', 'fields', 'created_by'],
  custom_tables: ['id', 'name', 'description', 'columns', 'data_source', 'created_by'],
  production_data: ['id', 'memo_id', 'production_number', 'product', 'grade', 'machine_no'],
  test_results: ['id', 'test_request_id', 'result_value', 'unit', 'status', 'tested_by'],
  audit_logs: ['id', 'user_id', 'action', 'resource_type', 'resource_id']
};

export function DataLinkManager() {
  const { toast } = useToast();
  const [dataLinks, setDataLinks] = useState<DataLink[]>([]);

  // Load existing data links from database or localStorage
  useEffect(() => {
    loadDataLinks();
  }, []);

  const loadDataLinks = async () => {
    try {
      let links: DataLink[] = [];
      
      if (window.electronAPI) {
        // Load from database
        const result = await window.electronAPI.dbQuery(`
          SELECT * FROM data_links 
          ORDER BY created_at DESC
        `);
        
        if (result.success && result.data) {
          links = result.data;
        }
      } else {
        // Load from localStorage for web preview
        const saved = localStorage.getItem('data_links');
        if (saved) {
          links = JSON.parse(saved);
        }
      }
      
      setDataLinks(links);
    } catch (error) {
      console.error('Failed to load data links:', error);
    }
  };

  const [newLink, setNewLink] = useState<Partial<DataLink>>({
    linkType: '1:N',
    cascadeDelete: false,
    cascadeUpdate: true,
    enforceReferentialIntegrity: true
  });

  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedLink, setSelectedLink] = useState<DataLink | null>(null);

  const createDataLink = async () => {
    if (!newLink.name || !newLink.sourceTable || !newLink.sourceField || !newLink.targetTable || !newLink.targetField) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const link: DataLink = {
      id: `link_${Date.now()}`,
      name: newLink.name!,
      sourceTable: newLink.sourceTable!,
      sourceField: newLink.sourceField!,
      targetTable: newLink.targetTable!,
      targetField: newLink.targetField!,
      linkType: newLink.linkType as DataLink['linkType'],
      cascadeDelete: newLink.cascadeDelete || false,
      cascadeUpdate: newLink.cascadeUpdate || true,
      enforceReferentialIntegrity: newLink.enforceReferentialIntegrity || true,
      description: newLink.description,
      created_at: new Date().toISOString(),
      created_by: 'current_user'
    };

    // Save to database or localStorage
    if (window.electronAPI) {
      try {
        await window.electronAPI.dbRun(`
          INSERT INTO data_links (id, name, source_table, source_field, target_table, target_field, link_type, cascade_delete, cascade_update, enforce_referential_integrity, description, created_at, created_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [link.id, link.name, link.sourceTable, link.sourceField, link.targetTable, link.targetField, link.linkType, link.cascadeDelete, link.cascadeUpdate, link.enforceReferentialIntegrity, link.description, link.created_at, link.created_by]);
      } catch (error) {
        console.error('Failed to save data link:', error);
      }
    } else {
      // Save to localStorage
      const updated = [...dataLinks, link];
      localStorage.setItem('data_links', JSON.stringify(updated));
    }

    setDataLinks(prev => [...prev, link]);
    setNewLink({
      linkType: '1:N',
      cascadeDelete: false,
      cascadeUpdate: true,
      enforceReferentialIntegrity: true
    });
    setShowCreateDialog(false);

    toast({
      title: "Data Link Created",
      description: `${link.name} has been created successfully`
    });
  };

  const deleteDataLink = async (id: string) => {
    const link = dataLinks.find(l => l.id === id);
    if (!link) return;

    // Delete from database or localStorage
    if (window.electronAPI) {
      try {
        await window.electronAPI.dbRun('DELETE FROM data_links WHERE id = ?', [id]);
      } catch (error) {
        console.error('Failed to delete data link:', error);
      }
    } else {
      // Delete from localStorage
      const updated = dataLinks.filter(l => l.id !== id);
      localStorage.setItem('data_links', JSON.stringify(updated));
    }

    setDataLinks(prev => prev.filter(l => l.id !== id));
    
    toast({
      title: "Data Link Deleted",
      description: `${link.name} has been removed`
    });
  };

  const getLinkTypeIcon = (linkType: string) => {
    switch (linkType) {
      case '1:1': return '⟷';
      case '1:N': return '→';
      case 'N:1': return '←';
      case 'N:N': return '⟷';
      case 'lookup': return '👁';
      default: return '→';
    }
  };

  const getLinkTypeColor = (linkType: string) => {
    switch (linkType) {
      case '1:1': return 'bg-blue-500';
      case '1:N': return 'bg-green-500';
      case 'N:1': return 'bg-orange-500';
      case 'N:N': return 'bg-purple-500';
      case 'lookup': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const validateLink = (link: Partial<DataLink>): string[] => {
    const errors: string[] = [];
    
    if (!link.name) errors.push('Link name is required');
    if (!link.sourceTable) errors.push('Source table is required');
    if (!link.sourceField) errors.push('Source field is required');
    if (!link.targetTable) errors.push('Target table is required');
    if (!link.targetField) errors.push('Target field is required');
    
    if (link.sourceTable === link.targetTable && link.sourceField === link.targetField) {
      errors.push('Source and target cannot be the same field');
    }
    
    return errors;
  };

  const errors = validateLink(newLink);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Data Link Manager</h3>
          <p className="text-sm text-muted-foreground">Create and manage relationships between data tables</p>
        </div>
        
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Link
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Data Link</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label>Link Name</Label>
                <Input
                  value={newLink.name || ''}
                  onChange={(e) => setNewLink(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., User to Profile"
                />
              </div>

              <div>
                <Label>Description</Label>
                <Input
                  value={newLink.description || ''}
                  onChange={(e) => setNewLink(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe this relationship"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Source</Label>
                  <div>
                    <Label className="text-xs">Table</Label>
                    <Select value={newLink.sourceTable} onValueChange={(value) => setNewLink(prev => ({ ...prev, sourceTable: value, sourceField: '' }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select source table" />
                      </SelectTrigger>
                      <SelectContent>
                        {AVAILABLE_TABLES.map(table => (
                          <SelectItem key={table} value={table}>{table}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Field</Label>
                    <Select value={newLink.sourceField} onValueChange={(value) => setNewLink(prev => ({ ...prev, sourceField: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select source field" />
                      </SelectTrigger>
                      <SelectContent>
                        {(newLink.sourceTable ? TABLE_FIELDS[newLink.sourceTable] || [] : []).map(field => (
                          <SelectItem key={field} value={field}>{field}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Target</Label>
                  <div>
                    <Label className="text-xs">Table</Label>
                    <Select value={newLink.targetTable} onValueChange={(value) => setNewLink(prev => ({ ...prev, targetTable: value, targetField: '' }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select target table" />
                      </SelectTrigger>
                      <SelectContent>
                        {AVAILABLE_TABLES.map(table => (
                          <SelectItem key={table} value={table}>{table}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Field</Label>
                    <Select value={newLink.targetField} onValueChange={(value) => setNewLink(prev => ({ ...prev, targetField: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select target field" />
                      </SelectTrigger>
                      <SelectContent>
                        {(newLink.targetTable ? TABLE_FIELDS[newLink.targetTable] || [] : []).map(field => (
                          <SelectItem key={field} value={field}>{field}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div>
                <Label>Link Type</Label>
                <Select value={newLink.linkType} onValueChange={(value) => setNewLink(prev => ({ ...prev, linkType: value as DataLink['linkType'] }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LINK_TYPES.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        <div>
                          <div className="font-medium">{type.label}</div>
                          <div className="text-xs text-muted-foreground">{type.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Cascade Delete</Label>
                  <Switch
                    checked={newLink.cascadeDelete}
                    onCheckedChange={(checked) => setNewLink(prev => ({ ...prev, cascadeDelete: checked }))}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Cascade Update</Label>
                  <Switch
                    checked={newLink.cascadeUpdate}
                    onCheckedChange={(checked) => setNewLink(prev => ({ ...prev, cascadeUpdate: checked }))}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Enforce Referential Integrity</Label>
                  <Switch
                    checked={newLink.enforceReferentialIntegrity}
                    onCheckedChange={(checked) => setNewLink(prev => ({ ...prev, enforceReferentialIntegrity: checked }))}
                  />
                </div>
              </div>

              {errors.length > 0 && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <ul className="list-disc list-inside">
                      {errors.map((error, index) => (
                        <li key={index}>{error}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={createDataLink} disabled={errors.length > 0}>
                  Create Link
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="visual" className="space-y-4">
        <TabsList>
          <TabsTrigger value="visual">Visual View</TabsTrigger>
          <TabsTrigger value="list">List View</TabsTrigger>
          <TabsTrigger value="diagram">Entity Diagram</TabsTrigger>
        </TabsList>

        <TabsContent value="visual" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {dataLinks.map(link => (
              <Card key={link.id} className="relative">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">{link.name}</CardTitle>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="sm" onClick={() => setSelectedLink(link)}>
                        <Eye className="w-3 h-3" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => deleteDataLink(link.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <div className="text-center">
                      <div className="font-medium">{link.sourceTable}</div>
                      <div className="text-xs text-muted-foreground">{link.sourceField}</div>
                    </div>
                    
                    <div className="flex flex-col items-center">
                      <Badge className={`${getLinkTypeColor(link.linkType)} text-white text-xs`}>
                        {getLinkTypeIcon(link.linkType)} {link.linkType}
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground mt-1" />
                    </div>
                    
                    <div className="text-center">
                      <div className="font-medium">{link.targetTable}</div>
                      <div className="text-xs text-muted-foreground">{link.targetField}</div>
                    </div>
                  </div>

                  {link.description && (
                    <p className="text-xs text-muted-foreground">{link.description}</p>
                  )}

                  <div className="flex gap-1 flex-wrap">
                    {link.cascadeDelete && <Badge variant="destructive" className="text-xs">Cascade Delete</Badge>}
                    {link.cascadeUpdate && <Badge variant="outline" className="text-xs">Cascade Update</Badge>}
                    {link.enforceReferentialIntegrity && <Badge variant="secondary" className="text-xs">Integrity</Badge>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <div className="space-y-2">
            {dataLinks.map(link => (
              <Card key={link.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <Badge className={`${getLinkTypeColor(link.linkType)} text-white`}>
                      {link.linkType}
                    </Badge>
                    <div>
                      <div className="font-medium">{link.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {link.sourceTable}.{link.sourceField} → {link.targetTable}.{link.targetField}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {link.enforceReferentialIntegrity && <CheckCircle className="w-4 h-4 text-green-500" />}
                    <Button variant="ghost" size="sm" onClick={() => setSelectedLink(link)}>
                      <Settings className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => deleteDataLink(link.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="diagram" className="space-y-4">
          <Card>
            <CardContent className="p-6">
              <div className="text-center text-muted-foreground py-8">
                <Database className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">Entity Relationship Diagram</h3>
                <p>Interactive diagram view coming soon</p>
                <p className="text-sm mt-2">Will show visual connections between all linked tables</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Link Details Dialog */}
      {selectedLink && (
        <Dialog open={!!selectedLink} onOpenChange={() => setSelectedLink(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{selectedLink.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Description</Label>
                <p className="text-sm text-muted-foreground">{selectedLink.description || 'No description'}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Source</Label>
                  <p className="text-sm">{selectedLink.sourceTable}.{selectedLink.sourceField}</p>
                </div>
                <div>
                  <Label>Target</Label>
                  <p className="text-sm">{selectedLink.targetTable}.{selectedLink.targetField}</p>
                </div>
              </div>

              <div>
                <Label>Link Type</Label>
                <Badge className={`${getLinkTypeColor(selectedLink.linkType)} text-white`}>
                  {selectedLink.linkType}
                </Badge>
              </div>

              <div className="space-y-2">
                <Label>Options</Label>
                <div className="space-y-1 text-sm">
                  <div className="flex items-center gap-2">
                    {selectedLink.cascadeDelete ? <CheckCircle className="w-4 h-4 text-green-500" /> : <div className="w-4 h-4" />}
                    Cascade Delete
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedLink.cascadeUpdate ? <CheckCircle className="w-4 h-4 text-green-500" /> : <div className="w-4 h-4" />}
                    Cascade Update
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedLink.enforceReferentialIntegrity ? <CheckCircle className="w-4 h-4 text-green-500" /> : <div className="w-4 h-4" />}
                    Enforce Referential Integrity
                  </div>
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                Created by {selectedLink.created_by} on {new Date(selectedLink.created_at).toLocaleString()}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}