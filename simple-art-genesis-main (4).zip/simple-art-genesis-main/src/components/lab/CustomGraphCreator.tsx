import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { BarChart, LineChart, PieChart, Activity, Plus, Trash2, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ResponsiveContainer, BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart as RechartsLineChart, Line, PieChart as RechartsPieChart, Pie, Cell } from "recharts";

interface CustomChart {
  id: string;
  user_id: string;
  chart_name: string;
  chart_type: string;
  data_source: string;
  chart_config: string;
  filters: string;
  created_at: string;
  updated_at: string;
}

interface CustomGraphCreatorProps {
  userId: string;
}

const CHART_TYPES = [
  { value: "bar", label: "Bar Chart", icon: BarChart },
  { value: "line", label: "Line Chart", icon: LineChart },
  { value: "pie", label: "Pie Chart", icon: PieChart }
];

const DATA_SOURCES = [
  { value: "test_requests", label: "Test Requests", description: "Laboratory test request data" },
  { value: "users", label: "Users", description: "User activity and information" },
  { value: "comments", label: "Comments", description: "Comments and feedback data" },
  { value: "calendar_events", label: "Calendar Events", description: "Scheduled events and activities" }
];

const AGGREGATION_TYPES = [
  { value: "count", label: "Count" },
  { value: "sum", label: "Sum" },
  { value: "avg", label: "Average" },
  { value: "min", label: "Minimum" },
  { value: "max", label: "Maximum" }
];

export function CustomGraphCreator({ userId }: CustomGraphCreatorProps) {
  const [charts, setCharts] = useState<CustomChart[]>([]);
  const [isCreatingChart, setIsCreatingChart] = useState(false);
  const [chartName, setChartName] = useState("");
  const [chartType, setChartType] = useState("");
  const [dataSource, setDataSource] = useState("");
  const [xAxisField, setXAxisField] = useState("");
  const [yAxisField, setYAxisField] = useState("");
  const [aggregationType, setAggregationType] = useState("count");
  const [filters, setFilters] = useState("");
  const [previewData, setPreviewData] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadUserCharts();
  }, [userId]);

  const loadUserCharts = async () => {
    try {
      // Load charts from database or localStorage
      let userCharts: CustomChart[] = [];
      
      if (window.electronAPI) {
        // Load from database in Electron environment
        const result = await window.electronAPI.dbQuery(`
          SELECT * FROM custom_charts 
          WHERE user_id = ? 
          ORDER BY created_at DESC
        `, [userId]);
        
        if (result.success && result.data) {
          userCharts = result.data;
        }
      } else {
        // Load from localStorage for web preview
        const saved = localStorage.getItem(`custom_charts_${userId}`);
        if (saved) {
          userCharts = JSON.parse(saved);
        }
      }
      
      setCharts(userCharts);
    } catch (error) {
      console.error("Error loading user charts:", error);
      toast({
        title: "Error",
        description: "Failed to load custom charts",
        variant: "destructive"
      });
    }
  };

  const generatePreviewData = async () => {
    if (!dataSource) return;

    try {
      let queryData: any[] = [];
      
      if (window.electronAPI) {
        // Generate real data from database
        let query = '';
        switch (dataSource) {
          case "test_requests":
            query = `
              SELECT 
                strftime('%Y-%m', created_at) as period,
                COUNT(*) as value
              FROM test_requests 
              GROUP BY strftime('%Y-%m', created_at)
              ORDER BY period DESC
              LIMIT 10
            `;
            break;
          case "users":
            query = `
              SELECT 
                role as category,
                COUNT(*) as value
              FROM profiles 
              GROUP BY role
            `;
            break;
          case "calendar_events":
            query = `
              SELECT 
                DATE(date) as period,
                COUNT(*) as value
              FROM calendar_events 
              WHERE date >= date('now', '-30 days')
              GROUP BY DATE(date)
              ORDER BY period DESC
            `;
            break;
          default:
            query = `SELECT 'No Data' as period, 0 as value`;
        }
        
        const result = await window.electronAPI.dbQuery(query);
        if (result.success && result.data) {
          queryData = result.data;
        }
      }
      
      // Use query data or fallback to empty array
      setPreviewData(queryData.length > 0 ? queryData : []);
    } catch (error) {
      console.error("Error generating preview data:", error);
      toast({
        title: "Error",
        description: "Failed to generate preview data",
        variant: "destructive"
      });
    }
  };

  const saveChart = async () => {
    if (!chartName || !chartType || !dataSource) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      const chartId = `chart_${Date.now()}`;
      const config = JSON.stringify({
        xAxisField,
        yAxisField,
        aggregationType,
        chartType
      });

      const newChart: CustomChart = {
        id: chartId,
        user_id: userId,
        chart_name: chartName,
        chart_type: chartType,
        data_source: dataSource,
        chart_config: config,
        filters: filters || "",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      if (window.electronAPI) {
        // Save to database
        await window.electronAPI.dbRun(`
          INSERT INTO custom_charts (id, user_id, chart_name, chart_type, data_source, chart_config, filters, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [chartId, userId, chartName, chartType, dataSource, config, filters || "", newChart.created_at, newChart.updated_at]);
      } else {
        // Save to localStorage
        const existing = JSON.parse(localStorage.getItem(`custom_charts_${userId}`) || '[]');
        existing.unshift(newChart);
        localStorage.setItem(`custom_charts_${userId}`, JSON.stringify(existing));
      }

      setCharts([newChart, ...charts]);

      // Reset form
      setChartName("");
      setChartType("");
      setDataSource("");
      setXAxisField("");
      setYAxisField("");
      setAggregationType("count");
      setFilters("");
      setPreviewData([]);
      setIsCreatingChart(false);

      toast({
        title: "Success",
        description: "Custom chart created successfully"
      });
    } catch (error) {
      console.error("Error saving chart:", error);
      toast({
        title: "Error",
        description: "Failed to save chart",
        variant: "destructive"
      });
    }
  };

  const deleteChart = async (chartId: string) => {
    try {
      if (window.electronAPI) {
        // Delete from database
        await window.electronAPI.dbRun('DELETE FROM custom_charts WHERE id = ?', [chartId]);
      } else {
        // Delete from localStorage
        const existing = JSON.parse(localStorage.getItem(`custom_charts_${userId}`) || '[]');
        const filtered = existing.filter((c: CustomChart) => c.id !== chartId);
        localStorage.setItem(`custom_charts_${userId}`, JSON.stringify(filtered));
      }
      
      setCharts(charts.filter(c => c.id !== chartId));
      toast({
        title: "Success",
        description: "Chart deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting chart:", error);
      toast({
        title: "Error",
        description: "Failed to delete chart",
        variant: "destructive"
      });
    }
  };

  const renderPreviewChart = () => {
    if (!previewData.length || !chartType) return null;

    const colors = ["#8884d8", "#82ca9d", "#ffc658", "#ff7300", "#0088fe"];

    switch (chartType) {
      case "bar":
        return (
          <ResponsiveContainer width="100%" height={200}>
            <RechartsBarChart data={previewData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#8884d8" />
            </RechartsBarChart>
          </ResponsiveContainer>
        );
      case "line":
        return (
          <ResponsiveContainer width="100%" height={200}>
            <RechartsLineChart data={previewData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#8884d8" />
            </RechartsLineChart>
          </ResponsiveContainer>
        );
      case "pie":
        return (
          <ResponsiveContainer width="100%" height={200}>
            <RechartsPieChart>
              <Pie
                data={previewData}
                cx="50%"
                cy="50%"
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
                label={({ category, value }) => `${category}: ${value}`}
              >
                {previewData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip />
            </RechartsPieChart>
          </ResponsiveContainer>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Activity className="h-4 w-4 mr-2" />
          Create Custom Graph
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Custom Graph Creator</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Chart Creation */}
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Create New Chart</h3>
              <Button onClick={() => setIsCreatingChart(!isCreatingChart)}>
                <Plus className="h-4 w-4 mr-2" />
                New Chart
              </Button>
            </div>

            {isCreatingChart && (
              <Card>
                <CardHeader>
                  <CardTitle>Chart Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="chart-name">Chart Name</Label>
                    <Input
                      id="chart-name"
                      value={chartName}
                      onChange={(e) => setChartName(e.target.value)}
                      placeholder="Enter chart name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="chart-type">Chart Type</Label>
                    <Select value={chartType} onValueChange={setChartType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select chart type" />
                      </SelectTrigger>
                      <SelectContent>
                        {CHART_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center">
                              <type.icon className="h-4 w-4 mr-2" />
                              {type.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="data-source">Data Source</Label>
                    <Select value={dataSource} onValueChange={setDataSource}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select data source" />
                      </SelectTrigger>
                      <SelectContent>
                        {DATA_SOURCES.map((source) => (
                          <SelectItem key={source.value} value={source.value}>
                            <div>
                              <div className="font-medium">{source.label}</div>
                              <div className="text-xs text-muted-foreground">{source.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="aggregation">Aggregation Type</Label>
                    <Select value={aggregationType} onValueChange={setAggregationType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {AGGREGATION_TYPES.map((agg) => (
                          <SelectItem key={agg.value} value={agg.value}>
                            {agg.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="filters">Filters (Optional)</Label>
                    <Textarea
                      id="filters"
                      value={filters}
                      onChange={(e) => setFilters(e.target.value)}
                      placeholder="Enter SQL WHERE conditions (e.g., status = 'completed')"
                      rows={3}
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={generatePreviewData} variant="outline">
                      Preview Data
                    </Button>
                    <Button onClick={saveChart}>Save Chart</Button>
                    <Button variant="outline" onClick={() => setIsCreatingChart(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Preview */}
            {previewData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Chart Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  {renderPreviewChart()}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Saved Charts */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Your Custom Charts</h3>
            
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {charts.map((chart) => (
                <Card key={chart.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">{chart.chart_name}</h4>
                        <p className="text-sm text-muted-foreground capitalize">
                          {chart.chart_type} chart from {chart.data_source.replace('_', ' ')}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Created {new Date(chart.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteChart(chart.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {charts.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  No custom charts created yet.
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}