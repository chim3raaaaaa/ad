import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageCircle, Send, Search, PlusCircle, Users, Clock, AlertCircle } from "lucide-react";
import { useState } from "react";

interface Message {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  content: string;
  timestamp: string;
  isRead: boolean;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  type: 'message' | 'notification' | 'alert';
}

interface Conversation {
  id: string;
  participants: string[];
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
}

const messages: Message[] = [
  {
    id: "1",
    sender: "sarah.johnson@ubpmauritius.com",
    recipient: "john.smith@ubpmauritius.com",
    subject: "Test Request TR-2024-001 Update",
    content: "Hi John, I've reviewed the test request and noticed some issues with the sample parameters. Could you please check the pH requirements?",
    timestamp: "2024-01-15T10:30:00Z",
    isRead: false,
    priority: "normal",
    type: "message"
  },
  {
    id: "2",
    sender: "system@ubpmauritius.com",
    recipient: "all@ubpmauritius.com",
    subject: "System Maintenance Scheduled",
    content: "The system will be under maintenance tonight from 11 PM to 2 AM. Please save your work before this time.",
    timestamp: "2024-01-15T09:45:00Z",
    isRead: true,
    priority: "high",
    type: "notification"
  },
  {
    id: "3",
    sender: "emma.wilson@ubpmauritius.com",
    recipient: "sarah.johnson@ubpmauritius.com",
    subject: "Urgent: Equipment Calibration",
    content: "The pH meter needs immediate calibration. All tests are on hold until this is resolved.",
    timestamp: "2024-01-15T08:15:00Z",
    isRead: false,
    priority: "urgent",
    type: "alert"
  }
];

const conversations: Conversation[] = [
  {
    id: "1",
    participants: ["sarah.johnson@ubpmauritius.com", "john.smith@ubpmauritius.com"],
    lastMessage: "Could you please check the pH requirements?",
    timestamp: "2024-01-15T10:30:00Z",
    unreadCount: 2
  },
  {
    id: "2",
    participants: ["emma.wilson@ubpmauritius.com", "sarah.johnson@ubpmauritius.com"],
    lastMessage: "The pH meter needs immediate calibration.",
    timestamp: "2024-01-15T08:15:00Z",
    unreadCount: 1
  }
];

export function InternalMessaging() {
  const [activeTab, setActiveTab] = useState<'inbox' | 'compose' | 'conversations'>('inbox');
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [messageList, setMessageList] = useState(messages);
  const [conversationList, setConversationList] = useState(conversations);

  const [newMessage, setNewMessage] = useState({
    recipient: "",
    subject: "",
    content: "",
    priority: "normal"
  });

  const filteredMessages = messageList.filter(message => 
    message.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const unreadCount = messageList.filter(m => !m.isRead).length;

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'normal': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'alert': return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'notification': return <MessageCircle className="h-4 w-4 text-blue-600" />;
      default: return <MessageCircle className="h-4 w-4 text-green-600" />;
    }
  };

  const getInitials = (email: string) => {
    return email.split('@')[0].split('.').map(part => part[0]).join('').toUpperCase();
  };

  const markAsRead = (messageId: string) => {
    setMessageList(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, isRead: true } : msg
    ));
  };

  const sendMessage = () => {
    if (newMessage.recipient && newMessage.subject && newMessage.content) {
      const message: Message = {
        id: Date.now().toString(),
        sender: "current.user@ubpmauritius.com",
        recipient: newMessage.recipient,
        subject: newMessage.subject,
        content: newMessage.content,
        timestamp: new Date().toISOString(),
        isRead: false,
        priority: newMessage.priority as 'low' | 'normal' | 'high' | 'urgent',
        type: 'message'
      };

      setMessageList(prev => [message, ...prev]);
      setNewMessage({ recipient: "", subject: "", content: "", priority: "normal" });
      setActiveTab('inbox');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MessageCircle className="h-6 w-6" />
            Internal Messaging
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-2">
                {unreadCount}
              </Badge>
            )}
          </h2>
          <p className="text-muted-foreground">Communicate with team members and receive system notifications</p>
        </div>
        <Button onClick={() => setActiveTab('compose')}>
          <PlusCircle className="h-4 w-4 mr-2" />
          New Message
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{messageList.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{unreadCount}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversations</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{conversationList.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Urgent</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {messageList.filter(m => m.priority === 'urgent').length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex space-x-2">
        <Button 
          variant={activeTab === 'inbox' ? 'default' : 'outline'}
          onClick={() => setActiveTab('inbox')}
        >
          Inbox
        </Button>
        <Button 
          variant={activeTab === 'conversations' ? 'default' : 'outline'}
          onClick={() => setActiveTab('conversations')}
        >
          Conversations
        </Button>
        <Button 
          variant={activeTab === 'compose' ? 'default' : 'outline'}
          onClick={() => setActiveTab('compose')}
        >
          Compose
        </Button>
      </div>

      {activeTab === 'inbox' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Messages</CardTitle>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search messages..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {filteredMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors hover:bg-muted/50 ${
                          !message.isRead ? 'bg-primary/5 border-primary/20' : ''
                        } ${selectedMessage?.id === message.id ? 'border-primary' : ''}`}
                        onClick={() => {
                          setSelectedMessage(message);
                          markAsRead(message.id);
                        }}
                      >
                        <div className="flex items-start space-x-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>{getInitials(message.sender)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium truncate">
                                {message.sender.split('@')[0]}
                              </p>
                              <div className="flex items-center space-x-1">
                                {getTypeIcon(message.type)}
                                <Badge className={getPriorityColor(message.priority)} variant="outline">
                                  {message.priority}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">{message.subject}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(message.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            {selectedMessage ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{selectedMessage.subject}</CardTitle>
                    <div className="flex items-center space-x-2">
                      {getTypeIcon(selectedMessage.type)}
                      <Badge className={getPriorityColor(selectedMessage.priority)}>
                        {selectedMessage.priority}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarFallback>{getInitials(selectedMessage.sender)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{selectedMessage.sender}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(selectedMessage.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="prose max-w-none">
                    <p>{selectedMessage.content}</p>
                  </div>
                  <Separator className="my-4" />
                  <div className="flex space-x-2">
                    <Button size="sm">
                      <Send className="h-4 w-4 mr-2" />
                      Reply
                    </Button>
                    <Button size="sm" variant="outline">
                      Forward
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center">
                    <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Select a message to view</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}

      {activeTab === 'compose' && (
        <Card>
          <CardHeader>
            <CardTitle>Compose New Message</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="recipient">Recipient</Label>
                <Select value={newMessage.recipient} onValueChange={(value) => setNewMessage(prev => ({ ...prev, recipient: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select recipient" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sarah.johnson@ubpmauritius.com">Sarah Johnson</SelectItem>
                    <SelectItem value="john.smith@ubpmauritius.com">John Smith</SelectItem>
                    <SelectItem value="emma.wilson@ubpmauritius.com">Emma Wilson</SelectItem>
                    <SelectItem value="mike.davis@ubpmauritius.com">Mike Davis</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priority</Label>
                <Select value={newMessage.priority} onValueChange={(value) => setNewMessage(prev => ({ ...prev, priority: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject">Subject</Label>
              <Input
                id="subject"
                value={newMessage.subject}
                onChange={(e) => setNewMessage(prev => ({ ...prev, subject: e.target.value }))}
                placeholder="Enter subject"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Message</Label>
              <Textarea
                id="content"
                value={newMessage.content}
                onChange={(e) => setNewMessage(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Type your message here..."
                rows={8}
              />
            </div>

            <div className="flex space-x-2">
              <Button onClick={sendMessage}>
                <Send className="h-4 w-4 mr-2" />
                Send Message
              </Button>
              <Button variant="outline" onClick={() => setNewMessage({ recipient: "", subject: "", content: "", priority: "normal" })}>
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}