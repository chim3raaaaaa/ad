import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Eye, 
  Code2, 
  Database, 
  Link, 
  Settings,
  Search,
  Copy,
  Save,
  Trash2,
  Plus
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FieldMetadata {
  id: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'boolean' | 'select' | 'reference' | 'calculated';
  table: string;
  required: boolean;
  unique: boolean;
  indexed: boolean;
  defaultValue?: string;
  validation?: string;
  description?: string;
  displayName?: string;
  placeholder?: string;
  helpText?: string;
  options?: string[];
  linkedTable?: string;
  linkedField?: string;
  calculation?: string;
  visibility: 'visible' | 'hidden' | 'readonly';
  permissions: string[];
}

interface DataLink {
  id: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  linkType: '1:1' | '1:N' | 'N:1' | 'N:N' | 'lookup';
  cascadeDelete: boolean;
}

export function FieldInspector() {
  const { toast } = useToast();
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [selectedField, setSelectedField] = useState<string>('');
  const [fieldMetadata, setFieldMetadata] = useState<FieldMetadata | null>(null);
  const [dataLinks, setDataLinks] = useState<DataLink[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showJson, setShowJson] = useState(false);

  // Mock data for tables and fields
  const tables = [
    'memos',
    'test_requests', 
    'user_profiles',
    'user_roles',
    'custom_forms',
    'custom_tables',
    'audit_logs'
  ];

  const getFieldsForTable = (table: string): string[] => {
    const fieldMap = {
      memos: ['id', 'ref', 'created_at', 'production_data', 'user_id'],
      test_requests: ['id', 'client_name', 'sample_description', 'test_type', 'priority', 'status', 'assigned_to', 'due_date'],
      user_profiles: ['id', 'user_id', 'name', 'email', 'role', 'department', 'status'],
      user_roles: ['id', 'name', 'description', 'permissions'],
      custom_forms: ['id', 'name', 'description', 'fields', 'created_by'],
      custom_tables: ['id', 'name', 'description', 'columns', 'data_source'],
      audit_logs: ['id', 'user_id', 'action', 'resource_type', 'resource_id', 'old_data', 'new_data']
    };
    return fieldMap[table] || [];
  };

  const loadFieldMetadata = (table: string, field: string) => {
    // Mock field metadata - in real app, this would come from database schema
    const mockMetadata: FieldMetadata = {
      id: `${table}.${field}`,
      name: field,
      type: field.includes('id') ? 'reference' : field.includes('date') ? 'date' : 'text',
      table,
      required: field === 'id' || field.includes('name'),
      unique: field === 'id',
      indexed: field === 'id' || field.includes('_id'),
      defaultValue: field === 'status' ? 'active' : undefined,
      validation: field === 'email' ? 'email' : undefined,
      description: `${field} field in ${table} table`,
      displayName: field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      placeholder: `Enter ${field.replace(/_/g, ' ')}`,
      helpText: `This field stores ${field.replace(/_/g, ' ')} information`,
      options: field === 'status' ? ['active', 'inactive'] : field === 'priority' ? ['low', 'medium', 'high', 'urgent'] : undefined,
      linkedTable: field.includes('_id') ? field.replace('_id', 's') : undefined,
      linkedField: field.includes('_id') ? 'id' : undefined,
      visibility: 'visible',
      permissions: ['read', 'write']
    };

    setFieldMetadata(mockMetadata);
  };

  const loadDataLinks = (table: string, field: string) => {
    // Mock data links
    const mockLinks: DataLink[] = [
      {
        id: 'link_1',
        sourceTable: 'test_requests',
        sourceField: 'user_id',
        targetTable: 'user_profiles',
        targetField: 'id',
        linkType: 'N:1' as const,
        cascadeDelete: false
      },
      {
        id: 'link_2',
        sourceTable: 'memos',
        sourceField: 'user_id',
        targetTable: 'user_profiles', 
        targetField: 'id',
        linkType: 'N:1' as const,
        cascadeDelete: false
      }
    ].filter(link => 
      (link.sourceTable === table && link.sourceField === field) ||
      (link.targetTable === table && link.targetField === field)
    );

    setDataLinks(mockLinks);
  };

  useEffect(() => {
    if (selectedTable && selectedField) {
      loadFieldMetadata(selectedTable, selectedField);
      loadDataLinks(selectedTable, selectedField);
    }
  }, [selectedTable, selectedField]);

  const updateFieldMetadata = (updates: Partial<FieldMetadata>) => {
    if (!fieldMetadata) return;
    
    setFieldMetadata(prev => ({ ...prev!, ...updates }));
  };

  const saveFieldMetadata = () => {
    if (!fieldMetadata) return;

    // In real app, save to database
    console.log('Saving field metadata:', fieldMetadata);
    
    toast({
      title: "Field Updated",
      description: `${fieldMetadata.displayName} metadata has been saved`
    });
  };

  const copyFieldKey = () => {
    if (fieldMetadata) {
      navigator.clipboard.writeText(fieldMetadata.id);
      toast({
        title: "Copied",
        description: "Field key copied to clipboard"
      });
    }
  };

  const filteredTables = tables.filter(table => 
    table.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const fieldList = selectedTable ? getFieldsForTable(selectedTable) : [];
  const filteredFields = fieldList.filter(field =>
    field.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Field Inspector</h3>
          <p className="text-sm text-muted-foreground">Inspect and modify field properties and relationships</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowJson(!showJson)}>
            <Code2 className="w-4 h-4 mr-2" />
            {showJson ? 'Hide JSON' : 'Show JSON'}
          </Button>
          {fieldMetadata && (
            <Button onClick={saveFieldMetadata}>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Table and Field Browser */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Database className="w-4 h-4" />
              Schema Browser
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tables and fields..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredTables.map(table => (
                <div key={table} className="space-y-1">
                  <Button
                    variant={selectedTable === table ? "default" : "ghost"}
                    className="w-full justify-start text-sm"
                    onClick={() => {
                      setSelectedTable(table);
                      setSelectedField('');
                      setFieldMetadata(null);
                    }}
                  >
                    <Database className="w-3 h-3 mr-2" />
                    {table}
                  </Button>
                  
                  {selectedTable === table && (
                    <div className="ml-4 space-y-1">
                      {filteredFields.map(field => (
                        <Button
                          key={field}
                          variant={selectedField === field ? "secondary" : "ghost"}
                          size="sm"
                          className="w-full justify-start text-xs"
                          onClick={() => setSelectedField(field)}
                        >
                          {field}
                          {field === 'id' && <Badge variant="outline" className="ml-auto text-xs">PK</Badge>}
                          {field.includes('_id') && <Badge variant="outline" className="ml-auto text-xs">FK</Badge>}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Field Properties */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Field Properties
              {fieldMetadata && (
                <Button variant="ghost" size="sm" onClick={copyFieldKey}>
                  <Copy className="w-3 h-3" />
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {fieldMetadata ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{fieldMetadata.type}</Badge>
                  <Badge variant={fieldMetadata.required ? "default" : "secondary"}>
                    {fieldMetadata.required ? "Required" : "Optional"}
                  </Badge>
                  {fieldMetadata.unique && <Badge variant="outline">Unique</Badge>}
                  {fieldMetadata.indexed && <Badge variant="outline">Indexed</Badge>}
                </div>

                <div>
                  <Label>Display Name</Label>
                  <Input
                    value={fieldMetadata.displayName || ''}
                    onChange={(e) => updateFieldMetadata({ displayName: e.target.value })}
                  />
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={fieldMetadata.description || ''}
                    onChange={(e) => updateFieldMetadata({ description: e.target.value })}
                    rows={2}
                  />
                </div>

                <div>
                  <Label>Placeholder Text</Label>
                  <Input
                    value={fieldMetadata.placeholder || ''}
                    onChange={(e) => updateFieldMetadata({ placeholder: e.target.value })}
                  />
                </div>

                <div>
                  <Label>Help Text</Label>
                  <Input
                    value={fieldMetadata.helpText || ''}
                    onChange={(e) => updateFieldMetadata({ helpText: e.target.value })}
                  />
                </div>

                <div>
                  <Label>Default Value</Label>
                  <Input
                    value={fieldMetadata.defaultValue || ''}
                    onChange={(e) => updateFieldMetadata({ defaultValue: e.target.value })}
                  />
                </div>

                {fieldMetadata.type === 'select' && (
                  <div>
                    <Label>Options (one per line)</Label>
                    <Textarea
                      value={fieldMetadata.options?.join('\n') || ''}
                      onChange={(e) => updateFieldMetadata({ 
                        options: e.target.value.split('\n').filter(o => o.trim()) 
                      })}
                      placeholder="Option 1&#10;Option 2&#10;Option 3"
                      rows={3}
                    />
                  </div>
                )}

                <div>
                  <Label>Validation Rule</Label>
                  <Input
                    value={fieldMetadata.validation || ''}
                    onChange={(e) => updateFieldMetadata({ validation: e.target.value })}
                    placeholder="email, phone, regex:pattern"
                  />
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Required</Label>
                    <Switch
                      checked={fieldMetadata.required}
                      onCheckedChange={(checked) => updateFieldMetadata({ required: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label>Unique</Label>
                    <Switch
                      checked={fieldMetadata.unique}
                      onCheckedChange={(checked) => updateFieldMetadata({ unique: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label>Indexed</Label>
                    <Switch
                      checked={fieldMetadata.indexed}
                      onCheckedChange={(checked) => updateFieldMetadata({ indexed: checked })}
                    />
                  </div>
                </div>

                <div>
                  <Label>Visibility</Label>
                  <Select
                    value={fieldMetadata.visibility}
                    onValueChange={(value) => updateFieldMetadata({ visibility: value as any })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="visible">Visible</SelectItem>
                      <SelectItem value="hidden">Hidden</SelectItem>
                      <SelectItem value="readonly">Read Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <Eye className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Select a field to inspect its properties</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Data Relationships */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Link className="w-4 h-4" />
              Data Relationships
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {fieldMetadata && (
              <div className="space-y-4">
                {dataLinks.length > 0 ? (
                  <div className="space-y-3">
                    {dataLinks.map(link => (
                      <div key={link.id} className="p-3 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <Badge variant="outline">{link.linkType}</Badge>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="text-sm">
                          <div><strong>Source:</strong> {link.sourceTable}.{link.sourceField}</div>
                          <div><strong>Target:</strong> {link.targetTable}.{link.targetField}</div>
                          {link.cascadeDelete && (
                            <Badge variant="destructive" className="mt-1">Cascade Delete</Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-4">
                    <Link className="w-6 h-6 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No relationships found</p>
                  </div>
                )}

                <Button variant="outline" className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Relationship
                </Button>

                {fieldMetadata.linkedTable && (
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="text-sm font-medium mb-1">Foreign Key Reference</div>
                    <div className="text-sm text-muted-foreground">
                      Links to {fieldMetadata.linkedTable}.{fieldMetadata.linkedField}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* JSON View */}
      {showJson && fieldMetadata && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Code2 className="w-4 h-4" />
              Field Metadata JSON
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
              {JSON.stringify(fieldMetadata, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}