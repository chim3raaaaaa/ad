import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Search, Plus, TestTube, CheckCircle, XCircle, Clock, Download, RefreshCw, Filter, Wifi, WifiOff, Smartphone, Grid3X3, Box, Layers, Minus, Hexagon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { directInputService } from "@/services/database/DirectInputService";
import { OperatorTestEntryForm } from "./OperatorTestEntryForm";
import { useConcreteProductsAPI } from "@/hooks/useConcreteProductsAPI";
import { ConcreteProductsAPIService } from "@/services/database/concreteProductsAPIService";

export function ConcreteProductsTab() {
  const { toast } = useToast();
  const { 
    isConnected, 
    lastSyncTime, 
    connectedDevices, 
    getConnectionHealth 
  } = useConcreteProductsAPI();
  const [isLoading, setIsLoading] = useState(false);
  const [directInputResults, setDirectInputResults] = useState<any[]>([]);
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [selectedProductType, setSelectedProductType] = useState<string>("blocks");
  const [searchTerm, setSearchTerm] = useState("");
  const [memoGroups, setMemoGroups] = useState<any[]>([]);
  const [expandedMemos, setExpandedMemos] = useState<Set<string>>(new Set());
  const [stats, setStats] = useState({
    totalTests: 0,
    passedTests: 0,
    failedTests: 0,
    pendingTests: 0,
    avgStrength: 0
  });

  // Get connection health info
  const connectionHealth = getConnectionHealth();

  // Load initial data
  useEffect(() => {
    initializeAndLoadData();
  }, []);

  // Reload data when product type or search changes
  useEffect(() => {
    loadDirectInputResults();
  }, [selectedProductType, searchTerm]);

  const initializeAndLoadData = async () => {
    await directInputService.initialize();
    await loadDirectInputResults();
    await loadMemoGroups();
    await loadStats();
  };

  const loadDirectInputResults = async () => {
    setIsLoading(true);
    try {
      const filters = {
        productType: selectedProductType,
        memoReference: searchTerm || undefined
      };
      
      const results = await directInputService.getDirectInputResults(filters);
      setDirectInputResults(results);
    } catch (error) {
      console.error('Failed to load direct input results:', error);
      toast({
        title: "Error",
        description: "Failed to load test results",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadMemoGroups = async () => {
    try {
      const groups = await directInputService.getResultsByMemo();
      setMemoGroups(groups);
    } catch (error) {
      console.error('Failed to load memo groups:', error);
    }
  };

  const loadStats = async () => {
    try {
      const statsData = await directInputService.getStatsSummary();
      setStats(statsData);
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleTestEntrySuccess = (newResult: any) => {
    setDirectInputResults(prev => [newResult, ...prev]);
    loadMemoGroups();
    loadStats();
    toast({
      title: "Success",
      description: "Test result saved successfully"
    });
  };

  const handleExportCSV = async () => {
    try {
      const csvContent = [
        ['Memo', 'Production Date', 'Test Date', 'Age (days)', 'Operator', 'Machine', 'Product', 'Load (kN)', 'Weight (kg)', 'Strength (MPa)', 'Status', 'Data Source'].join(','),
        ...directInputResults.map(entry => [
          entry.memo_reference || '',
          entry.production_date || '',
          entry.test_date || '',
          entry.age_days || '',
          entry.operator_name || '',
          entry.machine_no || '',
          entry.product || '',
          entry.load_kn || '',
          entry.weight_kg || '',
          entry.strength_mpa || '',
          entry.status || '',
          entry.data_source || 'manual'
        ].join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `concrete-products-${selectedProductType}-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Success",
        description: "Concrete products test results exported to CSV"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export CSV",
        variant: "destructive"
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'default';
      case 'fail': return 'destructive';
      default: return 'secondary';
    }
  };

  const toggleMemoExpansion = (memoRef: string) => {
    const newExpanded = new Set(expandedMemos);
    if (newExpanded.has(memoRef)) {
      newExpanded.delete(memoRef);
    } else {
      newExpanded.add(memoRef);
    }
    setExpandedMemos(newExpanded);
  };

  // Get product display names
  const getProductDisplayName = (productType: string) => {
    const names = {
      blocks: 'Blocks',
      cubes: 'Cubes', 
      pavers: 'Pavers',
      kerbs: 'Kerbs',
      flagstones: 'Flagstones'
    };
    return names[productType] || productType;
  };

  const getShortProductName = (productType: string) => {
    const names = {
      blocks: 'Blocks',
      cubes: 'Cubes',
      pavers: 'Pavers', 
      kerbs: 'Kerbs',
      flagstones: 'Flagstones'
    };
    return names[productType] || productType;
  };

  // Get product icons
  const getProductIcon = (productType: string) => {
    const icons = {
      blocks: Grid3X3,
      cubes: Box,
      pavers: Layers,
      kerbs: Minus,
      flagstones: Hexagon
    };
    return icons[productType] || TestTube;
  };

  return (
    <div className="space-y-6">
      {/* Connection Status Banner */}
      <Card className={`border-l-4 ${isConnected ? 'border-l-green-500' : 'border-l-amber-500'}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {isConnected ? (
                <Wifi className="h-5 w-5 text-green-500" />
              ) : (
                <WifiOff className="h-5 w-5 text-amber-500" />
              )}
              <div>
                <p className="font-medium">
                  {isConnected ? 'Tablet App Connected' : 'No Tablet Connection'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {isConnected 
                    ? `${connectionHealth.connectedDevices} device(s) connected • Last sync: ${lastSyncTime?.toLocaleTimeString() || 'Never'}`
                    : 'Manual entry mode • Tablet apps offline'
                  }
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {connectedDevices.map(device => (
                <Badge 
                  key={device.id}
                  variant={device.isConnected ? "default" : "secondary"}
                  className="flex items-center"
                >
                  <Smartphone className="h-3 w-3 mr-1" />
                  {device.deviceName.split(' ')[0]}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Tests</p>
                <p className="text-2xl font-bold">{stats.totalTests}</p>
              </div>
              <TestTube className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Passed</p>
                <p className="text-2xl font-bold text-green-600">{stats.passedTests}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Failed</p>
                <p className="text-2xl font-bold text-red-600">{stats.failedTests}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Strength</p>
                <p className="text-2xl font-bold">{stats.avgStrength.toFixed(1)} MPa</p>
              </div>
              <Badge variant="outline" className="text-xs">MPa</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Concrete Products Interface */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-lg">
              <TestTube className="h-4 w-4 mr-2" />
              {getProductDisplayName(selectedProductType)} ({directInputResults.length})
            </CardTitle>
            <div className="flex space-x-2">
              <Button 
                onClick={() => setShowEntryForm(true)}
                className="bg-primary hover:bg-primary/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add {getShortProductName(selectedProductType)} Test
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={loadDirectInputResults}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleExportCSV}
              >
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Product Type Selection */}
          <div className="mb-4">
            <ToggleGroup 
              type="single" 
              value={selectedProductType} 
              onValueChange={(value) => value && setSelectedProductType(value)}
              className="justify-start"
            >
              <ToggleGroupItem value="blocks" aria-label="Blocks" className="px-3 py-2 flex items-center gap-2">
                <Grid3X3 className="h-4 w-4" />
                Blocks
              </ToggleGroupItem>
              <ToggleGroupItem value="cubes" aria-label="Cubes" className="px-3 py-2 flex items-center gap-2">
                <Box className="h-4 w-4" />
                Cubes
              </ToggleGroupItem>
              <ToggleGroupItem value="pavers" aria-label="Pavers" className="px-3 py-2 flex items-center gap-2">
                <Layers className="h-4 w-4" />
                Pavers
              </ToggleGroupItem>
              <ToggleGroupItem value="kerbs" aria-label="Kerbs" className="px-3 py-2 flex items-center gap-2">
                <Minus className="h-4 w-4" />
                Kerbs
              </ToggleGroupItem>
              <ToggleGroupItem value="flagstones" aria-label="Flagstones" className="px-3 py-2 flex items-center gap-2">
                <Hexagon className="h-4 w-4" />
                Flagstones
              </ToggleGroupItem>
            </ToggleGroup>
          </div>

          {/* Search Filter */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by memo reference..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {/* Results Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Memo</TableHead>
                  <TableHead>Production Date</TableHead>
                  <TableHead>Test Date</TableHead>
                  <TableHead>Age (days)</TableHead>
                  <TableHead>Operator</TableHead>
                  <TableHead>Machine</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Load (kN)</TableHead>
                  <TableHead>Weight (kg)</TableHead>
                  <TableHead>Strength (MPa)</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Source</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {directInputResults.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="text-center py-8">
                      <TestTube className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-muted-foreground">No {getShortProductName(selectedProductType).toLowerCase()} test results found</p>
                      <Button 
                        variant="outline" 
                        className="mt-2"
                        onClick={() => setShowEntryForm(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add First {getShortProductName(selectedProductType)} Test
                      </Button>
                    </TableCell>
                  </TableRow>
                ) : (
                  directInputResults.map((result) => (
                    <TableRow key={result.id}>
                      <TableCell className="font-medium">{result.memo_reference}</TableCell>
                      <TableCell>{result.production_date}</TableCell>
                      <TableCell>{result.test_date}</TableCell>
                      <TableCell>{result.age_days}</TableCell>
                      <TableCell>{result.operator_name}</TableCell>
                      <TableCell>{result.machine_no}</TableCell>
                      <TableCell>{result.product}</TableCell>
                      <TableCell>{result.load_kn}</TableCell>
                      <TableCell>{result.weight_kg}</TableCell>
                      <TableCell className="font-medium">{result.strength_mpa}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(result.status) as any} className="flex items-center w-fit">
                          {getStatusIcon(result.status)}
                          <span className="ml-1">{result.status}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={result.data_source === 'tablet_app' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {result.data_source === 'tablet_app' ? 'Tablet' : 'Manual'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Per-Memo Summary */}
      {memoGroups.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Per-Memo Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {memoGroups.map((group) => (
                <div key={group.memo_reference} className="border rounded p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <span className="font-medium">{group.memo_reference}</span>
                      <Badge variant="outline">{group.product_type}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {group.total_tests} tests • {group.passed_tests} passed • {group.failed_tests} failed
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="default">{group.avg_strength.toFixed(1)} MPa avg</Badge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(group.last_test_date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Operator Test Entry Form Modal */}
      <OperatorTestEntryForm
        isOpen={showEntryForm}
        onOpenChange={setShowEntryForm}
        onSuccess={handleTestEntrySuccess}
        defaultProductType={selectedProductType}
      />
    </div>
  );
}