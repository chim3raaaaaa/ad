import { 
  LayoutDashboard, 
  Bell, 
  Package, 
  FileText, 
  Grid3x3,
  AlertTriangle,
  FileBarChart,
  BarChart3,
  Users,
  Zap,
  TrendingUp,
  Settings,
  LogOut,
  Code,
  Database,
  Palette,
  Upload,
  Calendar,
  Folder,
  FlaskConical
} from "lucide-react";
import { NavLink } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useUser } from "@/contexts/UserContext";
import { Button } from "@/components/ui/button";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";

const sidebarItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Calendar, label: "Test Calendar", path: "/test-calendar" },
  { icon: Bell, label: "Notifications", path: "/notifications" },
  { icon: Package, label: "Memo Management", path: "/memos" },
  { icon: FileText, label: "Test Result Manager", path: "/test-result-manager" },
  { icon: BarChart3, label: "Generate Reports", path: "/reports" },
  { icon: Grid3x3, label: "Test Modules", path: "/test-modules" },
  { icon: Database, label: "Advanced Data Hub", path: "/advanced-data" },
  { icon: Folder, label: "Reference Data Manager", path: "/reference-data-manager" },
  { icon: FlaskConical, label: "Mix Design Manager", path: "/mix-design-manager" },
  
  { icon: Users, label: "User & Roles", path: "/users" },
  { icon: Zap, label: "SMTP Integrations", path: "/integrations" },
  { icon: TrendingUp, label: "Analytics", path: "/analytics" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

const developerItems = [
  { icon: Code, label: "Developer Mode", path: "/developer" },
];

export function LabSidebar() {
  const { user, signOut } = useUser();
  
  return (
    <aside className="sidebar-container w-64 h-screen flex flex-col overflow-hidden" style={{ backgroundColor: '#2c3e50' }}>
      {/* Header Section */}
      <div className="sidebar-header p-6 border-b border-white/20">
        <div className="space-y-2">
          <h1 className="text-lg font-semibold text-white tracking-tight">
            UBP Mauritius Lab App
          </h1>
          {user && (
            <p className="text-sm text-white/70 font-medium">
              Welcome, {user.fullName}
            </p>
          )}
        </div>
      </div>
      
      {/* Navigation Section */}
      <nav className="sidebar-nav flex-1 overflow-y-auto overflow-x-hidden py-4 px-3 space-y-6" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
        {/* Main Navigation */}
        <div className="nav-group">
          <ul className="space-y-1">
            {sidebarItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      "nav-item group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out",
                      "hover:bg-white/10 hover:text-white",
                      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2",
                      isActive
                        ? "bg-blue-500 text-white shadow-sm"
                        : "text-white/80"
                    )
                  }
                >
                  <item.icon className="h-4 w-4 transition-transform duration-200 group-hover:scale-110" />
                  <span className="truncate">{item.label}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </div>

        {/* Developer Tools Section */}
        <PermissionWrapper permission="system.developer_mode">
          <div className="nav-group border-t border-white/20 pt-4">
            <div className="px-3 mb-3">
              <h3 className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                Developer Tools
              </h3>
            </div>
            <ul className="space-y-1">
              {developerItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      cn(
                        "nav-item group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out",
                        "hover:bg-white/10 hover:text-white",
                        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2",
                        isActive
                          ? "bg-blue-500 text-white shadow-sm"
                          : "text-white/80"
                      )
                    }
                  >
                    <item.icon className="h-4 w-4 transition-transform duration-200 group-hover:scale-110" />
                    <span className="truncate">{item.label}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        </PermissionWrapper>
      </nav>
    </aside>
  );
}