import { useState } from "react";
import type { UserRole as UserRoleData } from '@/services/api/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Settings, Users, Database, FileText, Mail } from "lucide-react";

interface RoleEditModalProps {
  role: UserRoleData;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedRole: UserRoleData) => void;
  currentUserRole: string;
}

const availablePermissions = [
  { id: "user_management", label: "User Management", icon: Users, category: "Administration" },
  { id: "system_config", label: "System Configuration", icon: Settings, category: "Administration" },
  { id: "full_access", label: "Full Access", icon: Shield, category: "Administration" },
  { id: "test_management", label: "Test Management", icon: Database, category: "Testing" },
  { id: "test_execution", label: "Test Execution", icon: Database, category: "Testing" },
  { id: "data_entry", label: "Data Entry", icon: FileText, category: "Testing" },
  { id: "report_generation", label: "Report Generation", icon: FileText, category: "Reports" },
  { id: "report_viewing", label: "Report Viewing", icon: FileText, category: "Reports" },
  { id: "email_notifications", label: "Email Notifications", icon: Mail, category: "Communication" },
];

export function RoleEditModal({ role, isOpen, onClose, onSave, currentUserRole }: RoleEditModalProps) {
  const [formData, setFormData] = useState({
    name: role?.name || "",
    permissions: role?.permissions || [],
    description: role?.description || ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const updatedRole = {
        ...role,
        ...formData,
        lastModified: new Date().toISOString()
      };

      onSave(updatedRole);
      onClose();
    } catch (error) {
      console.error('Failed to update role:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canEditRole = (roleName: string) => {
    if (currentUserRole === "admin") return true;
    if (currentUserRole === "lab_manager" && roleName !== "Admin") return true;
    return false;
  };

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      permissions: checked
        ? [...prev.permissions, permissionId]
        : prev.permissions.filter((p: string) => p !== permissionId)
    }));
  };

  const groupedPermissions = availablePermissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, typeof availablePermissions>);

  const isReadOnly = !canEditRole(role?.name);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Edit Role: {role?.name}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Role Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Role Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter role name"
                  disabled={isReadOnly}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Enter role description"
                  disabled={isReadOnly}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Permissions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(groupedPermissions).map(([category, permissions]) => (
                  <div key={category} className="space-y-3">
                    <h4 className="font-medium text-sm text-muted-foreground border-b pb-2">
                      {category}
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {permissions.map((permission) => (
                        <div key={permission.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={permission.id}
                            checked={formData.permissions.includes(permission.id)}
                            onCheckedChange={(checked) => 
                              handlePermissionChange(permission.id, checked as boolean)
                            }
                            disabled={isReadOnly}
                          />
                          <Label 
                            htmlFor={permission.id} 
                            className="flex items-center gap-2 cursor-pointer"
                          >
                            <permission.icon className="h-4 w-4" />
                            {permission.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {isReadOnly && (
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                You don't have permission to edit this role. Only administrators can modify all roles.
              </p>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || isReadOnly}>
              {isSubmitting ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}