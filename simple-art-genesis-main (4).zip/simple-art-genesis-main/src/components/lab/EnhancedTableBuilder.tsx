import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  Table2, 
  Eye, 
  Edit, 
  Trash2, 
  Plus, 
  Search,
  Database,
  Info,
  Filter
} from 'lucide-react';

interface TableInfo {
  name: string;
  type: string;
  module: string;
  recordCount: number;
  lastModified: string;
  columns: Array<{
    name: string;
    type: string;
    nullable: boolean;
    default_value?: string;
  }>;
}

export function EnhancedTableBuilder() {
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [filteredTables, setFilteredTables] = useState<TableInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedModule, setSelectedModule] = useState('all');
  const [selectedTable, setSelectedTable] = useState<TableInfo | null>(null);
  const [showColumnInspector, setShowColumnInspector] = useState(false);
  const { toast } = useToast();

  const loadTables = async () => {
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        // Get all user tables (excluding system tables)
        const tableNames = await window.electronAPI.dbQuery(`
          SELECT name, type FROM sqlite_master 
          WHERE type='table' 
          AND name NOT LIKE 'sqlite_%' 
          AND name NOT LIKE 'version_%'
          AND name NOT LIKE 'audit_%'
          ORDER BY name
        `);

        const tableInfoPromises = tableNames.map(async (table: any) => {
          try {
            // Get column information
            const columns = await window.electronAPI.dbQuery(`PRAGMA table_info(${table.name})`);
            
            // Get record count
            const countResult = await window.electronAPI.dbQuery(`SELECT COUNT(*) as count FROM ${table.name}`);
            const recordCount = countResult[0]?.count || 0;

            // Determine module based on table name patterns
            let module = 'Unknown';
            if (table.name.includes('aggregate')) module = 'Aggregates';
            else if (table.name.includes('block')) module = 'Blocks';
            else if (table.name.includes('paver')) module = 'Pavers';
            else if (table.name.includes('kerb')) module = 'Kerbs';
            else if (table.name.includes('flagstone')) module = 'Flagstones';
            else if (table.name.includes('memo')) module = 'Memos';
            else if (table.name.includes('validation')) module = 'Validation';
            else if (table.name.includes('reference')) module = 'Reference Data';
            else if (table.name.includes('user')) module = 'Users';
            else module = 'General';

            return {
              name: table.name,
              type: table.type,
              module,
              recordCount,
              lastModified: new Date().toISOString(), // Would need to track this in metadata
              columns: columns.map((col: any) => ({
                name: col.name,
                type: col.type,
                nullable: col.notnull === 0,
                default_value: col.dflt_value
              }))
            };
          } catch (error) {
            console.error(`Error loading info for table ${table.name}:`, error);
            return {
              name: table.name,
              type: table.type,
              module: 'Unknown',
              recordCount: 0,
              lastModified: new Date().toISOString(),
              columns: []
            };
          }
        });

        const tableInfos = await Promise.all(tableInfoPromises);
        setTables(tableInfos);
        setFilteredTables(tableInfos);
      }
    } catch (error) {
      console.error('Error loading tables:', error);
      toast({
        title: "Error",
        description: "Failed to load table information",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterTables = () => {
    let filtered = tables;
    
    if (searchTerm) {
      filtered = filtered.filter(table => 
        table.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        table.module.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedModule !== 'all') {
      filtered = filtered.filter(table => table.module === selectedModule);
    }
    
    setFilteredTables(filtered);
  };

  const handleDeleteTable = async (tableName: string) => {
    if (!confirm(`Are you sure you want to delete table "${tableName}"? This action cannot be undone.`)) {
      return;
    }

    try {
      if (window.electronAPI) {
        await window.electronAPI.dbRun(`DROP TABLE IF EXISTS ${tableName}`);
        
        // Also remove from table metadata if exists
        await window.electronAPI.dbRun(
          `DELETE FROM table_metadata WHERE name = ?`, 
          [tableName]
        );

        toast({
          title: "Success",
          description: `Table "${tableName}" has been deleted`,
        });
        
        await loadTables();
      }
    } catch (error) {
      console.error('Error deleting table:', error);
      toast({
        title: "Error",
        description: `Failed to delete table: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const getModuleBadgeVariant = (module: string) => {
    const variants: Record<string, any> = {
      'Aggregates': 'default',
      'Blocks': 'secondary',
      'Pavers': 'default',
      'Kerbs': 'secondary',
      'Flagstones': 'default',
      'Memos': 'secondary',
      'Validation': 'destructive',
      'Reference Data': 'default',
      'Users': 'secondary',
      'General': 'outline'
    };
    return variants[module] || 'outline';
  };

  const getUniqueModules = () => {
    const modules = [...new Set(tables.map(table => table.module))];
    return modules.sort();
  };

  useEffect(() => {
    loadTables();
  }, []);

  useEffect(() => {
    filterTables();
  }, [searchTerm, selectedModule, tables]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Table2 className="w-5 h-5" />
            Database Tables
          </h3>
          <p className="text-sm text-muted-foreground">
            Manage and inspect your database tables
          </p>
        </div>
        <Button onClick={loadTables} variant="outline">
          <Database className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4 items-center">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search tables..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <select
                value={selectedModule}
                onChange={(e) => setSelectedModule(e.target.value)}
                className="px-3 py-2 border rounded-md bg-background"
              >
                <option value="all">All Modules</option>
                {getUniqueModules().map(module => (
                  <option key={module} value={module}>{module}</option>
                ))}
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tables List */}
      <Card>
        <CardHeader>
          <CardTitle>Tables ({filteredTables.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading tables...</div>
          ) : filteredTables.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No tables found matching your criteria
            </div>
          ) : (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Table Name</TableHead>
                    <TableHead>Used In</TableHead>
                    <TableHead>Records</TableHead>
                    <TableHead>Columns</TableHead>
                    <TableHead>Last Modified</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTables.map((table) => (
                    <TableRow key={table.name}>
                      <TableCell className="font-mono font-medium">
                        {table.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getModuleBadgeVariant(table.module)}>
                          {table.module}
                        </Badge>
                      </TableCell>
                      <TableCell>{table.recordCount.toLocaleString()}</TableCell>
                      <TableCell>{table.columns.length}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(table.lastModified).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Dialog open={showColumnInspector && selectedTable?.name === table.name} onOpenChange={setShowColumnInspector}>
                            <DialogTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => setSelectedTable(table)}
                              >
                                <Info className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl">
                              <DialogHeader>
                                <DialogTitle>Table Schema: {table.name}</DialogTitle>
                              </DialogHeader>
                              <div className="mt-4">
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Column Name</TableHead>
                                      <TableHead>Data Type</TableHead>
                                      <TableHead>Nullable</TableHead>
                                      <TableHead>Default Value</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {table.columns.map((column, index) => (
                                      <TableRow key={index}>
                                        <TableCell className="font-mono">{column.name}</TableCell>
                                        <TableCell>
                                          <Badge variant="outline">{column.type}</Badge>
                                        </TableCell>
                                        <TableCell>
                                          <Badge variant={column.nullable ? "secondary" : "default"}>
                                            {column.nullable ? "Yes" : "No"}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="font-mono text-sm">
                                          {column.default_value || "-"}
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDeleteTable(table.name)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}