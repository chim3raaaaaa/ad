import React, { useState, useCallback, useEffect } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, Info, Loader2, RefreshCw, Download } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { enhancedCSVService, CSVUploadResult } from '@/services/api/enhancedCSVService';

interface UploadStatus {
  fileName: string;
  status: 'uploading' | 'success' | 'error';
  message: string;
  rowsInserted?: number;
  timestamp: string;
}

export const EnhancedReferenceUpload: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadHistory, setUploadHistory] = useState<UploadStatus[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [supportedFiles, setSupportedFiles] = useState<any[]>([]);
  const { toast } = useToast();

  // Load supported files information
  useEffect(() => {
    const files = enhancedCSVService.getSupportedFiles();
    setSupportedFiles(files);
  }, []);

  const handleFileSelect = useCallback((file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: 'Invalid File Type',
        description: 'Please select a CSV file.',
        variant: 'destructive'
      });
      return;
    }

    const supportedFileNames = supportedFiles.map(f => f.filename.toLowerCase());
    if (!supportedFileNames.includes(file.name.toLowerCase())) {
      toast({
        title: 'Unsupported File',
        description: `File "${file.name}" is not supported. Please select one of the supported reference files.`,
        variant: 'destructive'
      });
      return;
    }

    setSelectedFile(file);
  }, [toast, supportedFiles]);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  }, [handleFileSelect]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files?.[0]) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const processUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    const fileName = selectedFile.name;

    try {
      const result: CSVUploadResult = await enhancedCSVService.uploadCSV(selectedFile);

      const newStatus: UploadStatus = {
        fileName,
        status: result.success ? 'success' : 'error',
        message: result.success 
          ? `Successfully imported ${result.rowsImported} rows${result.errors.length > 0 ? ` (${result.errors.length} warnings)` : ''}`
          : result.errors.join(', '),
        rowsInserted: result.rowsImported,
        timestamp: result.timestamp
      };
      
      setUploadHistory(prev => [newStatus, ...prev.slice(0, 9)]);
      
      if (result.success) {
        setSelectedFile(null);
        
        toast({
          title: 'Upload Successful',
          description: `${fileName} - ${result.rowsImported} rows imported`,
        });
      } else {
        toast({
          title: 'Upload Failed',
          description: result.errors.join(', '),
          variant: 'destructive'
        });
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      
      const newStatus: UploadStatus = {
        fileName,
        status: 'error',
        message: errorMessage,
        timestamp: new Date().toISOString()
      };
      
      setUploadHistory(prev => [newStatus, ...prev.slice(0, 9)]);

      toast({
        title: 'Upload Failed',
        description: errorMessage,
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleGenerateTemplate = async (filename: string) => {
    try {
      await enhancedCSVService.generateTemplate(filename);
      toast({
        title: 'Template Downloaded',
        description: `${filename} template has been downloaded`,
      });
    } catch (error) {
      toast({
        title: 'Download Failed',
        description: `Failed to generate template: ${error}`,
        variant: 'destructive'
      });
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Upload Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload Reference Data
            </CardTitle>
            <CardDescription>
              Upload CSV files to populate reference datasets for laboratory operations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Drag & Drop Area */}
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive 
                  ? 'border-primary bg-primary/5' 
                  : 'border-muted-foreground/25 hover:border-muted-foreground/50'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <div className="space-y-2">
                <p className="text-lg font-medium">
                  {dragActive ? 'Drop your CSV file here' : 'Drag & drop or select a CSV file'}
                </p>
                <p className="text-muted-foreground text-sm">
                  Supported: {supportedFiles.length} reference data types
                </p>
              </div>
              <Input
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="mt-4 max-w-sm mx-auto"
              />
            </div>

            {/* Selected File */}
            {selectedFile && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <div className="flex items-center justify-between">
                    <span>Selected: <strong>{selectedFile.name}</strong></span>
                    <Button 
                      onClick={processUpload}
                      disabled={isUploading}
                      size="sm"
                    >
                      {isUploading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Uploading...
                        </>
                      ) : (
                        'Upload Data'
                      )}
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh Data
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => {
                // Switch to tools tab for validation
                const toolsTab = document.querySelector('[data-value="tools"]') as HTMLElement;
                if (toolsTab) toolsTab.click();
              }}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Validate All Data
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Supported Files with Template Download */}
      <Card>
        <CardHeader>
          <CardTitle>Supported Reference Files</CardTitle>
          <CardDescription>
            CSV files that can be uploaded with template download options
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {supportedFiles.map((config) => (
              <div key={config.filename} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <p className="font-medium text-sm">{config.filename}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleGenerateTemplate(config.filename)}
                    className="h-6 w-6 p-0"
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                </div>
                
                <p className="text-muted-foreground text-xs mb-3">{config.description}</p>
                
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-1">
                    {config.requiredFields.slice(0, 3).map((field: string) => (
                      <Badge key={field} variant="outline" className="text-xs">
                        {field}
                      </Badge>
                    ))}
                    {config.requiredFields.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{config.requiredFields.length - 3} more
                      </Badge>
                    )}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => handleGenerateTemplate(config.filename)}
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Template
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upload History */}
      {uploadHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Uploads</CardTitle>
            <CardDescription>
              History of recent upload attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {uploadHistory.map((upload, index) => (
                <div 
                  key={`${upload.fileName}-${index}`}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    {upload.status === 'success' ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : upload.status === 'uploading' ? (
                      <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    )}
                    <div>
                      <p className="font-medium text-sm">{upload.fileName}</p>
                      <p className="text-muted-foreground text-xs">{upload.message}</p>
                      <p className="text-muted-foreground text-xs">
                        {formatTimestamp(upload.timestamp)}
                      </p>
                    </div>
                  </div>
                  {upload.rowsInserted && (
                    <Badge variant="outline">
                      {upload.rowsInserted} rows
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};