import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Plus, 
  AlertCircle, 
  CheckCircle, 
  Settings,
  Play,
  Repeat,
  Bell,
  Users,
  Filter
} from 'lucide-react';
import { dataService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import type { TestSchedule, ScheduleTemplate } from '@/services/api/types';
import { cn } from '@/lib/utils';

const testTypes = [
  { value: 'cube_compression', label: 'Cube Compression Test', defaultAges: [7, 28] },
  { value: 'slump_test', label: 'Slump Test', defaultAges: [0] },
  { value: 'density_test', label: 'Density Test', defaultAges: [0, 7] },
  { value: 'air_content', label: 'Air Content Test', defaultAges: [0] },
  { value: 'flexural_strength', label: 'Flexural Strength', defaultAges: [7, 28] }
];

const priorityColors = {
  low: 'secondary',
  normal: 'outline',
  high: 'default',
  urgent: 'destructive'
};

const statusColors = {
  scheduled: 'outline',
  pending: 'secondary',
  completed: 'default',
  overdue: 'destructive'
};

export default function SmartDateCalculator() {
  const [schedules, setSchedules] = useState<TestSchedule[]>([]);
  const [templates, setTemplates] = useState<ScheduleTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const { toast } = useToast();

  // Initialize with mock data for testing
  useEffect(() => {
    const mockSchedules: TestSchedule[] = [
      {
        id: 'sched_001',
        test_type: 'Compressive Strength',
        sample_id: 'sample_001',
        scheduled_date: '2024-02-08T09:00:00Z',
        due_date: '2024-02-08T17:00:00Z',
        age_days: 7,
        priority: 'normal',
        status: 'completed',
        auto_generated: true,
        notification_sent: true,
        assigned_to: 'tech_001',
        created_at: '2024-02-01T10:00:00Z',
        updated_at: '2024-02-08T16:30:00Z'
      },
      {
        id: 'sched_002',
        test_type: 'Compressive Strength',
        sample_id: 'sample_001',
        scheduled_date: '2024-02-29T09:00:00Z',
        due_date: '2024-02-29T17:00:00Z',
        age_days: 28,
        priority: 'high',
        status: 'scheduled',
        auto_generated: true,
        notification_sent: false,
        assigned_to: 'tech_002',
        created_at: '2024-02-01T10:00:00Z',
        updated_at: '2024-02-01T10:00:00Z'
      },
      {
        id: 'sched_003',
        test_type: 'Flexural Strength',
        sample_id: 'sample_002',
        scheduled_date: '2024-02-15T14:00:00Z',
        due_date: '2024-02-15T18:00:00Z',
        age_days: 14,
        priority: 'normal',
        status: 'pending',
        auto_generated: false,
        notification_sent: true,
        assigned_to: 'tech_001',
        created_at: '2024-02-01T11:00:00Z',
        updated_at: '2024-02-01T11:00:00Z'
      }
    ];

    const mockTemplates: ScheduleTemplate[] = [
      {
        id: 'template_001',
        name: 'Standard Concrete Tests',
        test_type: 'Compressive Strength',
        schedule_pattern: {
          intervals: [7, 28],
          unit: 'days',
          working_days_only: true,
          exclude_holidays: true
        },
        auto_create: true,
        active: true,
        created_at: '2024-01-10T10:00:00Z',
        updated_at: '2024-01-10T10:00:00Z'
      },
      {
        id: 'template_002',
        name: 'Extended Testing Schedule',
        test_type: 'Compressive Strength',
        schedule_pattern: {
          intervals: [3, 7, 14, 28, 56],
          unit: 'days',
          working_days_only: true,
          exclude_holidays: true
        },
        auto_create: false,
        active: true,
        created_at: '2024-01-12T14:00:00Z',
        updated_at: '2024-01-12T14:00:00Z'
      }
    ];

    setSchedules(mockSchedules);
    setTemplates(mockTemplates);
    setLoading(false);
  }, []);

  const loadSchedules = async () => {
    try {
      const response = await dataService.getTestSchedules({ limit: 100 });
      setSchedules(response.data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load test schedules',
        variant: 'destructive'
      });
    }
  };

  const loadTemplates = async () => {
    try {
      const response = await dataService.getScheduleTemplates();
      setTemplates(response.data);
    } catch (error) {
      console.error('Failed to load schedule templates:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateTestDate = (sampleDate: Date, ageDays: number): Date => {
    const testDate = new Date(sampleDate);
    testDate.setDate(testDate.getDate() + ageDays);
    
    // Skip weekends if working days only
    while (testDate.getDay() === 0 || testDate.getDay() === 6) {
      testDate.setDate(testDate.getDate() + 1);
    }
    
    return testDate;
  };

  const generateSchedule = async (templateId: string, sampleIds: string[]) => {
    try {
      const response = await dataService.generateSchedulesFromTemplate(templateId, sampleIds);
      
      toast({
        title: 'Success',
        description: `Generated ${response.data.length} test schedules`
      });
      
      loadSchedules();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate schedules',
        variant: 'destructive'
      });
    }
  };

  const filteredSchedules = schedules.filter(schedule => 
    filterStatus === 'all' || schedule.status === filterStatus
  );

  const upcomingSchedules = schedules.filter(schedule => {
    const dueDate = new Date(schedule.due_date);
    const today = new Date();
    const daysDiff = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff <= 7 && daysDiff >= 0 && schedule.status !== 'completed';
  });

  const overdueSchedules = schedules.filter(schedule => {
    const dueDate = new Date(schedule.due_date);
    return dueDate < new Date() && schedule.status !== 'completed';
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Smart Date Calculator</h2>
          <p className="text-muted-foreground">
            Automated test scheduling with calendar integration and notifications
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowTemplateDialog(true)}>
            <Settings className="w-4 h-4 mr-2" />
            Templates
          </Button>
          <Button onClick={() => setShowScheduleDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Schedule
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Upcoming</p>
                <p className="text-xl font-bold">{upcomingSchedules.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <div>
                <p className="text-sm text-muted-foreground">Overdue</p>
                <p className="text-xl font-bold">{overdueSchedules.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-xl font-bold">
                  {schedules.filter(s => s.status === 'completed').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Repeat className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Templates</p>
                <p className="text-xl font-bold">{templates.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="schedules" className="space-y-4">
        <TabsList>
          <TabsTrigger value="schedules">
            <CalendarIcon className="w-4 h-4 mr-2" />
            Schedules ({filteredSchedules.length})
          </TabsTrigger>
          <TabsTrigger value="calendar">
            <CalendarIcon className="w-4 h-4 mr-2" />
            Calendar View
          </TabsTrigger>
          <TabsTrigger value="calculator">
            <Clock className="w-4 h-4 mr-2" />
            Date Calculator
          </TabsTrigger>
        </TabsList>

        <TabsContent value="schedules" className="space-y-4">
          {/* Filters */}
          <div className="flex gap-4 items-center">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <Label>Status:</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Schedules List */}
          <div className="space-y-4">
            {filteredSchedules.map((schedule) => (
              <Card key={schedule.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{schedule.test_type}</h3>
                        <Badge variant={statusColors[schedule.status] as any}>
                          {schedule.status}
                        </Badge>
                        <Badge variant={priorityColors[schedule.priority] as any}>
                          {schedule.priority}
                        </Badge>
                        {schedule.auto_generated && (
                          <Badge variant="outline">Auto</Badge>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Sample ID</p>
                          <p className="font-medium">{schedule.sample_id}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Age (days)</p>
                          <p className="font-medium">{schedule.age_days}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Due Date</p>
                          <p className="font-medium">
                            {new Date(schedule.due_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Assigned To</p>
                          <p className="font-medium">{schedule.assigned_to || 'Unassigned'}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {schedule.notification_sent && (
                        <Bell className="w-4 h-4 text-blue-500" />
                      )}
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Schedule Calendar</CardTitle>
              <p className="text-sm text-muted-foreground">
                Click on dates to view scheduled tests
              </p>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                modifiers={{
                  hasSchedule: schedules.map(s => new Date(s.due_date)),
                  overdue: overdueSchedules.map(s => new Date(s.due_date))
                }}
                modifiersStyles={{
                  hasSchedule: { backgroundColor: 'hsl(var(--primary))', color: 'white' },
                  overdue: { backgroundColor: 'hsl(var(--destructive))', color: 'white' }
                }}
              />
              
              {selectedDate && (
                <div className="mt-4">
                  <h4 className="font-semibold mb-2">
                    Tests on {selectedDate.toLocaleDateString()}:
                  </h4>
                  {schedules
                    .filter(s => new Date(s.due_date).toDateString() === selectedDate.toDateString())
                    .map(schedule => (
                      <div key={schedule.id} className="p-2 border rounded mb-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{schedule.test_type}</span>
                          <Badge variant={statusColors[schedule.status] as any}>
                            {schedule.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Sample: {schedule.sample_id} | Age: {schedule.age_days} days
                        </p>
                      </div>
                    ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator" className="space-y-4">
          <DateCalculatorComponent />
        </TabsContent>
      </Tabs>

      {/* Template Dialog */}
      <TemplateDialog
        open={showTemplateDialog}
        onOpenChange={setShowTemplateDialog}
        templates={templates}
        onTemplatesChange={loadTemplates}
        onGenerateSchedule={generateSchedule}
      />

      {/* Schedule Dialog */}
      <ScheduleDialog
        open={showScheduleDialog}
        onOpenChange={setShowScheduleDialog}
        onScheduleCreated={loadSchedules}
      />
    </div>
  );
}

// Date Calculator Component
function DateCalculatorComponent() {
  const [sampleDate, setSampleDate] = useState<Date>(new Date());
  const [testType, setTestType] = useState('cube_compression');
  const [customAges, setCustomAges] = useState('7,28');
  const [workingDaysOnly, setWorkingDaysOnly] = useState(true);
  const [results, setResults] = useState<Array<{ age: number; date: Date }>>([]);

  const calculateDates = () => {
    const selectedTestType = testTypes.find(t => t.value === testType);
    const ages = customAges ? customAges.split(',').map(a => parseInt(a.trim())).filter(a => !isNaN(a)) : selectedTestType?.defaultAges || [];
    
    const calculatedResults = ages.map(age => {
      const testDate = new Date(sampleDate);
      testDate.setDate(testDate.getDate() + age);
      
      if (workingDaysOnly) {
        // Skip weekends
        while (testDate.getDay() === 0 || testDate.getDay() === 6) {
          testDate.setDate(testDate.getDate() + 1);
        }
      }
      
      return { age, date: testDate };
    });
    
    setResults(calculatedResults);
  };

  useEffect(() => {
    calculateDates();
  }, [sampleDate, testType, customAges, workingDaysOnly]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Test Date Calculator</CardTitle>
        <p className="text-sm text-muted-foreground">
          Calculate test dates based on sample date and aging requirements
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Sample Date</Label>
            <Calendar
              mode="single"
              selected={sampleDate}
              onSelect={(date) => date && setSampleDate(date)}
              className="rounded-md border w-fit"
            />
          </div>
          
          <div className="space-y-4">
            <div>
              <Label>Test Type</Label>
              <Select value={testType} onValueChange={setTestType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {testTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Test Ages (days, comma-separated)</Label>
              <Input
                value={customAges}
                onChange={(e) => setCustomAges(e.target.value)}
                placeholder="7,28"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="working-days"
                checked={workingDaysOnly}
                onCheckedChange={setWorkingDaysOnly}
              />
              <Label htmlFor="working-days">Working days only</Label>
            </div>
          </div>
        </div>
        
        {results.length > 0 && (
          <div>
            <h4 className="font-semibold mb-2">Calculated Test Dates:</h4>
            <div className="space-y-2">
              {results.map(result => (
                <div key={result.age} className="flex justify-between items-center p-2 border rounded">
                  <span>{result.age} days</span>
                  <span className="font-medium">{result.date.toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Template Dialog Component
function TemplateDialog({ 
  open, 
  onOpenChange, 
  templates, 
  onTemplatesChange, 
  onGenerateSchedule 
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  templates: ScheduleTemplate[];
  onTemplatesChange: () => void;
  onGenerateSchedule: (templateId: string, sampleIds: string[]) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Schedule Templates</DialogTitle>
          <DialogDescription>
            Manage templates for automated test scheduling
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {templates.map(template => (
            <Card key={template.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold">{template.name}</h3>
                    <p className="text-sm text-muted-foreground">{template.test_type}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Ages: {template.schedule_pattern.intervals.join(', ')} {template.schedule_pattern.unit}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={template.active ? 'default' : 'secondary'}>
                      {template.active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onGenerateSchedule(template.id, ['sample1', 'sample2'])}
                    >
                      <Play className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Schedule Dialog Component
function ScheduleDialog({ 
  open, 
  onOpenChange, 
  onScheduleCreated 
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onScheduleCreated: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Test Schedule</DialogTitle>
          <DialogDescription>
            Manually create a new test schedule
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Schedule creation form would go here...
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}