import React, { useState } from 'react';
import { History, User, Clock, FileText, Edit, Mail, CheckCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { ScrollArea } from '../ui/scroll-area';
import { Separator } from '../ui/separator';

interface HistoryEntry {
  id: string;
  timestamp: string;
  action: string;
  user: string;
  details: string;
  changes?: {
    field: string;
    oldValue: string;
    newValue: string;
  }[];
  type: 'create' | 'update' | 'approve' | 'email' | 'status' | 'comment';
}

interface RequestHistoryAuditProps {
  requestId: string;
  requestReference: string;
}

export function RequestHistoryAudit({ requestId, requestReference }: RequestHistoryAuditProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Sample history data
  const historyEntries: HistoryEntry[] = [
    {
      id: '1',
      timestamp: '2024-01-15T14:30:00Z',
      action: 'Request Created',
      user: 'System',
      details: 'Test request created from PDF import',
      type: 'create'
    },
    {
      id: '2',
      timestamp: '2024-01-15T14:35:00Z',
      action: 'PDF Data Extracted',
      user: 'System',
      details: 'Extracted site, officer, and test type information from PDF',
      type: 'update'
    },
    {
      id: '3',
      timestamp: '2024-01-15T15:00:00Z',
      action: 'Priority Updated',
      user: 'John Smith',
      details: 'Priority changed from Normal to High',
      changes: [
        { field: 'priority', oldValue: 'normal', newValue: 'high' }
      ],
      type: 'update'
    },
    {
      id: '4',
      timestamp: '2024-01-15T15:15:00Z',
      action: 'Comment Added',
      user: 'Mary Wong',
      details: 'Added comment: "Urgent project deadline requires expedited testing"',
      type: 'comment'
    },
    {
      id: '5',
      timestamp: '2024-01-15T16:00:00Z',
      action: 'Status Changed',
      user: 'Tech Team',
      details: 'Status changed from Pending to Processing',
      changes: [
        { field: 'status', oldValue: 'pending', newValue: 'processing' }
      ],
      type: 'status'
    },
    {
      id: '6',
      timestamp: '2024-01-15T16:30:00Z',
      action: 'Email Sent',
      user: 'System',
      details: 'Notification email sent to john.smith@contractor.mu',
      type: 'email'
    },
    {
      id: '7',
      timestamp: '2024-01-15T17:00:00Z',
      action: 'Test Started',
      user: 'Lab Technician',
      details: 'Concrete block compression test initiated',
      type: 'update'
    },
    {
      id: '8',
      timestamp: '2024-01-15T19:00:00Z',
      action: 'Test Completed',
      user: 'Lab Technician',
      details: 'All tests completed successfully',
      type: 'update'
    },
    {
      id: '9',
      timestamp: '2024-01-15T19:30:00Z',
      action: 'Results Reviewed',
      user: 'Supervisor',
      details: 'Test results reviewed and validated',
      type: 'update'
    },
    {
      id: '10',
      timestamp: '2024-01-15T20:00:00Z',
      action: 'Request Approved',
      user: 'Lab Manager',
      details: 'Test request approved and ready for report generation',
      type: 'approve'
    }
  ];

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'create': return <FileText className="h-4 w-4 text-blue-600" />;
      case 'update': return <Edit className="h-4 w-4 text-orange-600" />;
      case 'approve': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'email': return <Mail className="h-4 w-4 text-purple-600" />;
      case 'status': return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      case 'comment': return <User className="h-4 w-4 text-gray-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getActionColor = (type: string) => {
    switch (type) {
      case 'create': return 'bg-blue-100 text-blue-800';
      case 'update': return 'bg-orange-100 text-orange-800';
      case 'approve': return 'bg-green-100 text-green-800';
      case 'email': return 'bg-purple-100 text-purple-800';
      case 'status': return 'bg-yellow-100 text-yellow-800';
      case 'comment': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString()
    };
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <History className="h-4 w-4 mr-2" />
          History
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Request History & Audit Trail
          </DialogTitle>
          <DialogDescription>
            Complete history for {requestReference}
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[60vh] pr-4">
          <div className="space-y-4">
            {historyEntries.map((entry, index) => {
              const { date, time } = formatTimestamp(entry.timestamp);
              
              return (
                <div key={entry.id} className="relative">
                  {index < historyEntries.length - 1 && (
                    <div className="absolute left-6 top-12 w-0.5 h-8 bg-border" />
                  )}
                  
                  <div className="flex gap-3">
                    <div className="flex-shrink-0 w-12 h-12 bg-background border-2 border-border rounded-full flex items-center justify-center">
                      {getActionIcon(entry.type)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <Card className="shadow-sm">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{entry.action}</h4>
                                <Badge className={getActionColor(entry.type)}>
                                  {entry.type}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <User className="h-3 w-3" />
                                <span>{entry.user}</span>
                                <span>•</span>
                                <Clock className="h-3 w-3" />
                                <span>{date} at {time}</span>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <p className="text-sm text-muted-foreground">
                            {entry.details}
                          </p>
                          
                          {entry.changes && entry.changes.length > 0 && (
                            <div className="mt-3 p-3 bg-muted/50 rounded-md">
                              <h5 className="text-sm font-medium mb-2">Changes:</h5>
                              <div className="space-y-1">
                                {entry.changes.map((change, changeIndex) => (
                                  <div key={changeIndex} className="text-sm">
                                    <span className="font-medium capitalize">
                                      {change.field.replace('_', ' ')}:
                                    </span>
                                    <span className="text-red-600 line-through ml-2">
                                      {change.oldValue}
                                    </span>
                                    <span className="mx-2">→</span>
                                    <span className="text-green-600 font-medium">
                                      {change.newValue}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}