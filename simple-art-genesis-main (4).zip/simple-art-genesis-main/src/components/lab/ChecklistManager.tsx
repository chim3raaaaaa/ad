import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Save, X, Check } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { memoInboxService, type AcknowledgmentChecklist, type ChecklistItem } from "@/services/database/memoInboxService";
import { EmptyState } from "@/components/ui/empty-state";

export function ChecklistManager() {
  const { toast } = useToast();
  const [checklists, setChecklists] = useState<AcknowledgmentChecklist[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingChecklist, setEditingChecklist] = useState<AcknowledgmentChecklist | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    description: "",
    checklist_items: [] as ChecklistItem[],
    required_fields: [] as string[]
  });
  const [newItem, setNewItem] = useState({
    name: "",
    description: "",
    required: false,
    category: ""
  });
  const [loading, setLoading] = useState(true);

  const categories = [
    { value: "blocks", label: "Blocks" },
    { value: "cubes", label: "Cubes" },
    { value: "aggregates", label: "Aggregates" },
    { value: "pavers", label: "Pavers" },
    { value: "kerbs", label: "Kerbs" },
    { value: "flagstones", label: "Flagstones" }
  ];

  useEffect(() => {
    loadChecklists();
  }, []);

  const loadChecklists = async () => {
    try {
      setLoading(true);
      const data = await memoInboxService.getChecklists();
      setChecklists(data);
    } catch (error) {
      console.error('Error loading checklists:', error);
      toast({
        title: "Error",
        description: "Failed to load checklists",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "",
      description: "",
      checklist_items: [],
      required_fields: []
    });
    setNewItem({
      name: "",
      description: "",
      required: false,
      category: ""
    });
  };

  const handleCreateChecklist = () => {
    resetForm();
    setEditingChecklist(null);
    setShowCreateDialog(true);
  };

  const handleEditChecklist = (checklist: AcknowledgmentChecklist) => {
    setFormData({
      name: checklist.name,
      category: checklist.category,
      description: checklist.description,
      checklist_items: checklist.checklist_items,
      required_fields: checklist.required_fields
    });
    setEditingChecklist(checklist);
    setShowCreateDialog(true);
  };

  const handleAddItem = () => {
    if (!newItem.name) return;

    const item: ChecklistItem = {
      id: crypto.randomUUID(),
      name: newItem.name,
      description: newItem.description,
      required: newItem.required,
      category: newItem.category || formData.category
    };

    setFormData(prev => ({
      ...prev,
      checklist_items: [...prev.checklist_items, item]
    }));

    if (newItem.required) {
      setFormData(prev => ({
        ...prev,
        required_fields: [...prev.required_fields, item.id]
      }));
    }

    setNewItem({
      name: "",
      description: "",
      required: false,
      category: ""
    });
  };

  const handleRemoveItem = (itemId: string) => {
    setFormData(prev => ({
      ...prev,
      checklist_items: prev.checklist_items.filter(item => item.id !== itemId),
      required_fields: prev.required_fields.filter(id => id !== itemId)
    }));
  };

  const handleToggleRequired = (itemId: string, required: boolean) => {
    setFormData(prev => ({
      ...prev,
      checklist_items: prev.checklist_items.map(item =>
        item.id === itemId ? { ...item, required } : item
      ),
      required_fields: required
        ? [...prev.required_fields, itemId]
        : prev.required_fields.filter(id => id !== itemId)
    }));
  };

  const handleSaveChecklist = async () => {
    if (!formData.name || !formData.category || formData.checklist_items.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and add at least one checklist item",
        variant: "destructive"
      });
      return;
    }

    try {
      await memoInboxService.createChecklist(
        formData.name,
        formData.category,
        formData.description,
        formData.checklist_items,
        formData.required_fields,
        'current-user-id' // TODO: Get from auth context
      );

      toast({
        title: "Success",
        description: editingChecklist ? "Checklist updated successfully" : "Checklist created successfully"
      });

      setShowCreateDialog(false);
      resetForm();
      setEditingChecklist(null);
      loadChecklists();
    } catch (error) {
      console.error('Error saving checklist:', error);
      toast({
        title: "Error",
        description: "Failed to save checklist",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Acknowledgment Checklists</CardTitle>
          <CardDescription>Loading checklists...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Acknowledgment Checklists</CardTitle>
            <CardDescription>
              Manage checklists used for memo acknowledgment process
            </CardDescription>
          </div>
          <Button onClick={handleCreateChecklist}>
            <Plus className="h-4 w-4 mr-2" />
            Create Checklist
          </Button>
        </CardHeader>
        <CardContent>
          {checklists.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <Check className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No checklists configured</h3>
              <p className="text-muted-foreground mb-4">Create your first acknowledgment checklist to get started</p>
              <Button onClick={handleCreateChecklist}>
                <Plus className="h-4 w-4 mr-2" />
                Create Checklist
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Required Items</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {checklists.map((checklist) => (
                  <TableRow key={checklist.id}>
                    <TableCell className="font-medium">{checklist.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {checklist.category}
                      </Badge>
                    </TableCell>
                    <TableCell>{checklist.checklist_items.length}</TableCell>
                    <TableCell>
                      {checklist.checklist_items.filter(item => item.required).length}
                    </TableCell>
                    <TableCell>
                      <Badge variant={checklist.is_active ? "default" : "secondary"}>
                        {checklist.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditChecklist(checklist)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => {
                            toast({
                              title: "Feature Coming Soon",
                              description: "Delete functionality will be implemented in the next update",
                            });
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingChecklist ? "Edit Checklist" : "Create New Checklist"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Checklist Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter checklist name"
                />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter checklist description"
              />
            </div>

            {/* Checklist Items */}
            <div>
              <Label className="text-base font-medium">Checklist Items</Label>
              
              {/* Add New Item */}
              <Card className="mt-2">
                <CardHeader>
                  <CardTitle className="text-sm">Add New Item</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-2 items-end">
                    <div>
                      <Label htmlFor="item-name">Item Name</Label>
                      <Input
                        id="item-name"
                        value={newItem.name}
                        onChange={(e) => setNewItem(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter item name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="item-description">Description</Label>
                      <Input
                        id="item-description"
                        value={newItem.description}
                        onChange={(e) => setNewItem(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Enter description"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="item-required"
                        checked={newItem.required}
                        onCheckedChange={(checked) => setNewItem(prev => ({ ...prev, required: !!checked }))}
                      />
                      <Label htmlFor="item-required">Required</Label>
                    </div>
                    <Button onClick={handleAddItem} disabled={!newItem.name}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Existing Items */}
              {formData.checklist_items.length > 0 && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-sm">Checklist Items ({formData.checklist_items.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {formData.checklist_items.map((item) => (
                        <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Checkbox
                                checked={item.required}
                                onCheckedChange={(checked) => handleToggleRequired(item.id, !!checked)}
                              />
                              <span className="font-medium">{item.name}</span>
                              {item.required && (
                                <Badge variant="destructive" className="text-xs">Required</Badge>
                              )}
                            </div>
                            {item.description && (
                              <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowCreateDialog(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveChecklist}>
                <Save className="h-4 w-4 mr-2" />
                {editingChecklist ? "Update" : "Create"} Checklist
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
