import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Palette, 
  Eye, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Star,
  Hash,
  Calendar,
  Type,
  FileText,
  Image,
  MapPin,
  Clock,
  DollarSign,
  Percent,
  Mail,
  Phone,
  Link,
  User,
  Save,
  Trash2,
  Copy,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface FieldTemplate {
  id: string;
  name: string;
  description: string;
  type: string;
  icon: string;
  styling: FieldStyling;
  validationRules: ValidationRule[];
  category: 'basic' | 'advanced' | 'custom';
}

interface FieldStyling {
  backgroundColor: string;
  borderColor: string;
  textColor: string;
  iconColor: string;
  size: 'sm' | 'md' | 'lg';
  variant: 'default' | 'critical' | 'warning' | 'success' | 'info';
  showIcon: boolean;
  showValidationBadge: boolean;
  customCSS?: string;
}

interface ValidationRule {
  type: 'required' | 'pattern' | 'range' | 'custom';
  message: string;
  config: any;
}

interface StyledFieldProps {
  template: FieldTemplate;
  value: any;
  onChange: (value: any) => void;
  validationStatus?: 'valid' | 'invalid' | 'warning' | 'pending';
  validationMessage?: string;
}

const fieldIcons = {
  text: Type,
  number: Hash,
  email: Mail,
  phone: Phone,
  url: Link,
  date: Calendar,
  time: Clock,
  textarea: FileText,
  select: Settings,
  image: Image,
  location: MapPin,
  currency: DollarSign,
  percentage: Percent,
  user: User
};

const validationStatusColors = {
  valid: 'bg-green-100 text-green-700 border-green-300',
  invalid: 'bg-red-100 text-red-700 border-red-300',
  warning: 'bg-yellow-100 text-yellow-700 border-yellow-300',
  pending: 'bg-blue-100 text-blue-700 border-blue-300'
};

const validationStatusIcons = {
  valid: CheckCircle,
  invalid: XCircle,
  warning: AlertTriangle,
  pending: Clock
};

const StyledField: React.FC<StyledFieldProps> = ({ 
  template, 
  value, 
  onChange, 
  validationStatus = 'valid',
  validationMessage 
}) => {
  const IconComponent = fieldIcons[template.icon as keyof typeof fieldIcons] || Type;
  const ValidationIcon = validationStatusIcons[validationStatus];
  
  const getSizeClasses = () => {
    switch (template.styling.size) {
      case 'sm': return 'h-8 text-sm';
      case 'lg': return 'h-12 text-lg';
      default: return 'h-10';
    }
  };
  
  const getVariantClasses = () => {
    switch (template.styling.variant) {
      case 'critical': return 'border-red-300 bg-red-50 focus:border-red-500 focus:ring-red-500';
      case 'warning': return 'border-yellow-300 bg-yellow-50 focus:border-yellow-500 focus:ring-yellow-500';
      case 'success': return 'border-green-300 bg-green-50 focus:border-green-500 focus:ring-green-500';
      case 'info': return 'border-blue-300 bg-blue-50 focus:border-blue-500 focus:ring-blue-500';
      default: return 'border-input bg-background focus:border-primary focus:ring-primary';
    }
  };

  const renderField = () => {
    const commonClasses = cn(
      getSizeClasses(),
      getVariantClasses(),
      template.styling.showIcon && 'pl-10',
      template.styling.customCSS
    );

    switch (template.type) {
      case 'textarea':
        return (
          <Textarea
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className={cn(commonClasses, 'min-h-[80px]')}
            placeholder={`Enter ${template.name.toLowerCase()}...`}
          />
        );
      
      case 'select':
        return (
          <Select value={value || ''} onValueChange={onChange}>
            <SelectTrigger className={commonClasses}>
              <SelectValue placeholder={`Select ${template.name.toLowerCase()}...`} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="option1">Option 1</SelectItem>
              <SelectItem value="option2">Option 2</SelectItem>
              <SelectItem value="option3">Option 3</SelectItem>
            </SelectContent>
          </Select>
        );
      
      default:
        return (
          <Input
            type={template.type}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className={commonClasses}
            placeholder={`Enter ${template.name.toLowerCase()}...`}
          />
        );
    }
  };

  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{template.name}</Label>
      <div className="relative">
        {template.styling.showIcon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 z-10">
            <IconComponent 
              className="w-4 h-4" 
              style={{ color: template.styling.iconColor }}
            />
          </div>
        )}
        
        {renderField()}
        
        {template.styling.showValidationBadge && validationStatus !== 'valid' && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <ValidationIcon className="w-4 h-4" />
          </div>
        )}
      </div>
      
      {template.styling.showValidationBadge && validationMessage && (
        <div className={cn(
          'text-xs p-2 rounded border flex items-center gap-1',
          validationStatusColors[validationStatus]
        )}>
          <ValidationIcon className="w-3 h-3" />
          {validationMessage}
        </div>
      )}
      
      <p className="text-xs text-muted-foreground">{template.description}</p>
    </div>
  );
};

export default function CustomFieldStyling() {
  const [templates, setTemplates] = useState<FieldTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<FieldTemplate | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [previewValues, setPreviewValues] = useState<Record<string, any>>({});
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Initialize with comprehensive field templates
  useEffect(() => {
    const mockTemplates: FieldTemplate[] = [
      {
        id: 'critical-strength',
        name: 'Critical Strength Value',
        description: 'High-priority strength measurement field with validation',
        type: 'number',
        icon: 'number',
        category: 'advanced',
        styling: {
          backgroundColor: '#fef2f2',
          borderColor: '#fca5a5',
          textColor: '#dc2626',
          iconColor: '#dc2626',
          size: 'lg',
          variant: 'critical',
          showIcon: true,
          showValidationBadge: true,
          customCSS: 'font-bold'
        },
        validationRules: [
          { type: 'required', message: 'Strength value is required', config: {} },
          { type: 'range', message: 'Value must be between 10-100 MPa', config: { min: 10, max: 100 } }
        ]
      },
      {
        id: 'standard-text',
        name: 'Standard Text Input',
        description: 'Basic text input with clean styling',
        type: 'text',
        icon: 'text',
        category: 'basic',
        styling: {
          backgroundColor: '#ffffff',
          borderColor: '#d1d5db',
          textColor: '#374151',
          iconColor: '#6b7280',
          size: 'md',
          variant: 'default',
          showIcon: true,
          showValidationBadge: false
        },
        validationRules: [
          { type: 'required', message: 'This field is required', config: {} }
        ]
      },
      {
        id: 'success-indicator',
        name: 'Success Status Field',
        description: 'Field for displaying successful test results',
        type: 'text',
        icon: 'text',
        category: 'advanced',
        styling: {
          backgroundColor: '#f0fdf4',
          borderColor: '#86efac',
          textColor: '#166534',
          iconColor: '#16a34a',
          size: 'md',
          variant: 'success',
          showIcon: true,
          showValidationBadge: true
        },
        validationRules: []
      },
      {
        id: 'warning-alert',
        name: 'Warning Alert Field',
        description: 'Field for values that need attention',
        type: 'number',
        icon: 'number',
        category: 'advanced',
        styling: {
          backgroundColor: '#fffbeb',
          borderColor: '#fcd34d',
          textColor: '#92400e',
          iconColor: '#f59e0b',
          size: 'md',
          variant: 'warning',
          showIcon: true,
          showValidationBadge: true,
          customCSS: 'animate-pulse'
        },
        validationRules: [
          { type: 'custom', message: 'Value approaching threshold', config: { formula: 'value > 80' } }
        ]
      },
      {
        id: 'date-picker',
        name: 'Enhanced Date Picker',
        description: 'Styled date input with calendar icon',
        type: 'date',
        icon: 'date',
        category: 'basic',
        styling: {
          backgroundColor: '#fafafa',
          borderColor: '#d4d4d8',
          textColor: '#18181b',
          iconColor: '#3b82f6',
          size: 'md',
          variant: 'info',
          showIcon: true,
          showValidationBadge: false
        },
        validationRules: [
          { type: 'required', message: 'Date is required', config: {} }
        ]
      },
      {
        id: 'email-field',
        name: 'Email Address',
        description: 'Email input with validation and styling',
        type: 'email',
        icon: 'email',
        category: 'basic',
        styling: {
          backgroundColor: '#ffffff',
          borderColor: '#e5e7eb',
          textColor: '#111827',
          iconColor: '#6366f1',
          size: 'md',
          variant: 'default',
          showIcon: true,
          showValidationBadge: true
        },
        validationRules: [
          { type: 'pattern', message: 'Please enter a valid email', config: { pattern: '^[^@]+@[^@]+\\.[^@]+$' } }
        ]
      },
      {
        id: 'currency-input',
        name: 'Currency Amount',
        description: 'Styled currency input with dollar sign',
        type: 'number',
        icon: 'currency',
        category: 'custom',
        styling: {
          backgroundColor: '#f8fafc',
          borderColor: '#cbd5e1',
          textColor: '#0f172a',
          iconColor: '#059669',
          size: 'lg',
          variant: 'default',
          showIcon: true,
          showValidationBadge: false,
          customCSS: 'text-right font-mono'
        },
        validationRules: [
          { type: 'range', message: 'Amount must be positive', config: { min: 0 } }
        ]
      },
      {
        id: 'percentage-field',
        name: 'Percentage Value',
        description: 'Percentage input with custom styling',
        type: 'number',
        icon: 'percentage',
        category: 'custom',
        styling: {
          backgroundColor: '#ffffff',
          borderColor: '#a78bfa',
          textColor: '#581c87',
          iconColor: '#8b5cf6',
          size: 'md',
          variant: 'default',
          showIcon: true,
          showValidationBadge: true,
          customCSS: 'text-center'
        },
        validationRules: [
          { type: 'range', message: 'Percentage must be 0-100', config: { min: 0, max: 100 } }
        ]
      }
    ];

    setTemplates(mockTemplates);
    
    // Initialize preview values
    const initialValues: Record<string, any> = {};
    mockTemplates.forEach(template => {
      initialValues[template.id] = template.type === 'number' ? 25 : 
                                  template.type === 'email' ? 'test@example.com' :
                                  template.type === 'date' ? '2024-02-22' :
                                  'Sample value';
    });
    setPreviewValues(initialValues);
  }, []);

  const createNewTemplate = () => {
    const newTemplate: FieldTemplate = {
      id: `template_${Date.now()}`,
      name: 'New Field Template',
      description: 'Custom field template',
      type: 'text',
      icon: 'text',
      category: 'custom',
      styling: {
        backgroundColor: '#ffffff',
        borderColor: '#d1d5db',
        textColor: '#374151',
        iconColor: '#6b7280',
        size: 'md',
        variant: 'default',
        showIcon: true,
        showValidationBadge: false
      },
      validationRules: []
    };
    
    setSelectedTemplate(newTemplate);
    setIsEditing(true);
  };

  const saveTemplate = () => {
    if (selectedTemplate) {
      setTemplates(prev => {
        const existing = prev.find(t => t.id === selectedTemplate.id);
        if (existing) {
          return prev.map(t => t.id === selectedTemplate.id ? selectedTemplate : t);
        } else {
          return [...prev, selectedTemplate];
        }
      });
      setIsEditing(false);
    }
  };

  const duplicateTemplate = (template: FieldTemplate) => {
    const duplicated = {
      ...template,
      id: `${template.id}_copy_${Date.now()}`,
      name: `${template.name} (Copy)`
    };
    setTemplates(prev => [...prev, duplicated]);
  };

  const deleteTemplate = (templateId: string) => {
    setTemplates(prev => prev.filter(t => t.id !== templateId));
    if (selectedTemplate?.id === templateId) {
      setSelectedTemplate(null);
    }
  };

  const filteredTemplates = templates.filter(template =>
    selectedCategory === 'all' || template.category === selectedCategory
  );

  const getValidationStatus = (template: FieldTemplate, value: any): 'valid' | 'invalid' | 'warning' | 'pending' => {
    if (!value) return template.validationRules.some(r => r.type === 'required') ? 'invalid' : 'valid';
    
    // Simulate validation logic
    if (template.id === 'critical-strength' && typeof value === 'number') {
      if (value < 10 || value > 100) return 'invalid';
      if (value < 20 || value > 80) return 'warning';
    }
    
    if (template.type === 'email' && value) {
      const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;
      return emailRegex.test(value) ? 'valid' : 'invalid';
    }
    
    return 'valid';
  };

  const getValidationMessage = (template: FieldTemplate, status: string): string => {
    switch (status) {
      case 'invalid': return template.validationRules[0]?.message || 'Invalid value';
      case 'warning': return 'Value approaching limits';
      case 'pending': return 'Validating...';
      default: return 'Value is valid';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Custom Field Styling & Templates
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Create and manage custom field templates with advanced styling and validation
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              {['all', 'basic', 'advanced', 'custom'].map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="capitalize"
                >
                  {category}
                </Button>
              ))}
            </div>
            <Button onClick={createNewTemplate}>
              <Star className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Template Library */}
        <Card>
          <CardHeader>
            <CardTitle>Field Templates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className={cn(
                  "p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md",
                  selectedTemplate?.id === template.id && "ring-2 ring-primary"
                )}
                onClick={() => setSelectedTemplate(template)}
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{template.name}</h4>
                      <Badge variant="outline" className="text-xs">
                        {template.type}
                      </Badge>
                      <Badge 
                        variant="secondary" 
                        className={cn(
                          "text-xs",
                          template.category === 'basic' && "bg-green-100 text-green-700",
                          template.category === 'advanced' && "bg-blue-100 text-blue-700",
                          template.category === 'custom' && "bg-purple-100 text-purple-700"
                        )}
                      >
                        {template.category}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{template.description}</p>
                    
                    {/* Mini Preview */}
                    <div className="mt-3">
                      <StyledField
                        template={template}
                        value={previewValues[template.id]}
                        onChange={(value) => setPreviewValues(prev => ({ ...prev, [template.id]: value }))}
                        validationStatus={getValidationStatus(template, previewValues[template.id])}
                        validationMessage={getValidationMessage(template, getValidationStatus(template, previewValues[template.id]))}
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        duplicateTemplate(template);
                      }}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    {template.category === 'custom' && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteTemplate(template.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Template Editor */}
        {selectedTemplate && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Template Editor
                <div className="flex gap-2">
                  {!isEditing ? (
                    <Button size="sm" onClick={() => setIsEditing(true)}>
                      <Settings className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                  ) : (
                    <>
                      <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                        Cancel
                      </Button>
                      <Button size="sm" onClick={saveTemplate}>
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                    </>
                  )}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic Settings */}
              <div className="space-y-4">
                <h4 className="font-medium">Basic Settings</h4>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Template Name</Label>
                    <Input
                      value={selectedTemplate.name}
                      onChange={(e) => setSelectedTemplate(prev => prev ? { ...prev, name: e.target.value } : null)}
                      disabled={!isEditing}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Field Type</Label>
                    <Select
                      value={selectedTemplate.type}
                      onValueChange={(value) => setSelectedTemplate(prev => prev ? { ...prev, type: value } : null)}
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="text">Text</SelectItem>
                        <SelectItem value="number">Number</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="date">Date</SelectItem>
                        <SelectItem value="textarea">Textarea</SelectItem>
                        <SelectItem value="select">Select</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={selectedTemplate.description}
                    onChange={(e) => setSelectedTemplate(prev => prev ? { ...prev, description: e.target.value } : null)}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              {/* Styling Options */}
              <div className="space-y-4">
                <h4 className="font-medium">Styling Options</h4>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Size</Label>
                    <Select
                      value={selectedTemplate.styling.size}
                      onValueChange={(value: 'sm' | 'md' | 'lg') => 
                        setSelectedTemplate(prev => prev ? { 
                          ...prev, 
                          styling: { ...prev.styling, size: value }
                        } : null)
                      }
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sm">Small</SelectItem>
                        <SelectItem value="md">Medium</SelectItem>
                        <SelectItem value="lg">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Variant</Label>
                    <Select
                      value={selectedTemplate.styling.variant}
                      onValueChange={(value: any) => 
                        setSelectedTemplate(prev => prev ? { 
                          ...prev, 
                          styling: { ...prev.styling, variant: value }
                        } : null)
                      }
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="warning">Warning</SelectItem>
                        <SelectItem value="success">Success</SelectItem>
                        <SelectItem value="info">Info</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <Label>Show Icon</Label>
                    <Switch
                      checked={selectedTemplate.styling.showIcon}
                      onCheckedChange={(checked) => 
                        setSelectedTemplate(prev => prev ? { 
                          ...prev, 
                          styling: { ...prev.styling, showIcon: checked }
                        } : null)
                      }
                      disabled={!isEditing}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Show Validation Badge</Label>
                    <Switch
                      checked={selectedTemplate.styling.showValidationBadge}
                      onCheckedChange={(checked) => 
                        setSelectedTemplate(prev => prev ? { 
                          ...prev, 
                          styling: { ...prev.styling, showValidationBadge: checked }
                        } : null)
                      }
                      disabled={!isEditing}
                    />
                  </div>
                </div>
              </div>

              {/* Preview */}
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Live Preview
                </h4>
                
                <div className="p-4 border rounded-lg bg-muted/20">
                  <StyledField
                    template={selectedTemplate}
                    value={previewValues[selectedTemplate.id]}
                    onChange={(value) => setPreviewValues(prev => ({ ...prev, [selectedTemplate.id]: value }))}
                    validationStatus={getValidationStatus(selectedTemplate, previewValues[selectedTemplate.id])}
                    validationMessage={getValidationMessage(selectedTemplate, getValidationStatus(selectedTemplate, previewValues[selectedTemplate.id]))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}