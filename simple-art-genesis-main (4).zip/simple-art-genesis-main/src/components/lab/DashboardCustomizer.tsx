import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Plus, Trash2, BarChart, LineChart, PieChart, AlertTriangle, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CustomChart {
  id: string;
  user_id: string;
  chart_name: string;
  chart_type: string;
  data_source: string;
  chart_config: string;
  filters: string;
  created_at: string;
  updated_at: string;
}

interface DashboardWidget {
  id: string;
  chart_id: string; // Reference to the analytics chart
  chart_name: string;
  chart_type: string;
  is_visible: boolean;
  added_at: string;
}

interface DashboardCustomizerProps {
  userId: string;
  onWidgetsChange: (widgets: DashboardWidget[]) => void;
}

const CHART_ICONS = {
  bar: BarChart,
  line: LineChart,
  pie: PieChart
};

export function DashboardCustomizer({ userId, onWidgetsChange }: DashboardCustomizerProps) {
  const [availableCharts, setAvailableCharts] = useState<CustomChart[]>([]);
  const [dashboardWidgets, setDashboardWidgets] = useState<DashboardWidget[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadAnalyticsCharts();
    loadDashboardWidgets();
  }, [userId]);

  const loadAnalyticsCharts = async () => {
    try {
      // Load custom charts created in Analytics section
      // For web preview, use mock data representing saved analytics charts
      const mockAnalyticsCharts: CustomChart[] = [
        {
          id: "chart_1",
          user_id: userId,
          chart_name: "Monthly Test Volume",
          chart_type: "bar",
          data_source: "test_requests",
          chart_config: JSON.stringify({ xAxisField: "month", yAxisField: "count", aggregationType: "count" }),
          filters: "",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: "chart_2",
          user_id: userId,
          chart_name: "Test Type Distribution",
          chart_type: "pie",
          data_source: "test_requests",
          chart_config: JSON.stringify({ field: "test_type", aggregationType: "count" }),
          filters: "",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: "chart_3",
          user_id: userId,
          chart_name: "Completion Trends",
          chart_type: "line",
          data_source: "test_requests",
          chart_config: JSON.stringify({ xAxisField: "date", yAxisField: "completion_rate" }),
          filters: "status = 'completed'",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ];
      
      setAvailableCharts(mockAnalyticsCharts);
    } catch (error) {
      console.error("Error loading analytics charts:", error);
      toast({
        title: "Error",
        description: "Failed to load analytics charts",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadDashboardWidgets = () => {
    // Load currently added dashboard widgets from localStorage
    try {
      const saved = localStorage.getItem(`dashboard-widgets-${userId}`);
      if (saved) {
        const widgets = JSON.parse(saved);
        setDashboardWidgets(widgets);
        onWidgetsChange(widgets);
      }
    } catch (error) {
      console.error("Error loading dashboard widgets:", error);
    }
  };

  const saveDashboardWidgets = (widgets: DashboardWidget[]) => {
    try {
      localStorage.setItem(`dashboard-widgets-${userId}`, JSON.stringify(widgets));
      onWidgetsChange(widgets);
    } catch (error) {
      console.error("Error saving dashboard widgets:", error);
    }
  };

  const addChartToDashboard = (chart: CustomChart) => {
    const newWidget: DashboardWidget = {
      id: `widget_${Date.now()}`,
      chart_id: chart.id,
      chart_name: chart.chart_name,
      chart_type: chart.chart_type,
      is_visible: true,
      added_at: new Date().toISOString()
    };

    const updatedWidgets = [...dashboardWidgets, newWidget];
    setDashboardWidgets(updatedWidgets);
    saveDashboardWidgets(updatedWidgets);

    toast({
      title: "Chart Added",
      description: `"${chart.chart_name}" has been added to your dashboard.`
    });
  };

  const removeChartFromDashboard = (widgetId: string) => {
    const updatedWidgets = dashboardWidgets.filter(w => w.id !== widgetId);
    setDashboardWidgets(updatedWidgets);
    saveDashboardWidgets(updatedWidgets);

    toast({
      title: "Chart Removed",
      description: "Chart has been removed from your dashboard."
    });
  };

  const toggleChartVisibility = (widgetId: string, isVisible: boolean) => {
    const updatedWidgets = dashboardWidgets.map(w => 
      w.id === widgetId ? { ...w, is_visible: isVisible } : w
    );
    setDashboardWidgets(updatedWidgets);
    saveDashboardWidgets(updatedWidgets);

    toast({
      title: isVisible ? "Chart Shown" : "Chart Hidden",
      description: `Chart is now ${isVisible ? 'visible' : 'hidden'} on your dashboard.`
    });
  };

  const isChartAdded = (chartId: string) => {
    return dashboardWidgets.some(w => w.chart_id === chartId);
  };

  const getChartIcon = (chartType: string) => {
    const IconComponent = CHART_ICONS[chartType as keyof typeof CHART_ICONS] || BarChart;
    return <IconComponent className="h-4 w-4" />;
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Settings className="h-4 w-4 mr-2" />
          Customize Dashboard
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Customize Dashboard</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Import and arrange analytics charts created in the Analytics section
          </p>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Current Dashboard Widgets */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Dashboard Charts</h3>
            {dashboardWidgets.length === 0 ? (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  No charts added to dashboard yet. Import charts from the available analytics below.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dashboardWidgets.map((widget) => (
                  <Card key={widget.id} className="relative">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          {getChartIcon(widget.chart_type)}
                          <div>
                            <h4 className="font-medium">{widget.chart_name}</h4>
                            <p className="text-sm text-muted-foreground capitalize">
                              {widget.chart_type} chart
                            </p>
                            <Badge variant={widget.is_visible ? "default" : "secondary"} className="mt-1">
                              {widget.is_visible ? "Visible" : "Hidden"}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleChartVisibility(widget.id, !widget.is_visible)}
                          >
                            {widget.is_visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeChartFromDashboard(widget.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Available Analytics Charts */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Available Analytics Charts</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Charts created in the Analytics section that can be imported to your dashboard
            </p>
            
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Loading analytics charts...</p>
              </div>
            ) : availableCharts.length === 0 ? (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  No analytics charts available yet. Please create charts in the{" "}
                  <strong>Analytics &gt; Create Custom Graph</strong> section first.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availableCharts.map((chart) => (
                  <Card key={chart.id} className="relative">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          {getChartIcon(chart.chart_type)}
                          <div className="flex-1">
                            <h4 className="font-medium">{chart.chart_name}</h4>
                            <p className="text-sm text-muted-foreground capitalize">
                              {chart.chart_type} chart
                            </p>
                            <p className="text-xs text-muted-foreground">
                              From {chart.data_source.replace('_', ' ')}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Created {new Date(chart.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-3">
                        {isChartAdded(chart.id) ? (
                          <Badge variant="secondary" className="w-full justify-center">
                            Already Added
                          </Badge>
                        ) : (
                          <Button
                            size="sm"
                            className="w-full"
                            onClick={() => addChartToDashboard(chart)}
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Add to Dashboard
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Instructions */}
          <Alert>
            <Settings className="h-4 w-4" />
            <AlertDescription>
              <strong>How to use:</strong>
              <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                <li>Create charts in <strong>Analytics &gt; Create Custom Graph</strong></li>
                <li>Import them here using "Add to Dashboard"</li>
                <li>Use show/hide toggles to control visibility</li>
                <li>Drag and resize charts on the main dashboard</li>
                <li>Save different layouts using "Save Layout"</li>
              </ul>
            </AlertDescription>
          </Alert>
        </div>
      </DialogContent>
    </Dialog>
  );
}