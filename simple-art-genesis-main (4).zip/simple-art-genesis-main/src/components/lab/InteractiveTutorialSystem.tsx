import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  SkipForward, 
  RotateCcw, 
  HelpCircle, 
  Lightbulb, 
  Clock,
  ChevronRight,
  ChevronLeft,
  X,
  Check,
  Star,
  Users,
  Settings,
  BookOpen,
  Zap,
  Target
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  target: string; // CSS selector for element to highlight
  position: 'top' | 'bottom' | 'left' | 'right';
  action?: 'click' | 'hover' | 'input' | 'none';
  content: string;
  image?: string;
  videoUrl?: string;
}

interface Tutorial {
  id: string;
  title: string;
  description: string;
  category: 'beginner' | 'intermediate' | 'advanced';
  role: string[];
  estimatedTime: string;
  steps: TutorialStep[];
  completed: boolean;
}

interface TooltipProps {
  step: TutorialStep;
  currentStep: number;
  totalSteps: number;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
  onComplete: () => void;
  position: { x: number; y: number };
}

const TutorialTooltip: React.FC<TooltipProps> = ({
  step,
  currentStep,
  totalSteps,
  onNext,
  onPrev,
  onSkip,
  onComplete,
  position
}) => {
  return (
    <div 
      className="fixed z-50 bg-white rounded-lg shadow-lg border p-4 max-w-sm"
      style={{
        left: position.x,
        top: position.y,
        transform: 'translate(-50%, -100%)'
      }}
    >
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <h4 className="font-semibold text-sm">{step.title}</h4>
            <p className="text-sm text-muted-foreground">{step.description}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onSkip}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="text-sm text-foreground">
          {step.content}
        </div>
        
        {step.action && (
          <div className="p-2 bg-blue-50 rounded text-xs text-blue-700">
            {step.action === 'click' && '👆 Click this element'}
            {step.action === 'hover' && '🖱️ Hover over this element'}
            {step.action === 'input' && '⌨️ Type in this field'}
          </div>
        )}
        
        <div className="flex items-center justify-between">
          <div className="text-xs text-muted-foreground">
            Step {currentStep + 1} of {totalSteps}
          </div>
          <div className="flex gap-2">
            {currentStep > 0 && (
              <Button variant="outline" size="sm" onClick={onPrev}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
            )}
            {currentStep < totalSteps - 1 ? (
              <Button size="sm" onClick={onNext}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button size="sm" onClick={onComplete}>
                <Check className="w-4 h-4" />
                Complete
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const TutorialHighlight: React.FC<{ targetElement: Element }> = ({ targetElement }) => {
  const [rect, setRect] = useState<DOMRect | null>(null);

  useEffect(() => {
    if (targetElement) {
      setRect(targetElement.getBoundingClientRect());
    }
  }, [targetElement]);

  if (!rect) return null;

  return (
    <div
      className="fixed pointer-events-none z-40 border-2 border-blue-500 rounded bg-blue-500/10"
      style={{
        left: rect.left - 4,
        top: rect.top - 4,
        width: rect.width + 8,
        height: rect.height + 8
      }}
    />
  );
};

export default function InteractiveTutorialSystem() {
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [activeTutorial, setActiveTutorial] = useState<Tutorial | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showCompletionDialog, setShowCompletionDialog] = useState(false);
  const [highlightedElement, setHighlightedElement] = useState<Element | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  // Initialize with comprehensive tutorial data
  useEffect(() => {
    const mockTutorials: Tutorial[] = [
      {
        id: 'developer-mode-intro',
        title: 'Getting Started with Developer Mode',
        description: 'Learn how to activate and use Developer Mode for advanced features',
        category: 'beginner',
        role: ['developer', 'admin'],
        estimatedTime: '5 minutes',
        completed: false,
        steps: [
          {
            id: '1',
            title: 'Welcome to Developer Mode',
            description: 'Developer Mode unlocks advanced features and debugging tools',
            target: '.developer-toggle',
            position: 'bottom',
            action: 'none',
            content: 'Developer Mode provides access to debugging tools, advanced settings, and development features that help you customize and troubleshoot the laboratory system.'
          },
          {
            id: '2',
            title: 'Activating Developer Mode',
            description: 'Click the toggle to enable Developer Mode',
            target: '.developer-toggle',
            position: 'bottom',
            action: 'click',
            content: 'Click this toggle to enable Developer Mode. You\'ll see additional options and tools appear in the interface once activated.'
          },
          {
            id: '3',
            title: 'Developer Panel',
            description: 'Access the floating developer panel',
            target: '.floating-developer-panel',
            position: 'left',
            action: 'click',
            content: 'The floating developer panel provides quick access to debugging information, system logs, and development tools.'
          },
          {
            id: '4',
            title: 'Debug Information',
            description: 'View system information and logs',
            target: '.debug-overlay',
            position: 'top',
            action: 'none',
            content: 'The debug overlay shows real-time system information, performance metrics, and error logs to help with troubleshooting.'
          }
        ]
      },
      {
        id: 'validation-system-tour',
        title: 'Validation Rules Engine Tour',
        description: 'Learn how to create and manage validation rules for quality control',
        category: 'intermediate',
        role: ['quality_manager', 'lab_technician'],
        estimatedTime: '8 minutes',
        completed: false,
        steps: [
          {
            id: '1',
            title: 'Validation Rules Overview',
            description: 'Understanding the validation system',
            target: '.validation-rules-tab',
            position: 'bottom',
            action: 'click',
            content: 'The validation rules engine helps ensure data quality by automatically checking values against predefined criteria.'
          },
          {
            id: '2',
            title: 'Creating a New Rule',
            description: 'Add a new validation rule',
            target: '.create-rule-button',
            position: 'bottom',
            action: 'click',
            content: 'Click here to create a new validation rule. You can set thresholds, cross-field validations, or custom formulas.'
          },
          {
            id: '3',
            title: 'Rule Configuration',
            description: 'Configure rule parameters',
            target: '.rule-builder-form',
            position: 'right',
            action: 'input',
            content: 'Fill in the rule details including name, target field, validation type, and criteria. You can also set custom error messages.'
          },
          {
            id: '4',
            title: 'Testing Rules',
            description: 'Test your validation rules',
            target: '.test-validation-button',
            position: 'top',
            action: 'click',
            content: 'Always test your rules with sample data to ensure they work correctly before activating them for live data.'
          }
        ]
      },
      {
        id: 'module-management',
        title: 'Module System Management',
        description: 'Learn to install, configure, and manage laboratory modules',
        category: 'advanced',
        role: ['admin', 'system_manager'],
        estimatedTime: '12 minutes',
        completed: false,
        steps: [
          {
            id: '1',
            title: 'Module Marketplace',
            description: 'Browse available modules',
            target: '.marketplace-tab',
            position: 'bottom',
            action: 'click',
            content: 'The marketplace contains pre-built modules for various laboratory functions. You can browse, preview, and install modules here.'
          },
          {
            id: '2',
            title: 'Installing Modules',
            description: 'Install a new module',
            target: '.install-module-button',
            position: 'bottom',
            action: 'click',
            content: 'Click install to add a module to your system. Some modules may require configuration after installation.'
          },
          {
            id: '3',
            title: 'Module Configuration',
            description: 'Configure module settings',
            target: '.module-config-panel',
            position: 'left',
            action: 'none',
            content: 'Each module has its own configuration options. Set up parameters, permissions, and integration settings here.'
          },
          {
            id: '4',
            title: 'Module Instances',
            description: 'Create module instances',
            target: '.create-instance-button',
            position: 'bottom',
            action: 'click',
            content: 'Module instances allow you to run the same module with different configurations for different use cases.'
          }
        ]
      },
      {
        id: 'report-generation',
        title: 'Report Generation Workflow',
        description: 'Master the report generation and export features',
        category: 'intermediate',
        role: ['lab_technician', 'quality_manager', 'supervisor'],
        estimatedTime: '10 minutes',
        completed: true,
        steps: [
          {
            id: '1',
            title: 'Report Templates',
            description: 'Choose from available templates',
            target: '.report-templates',
            position: 'bottom',
            action: 'click',
            content: 'Select from pre-built report templates or create custom reports based on your data needs.'
          },
          {
            id: '2',
            title: 'Data Selection',
            description: 'Select data for your report',
            target: '.data-selector',
            position: 'right',
            action: 'none',
            content: 'Choose the date range, test types, and specific data points you want to include in your report.'
          },
          {
            id: '3',
            title: 'Report Preview',
            description: 'Preview before generation',
            target: '.report-preview',
            position: 'top',
            action: 'none',
            content: 'Always preview your report to ensure the data and formatting meet your requirements before generating the final version.'
          }
        ]
      }
    ];

    setTutorials(mockTutorials);
  }, []);

  const startTutorial = (tutorial: Tutorial) => {
    setActiveTutorial(tutorial);
    setCurrentStep(0);
    setIsPlaying(true);
    highlightStep(tutorial.steps[0]);
  };

  const highlightStep = (step: TutorialStep) => {
    try {
      const element = document.querySelector(step.target);
      if (element) {
        setHighlightedElement(element);
        const rect = element.getBoundingClientRect();
        setTooltipPosition({
          x: rect.left + rect.width / 2,
          y: rect.top
        });
      }
    } catch (error) {
      console.log('Element not found:', step.target);
    }
  };

  const nextStep = () => {
    if (activeTutorial && currentStep < activeTutorial.steps.length - 1) {
      const next = currentStep + 1;
      setCurrentStep(next);
      highlightStep(activeTutorial.steps[next]);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      const prev = currentStep - 1;
      setCurrentStep(prev);
      if (activeTutorial) {
        highlightStep(activeTutorial.steps[prev]);
      }
    }
  };

  const completeTutorial = () => {
    if (activeTutorial) {
      setTutorials(prev => prev.map(t => 
        t.id === activeTutorial.id ? { ...t, completed: true } : t
      ));
      setShowCompletionDialog(true);
      stopTutorial();
    }
  };

  const stopTutorial = () => {
    setActiveTutorial(null);
    setCurrentStep(0);
    setIsPlaying(false);
    setHighlightedElement(null);
  };

  const filteredTutorials = tutorials.filter(tutorial => 
    selectedCategory === 'all' || tutorial.category === selectedCategory
  );

  const categoryColors = {
    beginner: 'bg-green-100 text-green-700',
    intermediate: 'bg-blue-100 text-blue-700',
    advanced: 'bg-purple-100 text-purple-700'
  };

  return (
    <div className="space-y-6">
      {/* Tutorial Controls */}
      {activeTutorial && isPlaying && (
        <>
          {highlightedElement && <TutorialHighlight targetElement={highlightedElement} />}
          <TutorialTooltip
            step={activeTutorial.steps[currentStep]}
            currentStep={currentStep}
            totalSteps={activeTutorial.steps.length}
            onNext={nextStep}
            onPrev={prevStep}
            onSkip={stopTutorial}
            onComplete={completeTutorial}
            position={tooltipPosition}
          />
          <div className="fixed bottom-4 right-4 z-50">
            <Card className="w-80">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-sm">{activeTutorial.title}</h4>
                  <Button variant="ghost" size="sm" onClick={stopTutorial}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <Progress 
                  value={(currentStep + 1) / activeTutorial.steps.length * 100} 
                  className="mb-2"
                />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    Step {currentStep + 1} of {activeTutorial.steps.length}
                  </span>
                  <div className="flex gap-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setIsPlaying(!isPlaying)}
                    >
                      {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                    </Button>
                    <Button variant="outline" size="sm" onClick={stopTutorial}>
                      <RotateCcw className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {/* Tutorial Library */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Interactive Tutorial System
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Guided tours and tutorials to help you master the laboratory system
          </p>
        </CardHeader>
        <CardContent>
          {/* Category Filter */}
          <div className="flex gap-2 mb-6">
            {['all', 'beginner', 'intermediate', 'advanced'].map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="capitalize"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Tutorial Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredTutorials.map((tutorial) => (
              <Card key={tutorial.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-base">{tutorial.title}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className={cn("text-xs", categoryColors[tutorial.category])}
                        >
                          {tutorial.category}
                        </Badge>
                        {tutorial.completed && (
                          <Badge variant="default" className="text-xs bg-green-100 text-green-700">
                            <Check className="w-3 h-3 mr-1" />
                            Completed
                          </Badge>
                        )}
                      </div>
                    </div>
                    {tutorial.completed && <Star className="w-5 h-5 text-yellow-500 fill-current" />}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">{tutorial.description}</p>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Target className="w-3 h-3" />
                      {tutorial.steps.length} steps
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {tutorial.estimatedTime}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {tutorial.role.map((role) => (
                      <Badge key={role} variant="secondary" className="text-xs">
                        {role.replace('_', ' ')}
                      </Badge>
                    ))}
                  </div>
                  
                  <Button 
                    onClick={() => startTutorial(tutorial)}
                    className="w-full"
                    disabled={isPlaying}
                  >
                    {tutorial.completed ? (
                      <>
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Replay Tutorial
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Start Tutorial
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Help Tooltips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            Quick Help & Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50">
                <HelpCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900">Feature Discovery</h4>
                  <p className="text-sm text-blue-700">
                    Hover over any UI element to see contextual help and tips
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50">
                <Users className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-900">Role-Specific Guidance</h4>
                  <p className="text-sm text-green-700">
                    Tutorials are customized based on your role and permissions
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50">
                <Zap className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-purple-900">Keyboard Shortcuts</h4>
                  <p className="text-sm text-purple-700">
                    Press <kbd className="px-1 py-0.5 bg-white rounded border text-xs">?</kbd> to see available shortcuts
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 rounded-lg bg-orange-50">
                <Settings className="w-5 h-5 text-orange-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-900">Interactive Elements</h4>
                  <p className="text-sm text-orange-700">
                    Look for the interactive hints and guided actions throughout the interface
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Completion Dialog */}
      <Dialog open={showCompletionDialog} onOpenChange={setShowCompletionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Check className="w-5 h-5 text-green-600" />
              Tutorial Completed!
            </DialogTitle>
            <DialogDescription>
              Congratulations! You've successfully completed the tutorial. 
              You can replay it anytime or try another tutorial to expand your knowledge.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setShowCompletionDialog(false)}>
              Close
            </Button>
            <Button onClick={() => {
              setShowCompletionDialog(false);
              setSelectedCategory('all');
            }}>
              Explore More Tutorials
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}