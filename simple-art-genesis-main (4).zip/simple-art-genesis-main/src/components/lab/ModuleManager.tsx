import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Package, 
  Download, 
  Upload, 
  Settings, 
  Trash2, 
  Play, 
  Pause, 
  FileText, 
  Database,
  Code,
  Store,
  Plus,
  Search,
  Filter,
  Star,
  Users,
  Calendar,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { dataService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import type { Module, ModuleMarketplace, ModuleInstance } from '@/services/api/types';

export default function ModuleManager() {
  const [modules, setModules] = useState<Module[]>([]);
  const [marketplaceModules, setMarketplaceModules] = useState<ModuleMarketplace[]>([]);
  const [moduleInstances, setModuleInstances] = useState<ModuleInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const { toast } = useToast();

  // Initialize with comprehensive mock data for testing
  useEffect(() => {
    const mockModules: Module[] = [
      {
        id: 'cube-test-1.0.0',
        config: {
          name: 'Cube Test Manager',
          version: '1.0.0',
          description: 'Complete concrete cube testing workflow management',
          author: 'Lab Systems Inc.',
          license: 'MIT',
          dependencies: [],
          tags: ['testing', 'concrete', 'quality'],
          category: 'testing',
          permissions: ['test.create', 'test.read', 'test.update'],
          minAppVersion: '1.0.0'
        },
        schema: {
          tables: [
            {
              name: 'cube_tests',
              columns: [
                { name: 'id', type: 'uuid', required: true },
                { name: 'test_date', type: 'date', required: true },
                { name: 'strength', type: 'number', required: true },
                { name: 'status', type: 'text', required: true, default: 'pending' }
              ]
            }
          ]
        },
        components: [
          { name: 'CubeTestForm', type: 'form', path: '/cube-test', permissions: ['test.create'] },
          { name: 'TestResults', type: 'list', path: '/cube-test/results', permissions: ['test.read'] }
        ],
        logic: {
          calculations: { 'strength_ratio': 'actual_strength / design_strength * 100' },
          validations: { 'min_strength': 'strength >= 20' }
        },
        enabled: true,
        installed_at: '2024-01-15T10:00:00Z',
        updated_at: '2024-01-15T10:00:00Z',
        data_version: '1.0.0'
      },
      {
        id: 'mix-design-2.1.0',
        config: {
          name: 'Advanced Mix Design',
          version: '2.1.0',
          description: 'Comprehensive concrete mix design calculator with optimization',
          author: 'Concrete Experts Ltd.',
          license: 'Commercial',
          dependencies: ['cube-test-1.0.0'],
          tags: ['mix-design', 'concrete', 'optimization'],
          category: 'testing',
          permissions: ['mix.create', 'mix.read', 'mix.update', 'mix.delete'],
          minAppVersion: '1.0.0'
        },
        schema: {
          tables: [
            {
              name: 'mix_designs',
              columns: [
                { name: 'id', type: 'uuid', required: true },
                { name: 'name', type: 'text', required: true },
                { name: 'cement_content', type: 'number', required: true },
                { name: 'water_ratio', type: 'number', required: true },
                { name: 'strength_grade', type: 'text', required: true }
              ]
            }
          ]
        },
        components: [
          { name: 'MixDesigner', type: 'form', path: '/mix-design', permissions: ['mix.create'] },
          { name: 'MixLibrary', type: 'list', path: '/mix-design/library', permissions: ['mix.read'] }
        ],
        logic: {
          calculations: { 
            'water_cement_ratio': 'water_content / cement_content',
            'total_volume': 'cement_volume + water_volume + aggregate_volume'
          }
        },
        enabled: true,
        installed_at: '2024-01-20T14:30:00Z',
        updated_at: '2024-02-01T09:15:00Z',
        data_version: '2.1.0'
      },
      {
        id: 'analytics-dashboard-1.5.0',
        config: {
          name: 'Advanced Analytics Dashboard',
          version: '1.5.0',
          description: 'Real-time analytics and reporting with custom visualizations',
          author: 'Data Insights Pro',
          license: 'Premium',
          dependencies: [],
          tags: ['analytics', 'dashboard', 'reporting'],
          category: 'dashboard',
          permissions: ['analytics.read', 'reports.create'],
          minAppVersion: '1.0.0'
        },
        schema: {
          tables: [
            {
              name: 'analytics_metrics',
              columns: [
                { name: 'id', type: 'uuid', required: true },
                { name: 'metric_name', type: 'text', required: true },
                { name: 'value', type: 'number', required: true },
                { name: 'timestamp', type: 'timestamp', required: true }
              ]
            }
          ]
        },
        components: [
          { name: 'AnalyticsDashboard', type: 'dashboard', path: '/analytics', permissions: ['analytics.read'] },
          { name: 'CustomReports', type: 'widget', path: '/analytics/reports', permissions: ['reports.create'] }
        ],
        logic: {
          calculations: {
            'completion_rate': 'completed_tests / total_tests * 100',
            'average_strength': 'sum(strength_values) / count(strength_values)'
          }
        },
        enabled: false,
        installed_at: '2024-01-25T11:45:00Z',
        updated_at: '2024-01-25T11:45:00Z',
        data_version: '1.5.0'
      }
    ];

    const mockMarketplace: ModuleMarketplace[] = [
      {
        id: 'mp_001',
        name: 'Quality Control Pro',
        description: 'Advanced quality control module with statistical analysis and trend monitoring',
        version: '3.2.1',
        author: 'QualityTech Solutions',
        downloads: 2847,
        rating: 4.8,
        category: 'quality',
        price: 299,
        screenshots: ['/mock-screenshots/qc-pro-1.jpg', '/mock-screenshots/qc-pro-2.jpg'],
        documentation_url: 'https://docs.qualitytech.com/qc-pro',
        source_url: 'https://github.com/qualitytech/qc-pro'
      },
      {
        id: 'mp_002',
        name: 'Environmental Monitor',
        description: 'Real-time environmental condition monitoring for laboratory spaces',
        version: '2.0.4',
        author: 'EnviroSense Labs',
        downloads: 1523,
        rating: 4.6,
        category: 'utility',
        price: 149,
        screenshots: ['/mock-screenshots/env-monitor-1.jpg'],
        documentation_url: 'https://docs.envirosense.com/monitor'
      },
      {
        id: 'mp_003',
        name: 'Sample Tracking System',
        description: 'Complete sample lifecycle tracking with barcode/QR code integration',
        version: '4.1.0',
        author: 'TrackLab Systems',
        downloads: 3291,
        rating: 4.9,
        category: 'workflow',
        price: 399,
        screenshots: ['/mock-screenshots/tracking-1.jpg', '/mock-screenshots/tracking-2.jpg'],
        documentation_url: 'https://docs.tracklab.com/tracking'
      },
      {
        id: 'mp_004',
        name: 'Certification Manager',
        description: 'Automated certificate generation and compliance management',
        version: '1.8.2',
        author: 'CertifyPro',
        downloads: 876,
        rating: 4.4,
        category: 'reports',
        price: 199,
        screenshots: ['/mock-screenshots/cert-manager-1.jpg'],
        documentation_url: 'https://docs.certifypro.com/manager'
      },
      {
        id: 'mp_005',
        name: 'IoT Sensors Integration',
        description: 'Connect and monitor IoT sensors for automated data collection',
        version: '2.3.0',
        author: 'IoT Solutions Inc.',
        downloads: 654,
        rating: 4.2,
        category: 'utility',
        price: 0,
        screenshots: ['/mock-screenshots/iot-sensors-1.jpg'],
        documentation_url: 'https://docs.iotsolutions.com/sensors',
        source_url: 'https://github.com/iotsolutions/lab-sensors'
      }
    ];

    const mockInstances: ModuleInstance[] = [
      {
        id: 'inst_001',
        module_id: 'cube-test-1.0.0',
        name: 'Main Cube Testing',
        configuration: {
          default_test_age: 28,
          auto_calculate_strength: true,
          notification_enabled: true,
          report_template: 'standard'
        },
        enabled: true,
        created_at: '2024-01-15T10:30:00Z',
        updated_at: '2024-01-15T10:30:00Z'
      },
      {
        id: 'inst_002',
        module_id: 'mix-design-2.1.0',
        name: 'High-Strength Mix Designer',
        configuration: {
          max_cement_content: 500,
          default_slump: 100,
          optimization_enabled: true,
          cost_analysis: true
        },
        enabled: true,
        created_at: '2024-01-20T15:00:00Z',
        updated_at: '2024-02-01T10:00:00Z'
      },
      {
        id: 'inst_003',
        module_id: 'analytics-dashboard-1.5.0',
        name: 'Weekly Performance Dashboard',
        configuration: {
          refresh_interval: 300,
          chart_types: ['line', 'bar', 'pie'],
          data_retention_days: 90
        },
        enabled: false,
        created_at: '2024-01-25T12:00:00Z',
        updated_at: '2024-01-25T12:00:00Z'
      }
    ];

    setModules(mockModules);
    setMarketplaceModules(mockMarketplace);
    setModuleInstances(mockInstances);
    setLoading(false);
  }, []);
  const handleEnableModule = async (moduleId: string, enabled: boolean) => {
    try {
      if (enabled) {
        await dataService.enableModule(moduleId);
      } else {
        await dataService.disableModule(moduleId);
      }
      
      setModules(modules.map(m => 
        m.id === moduleId ? { ...m, enabled } : m
      ));
      
      toast({
        title: enabled ? 'Module Enabled' : 'Module Disabled',
        description: `Module has been ${enabled ? 'enabled' : 'disabled'} successfully`
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: `Failed to ${enabled ? 'enable' : 'disable'} module`,
        variant: 'destructive'
      });
    }
  };

  const handleUninstallModule = async (moduleId: string) => {
    try {
      await dataService.uninstallModule(moduleId);
      setModules(modules.filter(m => m.id !== moduleId));
      toast({
        title: 'Module Uninstalled',
        description: 'Module has been uninstalled successfully'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to uninstall module',
        variant: 'destructive'
      });
    }
  };

  const handleInstallFromMarketplace = async (marketplaceModule: ModuleMarketplace) => {
    try {
      setLoading(true);
      const moduleData = await dataService.downloadModule(marketplaceModule.id);
      const installedModule = await dataService.installModule(moduleData.data);
      
      setModules([...modules, installedModule.data]);
      toast({
        title: 'Module Installed',
        description: `${marketplaceModule.name} has been installed successfully`
      });
    } catch (error) {
      toast({
        title: 'Installation Failed',
        description: 'Failed to install module from marketplace',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExportModule = async (moduleId: string) => {
    try {
      const response = await dataService.exportModule(moduleId);
      const module = modules.find(m => m.id === moduleId);
      
      // Create download link
      const url = URL.createObjectURL(response.data);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${module?.config.name || 'module'}-v${module?.config.version || '1.0.0'}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: 'Export Complete',
        description: 'Module exported successfully'
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'Failed to export module',
        variant: 'destructive'
      });
    }
  };

  const handleImportModule = async (file: File) => {
    try {
      setLoading(true);
      const response = await dataService.importModule(file);
      setModules([...modules, response.data]);
      setImportDialogOpen(false);
      
      toast({
        title: 'Import Complete',
        description: 'Module imported successfully'
      });
    } catch (error) {
      toast({
        title: 'Import Failed',
        description: 'Failed to import module',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredModules = modules.filter(module => {
    const matchesSearch = module.config.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         module.config.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || module.config.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const filteredMarketplace = marketplaceModules.filter(module => {
    const matchesSearch = module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || module.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading modules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Module Manager</h2>
          <p className="text-muted-foreground">
            Manage plugins and extensions for your laboratory system
          </p>
        </div>
        
        <div className="flex gap-2">
          <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Import Module
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Module</DialogTitle>
                <DialogDescription>
                  Upload a module file (.json or .zip) to install
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="moduleFile">Module File</Label>
                  <Input
                    id="moduleFile"
                    type="file"
                    accept=".json,.zip"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleImportModule(file);
                      }
                    }}
                  />
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search modules..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="testing">Testing</SelectItem>
            <SelectItem value="dashboard">Dashboard</SelectItem>
            <SelectItem value="reports">Reports</SelectItem>
            <SelectItem value="workflow">Workflow</SelectItem>
            <SelectItem value="utility">Utility</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="installed" className="space-y-4">
        <TabsList>
          <TabsTrigger value="installed">
            <Package className="w-4 h-4 mr-2" />
            Installed ({modules.length})
          </TabsTrigger>
          <TabsTrigger value="marketplace">
            <Store className="w-4 h-4 mr-2" />
            Marketplace ({marketplaceModules.length})
          </TabsTrigger>
          <TabsTrigger value="instances">
            <Settings className="w-4 h-4 mr-2" />
            Instances ({moduleInstances.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="installed" className="space-y-4">
          {filteredModules.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No modules found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm || categoryFilter !== 'all' 
                    ? 'No modules match your search criteria'
                    : 'No modules are currently installed'
                  }
                </p>
                <Button variant="outline" onClick={() => {
                  setSearchTerm('');
                  setCategoryFilter('all');
                }}>
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredModules.map((module) => (
                <Card key={module.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{module.config.name}</CardTitle>
                        <CardDescription className="text-sm">
                          v{module.config.version} by {module.config.author}
                        </CardDescription>
                      </div>
                      <Badge variant={module.enabled ? 'default' : 'secondary'}>
                        {module.enabled ? 'Enabled' : 'Disabled'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      {module.config.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">
                        {module.config.category}
                      </Badge>
                      {module.config.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={module.enabled}
                          onCheckedChange={(checked) => 
                            handleEnableModule(module.id, checked)
                          }
                        />
                        <Label className="text-sm">
                          {module.enabled ? 'Enabled' : 'Disabled'}
                        </Label>
                      </div>
                      
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedModule(module)}
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleExportModule(module.id)}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUninstallModule(module.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="marketplace" className="space-y-4">
          {filteredMarketplace.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Store className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No modules found</h3>
                <p className="text-muted-foreground">
                  No modules available in the marketplace match your search
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredMarketplace.map((module) => (
                <Card key={module.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{module.name}</CardTitle>
                        <CardDescription className="text-sm">
                          v{module.version} by {module.author}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{module.rating}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      {module.description}
                    </p>
                    
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {module.downloads.toLocaleString()} downloads
                      </div>
                      <div>
                        {module.price === 0 ? 'Free' : `$${module.price}`}
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      onClick={() => handleInstallFromMarketplace(module)}
                      disabled={modules.some(m => m.config.name === module.name)}
                    >
                      {modules.some(m => m.config.name === module.name) ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Installed
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4 mr-2" />
                          Install
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="instances" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Module Instances</h3>
            <Button variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Create Instance
            </Button>
          </div>
          
          {moduleInstances.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Settings className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No instances configured</h3>
                <p className="text-muted-foreground">
                  Create module instances to customize their behavior
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {moduleInstances.map((instance) => (
                <Card key={instance.id}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-lg">{instance.name}</CardTitle>
                        <CardDescription>
                          Module: {modules.find(m => m.id === instance.module_id)?.config.name || 'Unknown'}
                        </CardDescription>
                      </div>
                      <Badge variant={instance.enabled ? 'default' : 'secondary'}>
                        {instance.enabled ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">
                        Created: {new Date(instance.created_at).toLocaleDateString()}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Module Details Dialog */}
      {selectedModule && (
        <Dialog open={!!selectedModule} onOpenChange={() => setSelectedModule(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedModule.config.name}</DialogTitle>
              <DialogDescription>
                Module configuration and details
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Tabs defaultValue="info">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="info">Info</TabsTrigger>
                  <TabsTrigger value="schema">Schema</TabsTrigger>
                  <TabsTrigger value="components">Components</TabsTrigger>
                  <TabsTrigger value="logic">Logic</TabsTrigger>
                </TabsList>
                
                <TabsContent value="info" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Name</Label>
                      <p className="text-sm text-muted-foreground">{selectedModule.config.name}</p>
                    </div>
                    <div>
                      <Label>Version</Label>
                      <p className="text-sm text-muted-foreground">{selectedModule.config.version}</p>
                    </div>
                    <div>
                      <Label>Author</Label>
                      <p className="text-sm text-muted-foreground">{selectedModule.config.author}</p>
                    </div>
                    <div>
                      <Label>Category</Label>
                      <p className="text-sm text-muted-foreground">{selectedModule.config.category}</p>
                    </div>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <p className="text-sm text-muted-foreground">{selectedModule.config.description}</p>
                  </div>
                  <div>
                    <Label>Dependencies</Label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedModule.config.dependencies.map((dep) => (
                        <Badge key={dep} variant="outline" className="text-xs">{dep}</Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="schema">
                  <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto max-h-64">
                    {JSON.stringify(selectedModule.schema, null, 2)}
                  </pre>
                </TabsContent>
                
                <TabsContent value="components">
                  <div className="space-y-2">
                    {selectedModule.components.map((comp) => (
                      <div key={comp.name} className="flex justify-between items-center p-2 border rounded">
                        <div>
                          <p className="font-medium">{comp.name}</p>
                          <p className="text-xs text-muted-foreground">{comp.type}</p>
                        </div>
                        <Badge variant="outline">{comp.type}</Badge>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="logic">
                  <pre className="text-xs bg-muted p-4 rounded-lg overflow-auto max-h-64">
                    {JSON.stringify(selectedModule.logic, null, 2)}
                  </pre>
                </TabsContent>
              </Tabs>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}