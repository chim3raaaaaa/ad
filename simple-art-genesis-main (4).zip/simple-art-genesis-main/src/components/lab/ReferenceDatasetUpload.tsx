import React, { useState, useCallback, useEffect } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, Info, Loader2, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { referenceDataUploadService, UploadResult, ReferenceTableInfo } from '@/services/api/referenceDataUploadService';

interface UploadStatus {
  fileName: string;
  status: 'uploading' | 'success' | 'error';
  message: string;
  rowsInserted?: number;
  timestamp: string;
}

const SUPPORTED_FILES = [
  { 
    fileName: 'lab tests.csv', 
    description: 'Laboratory test types and configurations',
    tableName: 'lab_tests',
    requiredColumns: ['code', 'name', 'type', 'active']
  },
  { 
    fileName: 'lab group code.csv', 
    description: 'Lab sites, products, and machine mappings',
    tableName: 'lab_group_code',
    requiredColumns: ['lab_site', 'lab_product', 'lab_machine', 'active']
  },
  { 
    fileName: 'lab mould.csv', 
    description: 'Mould references and machine assignments',
    tableName: 'lab_mould',
    requiredColumns: ['code', 'name', 'machine_no', 'active']
  },
  { 
    fileName: 'sampling places.csv', 
    description: 'Sample collection locations',
    tableName: 'sampling_places',
    requiredColumns: ['code', 'name', 'location', 'active']
  },
  { 
    fileName: 'colour.csv', 
    description: 'Color codes and specifications',
    tableName: 'colour',
    requiredColumns: ['code', 'name', 'hex_value', 'active']
  },
  { 
    fileName: 'climatic conditions.csv', 
    description: 'Weather and environmental conditions',
    tableName: 'climatic_conditions',
    requiredColumns: ['code', 'name', 'description', 'active']
  }
];

export const ReferenceDatasetUpload: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadHistory, setUploadHistory] = useState<UploadStatus[]>([]);
  const [tableInfo, setTableInfo] = useState<ReferenceTableInfo[]>([]);
  const [loadingTables, setLoadingTables] = useState(true);
  const [dragActive, setDragActive] = useState(false);
  const { toast } = useToast();

  // Load table information on mount
  useEffect(() => {
    loadTableInfo();
  }, []);

  const loadTableInfo = async () => {
    setLoadingTables(true);
    try {
      const info = await referenceDataUploadService.getReferenceTablesInfo();
      setTableInfo(info);
      
      // Load upload history
      const history = await referenceDataUploadService.getUploadHistory(10);
      const formattedHistory: UploadStatus[] = history.map(record => ({
        fileName: record.filename,
        status: 'success',
        message: `${record.rows_imported} rows imported`,
        rowsInserted: record.rows_imported,
        timestamp: record.uploaded_at
      }));
      setUploadHistory(formattedHistory);
    } catch (error) {
      console.error('Failed to load table info:', error);
      toast({
        title: "Error",
        description: "Failed to load reference table information",
        variant: "destructive"
      });
    } finally {
      setLoadingTables(false);
    }
  };

  const handleFileSelect = useCallback((file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: 'Invalid File Type',
        description: 'Please select a CSV file.',
        variant: 'destructive'
      });
      return;
    }

    const supportedFileNames = SUPPORTED_FILES.map(f => f.fileName.toLowerCase());
    if (!supportedFileNames.includes(file.name.toLowerCase())) {
      toast({
        title: 'Unsupported File',
        description: `File "${file.name}" is not a supported reference dataset. Please select one of: ${SUPPORTED_FILES.map(f => f.fileName).join(', ')}`,
        variant: 'destructive'
      });
      return;
    }

    setSelectedFile(file);
  }, [toast]);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  }, [handleFileSelect]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files?.[0]) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const processUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    const fileName = selectedFile.name;

    try {
      // Upload using the SQLite service
      const result: UploadResult = await referenceDataUploadService.uploadCSV(
        selectedFile, 
        'Current User' // TODO: Get from auth context
      );

      const newStatus: UploadStatus = {
        fileName,
        status: result.success ? 'success' : 'error',
        message: result.success 
          ? `Successfully imported ${result.rowsImported} rows${result.errors.length > 0 ? ` (${result.errors.length} warnings)` : ''}`
          : result.errors.join(', '),
        rowsInserted: result.rowsImported,
        timestamp: result.timestamp
      };
      
      setUploadHistory(prev => [newStatus, ...prev.slice(0, 9)]);
      
      if (result.success) {
        setSelectedFile(null);
        await loadTableInfo(); // Refresh table info
        
        toast({
          title: 'Upload Successful',
          description: `${fileName} - ${result.rowsImported} rows imported`,
        });
      } else {
        toast({
          title: 'Upload Failed',
          description: result.errors.join(', '),
          variant: 'destructive'
        });
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      
      const newStatus: UploadStatus = {
        fileName,
        status: 'error',
        message: errorMessage,
        timestamp: new Date().toISOString()
      };
      
      setUploadHistory(prev => [newStatus, ...prev.slice(0, 9)]);

      toast({
        title: 'Upload Failed',
        description: errorMessage,
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
    }
  };

  const formatTimestamp = (timestamp: string | null) => {
    if (!timestamp) return 'Never';
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Upload Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload Reference Dataset
            </CardTitle>
            <CardDescription>
              Upload CSV files to populate reference lookup tables
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Drag & Drop Area */}
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive 
                  ? 'border-primary bg-primary/5' 
                  : 'border-muted-foreground/25 hover:border-muted-foreground/50'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <div className="space-y-2">
                <p className="text-lg font-medium">
                  {dragActive ? 'Drop your CSV file here' : 'Drag & drop or select a CSV file'}
                </p>
                <p className="text-muted-foreground text-sm">
                  Supported files: {SUPPORTED_FILES.map(f => f.fileName).join(', ')}
                </p>
              </div>
              <Input
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="mt-4 max-w-sm mx-auto"
              />
            </div>

            {/* Selected File */}
            {selectedFile && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <div className="flex items-center justify-between">
                    <span>Selected: <strong>{selectedFile.name}</strong></span>
                    <Button 
                      onClick={processUpload}
                      disabled={isUploading}
                      size="sm"
                    >
                      {isUploading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Uploading...
                        </>
                      ) : (
                        'Upload'
                      )}
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Table Status */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base">Table Status</CardTitle>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={loadTableInfo}
              disabled={loadingTables}
            >
              <RefreshCw className={`h-4 w-4 ${loadingTables ? 'animate-spin' : ''}`} />
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {loadingTables ? (
              <div className="text-center py-4">
                <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
              </div>
            ) : (
              tableInfo.map((table) => (
                <div key={table.tableName} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{table.tableName}</span>
                    <Badge variant={table.rowCount > 0 ? "secondary" : "outline"}>
                      {table.rowCount} rows
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Updated: {formatTimestamp(table.lastUpdated)}
                  </p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Supported Files Info */}
      <Card>
        <CardHeader>
          <CardTitle>Supported Reference Files</CardTitle>
          <CardDescription>
            CSV files that can be uploaded to populate lookup tables
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {SUPPORTED_FILES.map((config) => (
              <div key={config.fileName} className="flex items-start gap-3 p-4 border rounded-lg">
                <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{config.fileName}</p>
                  <p className="text-muted-foreground text-xs mb-2">{config.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {config.requiredColumns.map((col) => (
                      <Badge key={col} variant="outline" className="text-xs">
                        {col}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upload History */}
      {uploadHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Uploads</CardTitle>
            <CardDescription>
              History of the last 10 upload attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {uploadHistory.map((upload, index) => (
                <div 
                  key={`${upload.fileName}-${index}`}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    {upload.status === 'success' ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    )}
                    <div>
                      <p className="font-medium text-sm">{upload.fileName}</p>
                      <p className="text-muted-foreground text-xs">{upload.message}</p>
                      {upload.timestamp && (
                        <p className="text-muted-foreground text-xs">
                          {formatTimestamp(upload.timestamp)}
                        </p>
                      )}
                    </div>
                  </div>
                  {upload.rowsInserted && (
                    <Badge variant="outline">
                      {upload.rowsInserted} rows
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};