import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash2, Eye, Code, Save, Copy, Settings, Palette } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PlacementSelector } from '@/components/developer/PlacementSelector';
import { SuccessMessageDialog } from '@/components/developer/SuccessMessageDialog';
import type { SuccessMessage } from '@/types/developer';

interface ComponentProp {
  id: string;
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  required: boolean;
  defaultValue?: any;
  description?: string;
}

export interface CustomComponent {
  id: string;
  name: string;
  description: string;
  componentType: 'ui' | 'functional' | 'layout';
  templateCode: string;
  props: ComponentProp[];
  styleConfig: {
    className?: string;
    customCSS?: string;
  };
  dependencies: string[];
  category: string;
  isReusable: boolean;
  created_at: string;
}

export function ComponentBuilder() {
  const { toast } = useToast();
  const [currentComponent, setCurrentComponent] = useState<CustomComponent>({
    id: '',
    name: '',
    description: '',
    componentType: 'ui',
    templateCode: '',
    props: [],
    styleConfig: {},
    dependencies: [],
    category: 'custom',
    isReusable: true,
    created_at: new Date().toISOString()
  });
  const [previewMode, setPreviewMode] = useState(false);
  const [savedComponents, setSavedComponents] = useState<CustomComponent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Placement selector state
  const [selectedPlacement, setSelectedPlacement] = useState('dashboard');
  const [moduleId, setModuleId] = useState('');
  const [customRoute, setCustomRoute] = useState('');
  
  // Success dialog state
  const [successMessage, setSuccessMessage] = useState<SuccessMessage | null>(null);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  useEffect(() => {
    loadSavedComponents();
  }, []);

  const loadSavedComponents = async () => {
    try {
      const saved = localStorage.getItem('custom_components');
      if (saved) {
        setSavedComponents(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load saved components:', error);
    }
  };

  const componentTypes = [
    { value: 'ui', label: 'UI Component' },
    { value: 'functional', label: 'Functional Component' },
    { value: 'layout', label: 'Layout Component' }
  ];

  const propTypes = [
    { value: 'string', label: 'String' },
    { value: 'number', label: 'Number' },
    { value: 'boolean', label: 'Boolean' },
    { value: 'object', label: 'Object' },
    { value: 'array', label: 'Array' }
  ];

  const addProp = () => {
    const newProp: ComponentProp = {
      id: `prop_${Date.now()}`,
      name: 'newProp',
      type: 'string',
      required: false
    };
    
    setCurrentComponent(prev => ({
      ...prev,
      props: [...prev.props, newProp]
    }));
  };

  const updateProp = (propId: string, updates: Partial<ComponentProp>) => {
    setCurrentComponent(prev => ({
      ...prev,
      props: prev.props.map(prop => 
        prop.id === propId ? { ...prop, ...updates } : prop
      )
    }));
  };

  const removeProp = (propId: string) => {
    setCurrentComponent(prev => ({
      ...prev,
      props: prev.props.filter(prop => prop.id !== propId)
    }));
  };

  const generateComponentCode = () => {
    const componentName = currentComponent.name.replace(/\s+/g, '');
    const propsInterface = currentComponent.props.length > 0 ? `
interface ${componentName}Props {
${currentComponent.props.map(prop => 
  `  ${prop.name}${prop.required ? '' : '?'}: ${prop.type === 'array' ? 'any[]' : prop.type};`
).join('\n')}
}` : '';

    const propsParam = currentComponent.props.length > 0 ? 
      `{ ${currentComponent.props.map(p => p.name).join(', ')} }: ${componentName}Props` : '';

    return `${propsInterface}

export function ${componentName}(${propsParam}) {
  return (
    <div className="${currentComponent.styleConfig.className || ''}">
      ${currentComponent.templateCode || '<!-- Component content here -->'}
    </div>
  );
}`;
  };

  const saveComponent = async () => {
    if (!currentComponent.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Component name is required",
        variant: "destructive"
      });
      return;
    }

    const componentToSave = {
      ...currentComponent,
      id: currentComponent.id || `comp_${Date.now()}`,
      created_at: currentComponent.created_at || new Date().toISOString(),
      placement: selectedPlacement,
      module_id: moduleId || null,
      custom_route: customRoute || null
    };

    try {
      // Try to save to Electron database if available
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO component_definitions (id, name, description, component_code, props_schema, placement, module_id, custom_route, created_at, updated_at, created_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            componentToSave.id,
            componentToSave.name,
            componentToSave.description || '',
            generateComponentCode(),
            JSON.stringify(componentToSave.props),
            componentToSave.placement,
            componentToSave.module_id,
            componentToSave.custom_route,
            componentToSave.created_at,
            new Date().toISOString(),
            'current_user'
          ]
        );

        if (!result.success) {
          throw new Error(result.error);
        }
      }

      // Update local state
      setSavedComponents(prev => {
        const existing = prev.find(c => c.id === componentToSave.id);
        if (existing) {
          return prev.map(c => c.id === componentToSave.id ? componentToSave : c);
        }
        return [...prev, componentToSave];
      });

      // Show success message
      const message: SuccessMessage = {
        title: 'Component Created Successfully!',
        description: `Component "${componentToSave.name}" has been saved to the SQLite database.`,
        saved_location: 'SQLite Database → component_definitions table',
        view_location: selectedPlacement === 'custom-route' ? customRoute : `/${selectedPlacement}`,
        action_button: {
          label: `View in ${selectedPlacement}`,
          route: selectedPlacement === 'custom-route' ? customRoute || '/' : `/${selectedPlacement}`
        }
      };

      setSuccessMessage(message);
      setShowSuccessDialog(true);

    } catch (error) {
      console.error('Failed to save component to database:', error);
      toast({
        title: "Save Error",
        description: `Failed to save component: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const loadComponent = (component: CustomComponent) => {
    setCurrentComponent(component);
    setPreviewMode(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Component Builder</h3>
          <p className="text-sm text-muted-foreground">Create reusable UI components</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setPreviewMode(!previewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Edit' : 'Preview'}
          </Button>
          <Button onClick={saveComponent} disabled={isLoading}>
            {isLoading ? 'Saving...' : 'Save Component'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList>
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="components">Saved Components ({savedComponents.length})</TabsTrigger>
          <TabsTrigger value="code">Generated Code</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-4">
          {!previewMode ? (
            <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Component Settings */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Component Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="component-name">Component Name</Label>
                      <Input
                        id="component-name"
                        value={currentComponent.name}
                        onChange={(e) => setCurrentComponent(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter component name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="component-description">Description</Label>
                      <Textarea
                        id="component-description"
                        value={currentComponent.description}
                        onChange={(e) => setCurrentComponent(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Component description"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label>Component Type</Label>
                      <Select
                        value={currentComponent.componentType}
                        onValueChange={(value) => setCurrentComponent(prev => ({ ...prev, componentType: value as CustomComponent['componentType'] }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {componentTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input
                        id="category"
                        value={currentComponent.category}
                        onChange={(e) => setCurrentComponent(prev => ({ ...prev, category: e.target.value }))}
                        placeholder="e.g., forms, navigation, layout"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={currentComponent.isReusable}
                        onCheckedChange={(checked) => setCurrentComponent(prev => ({ ...prev, isReusable: checked }))}
                      />
                      <Label>Reusable Component</Label>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Style Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="className">CSS Classes</Label>
                      <Input
                        id="className"
                        value={currentComponent.styleConfig.className || ''}
                        onChange={(e) => setCurrentComponent(prev => ({ 
                          ...prev, 
                          styleConfig: { ...prev.styleConfig, className: e.target.value }
                        }))}
                        placeholder="e.g., bg-primary text-white p-4"
                      />
                    </div>
                    <div>
                      <Label htmlFor="customCSS">Custom CSS</Label>
                      <Textarea
                        id="customCSS"
                        value={currentComponent.styleConfig.customCSS || ''}
                        onChange={(e) => setCurrentComponent(prev => ({ 
                          ...prev, 
                          styleConfig: { ...prev.styleConfig, customCSS: e.target.value }
                        }))}
                        placeholder="/* Custom CSS styles */"
                        rows={4}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Template Code & Props */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Template Code</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={currentComponent.templateCode}
                      onChange={(e) => setCurrentComponent(prev => ({ ...prev, templateCode: e.target.value }))}
                      placeholder="Enter JSX template code here..."
                      rows={10}
                      className="font-mono text-sm"
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-base">Props</CardTitle>
                    <Button size="sm" onClick={addProp}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Prop
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-4 max-h-64 overflow-y-auto">
                    {currentComponent.props.map((prop, index) => (
                      <div key={prop.id} className="p-3 border rounded-lg space-y-3">
                        <div className="flex items-center justify-between">
                          <Badge variant="outline">Prop {index + 1}</Badge>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeProp(prop.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label>Name</Label>
                            <Input
                              value={prop.name}
                              onChange={(e) => updateProp(prop.id, { name: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>Type</Label>
                            <Select
                              value={prop.type}
                              onValueChange={(value) => updateProp(prop.id, { type: value as ComponentProp['type'] })}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {propTypes.map(type => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div>
                          <Label>Description</Label>
                          <Input
                            value={prop.description || ''}
                            onChange={(e) => updateProp(prop.id, { description: e.target.value })}
                            placeholder="Prop description"
                          />
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={prop.required}
                            onCheckedChange={(checked) => updateProp(prop.id, { required: checked })}
                          />
                          <Label>Required</Label>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
            
            {/* Placement Selector */}
            <PlacementSelector
              selectedPlacement={selectedPlacement}
              onPlacementChange={setSelectedPlacement}
              moduleId={moduleId}
              onModuleIdChange={setModuleId}
              customRoute={customRoute}
              onCustomRouteChange={setCustomRoute}
            />
            </>
          ) : (
            /* Preview Mode */
            <Card>
              <CardHeader>
                <CardTitle>{currentComponent.name || 'Untitled Component'}</CardTitle>
                {currentComponent.description && (
                  <p className="text-sm text-muted-foreground">{currentComponent.description}</p>
                )}
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 bg-muted/50">
                  <p className="text-sm text-muted-foreground mb-4">Component Preview:</p>
                  <div 
                    className={currentComponent.styleConfig.className || 'p-4 border rounded'}
                    dangerouslySetInnerHTML={{ __html: currentComponent.templateCode || '<p>No template code provided</p>' }}
                  />
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="components">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedComponents.map(component => (
              <Card key={component.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{component.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{component.componentType}</Badge>
                    <Badge variant="outline">{component.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">{component.description}</p>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => loadComponent(component)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Deploy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                <CardTitle>Generated React Component</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
                {generateComponentCode()}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <SuccessMessageDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
        message={successMessage}
      />
    </div>
  );
}