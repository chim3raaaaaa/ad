// Role Management Interface
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Plus, Edit, Trash2, Shield, Users, Settings, AlertTriangle } from 'lucide-react';
import { usePermissions } from '@/services/rbac/guards';
import { PERMISSIONS, SYSTEM_ROLES, getAllPermissions, getPermissionCategories, type Role, type Permission, type PermissionCategory } from '@/services/rbac/permissions';
import { useToast } from '@/hooks/use-toast';

export function RoleManagement() {
  const [roles, setRoles] = useState<Role[]>(SYSTEM_ROLES);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { guard, canManageRoles, canManageSystem } = usePermissions();
  const { toast } = useToast();

  // Check permissions
  if (!canManageRoles() && !canManageSystem()) {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          You don't have permission to manage roles. Please contact an administrator.
        </AlertDescription>
      </Alert>
    );
  }

  const handleCreateRole = (roleData: Omit<Role, 'id' | 'created_at' | 'updated_at'>) => {
    const newRole: Role = {
      ...roleData,
      id: `role_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setRoles([...roles, newRole]);
    setIsCreateDialogOpen(false);
    toast({
      title: 'Role Created',
      description: `Role "${newRole.displayName}" has been created successfully.`
    });
  };

  const handleEditRole = (roleData: Partial<Role>) => {
    if (!selectedRole) return;

    const updatedRole = {
      ...selectedRole,
      ...roleData,
      updated_at: new Date().toISOString()
    };

    setRoles(roles.map(role => role.id === selectedRole.id ? updatedRole : role));
    setIsEditDialogOpen(false);
    setSelectedRole(null);
    toast({
      title: 'Role Updated',
      description: `Role "${updatedRole.displayName}" has been updated successfully.`
    });
  };

  const handleDeleteRole = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    if (!role) return;

    if (role.isSystemRole) {
      toast({
        title: 'Cannot Delete System Role',
        description: 'System roles cannot be deleted.',
        variant: 'destructive'
      });
      return;
    }

    setRoles(roles.filter(r => r.id !== roleId));
    toast({
      title: 'Role Deleted',
      description: `Role "${role.displayName}" has been deleted.`
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Role Management</h2>
          <p className="text-muted-foreground">
            Manage user roles and permissions for the laboratory management system.
          </p>
        </div>
        {canManageSystem() && (
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Role
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Role</DialogTitle>
                <DialogDescription>
                  Define a new role with specific permissions for users.
                </DialogDescription>
              </DialogHeader>
              <RoleForm onSubmit={handleCreateRole} onCancel={() => setIsCreateDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {roles.map((role) => (
          <RoleCard
            key={role.id}
            role={role}
            onEdit={() => {
              setSelectedRole(role);
              setIsEditDialogOpen(true);
            }}
            onDelete={() => handleDeleteRole(role.id)}
            canEdit={canManageSystem() || (!role.isSystemRole && canManageRoles())}
            canDelete={canManageSystem() && !role.isSystemRole}
          />
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Role: {selectedRole?.displayName}</DialogTitle>
            <DialogDescription>
              Modify the role permissions and settings.
            </DialogDescription>
          </DialogHeader>
          {selectedRole && (
            <RoleForm
              role={selectedRole}
              onSubmit={handleEditRole}
              onCancel={() => {
                setIsEditDialogOpen(false);
                setSelectedRole(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface RoleCardProps {
  role: Role;
  onEdit: () => void;
  onDelete: () => void;
  canEdit: boolean;
  canDelete: boolean;
}

function RoleCard({ role, onEdit, onDelete, canEdit, canDelete }: RoleCardProps) {
  const permissionCount = role.permissions.length;
  const hasFullAccess = role.permissions.includes('system.full_access');

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-muted-foreground" />
            <CardTitle className="text-lg">{role.displayName}</CardTitle>
          </div>
          {role.isSystemRole && (
            <Badge variant="secondary">System</Badge>
          )}
        </div>
        <CardDescription>{role.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground">Permissions</p>
            <p className="text-lg font-semibold">
              {hasFullAccess ? 'Full Access' : `${permissionCount} permissions`}
            </p>
          </div>

          <div className="flex gap-2">
            {canEdit && (
              <Button variant="outline" size="sm" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
            )}
            {canDelete && (
              <Button variant="outline" size="sm" onClick={onDelete}>
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface RoleFormProps {
  role?: Role;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

function RoleForm({ role, onSubmit, onCancel }: RoleFormProps) {
  const [formData, setFormData] = useState({
    name: role?.name || '',
    displayName: role?.displayName || '',
    description: role?.description || '',
    permissions: role?.permissions || []
  });

  const allPermissions = getAllPermissions();
  const categories = getPermissionCategories();

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        permissions: [...prev.permissions, permissionId]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        permissions: prev.permissions.filter(p => p !== permissionId)
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.displayName) {
      return;
    }

    onSubmit({
      ...formData,
      isSystemRole: false
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-4">
        <div>
          <Label htmlFor="name">Role Name (ID)</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="e.g., custom_role"
            disabled={role?.isSystemRole}
            required
          />
        </div>

        <div>
          <Label htmlFor="displayName">Display Name</Label>
          <Input
            id="displayName"
            value={formData.displayName}
            onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
            placeholder="e.g., Custom Role"
            required
          />
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Describe what this role can do..."
            rows={3}
          />
        </div>
      </div>

      <div>
        <Label>Permissions</Label>
        <ScrollArea className="h-96 w-full border rounded-md p-4">
          <Tabs defaultValue={categories[0]} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              {categories.slice(0, 3).map((category) => (
                <TabsTrigger key={category} value={category} className="text-xs">
                  {category.replace('_', ' ')}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsList className="grid w-full grid-cols-4 mt-2">
              {categories.slice(3).map((category) => (
                <TabsTrigger key={category} value={category} className="text-xs">
                  {category.replace('_', ' ')}
                </TabsTrigger>
              ))}
            </TabsList>

            {categories.map((category) => (
              <TabsContent key={category} value={category} className="space-y-4">
                <h4 className="font-medium text-sm">
                  {category.replace('_', ' ').toUpperCase()}
                </h4>
                <div className="space-y-3">
                  {allPermissions
                    .filter(permission => permission.category === category)
                    .map((permission) => (
                      <div key={permission.id} className="flex items-start space-x-3">
                        <Checkbox
                          id={permission.id}
                          checked={formData.permissions.includes(permission.id)}
                          onCheckedChange={(checked) => 
                            handlePermissionChange(permission.id, checked as boolean)
                          }
                        />
                        <div className="grid gap-1.5 leading-none">
                          <Label
                            htmlFor={permission.id}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {permission.name}
                          </Label>
                          <p className="text-xs text-muted-foreground">
                            {permission.description}
                          </p>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </ScrollArea>
        <p className="text-sm text-muted-foreground mt-2">
          Selected: {formData.permissions.length} permissions
        </p>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {role ? 'Update Role' : 'Create Role'}
        </Button>
      </div>
    </form>
  );
}