import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BarChart, 
  LineChart, 
  PieChart, 
  Activity, 
  Calendar, 
  Filter, 
  Palette, 
  Settings,
  Eye,
  Database,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChartDefinition, ChartConfig } from "@/services/reporting/enhancedAnalyticsIntegration";

interface ChartConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (chartConfig: ConfiguredChart) => void;
  chartDefinition?: ChartDefinition | null;
  initialConfig?: Partial<ConfiguredChart>;
}

export interface ConfiguredChart {
  id: string;
  name: string;
  description: string;
  type: string;
  dataSource: string;
  config: ChartConfig;
  timeRange: string;
  filters: Record<string, any>;
  styling: {
    colors: string[];
    showGrid: boolean;
    showLegend: boolean;
    showTrendline: boolean;
  };
  isCustom: boolean;
}

export const ChartConfigurationModal: React.FC<ChartConfigurationModalProps> = ({
  isOpen,
  onClose,
  onSave,
  chartDefinition,
  initialConfig
}) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ConfiguredChart>({
    id: '',
    name: '',
    description: '',
    type: 'bar',
    dataSource: 'test_results',
    config: {
      chartType: 'bar',
      xAxis: 'date',
      yAxis: 'value',
      aggregation: 'count'
    },
    timeRange: '6months',
    filters: {},
    styling: {
      colors: ['#8884d8', '#82ca9d', '#ffc658', '#ff7300'],
      showGrid: true,
      showLegend: true,
      showTrendline: false
    },
    isCustom: false
  });

  const [previewData, setPreviewData] = useState<any[]>([]);
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);

  // Initialize form data when modal opens
  useEffect(() => {
    if (isOpen) {
      if (chartDefinition) {
        setFormData({
          id: chartDefinition.id,
          name: chartDefinition.name,
          description: chartDefinition.description,
          type: chartDefinition.type,
          dataSource: chartDefinition.dataSource,
          config: chartDefinition.config,
          timeRange: '6months',
          filters: {},
          styling: {
            colors: chartDefinition.config.styling?.colors || ['#8884d8', '#82ca9d', '#ffc658'],
            showGrid: chartDefinition.config.styling?.showGrid ?? true,
            showLegend: chartDefinition.config.styling?.showLegend ?? true,
            showTrendline: chartDefinition.config.styling?.showTrendline ?? false
          },
          isCustom: false
        });
      } else if (initialConfig) {
        setFormData(prev => ({ ...prev, ...initialConfig }));
      }
    }
  }, [isOpen, chartDefinition, initialConfig]);

  const updateFormData = (field: keyof ConfiguredChart, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateConfig = (field: keyof ChartConfig, value: any) => {
    setFormData(prev => ({
      ...prev,
      config: { ...prev.config, [field]: value }
    }));
  };

  const updateStyling = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      styling: { ...prev.styling, [field]: value }
    }));
  };

  const updateFilters = (key: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      filters: { ...prev.filters, [key]: value }
    }));
  };

  const generatePreview = async () => {
    setIsGeneratingPreview(true);
    try {
      // Generate mock preview data based on chart type
      let mockData: any[] = [];
      
      switch (formData.config.chartType) {
        case 'bar':
        case 'line':
          mockData = [
            { date: '2024-01', value: 45 },
            { date: '2024-02', value: 52 },
            { date: '2024-03', value: 38 },
            { date: '2024-04', value: 67 },
            { date: '2024-05', value: 71 },
            { date: '2024-06', value: 58 }
          ];
          break;
        case 'pie':
          mockData = [
            { category: 'Passed', value: 65 },
            { category: 'Failed', value: 23 },
            { category: 'Pending', value: 12 }
          ];
          break;
        case 'gauge':
          mockData = [{ current: 78, target: 85, label: 'Efficiency' }];
          break;
        default:
          mockData = [];
      }
      
      setPreviewData(mockData);
      
      toast({
        title: "Preview Generated",
        description: "Chart preview updated with sample data"
      });
    } catch (error) {
      console.error('Error generating preview:', error);
      toast({
        title: "Preview Error",
        description: "Failed to generate chart preview",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingPreview(false);
    }
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a chart name",
        variant: "destructive"
      });
      return;
    }

    const chartConfig: ConfiguredChart = {
      ...formData,
      id: formData.id || `chart_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    onSave(chartConfig);
    onClose();
    
    toast({
      title: "Chart Configured",
      description: `Chart "${chartConfig.name}" has been configured successfully`
    });
  };

  const chartTypeOptions = [
    { value: 'bar', label: 'Bar Chart', icon: <BarChart size={16} /> },
    { value: 'line', label: 'Line Chart', icon: <LineChart size={16} /> },
    { value: 'pie', label: 'Pie Chart', icon: <PieChart size={16} /> },
    { value: 'gauge', label: 'Gauge Chart', icon: <Activity size={16} /> }
  ];

  const dataSourceOptions = [
    { value: 'test_results', label: 'Test Results', description: 'Laboratory test data' },
    { value: 'memos', label: 'Memos', description: 'Memo creation and status data' },
    { value: 'production_data', label: 'Production Data', description: 'Production and manufacturing data' },
    { value: 'conformity', label: 'Conformity Tests', description: 'Pass/fail conformity data' }
  ];

  const timeRangeOptions = [
    { value: '1week', label: 'Last Week' },
    { value: '1month', label: 'Last Month' },
    { value: '3months', label: 'Last 3 Months' },
    { value: '6months', label: 'Last 6 Months' },
    { value: '1year', label: 'Last Year' },
    { value: 'all', label: 'All Time' }
  ];

  const aggregationOptions = [
    { value: 'count', label: 'Count' },
    { value: 'sum', label: 'Sum' },
    { value: 'avg', label: 'Average' },
    { value: 'max', label: 'Maximum' },
    { value: 'min', label: 'Minimum' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Configure Chart
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic" className="flex-1 overflow-hidden">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="data">Data</TabsTrigger>
            <TabsTrigger value="styling">Styling</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[500px] mt-4">
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="chart-name">Chart Name</Label>
                  <Input
                    id="chart-name"
                    value={formData.name}
                    onChange={(e) => updateFormData('name', e.target.value)}
                    placeholder="Enter chart name..."
                  />
                </div>
                
                <div>
                  <Label htmlFor="chart-type">Chart Type</Label>
                  <Select
                    value={formData.config.chartType}
                    onValueChange={(value) => updateConfig('chartType', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {chartTypeOptions.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            {option.icon}
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => updateFormData('description', e.target.value)}
                  placeholder="Enter chart description..."
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="time-range">Time Range</Label>
                <Select
                  value={formData.timeRange}
                  onValueChange={(value) => updateFormData('timeRange', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {timeRangeOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            <TabsContent value="data" className="space-y-4">
              <div>
                <Label>Data Source</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                  {dataSourceOptions.map(option => (
                    <Card
                      key={option.value}
                      className={`cursor-pointer transition-colors ${
                        formData.dataSource === option.value
                          ? 'ring-2 ring-primary bg-accent'
                          : 'hover:bg-accent'
                      }`}
                      onClick={() => updateFormData('dataSource', option.value)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center gap-2">
                          <Database className="h-4 w-4" />
                          <div>
                            <p className="font-medium text-sm">{option.label}</p>
                            <p className="text-xs text-muted-foreground">{option.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="x-axis">X-Axis Field</Label>
                  <Input
                    id="x-axis"
                    value={formData.config.xAxis || ''}
                    onChange={(e) => updateConfig('xAxis', e.target.value)}
                    placeholder="e.g., date, test_type"
                  />
                </div>
                
                <div>
                  <Label htmlFor="y-axis">Y-Axis Field</Label>
                  <Input
                    id="y-axis"
                    value={formData.config.yAxis || ''}
                    onChange={(e) => updateConfig('yAxis', e.target.value)}
                    placeholder="e.g., value, count"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="aggregation">Aggregation Method</Label>
                <Select
                  value={formData.config.aggregation}
                  onValueChange={(value) => updateConfig('aggregation', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {aggregationOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Filters</Label>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Product Type"
                      value={formData.filters.product_type || ''}
                      onChange={(e) => updateFilters('product_type', e.target.value)}
                    />
                    <Input
                      placeholder="Plant"
                      value={formData.filters.plant || ''}
                      onChange={(e) => updateFilters('plant', e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Officer"
                      value={formData.filters.officer || ''}
                      onChange={(e) => updateFilters('officer', e.target.value)}
                    />
                    <Input
                      placeholder="Status"
                      value={formData.filters.status || ''}
                      onChange={(e) => updateFilters('status', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="styling" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-grid">Show Grid</Label>
                  <Switch
                    id="show-grid"
                    checked={formData.styling.showGrid}
                    onCheckedChange={(checked) => updateStyling('showGrid', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-legend">Show Legend</Label>
                  <Switch
                    id="show-legend"
                    checked={formData.styling.showLegend}
                    onCheckedChange={(checked) => updateStyling('showLegend', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-trendline">Show Trendline</Label>
                  <Switch
                    id="show-trendline"
                    checked={formData.styling.showTrendline}
                    onCheckedChange={(checked) => updateStyling('showTrendline', checked)}
                  />
                </div>
              </div>

              <div>
                <Label>Color Palette</Label>
                <div className="flex gap-2 mt-2">
                  {formData.styling.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-8 h-8 rounded border-2 border-muted"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Color customization coming soon
                </p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Palette className="h-4 w-4" />
                    Theme Preview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Grid: {formData.styling.showGrid ? 'On' : 'Off'}</Badge>
                      <Badge variant="outline">Legend: {formData.styling.showLegend ? 'On' : 'Off'}</Badge>
                      <Badge variant="outline">Trendline: {formData.styling.showTrendline ? 'On' : 'Off'}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preview" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Chart Preview</h3>
                <Button onClick={generatePreview} disabled={isGeneratingPreview}>
                  <Eye className="h-4 w-4 mr-2" />
                  {isGeneratingPreview ? 'Generating...' : 'Generate Preview'}
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">{formData.name || 'Untitled Chart'}</CardTitle>
                  <p className="text-xs text-muted-foreground">{formData.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center border border-dashed border-muted-foreground/25 rounded">
                    {previewData.length > 0 ? (
                      <div className="text-center">
                        <TrendingUp className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          Preview: {formData.config.chartType} chart with {previewData.length} data points
                        </p>
                        <Badge variant="outline" className="mt-2">
                          {formData.dataSource} • {formData.timeRange}
                        </Badge>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Activity className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          Click "Generate Preview" to see chart preview
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Configuration Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs space-y-1">
                    <p><strong>Type:</strong> {formData.config.chartType}</p>
                    <p><strong>Data Source:</strong> {formData.dataSource}</p>
                    <p><strong>Time Range:</strong> {formData.timeRange}</p>
                    <p><strong>Aggregation:</strong> {formData.config.aggregation}</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Active Filters</CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs">
                    {Object.keys(formData.filters).length > 0 ? (
                      <div className="space-y-1">
                        {Object.entries(formData.filters).map(([key, value]) => (
                          value && <p key={key}><strong>{key}:</strong> {value}</p>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground">No filters applied</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Chart Configuration
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};