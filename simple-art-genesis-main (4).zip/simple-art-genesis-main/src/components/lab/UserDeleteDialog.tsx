import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, User } from "lucide-react";

interface UserDeleteDialogProps {
  user: any;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  currentUserRole: string;
}

export function UserDeleteDialog({ user, isOpen, onClose, onConfirm, currentUserRole }: UserDeleteDialogProps) {
  const canDeleteUser = () => {
    if (currentUserRole === "admin") return true;
    if (currentUserRole === "lab_manager" && user?.role !== "Admin") return true;
    return false;
  };

  const getDeletionWarning = () => {
    if (!canDeleteUser()) {
      return "You don't have permission to delete this user.";
    }
    
    if (user?.role === "Admin") {
      return "WARNING: You are about to delete an administrator account. This action cannot be undone and may affect system access.";
    }
    
    return "This action cannot be undone. All user data and associated records will be permanently removed.";
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Delete User Account
          </AlertDialogTitle>
          <AlertDialogDescription>
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <User className="h-5 w-5" />
                <div>
                  <p className="font-medium">{user?.name}</p>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                  <Badge variant="outline" className="mt-1">
                    {user?.role}
                  </Badge>
                </div>
              </div>
              
              <p className="text-sm">
                {getDeletionWarning()}
              </p>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={onConfirm}
            disabled={!canDeleteUser()}
            className="bg-destructive hover:bg-destructive/90"
          >
            Delete User
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}