import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  FileText, 
  Download, 
  Send, 
  Eye, 
  Save,
  X,
  Plus,
  Edit,
  Upload,
  Trash2,
  Type,
  Image,
  Table,
  PieChart,
  BarChart,
  LineChart,
  FileSpreadsheet,
  Hash,
  Calendar as CalendarIcon,
  MapPin,
  TestTube,
  Beaker,
  Target,
  TrendingUp,
  Activity,
  Database,
  Paperclip,
  Building,
  User,
  GripVertical,
  Copy,
  Search,
  Filter,
  RefreshCw,
  AlertTriangle,
  Package2,
  Layers,
  Settings,
  Palette,
  FileCheck
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { PDFGenerator } from "@/lib/pdfGenerator";
import { enhancedMemoService, EnhancedMemoData } from "@/services/database/enhancedMemoService";
import { memoTestService, MemoTestAssignment } from "@/services/database/memoTestService";
import { DataBindingService } from "@/services/reporting/dataBindingService";

interface ReportGenerationWizardProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledMemoId?: string;
}

interface ReportBlock {
  id: string;
  type: 'field' | 'chart' | 'text' | 'image' | 'table' | 'header' | 'footer';
  label: string;
  fieldKey?: string;
  dataSource?: 'memo' | 'test' | 'analytics' | 'static';
  position: { x: number; y: number };
  size: { width: number; height: number };
  properties: Record<string, any>;
}

interface ReportTemplate {
  id: string;
  name: string;
  description: string;
  product_type: string;
  layout_json: string;
  uploaded_by: string;
  uploaded_at: string;
  file_path?: string;
  blocks: ReportBlock[];
}

interface BlockCategory {
  name: string;
  icon: React.ReactNode;
  blocks: {
    type: string;
    label: string;
    icon: React.ReactNode;
    defaultSize: { width: number; height: number };
    properties: Record<string, any>;
  }[];
}

export function ReportGenerationWizard({ isOpen, onClose, prefilledMemoId }: ReportGenerationWizardProps) {
  const { toast } = useToast();
  const { user } = useUser();
  
  
  // Core states
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedMemo, setSelectedMemo] = useState<any>(null);
  const [availableMemos, setAvailableMemos] = useState<EnhancedMemoData[]>([]);
  const [memoData, setMemoData] = useState<any>({});
  const [currentTemplate, setCurrentTemplate] = useState<ReportTemplate | null>(null);
  const [savedTemplates, setSavedTemplates] = useState<ReportTemplate[]>([]);
  const [templateBlocks, setTemplateBlocks] = useState<ReportBlock[]>([]);
  const [selectedBlock, setSelectedBlock] = useState<ReportBlock | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [draggedBlockType, setDraggedBlockType] = useState<string | null>(null);
  
  // UI states
  const [activeTab, setActiveTab] = useState<'blocks' | 'templates'>('blocks');
  const [isGenerating, setIsGenerating] = useState(false);
  const [templateSearch, setTemplateSearch] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  // Initialize services
  const dataBindingService = new DataBindingService();

  // Initialize database tables for the report system
  const initializeReportDatabase = useCallback(async () => {
    if (!window.electronAPI) return;

    try {
      // Create ReportTemplates table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS report_templates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          product_type TEXT,
          layout_json TEXT,
          uploaded_by TEXT,
          uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
          file_path TEXT
        )
      `);

      // Create TemplateBlocks table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS template_blocks (
          id TEXT PRIMARY KEY,
          template_id TEXT,
          block_type TEXT,
          label TEXT,
          field_key TEXT,
          data_source TEXT,
          position_x INTEGER,
          position_y INTEGER,
          width INTEGER,
          height INTEGER,
          properties TEXT,
          FOREIGN KEY (template_id) REFERENCES report_templates(id)
        )
      `);

      // Create ReportAudit table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS report_audit (
          id TEXT PRIMARY KEY,
          template_id TEXT,
          memo_ref TEXT,
          generated_by TEXT,
          generated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          report_path TEXT
        )
      `);

      // Insert default templates if none exist
      const existingTemplates = await window.electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM report_templates'
      );

      if (existingTemplates.success && existingTemplates.data[0].count === 0) {
        await insertDefaultTemplates();
      }

    } catch (error) {
      console.error('Failed to initialize report database:', error);
    }
  }, []);

  const insertDefaultTemplates = async () => {
    const defaultTemplates = [
      {
        id: 'aggregates_standard',
        name: 'Aggregates Standard Report',
        description: 'Standard template for aggregate test reports',
        product_type: 'aggregates',
        layout_json: JSON.stringify({
          title: 'Aggregate Test Report',
          sections: ['header', 'test_results', 'sieve_analysis', 'footer']
        }),
        uploaded_by: 'System'
      },
      {
        id: 'concrete_compressive',
        name: 'Concrete Compressive Strength',
        description: 'Template for concrete compressive strength reports',
        product_type: 'concrete',
        layout_json: JSON.stringify({
          title: 'Compressive Strength Test Report',
          sections: ['header', 'specimen_details', 'strength_results', 'footer']
        }),
        uploaded_by: 'System'
      },
      {
        id: 'blocks_general',
        name: 'Blocks General Report',
        description: 'General template for block test reports',
        product_type: 'blocks',
        layout_json: JSON.stringify({
          title: 'Block Test Report',
          sections: ['header', 'specifications', 'test_data', 'footer']
        }),
        uploaded_by: 'System'
      }
    ];

    for (const template of defaultTemplates) {
      try {
        await window.electronAPI.dbQuery(
          'INSERT INTO report_templates (id, name, description, product_type, layout_json, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)',
          [template.id, template.name, template.description, template.product_type, template.layout_json, template.uploaded_by]
        );
      } catch (error) {
        console.error('Failed to insert default template:', template.name, error);
      }
    }
  };

  // Load data on component mount
  useEffect(() => {
    if (isOpen) {
      initializeData();
    }
  }, [isOpen]);

  const initializeData = useCallback(async () => {
    try {
      await initializeReportDatabase();
      
      // Load completed memos from enhanced memo service
      if (selectedCategory) {
        const completedMemos = await enhancedMemoService.searchMemos({
          status: 'Completed',
          category: selectedCategory
        });
        setAvailableMemos(completedMemos);
      } else {
        // Load all completed memos initially
        const allCompletedMemos = await enhancedMemoService.searchMemos({
          status: 'Completed'
        });
        setAvailableMemos(allCompletedMemos);
      }
      
      // Set prefilled memo if provided
      if (prefilledMemoId && availableMemos.length > 0) {
        const prefilledMemo = availableMemos.find((m: any) => m.id === prefilledMemoId);
        if (prefilledMemo) {
          setSelectedMemo(prefilledMemo);
          await fetchMemoTestData(prefilledMemo.memo_ref);
        }
      }

      // Load saved templates
      if (window.electronAPI) {
        const templatesResult = await window.electronAPI.dbQuery(
          'SELECT * FROM report_templates ORDER BY uploaded_at DESC'
        );
        if (templatesResult.success) {
          setSavedTemplates(templatesResult.data || []);
        }
      }
      
    } catch (error) {
      console.error('Failed to initialize report data:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to load report data",
        variant: "destructive"
      });
    }
  }, [selectedCategory, prefilledMemoId, initializeReportDatabase, toast]);

  // Fetch completed memos when category changes
  const fetchCompletedMemos = useCallback(async (categoryId: string) => {
    try {
      const completedMemos = await enhancedMemoService.searchMemos({
        status: 'Completed',
        category: categoryId
      });
      setAvailableMemos(completedMemos);
    } catch (error) {
      console.error('Failed to fetch completed memos:', error);
      toast({
        title: "Error",
        description: "Failed to load completed memos",
        variant: "destructive"
      });
    }
  }, [toast]);

  // Fetch memo test data when memo is selected
  const fetchMemoTestData = useCallback(async (memoRef: string) => {
    try {
      // Get test assignments for the memo
      const testAssignments = await memoTestService.getMemoTestAssignments(memoRef);
      const completedTests = testAssignments.filter(test => test.status === 'completed');
      
      // Combine all test results
      const combinedResults = completedTests.reduce((acc, test) => ({
        ...acc,
        ...test.test_results
      }), {});

      // Add memo-specific fields
      const selectedMemoData = availableMemos.find(m => m.memo_ref === memoRef);
      if (selectedMemoData) {
        (combinedResults as any).memo_ref = selectedMemoData.memo_ref;
        (combinedResults as any).plant = selectedMemoData.plant;
        (combinedResults as any).officer = selectedMemoData.officer;
        (combinedResults as any).category = selectedMemoData.category;
        (combinedResults as any).product_type = selectedMemoData.product_type;
        (combinedResults as any).date_created = selectedMemoData.date_created;
        (combinedResults as any).date_completed = selectedMemoData.date_completed;
      }

      setMemoData(combinedResults);
      
      toast({
        title: "Memo Data Loaded",
        description: `Test data loaded for memo ${memoRef}`
      });
    } catch (error) {
      console.error('Failed to fetch memo test data:', error);
      toast({
        title: "Error",
        description: "Failed to load memo test data",
        variant: "destructive"
      });
    }
  }, [availableMemos, toast]);

  // Effect to fetch memos when category changes
  useEffect(() => {
    if (selectedCategory) {
      fetchCompletedMemos(selectedCategory);
    }
  }, [selectedCategory, fetchCompletedMemos]);

  // Effect to fetch memo data when memo is selected
  useEffect(() => {
    if (selectedMemo?.memo_ref) {
      fetchMemoTestData(selectedMemo.memo_ref);
    }
  }, [selectedMemo, fetchMemoTestData]);

  // Block categories with product-specific fields
  const getBlockCategories = useCallback((): BlockCategory[] => {
    const productType = selectedMemo?.product_type || 'general';
    
    return [
      {
        name: 'Product-Specific Fields',
        icon: <Package2 className="h-4 w-4" />,
        blocks: getProductSpecificBlocks(productType)
      },
      {
        name: 'Static Elements',
        icon: <Type className="h-4 w-4" />,
        blocks: [
          { type: 'header', label: 'Header', icon: <FileText className="h-4 w-4" />, defaultSize: { width: 400, height: 60 }, properties: { text: 'Report Header', fontSize: 20, bold: true } },
          { type: 'footer', label: 'Footer', icon: <FileText className="h-4 w-4" />, defaultSize: { width: 400, height: 40 }, properties: { text: 'Report Footer', fontSize: 12 } },
          { type: 'text', label: 'Text Block', icon: <Type className="h-4 w-4" />, defaultSize: { width: 300, height: 100 }, properties: { text: 'Custom text content', fontSize: 14 } },
          { type: 'image', label: 'Logo/Image', icon: <Image className="h-4 w-4" />, defaultSize: { width: 150, height: 150 }, properties: { src: '', alt: 'Company Logo' } },
          { type: 'field', label: 'Date Stamp', icon: <CalendarIcon className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'current_date', label: 'Date' } }
        ]
      },
      {
        name: 'Charts from Analytics',
        icon: <BarChart className="h-4 w-4" />,
        blocks: [
          { type: 'chart', label: 'Sieve Analysis', icon: <BarChart className="h-4 w-4" />, defaultSize: { width: 400, height: 300 }, properties: { chartType: 'sieve_analysis', dataSource: 'analytics' } },
          { type: 'chart', label: 'Strength over Time', icon: <LineChart className="h-4 w-4" />, defaultSize: { width: 400, height: 300 }, properties: { chartType: 'strength_trend', dataSource: 'analytics' } },
          { type: 'chart', label: 'FM Trend', icon: <TrendingUp className="h-4 w-4" />, defaultSize: { width: 400, height: 300 }, properties: { chartType: 'fm_trend', dataSource: 'analytics' } },
          { type: 'chart', label: 'Conformity Rate', icon: <PieChart className="h-4 w-4" />, defaultSize: { width: 300, height: 300 }, properties: { chartType: 'conformity_pie', dataSource: 'analytics' } }
        ]
      },
      {
        name: 'Attachments',
        icon: <Paperclip className="h-4 w-4" />,
        blocks: [
          { type: 'table', label: 'Test Results Table', icon: <Table className="h-4 w-4" />, defaultSize: { width: 500, height: 200 }, properties: { dataSource: 'test_results', columns: ['parameter', 'value', 'unit', 'limit'] } },
          { type: 'field', label: 'Certificate Upload', icon: <FileCheck className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'certificate_file', type: 'file' } },
          { type: 'field', label: 'Lab Photos', icon: <Image className="h-4 w-4" />, defaultSize: { width: 200, height: 200 }, properties: { fieldKey: 'lab_photos', type: 'image_gallery' } }
        ]
      }
    ];
  }, [selectedMemo?.product_type]);

  const getProductSpecificBlocks = (productType: string) => {
    const commonFields = [
      { type: 'field', label: 'Memo Reference', icon: <Hash className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'memo_ref', label: 'Memo Ref' } },
      { type: 'field', label: 'Plant/Site', icon: <Building className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'plant', label: 'Plant' } },
      { type: 'field', label: 'Officer', icon: <User className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'officer', label: 'Officer' } },
      { type: 'field', label: 'Test Date', icon: <CalendarIcon className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'test_date', label: 'Test Date' } }
    ];

    switch (productType) {
      case 'aggregates':
        return [
          ...commonFields,
          { type: 'field', label: 'Material Type', icon: <Package2 className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'material_type', label: 'Material' } },
          { type: 'field', label: 'Fineness Modulus', icon: <Hash className="h-4 w-4" />, defaultSize: { width: 150, height: 30 }, properties: { fieldKey: 'fm', label: 'FM' } },
          { type: 'field', label: 'Sand Equivalent', icon: <Target className="h-4 w-4" />, defaultSize: { width: 150, height: 30 }, properties: { fieldKey: 'se', label: 'SE %' } },
          { type: 'table', label: 'Sieve Results', icon: <Table className="h-4 w-4" />, defaultSize: { width: 400, height: 250 }, properties: { dataSource: 'sieve_analysis', fieldKey: 'sieve_results' } }
        ];
      case 'concrete':
      case 'cubes':
        return [
          ...commonFields,
          { type: 'field', label: 'Compressive Strength', icon: <Activity className="h-4 w-4" />, defaultSize: { width: 180, height: 30 }, properties: { fieldKey: 'compressive_strength', label: 'Strength (MPa)' } },
          { type: 'field', label: 'Curing Method', icon: <Beaker className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'curing_method', label: 'Curing' } },
          { type: 'field', label: 'Age (Days)', icon: <CalendarIcon className="h-4 w-4" />, defaultSize: { width: 120, height: 30 }, properties: { fieldKey: 'age_days', label: 'Age' } },
          { type: 'field', label: 'Specimen ID', icon: <TestTube className="h-4 w-4" />, defaultSize: { width: 150, height: 30 }, properties: { fieldKey: 'specimen_id', label: 'Specimen' } }
        ];
      case 'blocks':
      case 'pavers':
        return [
          ...commonFields,
          { type: 'field', label: 'Block Type', icon: <Package2 className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'block_type', label: 'Type' } },
          { type: 'field', label: 'Dimensions', icon: <Target className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'dimensions', label: 'Dimensions' } },
          { type: 'field', label: 'Compressive Strength', icon: <Activity className="h-4 w-4" />, defaultSize: { width: 180, height: 30 }, properties: { fieldKey: 'compressive_strength', label: 'Strength (MPa)' } },
          { type: 'field', label: 'Water Absorption', icon: <Database className="h-4 w-4" />, defaultSize: { width: 180, height: 30 }, properties: { fieldKey: 'water_absorption', label: 'Absorption %' } }
        ];
      case 'flagstone':
        return [
          ...commonFields,
          { type: 'field', label: 'Stone Type', icon: <Package2 className="h-4 w-4" />, defaultSize: { width: 200, height: 30 }, properties: { fieldKey: 'stone_type', label: 'Stone Type' } },
          { type: 'field', label: 'Absorption Rate', icon: <Database className="h-4 w-4" />, defaultSize: { width: 180, height: 30 }, properties: { fieldKey: 'absorption_rate', label: 'Absorption %' } },
          { type: 'field', label: 'Thickness', icon: <Target className="h-4 w-4" />, defaultSize: { width: 150, height: 30 }, properties: { fieldKey: 'thickness', label: 'Thickness (mm)' } }
        ];
      default:
        return commonFields;
    }
  };

  // Drag and drop handlers
  const handleDragStart = (blockType: string) => {
    setDraggedBlockType(blockType);
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setDraggedBlockType(null);
    setIsDragging(false);
  };

  const handleCanvasDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedBlockType) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find the block definition
    const categories = getBlockCategories();
    let blockDef = null;
    for (const category of categories) {
      blockDef = category.blocks.find(b => b.type === draggedBlockType);
      if (blockDef) break;
    }

    if (!blockDef) return;

    const newBlock: ReportBlock = {
      id: `block_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: blockDef.type as any,
      label: blockDef.label,
      fieldKey: blockDef.properties.fieldKey,
      dataSource: blockDef.properties.dataSource || 'memo',
      position: { x, y },
      size: blockDef.defaultSize,
      properties: { ...blockDef.properties }
    };

    setTemplateBlocks(prev => [...prev, newBlock]);
    setSelectedBlock(newBlock);
    handleDragEnd();
  };

  // Template management
  const saveTemplate = async () => {
    if (!currentTemplate?.name || !selectedMemo) {
      toast({
        title: "Save Failed",
        description: "Please provide a template name and select a memo",
        variant: "destructive"
      });
      return;
    }

    try {
      const templateData = {
        id: currentTemplate.id || `template_${Date.now()}`,
        name: currentTemplate.name,
        description: currentTemplate.description || '',
        product_type: selectedMemo.product_type,
        layout_json: JSON.stringify({
          blocks: templateBlocks,
          metadata: {
            created_by: user?.fullName,
            created_at: new Date().toISOString(),
            version: '1.0'
          }
        }),
        uploaded_by: user?.fullName || 'Unknown'
      };

      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT OR REPLACE INTO report_templates 
           (id, name, description, product_type, layout_json, uploaded_by) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [templateData.id, templateData.name, templateData.description, 
           templateData.product_type, templateData.layout_json, templateData.uploaded_by]
        );

        if (result.success) {
          // Save individual blocks
          await window.electronAPI.dbQuery(
            'DELETE FROM template_blocks WHERE template_id = ?',
            [templateData.id]
          );

          for (const block of templateBlocks) {
            await window.electronAPI.dbQuery(
              `INSERT INTO template_blocks 
               (id, template_id, block_type, label, field_key, data_source, 
                position_x, position_y, width, height, properties) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [block.id, templateData.id, block.type, block.label, 
               block.fieldKey, block.dataSource, block.position.x, 
               block.position.y, block.size.width, block.size.height, 
               JSON.stringify(block.properties)]
            );
          }

          setCurrentTemplate(templateData as any);
          setSavedTemplates(prev => {
            const updated = prev.filter(t => t.id !== templateData.id);
            return [...updated, templateData as any];
          });

          toast({
            title: "Template Saved",
            description: `Template "${templateData.name}" saved successfully`
          });
        }
      }
    } catch (error) {
      console.error('Save template error:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save template",
        variant: "destructive"
      });
    }
  };

  const loadTemplate = async (template: ReportTemplate) => {
    try {
      setCurrentTemplate(template);
      
      // Load blocks for this template
      if (window.electronAPI) {
        const blocksResult = await window.electronAPI.dbQuery(
          'SELECT * FROM template_blocks WHERE template_id = ?',
          [template.id]
        );

        if (blocksResult.success && blocksResult.data) {
          const blocks: ReportBlock[] = blocksResult.data.map((row: any) => ({
            id: row.id,
            type: row.block_type,
            label: row.label,
            fieldKey: row.field_key,
            dataSource: row.data_source,
            position: { x: row.position_x, y: row.position_y },
            size: { width: row.width, height: row.height },
            properties: JSON.parse(row.properties || '{}')
          }));
          
          setTemplateBlocks(blocks);
        }
      }

      toast({
        title: "Template Loaded",
        description: `Template "${template.name}" loaded successfully`
      });
    } catch (error) {
      console.error('Load template error:', error);
      toast({
        title: "Load Failed",
        description: "Failed to load template",
        variant: "destructive"
      });
    }
  };

  // Export functionality with full backend integration
  const handleExport = useCallback(async () => {
    if (!selectedMemo || !templateBlocks.length) {
      toast({
        title: "Missing Requirements",
        description: "Please select a memo and create template blocks",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      // Fetch test results for the selected memo
      const testResults = await memoTestService.getMemoTestAssignments(selectedMemo.memo_ref);
      const completedTests = testResults.filter(test => test.status === 'completed');
      
      // Combine all test data
      const combinedTestData = completedTests.reduce((acc, test) => ({
        ...acc,
        ...test.test_results
      }), {});

      // Add memo metadata
      const fullMemoData = {
        ...combinedTestData,
        memo_ref: selectedMemo.memo_ref,
        plant: selectedMemo.plant,
        officer: selectedMemo.officer,
        category: selectedMemo.category,
        product_type: selectedMemo.product_type,
        date_created: selectedMemo.date_created,
        date_completed: selectedMemo.date_completed,
        current_date: new Date().toLocaleDateString(),
        generated_by: user?.fullName || 'Unknown'
      };

      // Create token map for data binding
      const tokenMap = Object.entries(fullMemoData).map(([key, value]) => ({
        token: `{{${key}}}`,
        value: String(value || '')
      }));

      // Bind data to template using DataBindingService
      const reportData = await dataBindingService.bindMemoData(selectedMemo.id);
      
      // Create filled template blocks with bound data
      const filledBlocks = templateBlocks.map(block => {
        if (block.type === 'field' && block.fieldKey) {
          const dataValue = fullMemoData[block.fieldKey];
          return {
            ...block,
            properties: {
              ...block.properties,
              value: dataValue || 'N/A'
            }
          };
        }
        return block;
      });

      // Create template structure
      const template = {
        id: currentTemplate?.id || 'temp_template',
        name: currentTemplate?.name || 'Generated Template',
        description: 'Auto-generated from blocks',
        product_type: selectedMemo.product_type,
        layout_json: JSON.stringify(filledBlocks),
        uploaded_by: user?.fullName || 'Unknown',
        uploaded_at: new Date().toISOString(),
        blocks: filledBlocks
      };

      // Generate PDF using PDFGenerator with correct ReportData format
      const pdfReportData = {
        title: `Test Report - ${selectedMemo.memo_ref}`,
        memoId: selectedMemo.id,
        reference: selectedMemo.memo_ref,
        site: selectedMemo.plant,
        testDate: selectedMemo.date_completed || new Date().toLocaleDateString(),
        technician: user?.fullName || 'Unknown',
        testType: selectedMemo.product_type,
        extractedData: fullMemoData,
        templateData: filledBlocks,
        watermark: 'UBP Internal Use'
      };

      const pdfBlob = await PDFGenerator.generateTestReport(pdfReportData);
      const filename = `Report_${selectedMemo.memo_ref}_${Date.now()}.pdf`;
      
      PDFGenerator.downloadBlob(pdfBlob, filename);

      // Log export in audit table
      if (window.electronAPI) {
        await window.electronAPI.dbQuery(
          'INSERT INTO report_audit (id, template_id, memo_ref, generated_by, report_path) VALUES (?, ?, ?, ?, ?)',
          [
            `audit_${Date.now()}`,
            currentTemplate?.id || 'manual_export',
            selectedMemo.memo_ref,
            user?.fullName || 'Unknown',
            filename
          ]
        );
      }

      toast({
        title: "Export Successful",
        description: `Report exported as ${filename}`,
      });

    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export report. Please check your data and try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  }, [selectedMemo, templateBlocks, memoTestService, dataBindingService, currentTemplate, user, toast]);

  // Report generation for preview
  const generateReport = useCallback(async () => {
    if (!selectedMemo) {
      toast({
        title: "No Memo Selected",
        description: "Please select a memo to generate the report",
        variant: "destructive"
      });
      return;
    }

    await handleExport();
  }, [selectedMemo, handleExport, toast]);

  // Named button handler functions
  const handlePreviewToggle = useCallback(() => {
    if (showPreview) {
      handleExport();
    } else {
      setShowPreview(true);
    }
  }, [showPreview, handleExport]);

  const handleSaveTemplate = useCallback(async () => {
    if (!window.electronAPI) {
      toast({
        title: "Error",
        description: "Database not available",
        variant: "destructive"
      });
      return;
    }

    try {
      const templateData = {
        id: currentTemplate?.id || `template_${Date.now()}`,
        name: currentTemplate?.name || "Untitled Template",
        description: currentTemplate?.description || "",
        product_type: selectedMemo?.product_type || selectedCategory || 'general',
        layout_json: JSON.stringify(templateBlocks),
        uploaded_by: user?.fullName || "Unknown",
        uploaded_at: new Date().toISOString(),
      };

      await window.electronAPI.dbQuery(
        'INSERT OR REPLACE INTO report_templates (id, name, description, product_type, layout_json, uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [templateData.id, templateData.name, templateData.description, templateData.product_type, templateData.layout_json, templateData.uploaded_by, templateData.uploaded_at]
      );

      // Save template blocks
      await window.electronAPI.dbQuery(
        'DELETE FROM template_blocks WHERE template_id = ?',
        [templateData.id]
      );

      for (const block of templateBlocks) {
        await window.electronAPI.dbQuery(
          `INSERT INTO template_blocks 
           (id, template_id, block_type, label, field_key, data_source, 
            position_x, position_y, width, height, properties) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [block.id, templateData.id, block.type, block.label, 
           block.fieldKey, block.dataSource, block.position.x, 
           block.position.y, block.size.width, block.size.height, 
           JSON.stringify(block.properties)]
        );
      }

      // Refresh saved templates list
      const templatesResult = await window.electronAPI.dbQuery(
        'SELECT * FROM report_templates ORDER BY uploaded_at DESC'
      );
      if (templatesResult.success) {
        setSavedTemplates(templatesResult.data || []);
      }

      toast({
        title: "Template Saved",
        description: `Template "${templateData.name}" has been saved successfully`
      });

    } catch (error) {
      console.error('Failed to save template:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save template",
        variant: "destructive"
      });
    }
  }, [currentTemplate, templateBlocks, selectedMemo, selectedCategory, user, toast]);

  const handleClearTemplate = useCallback(() => {
    setTemplateBlocks([]);
    setSelectedBlock(null);
    setCurrentTemplate(null);
    toast({
      title: "Template Cleared",
      description: "All blocks have been removed from the template"
    });
  }, [toast]);

  const handleNewTemplate = useCallback(() => {
    setCurrentTemplate({
      id: '',
      name: 'New Template',
      description: '',
      product_type: selectedMemo?.product_type || selectedCategory || 'general',
      layout_json: '',
      uploaded_by: user?.fullName || '',
      uploaded_at: '',
      blocks: []
    });
    setTemplateBlocks([]);
    setSelectedBlock(null);
    toast({
      title: "New Template Started",
      description: "Ready to create a new template"
    });
  }, [selectedMemo, selectedCategory, user, toast]);

  const handleDeleteSelectedBlock = useCallback(() => {
    if (!selectedBlock) {
      toast({
        title: "No Block Selected",
        description: "Please select a block to delete",
        variant: "destructive"
      });
      return;
    }
    
    setTemplateBlocks(prev => prev.filter(b => b.id !== selectedBlock.id));
    setSelectedBlock(null);
    
    toast({
      title: "Block Deleted",
      description: "Selected block has been removed from the template"
    });
  }, [selectedBlock, toast]);

  const handleUploadTemplate = useCallback(() => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json';
    fileInput.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        try {
          const result = readerEvent.target?.result as string;
          const layout = JSON.parse(result);
          
          if (layout.blocks && Array.isArray(layout.blocks)) {
            setTemplateBlocks(layout.blocks);
            setCurrentTemplate({
              id: `uploaded_${Date.now()}`,
              name: file.name.replace('.json', ''),
              description: 'Uploaded template',
              product_type: layout.product_type || 'general',
              layout_json: result,
              uploaded_by: user?.username || 'Unknown',
              uploaded_at: new Date().toISOString(),
              blocks: layout.blocks
            });
            
            toast({
              title: "Template Uploaded",
              description: `Template "${file.name}" has been loaded successfully`
            });
          } else {
            throw new Error('Invalid template format - missing blocks array');
          }
        } catch (error) {
          console.error('Failed to parse template file:', error);
          toast({
            title: "Upload Failed",
            description: "Invalid template file format. Please ensure it's a valid JSON file with blocks array.",
            variant: "destructive"
          });
        }
      };
      reader.readAsText(file);
    };
    fileInput.click();
  }, [user, toast]);

  const handleBlockClick = useCallback((block: ReportBlock) => {
    setSelectedBlock(block);
  }, []);

  const handleDeleteBlock = useCallback((blockId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTemplateBlocks(prev => prev.filter(b => b.id !== blockId));
    if (selectedBlock?.id === blockId) {
      setSelectedBlock(null);
    }
  }, [selectedBlock]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] max-h-[95vh] p-0">
        <DialogHeader className="px-6 py-4 border-b">
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>Advanced Report Designer</span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex h-[85vh]">
          {/* Left Sidebar */}
          <div className="w-80 border-r bg-muted/30 flex flex-col">
            {/* Top Action Bar */}
            <div className="p-4 border-b flex space-x-2">
              <Button size="sm" onClick={handlePreviewToggle} disabled={isGenerating}>
                {isGenerating ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : showPreview ? (
                  <Download className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
                {isGenerating ? 'Generating...' : showPreview ? 'Download PDF' : 'Preview Report'}
              </Button>
              <Button size="sm" variant="outline" onClick={handleSaveTemplate}>
                <Save className="h-4 w-4" />
                Save Template
              </Button>
              <Button size="sm" variant="outline" onClick={handleClearTemplate}>
                <Trash2 className="h-4 w-4" />
                Clear
              </Button>
            </div>

            {/* Memo Selection */}
            <div className="p-4 border-b space-y-3">
              <div>
                <Label className="text-sm font-medium mb-2 block">Select Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose category..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aggregates">Aggregates</SelectItem>
                    <SelectItem value="concrete">Concrete</SelectItem>
                    <SelectItem value="blocks">Blocks</SelectItem>
                    <SelectItem value="pavers">Pavers</SelectItem>
                    <SelectItem value="flagstone">Flagstone</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-sm font-medium mb-2 block">Select Completed Memo</Label>
                <Select 
                  value={selectedMemo?.id || ''} 
                  onValueChange={(value) => {
                    const memo = availableMemos.find(m => m.id === value);
                    setSelectedMemo(memo);
                  }}
                  disabled={!selectedCategory}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose memo..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableMemos.map((memo) => (
                      <SelectItem key={memo.id} value={memo.id}>
                        <div className="flex items-center space-x-2">
                          <FileCheck className="h-4 w-4 text-green-500" />
                          <span>{memo.memo_ref} - {memo.plant}</span>
                          <Badge variant="outline" className="text-xs">
                            {memo.product_type}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedMemo && memoData && Object.keys(memoData).length > 0 && (
                <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
                  <p>✅ Memo data loaded: {Object.keys(memoData).length} fields</p>
                  <p className="truncate">Fields: {Object.keys(memoData).slice(0, 3).join(', ')}...</p>
                </div>
              )}
            </div>

            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="flex-1 flex flex-col">
              <TabsList className="mx-4 mt-2">
                <TabsTrigger value="blocks" className="flex-1">Blocks</TabsTrigger>
                <TabsTrigger value="templates" className="flex-1">Templates</TabsTrigger>
              </TabsList>

              <TabsContent value="blocks" className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="p-4 space-y-4">
                    {getBlockCategories().map((category, categoryIndex) => (
                      <div key={categoryIndex}>
                        <div className="flex items-center space-x-2 mb-2">
                          {category.icon}
                          <span className="font-medium text-sm">{category.name}</span>
                        </div>
                        <div className="grid grid-cols-1 gap-2">
                          {category.blocks.map((block, blockIndex) => (
                            <div
                              key={blockIndex}
                              className="p-3 border rounded-lg cursor-move hover:bg-muted/50 transition-colors"
                              draggable
                              onDragStart={() => handleDragStart(block.type)}
                              onDragEnd={handleDragEnd}
                            >
                              <div className="flex items-center space-x-2">
                                {block.icon}
                                <span className="text-sm font-medium">{block.label}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="templates" className="flex-1 overflow-hidden">
                <div className="p-4 space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Search templates..."
                      value={templateSearch}
                      onChange={(e) => setTemplateSearch(e.target.value)}
                      className="flex-1"
                    />
                    <Button size="icon" variant="outline">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>

                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {savedTemplates
                        .filter(t => t.name.toLowerCase().includes(templateSearch.toLowerCase()))
                        .map((template) => (
                        <Card
                          key={template.id}
                          className="p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => loadTemplate(template)}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium text-sm">{template.name}</h4>
                              <p className="text-xs text-muted-foreground">{template.description}</p>
                              <Badge variant="outline" className="mt-1 text-xs">
                                {template.product_type}
                              </Badge>
                            </div>
                            <Button size="sm" variant="ghost">
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="space-y-2">
                    <Button variant="outline" className="w-full" onClick={handleNewTemplate}>
                      <Plus className="h-4 w-4 mr-2" />
                      New Template
                    </Button>
                    <Button variant="outline" className="w-full" onClick={handleUploadTemplate}>
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Template
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Center Panel - Report Canvas */}
          <div className="flex-1 flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-medium">Live Report Preview</h3>
              {currentTemplate && (
                <div className="flex items-center space-x-2">
                  <Input
                    value={currentTemplate.name}
                    onChange={(e) => setCurrentTemplate(prev => prev ? { ...prev, name: e.target.value } : null)}
                    className="w-40"
                    placeholder="Template name..."
                  />
                </div>
              )}
            </div>

            <div 
              className="flex-1 bg-white relative overflow-auto"
              onDrop={handleCanvasDrop}
              onDragOver={(e) => e.preventDefault()}
              style={{ backgroundImage: 'radial-gradient(circle, #ccc 1px, transparent 1px)', backgroundSize: '20px 20px' }}
            >
              {templateBlocks.map((block) => (
                <div
                  key={block.id}
                  className={`absolute border-2 rounded cursor-move p-2 bg-white shadow-sm ${
                    selectedBlock?.id === block.id ? 'border-blue-500' : 'border-gray-300 hover:border-blue-300'
                  }`}
                  style={{
                    left: block.position.x,
                    top: block.position.y,
                    width: block.size.width,
                    height: block.size.height
                  }}
                  onClick={() => handleBlockClick(block)}
                >
                  <div className="flex items-center space-x-2 h-full">
                    <div className="flex-1 overflow-hidden">
                      <div className="text-sm font-medium truncate">{block.label}</div>
                      {block.fieldKey && (
                        <div className="text-xs text-muted-foreground">{block.fieldKey}</div>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => handleDeleteBlock(block.id, e)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}

              {templateBlocks.length === 0 && (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="text-lg font-medium">Drag blocks from the sidebar</p>
                    <p className="text-sm">Build your report template by dragging elements here</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Properties */}
          <div className="w-80 border-l bg-muted/30 p-4">
            <h3 className="font-medium mb-4">Properties</h3>
            
            {selectedBlock ? (
              <div className="space-y-4">
                <div>
                  <Label>Label</Label>
                  <Input
                    value={selectedBlock.label}
                    onChange={(e) => {
                      setSelectedBlock({ ...selectedBlock, label: e.target.value });
                      setTemplateBlocks(prev => prev.map(b => 
                        b.id === selectedBlock.id ? { ...b, label: e.target.value } : b
                      ));
                    }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label>Width</Label>
                    <Input
                      type="number"
                      value={selectedBlock.size.width}
                      onChange={(e) => {
                        const width = parseInt(e.target.value) || 0;
                        setSelectedBlock({ ...selectedBlock, size: { ...selectedBlock.size, width } });
                        setTemplateBlocks(prev => prev.map(b => 
                          b.id === selectedBlock.id ? { ...b, size: { ...b.size, width } } : b
                        ));
                      }}
                    />
                  </div>
                  <div>
                    <Label>Height</Label>
                    <Input
                      type="number"
                      value={selectedBlock.size.height}
                      onChange={(e) => {
                        const height = parseInt(e.target.value) || 0;
                        setSelectedBlock({ ...selectedBlock, size: { ...selectedBlock.size, height } });
                        setTemplateBlocks(prev => prev.map(b => 
                          b.id === selectedBlock.id ? { ...b, size: { ...b.size, height } } : b
                        ));
                      }}
                    />
                  </div>
                </div>

                {selectedBlock.type === 'field' && (
                  <div>
                    <Label>Field Key</Label>
                    <Input
                      value={selectedBlock.fieldKey || ''}
                      onChange={(e) => {
                        setSelectedBlock({ ...selectedBlock, fieldKey: e.target.value });
                        setTemplateBlocks(prev => prev.map(b => 
                          b.id === selectedBlock.id ? { ...b, fieldKey: e.target.value } : b
                        ));
                      }}
                    />
                  </div>
                )}

                {selectedBlock.type === 'text' && (
                  <>
                    <div>
                      <Label>Text Content</Label>
                      <Textarea
                        value={selectedBlock.properties.text || ''}
                        onChange={(e) => {
                          const newProperties = { ...selectedBlock.properties, text: e.target.value };
                          setSelectedBlock({ ...selectedBlock, properties: newProperties });
                          setTemplateBlocks(prev => prev.map(b => 
                            b.id === selectedBlock.id ? { ...b, properties: newProperties } : b
                          ));
                        }}
                      />
                    </div>
                    <div>
                      <Label>Font Size</Label>
                      <Input
                        type="number"
                        value={selectedBlock.properties.fontSize || 14}
                        onChange={(e) => {
                          const newProperties = { ...selectedBlock.properties, fontSize: parseInt(e.target.value) || 14 };
                          setSelectedBlock({ ...selectedBlock, properties: newProperties });
                          setTemplateBlocks(prev => prev.map(b => 
                            b.id === selectedBlock.id ? { ...b, properties: newProperties } : b
                          ));
                        }}
                      />
                    </div>
                  </>
                )}

                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDeleteSelectedBlock}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Block
                </Button>
              </div>
            ) : (
              <div className="text-center text-muted-foreground">
                <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>Select a block to edit properties</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}