import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  Info,
  Loader2,
  Database,
  FileCheck,
  RefreshCw,
  BarChart3,
  Archive
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localCSVService, CSVExportResult, ValidationResult } from '@/services/storage/localCSVService';

export const ReferenceDataTools: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [showSync, setShowSync] = useState(false);
  const [tableStats, setTableStats] = useState<{ [tableName: string]: { rowCount: number; lastUpdated?: string } }>({});
  const [exportResults, setExportResults] = useState<CSVExportResult[]>([]);
  const [validationResults, setValidationResults] = useState<ValidationResult | null>(null);
  const [lastExportTime, setLastExportTime] = useState<string | null>(null);
  const [lastValidationTime, setLastValidationTime] = useState<string | null>(null);
  const { toast } = useToast();

  const handleExportAll = async () => {
    setIsExporting(true);
    try {
      const results = await localCSVService.exportAllData();
      setExportResults(results);
      setLastExportTime(new Date().toISOString());

      const successCount = results.filter(r => r.success).length;
      const totalRows = results.reduce((sum, r) => sum + r.rowCount, 0);

      toast({
        title: 'Export Complete',
        description: `Exported ${successCount} files with ${totalRows} total records`,
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: `Failed to export data: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleValidateAll = async () => {
    setIsValidating(true);
    try {
      const results = await localCSVService.validateAllData();
      setValidationResults(results);
      setLastValidationTime(new Date().toISOString());

      if (results.isValid) {
        toast({
          title: 'Validation Passed',
          description: `All ${results.tablesChecked} reference tables are valid`,
        });
      } else {
        toast({
          title: 'Validation Issues Found',
          description: `Found ${results.errors.length} errors and ${results.warnings.length} warnings`,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Validation Failed',
        description: `Failed to validate data: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleInitializeSampleData = async () => {
    setIsInitializing(true);
    try {
      // Initialize tables without sample data for clean prototype
      console.log('Reference tables initialized (no sample data added)');
      
      toast({
        title: 'Tables Initialized', 
        description: 'Reference data tables have been initialized and are ready for use',
      });
      
      // Refresh validation after initialization
      setTimeout(() => handleValidateAll(), 1000);
    } catch (error) {
      toast({
        title: 'Initialization Failed',
        description: `Failed to initialize sample data: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setIsInitializing(false);
    }
  };

  const handleShowStats = async () => {
    try {
      const stats = await localCSVService.getTableStats();
      setTableStats(stats);
      setShowStats(true);
    } catch (error) {
      toast({
        title: 'Failed to Load Statistics',
        description: `Error loading table statistics: ${error}`,
        variant: 'destructive'
      });
    }
  };

  const handleShowSync = () => {
    setShowSync(true);
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Data Export */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-blue-600" />
              Export All Data
            </CardTitle>
            <CardDescription>
              Download all reference data as CSV files
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={handleExportAll}
              disabled={isExporting}
              className="w-full"
            >
              {isExporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV Files
                </>
              )}
            </Button>
            
            {lastExportTime && (
              <p className="text-xs text-muted-foreground">
                Last export: {formatTimestamp(lastExportTime)}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Data Validation */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Validate Data
            </CardTitle>
            <CardDescription>
              Check data integrity and relationships
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              variant="outline"
              onClick={handleValidateAll}
              disabled={isValidating}
              className="w-full"
            >
              {isValidating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Validating...
                </>
              ) : (
                <>
                  <FileCheck className="h-4 w-4 mr-2" />
                  Run Validation
                </>
              )}
            </Button>
            
            {lastValidationTime && (
              <p className="text-xs text-muted-foreground">
                Last check: {formatTimestamp(lastValidationTime)}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Initialize Sample Data */}
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-purple-600" />
              Sample Data
            </CardTitle>
            <CardDescription>
              Initialize tables with sample reference data
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              variant="outline"
              onClick={handleInitializeSampleData}
              disabled={isInitializing}
              className="w-full"
            >
              {isInitializing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Initializing...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Initialize Data
                </>
              )}
            </Button>
            
            <p className="text-xs text-muted-foreground">
              Adds sample data to empty tables
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Validation Results */}
      {validationResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {validationResults.isValid ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-600" />
              )}
              Validation Results
            </CardTitle>
            <CardDescription>
              Data integrity check completed on {formatTimestamp(validationResults.timestamp)}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="flex items-center gap-2">
                <Badge variant={validationResults.isValid ? "default" : "destructive"}>
                  {validationResults.isValid ? 'Valid' : 'Issues Found'}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Overall Status
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge variant="outline">
                  {validationResults.tablesChecked}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Tables Checked
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge variant={validationResults.errors.length > 0 ? "destructive" : "secondary"}>
                  {validationResults.errors.length}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Errors Found
                </span>
              </div>
            </div>

            {validationResults.errors.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-medium">Errors found:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {validationResults.errors.map((error, index) => (
                        <li key={index} className="text-red-600">{error}</li>
                      ))}
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {validationResults.warnings.length > 0 && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-medium">Warnings:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {validationResults.warnings.map((warning, index) => (
                        <li key={index} className="text-yellow-600">{warning}</li>
                      ))}
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Export Results */}
      {exportResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Archive className="h-5 w-5" />
              Export Results
            </CardTitle>
            <CardDescription>
              Data export completed on {lastExportTime && formatTimestamp(lastExportTime)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {exportResults.map((result, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    {result.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                    )}
                    <div>
                      <p className="font-medium text-sm">{result.filename}</p>
                      {result.error && (
                        <p className="text-xs text-red-600">{result.error}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      {result.rowCount} rows
                    </Badge>
                    {result.success && (
                      <Badge variant="default">
                        Downloaded
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-between text-sm">
                <span>Total files exported:</span>
                <span className="font-medium">
                  {exportResults.filter(r => r.success).length} / {exportResults.length}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Total records exported:</span>
                <span className="font-medium">
                  {exportResults.reduce((sum, r) => sum + (r.success ? r.rowCount : 0), 0)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Additional Tools */}
      <Card>
        <CardHeader>
          <CardTitle>Additional Tools</CardTitle>
          <CardDescription>
            Advanced reference data management utilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="cursor-pointer hover:bg-accent/50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-lg">
                    <BarChart3 className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Data Statistics</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      View detailed statistics and usage metrics for reference data
                    </p>
                    <Button variant="outline" size="sm" className="w-full" onClick={handleShowStats}>
                      View Statistics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:bg-accent/50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-lg">
                    <RefreshCw className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">Data Synchronization</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Sync reference data across multiple database instances
                    </p>
                    <Button variant="outline" size="sm" className="w-full" onClick={handleShowSync}>
                      Setup Sync
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Data Statistics Modal */}
      {showStats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Data Statistics
              </span>
              <Button variant="ghost" size="sm" onClick={() => setShowStats(false)}>
                ×
              </Button>
            </CardTitle>
            <CardDescription>
              Overview of reference data tables and their current status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {Object.entries(tableStats).map(([tableName, stats]) => (
                <div key={tableName} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium text-sm capitalize">{tableName.replace(/_/g, ' ')}</p>
                    {stats.lastUpdated && (
                      <p className="text-xs text-muted-foreground">
                        Last updated: {formatTimestamp(stats.lastUpdated)}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={stats.rowCount > 0 ? "default" : "secondary"}>
                      {stats.rowCount} rows
                    </Badge>
                    {stats.rowCount === 0 && (
                      <Badge variant="destructive">Empty</Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <div className="grid gap-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Tables:</span>
                  <span className="font-medium">{Object.keys(tableStats).length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tables with Data:</span>
                  <span className="font-medium">
                    {Object.values(tableStats).filter(s => s.rowCount > 0).length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Total Records:</span>
                  <span className="font-medium">
                    {Object.values(tableStats).reduce((sum, s) => sum + s.rowCount, 0)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data Synchronization Modal */}
      {showSync && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <RefreshCw className="h-5 w-5" />
                Data Synchronization
              </span>
              <Button variant="ghost" size="sm" onClick={() => setShowSync(false)}>
                ×
              </Button>
            </CardTitle>
            <CardDescription>
              Manage data synchronization across environments
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Data synchronization allows you to keep reference data consistent across different environments (development, testing, production).
              </AlertDescription>
            </Alert>
            
            <div className="grid gap-4">
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">Backup Current Data</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Create a backup of all current reference data before synchronization
                  </p>
                  <Button variant="outline" size="sm" onClick={handleExportAll}>
                    Create Backup
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">Import from Backup</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Restore reference data from a previously exported backup
                  </p>
                  <Button variant="outline" size="sm" disabled>
                    Import Backup
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">Reset to Defaults</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Reset all reference tables to their default sample data
                  </p>
                  <Button variant="destructive" size="sm" onClick={handleInitializeSampleData}>
                    Reset Data
                  </Button>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};