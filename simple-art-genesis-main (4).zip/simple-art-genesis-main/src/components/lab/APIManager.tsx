import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash2, Play, Settings, Globe, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PlacementSelector } from '@/components/developer/PlacementSelector';
import { SuccessMessageDialog } from '@/components/developer/SuccessMessageDialog';
import type { SuccessMessage } from '@/types/developer';

interface APIEndpoint {
  id: string;
  name: string;
  description: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  headers: Record<string, string>;
  queryParams: Record<string, string>;
  requestSchema?: any;
  responseSchema?: any;
  sqliteMapping?: {
    table: string;
    operation: 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE';
    fields: string[];
    conditions?: string;
  };
  isActive: boolean;
  created_at: string;
}

export function APIManager() {
  const { toast } = useToast();
  const [currentEndpoint, setCurrentEndpoint] = useState<APIEndpoint>({
    id: '',
    name: '',
    description: '',
    method: 'GET',
    path: '/api/',
    headers: {},
    queryParams: {},
    isActive: true,
    created_at: new Date().toISOString()
  });
  const [savedEndpoints, setSavedEndpoints] = useState<APIEndpoint[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [testResponse, setTestResponse] = useState<any>(null);
  
  // Placement selector state
  const [selectedPlacement, setSelectedPlacement] = useState('dashboard');
  const [moduleId, setModuleId] = useState('');
  const [customRoute, setCustomRoute] = useState('');
  
  // Success dialog state
  const [successMessage, setSuccessMessage] = useState<SuccessMessage | null>(null);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  useEffect(() => {
    loadSavedEndpoints();
  }, []);

  const loadSavedEndpoints = async () => {
    try {
      const saved = localStorage.getItem('api_endpoints');
      if (saved) {
        setSavedEndpoints(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load saved endpoints:', error);
    }
  };

  const httpMethods = [
    { value: 'GET', label: 'GET' },
    { value: 'POST', label: 'POST' },
    { value: 'PUT', label: 'PUT' },
    { value: 'DELETE', label: 'DELETE' },
    { value: 'PATCH', label: 'PATCH' }
  ];

  const sqliteOperations = [
    { value: 'SELECT', label: 'SELECT (Read)' },
    { value: 'INSERT', label: 'INSERT (Create)' },
    { value: 'UPDATE', label: 'UPDATE (Modify)' },
    { value: 'DELETE', label: 'DELETE (Remove)' }
  ];

  const addHeader = () => {
    const key = prompt('Header name:');
    const value = prompt('Header value:');
    if (key && value) {
      setCurrentEndpoint(prev => ({
        ...prev,
        headers: { ...prev.headers, [key]: value }
      }));
    }
  };

  const removeHeader = (key: string) => {
    setCurrentEndpoint(prev => ({
      ...prev,
      headers: Object.fromEntries(Object.entries(prev.headers).filter(([k]) => k !== key))
    }));
  };

  const addQueryParam = () => {
    const key = prompt('Parameter name:');
    const description = prompt('Parameter description:');
    if (key && description) {
      setCurrentEndpoint(prev => ({
        ...prev,
        queryParams: { ...prev.queryParams, [key]: description }
      }));
    }
  };

  const removeQueryParam = (key: string) => {
    setCurrentEndpoint(prev => ({
      ...prev,
      queryParams: Object.fromEntries(Object.entries(prev.queryParams).filter(([k]) => k !== key))
    }));
  };

  const generateExpressCode = () => {
    const method = currentEndpoint.method.toLowerCase();
    const pathParam = currentEndpoint.path.replace(/\{(\w+)\}/g, ':$1');
    
    return `// Express.js endpoint for: ${currentEndpoint.name}
app.${method}('${pathParam}', async (req, res) => {
  try {
    ${currentEndpoint.sqliteMapping ? `
    // SQLite Database Operation
    const db = req.app.get('db');
    ${generateSQLiteCode()}
    
    res.json({ success: true, data: result });` : `
    // Custom logic here
    const result = {
      message: 'Endpoint ${currentEndpoint.name} called successfully',
      timestamp: new Date().toISOString()
    };
    
    res.json(result);`}
  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: error.message });
  }
});`;
  };

  const generateSQLiteCode = () => {
    if (!currentEndpoint.sqliteMapping) return '';

    const { table, operation, fields, conditions } = currentEndpoint.sqliteMapping;

    switch (operation) {
      case 'SELECT':
        return `const stmt = db.prepare('SELECT ${fields.join(', ')} FROM ${table}${conditions ? ` WHERE ${conditions}` : ''}');
    const result = stmt.all();`;
      case 'INSERT':
        return `const stmt = db.prepare('INSERT INTO ${table} (${fields.join(', ')}) VALUES (${fields.map(() => '?').join(', ')})');
    const result = stmt.run(${fields.map(field => `req.body.${field}`).join(', ')});`;
      case 'UPDATE':
        return `const stmt = db.prepare('UPDATE ${table} SET ${fields.map(field => `${field} = ?`).join(', ')}${conditions ? ` WHERE ${conditions}` : ''}');
    const result = stmt.run(${fields.map(field => `req.body.${field}`).join(', ')});`;
      case 'DELETE':
        return `const stmt = db.prepare('DELETE FROM ${table}${conditions ? ` WHERE ${conditions}` : ''}');
    const result = stmt.run();`;
      default:
        return '';
    }
  };

  const testEndpoint = async () => {
    setIsLoading(true);
    try {
      // Simulate API call for testing
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockResponse = {
        status: 200,
        data: {
          message: `Test response for ${currentEndpoint.name}`,
          method: currentEndpoint.method,
          path: currentEndpoint.path,
          timestamp: new Date().toISOString()
        }
      };
      
      setTestResponse(mockResponse);
      toast({
        title: "Test Successful",
        description: "API endpoint test completed successfully"
      });
    } catch (error) {
      toast({
        title: "Test Failed",
        description: "Failed to test API endpoint",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const saveEndpoint = async () => {
    if (!currentEndpoint.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Endpoint name is required",
        variant: "destructive"
      });
      return;
    }

    const endpointToSave = {
      ...currentEndpoint,
      id: currentEndpoint.id || `api_${Date.now()}`,
      created_at: currentEndpoint.created_at || new Date().toISOString(),
      placement: selectedPlacement,
      module_id: moduleId || null,
      custom_route: customRoute || null
    };

    try {
      // Try to save to Electron database if available
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO api_endpoint_definitions (id, name, description, method, path, request_schema, response_schema, placement, module_id, created_at, updated_at, created_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            endpointToSave.id,
            endpointToSave.name,
            endpointToSave.description || '',
            endpointToSave.method,
            endpointToSave.path,
            JSON.stringify(endpointToSave.requestSchema),
            JSON.stringify(endpointToSave.responseSchema),
            endpointToSave.placement,
            endpointToSave.module_id,
            endpointToSave.created_at,
            new Date().toISOString(),
            'current_user'
          ]
        );

        if (!result.success) {
          throw new Error(result.error);
        }
      }

      // Update local state
      setSavedEndpoints(prev => {
        const existing = prev.find(e => e.id === endpointToSave.id);
        if (existing) {
          return prev.map(e => e.id === endpointToSave.id ? endpointToSave : e);
        }
        return [...prev, endpointToSave];
      });

      // Show success message
      const message: SuccessMessage = {
        title: 'API Endpoint Created Successfully!',
        description: `Endpoint "${endpointToSave.name}" (${endpointToSave.method} ${endpointToSave.path}) has been saved.`,
        saved_location: 'SQLite Database → api_endpoint_definitions table',
        view_location: selectedPlacement === 'custom-route' ? customRoute : `/${selectedPlacement}`,
        action_button: {
          label: `View in ${selectedPlacement}`,
          route: selectedPlacement === 'custom-route' ? customRoute || '/' : `/${selectedPlacement}`
        }
      };

      setSuccessMessage(message);
      setShowSuccessDialog(true);

    } catch (error) {
      console.error('Failed to save endpoint to database:', error);
      toast({
        title: "Save Error",
        description: `Failed to save endpoint: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const loadEndpoint = (endpoint: APIEndpoint) => {
    setCurrentEndpoint(endpoint);
    setTestResponse(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">API Manager</h3>
          <p className="text-sm text-muted-foreground">Create and manage local API endpoints</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={testEndpoint} disabled={isLoading}>
            <Play className="w-4 h-4 mr-2" />
            {isLoading ? 'Testing...' : 'Test Endpoint'}
          </Button>
          <Button onClick={saveEndpoint}>
            Save Endpoint
          </Button>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList>
          <TabsTrigger value="builder">Builder</TabsTrigger>
          <TabsTrigger value="endpoints">Saved Endpoints ({savedEndpoints.length})</TabsTrigger>
          <TabsTrigger value="code">Generated Code</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Endpoint Configuration */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Endpoint Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="endpoint-name">Endpoint Name</Label>
                    <Input
                      id="endpoint-name"
                      value={currentEndpoint.name}
                      onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Get Users"
                    />
                  </div>
                  <div>
                    <Label htmlFor="endpoint-description">Description</Label>
                    <Textarea
                      id="endpoint-description"
                      value={currentEndpoint.description}
                      onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Endpoint description"
                      rows={2}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>HTTP Method</Label>
                      <Select
                        value={currentEndpoint.method}
                        onValueChange={(value) => setCurrentEndpoint(prev => ({ ...prev, method: value as APIEndpoint['method'] }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {httpMethods.map(method => (
                            <SelectItem key={method.value} value={method.value}>
                              {method.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="endpoint-path">Path</Label>
                      <Input
                        id="endpoint-path"
                        value={currentEndpoint.path}
                        onChange={(e) => setCurrentEndpoint(prev => ({ ...prev, path: e.target.value }))}
                        placeholder="/api/users"
                      />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={currentEndpoint.isActive}
                      onCheckedChange={(checked) => setCurrentEndpoint(prev => ({ ...prev, isActive: checked }))}
                    />
                    <Label>Active Endpoint</Label>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-base">Headers</CardTitle>
                  <Button size="sm" onClick={addHeader}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Header
                  </Button>
                </CardHeader>
                <CardContent className="space-y-2">
                  {Object.entries(currentEndpoint.headers).map(([key, value]) => (
                    <div key={key} className="flex items-center gap-2 p-2 bg-muted rounded">
                      <code className="text-sm flex-1">{key}: {value}</code>
                      <Button size="sm" variant="ghost" onClick={() => removeHeader(key)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-base">Query Parameters</CardTitle>
                  <Button size="sm" onClick={addQueryParam}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Parameter
                  </Button>
                </CardHeader>
                <CardContent className="space-y-2">
                  {Object.entries(currentEndpoint.queryParams).map(([key, description]) => (
                    <div key={key} className="flex items-center gap-2 p-2 bg-muted rounded">
                      <code className="text-sm flex-1">{key}: {description}</code>
                      <Button size="sm" variant="ghost" onClick={() => removeQueryParam(key)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* SQLite Mapping & Testing */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    SQLite Database Mapping
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="table">Table Name</Label>
                    <Input
                      id="table"
                      value={currentEndpoint.sqliteMapping?.table || ''}
                      onChange={(e) => setCurrentEndpoint(prev => ({
                        ...prev,
                        sqliteMapping: { ...prev.sqliteMapping, table: e.target.value, operation: 'SELECT', fields: [] }
                      }))}
                      placeholder="e.g., users, test_results"
                    />
                  </div>
                  <div>
                    <Label>Database Operation</Label>
                    <Select
                      value={currentEndpoint.sqliteMapping?.operation || 'SELECT'}
                      onValueChange={(value) => setCurrentEndpoint(prev => ({
                        ...prev,
                        sqliteMapping: { ...prev.sqliteMapping!, operation: value as 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE' }
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {sqliteOperations.map(op => (
                          <SelectItem key={op.value} value={op.value}>
                            {op.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="fields">Fields (comma-separated)</Label>
                    <Input
                      id="fields"
                      value={currentEndpoint.sqliteMapping?.fields.join(', ') || ''}
                      onChange={(e) => setCurrentEndpoint(prev => ({
                        ...prev,
                        sqliteMapping: { 
                          ...prev.sqliteMapping!, 
                          fields: e.target.value.split(',').map(f => f.trim()).filter(Boolean)
                        }
                      }))}
                      placeholder="id, name, email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="conditions">WHERE Conditions (optional)</Label>
                    <Input
                      id="conditions"
                      value={currentEndpoint.sqliteMapping?.conditions || ''}
                      onChange={(e) => setCurrentEndpoint(prev => ({
                        ...prev,
                        sqliteMapping: { ...prev.sqliteMapping!, conditions: e.target.value }
                      }))}
                      placeholder="status = 'active'"
                    />
                  </div>
                </CardContent>
              </Card>

              {testResponse && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Test Response</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
                      {JSON.stringify(testResponse, null, 2)}
                    </pre>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
          
          {/* Placement Selector */}
          <PlacementSelector
            selectedPlacement={selectedPlacement}
            onPlacementChange={setSelectedPlacement}
            moduleId={moduleId}
            onModuleIdChange={setModuleId}
            customRoute={customRoute}
            onCustomRouteChange={setCustomRoute}
          />
        </TabsContent>

        <TabsContent value="endpoints">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedEndpoints.map(endpoint => (
              <Card key={endpoint.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{endpoint.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{endpoint.method}</Badge>
                    <Badge variant={endpoint.isActive ? 'default' : 'secondary'}>
                      {endpoint.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-2">{endpoint.description}</p>
                  <code className="text-xs bg-muted p-1 rounded">{endpoint.path}</code>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" onClick={() => loadEndpoint(endpoint)}>
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Deploy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Generated Express.js Code
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
                {generateExpressCode()}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <SuccessMessageDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
        message={successMessage}
      />
    </div>
  );
}