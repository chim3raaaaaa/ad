import { LabSidebar } from "./LabSidebar";

interface LabLayoutProps {
  children: React.ReactNode;
}

export function LabLayout({ children }: LabLayoutProps) {
  return (
    <div className="app-shell flex h-screen w-full bg-background overflow-hidden">
      <LabSidebar />
      <main className="main-content flex-1 overflow-y-auto min-h-0 pb-4">
        {children}
      </main>
    </div>
  );
}