import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Palette, Download, Upload, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ColorScheme {
  primary: string;
  secondary: string;
  background: string;
  foreground: string;
  muted: string;
  accent: string;
  destructive: string;
  border: string;
  input: string;
  ring: string;
}

interface ThemeConfig {
  id: string;
  name: string;
  description: string;
  colors: {
    light: ColorScheme;
    dark: ColorScheme;
  };
  typography: {
    fontFamily: string;
    fontSize: {
      base: number;
      scale: number;
    };
    lineHeight: number;
    letterSpacing: number;
  };
  spacing: {
    scale: number;
    containerPadding: number;
  };
  borderRadius: {
    small: number;
    medium: number;
    large: number;
  };
  shadows: {
    enabled: boolean;
    intensity: number;
  };
  animations: {
    enabled: boolean;
    duration: number;
    easing: string;
  };
  created_at: string;
}

export function ThemeCustomizer() {
  const { toast } = useToast();
  const [currentTheme, setCurrentTheme] = useState<ThemeConfig>({
    id: '',
    name: 'Custom Theme',
    description: '',
    colors: {
      light: {
        primary: '#3b82f6',
        secondary: '#64748b',
        background: '#ffffff',
        foreground: '#0f172a',
        muted: '#f1f5f9',
        accent: '#f1f5f9',
        destructive: '#ef4444',
        border: '#e2e8f0',
        input: '#ffffff',
        ring: '#3b82f6'
      },
      dark: {
        primary: '#3b82f6',
        secondary: '#64748b',
        background: '#0f172a',
        foreground: '#f8fafc',
        muted: '#1e293b',
        accent: '#1e293b',
        destructive: '#ef4444',
        border: '#334155',
        input: '#1e293b',
        ring: '#3b82f6'
      }
    },
    typography: {
      fontFamily: 'Inter, system-ui, sans-serif',
      fontSize: { base: 16, scale: 1.125 },
      lineHeight: 1.5,
      letterSpacing: 0
    },
    spacing: {
      scale: 1,
      containerPadding: 24
    },
    borderRadius: {
      small: 4,
      medium: 8,
      large: 16
    },
    shadows: {
      enabled: true,
      intensity: 0.1
    },
    animations: {
      enabled: true,
      duration: 200,
      easing: 'ease-out'
    },
    created_at: new Date().toISOString()
  });
  
  const [savedThemes, setSavedThemes] = useState<ThemeConfig[]>([]);
  const [previewMode, setPreviewMode] = useState('light' as 'light' | 'dark');
  const [isApplied, setIsApplied] = useState(false);

  const defaultLightColors: ColorScheme = {
    primary: '#3b82f6',
    secondary: '#64748b', 
    background: '#ffffff',
    foreground: '#0f172a',
    muted: '#f1f5f9',
    accent: '#f1f5f9',
    destructive: '#ef4444',
    border: '#e2e8f0',
    input: '#ffffff',
    ring: '#3b82f6'
  };

  const defaultDarkColors: ColorScheme = {
    primary: '#3b82f6',
    secondary: '#64748b',
    background: '#0f172a', 
    foreground: '#f8fafc',
    muted: '#1e293b',
    accent: '#1e293b',
    destructive: '#ef4444',
    border: '#334155',
    input: '#1e293b',
    ring: '#3b82f6'
  };

  const colorPresets = [
    { name: 'Blue', primary: '#3b82f6' },
    { name: 'Green', primary: '#10b981' },
    { name: 'Purple', primary: '#8b5cf6' },
    { name: 'Pink', primary: '#ec4899' },
    { name: 'Orange', primary: '#f97316' },
    { name: 'Red', primary: '#ef4444' }
  ];

  const fontOptions = [
    'Inter, system-ui, sans-serif',
    'Roboto, system-ui, sans-serif', 
    'Poppins, system-ui, sans-serif',
    'Merriweather, serif',
    'Playfair Display, serif',
    'JetBrains Mono, monospace'
  ];

  useEffect(() => {
    // Load saved themes from localStorage
    const saved = localStorage.getItem('customThemes');
    if (saved) {
      setSavedThemes(JSON.parse(saved));
    }
  }, []);

  const updateColors = (mode: 'light' | 'dark', colorKey: keyof ColorScheme, value: string) => {
    setCurrentTheme(prev => ({
      ...prev,
      colors: {
        ...prev.colors,
        [mode]: {
          ...prev.colors[mode],
          [colorKey]: value
        }
      }
    }));
  };

  const applyColorPreset = (preset: { primary: string }) => {
    setCurrentTheme(prev => ({
      ...prev,
      colors: {
        light: { ...prev.colors.light, primary: preset.primary, ring: preset.primary },
        dark: { ...prev.colors.dark, primary: preset.primary, ring: preset.primary }
      }
    }));
  };

  const applyTheme = () => {
    const root = document.documentElement;
    const colors = currentTheme.colors[previewMode];
    
    // Apply CSS custom properties
    Object.entries(colors).forEach(([key, value]) => {
      // Convert hex to HSL for CSS custom properties
      const hsl = hexToHsl(value);
      root.style.setProperty(`--${key}`, hsl);
    });

    // Apply typography
    root.style.setProperty('--font-family', currentTheme.typography.fontFamily);
    root.style.setProperty('--font-size-base', `${currentTheme.typography.fontSize.base}px`);
    root.style.setProperty('--line-height', currentTheme.typography.lineHeight.toString());
    root.style.setProperty('--letter-spacing', `${currentTheme.typography.letterSpacing}em`);

    // Apply border radius
    root.style.setProperty('--border-radius-sm', `${currentTheme.borderRadius.small}px`);
    root.style.setProperty('--border-radius', `${currentTheme.borderRadius.medium}px`);
    root.style.setProperty('--border-radius-lg', `${currentTheme.borderRadius.large}px`);

    setIsApplied(true);
    toast({
      title: "Theme Applied",
      description: "Custom theme has been applied to the application"
    });
  };

  const resetTheme = () => {
    const root = document.documentElement;
    
    // Remove custom properties to restore defaults
    const properties = [
      '--primary', '--secondary', '--background', '--foreground',
      '--muted', '--accent', '--destructive', '--border', '--input', '--ring',
      '--font-family', '--font-size-base', '--line-height', '--letter-spacing',
      '--border-radius-sm', '--border-radius', '--border-radius-lg'
    ];
    
    properties.forEach(prop => {
      root.style.removeProperty(prop);
    });

    setCurrentTheme(prev => ({
      ...prev,
      colors: {
        light: { ...defaultLightColors },
        dark: { ...defaultDarkColors }
      }
    }));

    setIsApplied(false);
    toast({
      title: "Theme Reset",
      description: "Default theme has been restored"
    });
  };

  const saveTheme = () => {
    if (!currentTheme.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Theme name is required",
        variant: "destructive"
      });
      return;
    }

    const themeToSave = {
      ...currentTheme,
      id: currentTheme.id || `theme_${Date.now()}`,
      created_at: currentTheme.created_at || new Date().toISOString()
    };

    const updatedThemes = savedThemes.some(t => t.id === themeToSave.id)
      ? savedThemes.map(t => t.id === themeToSave.id ? themeToSave : t)
      : [...savedThemes, themeToSave];

    setSavedThemes(updatedThemes);
    localStorage.setItem('customThemes', JSON.stringify(updatedThemes));

    toast({
      title: "Theme Saved",
      description: `"${themeToSave.name}" has been saved successfully`
    });
  };

  const loadTheme = (theme: ThemeConfig) => {
    setCurrentTheme(theme);
    setIsApplied(false);
  };

  const exportTheme = () => {
    const dataStr = JSON.stringify(currentTheme, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${currentTheme.name.replace(/\s+/g, '-').toLowerCase()}-theme.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();

    toast({
      title: "Theme Exported",
      description: "Theme configuration has been downloaded"
    });
  };

  const importTheme = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const theme = JSON.parse(e.target?.result as string) as ThemeConfig;
        setCurrentTheme(theme);
        toast({
          title: "Theme Imported",
          description: "Theme configuration has been loaded"
        });
      } catch (error) {
        toast({
          title: "Import Error",
          description: "Invalid theme file format",
          variant: "destructive"
        });
      }
    };
    reader.readAsText(file);
  };

  const hexToHsl = (hex: string): string => {
    // Simple hex to HSL conversion for CSS custom properties
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return '0 0% 0%';
    
    const r = parseInt(result[1], 16) / 255;
    const g = parseInt(result[2], 16) / 255;
    const b = parseInt(result[3], 16) / 255;
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s;
    const l = (max + min) / 2;

    if (max === min) {
      h = s = 0;
    } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
        default: h = 0;
      }
      h /= 6;
    }

    return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Theme Customizer</h3>
          <p className="text-sm text-muted-foreground">Customize the application's appearance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={resetTheme} disabled={!isApplied}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button onClick={applyTheme}>
            <Palette className="w-4 h-4 mr-2" />
            Apply Theme
          </Button>
        </div>
      </div>

      <Tabs defaultValue="colors" className="space-y-4">
        <TabsList>
          <TabsTrigger value="colors">Colors</TabsTrigger>
          <TabsTrigger value="typography">Typography</TabsTrigger>
          <TabsTrigger value="spacing">Layout</TabsTrigger>
          <TabsTrigger value="themes">Saved Themes ({savedThemes.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="colors" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Preview Mode</Label>
              <div className="flex items-center gap-2 mt-1">
                <Button
                  size="sm"
                  variant={previewMode === 'light' ? 'default' : 'outline'}
                  onClick={() => setPreviewMode('light')}
                >
                  Light
                </Button>
                <Button
                  size="sm"
                  variant={previewMode === 'dark' ? 'default' : 'outline'}
                  onClick={() => setPreviewMode('dark')}
                >
                  Dark
                </Button>
              </div>
            </div>
            
            <div>
              <Label>Quick Presets</Label>
              <div className="flex gap-1 mt-1">
                {colorPresets.map(preset => (
                  <button
                    key={preset.name}
                    className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                    style={{ backgroundColor: preset.primary }}
                    onClick={() => applyColorPreset(preset)}
                    title={preset.name}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(currentTheme.colors[previewMode]).map(([colorKey, colorValue]) => (
              <Card key={colorKey}>
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <Label className="capitalize">{colorKey.replace(/([A-Z])/g, ' $1')}</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="color"
                        value={colorValue}
                        onChange={(e) => updateColors(previewMode, colorKey as keyof ColorScheme, e.target.value)}
                        className="w-12 h-8 p-0 border-0"
                      />
                      <Input
                        value={colorValue}
                        onChange={(e) => updateColors(previewMode, colorKey as keyof ColorScheme, e.target.value)}
                        className="font-mono text-sm"
                      />
                    </div>
                    <div
                      className="h-8 rounded border"
                      style={{ backgroundColor: colorValue }}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="typography" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Font Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Font Family</Label>
                  <select
                    className="w-full mt-1 p-2 border rounded"
                    value={currentTheme.typography.fontFamily}
                    onChange={(e) => setCurrentTheme(prev => ({
                      ...prev,
                      typography: { ...prev.typography, fontFamily: e.target.value }
                    }))}
                  >
                    {fontOptions.map(font => (
                      <option key={font} value={font}>
                        {font.split(',')[0]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label>Base Font Size: {currentTheme.typography.fontSize.base}px</Label>
                  <Slider
                    value={[currentTheme.typography.fontSize.base]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      typography: { 
                        ...prev.typography, 
                        fontSize: { ...prev.typography.fontSize, base: value[0] }
                      }
                    }))}
                    max={24}
                    min={12}
                    step={1}
                  />
                </div>

                <div>
                  <Label>Type Scale: {currentTheme.typography.fontSize.scale}</Label>
                  <Slider
                    value={[currentTheme.typography.fontSize.scale]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      typography: { 
                        ...prev.typography, 
                        fontSize: { ...prev.typography.fontSize, scale: value[0] }
                      }
                    }))}
                    max={1.5}
                    min={1.1}
                    step={0.05}
                  />
                </div>

                <div>
                  <Label>Line Height: {currentTheme.typography.lineHeight}</Label>
                  <Slider
                    value={[currentTheme.typography.lineHeight]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      typography: { ...prev.typography, lineHeight: value[0] }
                    }))}
                    max={2}
                    min={1.2}
                    step={0.1}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Typography Preview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div 
                  style={{ 
                    fontFamily: currentTheme.typography.fontFamily,
                    fontSize: `${currentTheme.typography.fontSize.base}px`,
                    lineHeight: currentTheme.typography.lineHeight
                  }}
                >
                  <h1 style={{ fontSize: `${currentTheme.typography.fontSize.base * Math.pow(currentTheme.typography.fontSize.scale, 3)}px` }}>
                    Heading 1
                  </h1>
                  <h2 style={{ fontSize: `${currentTheme.typography.fontSize.base * Math.pow(currentTheme.typography.fontSize.scale, 2)}px` }}>
                    Heading 2
                  </h2>
                  <h3 style={{ fontSize: `${currentTheme.typography.fontSize.base * currentTheme.typography.fontSize.scale}px` }}>
                    Heading 3
                  </h3>
                  <p>
                    This is a paragraph of body text demonstrating the chosen typography settings. 
                    It shows how the font family, size, and line height work together.
                  </p>
                  <small style={{ fontSize: `${currentTheme.typography.fontSize.base * 0.875}px` }}>
                    Small text for captions and fine print.
                  </small>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="spacing" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Spacing & Layout</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Spacing Scale: {currentTheme.spacing.scale}</Label>
                  <Slider
                    value={[currentTheme.spacing.scale]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      spacing: { ...prev.spacing, scale: value[0] }
                    }))}
                    max={1.5}
                    min={0.5}
                    step={0.1}
                  />
                </div>

                <div>
                  <Label>Container Padding: {currentTheme.spacing.containerPadding}px</Label>
                  <Slider
                    value={[currentTheme.spacing.containerPadding]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      spacing: { ...prev.spacing, containerPadding: value[0] }
                    }))}
                    max={48}
                    min={8}
                    step={4}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Border Radius</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Small: {currentTheme.borderRadius.small}px</Label>
                  <Slider
                    value={[currentTheme.borderRadius.small]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      borderRadius: { ...prev.borderRadius, small: value[0] }
                    }))}
                    max={16}
                    min={0}
                    step={1}
                  />
                </div>

                <div>
                  <Label>Medium: {currentTheme.borderRadius.medium}px</Label>
                  <Slider
                    value={[currentTheme.borderRadius.medium]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      borderRadius: { ...prev.borderRadius, medium: value[0] }
                    }))}
                    max={24}
                    min={0}
                    step={1}
                  />
                </div>

                <div>
                  <Label>Large: {currentTheme.borderRadius.large}px</Label>
                  <Slider
                    value={[currentTheme.borderRadius.large]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      borderRadius: { ...prev.borderRadius, large: value[0] }
                    }))}
                    max={32}
                    min={0}
                    step={2}
                  />
                </div>

                <div className="space-y-2">
                  <p className="text-sm">Preview:</p>
                  <div className="flex gap-2">
                    <div 
                      className="w-12 h-8 bg-primary"
                      style={{ borderRadius: `${currentTheme.borderRadius.small}px` }}
                    />
                    <div 
                      className="w-12 h-8 bg-primary"
                      style={{ borderRadius: `${currentTheme.borderRadius.medium}px` }}
                    />
                    <div 
                      className="w-12 h-8 bg-primary"
                      style={{ borderRadius: `${currentTheme.borderRadius.large}px` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Effects</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Enable Shadows</Label>
                <Switch
                  checked={currentTheme.shadows.enabled}
                  onCheckedChange={(checked) => setCurrentTheme(prev => ({
                    ...prev,
                    shadows: { ...prev.shadows, enabled: checked }
                  }))}
                />
              </div>

              {currentTheme.shadows.enabled && (
                <div>
                  <Label>Shadow Intensity: {currentTheme.shadows.intensity}</Label>
                  <Slider
                    value={[currentTheme.shadows.intensity]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      shadows: { ...prev.shadows, intensity: value[0] }
                    }))}
                    max={0.5}
                    min={0.05}
                    step={0.05}
                  />
                </div>
              )}

              <div className="flex items-center justify-between">
                <Label>Enable Animations</Label>
                <Switch
                  checked={currentTheme.animations.enabled}
                  onCheckedChange={(checked) => setCurrentTheme(prev => ({
                    ...prev,
                    animations: { ...prev.animations, enabled: checked }
                  }))}
                />
              </div>

              {currentTheme.animations.enabled && (
                <div>
                  <Label>Animation Duration: {currentTheme.animations.duration}ms</Label>
                  <Slider
                    value={[currentTheme.animations.duration]}
                    onValueChange={(value) => setCurrentTheme(prev => ({
                      ...prev,
                      animations: { ...prev.animations, duration: value[0] }
                    }))}
                    max={500}
                    min={100}
                    step={50}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="themes">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Current Theme</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={exportTheme}>
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                    <Button variant="outline" onClick={() => document.getElementById('theme-import')?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      Import
                    </Button>
                    <input
                      id="theme-import"
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={importTheme}
                    />
                    <Button onClick={saveTheme}>
                      Save Theme
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="theme-name">Theme Name</Label>
                  <Input
                    id="theme-name"
                    value={currentTheme.name}
                    onChange={(e) => setCurrentTheme(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="My Custom Theme"
                  />
                </div>
                <div>
                  <Label htmlFor="theme-description">Description</Label>
                  <Input
                    id="theme-description"
                    value={currentTheme.description}
                    onChange={(e) => setCurrentTheme(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Theme description"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedThemes.map(theme => (
                <Card key={theme.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-base">{theme.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {new Date(theme.created_at).toLocaleDateString()}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex gap-1">
                        <div 
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: theme.colors.light.primary }}
                        />
                        <div 
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: theme.colors.light.secondary }}
                        />
                        <div 
                          className="w-4 h-4 rounded-full border"
                          style={{ backgroundColor: theme.colors.light.accent }}
                        />
                      </div>
                      <p className="text-sm text-muted-foreground">{theme.description}</p>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => loadTheme(theme)}>
                          Load
                        </Button>
                        <Button size="sm" variant="outline">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}