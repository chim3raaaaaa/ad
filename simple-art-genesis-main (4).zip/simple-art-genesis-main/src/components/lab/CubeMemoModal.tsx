import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMemoContext } from "@/contexts/MemoContext";
import { memoApiService, MemoReferenceData } from "@/services/api/memoApiService";

interface CubeMemoModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

interface CubeProductionData {
  productionDate: string;
  testDate: string;
  ageDays: number;
  mixDesign: string;
  gradeMpa: string;
  machineNo: string;
  sampleId: string;
  cubeSize: string;
  remarks: string;
}

export function CubeMemoModal({ isOpen, onOpenChange }: CubeMemoModalProps) {
  const { toast } = useToast();
  const { addMemo } = useMemoContext();

  // Form state
  const [formData, setFormData] = useState({
    reference: '',
    labSite: '',
    officerInCharge: '',
    cubesCount: 0,
    typeOfTest: 'Standard',
    testPerformed: 'Compressive Strength',
    remarks: '',
    date: new Date().toISOString().split('T')[0],
    retest: 'No',
    postedBy: ''
  });

  const [productions, setProductions] = useState<CubeProductionData[]>([
    {
      productionDate: new Date().toISOString().split('T')[0],
      testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      ageDays: 7,
      mixDesign: '',
      gradeMpa: '',
      machineNo: '',
      sampleId: '',
      cubeSize: '150mm',
      remarks: ''
    }
  ]);

  // Loading states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [isGeneratingRef, setIsGeneratingRef] = useState(false);

  // Reference data
  const [referenceData, setReferenceData] = useState<MemoReferenceData>({
    categories: [],
    products: {},
    labTests: {},
    machines: {},
    moulds: {},
    officers: [],
    labSites: []
  });

  // Initialize reference data on mount
  useEffect(() => {
    const initializeData = async () => {
      if (!isOpen) return;
      
      setIsLoadingData(true);
      try {
        const data = await memoApiService.loadReferenceData();
        setReferenceData(data);

        if (data.labSites.length > 0) {
          setFormData(prev => ({ 
            ...prev, 
            labSite: data.labSites[0],
            postedBy: 'Current User'
          }));
        }
      } catch (error) {
        console.error('Failed to initialize form data:', error);
        toast({
          title: "Warning",
          description: "Failed to load reference data. Some dropdowns may be empty.",
          variant: "destructive"
        });
      } finally {
        setIsLoadingData(false);
      }
    };

    initializeData();
  }, [isOpen, toast]);

  // Generate cube-specific reference number
  const generateReference = async () => {
    setIsGeneratingRef(true);
    try {
      const cubeReference = await memoApiService.generateNextReference('cubes');
      setFormData(prev => ({ ...prev, reference: cubeReference }));
      toast({
        title: "Reference Generated",
        description: `Generated reference: ${cubeReference}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate reference number",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingRef(false);
    }
  };

  const addProduction = () => {
    setProductions([...productions, {
      productionDate: new Date().toISOString().split('T')[0],
      testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      ageDays: 7,
      mixDesign: '',
      gradeMpa: '',
      machineNo: '',
      sampleId: '',
      cubeSize: '150mm',
      remarks: ''
    }]);
  };

  const removeProduction = (index: number) => {
    if (productions.length > 1) {
      setProductions(productions.filter((_, i) => i !== index));
    }
  };

  const updateProduction = (index: number, field: keyof CubeProductionData, value: any) => {
    const updated = [...productions];
    updated[index] = { ...updated[index], [field]: value };
    
    // Auto-calculate age if both dates are present
    if (field === 'productionDate' || field === 'testDate') {
      const prodDate = field === 'productionDate' ? value : updated[index].productionDate;
      const testDate = field === 'testDate' ? value : updated[index].testDate;
      
      if (prodDate && testDate) {
        updated[index].ageDays = memoApiService.calculateAge(prodDate, testDate);
      }
    }
    
    setProductions(updated);
  };

  const handleSubmit = async () => {
    if (!formData.reference || !formData.labSite || !formData.officerInCharge) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in Reference, Lab Site, and Officer In Charge.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Submit via API service with cube-specific data
      const submissionData = {
        reference: formData.reference,
        date: formData.date,
        labSite: formData.labSite,
        officerInCharge: formData.officerInCharge,
        lorry: '',
        blocksCount: formData.cubesCount,
        typeOfTest: formData.typeOfTest,
        testPerformed: formData.testPerformed,
        retest: formData.retest,
        postedBy: formData.postedBy,
        productions: productions.map(prod => ({
          productionDate: prod.productionDate,
          testDate: prod.testDate,
          ageDays: prod.ageDays,
          category: 'cubes',
          product: prod.mixDesign,
          gradeMpa: prod.gradeMpa,
          machineNo: prod.machineNo,
          mouldRef: prod.sampleId,
          sampleCount: 1,
          blockPosition: prod.cubeSize,
          remarks: prod.remarks
        })),
        remarks: formData.remarks
      };

      const result = await memoApiService.submitMemo(submissionData);
      
      if (!result.success) {
        toast({
          title: "Submission Failed",
          description: result.error || "Failed to submit memo",
          variant: "destructive"
        });
        return;
      }

      // Create memo for context
      const newMemo = {
        id: result.id || `memo-${Date.now()}`,
        reference: formData.reference,
        filename: undefined,
        sender: formData.postedBy,
        subject: `Cube Test Request - ${formData.testPerformed}`,
        status: 'pending' as const,
        category: 'cubes',
        extractedData: {
          date: formData.date,
          site: formData.labSite,
          officer: formData.officerInCharge,
          testType: formData.typeOfTest,
          product: productions[0]?.mixDesign || '',
          clientName: undefined,
          sampleType: 'Concrete Cubes',
          siteSupervisor: undefined,
          blocksRequired: formData.cubesCount,
          lorry: ''
        },
        labSite: formData.labSite,
        officerInCharge: formData.officerInCharge,
        blocksCount: formData.cubesCount,
        testPerformed: formData.testPerformed,
        retest: formData.retest,
        postedBy: formData.postedBy,
        productions: productions.map(prod => ({
          productionDate: prod.productionDate,
          testDate: prod.testDate,
          ageDays: prod.ageDays,
          product: prod.mixDesign,
          gradeMpa: prod.gradeMpa,
          machineNo: prod.machineNo,
          mouldRef: prod.sampleId,
          sampleCount: 1,
          blockPosition: prod.cubeSize,
          additionalRemarks: prod.remarks
        })),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      addMemo(newMemo);
      
      toast({
        title: "Cube Memo Created",
        description: `Memo ${formData.reference} has been created successfully.`
      });

      // Reset form
      setFormData({
        reference: '',
        labSite: referenceData.labSites[0] || '',
        officerInCharge: '',
        cubesCount: 0,
        typeOfTest: 'Standard',
        testPerformed: 'Compressive Strength',
        remarks: '',
        date: new Date().toISOString().split('T')[0],
        retest: 'No',
        postedBy: 'Current User'
      });
      
      setProductions([{
        productionDate: new Date().toISOString().split('T')[0],
        testDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        ageDays: 7,
        mixDesign: '',
        gradeMpa: '',
        machineNo: '',
        sampleId: '',
        cubeSize: '150mm',
        remarks: ''
      }]);

      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create cube memo. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingData) {
    return (
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl">
          <div className="flex items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Loading reference data...</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Cube Memo</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Cube Memo Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="reference">Reference *</Label>
                <div className="flex gap-2">
                  <Input
                    id="reference"
                    value={formData.reference}
                    onChange={(e) => setFormData({...formData, reference: e.target.value})}
                    placeholder="RTC240725001"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={generateReference}
                    disabled={isGeneratingRef}
                  >
                    {isGeneratingRef ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="labSite">Lab Site *</Label>
                <Select 
                  value={formData.labSite} 
                  onValueChange={(value) => setFormData({...formData, labSite: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select lab site" />
                  </SelectTrigger>
                  <SelectContent>
                    {referenceData.labSites.map(site => (
                      <SelectItem key={site} value={site}>
                        {site}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="officerInCharge">Officer In Charge *</Label>
                <Select 
                  value={formData.officerInCharge} 
                  onValueChange={(value) => setFormData({...formData, officerInCharge: value})}
                  disabled={!formData.labSite}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select officer" />
                  </SelectTrigger>
                  <SelectContent>
                    {referenceData.officers
                      .filter(officer => !formData.labSite || officer.labSite === formData.labSite)
                      .map(officer => (
                      <SelectItem key={officer.id} value={officer.name}>
                        {officer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="cubesCount">No. Cubes Sent</Label>
                <Input
                  id="cubesCount"
                  type="number"
                  value={formData.cubesCount}
                  onChange={(e) => setFormData({...formData, cubesCount: parseInt(e.target.value) || 0})}
                  placeholder="12"
                />
              </div>
              <div>
                <Label htmlFor="typeOfTest">Type of Test</Label>
                <Select value={formData.typeOfTest} onValueChange={(value) => setFormData({...formData, typeOfTest: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Express">Express</SelectItem>
                    <SelectItem value="Special">Special</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="testPerformed">Test Performed</Label>
                <Select value={formData.testPerformed} onValueChange={(value) => setFormData({...formData, testPerformed: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Compressive Strength">Compressive Strength</SelectItem>
                    <SelectItem value="Density Test">Density Test</SelectItem>
                    <SelectItem value="Water Absorption">Water Absorption</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="retest">Retest</Label>
                <Select value={formData.retest} onValueChange={(value) => setFormData({...formData, retest: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="No">No</SelectItem>
                    <SelectItem value="Yes">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Production Details */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Cube Production Details</CardTitle>
              <Button onClick={addProduction} size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Production
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {productions.map((production, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">Production {index + 1}</Badge>
                    {productions.length > 1 && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeProduction(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Production Date</Label>
                      <Input
                        type="date"
                        value={production.productionDate}
                        onChange={(e) => updateProduction(index, 'productionDate', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Test Date</Label>
                      <Input
                        type="date"
                        value={production.testDate}
                        onChange={(e) => updateProduction(index, 'testDate', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Age (days)</Label>
                      <Input
                        type="number"
                        value={production.ageDays}
                        onChange={(e) => updateProduction(index, 'ageDays', parseInt(e.target.value) || 0)}
                        readOnly
                        className="bg-muted"
                      />
                    </div>
                    <div>
                      <Label>Mix Design</Label>
                      <Input
                        value={production.mixDesign}
                        onChange={(e) => updateProduction(index, 'mixDesign', e.target.value)}
                        placeholder="C25/30"
                      />
                    </div>
                    <div>
                      <Label>Grade (MPA)</Label>
                      <Input
                        value={production.gradeMpa}
                        onChange={(e) => updateProduction(index, 'gradeMpa', e.target.value)}
                        placeholder="25"
                      />
                    </div>
                    <div>
                      <Label>Machine No</Label>
                      <Select 
                        value={production.machineNo} 
                        onValueChange={(value) => updateProduction(index, 'machineNo', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select machine" />
                        </SelectTrigger>
                        <SelectContent>
                          {(referenceData.machines[formData.labSite] || []).map(machine => (
                            <SelectItem key={machine.code} value={machine.code}>
                              {machine.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Sample ID</Label>
                      <Input
                        value={production.sampleId}
                        onChange={(e) => updateProduction(index, 'sampleId', e.target.value)}
                        placeholder="CUBE001"
                      />
                    </div>
                    <div>
                      <Label>Cube Size</Label>
                      <Select 
                        value={production.cubeSize} 
                        onValueChange={(value) => updateProduction(index, 'cubeSize', value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="100mm">100mm</SelectItem>
                          <SelectItem value="150mm">150mm</SelectItem>
                          <SelectItem value="200mm">200mm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-3">
                      <Label>Remarks</Label>
                      <Textarea
                        value={production.remarks}
                        onChange={(e) => updateProduction(index, 'remarks', e.target.value)}
                        placeholder="Additional notes..."
                        rows={2}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Additional Remarks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Additional Remarks</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.remarks}
                onChange={(e) => setFormData({...formData, remarks: e.target.value})}
                placeholder="Enter any additional remarks or notes..."
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Cube Memo'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}