import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Upload, FileSpreadsheet, CheckCircle, XCircle, Clock } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';

interface UploadStatus {
  filename: string;
  status: 'uploading' | 'success' | 'error';
  message: string;
  rowsImported?: number;
  timestamp: Date;
}

interface TableInfo {
  tableName: string;
  displayName: string;
  rowCount: number;
  lastUpdated?: Date;
}

const SUPPORTED_FILES = [
  {
    name: 'product_categories.csv',
    description: 'Product Categories',
    example: 'category_id, name, description',
    requiredColumns: ['category_id', 'name']
  },
  {
    name: 'products.csv',
    description: 'Product List with Category Mapping',
    example: 'product_id, name, category_id, grade_id, test_module',
    requiredColumns: ['product_id', 'name', 'category_id', 'test_module']
  },
  {
    name: 'grades.csv',
    description: 'Product Grades',
    example: 'grade_id, name, description',
    requiredColumns: ['grade_id', 'name']
  },
  {
    name: 'machines.csv',
    description: 'Testing Machines',
    example: 'machine_id, name, type, location',
    requiredColumns: ['machine_id', 'name']
  },
  {
    name: 'moulds.csv',
    description: 'Testing Moulds',
    example: 'mould_id, name, type, dimensions',
    requiredColumns: ['mould_id', 'name']
  },
  {
    name: 'test_types.csv',
    description: 'Test Types',
    example: 'test_type_id, name, description, category',
    requiredColumns: ['test_type_id', 'name']
  },
  {
    name: 'officers.csv',
    description: 'Lab Officers',
    example: 'officer_id, name, role, department',
    requiredColumns: ['officer_id', 'name']
  },
  {
    name: 'lab_sites.csv',
    description: 'Laboratory Sites',
    example: 'site_id, name, location, capacity',
    requiredColumns: ['site_id', 'name']
  }
];

export function ReferenceDataUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadHistory, setUploadHistory] = useState<UploadStatus[]>([]);
  const [tableInfo, setTableInfo] = useState<TableInfo[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    initializeAndLoadData();
  }, []);

  const initializeAndLoadData = async () => {
    try {
      await enhancedReferenceDataService.initializeAllReferenceTables();
      await loadTableInfo();
    } catch (error) {
      console.error('Failed to initialize reference data:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to initialize reference data tables",
        variant: "destructive"
      });
    }
  };

  const loadTableInfo = async () => {
    try {
      const tables = [
        { tableName: 'product_categories', displayName: 'Product Categories' },
        { tableName: 'products', displayName: 'Products' },
        { tableName: 'grades', displayName: 'Grades' },
        { tableName: 'machines', displayName: 'Machines' },
        { tableName: 'moulds', displayName: 'Moulds' },
        { tableName: 'test_types', displayName: 'Test Types' },
        { tableName: 'officers', displayName: 'Officers' },
        { tableName: 'lab_sites', displayName: 'Lab Sites' }
      ];

      const tableInfoData: TableInfo[] = [];
      
      for (const table of tables) {
        try {
          let data: any[] = [];
          switch (table.tableName) {
            case 'product_categories':
              data = await enhancedReferenceDataService.getProductCategories();
              break;
            case 'products':
              data = await enhancedReferenceDataService.getAllProducts();
              break;
            case 'grades':
              data = await enhancedReferenceDataService.getGrades();
              break;
            case 'machines':
              data = await enhancedReferenceDataService.getMachines();
              break;
            case 'moulds':
              data = await enhancedReferenceDataService.getMouldReferences();
              break;
            case 'test_types':
              data = await enhancedReferenceDataService.getTestTypes();
              break;
            case 'officers':
              data = await enhancedReferenceDataService.getOfficers();
              break;
            case 'lab_sites':
              data = await enhancedReferenceDataService.getPlants();
              break;
          }
          
          tableInfoData.push({
            tableName: table.tableName,
            displayName: table.displayName,
            rowCount: data.length,
            lastUpdated: new Date()
          });
        } catch (error) {
          console.error(`Failed to load ${table.tableName}:`, error);
          tableInfoData.push({
            tableName: table.tableName,
            displayName: table.displayName,
            rowCount: 0
          });
        }
      }
      
      setTableInfo(tableInfoData);
    } catch (error) {
      console.error('Failed to load table info:', error);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      validateAndSetFile(file);
    }
  };

  const validateAndSetFile = (file: File) => {
    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please select a CSV file",
        variant: "destructive"
      });
      return;
    }

    const supportedFile = SUPPORTED_FILES.find(sf => 
      file.name.toLowerCase().includes(sf.name.toLowerCase().replace('.csv', ''))
    );

    if (!supportedFile) {
      toast({
        title: "Unsupported File",
        description: `File ${file.name} is not recognized as a supported reference dataset`,
        variant: "destructive"
      });
      return;
    }

    setSelectedFile(file);
    toast({
      title: "File Selected",
      description: `Ready to import ${supportedFile.description}`
    });
  };

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      validateAndSetFile(files[0]);
    }
  };

  const processUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // Read file content
      const content = await readFileContent(selectedFile);
      setUploadProgress(30);

      // Import data
      await enhancedReferenceDataService.importReferenceData(selectedFile.name, content);
      setUploadProgress(80);

      // Refresh table info
      await loadTableInfo();
      setUploadProgress(100);

      // Add to upload history
      const uploadStatus: UploadStatus = {
        filename: selectedFile.name,
        status: 'success',
        message: 'Import completed successfully',
        timestamp: new Date()
      };
      
      setUploadHistory(prev => [uploadStatus, ...prev].slice(0, 10));
      setSelectedFile(null);
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

    } catch (error) {
      console.error('Upload failed:', error);
      
      const uploadStatus: UploadStatus = {
        filename: selectedFile.name,
        status: 'error',
        message: `Import failed: ${error}`,
        timestamp: new Date()
      };
      
      setUploadHistory(prev => [uploadStatus, ...prev].slice(0, 10));
      
      toast({
        title: "Upload Failed",
        description: `Failed to import ${selectedFile.name}: ${error}`,
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        resolve(event.target?.result as string);
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsText(file);
    });
  };

  const formatTimestamp = (timestamp: Date) => {
    return timestamp.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Reference Datasets
          </CardTitle>
          <CardDescription>
            Import CSV files to populate reference data for product categories, machines, officers, and more.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Drag & Drop Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragOver 
                ? 'border-primary bg-primary/5' 
                : 'border-muted-foreground/25 hover:border-muted-foreground/50'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <FileSpreadsheet className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <div className="space-y-2">
              <p className="text-lg font-medium">Drop CSV files here or click to select</p>
              <p className="text-sm text-muted-foreground">
                Supported: Product Categories, Products, Grades, Machines, Moulds, Test Types, Officers, Lab Sites
              </p>
            </div>
            <Input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              Select CSV File
            </Button>
          </div>

          {/* Selected File & Upload */}
          {selectedFile && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="h-5 w-5" />
                  <div>
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(selectedFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                </div>
                <Button onClick={processUpload} disabled={isUploading}>
                  {isUploading ? 'Importing...' : 'Import Data'}
                </Button>
              </div>
              
              {isUploading && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} />
                  <p className="text-sm text-center text-muted-foreground">
                    Importing data... {uploadProgress}%
                  </p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Current Data Status */}
      <Card>
        <CardHeader>
          <CardTitle>Reference Data Status</CardTitle>
          <CardDescription>
            Current status of reference data tables in the local database.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Table</TableHead>
                <TableHead>Records</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tableInfo.map((table) => (
                <TableRow key={table.tableName}>
                  <TableCell className="font-medium">{table.displayName}</TableCell>
                  <TableCell>{table.rowCount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={table.rowCount > 0 ? "default" : "secondary"}>
                      {table.rowCount > 0 ? "Populated" : "Empty"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {table.lastUpdated ? formatTimestamp(table.lastUpdated) : 'Never'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Supported Files */}
      <Card>
        <CardHeader>
          <CardTitle>Supported File Formats</CardTitle>
          <CardDescription>
            CSV file formats that can be imported as reference datasets.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {SUPPORTED_FILES.map((file) => (
              <div key={file.name} className="border rounded-lg p-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{file.description}</h4>
                    <Badge variant="outline">{file.name}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Required columns: {file.requiredColumns.join(', ')}
                  </p>
                  <p className="text-xs font-mono bg-muted p-2 rounded">
                    {file.example}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upload History */}
      {uploadHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Uploads</CardTitle>
            <CardDescription>
              History of recent reference data imports.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {uploadHistory.map((upload, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {upload.status === 'success' && <CheckCircle className="h-5 w-5 text-green-600" />}
                    {upload.status === 'error' && <XCircle className="h-5 w-5 text-red-600" />}
                    {upload.status === 'uploading' && <Clock className="h-5 w-5 text-blue-600" />}
                    <div>
                      <p className="font-medium">{upload.filename}</p>
                      <p className="text-sm text-muted-foreground">{upload.message}</p>
                    </div>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    {formatTimestamp(upload.timestamp)}
                    {upload.rowsImported && (
                      <div>{upload.rowsImported} rows imported</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}