import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { CalendarIcon, Calculator, Save, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { directInputService } from "@/services/database/DirectInputService";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface OperatorTestEntryFormProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (result: any) => void;
  defaultProductType?: string;
}

export function OperatorTestEntryForm({ 
  isOpen, 
  onOpenChange, 
  onSuccess, 
  defaultProductType = "blocks" 
}: OperatorTestEntryFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [productionDate, setProductionDate] = useState<Date>();
  const [testDate, setTestDate] = useState<Date>(new Date());
  const [ageDays, setAgeDays] = useState<number>(0);

  const [formData, setFormData] = useState({
    memo_reference: '',
    operator_name: '',
    machine_no: '',
    product: '',
    load_kn: '',
    weight_kg: '',
    strength_mpa: '',
    product_type: defaultProductType
  });

  // Auto-calculate age when dates change
  useEffect(() => {
    if (productionDate && testDate) {
      const diffTime = testDate.getTime() - productionDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setAgeDays(Math.max(0, diffDays));
    }
  }, [productionDate, testDate]);

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setFormData({
        memo_reference: '',
        operator_name: '',
        machine_no: '',
        product: '',
        load_kn: '',
        weight_kg: '',
        strength_mpa: '',
        product_type: defaultProductType
      });
      setProductionDate(undefined);
      setTestDate(new Date());
      setAgeDays(0);
    }
  }, [isOpen, defaultProductType]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.memo_reference.trim()) {
      toast({
        title: "Validation Error",
        description: "Memo reference is required",
        variant: "destructive"
      });
      return;
    }

    if (!productionDate || !testDate) {
      toast({
        title: "Validation Error",
        description: "Both production and test dates are required",
        variant: "destructive"
      });
      return;
    }

    if (!formData.operator_name.trim()) {
      toast({
        title: "Validation Error",
        description: "Operator name is required",
        variant: "destructive"
      });
      return;
    }

    if (!formData.load_kn || parseFloat(formData.load_kn) <= 0) {
      toast({
        title: "Validation Error",
        description: "Valid load (kN) value is required",
        variant: "destructive"
      });
      return;
    }

    if (!formData.weight_kg || parseFloat(formData.weight_kg) <= 0) {
      toast({
        title: "Validation Error",
        description: "Valid weight (kg) value is required",
        variant: "destructive"
      });
      return;
    }

    if (!formData.strength_mpa || parseFloat(formData.strength_mpa) <= 0) {
      toast({
        title: "Validation Error",
        description: "Valid strength (MPa) value is required",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const result = await directInputService.createDirectInputResult({
        memo_reference: formData.memo_reference.trim(),
        production_date: format(productionDate, 'yyyy-MM-dd'),
        test_date: format(testDate, 'yyyy-MM-dd'),
        age_days: ageDays,
        operator_name: formData.operator_name.trim(),
        machine_no: formData.machine_no.trim(),
        product: formData.product.trim(),
        load_kn: parseFloat(formData.load_kn),
        weight_kg: parseFloat(formData.weight_kg),
        strength_mpa: parseFloat(formData.strength_mpa),
        product_type: formData.product_type,
        created_by: 'manual_entry',
        data_source: 'manual',
        status: 'pending'
      });

      // Success - result is always valid from our service
      onSuccess(result);
      onOpenChange(false);
      
      toast({
        title: "Success",
        description: "Test result saved successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save test result",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStrengthStatus = () => {
    const strength = parseFloat(formData.strength_mpa);
    if (isNaN(strength) || strength <= 0) return null;
    
    // Basic threshold logic - can be enhanced with proper validation rules
    if (strength >= 30) return { status: 'excellent', color: 'bg-green-100 text-green-800' };
    if (strength >= 20) return { status: 'pass', color: 'bg-blue-100 text-blue-800' };
    return { status: 'fail', color: 'bg-red-100 text-red-800' };
  };

  const strengthStatus = getStrengthStatus();

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Calculator className="h-5 w-5 mr-2" />
            Concrete Product Test Entry - {formData.product_type.charAt(0).toUpperCase() + formData.product_type.slice(1)}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Product Type Selection */}
          <Card>
            <CardContent className="p-4">
              <div className="space-y-2">
                <Label htmlFor="product_type">Product Type</Label>
                <Select 
                  value={formData.product_type} 
                  onValueChange={(value) => handleInputChange('product_type', value)}
                >
                  <SelectTrigger className="h-12 text-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blocks">Blocks</SelectItem>
                    <SelectItem value="cubes">Cubes</SelectItem>
                    <SelectItem value="pavers">Pavers</SelectItem>
                    <SelectItem value="kerbs">Kerbs</SelectItem>
                    <SelectItem value="flagstones">Flagstones</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column - Basic Information */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <h3 className="font-medium text-lg">Basic Information</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="memo_reference">Memo Reference *</Label>
                  <Input
                    id="memo_reference"
                    value={formData.memo_reference}
                    onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                    placeholder="Enter memo reference"
                    className="h-12 text-lg"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="operator_name">Operator *</Label>
                  <Input
                    id="operator_name"
                    value={formData.operator_name}
                    onChange={(e) => handleInputChange('operator_name', e.target.value)}
                    placeholder="Enter operator name"
                    className="h-12 text-lg"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="machine_no">Machine</Label>
                  <Input
                    id="machine_no"
                    value={formData.machine_no}
                    onChange={(e) => handleInputChange('machine_no', e.target.value)}
                    placeholder="Enter machine number"
                    className="h-12 text-lg"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="product">Product</Label>
                  <Input
                    id="product"
                    value={formData.product}
                    onChange={(e) => handleInputChange('product', e.target.value)}
                    placeholder="Enter product name"
                    className="h-12 text-lg"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Right Column - Test Information */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <h3 className="font-medium text-lg">Test Information</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Production Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "h-12 w-full justify-start text-left font-normal text-lg",
                            !productionDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {productionDate ? format(productionDate, "PPP") : "Pick date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={productionDate}
                          onSelect={setProductionDate}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Test Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="h-12 w-full justify-start text-left font-normal text-lg"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(testDate, "PPP")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={testDate}
                          onSelect={(date) => date && setTestDate(date)}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Age (days)</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      value={ageDays}
                      readOnly
                      className="h-12 text-lg font-medium bg-muted"
                    />
                    <Badge variant="outline">Auto-calculated</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="load_kn">Load (kN) *</Label>
                    <Input
                      id="load_kn"
                      type="number"
                      step="0.1"
                      min="0"
                      value={formData.load_kn}
                      onChange={(e) => handleInputChange('load_kn', e.target.value)}
                      placeholder="0.0"
                      className="h-12 text-lg"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="weight_kg">Weight (kg) *</Label>
                    <Input
                      id="weight_kg"
                      type="number"
                      step="0.1"
                      min="0"
                      value={formData.weight_kg}
                      onChange={(e) => handleInputChange('weight_kg', e.target.value)}
                      placeholder="0.0"
                      className="h-12 text-lg"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="strength_mpa">Strength (MPa) *</Label>
                    <div className="space-y-2">
                      <Input
                        id="strength_mpa"
                        type="number"
                        step="0.1"
                        min="0"
                        value={formData.strength_mpa}
                        onChange={(e) => handleInputChange('strength_mpa', e.target.value)}
                        placeholder="0.0"
                        className="h-12 text-lg"
                        required
                      />
                      {strengthStatus && (
                        <Badge className={strengthStatus.color}>
                          {strengthStatus.status.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-4 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
              className="h-12 px-8"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-12 px-8 bg-primary hover:bg-primary/90"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Test Result
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}