import { useState, useRef, useEffect } from "react";
import { ChevronDown, ChevronRight, Folder, FolderOpen, Download, Upload, Printer, RefreshCw, Eye, FileText, Trash2, Plus, Sheet, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useMemoContext, type MemoData } from "@/contexts/MemoContext";
import { CategoryToggleSelector } from "@/components/test-modules/CategoryToggleSelector";
import { MemoFormModal } from "@/components/lab/MemoFormModal";
import { AggregateModalForm } from "@/components/lab/AggregateModalForm";
import { CubeMemoModal } from "@/components/lab/CubeMemoModal";
import { PaverMemoModal } from "@/components/lab/PaverMemoModal";
import { KerbMemoModal } from "@/components/lab/KerbMemoModal";
import { FlagstoneMemoModal } from "@/components/lab/FlagstoneMemoModal";
import { ProductionPdfExtractor, type MemoData as ExtractedMemoData } from "@/lib/productionPdfExtractor";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MemoInboxTab } from "@/components/lab/MemoInboxTab";

// Default category configuration - will be loaded from database
const DEFAULT_CATEGORY_CONFIG = {
  title: "Testing – Memo Management",
  memoColumns: ["Reference", "Lab Site", "Date", "Officer", "Type", "Productions", "Actions"],
  productionColumns: ["Production No", "Production Date", "Test Date", "Age (days)", "Product", "Grade", "Machine No", "Sample ID", "Remarks"],
  modalComponent: "MemoFormModal"
};

interface ProductionData {
  Production_Label: string;
  Production_Date: string;
  Test_Date: string;
  Age_days: number;
  Product: string;
  Grade_MPA: number;
  Machine_No: string;
  Mould_Ref: string;
  Production_P: number;
  No_Samp_for_Test: number;
  Block_pos_No: string;
}

// Data clearing utilities
const clearTestData = () => {
  if (!window.electronAPI) {
    localStorage.removeItem('lab-memos');
    console.log('Test data cleared from localStorage');
  }
};

export function MemoManagement() {
  const [selectedCategory, setSelectedCategory] = useState<string>('blocks');
  const [activeTab, setActiveTab] = useState<string>('inbox');
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { memos, addMemo, updateMemo, refreshMemos, deleteMemo, submitMemoToInbox } = useMemoContext();
  const [showMemoFormModal, setShowMemoFormModal] = useState(false);
  const [showExcelModal, setShowExcelModal] = useState(false);
  const [excelData, setExcelData] = useState<any[]>([]);
  const [selectedMemoForExcel, setSelectedMemoForExcel] = useState<any>(null);
  
  const [selectedMemoId, setSelectedMemoId] = useState<string>(memos[0]?.id || "");
  const [isProcessing, setIsProcessing] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<{isOpen: boolean, memoId: string, memoRef: string}>({
    isOpen: false,
    memoId: "",
    memoRef: ""
  });
  const [extractedData, setExtractedData] = useState<ExtractedMemoData | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [showExtractionDialog, setShowExtractionDialog] = useState(false);
  
  // Initialize component
  useEffect(() => {
    // Component initialization logic if needed
  }, []);
  
  // Get current category configuration
  const currentConfig = DEFAULT_CATEGORY_CONFIG;
  const currentMemo = memos.find(m => m.id === selectedMemoId) || memos[0];

  // Filter memos by category
  const filteredMemos = memos.filter(memo => {
    // Filter by category if memo has category field
    if (memo.category) {
      return memo.category === selectedCategory;
    }
    // For legacy memos without category, show in blocks by default
    return selectedCategory === 'blocks';
  });

  const refreshMemoData = () => {
    console.log("Refreshing memo data...");
    refreshMemos();
    toast({
      title: "Data Refreshed",
      description: "Memo data has been refreshed successfully.",
    });
  };

  const handleSelectMemo = (memoId: string) => {
    setSelectedMemoId(memoId);
  };

  const handleReadMemo = (memoId: string) => {
    console.log("Opening memo:", memoId);
    setSelectedMemoId(memoId);
    const memoDetails = document.getElementById('memo-details');
    if (memoDetails) {
      memoDetails.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleImport = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      console.log("Imported file:", file.name);
      
      // Check for duplicate memos by filename
      const duplicateByFilename = memos.find(memo => memo.filename === file.name);
      
      if (duplicateByFilename) {
        toast({
          title: "Duplicate Memo Detected",
          description: `A memo with this filename already exists. Please check existing memos.`,
          variant: "destructive",
        });
        event.target.value = '';
        return;
      }
      
      setIsProcessing(true);
      
      try {
        // Check if it's a PDF file for special processing
        const fileExtension = file.name.toLowerCase().split('.').pop();
        let extractedPdfData: ExtractedMemoData | null = null;
        
        if (fileExtension === 'pdf') {
          await extractProductionData(file);
          return; // Exit early as extraction dialog will handle the rest
        }
        
        // Simple file import for non-PDF files
        const newMemoData = {
          id: `MEMO${Date.now()}`,
          reference: `MANUAL${Date.now()}`,
          filename: file.name,
          sender: "system@lab.com",
          subject: `Manual Import - ${file.name}`,
          status: "pending" as const,
          category: selectedCategory, // Add category to memo
          extractedData: {
            date: new Date().toLocaleDateString('en-GB'),
            site: "Manual Entry Required",
            officer: "Manual Entry Required", 
            testType: "Standard",
            product: "Manual Entry Required",
            clientName: "Manual Entry Required",
            sampleType: "Testing Sample",
            siteSupervisor: "Manual Entry Required",
            lorry: "Manual Entry Required",
            blocksRequired: 0
          },
          labSite: "Manual Entry Required",
          officerInCharge: "Manual Entry Required",
          blocksCount: 0,
          testPerformed: "Compressive Strength",
          retest: "No",
          postedBy: "Manual Import",
          productions: [],
          linkedReports: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          excelPath: ""
        };
        
        // Add to shared context
        addMemo(newMemoData);
        setSelectedMemoId(newMemoData.id);
        
        toast({
          title: "File Imported",
          description: `File ${file.name} imported. Please edit the memo to add details.`,
          action: (
            <Button size="sm" onClick={() => handleReadMemo(newMemoData.id)}>
              Read
            </Button>
          )
        });
        
        console.log('File imported:', newMemoData.reference);
        
      } catch (error) {
        console.error("Error importing file:", error);
        toast({
          title: "Import Error",
          description: "Failed to import the file. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsProcessing(false);
      }

      event.target.value = '';
    }
  };

  const extractProductionData = async (file: File) => {
    setIsExtracting(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      
      toast({
        title: "Extracting Data",
        description: "Extracting production data from PDF using OCR and text parsing...",
      });
      
      const extractedData = await ProductionPdfExtractor.extractProductionData(file);
      
      setExtractedData(extractedData);
      setShowExtractionDialog(true);
      
      toast({
        title: "Extraction Complete",
        description: `Extracted ${extractedData.productions.length} production(s) using ${extractedData.extractionMethod}`,
      });
      
      if (extractedData.missingFields.length > 0) {
        toast({
          title: "Review Required",
          description: `${extractedData.missingFields.length} fields need manual review`,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Extraction failed:", error);
      toast({
        title: "Extraction Failed",
        description: "Failed to extract production data from PDF. Please try manual entry.",
        variant: "destructive",
      });
    } finally {
      setIsExtracting(false);
    }
  };

  const handleImportExtractedData = () => {
    if (!extractedData) return;
    
    try {
      // Convert extracted data to memo format
      const newMemoData = {
        id: `MEMO${Date.now()}`,
        reference: extractedData.globalFields.referenceNo || `PDF${Date.now()}`,
        filename: `Extracted_${Date.now()}.pdf`,
        sender: "pdf-extractor@lab.com",
        subject: `PDF Import - ${extractedData.globalFields.referenceNo || 'Unknown'}`,
        status: "pending" as const,
        category: selectedCategory, // Add category to memo
        extractedData: {
          date: extractedData.globalFields.date || new Date().toLocaleDateString('en-GB'),
          site: extractedData.globalFields.site || "Extracted from PDF",
          officer: extractedData.globalFields.officer || "PDF Import", 
          testType: extractedData.globalFields.typeOfTest || "Standard",
          product: extractedData.productions[0]?.Product || "Extracted Product",
            clientName: "PDF Import",
            sampleType: "Testing Sample",
            siteSupervisor: extractedData.globalFields.officer || "PDF Import",
          lorry: extractedData.globalFields.lorry || "Not specified",
          blocksRequired: extractedData.productions.reduce((sum, p) => sum + (parseInt(p.numberOfSamples || '0') || 0), 0)
        },
        labSite: extractedData.globalFields.site || "PDF Import",
        officerInCharge: extractedData.globalFields.officer || "PDF Import",
        blocksCount: extractedData.productions.reduce((sum, p) => sum + (parseInt(p.numberOfSamples || '0') || 0), 0),
        testPerformed: extractedData.globalFields.typeOfTest || "Compressive Strength",
        retest: "No",
        postedBy: "PDF Extractor",
        productions: extractedData.productions.map(prod => ({
          Production_Label: prod.productionNumber,
          Production_Date: prod.productionDate || '',
          Test_Date: prod.testDate || '',
          Age_days: parseInt(prod.age?.replace(/\D/g, '') || '0') || 0,
          Product: prod.Product || '',
          Grade_MPA: parseFloat(prod.grade?.replace(/\D/g, '') || '0') || 0,
          Machine_No: prod.Machine_No || '',
          Mould_Ref: prod.Mould_Ref || '',
          Production_P: 0, // This might need to be extracted differently
          No_Samp_for_Test: parseInt(prod.numberOfSamples || '0') || 0,
          Block_pos_No: Array.isArray(prod.blockPositions) ? prod.blockPositions.join(', ') : (prod.blockPositions || '')
        })),
        linkedReports: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        excelPath: "",
        extractionMethod: extractedData.extractionMethod,
        missingFields: extractedData.missingFields
      };
      
      // Add to shared context
      addMemo(newMemoData);
      setSelectedMemoId(newMemoData.id);
      
      toast({
        title: "Data Imported",
        description: `PDF data imported successfully with ${extractedData.productions.length} production(s)`,
      });
      
      setShowExtractionDialog(false);
      setExtractedData(null);
      
      console.log('PDF data imported:', newMemoData.reference);
      
    } catch (error) {
      console.error("Error importing extracted data:", error);
      toast({
        title: "Import Error",
        description: "Failed to import the extracted data. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleExport = () => {
    console.log("Export triggered");
    
    const csvData = [
      currentConfig.productionColumns,
      ...currentMemo.productions.map(production => [
        production.Production_Label,
        production.Production_Date,
        production.Test_Date,
        production.Age_days.toString(),
        production.Product,
        production.Grade_MPA.toString(),
        production.Machine_No,
        production.Mould_Ref,
        production.Production_P.toString(),
        production.No_Samp_for_Test.toString(),
        production.Block_pos_No
      ])
    ];

    const csvContent = csvData
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${currentMemo.reference}_export.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: `${selectedCategory} testing data exported to CSV file successfully.`,
      });
    } else {
      toast({
        title: "Export Error",
        description: "File download not supported in this browser.",
        variant: "destructive",
      });
    }
  };

  const handlePrint = () => {
    console.log("Print triggered");
    window.print();
    toast({
      title: "Print",
      description: "Opening print dialog...",
    });
  };

  const handleDeleteMemo = (memoId: string, memoRef: string) => {
    setDeleteConfirm({
      isOpen: true,
      memoId,
      memoRef
    });
  };

  const confirmDeleteMemo = () => {
    deleteMemo(deleteConfirm.memoId);
    
    // If the deleted memo was selected, select the first available memo
    if (selectedMemoId === deleteConfirm.memoId) {
      const remainingMemos = memos.filter(m => m.id !== deleteConfirm.memoId);
      setSelectedMemoId(remainingMemos[0]?.id || "");
    }
    
    toast({
      title: "Memo Deleted",
      description: `Memo ${deleteConfirm.memoRef} has been deleted successfully.`,
    });
    
    setDeleteConfirm({
      isOpen: false,
      memoId: "",
      memoRef: ""
    });
    
    console.log('Memo deleted and synced across modules:', deleteConfirm.memoRef);
  };

  const handleViewExcel = async (memo: MemoData) => {
    try {
      setSelectedMemoForExcel(memo);
      
      // Extract tables from the original PDF file if available
      if (memo.filename) {
        // For demo purposes, we'll show the production data from the memo
        // In a real implementation, you would load the actual Excel data
        const mockExcelData = [
          {
            "Sheet": "Production Data",
            "Table 1": memo.productions && memo.productions.length > 0 ? memo.productions : [
              {
                "Production_Label": "Sample Data",
                "Production_Date": "2024-01-15",
                "Test_Date": "2024-01-22",
                "Age_days": 7,
                "Product": "Concrete Block",
                "Grade_MPA": 25,
                "Machine_No": "M001",
                "Mould_Ref": "MR001",
                "Production_P": 100,
                "No_Samp_for_Test": 3,
                "Block_pos_No": "1-A"
              }
            ]
          }
        ];
        
        setExcelData(mockExcelData);
        setShowExcelModal(true);
        
        toast({
          title: "Excel Data Loaded",
          description: "Click 'Download Excel' to get the extracted data file.",
        });
      } else {
        toast({
          title: "No Data Available",
          description: "No Excel data available for this memo.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error loading Excel data:", error);
      toast({
        title: "Error",
        description: "Failed to load Excel data.",
        variant: "destructive",
      });
    }
  };

  // Dynamic modal rendering
  const renderModal = () => {
    switch (selectedCategory) {
      case 'aggregates':
        return (
          <AggregateModalForm
            isOpen={showMemoFormModal}
            onClose={() => setShowMemoFormModal(false)}
            onSubmit={(data) => {
              console.log('Aggregate memo submitted:', data);
              setShowMemoFormModal(false);
            }}
            selectedCategory={selectedCategory}
          />
        );
      case 'blocks':
        return (
          <MemoFormModal
            isOpen={showMemoFormModal}
            onOpenChange={setShowMemoFormModal}
            selectedCategory={selectedCategory}
          />
        );
      case 'cubes':
        return (
          <CubeMemoModal
            isOpen={showMemoFormModal}
            onOpenChange={setShowMemoFormModal}
          />
        );
      case 'pavers':
        return (
          <PaverMemoModal
            isOpen={showMemoFormModal}
            onOpenChange={setShowMemoFormModal}
          />
        );
      case 'kerbs':
        return (
          <KerbMemoModal
            isOpen={showMemoFormModal}
            onOpenChange={setShowMemoFormModal}
          />
        );
      case 'flagstones':
        return (
          <FlagstoneMemoModal
            isOpen={showMemoFormModal}
            onOpenChange={setShowMemoFormModal}
          />
        );
      default:
        // For future categories, show a placeholder modal
        return (
          <Dialog open={showMemoFormModal} onOpenChange={setShowMemoFormModal}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{currentConfig.title}</DialogTitle>
                <DialogDescription>
                  The {selectedCategory} memo form is coming soon. Please select a different category or use the import function.
                </DialogDescription>
              </DialogHeader>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setShowMemoFormModal(false)}>
                  Close
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        );
    }
  };

  return (
    <div className="p-6">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".docx,.xlsx,.csv,.pdf"
        style={{ display: 'none' }}
        aria-label="Import memo file"
      />
      
      {/* Category Selection - Above Memo Management */}
      <div className="mb-6">
        <CategoryToggleSelector
          selectedCategory={selectedCategory}
          onCategorySelect={setSelectedCategory}
        />
      </div>
      
      {/* Selected Category Indicator */}
      <div className="mb-4">
        <Badge variant="outline" className="text-sm">
          Selected: {selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}
        </Badge>
      </div>
      
      {/* Section 1: Dynamic Heading */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">
          {currentConfig.title}
        </h1>
        
        {/* Section 2: Action Buttons */}
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowMemoFormModal(true)}
            aria-label="Add new memo manually"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Memo
          </Button>
          <Button
            id="memo-import-btn"
            variant="outline" 
            onClick={handleImport}
            disabled={isProcessing || isExtracting}
            aria-label="Import memo files (PDF, DOCX, Excel, CSV)"
          >
            {isProcessing || isExtracting ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                {isExtracting ? "Extracting..." : "Processing..."}
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Import
              </>
            )}
          </Button>
          <Button
            id="memo-export-btn"
            variant="outline" 
            onClick={handleExport}
            disabled={!currentMemo}
            aria-label="Export current memo data to CSV"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button
            id="memo-print-btn"
            variant="outline" 
            onClick={handlePrint}
            aria-label="Print current view"
          >
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button
            id="memo-refresh-btn"
            variant="outline" 
            onClick={refreshMemoData}
            aria-label="Refresh memo data"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>
      
      {/* Section 3: Tabbed Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="inbox">Memo Inbox</TabsTrigger>
          <TabsTrigger value="management">Acknowledged Memos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inbox">
          <MemoInboxTab />
        </TabsContent>
        
        <TabsContent value="management">
          <Card>
            <CardHeader>
              <CardTitle>Acknowledged Memos</CardTitle>
              <CardDescription>
                {filteredMemos.length} {selectedCategory} memo(s) found
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {currentConfig.memoColumns.map((column) => (
                        <TableHead key={column}>{column}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMemos.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={currentConfig.memoColumns.length} className="text-center py-8">
                          <div className="flex flex-col items-center gap-2">
                            <FileText className="h-8 w-8 text-muted-foreground" />
                            <p className="text-muted-foreground">No {selectedCategory} memos found</p>
                            <Button onClick={() => setShowMemoFormModal(true)} size="sm">
                              <Plus className="h-4 w-4 mr-2" />
                              Add First Memo
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredMemos.map((memo) => (
                        <TableRow 
                          key={memo.id}
                          className={cn(
                            "cursor-pointer hover:bg-muted/50",
                            selectedMemoId === memo.id && "bg-muted"
                          )}
                          onClick={() => handleSelectMemo(memo.id)}
                        >
                          <TableCell className="font-medium">{memo.reference}</TableCell>
                          <TableCell>{memo.labSite}</TableCell>
                          <TableCell>{memo.extractedData?.date || 'N/A'}</TableCell>
                          <TableCell>{memo.officerInCharge}</TableCell>
                          <TableCell>{memo.blocksCount}</TableCell>
                          <TableCell>{memo.productions?.length || 0}</TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleReadMemo(memo.id);
                                }}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewExcel(memo);
                                }}
                              >
                                <Sheet className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteMemo(memo.id, memo.reference);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Section 4: Selected Memo Overview */}
      {currentMemo && (
        <Card className="mb-6 sticky top-4 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">
                  Selected Memo: {currentMemo.reference} — {currentMemo.extractedData?.product || 'N/A'} 
                  <span className="text-muted-foreground ml-2">
                    (Officer: {currentMemo.officerInCharge})
                  </span>
                </h3>
              </div>
              <Badge variant={currentMemo.status === 'completed' ? 'default' : 'secondary'}>
                {currentMemo.status}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Section 5: Production Data Table */}
      {currentMemo && (
        <Card id="memo-details">
          <CardHeader>
            <CardTitle>Production Data</CardTitle>
            <CardDescription>
              {currentMemo.productions?.length || 0} production entries for {currentMemo.reference}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    {currentConfig.productionColumns.map((column) => (
                      <TableHead key={column}>{column}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {!currentMemo.productions || currentMemo.productions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={currentConfig.productionColumns.length} className="text-center py-8">
                        <div className="flex flex-col items-center gap-2">
                          <AlertTriangle className="h-8 w-8 text-muted-foreground" />
                          <p className="text-muted-foreground">No production data available</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    currentMemo.productions.map((production, index) => (
                      <TableRow key={index}>
                        <TableCell>{production.Production_Label}</TableCell>
                        <TableCell>{production.Production_Date}</TableCell>
                        <TableCell>{production.Test_Date}</TableCell>
                        <TableCell>{production.Age_days}</TableCell>
                        <TableCell>{production.Product}</TableCell>
                        <TableCell>{production.Grade_MPA}</TableCell>
                        <TableCell>{production.Machine_No}</TableCell>
                        <TableCell>{production.Mould_Ref}</TableCell>
                        <TableCell>{production.Production_P}</TableCell>
                        <TableCell>{production.No_Samp_for_Test}</TableCell>
                        <TableCell>{production.Block_pos_No}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dynamic Modal Rendering */}
      {renderModal()}

      {/* Excel Data Modal */}
      <Dialog open={showExcelModal} onOpenChange={setShowExcelModal}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Excel Data Preview</DialogTitle>
            <DialogDescription>
              Production data from {selectedMemoForExcel?.reference}
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-96 overflow-auto">
            {excelData.map((sheet, sheetIndex) => (
              <div key={sheetIndex} className="mb-4">
                <h3 className="font-semibold mb-2">{sheet.Sheet}</h3>
                {Object.entries(sheet).filter(([key]) => key !== 'Sheet').map(([tableName, tableData]) => (
                  <div key={tableName} className="mb-4">
                    <h4 className="font-medium mb-2">{tableName}</h4>
                    {Array.isArray(tableData) && tableData.length > 0 && (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              {Object.keys(tableData[0]).map((header) => (
                                <TableHead key={header}>{header}</TableHead>
                              ))}
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tableData.slice(0, 10).map((row, rowIndex) => (
                              <TableRow key={rowIndex}>
                                {Object.values(row).map((cell, cellIndex) => (
                                  <TableCell key={cellIndex}>{String(cell)}</TableCell>
                                ))}
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowExcelModal(false)}>
              Close
            </Button>
            <Button onClick={() => {
              toast({
                title: "Download Started",
                description: "Excel file download will begin shortly...",
              });
            }}>
              <Download className="h-4 w-4 mr-2" />
              Download Excel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* PDF Extraction Dialog */}
      <Dialog open={showExtractionDialog} onOpenChange={setShowExtractionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>PDF Data Extraction Results</DialogTitle>
            <DialogDescription>
              Review extracted data before importing
            </DialogDescription>
          </DialogHeader>
          
          {extractedData && (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Extraction Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><strong>Method:</strong> {extractedData.extractionMethod}</div>
                    <div><strong>Productions Found:</strong> {extractedData.productions.length}</div>
                    <div><strong>Reference:</strong> {extractedData.globalFields.referenceNo || 'Not found'}</div>
                    <div><strong>Date:</strong> {extractedData.globalFields.date || 'Not found'}</div>
                  </div>
                  
                  {extractedData.missingFields.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-destructive mb-2">Missing Fields ({extractedData.missingFields.length})</h4>
                      <div className="flex flex-wrap gap-1">
                        {extractedData.missingFields.map((field, index) => (
                          <Badge key={index} variant="destructive" className="text-xs">
                            {field}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Production Data Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="max-h-64 overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Production</TableHead>
                          <TableHead>Product</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Samples</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {extractedData.productions.slice(0, 5).map((prod, index) => (
                          <TableRow key={index}>
                            <TableCell>{prod.productionNumber}</TableCell>
                            <TableCell>{prod.Product || 'N/A'}</TableCell>
                            <TableCell>{prod.grade || 'N/A'}</TableCell>
                            <TableCell>{prod.numberOfSamples || 'N/A'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    {extractedData.productions.length > 5 && (
                      <p className="text-sm text-muted-foreground mt-2">
                        ... and {extractedData.productions.length - 5} more productions
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowExtractionDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleImportExtractedData}>
              Import Data
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirm.isOpen} onOpenChange={(open) => !open && setDeleteConfirm({isOpen: false, memoId: "", memoRef: ""})}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete memo "{deleteConfirm.memoRef}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteMemo} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}