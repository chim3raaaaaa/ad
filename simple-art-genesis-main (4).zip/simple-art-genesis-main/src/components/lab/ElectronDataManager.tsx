import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { 
  Database, 
  Download, 
  Upload, 
  Folder,
  HardDrive,
  Shield,
  Archive,
  RefreshCw
} from 'lucide-react';

interface AppPaths {
  userData: string;
  dataDir: string;
  dbDir: string;
  backupsDir: string;
  schemasDir: string;
  modulesDir: string;
}

export const ElectronDataManager: React.FC = () => {
  const [appPaths, setAppPaths] = useState<AppPaths | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAppPaths();
  }, []);

  const loadAppPaths = async () => {
    try {
      if (window.electronAPI) {
        const paths = await window.electronAPI.getAppPaths();
        setAppPaths(paths);
      }
    } catch (error) {
      console.error('Error loading app paths:', error);
    }
  };

  const handleCreateBackup = async () => {
    if (!window.electronAPI) {
      toast({
        title: "Error",
        description: "Electron API not available",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await window.electronAPI.createBackup();
      if (result.success) {
        toast({
          title: "Backup Created",
          description: `Backup saved to: ${result.path}`,
        });
      } else {
        toast({
          title: "Backup Failed",
          description: result.error || "Unknown error",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create backup",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportData = async (format: 'json' | 'sqlite') => {
    if (!window.electronAPI) {
      toast({
        title: "Error",
        description: "Electron API not available",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await window.electronAPI.exportData(format);
      if (result.success && !result.canceled) {
        toast({
          title: "Export Successful",
          description: `Data exported to: ${result.path}`,
        });
      } else if (result.canceled) {
        toast({
          title: "Export Canceled",
          description: "Export operation was canceled",
        });
      } else {
        toast({
          title: "Export Failed",
          description: result.error || "Unknown error",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportData = async () => {
    if (!window.electronAPI) {
      toast({
        title: "Error",
        description: "Electron API not available",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await window.electronAPI.importData();
      if (result.success && !result.canceled) {
        toast({
          title: "Import Successful",
          description: "Data imported successfully",
        });
        // Refresh the page to reflect imported data
        window.location.reload();
      } else if (result.canceled) {
        toast({
          title: "Import Canceled",
          description: "Import operation was canceled",
        });
      } else {
        toast({
          title: "Import Failed",
          description: result.error || "Unknown error",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to import data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!window.electronAPI) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5" />
            Local Database Manager
          </CardTitle>
          <CardDescription>
            Electron API not available. This feature requires running the app as an Electron desktop application.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Database className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              To use local SQLite database features, please run this app as an Electron desktop application.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5" />
            Local Database Manager
          </CardTitle>
          <CardDescription>
            Manage your local SQLite database, backups, and data exports/imports
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Database Status */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Database className="h-5 w-5" />
              Database Status
            </h3>
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Shield className="h-3 w-3 mr-1" />
                SQLite Active
              </Badge>
              <Badge variant="outline">
                Local Storage
              </Badge>
            </div>
          </div>

          <Separator />

          {/* Data Operations */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Data Operations</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                onClick={handleCreateBackup}
                disabled={isLoading}
                className="flex items-center gap-2"
              >
                {isLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Archive className="h-4 w-4" />
                )}
                Create Backup
              </Button>

              <Button
                onClick={() => handleExportData('json')}
                disabled={isLoading}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Export JSON
              </Button>

              <Button
                onClick={() => handleExportData('sqlite')}
                disabled={isLoading}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Export SQLite
              </Button>
            </div>

            <div className="mt-4">
              <Button
                onClick={handleImportData}
                disabled={isLoading}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                Import Data
              </Button>
            </div>
          </div>

          <Separator />

          {/* Storage Paths */}
          {appPaths && (
            <div>
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Folder className="h-5 w-5" />
                Storage Locations
              </h3>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">User Data:</span>
                  <code className="ml-2 px-2 py-1 bg-muted rounded text-xs">
                    {appPaths.userData}
                  </code>
                </div>
                <div>
                  <span className="font-medium">Database:</span>
                  <code className="ml-2 px-2 py-1 bg-muted rounded text-xs">
                    {appPaths.dbDir}
                  </code>
                </div>
                <div>
                  <span className="font-medium">Backups:</span>
                  <code className="ml-2 px-2 py-1 bg-muted rounded text-xs">
                    {appPaths.backupsDir}
                  </code>
                </div>
                <div>
                  <span className="font-medium">Schemas:</span>
                  <code className="ml-2 px-2 py-1 bg-muted rounded text-xs">
                    {appPaths.schemasDir}
                  </code>
                </div>
                <div>
                  <span className="font-medium">Modules:</span>
                  <code className="ml-2 px-2 py-1 bg-muted rounded text-xs">
                    {appPaths.modulesDir}
                  </code>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};