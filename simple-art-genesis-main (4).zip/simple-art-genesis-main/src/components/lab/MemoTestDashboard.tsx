import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { FileText, TestTube, CheckCircle, Clock, AlertCircle, Search, Filter } from 'lucide-react';
import { useMemoTestSystem } from '@/hooks/useMemoTestSystem';


export function MemoTestDashboard() {
  const { memos, pendingTests, loading, updateTestStatus } = useMemoTestSystem();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredMemos = memos.filter(memo => {
    const matchesSearch = 
      memo.memo_reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      memo.officer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      memo.plant.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = categoryFilter === 'all' || memo.category === categoryFilter;

    const matchesStatus = statusFilter === 'all' || 
      memo.tests.some(test => test.status === statusFilter);

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in_progress': return <Clock className="h-4 w-4 text-blue-500" />;
      case 'failed': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'border-green-500 text-green-700 bg-green-50';
      case 'in_progress': return 'border-blue-500 text-blue-700 bg-blue-50';
      case 'failed': return 'border-red-500 text-red-700 bg-red-50';
      default: return 'border-yellow-500 text-yellow-700 bg-yellow-50';
    }
  };

  const calculateProgress = (tests: any[]) => {
    if (tests.length === 0) return 0;
    const completed = tests.filter(test => test.status === 'completed').length;
    return (completed / tests.length) * 100;
  };

  const categories = Array.from(new Set(memos.map(m => m.category)));

  return (
    <div className="space-y-6">
      {/* Header and Filters */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold">Memo-Test Dashboard</h2>
          <p className="text-muted-foreground">
            Track memo→test→result workflow progress
          </p>
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search memos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-500" />
              <div>
                <div className="text-2xl font-bold">{memos.length}</div>
                <div className="text-sm text-muted-foreground">Total Memos</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <TestTube className="h-5 w-5 text-yellow-500" />
              <div>
                <div className="text-2xl font-bold">{pendingTests.length}</div>
                <div className="text-sm text-muted-foreground">Pending Tests</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <div className="text-2xl font-bold">
                  {memos.reduce((acc, memo) => acc + memo.tests.filter(t => t.status === 'completed').length, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Completed Tests</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-orange-500" />
              <div>
                <div className="text-2xl font-bold">
                  {memos.reduce((acc, memo) => acc + memo.completed_tests, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Total Results</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Memos List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-8">Loading...</div>
        ) : filteredMemos.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No memos found matching the current filters.</p>
          </div>
        ) : (
          filteredMemos.map((memo) => (
            <Card key={memo.memo_reference}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-blue-500" />
                    <div>
                      <CardTitle className="text-lg">{memo.memo_reference}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {memo.plant} • {memo.officer}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{memo.category}</Badge>
                    <Progress 
                      value={(memo.completed_tests / memo.total_tests) * 100} 
                      className="w-20"
                    />
                    <span className="text-sm text-muted-foreground">
                      {memo.total_tests > 0 ? Math.round((memo.completed_tests / memo.total_tests) * 100) : 0}%
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm font-medium">
                    Tests ({memo.tests.length}):
                  </div>
                  <div className="grid gap-2">
                    {memo.tests.map((test) => (
                      <div key={test.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <div>
                            <div className="font-medium">{test.test_type}</div>
                            <div className="text-sm text-muted-foreground">
                              Category: {test.test_category}
                              {test.assigned_date && ` • Assigned: ${new Date(test.assigned_date).toLocaleDateString()}`}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className={getStatusColor(test.status)}>
                            {test.status}
                          </Badge>
                          {test.status === 'pending' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateTestStatus(test.id, 'in_progress')}
                            >
                              Start Test
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}