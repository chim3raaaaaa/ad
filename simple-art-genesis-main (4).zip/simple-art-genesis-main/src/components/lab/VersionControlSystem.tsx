import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { GitBranch, Save, RotateCcw, FileText, Calendar, User } from 'lucide-react';
import { AuditLogger } from '@/services/audit/auditLogger';

interface Version {
  id: string;
  table_name: string;
  version_number: string;
  description: string;
  created_by: string;
  created_at: string;
  data_snapshot: string;
  record_count: number;
}

export default function VersionControlSystem() {
  const [versions, setVersions] = useState<Version[]>([]);
  const [tables, setTables] = useState<string[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [versionNumber, setVersionNumber] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [isCreating, setIsCreating] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Load available tables
  const loadTables = useCallback(async () => {
    try {
      if (window.electronAPI) {
        // Get list of tables from database
        const result = await window.electronAPI.dbQuery(`
          SELECT name FROM sqlite_master 
          WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'version_%'
          ORDER BY name
        `);
        const tableNames = result.map(row => row.name);
        setTables(tableNames);
      }
    } catch (error) {
      console.error('Error loading tables:', error);
    }
  }, []);

  // Load versions for selected table
  const loadVersions = useCallback(async () => {
    if (!selectedTable) return;
    
    setIsLoading(true);
    try {
      if (window.electronAPI) {
        // Create versions table if it doesn't exist
        const createVersionsTableSQL = `
          CREATE TABLE IF NOT EXISTS version_control (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT NOT NULL,
            version_number TEXT NOT NULL,
            description TEXT,
            created_by TEXT DEFAULT 'System',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            data_snapshot TEXT NOT NULL,
            record_count INTEGER DEFAULT 0
          )
        `;
        await window.electronAPI.dbRun(createVersionsTableSQL);
        
        // Load versions for selected table
        const result = await window.electronAPI.dbQuery(`
          SELECT * FROM version_control 
          WHERE table_name = ? 
          ORDER BY created_at DESC
        `, [selectedTable]);
        
        const versions = result.map(row => ({
          id: row.id.toString(),
          table_name: row.table_name,
          version_number: row.version_number,
          description: row.description,
          created_by: row.created_by,
          created_at: row.created_at,
          data_snapshot: row.data_snapshot,
          record_count: row.record_count
        }));
        
        setVersions(versions);
      }
    } catch (error) {
      console.error('Error loading versions:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedTable]);

  // Create new version
  const handleCreateVersion = async () => {
    if (!selectedTable || !versionNumber.trim()) {
      toast({
        title: "Error",
        description: "Table and version number are required",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    try {
      if (window.electronAPI) {
        // Get current data from table
        const tableData = await window.electronAPI.dbQuery(`SELECT * FROM ${selectedTable}`);
        const dataSnapshot = JSON.stringify(tableData);
        
        // Save version
        const insertSQL = `
          INSERT INTO version_control (table_name, version_number, description, data_snapshot, record_count)
          VALUES (?, ?, ?, ?, ?)
        `;
        
        await window.electronAPI.dbRun(insertSQL, [
          selectedTable,
          versionNumber,
          description,
          dataSnapshot,
          tableData.length
        ]);
        
        // Log audit event
        await AuditLogger.logVersionSave('Current User', selectedTable, versionNumber);
        
        toast({
          title: "Success",
          description: `Version ${versionNumber} created for ${selectedTable}`,
        });
        
        // Reset form and reload versions
        setVersionNumber('');
        setDescription('');
        await loadVersions();
      }
    } catch (error) {
      console.error('Error creating version:', error);
      toast({
        title: "Error",
        description: `Failed to create version: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  // Restore version
  const handleRestoreVersion = async (version: Version) => {
    setIsRestoring(true);
    try {
      if (window.electronAPI) {
        const data = JSON.parse(version.data_snapshot);
        
        // Clear existing data
        await window.electronAPI.dbRun(`DELETE FROM ${version.table_name}`);
        
        // Restore data
        for (const row of data) {
          const columns = Object.keys(row).filter(key => key !== 'id');
          const values = columns.map(col => row[col]);
          const placeholders = columns.map(() => '?').join(', ');
          
          if (columns.length > 0) {
            const insertSQL = `INSERT INTO ${version.table_name} (${columns.join(', ')}) VALUES (${placeholders})`;
            await window.electronAPI.dbRun(insertSQL, values);
          }
        }
        
        // Log audit event
        await AuditLogger.logEvent({
          user: 'Current User',
          action: 'RESTORE_VERSION',
          resource: 'version_control',
          details: `Restored ${version.table_name} to version ${version.version_number}`,
          severity: 'warning'
        });
        
        toast({
          title: "Success",
          description: `Restored ${version.table_name} to version ${version.version_number}`,
        });
      }
    } catch (error) {
      console.error('Error restoring version:', error);
      toast({
        title: "Error",
        description: `Failed to restore version: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setIsRestoring(false);
    }
  };

  useEffect(() => {
    loadTables();
  }, [loadTables]);

  useEffect(() => {
    loadVersions();
  }, [loadVersions]);

  return (
    <div className="space-y-6">
      {/* Create Version Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5" />
            Create New Version
          </CardTitle>
          <CardDescription>
            Save a snapshot of table data for version control
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="table-select">Table</Label>
              <select
                id="table-select"
                value={selectedTable}
                onChange={(e) => setSelectedTable(e.target.value)}
                className="w-full p-2 border rounded-md bg-background"
              >
                <option value="">Select a table...</option>
                {tables.map(table => (
                  <option key={table} value={table}>{table}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="version-number">Version Number</Label>
              <Input
                id="version-number"
                value={versionNumber}
                onChange={(e) => setVersionNumber(e.target.value)}
                placeholder="e.g., 1.0.0, v2.1, etc."
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the changes or reason for this version..."
              rows={3}
            />
          </div>
          
          <Button 
            onClick={handleCreateVersion}
            disabled={isCreating || !selectedTable || !versionNumber.trim()}
            className="w-full"
          >
            <Save className="h-4 w-4 mr-2" />
            {isCreating ? 'Creating...' : 'Create Version'}
          </Button>
        </CardContent>
      </Card>

      {/* Versions List */}
      <Card>
        <CardHeader>
          <CardTitle>Version History</CardTitle>
          <CardDescription>
            {selectedTable ? `Versions for table: ${selectedTable}` : 'Select a table to view versions'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground">Loading versions...</p>
          ) : versions.length === 0 ? (
            <p className="text-muted-foreground">
              {selectedTable ? 'No versions found for this table' : 'Select a table to view versions'}
            </p>
          ) : (
            <div className="space-y-4">
              {versions.map((version) => (
                <div key={version.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">{version.version_number}</Badge>
                      <span className="font-medium">{version.table_name}</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRestoreVersion(version)}
                      disabled={isRestoring}
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Restore
                    </Button>
                  </div>
                  
                  {version.description && (
                    <p className="text-sm text-muted-foreground">{version.description}</p>
                  )}
                  
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      {version.created_by}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(version.created_at).toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <FileText className="h-3 w-3" />
                      {version.record_count} records
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};