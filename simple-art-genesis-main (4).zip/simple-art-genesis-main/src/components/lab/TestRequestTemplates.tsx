import React, { useState } from 'react';
import { FileText, Plus, Edit, Trash2, Copy, Settings } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { useToast } from '../../hooks/use-toast';

interface TestTemplate {
  id: string;
  name: string;
  description: string;
  testType: string;
  estimatedDuration: number; // in hours
  priority: 'low' | 'normal' | 'high' | 'urgent';
  requiredFields: string[];
  instructions: string;
  equipment: string[];
  standards: string[];
  isActive: boolean;
  createdAt: string;
  usageCount: number;
}

interface TestRequestTemplatesProps {
  onTemplateSelect: (template: TestTemplate) => void;
}

export function TestRequestTemplates({ onTemplateSelect }: TestRequestTemplatesProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<TestTemplate | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const { toast } = useToast();

  // Sample templates
  const [templates, setTemplates] = useState<TestTemplate[]>([
    {
      id: '1',
      name: 'Concrete Block Compression Test',
      description: 'Standard compression test for concrete blocks',
      testType: 'Concrete Block Compression Test',
      estimatedDuration: 2,
      priority: 'normal',
      requiredFields: ['site', 'officer', 'lorry', 'blocks_count', 'grade'],
      instructions: 'Test concrete blocks according to BS EN 12390-3 standard. Ensure blocks are properly cured and surface is clean.',
      equipment: ['Compression Testing Machine', 'Calibrated Load Cell', 'Steel Plates'],
      standards: ['BS EN 12390-3', 'ASTM C39'],
      isActive: true,
      createdAt: '2024-01-15T10:00:00Z',
      usageCount: 25
    },
    {
      id: '2',
      name: 'Steel Bar Tensile Test',
      description: 'Tensile strength test for steel reinforcement bars',
      testType: 'Steel Bar Tensile Test',
      estimatedDuration: 4,
      priority: 'high',
      requiredFields: ['site', 'officer', 'bar_diameter', 'steel_grade', 'supplier'],
      instructions: 'Perform tensile test on steel bars according to BS 4449 standards. Check for yield strength and ultimate tensile strength.',
      equipment: ['Universal Testing Machine', 'Extensometer', 'Grip Fixtures'],
      standards: ['BS 4449', 'ASTM A615'],
      isActive: true,
      createdAt: '2024-01-12T14:30:00Z',
      usageCount: 18
    },
    {
      id: '3',
      name: 'Concrete Cube Test',
      description: 'Standard cube test for concrete strength',
      testType: 'Concrete Cube Test',
      estimatedDuration: 1,
      priority: 'urgent',
      requiredFields: ['site', 'officer', 'mix_design', 'curing_age', 'cubes_count'],
      instructions: 'Test concrete cubes at 7, 14, and 28 days according to BS EN 12390-3. Ensure proper curing conditions.',
      equipment: ['Compression Testing Machine', 'Cube Molds', 'Curing Tank'],
      standards: ['BS EN 12390-3', 'BS 1881-116'],
      isActive: true,
      createdAt: '2024-01-10T09:15:00Z',
      usageCount: 42
    }
  ]);

  const [newTemplate, setNewTemplate] = useState<Partial<TestTemplate>>({
    name: '',
    description: '',
    testType: '',
    estimatedDuration: 2,
    priority: 'normal',
    requiredFields: [],
    instructions: '',
    equipment: [],
    standards: [],
    isActive: true
  });

  const handleCreateTemplate = () => {
    if (!newTemplate.name || !newTemplate.testType) {
      toast({
        title: "Required fields missing",
        description: "Please fill in template name and test type.",
        variant: "destructive"
      });
      return;
    }

    const template: TestTemplate = {
      ...newTemplate,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      usageCount: 0
    } as TestTemplate;

    setTemplates([...templates, template]);
    setNewTemplate({
      name: '',
      description: '',
      testType: '',
      estimatedDuration: 2,
      priority: 'normal',
      requiredFields: [],
      instructions: '',
      equipment: [],
      standards: [],
      isActive: true
    });
    setIsCreateDialogOpen(false);
    
    toast({
      title: "Template Created",
      description: "Test request template has been created successfully.",
    });
  };

  const handleUseTemplate = (template: TestTemplate) => {
    setTemplates(templates.map(t => 
      t.id === template.id ? { ...t, usageCount: t.usageCount + 1 } : t
    ));
    onTemplateSelect(template);
    setIsOpen(false);
    
    toast({
      title: "Template Applied",
      description: `${template.name} template has been applied to the new test request.`,
    });
  };

  const handleDeleteTemplate = (templateId: string) => {
    setTemplates(templates.filter(t => t.id !== templateId));
    toast({
      title: "Template Deleted",
      description: "Test request template has been deleted.",
    });
  };

  const handleDuplicateTemplate = (template: TestTemplate) => {
    const duplicated: TestTemplate = {
      ...template,
      id: Date.now().toString(),
      name: `${template.name} (Copy)`,
      createdAt: new Date().toISOString(),
      usageCount: 0
    };
    setTemplates([...templates, duplicated]);
    
    toast({
      title: "Template Duplicated",
      description: "Template has been duplicated successfully.",
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low': return 'bg-gray-100 text-gray-800';
      case 'normal': return 'bg-blue-100 text-blue-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'urgent': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <FileText className="h-4 w-4 mr-2" />
          Use Template
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl">Test Request Templates</DialogTitle>
              <DialogDescription>
                Create, manage, and use templates for common test requests
              </DialogDescription>
            </div>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              New Template
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          {templates.map((template) => (
            <Card key={template.id} className="hover:shadow-sm transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {template.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(template.priority)}>
                      {template.priority}
                    </Badge>
                    <Badge variant="outline">
                      {template.usageCount} uses
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Test Type:</span> {template.testType}
                  </div>
                  <div>
                    <span className="font-medium">Duration:</span> {template.estimatedDuration} hours
                  </div>
                </div>

                {template.requiredFields.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium">Required Fields:</span>
                    <div className="flex flex-wrap gap-1">
                      {template.requiredFields.map((field) => (
                        <Badge key={field} variant="outline" className="text-xs">
                          {field.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {template.standards.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-sm font-medium">Standards:</span>
                    <div className="flex flex-wrap gap-1">
                      {template.standards.map((standard) => (
                        <Badge key={standard} variant="secondary" className="text-xs">
                          {standard}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button
                    onClick={() => handleUseTemplate(template)}
                    className="flex-1"
                  >
                    Use Template
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDuplicateTemplate(template)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingTemplate(template)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteTemplate(template.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Create Template Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Template</DialogTitle>
              <DialogDescription>
                Create a reusable template for common test requests
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Template Name</Label>
                  <Input
                    id="name"
                    value={newTemplate.name}
                    onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                    placeholder="Enter template name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="testType">Test Type</Label>
                  <Input
                    id="testType"
                    value={newTemplate.testType}
                    onChange={(e) => setNewTemplate({ ...newTemplate, testType: e.target.value })}
                    placeholder="Enter test type"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newTemplate.description}
                  onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                  placeholder="Enter template description"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Estimated Duration (hours)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={newTemplate.estimatedDuration}
                    onChange={(e) => setNewTemplate({ ...newTemplate, estimatedDuration: parseInt(e.target.value) || 0 })}
                    min="1"
                    max="72"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={newTemplate.priority}
                    onValueChange={(value) => setNewTemplate({ ...newTemplate, priority: value as any })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="instructions">Instructions</Label>
                <Textarea
                  id="instructions"
                  value={newTemplate.instructions}
                  onChange={(e) => setNewTemplate({ ...newTemplate, instructions: e.target.value })}
                  placeholder="Enter testing instructions"
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateTemplate}>
                  Create Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}