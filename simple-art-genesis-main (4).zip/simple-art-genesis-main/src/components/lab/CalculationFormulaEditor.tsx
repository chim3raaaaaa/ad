import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calculator, Edit, TestTube, Save, Play, Trash2, Plus } from 'lucide-react';
import { CalculationFormulaService, CalculationFormula } from '@/services/database/calculationFormulaService';
import { useToast } from '@/hooks/use-toast';

export function CalculationFormulaEditor() {
  const [formulas, setFormulas] = useState<CalculationFormula[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingFormula, setEditingFormula] = useState<CalculationFormula | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [testFormula, setTestFormula] = useState<CalculationFormula | null>(null);
  const [testParameters, setTestParameters] = useState<Record<string, string>>({});
  const [testResult, setTestResult] = useState<number | null>(null);
  const [testError, setTestError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadFormulas();
  }, []);

  const loadFormulas = async () => {
    setLoading(true);
    try {
      const formulaList = await CalculationFormulaService.listFormulas();
      setFormulas(formulaList);
    } catch (error) {
      console.error('Error loading formulas:', error);
      toast({
        title: "Error",
        description: "Failed to load calculation formulas.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (formula: CalculationFormula) => {
    setEditingFormula({ ...formula });
    setIsEditModalOpen(true);
  };

  const handleTest = (formula: CalculationFormula) => {
    setTestFormula(formula);
    const params = typeof formula.parameters === 'string' 
      ? JSON.parse(formula.parameters) 
      : formula.parameters;
    const initialParams: Record<string, string> = {};
    params.forEach((param: string) => {
      initialParams[param] = '';
    });
    setTestParameters(initialParams);
    setTestResult(null);
    setTestError(null);
    setIsTestModalOpen(true);
  };

  const handleSaveFormula = async () => {
    if (!editingFormula) return;

    try {
      if (editingFormula.id) {
        await CalculationFormulaService.updateFormula(editingFormula.id, {
          expression: editingFormula.expression,
          description: editingFormula.description,
          parameters: editingFormula.parameters
        });
      } else {
        await CalculationFormulaService.createFormula(editingFormula);
      }

      await loadFormulas();
      setIsEditModalOpen(false);
      setEditingFormula(null);
      toast({
        title: "Success",
        description: "Formula saved successfully."
      });
    } catch (error) {
      console.error('Error saving formula:', error);
      toast({
        title: "Error",
        description: "Failed to save formula.",
        variant: "destructive"
      });
    }
  };

  const handleTestFormula = async () => {
    if (!testFormula) return;

    setTestError(null);
    setTestResult(null);

    try {
      const numericParams: Record<string, number> = {};
      for (const [key, value] of Object.entries(testParameters)) {
        const numValue = Number(value);
        if (isNaN(numValue)) {
          throw new Error(`Invalid numeric value for parameter ${key}: ${value}`);
        }
        numericParams[key] = numValue;
      }

      const result = await CalculationFormulaService.evaluateFormula(testFormula.name, numericParams);
      setTestResult(result);
    } catch (error) {
      console.error('Error testing formula:', error);
      setTestError(error.message || 'Formula test failed');
    }
  };

  const handleDeleteFormula = async (id: number) => {
    if (!confirm('Are you sure you want to delete this formula?')) return;

    try {
      await CalculationFormulaService.deleteFormula(id);
      await loadFormulas();
      toast({
        title: "Success",
        description: "Formula deleted successfully."
      });
    } catch (error) {
      console.error('Error deleting formula:', error);
      toast({
        title: "Error",
        description: "Failed to delete formula.",
        variant: "destructive"
      });
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'aggregate': return Calculator;
      case 'sieve': return TestTube;
      case 'sand_equivalent': return TestTube;
      case 'methylene_blue': return TestTube;
      default: return Calculator;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'aggregate': return 'default';
      case 'sieve': return 'secondary';
      case 'sand_equivalent': return 'outline';
      case 'methylene_blue': return 'destructive';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <div className="text-center">
            <Calculator className="h-8 w-8 animate-pulse mx-auto mb-2" />
            <p>Loading calculation formulas...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Calculation Formula Management
          </CardTitle>
          <Button onClick={() => {
            setEditingFormula({
              name: '',
              expression: '',
              description: '',
              category: 'aggregate',
              parameters: []
            });
            setIsEditModalOpen(true);
          }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Formula
          </Button>
        </CardHeader>
        <CardContent>
          {formulas.length === 0 ? (
            <div className="text-center py-8">
              <Calculator className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No calculation formulas found.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Formula Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Expression</TableHead>
                  <TableHead>Parameters</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {formulas.map((formula) => {
                  const Icon = getCategoryIcon(formula.category);
                  const params = typeof formula.parameters === 'string' 
                    ? JSON.parse(formula.parameters) 
                    : formula.parameters;
                  
                  return (
                    <TableRow key={formula.id}>
                      <TableCell className="font-medium">{formula.name}</TableCell>
                      <TableCell>
                        <Badge variant={getCategoryColor(formula.category)}>
                          <Icon className="h-3 w-3 mr-1" />
                          {formula.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm max-w-xs truncate">
                        {formula.expression}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {params.map((param: string) => (
                            <Badge key={param} variant="outline" className="text-xs">
                              {param}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(formula)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTest(formula)}
                          >
                            <Play className="h-3 w-3" />
                          </Button>
                          {formula.id && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteFormula(formula.id!)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit Formula Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingFormula?.id ? 'Edit Formula' : 'Add New Formula'}
            </DialogTitle>
          </DialogHeader>
          {editingFormula && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="formula-name">Formula Name</Label>
                  <Input
                    id="formula-name"
                    value={editingFormula.name}
                    onChange={(e) => setEditingFormula({
                      ...editingFormula,
                      name: e.target.value
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="formula-category">Category</Label>
                  <Input
                    id="formula-category"
                    value={editingFormula.category}
                    onChange={(e) => setEditingFormula({
                      ...editingFormula,
                      category: e.target.value
                    })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="formula-expression">Expression</Label>
                <Textarea
                  id="formula-expression"
                  value={editingFormula.expression}
                  onChange={(e) => setEditingFormula({
                    ...editingFormula,
                    expression: e.target.value
                  })}
                  placeholder="e.g., ((Ph - Ps) / Ps) * 100"
                  className="font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="formula-description">Description</Label>
                <Textarea
                  id="formula-description"
                  value={editingFormula.description || ''}
                  onChange={(e) => setEditingFormula({
                    ...editingFormula,
                    description: e.target.value
                  })}
                  placeholder="Brief description of what this formula calculates"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="formula-parameters">Parameters (comma-separated)</Label>
                <Input
                  id="formula-parameters"
                  value={Array.isArray(editingFormula.parameters) 
                    ? editingFormula.parameters.join(', ')
                    : editingFormula.parameters
                  }
                  onChange={(e) => setEditingFormula({
                    ...editingFormula,
                    parameters: e.target.value.split(',').map(p => p.trim()).filter(p => p)
                  })}
                  placeholder="e.g., Ph, Ps, total_mass"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveFormula}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Formula
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Test Formula Modal */}
      <Dialog open={isTestModalOpen} onOpenChange={setIsTestModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Test Formula: {testFormula?.name}</DialogTitle>
          </DialogHeader>
          {testFormula && (
            <div className="space-y-4">
              <div className="p-3 bg-muted rounded-lg">
                <Label className="text-sm font-medium">Expression</Label>
                <p className="font-mono text-sm mt-1">{testFormula.expression}</p>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Test Parameters</Label>
                {Object.entries(testParameters).map(([param, value]) => (
                  <div key={param} className="grid grid-cols-3 gap-2 items-center">
                    <Label className="text-sm">{param}:</Label>
                    <Input
                      type="number"
                      step="any"
                      value={value}
                      onChange={(e) => setTestParameters({
                        ...testParameters,
                        [param]: e.target.value
                      })}
                      placeholder="Enter value"
                    />
                    <div></div>
                  </div>
                ))}
              </div>

              {testResult !== null && (
                <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                  <Label className="text-sm font-medium text-green-700 dark:text-green-300">Result</Label>
                  <p className="text-lg font-bold text-green-800 dark:text-green-200">{testResult}</p>
                </div>
              )}

              {testError && (
                <div className="p-3 bg-red-50 dark:bg-red-950 rounded-lg">
                  <Label className="text-sm font-medium text-red-700 dark:text-red-300">Error</Label>
                  <p className="text-sm text-red-800 dark:text-red-200">{testError}</p>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsTestModalOpen(false)}>
                  Close
                </Button>
                <Button onClick={handleTestFormula}>
                  <Play className="h-4 w-4 mr-2" />
                  Test Formula
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}