import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Plus } from 'lucide-react';
import { format } from 'date-fns';
import { testCalendarDataService } from '@/services/calendar/testCalendarDataService';
import { useToast } from '@/hooks/use-toast';

interface TestScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScheduled: () => void;
  selectedDate?: Date;
  memoId?: string;
}

export const TestScheduleModal: React.FC<TestScheduleModalProps> = ({
  isOpen,
  onClose,
  onScheduled,
  selectedDate,
  memoId
}) => {
  const [formData, setFormData] = useState({
    testType: '',
    productionDate: selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '',
    dueDate: '',
    productType: '',
    plantLocation: '',
    batchNumber: '',
    priority: 'normal' as 'low' | 'normal' | 'high' | 'critical',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [memoOptions, setMemoOptions] = useState<{id: string, title: string}[]>([]);
  const [selectedMemoId, setSelectedMemoId] = useState(memoId || '');
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      loadMemoOptions();
      if (selectedDate) {
        // Auto-calculate due date (28 days from production date)
        const dueDate = new Date(selectedDate);
        dueDate.setDate(dueDate.getDate() + 28);
        setFormData(prev => ({
          ...prev,
          productionDate: format(selectedDate, 'yyyy-MM-dd'),
          dueDate: format(dueDate, 'yyyy-MM-dd')
        }));
      }
    }
  }, [isOpen, selectedDate]);

  const loadMemoOptions = async () => {
    try {
      const isElectron = typeof window !== 'undefined' && !!window.electronAPI;
      if (isElectron) {
        const result = await window.electronAPI.dbQuery(`
          SELECT id, title 
          FROM memos 
          ORDER BY created_at DESC 
          LIMIT 50
        `);
        
        if (result.success) {
          setMemoOptions(result.data || []);
        }
      }
    } catch (error) {
      console.error('Error loading memo options:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.testType || !formData.productionDate || !formData.dueDate || !selectedMemoId) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const testId = await testCalendarDataService.createTestFromMemo(selectedMemoId, {
        testType: formData.testType,
        productionDate: formData.productionDate,
        dueDate: formData.dueDate,
        productType: formData.productType,
        plantLocation: formData.plantLocation,
        batchNumber: formData.batchNumber,
        priority: formData.priority
      });

      // Add notes if provided
      if (formData.notes && testId) {
        await window.electronAPI.dbRun(`
          UPDATE test_schedule 
          SET notes = ? 
          WHERE id = ?
        `, [formData.notes, testId]);
      }

      toast({
        title: "Test Scheduled",
        description: `Test scheduled successfully with ID: ${testId}`,
      });

      onScheduled();
      onClose();
      resetForm();
    } catch (error) {
      console.error('Error scheduling test:', error);
      toast({
        title: "Error",
        description: "Failed to schedule test. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      testType: '',
      productionDate: '',
      dueDate: '',
      productType: '',
      plantLocation: '',
      batchNumber: '',
      priority: 'normal',
      notes: ''
    });
    setSelectedMemoId(memoId || '');
  };

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateDueDate = (productionDate: string, testType: string) => {
    if (!productionDate) return '';
    
    const prodDate = new Date(productionDate);
    let daysToAdd = 28; // Default 28-day test
    
    // Adjust days based on test type
    if (testType.includes('7-day') || testType.includes('7 day')) {
      daysToAdd = 7;
    } else if (testType.includes('14-day') || testType.includes('14 day')) {
      daysToAdd = 14;
    } else if (testType.includes('56-day') || testType.includes('56 day')) {
      daysToAdd = 56;
    }
    
    const dueDate = new Date(prodDate);
    dueDate.setDate(dueDate.getDate() + daysToAdd);
    return format(dueDate, 'yyyy-MM-dd');
  };

  useEffect(() => {
    if (formData.productionDate && formData.testType) {
      const calculatedDueDate = calculateDueDate(formData.productionDate, formData.testType);
      if (calculatedDueDate !== formData.dueDate) {
        updateFormData('dueDate', calculatedDueDate);
      }
    }
  }, [formData.productionDate, formData.testType]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Plus className="h-5 w-5 mr-2" />
            Schedule New Test
          </DialogTitle>
          <DialogDescription>
            Create a new test schedule entry for the selected memo
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Memo Selection */}
            <div className="md:col-span-2">
              <Label htmlFor="memo">Associated Memo *</Label>
              <Select value={selectedMemoId} onValueChange={setSelectedMemoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a memo" />
                </SelectTrigger>
                <SelectContent>
                  {memoOptions.map(memo => (
                    <SelectItem key={memo.id} value={memo.id}>
                      {memo.title || `Memo ${memo.id}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Test Type */}
            <div>
              <Label htmlFor="testType">Test Type *</Label>
              <Select value={formData.testType} onValueChange={(value) => updateFormData('testType', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select test type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7-day Cube Test">7-day Cube Test</SelectItem>
                  <SelectItem value="14-day Cube Test">14-day Cube Test</SelectItem>
                  <SelectItem value="28-day Cube Test">28-day Cube Test</SelectItem>
                  <SelectItem value="56-day Cube Test">56-day Cube Test</SelectItem>
                  <SelectItem value="Aggregate Test">Aggregate Test</SelectItem>
                  <SelectItem value="Block Test">Block Test</SelectItem>
                  <SelectItem value="Paver Test">Paver Test</SelectItem>
                  <SelectItem value="Flagstone Test">Flagstone Test</SelectItem>
                  <SelectItem value="Kerb Test">Kerb Test</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Priority */}
            <div>
              <Label htmlFor="priority">Priority</Label>
              <Select value={formData.priority} onValueChange={(value) => updateFormData('priority', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Production Date */}
            <div>
              <Label>Production Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.productionDate ? format(new Date(formData.productionDate), "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.productionDate ? new Date(formData.productionDate) : undefined}
                    onSelect={(date) => updateFormData('productionDate', date ? format(date, 'yyyy-MM-dd') : '')}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Due Date */}
            <div>
              <Label>Due Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.dueDate ? format(new Date(formData.dueDate), "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.dueDate ? new Date(formData.dueDate) : undefined}
                    onSelect={(date) => updateFormData('dueDate', date ? format(date, 'yyyy-MM-dd') : '')}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Product Type */}
            <div>
              <Label htmlFor="productType">Product Type</Label>
              <Input
                value={formData.productType}
                onChange={(e) => updateFormData('productType', e.target.value)}
                placeholder="e.g., C25/30 Concrete"
              />
            </div>

            {/* Plant Location */}
            <div>
              <Label htmlFor="plantLocation">Plant Location</Label>
              <Input
                value={formData.plantLocation}
                onChange={(e) => updateFormData('plantLocation', e.target.value)}
                placeholder="e.g., Port Louis Plant"
              />
            </div>

            {/* Batch Number */}
            <div className="md:col-span-2">
              <Label htmlFor="batchNumber">Batch Number</Label>
              <Input
                value={formData.batchNumber}
                onChange={(e) => updateFormData('batchNumber', e.target.value)}
                placeholder="e.g., BATCH-2024-001"
              />
            </div>

            {/* Notes */}
            <div className="md:col-span-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => updateFormData('notes', e.target.value)}
                placeholder="Additional notes or special instructions..."
                className="h-20"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Scheduling...' : 'Schedule Test'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};