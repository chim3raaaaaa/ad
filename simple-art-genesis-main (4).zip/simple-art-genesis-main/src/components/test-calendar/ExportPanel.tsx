import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Download, FileText, Table, Calendar } from 'lucide-react';
import { CalendarExportService, ExportOptions } from '@/services/export/calendarExportService';
import { TestCalendarEvent } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface ExportPanelProps {
  events: TestCalendarEvent[];
  isOpen: boolean;
  onClose: () => void;
}

export const ExportPanel: React.FC<ExportPanelProps> = ({
  events,
  isOpen,
  onClose
}) => {
  const [exportFormat, setExportFormat] = useState<'pdf' | 'csv' | 'ical'>('pdf');
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      let blob: Blob;
      let filename: string;
      
      switch (exportFormat) {
        case 'pdf':
          blob = await CalendarExportService.exportToPDF(events);
          filename = `test-calendar-${new Date().toISOString().split('T')[0]}.pdf`;
          break;
        case 'csv':
          blob = await CalendarExportService.exportToCSV(events);
          filename = `test-calendar-${new Date().toISOString().split('T')[0]}.csv`;
          break;
        case 'ical':
          blob = await CalendarExportService.exportToICal(events);
          filename = `test-calendar-${new Date().toISOString().split('T')[0]}.ics`;
          break;
        default:
          throw new Error('Invalid export format');
      }
      
      CalendarExportService.downloadBlob(blob, filename);
      
      toast({
        title: "Export Successful",
        description: `Calendar exported as ${exportFormat.toUpperCase()}`,
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export calendar data",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Download className="h-5 w-5 mr-2" />
            Export Calendar
          </DialogTitle>
          <DialogDescription>
            Export {events.length} events in your preferred format
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="export-format">Export Format</Label>
            <Select
              value={exportFormat}
              onValueChange={(value) => setExportFormat(value as 'pdf' | 'csv' | 'ical')}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pdf">
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 mr-2" />
                    PDF Report
                  </div>
                </SelectItem>
                <SelectItem value="csv">
                  <div className="flex items-center">
                    <Table className="h-4 w-4 mr-2" />
                    CSV Spreadsheet
                  </div>
                </SelectItem>
                <SelectItem value="ical">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    iCal Calendar
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          <div className="text-sm text-muted-foreground">
            <p className="mb-2">Export includes:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>All filtered events ({events.length} total)</li>
              <li>Test details and status information</li>
              <li>Due dates and location data</li>
              <li>Generation timestamp</li>
            </ul>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              onClick={handleExport}
              disabled={isExporting}
              className="flex-1"
            >
              <Download className="h-4 w-4 mr-2" />
              {isExporting ? 'Exporting...' : `Export ${exportFormat.toUpperCase()}`}
              {events.length === 0 && ' (No Data)'}
            </Button>
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isExporting}
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};