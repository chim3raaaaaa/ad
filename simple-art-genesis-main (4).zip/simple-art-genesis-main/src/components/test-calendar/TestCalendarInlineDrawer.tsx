import { useState } from "react";
import { X, Calendar, FileText, User, MapPin, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { TestCalendarEvent } from "@/types";

interface TestCalendarInlineDrawerProps {
  event: TestCalendarEvent | null;
  isOpen: boolean;
  onClose: () => void;
  onMarkDone: (eventId: string) => void;
  onViewMemoDetails?: (memoId: string) => void;
}

export const TestCalendarInlineDrawer = ({
  event,
  isOpen,
  onClose,
  onMarkDone,
  onViewMemoDetails
}: TestCalendarInlineDrawerProps) => {
  if (!isOpen || !event) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700';
      case 'overdue':
        return 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-700';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-900/20 dark:text-gray-300 dark:border-gray-700';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-red-500 text-white';
      case 'high':
        return 'bg-orange-500 text-white';
      case 'normal':
        return 'bg-blue-500 text-white';
      case 'low':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <Card className="fixed right-4 top-20 w-96 max-h-[calc(100vh-100px)] overflow-y-auto shadow-lg border-2 bg-background z-50">
      <div className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-lg">Test Details</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Status and Priority Badges */}
        <div className="flex gap-2 mb-4">
          <Badge className={cn("text-xs", getStatusColor(event.status))}>
            {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
          </Badge>
          <Badge className={cn("text-xs", getPriorityColor(event.priority))}>
            {event.priority.charAt(0).toUpperCase() + event.priority.slice(1)} Priority
          </Badge>
        </div>

        <Separator className="mb-4" />

        {/* Test Information */}
        <div className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-muted-foreground">Memo Reference</div>
                <div className="font-mono text-sm">{event.memo_id}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-muted-foreground">Test Type</div>
                <div className="text-sm">{event.test_type}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <User className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-muted-foreground">Officer</div>
                <div className="text-sm">{event.assigned_to || 'Unassigned'}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-muted-foreground">Sample Location</div>
                <div className="text-sm">{event.plant_location || 'Not specified'}</div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Production Details */}
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Production Details</h4>
            
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <div className="text-muted-foreground">Product</div>
                <div className="font-medium">{event.product}</div>
              </div>
              
              {event.batch_number && (
                <div>
                  <div className="text-muted-foreground">Batch Number</div>
                  <div className="font-mono text-sm">{event.batch_number}</div>
                </div>
              )}
              
              <div>
                <div className="text-muted-foreground">Production Date</div>
                <div>{event.production_date ? new Date(event.production_date).toLocaleDateString() : 'N/A'}</div>
              </div>
              
              <div>
                <div className="text-muted-foreground">Due Date</div>
                <div className={cn(
                  "font-medium",
                  event.status === 'overdue' ? 'text-red-600' : 
                  (event.remaining_days || 0) === 0 ? 'text-orange-600' : 'text-foreground'
                )}>
                  {new Date(event.due_date).toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <Separator />
          
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Timeline</h4>
            
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span>
                {event.status === 'overdue' 
                  ? `Overdue by ${Math.abs(event.remaining_days || 0)} days`
                  : (event.remaining_days || 0) === 0 
                  ? "Due today"
                  : `Due in ${event.remaining_days || 0} days`
                }
              </span>
            </div>

            {event.status === 'completed' && (
              <div className="flex items-center gap-2 text-sm text-green-600">
                <CheckCircle className="h-4 w-4" />
                <span>Test completed</span>
              </div>
            )}
          </div>

          {/* Notes */}
          {event.notes && (
            <>
              <Separator />
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Notes</h4>
                <div className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
                  {event.notes}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Action Buttons */}
        <div className="mt-6 space-y-2">
          {event.status !== 'completed' && (
            <Button 
              onClick={() => {
                onMarkDone(event.id);
                onClose();
              }}
              className="w-full"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Done
            </Button>
          )}
          
          {onViewMemoDetails && event.memo_id && (
            <Button 
              variant="outline"
              onClick={() => {
                onViewMemoDetails(event.memo_id);
                onClose();
              }}
              className="w-full"
            >
              <FileText className="h-4 w-4 mr-2" />
              View Memo Details
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};