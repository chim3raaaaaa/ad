import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { FileText, Calendar, MapPin, Package, Clock, User } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface MemoDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  memoId: string;
  onScheduleTest?: (memoId: string) => void;
}

interface MemoData {
  id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
  plant_location: string;
  lab_site_id: string;
  production_data: any[];
  status?: string;
  created_by?: string;
}

export const MemoDetailsModal: React.FC<MemoDetailsModalProps> = ({
  isOpen,
  onClose,
  memoId,
  onScheduleTest
}) => {
  const [memoData, setMemoData] = useState<MemoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [relatedTests, setRelatedTests] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && memoId) {
      loadMemoData();
      loadRelatedTests();
    }
  }, [isOpen, memoId]);

  const loadMemoData = async () => {
    setLoading(true);
    try {
      const isElectron = typeof window !== 'undefined' && !!window.electronAPI;
      
      if (!isElectron) {
        throw new Error('Electron environment required');
      }

      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM memos WHERE id = ?
      `, [memoId]);

      if (result.success && result.data.length > 0) {
        const memo = result.data[0];
        setMemoData({
          ...memo,
          production_data: memo.production_data ? JSON.parse(memo.production_data) : []
        });
      } else {
        throw new Error('Memo not found');
      }
    } catch (error) {
      console.error('Error loading memo data:', error);
      toast({
        title: "Error",
        description: "Failed to load memo details",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadRelatedTests = async () => {
    try {
      const isElectron = typeof window !== 'undefined' && !!window.electronAPI;
      
      if (!isElectron) return;

      const result = await window.electronAPI.dbQuery(`
        SELECT ts.*, 
               CASE 
                 WHEN ts.status != 'completed' AND ts.due_date < date('now') THEN 'overdue'
                 ELSE ts.status 
               END as current_status
        FROM test_schedule ts 
        WHERE ts.memo_id = ?
        ORDER BY ts.due_date ASC
      `, [memoId]);

      if (result.success) {
        setRelatedTests(result.data || []);
      }
    } catch (error) {
      console.error('Error loading related tests:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'overdue': return 'bg-red-500';
      case 'in_progress': return 'bg-blue-500';
      case 'scheduled': return 'bg-yellow-500';
      case 'cancelled': return 'bg-gray-500';
      default: return 'bg-gray-400';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'PPP');
    } catch {
      return dateString;
    }
  };

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">Loading memo details...</div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!memoData) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Memo Not Found</DialogTitle>
            <DialogDescription>
              The requested memo could not be found or loaded.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={onClose}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Memo Details
          </DialogTitle>
          <DialogDescription>
            Memo ID: {memoData.id}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Memo Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{memoData.title || 'Untitled Memo'}</CardTitle>
              <CardDescription className="flex items-center gap-4">
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  Created: {formatDate(memoData.created_at)}
                </span>
                {memoData.plant_location && (
                  <span className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {memoData.plant_location}
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            {memoData.content && (
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <pre className="whitespace-pre-wrap text-sm">{memoData.content}</pre>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Production Data */}
          {memoData.production_data && memoData.production_data.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Production Data
                </CardTitle>
                <CardDescription>
                  {memoData.production_data.length} production record(s)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {memoData.production_data.map((production, index) => (
                    <div key={index} className="p-3 border rounded-lg bg-muted/50">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                        {Object.entries(production).map(([key, value]) => (
                          <div key={key}>
                            <span className="font-medium capitalize">{key.replace(/_/g, ' ')}:</span>
                            <div className="text-muted-foreground">{String(value)}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Related Tests */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Related Tests ({relatedTests.length})
                </CardTitle>
                {onScheduleTest && (
                  <Button
                    size="sm"
                    onClick={() => onScheduleTest(memoId)}
                  >
                    Schedule New Test
                  </Button>
                )}
              </div>
              <CardDescription>
                Tests scheduled for this memo
              </CardDescription>
            </CardHeader>
            <CardContent>
              {relatedTests.length > 0 ? (
                <div className="space-y-3">
                  {relatedTests.map((test) => (
                    <div key={test.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{test.test_type}</div>
                        <div className="text-sm text-muted-foreground">
                          Production: {formatDate(test.production_date)} → Due: {formatDate(test.due_date)}
                        </div>
                        {test.product_type && (
                          <div className="text-sm text-muted-foreground">
                            Product: {test.product_type}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(test.current_status)}>
                          {test.current_status}
                        </Badge>
                        {test.priority !== 'normal' && (
                          <Badge variant="outline">
                            {test.priority}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No tests scheduled for this memo</p>
                  {onScheduleTest && (
                    <Button
                      className="mt-4"
                      onClick={() => onScheduleTest(memoId)}
                    >
                      Schedule First Test
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};