import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckSquare, X, Trash2, Edit } from 'lucide-react';
import { BatchOperationsService, BatchOperationResult } from '@/services/batch/batchOperationsService';
import { useToast } from '@/hooks/use-toast';

interface BatchOperationsPanelProps {
  selectedEvents: string[];
  onClearSelection: () => void;
  onRefresh: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export const BatchOperationsPanel: React.FC<BatchOperationsPanelProps> = ({
  selectedEvents,
  onClearSelection,
  onRefresh,
  isOpen,
  onClose
}) => {
  const [isOperating, setIsOperating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentOperation, setCurrentOperation] = useState<string>('');
  const { toast } = useToast();

  const handleBatchOperation = async (
    operation: () => Promise<BatchOperationResult>,
    operationName: string
  ) => {
    setIsOperating(true);
    setCurrentOperation(operationName);
    setProgress(0);

    try {
      const result = await operation();
      
      if (result.success > 0) {
        toast({
          title: "Batch Operation Complete",
          description: `${result.success} items processed successfully${result.failed > 0 ? `, ${result.failed} failed` : ''}`,
        });
      }
      
      if (result.failed > 0) {
        toast({
          title: "Some Operations Failed",
          description: `${result.failed} items failed to process`,
          variant: "destructive",
        });
      }

      onRefresh();
      onClearSelection();
    } catch (error) {
      toast({
        title: "Batch Operation Failed",
        description: "An error occurred during the batch operation",
        variant: "destructive",
      });
    } finally {
      setIsOperating(false);
      setProgress(0);
      setCurrentOperation('');
    }
  };

  const markAllDone = () => {
    handleBatchOperation(
      () => BatchOperationsService.markMultipleDone(selectedEvents, (completed, total) => {
        setProgress((completed / total) * 100);
      }),
      'Marking as Done'
    );
  };

  const bulkStatusUpdate = (status: string) => {
    handleBatchOperation(
      () => BatchOperationsService.bulkStatusUpdate(selectedEvents, status, (completed, total) => {
        setProgress((completed / total) * 100);
      }),
      'Updating Status'
    );
  };

  const bulkDelete = () => {
    handleBatchOperation(
      () => BatchOperationsService.bulkDelete(selectedEvents, (completed, total) => {
        setProgress((completed / total) * 100);
      }),
      'Deleting Events'
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Batch Operations</DialogTitle>
          <DialogDescription>
            {selectedEvents.length > 0 ? (
              <>
                <Badge variant="secondary" className="mr-2">
                  {selectedEvents.length} selected
                </Badge>
                Perform actions on multiple events
              </>
            ) : (
              <span className="text-muted-foreground">
                Select events from the calendar to perform batch operations
              </span>
            )}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {isOperating && (
            <div>
              <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                <span>{currentOperation}...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
          
          <div className="flex flex-wrap gap-2">
            {selectedEvents.length > 0 ? (
              <>
                <Button
                  onClick={markAllDone}
                  disabled={isOperating}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Mark All Done
                </Button>
                
                <Button
                  onClick={() => bulkStatusUpdate('pending')}
                  disabled={isOperating}
                  variant="outline"
                  size="sm"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Set Pending
                </Button>
                
                <Button
                  onClick={() => bulkStatusUpdate('in_progress')}
                  disabled={isOperating}
                  variant="outline"
                  size="sm"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Set In Progress
                </Button>
                
                <Button
                  onClick={bulkDelete}
                  disabled={isOperating}
                  variant="destructive"
                  size="sm"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Selected
                </Button>
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground w-full">
                <p className="mb-4">No events selected</p>
                <p className="text-sm">
                  Switch to List View and use the checkboxes to select events for batch operations
                </p>
              </div>
            )}
          </div>
          
          <div className="flex justify-between pt-4">
            <Button
              variant="outline"
              onClick={onClearSelection}
              disabled={isOperating}
            >
              Clear Selection
            </Button>
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isOperating}
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};