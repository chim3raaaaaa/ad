import { useState } from "react";
import { Download, FileText, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CalendarExportService } from "@/services/export/calendarExportService";
import { TestCalendarEvent } from "@/types";
import { useToast } from "@/hooks/use-toast";

interface TestCalendarExportButtonsProps {
  events: TestCalendarEvent[];
  className?: string;
}

export const TestCalendarExportButtons = ({
  events,
  className
}: TestCalendarExportButtonsProps) => {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const blob = await CalendarExportService.exportToPDF(events);
      CalendarExportService.downloadBlob(blob, `test-calendar-${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "Export Successful",
        description: "PDF report has been downloaded",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to generate PDF report",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = async () => {
    setIsExporting(true);
    try {
      const blob = await CalendarExportService.exportToCSV(events);
      CalendarExportService.downloadBlob(blob, `test-calendar-${new Date().toISOString().split('T')[0]}.csv`);
      
      toast({
        title: "Export Successful",
        description: "CSV data has been downloaded",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to generate CSV file",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className={`flex gap-2 ${className}`}>
      <Button
        variant="outline"
        size="sm"
        onClick={handleExportPDF}
        disabled={isExporting || events.length === 0}
      >
        <FileText className="h-4 w-4 mr-2" />
        Export PDF
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        onClick={handleExportCSV}
        disabled={isExporting || events.length === 0}
      >
        <Table className="h-4 w-4 mr-2" />
        Export CSV
      </Button>
    </div>
  );
};