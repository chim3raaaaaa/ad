import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Activity, Clock, Database, Zap } from 'lucide-react';

interface PerformanceMetrics {
  loadTime: number;
  apiCalls: number;
  cacheHits: number;
  memoryUsage: string;
  eventsCount: number;
  filterTime: number;
  queryTime?: number;
  renderTime?: number;
}

interface PerformanceMonitorProps {
  metrics: PerformanceMetrics;
  isOpen: boolean;
  onClose: () => void;
}

export const PerformanceMonitor: React.FC<PerformanceMonitorProps> = ({
  metrics,
  isOpen,
  onClose
}) => {
  const [renderTime, setRenderTime] = useState<number>(0);
  const [realMetrics, setRealMetrics] = useState<PerformanceMetrics>(metrics);

  useEffect(() => {
    const startTime = performance.now();
    
    // Calculate real performance metrics
    const updateMetrics = () => {
      const endTime = performance.now();
      const componentRenderTime = endTime - startTime;
      
      // Get memory usage if available
      const memoryInfo = (performance as any).memory;
      const memoryUsage = memoryInfo ? 
        `${Math.round(memoryInfo.usedJSHeapSize / 1024 / 1024)}MB` : 
        metrics.memoryUsage;
      
      setRealMetrics(prev => ({
        ...prev,
        renderTime: componentRenderTime,
        memoryUsage: memoryUsage,
        queryTime: prev.queryTime || prev.filterTime
      }));
      setRenderTime(componentRenderTime);
    };

    updateMetrics();
  }, [metrics]);

  const getPerformanceStatus = (loadTime: number) => {
    if (loadTime < 1000) return { status: 'excellent', color: 'bg-green-500', text: 'Excellent' };
    if (loadTime < 2000) return { status: 'good', color: 'bg-yellow-500', text: 'Good' };
    return { status: 'poor', color: 'bg-red-500', text: 'Poor' };
  };

  const getCacheEfficiency = () => {
    const total = realMetrics.apiCalls + realMetrics.cacheHits;
    return total > 0 ? (realMetrics.cacheHits / total) * 100 : 0;
  };

  const performanceStatus = getPerformanceStatus(realMetrics.loadTime);
  const cacheEfficiency = getCacheEfficiency();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2" />
            Performance Monitor
          </DialogTitle>
          <DialogDescription>
            Real-time performance metrics for the Test Calendar
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Overall Performance */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Performance</span>
              <Badge variant="secondary" className={performanceStatus.color}>
                {performanceStatus.text}
              </Badge>
            </div>
            <Progress value={Math.min((2000 - realMetrics.loadTime) / 20, 100)} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              Load time: {realMetrics.loadTime}ms
            </p>
          </div>

          <Separator />

          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2 text-blue-500" />
                <span className="text-sm font-medium">Load Time</span>
              </div>
              <p className="text-2xl font-bold">{realMetrics.loadTime}ms</p>
              <p className="text-xs text-muted-foreground">
                Render: {(realMetrics.renderTime || renderTime).toFixed(1)}ms
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center">
                <Database className="h-4 w-4 mr-2 text-green-500" />
                <span className="text-sm font-medium">Cache Efficiency</span>
              </div>
              <p className="text-2xl font-bold">{cacheEfficiency.toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground">
                {realMetrics.cacheHits} hits / {realMetrics.apiCalls} API calls
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center">
                <Zap className="h-4 w-4 mr-2 text-yellow-500" />
                <span className="text-sm font-medium">Filter Speed</span>
              </div>
              <p className="text-2xl font-bold">{realMetrics.queryTime || realMetrics.filterTime}ms</p>
              <p className="text-xs text-muted-foreground">
                {realMetrics.eventsCount} events processed
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center">
                <Activity className="h-4 w-4 mr-2 text-purple-500" />
                <span className="text-sm font-medium">Memory Usage</span>
              </div>
              <p className="text-2xl font-bold">{realMetrics.memoryUsage}</p>
              <p className="text-xs text-muted-foreground">
                Current allocation
              </p>
            </div>
          </div>

          <Separator />

          {/* Performance Tips */}
          <div>
            <h4 className="text-sm font-medium mb-2">Performance Tips</h4>
            <div className="text-xs text-muted-foreground space-y-1">
              {realMetrics.loadTime > 2000 && (
                <p>• Consider reducing the date range to improve load times</p>
              )}
              {cacheEfficiency < 50 && realMetrics.apiCalls > 0 && (
                <p>• Cache efficiency is low - data might be changing frequently</p>
              )}
              {(realMetrics.queryTime || realMetrics.filterTime) > 500 && (
                <p>• Query processing is slow - consider reducing filter criteria</p>
              )}
              {realMetrics.eventsCount > 1000 && (
                <p>• Large dataset detected - pagination recommended</p>
              )}
              {renderTime > 100 && (
                <p>• Component rendering is slow - consider reducing complexity</p>
              )}
              <p>• Use filters to reduce data size and improve performance</p>
              <p>• Enable caching for frequently accessed data</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};