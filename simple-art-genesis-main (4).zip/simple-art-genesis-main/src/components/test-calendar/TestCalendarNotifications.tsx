import { useEffect, useState } from "react";
import { Bell, AlertTriangle, Clock, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { TestCalendarEvent } from "@/types";
import { cn } from "@/lib/utils";

interface TestCalendarNotificationsProps {
  events: TestCalendarEvent[];
  onDismiss?: (eventId: string) => void;
}

interface NotificationAlert {
  id: string;
  type: 'overdue' | 'due_today' | 'due_soon';
  title: string;
  message: string;
  event: TestCalendarEvent;
  timestamp: Date;
}

export const TestCalendarNotifications = ({
  events,
  onDismiss
}: TestCalendarNotificationsProps) => {
  const [alerts, setAlerts] = useState<NotificationAlert[]>([]);
  const [dismissedAlerts, setDismissedAlerts] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  useEffect(() => {
    const generateAlerts = () => {
      const today = new Date().toISOString().split('T')[0];
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      const newAlerts: NotificationAlert[] = [];

      events.forEach(event => {
        if (dismissedAlerts.has(event.id)) return;

        const eventDate = event.due_date;
        
        // Overdue tests
        if (today > eventDate && event.status !== 'completed') {
          newAlerts.push({
            id: event.id,
            type: 'overdue',
            title: 'Test Overdue',
            message: `${event.test_type} for ${event.product} is overdue by ${Math.abs(event.remaining_days || 0)} days`,
            event,
            timestamp: new Date()
          });
        }
        
        // Due today
        else if (today === eventDate && event.status !== 'completed') {
          newAlerts.push({
            id: event.id,
            type: 'due_today',
            title: 'Test Due Today',
            message: `${event.test_type} for ${event.product} is due today`,
            event,
            timestamp: new Date()
          });
        }
        
        // Due tomorrow (24-48 hours)
        else if (tomorrowStr === eventDate && event.status !== 'completed') {
          newAlerts.push({
            id: event.id,
            type: 'due_soon',
            title: 'Test Due Tomorrow',
            message: `${event.test_type} for ${event.product} is due tomorrow`,
            event,
            timestamp: new Date()
          });
        }
      });

      setAlerts(newAlerts);

      // Show toast notifications for critical alerts
      const overdueCount = newAlerts.filter(a => a.type === 'overdue').length;
      const dueTodayCount = newAlerts.filter(a => a.type === 'due_today').length;

      if (overdueCount > 0 || dueTodayCount > 0) {
        let message = "";
        if (dueTodayCount > 0) {
          message += `🧪 ${dueTodayCount} test${dueTodayCount > 1 ? 's' : ''} due today`;
        }
        if (overdueCount > 0) {
          if (message) message += "\n";
          message += `❗ ${overdueCount} test${overdueCount > 1 ? 's are' : ' is'} overdue`;
        }

        toast({
          title: "Test Calendar Alerts",
          description: message,
          duration: 8000,
        });
      }
    };

    generateAlerts();
  }, [events, dismissedAlerts, toast]);

  const handleDismissAlert = (alertId: string) => {
    setDismissedAlerts(prev => new Set(prev).add(alertId));
    if (onDismiss) {
      onDismiss(alertId);
    }
  };

  const getAlertIcon = (type: NotificationAlert['type']) => {
    switch (type) {
      case 'overdue':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'due_today':
        return <Clock className="h-4 w-4 text-orange-500" />;
      case 'due_soon':
        return <Bell className="h-4 w-4 text-blue-500" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const getAlertColor = (type: NotificationAlert['type']) => {
    switch (type) {
      case 'overdue':
        return 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950/20';
      case 'due_today':
        return 'border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950/20';
      case 'due_soon':
        return 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950/20';
      default:
        return 'border-border bg-background';
    }
  };

  const getAlertBadgeColor = (type: NotificationAlert['type']) => {
    switch (type) {
      case 'overdue':
        return 'bg-red-500 text-white';
      case 'due_today':
        return 'bg-orange-500 text-white';
      case 'due_soon':
        return 'bg-blue-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  if (alerts.length === 0) return null;

  return (
    <div className="space-y-3">
      {alerts.map(alert => (
        <Card
          key={alert.id}
          className={cn(
            "p-4 border-l-4",
            getAlertColor(alert.type)
          )}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              {getAlertIcon(alert.type)}
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-sm">{alert.title}</h4>
                  <Badge className={cn("text-xs", getAlertBadgeColor(alert.type))}>
                    {alert.type.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
                
                <p className="text-sm text-muted-foreground mb-2">
                  {alert.message}
                </p>
                
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Memo: {alert.event.memo_id}</span>
                  <span>•</span>
                  <span>Due: {new Date(alert.event.due_date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleDismissAlert(alert.id)}
              className="h-8 w-8 p-0 ml-2"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
};

// Badge component for menu icon with notification count
export const TestCalendarNotificationBadge = ({
  events,
  className
}: {
  events: TestCalendarEvent[];
  className?: string;
}) => {
  const today = new Date().toISOString().split('T')[0];
  
  const criticalCount = events.filter(event => 
    (today > event.due_date || today === event.due_date) && 
    event.status !== 'completed'
  ).length;

  if (criticalCount === 0) return null;

  return (
    <Badge 
      className={cn(
        "absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs bg-red-500 text-white",
        className
      )}
    >
      {criticalCount > 9 ? '9+' : criticalCount}
    </Badge>
  );
};