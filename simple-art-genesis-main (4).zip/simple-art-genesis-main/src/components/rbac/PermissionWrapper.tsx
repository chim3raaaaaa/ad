// Permission-aware wrapper component
import React from 'react';
import { usePermissions } from '@/services/rbac/guards';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

interface PermissionWrapperProps {
  children: React.ReactNode;
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  fallback?: React.ReactNode;
  hideIfNoAccess?: boolean;
}

export function PermissionWrapper({
  children,
  permission,
  permissions = [],
  requireAll = false,
  fallback,
  hideIfNoAccess = false
}: PermissionWrapperProps) {
  const { hasPermission } = usePermissions();

  // Check single permission
  if (permission && !hasPermission(permission)) {
    console.log('Permission check failed:', { permission, hasPermission: hasPermission(permission) });
    if (hideIfNoAccess) return null;
    return fallback || (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          You don't have permission to access this feature.
        </AlertDescription>
      </Alert>
    );
  }

  // Check multiple permissions
  if (permissions.length > 0) {
    const hasAccess = requireAll
      ? permissions.every(p => hasPermission(p))
      : permissions.some(p => hasPermission(p));

    if (!hasAccess) {
      if (hideIfNoAccess) return null;
      return fallback || (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            You don't have permission to access this feature.
          </AlertDescription>
        </Alert>
      );
    }
  }

  return <>{children}</>;
}

// HOC for protecting entire components
export function withPermission<P extends object>(
  Component: React.ComponentType<P>,
  permission: string,
  fallback?: React.ComponentType<P>
) {
  return function PermissionProtectedComponent(props: P) {
    const { hasPermission } = usePermissions();

    if (!hasPermission(permission)) {
      if (fallback) {
        const FallbackComponent = fallback;
        return <FallbackComponent {...props} />;
      }
      return (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            You don't have permission to access this component.
          </AlertDescription>
        </Alert>
      );
    }

    return <Component {...props} />;
  };
}

// Button with permission checking
interface PermissionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  children: React.ReactNode;
}

export function PermissionButton({
  permission,
  permissions = [],
  requireAll = false,
  children,
  ...props
}: PermissionButtonProps) {
  const { hasPermission } = usePermissions();

  let hasAccess = true;

  if (permission) {
    hasAccess = hasPermission(permission);
  } else if (permissions.length > 0) {
    hasAccess = requireAll
      ? permissions.every(p => hasPermission(p))
      : permissions.some(p => hasPermission(p));
  }

  if (!hasAccess) {
    return null;
  }

  return (
    <button {...props}>
      {children}
    </button>
  );
}