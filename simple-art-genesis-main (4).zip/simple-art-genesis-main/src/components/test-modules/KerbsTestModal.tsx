import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { directInputService } from '@/services/database/DirectInputService';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface KerbsTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  memoId?: string;
  plantId?: string;
}

export function KerbsTestModal({ isOpen, onClose, onSuccess, memoId, plantId }: KerbsTestModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    // General Information
    memo_reference: memoId || '',
    plant_id: plantId || '',
    batch_id: '',
    test_date: new Date().toISOString().split('T')[0],
    operator: '',
    
    // Kerb Specifications
    kerb_type: '',
    kerb_profile: '',
    length: '',
    height: '',
    width: '',
    chamfer_dimensions: '',
    
    // Physical Properties
    compressive_strength: '',
    flexural_strength: '',
    water_absorption: '',
    freeze_thaw_resistance: '',
    impact_resistance: '',
    
    // Dimensional Checks
    length_tolerance: '',
    height_tolerance: '',
    width_tolerance: '',
    straightness: '',
    squareness: '',
    
    // Surface Quality
    surface_finish: '',
    color_consistency: '',
    texture_quality: '',
    defects: '',
    
    // Test Conditions
    curing_period: '',
    test_temperature: '',
    test_humidity: '',
    
    // Results
    pass_fail_status: 'pending',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): boolean => {
    const required = ['test_date', 'operator', 'kerb_type'];
    const missing = required.filter(field => !formData[field as keyof typeof formData]);
    
    if (missing.length > 0) {
      toast({
        title: "Validation Error",
        description: `Missing required fields: ${missing.join(', ')}`,
        variant: "destructive"
      });
      return false;
    }

    // Validate compressive strength (typical minimum: 40 MPa for kerbs)
    if (formData.compressive_strength && parseFloat(formData.compressive_strength) < 40) {
      toast({
        title: "Validation Warning",
        description: "Compressive strength below typical minimum of 40 MPa for kerbs",
        variant: "destructive"
      });
    }

    // Validate water absorption (typical limit: ≤ 6%)
    if (formData.water_absorption && parseFloat(formData.water_absorption) > 6) {
      toast({
        title: "Validation Warning",
        description: "Water absorption exceeds typical limit of 6%",
        variant: "destructive"
      });
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await directInputService.createDirectInputResult({
        product_type: 'kerbs',
        plant_id: formData.plant_id,
        memo_id: formData.memo_reference,
        test_data: formData,
        operator: formData.operator,
        test_date: formData.test_date,
        status: formData.pass_fail_status as 'pass' | 'fail' | 'pending'
      });

      toast({
        title: "Success",
        description: "Kerbs test entry saved successfully"
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving kerbs test:', error);
      toast({
        title: "Error",
        description: "Failed to save kerbs test entry",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Kerbs Test Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* General Information */}
          <Card>
            <CardHeader>
              <CardTitle>General Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="memo_reference">Memo Reference</Label>
                  <Input
                    id="memo_reference"
                    value={formData.memo_reference}
                    onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="batch_id">Batch ID</Label>
                  <Input
                    id="batch_id"
                    value={formData.batch_id}
                    onChange={(e) => handleInputChange('batch_id', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="test_date">Test Date *</Label>
                  <Input
                    id="test_date"
                    type="date"
                    value={formData.test_date}
                    onChange={(e) => handleInputChange('test_date', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="operator">Operator *</Label>
                  <Input
                    id="operator"
                    value={formData.operator}
                    onChange={(e) => handleInputChange('operator', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Kerb Specifications */}
          <Card>
            <CardHeader>
              <CardTitle>Kerb Specifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="kerb_type">Kerb Type *</Label>
                  <Select value={formData.kerb_type} onValueChange={(value) => handleInputChange('kerb_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select kerb type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="straight">Straight Kerb</SelectItem>
                      <SelectItem value="curved">Curved Kerb</SelectItem>
                      <SelectItem value="dropped">Dropped Kerb</SelectItem>
                      <SelectItem value="half_battered">Half Battered</SelectItem>
                      <SelectItem value="full_battered">Full Battered</SelectItem>
                      <SelectItem value="bullnose">Bullnose</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="kerb_profile">Kerb Profile</Label>
                  <Select value={formData.kerb_profile} onValueChange={(value) => handleInputChange('kerb_profile', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select profile" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bn1">BN1 (125mm high)</SelectItem>
                      <SelectItem value="bn2">BN2 (150mm high)</SelectItem>
                      <SelectItem value="bn3">BN3 (200mm high)</SelectItem>
                      <SelectItem value="hb1">HB1 (125mm high)</SelectItem>
                      <SelectItem value="hb2">HB2 (150mm high)</SelectItem>
                      <SelectItem value="custom">Custom Profile</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="length">Length (mm)</Label>
                  <Input
                    id="length"
                    type="number"
                    value={formData.length}
                    onChange={(e) => handleInputChange('length', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="height">Height (mm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={formData.height}
                    onChange={(e) => handleInputChange('height', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="width">Width (mm)</Label>
                  <Input
                    id="width"
                    type="number"
                    value={formData.width}
                    onChange={(e) => handleInputChange('width', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Physical Properties */}
          <Card>
            <CardHeader>
              <CardTitle>Physical Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="compressive_strength">Compressive Strength (MPa)</Label>
                  <Input
                    id="compressive_strength"
                    type="number"
                    step="0.1"
                    value={formData.compressive_strength}
                    onChange={(e) => handleInputChange('compressive_strength', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="flexural_strength">Flexural Strength (MPa)</Label>
                  <Input
                    id="flexural_strength"
                    type="number"
                    step="0.1"
                    value={formData.flexural_strength}
                    onChange={(e) => handleInputChange('flexural_strength', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                  <Input
                    id="water_absorption"
                    type="number"
                    step="0.1"
                    value={formData.water_absorption}
                    onChange={(e) => handleInputChange('water_absorption', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="freeze_thaw_resistance">Freeze-Thaw Resistance</Label>
                  <Select value={formData.freeze_thaw_resistance} onValueChange={(value) => handleInputChange('freeze_thaw_resistance', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality Control */}
          <Card>
            <CardHeader>
              <CardTitle>Quality Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pass_fail_status">Status</Label>
                  <Select value={formData.pass_fail_status} onValueChange={(value) => handleInputChange('pass_fail_status', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="pass">Pass</SelectItem>
                      <SelectItem value="fail">Fail</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="surface_finish">Surface Finish</Label>
                  <Select value={formData.surface_finish} onValueChange={(value) => handleInputChange('surface_finish', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select finish quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="acceptable">Acceptable</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <PermissionWrapper permission="tests.create">
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Test Entry'}
            </Button>
          </PermissionWrapper>
        </div>
      </DialogContent>
    </Dialog>
  );
}