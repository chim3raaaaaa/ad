import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { directInputService } from '@/services/database/DirectInputService';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface AggregatesTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  memoId?: string;
  plantId?: string;
}

export function AggregatesTestModal({ isOpen, onClose, onSuccess, memoId, plantId }: AggregatesTestModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    // General Information
    memo_reference: memoId || '',
    plant_id: plantId || '',
    batch_id: '',
    test_date: new Date().toISOString().split('T')[0],
    operator: '',
    
    // Aggregate Sample Information
    material_type: '',
    source_location: '',
    sample_id: '',
    sampling_date: '',
    sample_size: '',
    
    // Sieve Analysis (Grading)
    sieve_75mm: '',
    sieve_63mm: '',
    sieve_50mm: '',
    sieve_37_5mm: '',
    sieve_28mm: '',
    sieve_20mm: '',
    sieve_14mm: '',
    sieve_10mm: '',
    sieve_6_3mm: '',
    sieve_5mm: '',
    sieve_2_36mm: '',
    sieve_1_18mm: '',
    sieve_600um: '',
    sieve_300um: '',
    sieve_150um: '',
    sieve_75um: '',
    pan: '',
    
    // Physical Properties
    bulk_density: '',
    particle_density: '',
    water_absorption: '',
    moisture_content: '',
    specific_gravity: '',
    
    // Mechanical Properties
    aggregate_crushing_value: '',
    ten_percent_fines_value: '',
    impact_value: '',
    los_angeles_abrasion: '',
    
    // Chemical Properties
    sulfate_content: '',
    chloride_content: '',
    organic_impurities: '',
    alkali_silica_reactivity: '',
    
    // Shape and Texture
    flakiness_index: '',
    elongation_index: '',
    angularity_number: '',
    surface_texture: '',
    
    // Test Conditions
    test_temperature: '',
    test_humidity: '',
    drying_temperature: '',
    
    // Results
    grading_conformity: '',
    specification_compliance: '',
    pass_fail_status: 'pending',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): boolean => {
    const required = ['test_date', 'operator', 'material_type'];
    const missing = required.filter(field => !formData[field as keyof typeof formData]);
    
    if (missing.length > 0) {
      toast({
        title: "Validation Error",
        description: `Missing required fields: ${missing.join(', ')}`,
        variant: "destructive"
      });
      return false;
    }

    // Validate grading totals (should sum to ~100%)
    const sieveValues = [
      'sieve_75mm', 'sieve_63mm', 'sieve_50mm', 'sieve_37_5mm', 'sieve_28mm',
      'sieve_20mm', 'sieve_14mm', 'sieve_10mm', 'sieve_6_3mm', 'sieve_5mm',
      'sieve_2_36mm', 'sieve_1_18mm', 'sieve_600um', 'sieve_300um', 'sieve_150um', 'sieve_75um', 'pan'
    ];
    
    const numericValues = sieveValues
      .map(field => parseFloat(formData[field as keyof typeof formData] as string))
      .filter(val => !isNaN(val));
    
    if (numericValues.length > 0) {
      const total = numericValues.reduce((sum, val) => sum + val, 0);
      if (Math.abs(total - 100) > 5) {
        toast({
          title: "Validation Warning",
          description: `Sieve analysis total (${total.toFixed(1)}%) should be approximately 100%`,
          variant: "destructive"
        });
      }
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await directInputService.createDirectInputResult({
        product_type: 'aggregates',
        plant_id: formData.plant_id,
        memo_id: formData.memo_reference,
        test_data: formData,
        operator: formData.operator,
        test_date: formData.test_date,
        status: formData.pass_fail_status as 'pass' | 'fail' | 'pending'
      });

      toast({
        title: "Success",
        description: "Aggregates test entry saved successfully"
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving aggregates test:', error);
      toast({
        title: "Error",
        description: "Failed to save aggregates test entry",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Aggregates Test Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* General Information */}
          <Card>
            <CardHeader>
              <CardTitle>General Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="memo_reference">Memo Reference</Label>
                  <Input
                    id="memo_reference"
                    value={formData.memo_reference}
                    onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="batch_id">Batch ID</Label>
                  <Input
                    id="batch_id"
                    value={formData.batch_id}
                    onChange={(e) => handleInputChange('batch_id', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="test_date">Test Date *</Label>
                  <Input
                    id="test_date"
                    type="date"
                    value={formData.test_date}
                    onChange={(e) => handleInputChange('test_date', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="operator">Operator *</Label>
                  <Input
                    id="operator"
                    value={formData.operator}
                    onChange={(e) => handleInputChange('operator', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sample Information */}
          <Card>
            <CardHeader>
              <CardTitle>Sample Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="material_type">Material Type *</Label>
                  <Select value={formData.material_type} onValueChange={(value) => handleInputChange('material_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select material type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="coarse_aggregate">Coarse Aggregate</SelectItem>
                      <SelectItem value="fine_aggregate">Fine Aggregate</SelectItem>
                      <SelectItem value="all_in_aggregate">All-in Aggregate</SelectItem>
                      <SelectItem value="crushed_stone">Crushed Stone</SelectItem>
                      <SelectItem value="natural_sand">Natural Sand</SelectItem>
                      <SelectItem value="manufactured_sand">Manufactured Sand</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="source_location">Source Location</Label>
                  <Input
                    id="source_location"
                    value={formData.source_location}
                    onChange={(e) => handleInputChange('source_location', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sample_id">Sample ID</Label>
                  <Input
                    id="sample_id"
                    value={formData.sample_id}
                    onChange={(e) => handleInputChange('sample_id', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sample_size">Sample Size (kg)</Label>
                  <Input
                    id="sample_size"
                    type="number"
                    step="0.1"
                    value={formData.sample_size}
                    onChange={(e) => handleInputChange('sample_size', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sieve Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Sieve Analysis (% Passing)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="sieve_75mm">75mm</Label>
                  <Input
                    id="sieve_75mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_75mm}
                    onChange={(e) => handleInputChange('sieve_75mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_63mm">63mm</Label>
                  <Input
                    id="sieve_63mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_63mm}
                    onChange={(e) => handleInputChange('sieve_63mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_50mm">50mm</Label>
                  <Input
                    id="sieve_50mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_50mm}
                    onChange={(e) => handleInputChange('sieve_50mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_37_5mm">37.5mm</Label>
                  <Input
                    id="sieve_37_5mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_37_5mm}
                    onChange={(e) => handleInputChange('sieve_37_5mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_20mm">20mm</Label>
                  <Input
                    id="sieve_20mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_20mm}
                    onChange={(e) => handleInputChange('sieve_20mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_14mm">14mm</Label>
                  <Input
                    id="sieve_14mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_14mm}
                    onChange={(e) => handleInputChange('sieve_14mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_10mm">10mm</Label>
                  <Input
                    id="sieve_10mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_10mm}
                    onChange={(e) => handleInputChange('sieve_10mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_5mm">5mm</Label>
                  <Input
                    id="sieve_5mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_5mm}
                    onChange={(e) => handleInputChange('sieve_5mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_2_36mm">2.36mm</Label>
                  <Input
                    id="sieve_2_36mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_2_36mm}
                    onChange={(e) => handleInputChange('sieve_2_36mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_1_18mm">1.18mm</Label>
                  <Input
                    id="sieve_1_18mm"
                    type="number"
                    step="0.1"
                    value={formData.sieve_1_18mm}
                    onChange={(e) => handleInputChange('sieve_1_18mm', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_600um">600μm</Label>
                  <Input
                    id="sieve_600um"
                    type="number"
                    step="0.1"
                    value={formData.sieve_600um}
                    onChange={(e) => handleInputChange('sieve_600um', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_300um">300μm</Label>
                  <Input
                    id="sieve_300um"
                    type="number"
                    step="0.1"
                    value={formData.sieve_300um}
                    onChange={(e) => handleInputChange('sieve_300um', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_150um">150μm</Label>
                  <Input
                    id="sieve_150um"
                    type="number"
                    step="0.1"
                    value={formData.sieve_150um}
                    onChange={(e) => handleInputChange('sieve_150um', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sieve_75um">75μm</Label>
                  <Input
                    id="sieve_75um"
                    type="number"
                    step="0.1"
                    value={formData.sieve_75um}
                    onChange={(e) => handleInputChange('sieve_75um', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="pan">Pan</Label>
                  <Input
                    id="pan"
                    type="number"
                    step="0.1"
                    value={formData.pan}
                    onChange={(e) => handleInputChange('pan', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Physical Properties */}
          <Card>
            <CardHeader>
              <CardTitle>Physical Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="bulk_density">Bulk Density (kg/m³)</Label>
                  <Input
                    id="bulk_density"
                    type="number"
                    value={formData.bulk_density}
                    onChange={(e) => handleInputChange('bulk_density', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="particle_density">Particle Density (kg/m³)</Label>
                  <Input
                    id="particle_density"
                    type="number"
                    value={formData.particle_density}
                    onChange={(e) => handleInputChange('particle_density', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                  <Input
                    id="water_absorption"
                    type="number"
                    step="0.1"
                    value={formData.water_absorption}
                    onChange={(e) => handleInputChange('water_absorption', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="moisture_content">Moisture Content (%)</Label>
                  <Input
                    id="moisture_content"
                    type="number"
                    step="0.1"
                    value={formData.moisture_content}
                    onChange={(e) => handleInputChange('moisture_content', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mechanical Properties */}
          <Card>
            <CardHeader>
              <CardTitle>Mechanical Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="aggregate_crushing_value">Aggregate Crushing Value (%)</Label>
                  <Input
                    id="aggregate_crushing_value"
                    type="number"
                    step="0.1"
                    value={formData.aggregate_crushing_value}
                    onChange={(e) => handleInputChange('aggregate_crushing_value', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="impact_value">Aggregate Impact Value (%)</Label>
                  <Input
                    id="impact_value"
                    type="number"
                    step="0.1"
                    value={formData.impact_value}
                    onChange={(e) => handleInputChange('impact_value', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="ten_percent_fines_value">Ten Percent Fines Value (kN)</Label>
                  <Input
                    id="ten_percent_fines_value"
                    type="number"
                    step="0.1"
                    value={formData.ten_percent_fines_value}
                    onChange={(e) => handleInputChange('ten_percent_fines_value', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="los_angeles_abrasion">Los Angeles Abrasion (%)</Label>
                  <Input
                    id="los_angeles_abrasion"
                    type="number"
                    step="0.1"
                    value={formData.los_angeles_abrasion}
                    onChange={(e) => handleInputChange('los_angeles_abrasion', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality Control */}
          <Card>
            <CardHeader>
              <CardTitle>Quality Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pass_fail_status">Status</Label>
                  <Select value={formData.pass_fail_status} onValueChange={(value) => handleInputChange('pass_fail_status', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="pass">Pass</SelectItem>
                      <SelectItem value="fail">Fail</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="grading_conformity">Grading Conformity</Label>
                  <Select value={formData.grading_conformity} onValueChange={(value) => handleInputChange('grading_conformity', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select conformity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="conforms">Conforms</SelectItem>
                      <SelectItem value="minor_deviation">Minor Deviation</SelectItem>
                      <SelectItem value="major_deviation">Major Deviation</SelectItem>
                      <SelectItem value="does_not_conform">Does Not Conform</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <PermissionWrapper permission="tests.create">
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Test Entry'}
            </Button>
          </PermissionWrapper>
        </div>
      </DialogContent>
    </Dialog>
  );
}