import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';
import { plantTestService } from '@/services/database/plantTestService';
import { useMemoTestSystem } from '@/hooks/useMemoTestSystem';
import { toast } from '@/hooks/use-toast';
import { AlertCircle, Upload, FileText, CheckCircle, X, TestTube } from 'lucide-react';
import { PaversTestModal } from './PaversTestModal';
import { KerbsTestModal } from './KerbsTestModal';
import { FlagstonesTestModal } from './FlagstonesTestModal';

interface TestEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: string;
  tableName: string;
  entry?: any;
  onSuccess: () => void;
  enableMemoIntegration?: boolean;
}

export function TestEntryModal({ 
  isOpen, 
  onClose, 
  category, 
  tableName, 
  entry, 
  onSuccess,
  enableMemoIntegration = false
}: TestEntryModalProps) {
  const [formData, setFormData] = useState<any>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [pendingTests, setPendingTests] = useState<any[]>([]);
  const [selectedTestAssignment, setSelectedTestAssignment] = useState<any>(null);
  const [loadingTests, setLoadingTests] = useState(false);
  
  const { data: dropdownOptions, loading: optionsLoading } = useAllDropdownOptions();
  const { getMemoTestAssignments, submitTestResult } = useMemoTestSystem();

  // Initialize form data
  useEffect(() => {
    if (entry) {
      setFormData(entry);
    } else {
      // Initialize with default values based on category
      const defaultData = getDefaultFormData(category);
      setFormData(defaultData);
    }
  }, [entry, category]);

  // Load pending tests when memo integration is enabled
  useEffect(() => {
    const loadPendingTests = async () => {
      if (!isOpen || !enableMemoIntegration || !category) return;
      
      setLoadingTests(true);
      try {
        // For now, we'll use a placeholder since getMemoTestAssignments needs a memo reference
        // In a real implementation, this would get all assignments for the category
        const allAssignments = await getMemoTestAssignments('');
        const categoryTests = allAssignments.filter(test => 
          test.test_category === category && 
          (test.status === 'pending' || test.status === 'in_progress')
        );
        setPendingTests(categoryTests);
      } catch (error) {
        console.error('Error loading pending tests:', error);
      } finally {
        setLoadingTests(false);
      }
    };

    loadPendingTests();
  }, [isOpen, enableMemoIntegration, category, getMemoTestAssignments]);

  // Get default form data based on category
  const getDefaultFormData = (category: string) => {
    const baseData = {
      production_date: new Date().toISOString().split('T')[0],
      test_date: new Date().toISOString().split('T')[0],
      test_performed: false,
      observations: '',
      calculation_sheet_path: null
    };

    switch (category) {
      case 'aggregates':
        return {
          ...baseData,
          memo_reference: '',
          sampling_date: new Date().toISOString().split('T')[0],
          plant_id: '',
          officer_id: '',
          aggregate_type_id: '',
          machine_id: '',
          sampling_place_id: '',
          moisture_condition_id: '',
          climatic_condition_id: '',
          sampled_by_id: '',
          // Sieve analysis
          sieve_0_075: null,
          sieve_0_15: null,
          sieve_0_3: null,
          sieve_0_6: null,
          sieve_1_18: null,
          sieve_2_36: null,
          sieve_5: null,
          sieve_10: null,
          // Physical properties
          moisture_content: null,
          fineness_modulus: null,
          sand_equivalent: null,
          methylene_blue: null,
          // Density properties
          bulk_density_loose: null,
          bulk_density_compacted: null,
          bulk_density_ssd: null,
          bulk_density_apparent: null,
          bulk_density_oven_dried: null,
          water_absorption: null,
          organic_impurities: '',
          grading_conformity: 'pending',
          cleanliness_conformity: 'pending'
        };
      
      case 'blocks':
        return {
          ...baseData,
          memo_reference: '',
          age_days: 28,
          plant_id: '',
          officer_id: '',
          product_id: '',
          grade_mpa: 15,
          machine_id: '',
          mould_reference: '',
          production_details: '',
          samples_for_test: 6,
          block_position_number: '',
          dimensions: { length: null, width: null, height: null },
          compressive_strength: null,
          water_absorption: null,
          density: null,
          thermal_conductivity: null,
          quality_conformity: 'pending'
        };
      
      case 'cubes':
        return {
          ...baseData,
          memo_reference: '',
          age_days: 28,
          plant_id: '',
          officer_id: '',
          concrete_grade: '',
          mix_design_ref: '',
          machine_id: '',
          batch_number: '',
          cast_time: '',
          curing_method: '',
          cube_dimensions: { length: null, width: null, height: null },
          compressive_strength_7_day: null,
          compressive_strength_28_day: null,
          compressive_strength_actual: null,
          failure_mode: '',
          density: null,
          strength_conformity: 'pending'
        };
      
      default:
        return baseData;
    }
  };

  // Handle form field changes
  const handleFieldChange = (field: string, value: any) => {
    setFormData((prev: any) => {
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        return {
          ...prev,
          [parent]: {
            ...prev[parent],
            [child]: value
          }
        };
      }
      return {
        ...prev,
        [field]: value
      };
    });
  };

  // Handle file attachment
  const handleFileAttachment = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type === 'application/pdf') {
        setAttachedFile(file);
        toast({
          title: "File Attached",
          description: `${file.name} ready for upload`
        });
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please select a PDF file",
          variant: "destructive"
        });
      }
    }
  };

  // Validate form data
  const validateForm = async (): Promise<boolean> => {
    const validation = await plantTestService.validateTestData(
      category,
      formData,
      dropdownOptions
    );
    
    setValidationErrors(validation.errors);
    return validation.isValid;
  };

  // Handle memo test assignment selection
  const handleTestAssignmentSelection = (assignmentId: string) => {
    const assignment = pendingTests.find(t => t.id === assignmentId);
    setSelectedTestAssignment(assignment);
    if (assignment) {
      setFormData(prev => ({
        ...prev,
        memo_reference: assignment.memo_reference,
        test_type: assignment.test_type
      }));
    }
  };

  // Handle form submission
  const handleSubmit = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      // If memo integration is enabled and we have a test assignment
      if (enableMemoIntegration && selectedTestAssignment) {
        // Submit as test result completion
        const testResults = {
          ...formData,
          test_type: selectedTestAssignment.test_type,
          test_category: selectedTestAssignment.test_category,
          memo_reference: selectedTestAssignment.memo_reference,
          officer_tested: formData.officer_id,
          test_date: formData.test_date,
          status: 'completed',
          submitted_at: new Date().toISOString()
        };

        await submitTestResult(selectedTestAssignment.id, testResults);
        
        toast({
          title: "Test Results Submitted",
          description: `Results for ${selectedTestAssignment.test_type} completed successfully`
        });
      } else {
        // Regular test entry creation/update
        // Validate form
        const isValid = await validateForm();
        if (!isValid) {
          setIsSubmitting(false);
          return;
        }

        // Upload file if attached
        let calculationSheetPath = formData.calculation_sheet_path;
        if (attachedFile) {
          calculationSheetPath = `calculations/${Date.now()}_${attachedFile.name}`;
          
          if (typeof window !== 'undefined' && (window as any).electronAPI) {
            await (window as any).electronAPI.saveFile(attachedFile, calculationSheetPath);
          }
        }

        const entryData = {
          ...formData,
          calculation_sheet_path: calculationSheetPath
        };

        if (entry?.id) {
          await plantTestService.updateTestEntry(category, tableName, entry.id, entryData);
          toast({
            title: "Entry Updated",
            description: "Test entry updated successfully"
          });
        } else {
          await plantTestService.createTestEntry(category, tableName, entryData);
          toast({
            title: "Entry Created",
            description: "Test entry created successfully"
          });
        }
      }

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving test entry:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save test entry",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Render form fields based on category
  const renderFormFields = () => {
    if (optionsLoading) {
      return <div>Loading form fields...</div>;
    }

    switch (category) {
      case 'aggregates':
        return renderAggregatesForm();
      case 'blocks':
        return renderBlocksForm();
      case 'cubes':
        return renderCubesForm();
      default:
        return <div>Form not implemented for this category</div>;
    }
  };

  // Render aggregates form
  const renderAggregatesForm = () => (
    <div className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Memo Reference</Label>
            <Input
              value={formData.memo_reference || ''}
              onChange={(e) => handleFieldChange('memo_reference', e.target.value)}
              placeholder="Enter memo reference"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Plant</Label>
            <Select
              value={formData.plant_id || ''}
              onValueChange={(value) => handleFieldChange('plant_id', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select plant" />
              </SelectTrigger>
              <SelectContent>
                {dropdownOptions?.plants?.filter(plant => plant?.id).map((plant: any) => (
                  <SelectItem key={`entry-modal-plant-${plant.id}`} value={plant.id}>
                    {plant.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Officer</Label>
            <Select
              value={formData.officer_id || ''}
              onValueChange={(value) => handleFieldChange('officer_id', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select officer" />
              </SelectTrigger>
              <SelectContent>
                {dropdownOptions?.officers?.map((officer: any) => (
                  <SelectItem key={`entry-modal-officer-${officer.id}`} value={officer.id}>
                    {officer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Aggregate Type</Label>
            <Select
              value={formData.aggregate_type_id || ''}
              onValueChange={(value) => handleFieldChange('aggregate_type_id', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select aggregate type" />
              </SelectTrigger>
              <SelectContent>
                {dropdownOptions?.aggregateTypes?.map((type: any) => (
                  <SelectItem key={`entry-modal-aggregate-${type.id}`} value={type.id}>
                    {type.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Dates */}
      <Card>
        <CardHeader>
          <CardTitle>Test Dates</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Production Date</Label>
            <Input
              type="date"
              value={formData.production_date || ''}
              onChange={(e) => handleFieldChange('production_date', e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Sampling Date</Label>
            <Input
              type="date"
              value={formData.sampling_date || ''}
              onChange={(e) => handleFieldChange('sampling_date', e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Test Date</Label>
            <Input
              type="date"
              value={formData.test_date || ''}
              onChange={(e) => handleFieldChange('test_date', e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Sieve Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Sieve Analysis (% Passing)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-4 gap-4">
          {[
            { field: 'sieve_0_075', label: '0.075mm' },
            { field: 'sieve_0_15', label: '0.15mm' },
            { field: 'sieve_0_3', label: '0.3mm' },
            { field: 'sieve_0_6', label: '0.6mm' },
            { field: 'sieve_1_18', label: '1.18mm' },
            { field: 'sieve_2_36', label: '2.36mm' },
            { field: 'sieve_5', label: '5mm' },
            { field: 'sieve_10', label: '10mm' }
          ].map(({ field, label }) => (
            <div key={field} className="space-y-2">
              <Label>{label}</Label>
              <Input
                type="number"
                step="0.1"
                value={formData[field] || ''}
                onChange={(e) => handleFieldChange(field, parseFloat(e.target.value) || null)}
                placeholder="% passing"
              />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );

  // Render blocks form
  const renderBlocksForm = () => (
    <div className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Memo Reference</Label>
            <Input
              value={formData.memo_reference || ''}
              onChange={(e) => handleFieldChange('memo_reference', e.target.value)}
              placeholder="Enter memo reference"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Plant</Label>
            <Select
              value={formData.plant_id || ''}
              onValueChange={(value) => handleFieldChange('plant_id', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select plant" />
              </SelectTrigger>
              <SelectContent>
                {dropdownOptions?.plants?.filter(plant => plant?.id).map((plant: any) => (
                  <SelectItem key={`blocks-modal-plant-${plant.id}`} value={plant.id}>
                    {plant.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Grade (MPA)</Label>
            <Input
              type="number"
              value={formData.grade_mpa || ''}
              onChange={(e) => handleFieldChange('grade_mpa', parseFloat(e.target.value) || null)}
              placeholder="Enter grade"
            />
          </div>

          <div className="space-y-2">
            <Label>Age (Days)</Label>
            <Input
              type="number"
              value={formData.age_days || ''}
              onChange={(e) => handleFieldChange('age_days', parseInt(e.target.value) || null)}
              placeholder="Enter age in days"
            />
          </div>
        </CardContent>
      </Card>

      {/* Dimensions */}
      <Card>
        <CardHeader>
          <CardTitle>Block Dimensions (mm)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Length</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.dimensions?.length || ''}
              onChange={(e) => handleFieldChange('dimensions.length', parseFloat(e.target.value) || null)}
              placeholder="Length (mm)"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Width</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.dimensions?.width || ''}
              onChange={(e) => handleFieldChange('dimensions.width', parseFloat(e.target.value) || null)}
              placeholder="Width (mm)"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Height</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.dimensions?.height || ''}
              onChange={(e) => handleFieldChange('dimensions.height', parseFloat(e.target.value) || null)}
              placeholder="Height (mm)"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Render cubes form
  const renderCubesForm = () => (
    <div className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Memo Reference</Label>
            <Input
              value={formData.memo_reference || ''}
              onChange={(e) => handleFieldChange('memo_reference', e.target.value)}
              placeholder="Enter memo reference"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Concrete Grade</Label>
            <Input
              value={formData.concrete_grade || ''}
              onChange={(e) => handleFieldChange('concrete_grade', e.target.value)}
              placeholder="e.g., C25"
            />
          </div>

          <div className="space-y-2">
            <Label>Mix Design Reference</Label>
            <Input
              value={formData.mix_design_ref || ''}
              onChange={(e) => handleFieldChange('mix_design_ref', e.target.value)}
              placeholder="Enter mix design ref"
            />
          </div>

          <div className="space-y-2">
            <Label>Batch Number</Label>
            <Input
              value={formData.batch_number || ''}
              onChange={(e) => handleFieldChange('batch_number', e.target.value)}
              placeholder="Enter batch number"
            />
          </div>
        </CardContent>
      </Card>

      {/* Strength Results */}
      <Card>
        <CardHeader>
          <CardTitle>Compressive Strength Results (MPa)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>7-Day Strength</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.compressive_strength_7_day || ''}
              onChange={(e) => handleFieldChange('compressive_strength_7_day', parseFloat(e.target.value) || null)}
              placeholder="MPa"
            />
          </div>
          
          <div className="space-y-2">
            <Label>28-Day Strength</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.compressive_strength_28_day || ''}
              onChange={(e) => handleFieldChange('compressive_strength_28_day', parseFloat(e.target.value) || null)}
              placeholder="MPa"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Actual Strength</Label>
            <Input
              type="number"
              step="0.1"
              value={formData.compressive_strength_actual || ''}
              onChange={(e) => handleFieldChange('compressive_strength_actual', parseFloat(e.target.value) || null)}
              placeholder="MPa"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {entry ? 'Edit' : 'Add'} {category.charAt(0).toUpperCase() + category.slice(1)} Test Entry
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Test Assignment Selection (Memo Integration) */}
          {enableMemoIntegration && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TestTube className="h-5 w-5" />
                  Select Test Assignment
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingTests ? (
                  <div className="text-center py-4">Loading pending tests...</div>
                ) : pendingTests.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <TestTube className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No pending tests found for {category}</p>
                    <p className="text-sm">Create a memo with test assignments first</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Label>Select a test to enter results for:</Label>
                    <div className="grid gap-3">
                      {pendingTests.map((test) => (
                        <div
                          key={test.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            selectedTestAssignment?.id === test.id
                              ? 'border-primary bg-primary/5'
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => handleTestAssignmentSelection(test.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">{test.memo_reference}</div>
                              <div className="text-sm text-muted-foreground">
                                {test.test_type} • Assigned: {new Date(test.assigned_date).toLocaleDateString()}
                              </div>
                            </div>
                            <Badge variant={test.status === 'in_progress' ? 'default' : 'secondary'}>
                              {test.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Validation Errors */}
          {validationErrors.length > 0 && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-2 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Please fix the following errors:</span>
                </div>
                <ul className="mt-2 list-disc list-inside text-sm text-destructive">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Form Fields */}
          {renderFormFields()}

          {/* Test Performed Toggle */}
          <Card>
            <CardHeader>
              <CardTitle>Test Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.test_performed || false}
                  onCheckedChange={(value) => handleFieldChange('test_performed', value)}
                />
                <Label>Test Performed</Label>
                {formData.test_performed ? (
                  <Badge variant="default" className="ml-2">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="ml-2">
                    Pending
                  </Badge>
                )}
              </div>
              
              <div className="space-y-2">
                <Label>Observations</Label>
                <Textarea
                  value={formData.observations || ''}
                  onChange={(e) => handleFieldChange('observations', e.target.value)}
                  placeholder="Enter any observations or notes"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* File Attachment */}
          <Card>
            <CardHeader>
              <CardTitle>Calculation Sheet (Optional)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <Input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileAttachment}
                  className="flex-1"
                />
                <Button variant="outline" size="sm">
                  <Upload className="h-4 w-4 mr-2" />
                  Browse
                </Button>
              </div>
              
              {attachedFile && (
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <FileText className="h-4 w-4" />
                  <span>{attachedFile.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setAttachedFile(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
              
              {formData.calculation_sheet_path && !attachedFile && (
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <FileText className="h-4 w-4" />
                  <span>Current file: {formData.calculation_sheet_path}</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="flex justify-end space-x-4 pt-6">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isSubmitting || (enableMemoIntegration && !selectedTestAssignment)}
          >
            {isSubmitting ? 'Saving...' : 
             enableMemoIntegration ? 'Submit Test Results' :
             entry ? 'Update Entry' : 'Create Entry'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}