import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Search, LinkIcon, Eye, Edit } from 'lucide-react';

interface MemoIntegrationProps {
  category: string;
  tableName?: string;
  testEntries: any[];
  onTestEntryClick?: (entry: any) => void;
}

interface MemoLink {
  id: string;
  memo_reference: string;
  test_id: string;
  linked_at: string;
  status: 'pending' | 'completed' | 'verified';
}

export function MemoIntegration({ category, tableName, testEntries, onTestEntryClick }: MemoIntegrationProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [memoLinks, setMemoLinks] = useState<MemoLink[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<any>(null);
  const [showLinkDialog, setShowLinkDialog] = useState(false);

  // Load memo links from localStorage
  React.useEffect(() => {
    const stored = localStorage.getItem('memo_links');
    if (stored) {
      setMemoLinks(JSON.parse(stored));
    }
  }, []);

  // Enhanced search and filtering
  const filteredEntries = useMemo(() => {
    let filtered = testEntries;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(entry => 
        entry.memo_reference?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.officer_id?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(entry => entry.pass_fail_status === statusFilter);
    }

    return filtered;
  }, [testEntries, searchTerm, statusFilter]);

  // Group entries by memo reference
  const groupedByMemo = useMemo(() => {
    const groups: { [key: string]: any[] } = {};
    filteredEntries.forEach(entry => {
      const memoRef = entry.memo_reference || 'unlinked';
      if (!groups[memoRef]) {
        groups[memoRef] = [];
      }
      groups[memoRef].push(entry);
    });
    return groups;
  }, [filteredEntries]);

  const linkToMemo = async (testEntry: any, memoReference: string) => {
    try {
      // Update test entry with memo reference
      if (tableName) {
        const stored = localStorage.getItem(tableName);
        const entries = stored ? JSON.parse(stored) : [];
        const index = entries.findIndex((e: any) => e.id === testEntry.id);
        
        if (index !== -1) {
          entries[index].memo_reference = memoReference;
          entries[index].updated_at = new Date().toISOString();
          localStorage.setItem(tableName, JSON.stringify(entries));
        }
      }

      // Create memo link record
      const newLink: MemoLink = {
        id: `link_${Date.now()}`,
        memo_reference: memoReference,
        test_id: testEntry.id,
        linked_at: new Date().toISOString(),
        status: 'pending'
      };

      const updatedLinks = [...memoLinks, newLink];
      setMemoLinks(updatedLinks);
      localStorage.setItem('memo_links', JSON.stringify(updatedLinks));

      toast({
        title: "Test Linked to Memo",
        description: `Test entry linked to memo ${memoReference}`
      });

      setShowLinkDialog(false);
      setSelectedEntry(null);

    } catch (error) {
      toast({
        title: "Link Failed",
        description: "Failed to link test entry to memo",
        variant: "destructive"
      });
    }
  };

  const updateLinkStatus = (testId: string, status: 'pending' | 'completed' | 'verified') => {
    const updatedLinks = memoLinks.map(link => 
      link.test_id === testId ? { ...link, status } : link
    );
    setMemoLinks(updatedLinks);
    localStorage.setItem('memo_links', JSON.stringify(updatedLinks));

    toast({
      title: "Status Updated",
      description: `Test status updated to ${status}`
    });
  };

  const getMemoLinkStatus = (testId: string): string => {
    const link = memoLinks.find(l => l.test_id === testId);
    return link?.status || 'unlinked';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'default';
      case 'verified': return 'default';
      case 'pending': return 'secondary';
      default: return 'destructive';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <LinkIcon className="h-5 w-5 mr-2" />
            Memo Integration
          </span>
          <Badge variant="outline">
            {Object.keys(groupedByMemo).length} memo(s)
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search and Filter Controls */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by memo reference, test ID, or officer..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pass">Pass</SelectItem>
              <SelectItem value="fail">Fail</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Grouped Test Entries by Memo */}
        <div className="space-y-4">
          {Object.entries(groupedByMemo).map(([memoRef, entries]) => (
            <div key={memoRef} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">
                  {memoRef === 'unlinked' ? 'Unlinked Tests' : `Memo: ${memoRef}`}
                </h4>
                <Badge variant={memoRef === 'unlinked' ? 'destructive' : 'default'}>
                  {entries.length} test{entries.length !== 1 ? 's' : ''}
                </Badge>
              </div>

              <div className="space-y-2">
                {entries.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                    <div className="flex items-center space-x-3">
                      <Badge variant={getStatusColor(entry.pass_fail_status)}>
                        {entry.pass_fail_status}
                      </Badge>
                      <span className="text-sm font-mono">{entry.id}</span>
                      <span className="text-sm text-muted-foreground">
                        {new Date(entry.test_date).toLocaleDateString()}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {getMemoLinkStatus(entry.id)}
                      </Badge>
                    </div>

                    <div className="flex items-center space-x-2">
                      {!entry.memo_reference && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedEntry(entry);
                            setShowLinkDialog(true);
                          }}
                        >
                          <LinkIcon className="h-4 w-4" />
                          Link
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onTestEntryClick?.(entry)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      {entry.memo_reference && (
                        <Select
                          value={getMemoLinkStatus(entry.id)}
                          onValueChange={(status: 'pending' | 'completed' | 'verified') => 
                            updateLinkStatus(entry.id, status)
                          }
                        >
                          <SelectTrigger className="h-8 w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="completed">Complete</SelectItem>
                            <SelectItem value="verified">Verified</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {filteredEntries.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <LinkIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No test entries found</p>
            <p className="text-sm">Adjust your search or filters</p>
          </div>
        )}

        {/* Link to Memo Dialog */}
        <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Link Test to Memo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-2">
                  Test Entry: {selectedEntry?.id}
                </p>
                <Input
                  placeholder="Enter memo reference (e.g., RTB240125001)"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const memoRef = (e.target as HTMLInputElement).value.trim();
                      if (memoRef && selectedEntry) {
                        linkToMemo(selectedEntry, memoRef);
                      }
                    }
                  }}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowLinkDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={() => {
                  const input = document.querySelector('input[placeholder*="memo reference"]') as HTMLInputElement;
                  const memoRef = input?.value.trim();
                  if (memoRef && selectedEntry) {
                    linkToMemo(selectedEntry, memoRef);
                  }
                }}>
                  Link to Memo
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}