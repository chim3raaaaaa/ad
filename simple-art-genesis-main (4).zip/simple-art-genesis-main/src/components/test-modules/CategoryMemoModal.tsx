import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Upload, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';
import { toast } from '@/hooks/use-toast';

interface CategoryMemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: string;
  onSubmit: (memoData: any) => void;
}

interface MemoFormData {
  memo_reference: string;
  category: string;
  product_id: string;
  plant_id: string;
  officer_id: string;
  machine_id?: string;
  production_date: Date | null;
  additional_notes?: string;
  pdf_file?: File;
}

export function CategoryMemoModal({ isOpen, onClose, category, onSubmit }: CategoryMemoModalProps) {
  const { data: dropdownOptions, loading } = useAllDropdownOptions();
  const [formData, setFormData] = useState<MemoFormData>({
    memo_reference: '',
    category,
    product_id: '',
    plant_id: '',
    officer_id: '',
    machine_id: '',
    production_date: null,
    additional_notes: ''
  });

  // Generate memo reference when category or plant changes
  useEffect(() => {
    if (formData.plant_id && category) {
      const plantCode = dropdownOptions.plants?.find(p => p.value === formData.plant_id)?.label?.slice(0, 3).toUpperCase() || 'UNK';
      const categoryCode = category.slice(0, 3).toUpperCase();
      const dateCode = new Date().toISOString().slice(2, 10).replace(/-/g, '');
      const randomCode = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      
      const memoRef = `${categoryCode}${plantCode}${dateCode}${randomCode}`;
      setFormData(prev => ({ ...prev, memo_reference: memoRef }));
    }
  }, [formData.plant_id, category, dropdownOptions.plants]);

  const handleInputChange = (field: keyof MemoFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setFormData(prev => ({ ...prev, pdf_file: file }));
      toast({
        title: "PDF Uploaded",
        description: `${file.name} has been attached to the memo.`
      });
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a PDF file only.",
        variant: "destructive"
      });
    }
  };

  const handleSubmit = () => {
    // Validation
    const requiredFields = ['memo_reference', 'product_id', 'plant_id', 'officer_id', 'production_date'];
    const missingFields = requiredFields.filter(field => !formData[field as keyof MemoFormData]);
    
    if (missingFields.length > 0) {
      toast({
        title: "Missing Required Fields",
        description: `Please fill in: ${missingFields.join(', ')}`,
        variant: "destructive"
      });
      return;
    }

    // Submit the memo data
    onSubmit({
      ...formData,
      category,
      production_date: formData.production_date?.toISOString().split('T')[0]
    });
    
    // Reset form and close
    setFormData({
      memo_reference: '',
      category,
      product_id: '',
      plant_id: '',
      officer_id: '',
      machine_id: '',
      production_date: null,
      additional_notes: ''
    });
    onClose();
  };

  const getCategoryTitle = () => {
    const titles = {
      aggregates: 'Aggregate Production Memo',
      blocks: 'Block Production Memo',
      cubes: 'Cube Test Memo',
      pavers: 'Paver Production Memo',
      kerbs: 'Kerb Production Memo',
      flagstones: 'Flagstone Production Memo'
    };
    return titles[category as keyof typeof titles] || 'Production Memo';
  };

  // Filter products by category
  const categoryProducts = dropdownOptions.products?.filter(product => 
    product.category?.toLowerCase() === category.toLowerCase()
  ) || [];

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[600px]">
          <div className="flex items-center justify-center p-6">
            <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
            <span className="ml-2">Loading reference data...</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{getCategoryTitle()}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Memo Reference */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Memo Reference</CardTitle>
            </CardHeader>
            <CardContent>
              <Input
                value={formData.memo_reference}
                onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                placeholder="Auto-generated memo reference"
                className="font-mono"
              />
            </CardContent>
          </Card>

          {/* Core Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Production Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Plant Selection */}
                <div className="space-y-2">
                  <Label htmlFor="plant">Plant *</Label>
                  <Select value={formData.plant_id} onValueChange={(value) => handleInputChange('plant_id', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select plant" />
                    </SelectTrigger>
                    <SelectContent>
                      {dropdownOptions.plants?.map((plant) => (
                        <SelectItem key={plant.value} value={plant.value}>
                          {plant.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Product Selection */}
                <div className="space-y-2">
                  <Label htmlFor="product">Product *</Label>
                  <Select value={formData.product_id} onValueChange={(value) => handleInputChange('product_id', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryProducts.map((product) => (
                        <SelectItem key={product.value} value={product.value}>
                          {product.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Officer Selection */}
                <div className="space-y-2">
                  <Label htmlFor="officer">Officer *</Label>
                  <Select value={formData.officer_id} onValueChange={(value) => handleInputChange('officer_id', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select officer" />
                    </SelectTrigger>
                    <SelectContent>
                      {dropdownOptions.officers?.map((officer) => (
                        <SelectItem key={officer.value} value={officer.value}>
                          {officer.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Machine Selection (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="machine">Machine</Label>
                  <Select value={formData.machine_id || ''} onValueChange={(value) => handleInputChange('machine_id', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select machine (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {dropdownOptions.machines?.map((machine) => (
                        <SelectItem key={machine.value} value={machine.value}>
                          {machine.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Production Date */}
              <div className="space-y-2">
                <Label>Production Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.production_date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.production_date ? (
                        format(formData.production_date, "PPP")
                      ) : (
                        <span>Pick production date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.production_date || undefined}
                      onSelect={(date) => handleInputChange('production_date', date)}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
          </Card>

          {/* Additional Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Additional Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Additional Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.additional_notes || ''}
                  onChange={(e) => handleInputChange('additional_notes', e.target.value)}
                  placeholder="Enter any additional notes or observations..."
                  className="min-h-[80px]"
                />
              </div>

              {/* PDF Upload */}
              <div className="space-y-2">
                <Label htmlFor="pdf">Attach PDF Document</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="pdf"
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    className="flex-1"
                  />
                  <Button variant="outline" size="sm" className="px-3">
                    <Upload className="h-4 w-4" />
                  </Button>
                </div>
                {formData.pdf_file && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span>{formData.pdf_file.name}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              Save Memo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}