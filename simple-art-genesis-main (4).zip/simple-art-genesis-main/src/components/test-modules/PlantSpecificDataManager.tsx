import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { usePlantSpecificData } from '@/hooks/usePlantSpecificData';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';
import { Plus, Settings, Users, Wrench, Cloud, MapPin } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface PlantSpecificDataManagerProps {
  selectedPlant: string;
  isOpen: boolean;
  onClose: () => void;
}

export function PlantSpecificDataManager({ selectedPlant, isOpen, onClose }: PlantSpecificDataManagerProps) {
  const { data, configuration, loading, addMachine, addOfficer, updateConfiguration } = usePlantSpecificData(selectedPlant);
  const { data: dropdownOptions } = useAllDropdownOptions();
  
  const [newMachine, setNewMachine] = useState({ name: '', category: '' });
  const [newOfficer, setNewOfficer] = useState({ name: '', department: '', role: '' });

  const plantName = dropdownOptions?.plants?.find(p => p.id === selectedPlant)?.name || selectedPlant;

  const handleAddMachine = async () => {
    if (!newMachine.name.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter a machine name",
        variant: "destructive"
      });
      return;
    }

    try {
      await addMachine(newMachine.name, newMachine.category || undefined);
      setNewMachine({ name: '', category: '' });
      toast({
        title: "Machine Added",
        description: `Successfully added ${newMachine.name} to ${plantName}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add machine",
        variant: "destructive"
      });
    }
  };

  const handleAddOfficer = async () => {
    if (!newOfficer.name.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter an officer name",
        variant: "destructive"
      });
      return;
    }

    try {
      await addOfficer(newOfficer.name, newOfficer.department || undefined, newOfficer.role || undefined);
      setNewOfficer({ name: '', department: '', role: '' });
      toast({
        title: "Officer Added",
        description: `Successfully added ${newOfficer.name} to ${plantName}`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add officer",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Plant-Specific Configuration: {plantName}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="machines" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="machines" className="flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              Machines
            </TabsTrigger>
            <TabsTrigger value="officers" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Officers
            </TabsTrigger>
            <TabsTrigger value="sampling" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Sampling
            </TabsTrigger>
            <TabsTrigger value="climate" className="flex items-center gap-2">
              <Cloud className="h-4 w-4" />
              Climate
            </TabsTrigger>
          </TabsList>

          <TabsContent value="machines" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Plant Machines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add new machine */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted rounded-lg">
                  <div className="space-y-2">
                    <Label>Machine Name</Label>
                    <Input
                      value={newMachine.name}
                      onChange={(e) => setNewMachine(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter machine name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select
                      value={newMachine.category}
                      onValueChange={(value) => setNewMachine(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="crusher">Crusher</SelectItem>
                        <SelectItem value="screen">Screen</SelectItem>
                        <SelectItem value="mixer">Mixer</SelectItem>
                        <SelectItem value="conveyor">Conveyor</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button onClick={handleAddMachine} className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Machine
                    </Button>
                  </div>
                </div>

                {/* Existing machines */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.machines.map((machine) => (
                    <Card key={machine.id} className="p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{machine.name}</p>
                          {machine.category && (
                            <Badge variant="outline" className="text-xs mt-1">
                              {machine.category}
                            </Badge>
                          )}
                        </div>
                        <Wrench className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Card>
                  ))}
                </div>

                {data.machines.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Wrench className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No machines configured for this plant</p>
                    <p className="text-sm">Add machines using the form above</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="officers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Plant Officers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add new officer */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-muted rounded-lg">
                  <div className="space-y-2">
                    <Label>Officer Name</Label>
                    <Input
                      value={newOfficer.name}
                      onChange={(e) => setNewOfficer(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter officer name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Department</Label>
                    <Select
                      value={newOfficer.department}
                      onValueChange={(value) => setNewOfficer(prev => ({ ...prev, department: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="laboratory">Laboratory</SelectItem>
                        <SelectItem value="production">Production</SelectItem>
                        <SelectItem value="quality">Quality Control</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="management">Management</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Select
                      value={newOfficer.role}
                      onValueChange={(value) => setNewOfficer(prev => ({ ...prev, role: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technician">Technician</SelectItem>
                        <SelectItem value="supervisor">Supervisor</SelectItem>
                        <SelectItem value="manager">Manager</SelectItem>
                        <SelectItem value="operator">Operator</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button onClick={handleAddOfficer} className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Officer
                    </Button>
                  </div>
                </div>

                {/* Existing officers */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.officers.map((officer) => (
                    <Card key={officer.id} className="p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{officer.name}</p>
                          <div className="flex gap-1 mt-1">
                            {officer.department && (
                              <Badge variant="outline" className="text-xs">
                                {officer.department}
                              </Badge>
                            )}
                            {officer.role && (
                              <Badge variant="secondary" className="text-xs">
                                {officer.role}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Users className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Card>
                  ))}
                </div>

                {data.officers.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No officers configured for this plant</p>
                    <p className="text-sm">Add officers using the form above</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sampling" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sampling Methods</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.sampling_methods.map((method) => (
                    <Card key={method.id} className="p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{method.name}</p>
                          {method.description && (
                            <p className="text-xs text-muted-foreground mt-1">{method.description}</p>
                          )}
                        </div>
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Card>
                  ))}
                </div>

                {data.sampling_methods.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <MapPin className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No sampling methods configured for this plant</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="climate" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Climatic Conditions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.climatic_conditions.map((condition) => (
                    <Card key={condition.id} className="p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{condition.name}</p>
                          {condition.description && (
                            <p className="text-xs text-muted-foreground mt-1">{condition.description}</p>
                          )}
                        </div>
                        <Cloud className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Card>
                  ))}
                </div>

                {data.climatic_conditions.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Cloud className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No climatic conditions configured for this plant</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
