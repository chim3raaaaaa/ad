import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Blocks, 
  Mountain, 
  Square, 
  Hexagon, 
  Minus, 
  Grid3X3 
} from 'lucide-react';

export interface ProductCategory {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  description: string;
}

const PRODUCT_CATEGORIES: ProductCategory[] = [
  {
    id: 'aggregates',
    name: 'Aggregates',
    icon: Mountain,
    description: 'Sand, gravel, crushed stone'
  },
  {
    id: 'blocks',
    name: 'Blocks',
    icon: Blocks,
    description: 'Concrete blocks'
  },
  {
    id: 'cubes',
    name: 'Cubes',
    icon: Square,
    description: 'Test cubes'
  },
  {
    id: 'pavers',
    name: 'Pavers',
    icon: Grid3X3,
    description: 'Paving stones'
  },
  {
    id: 'kerbs',
    name: 'Kerbs',
    icon: Minus,
    description: 'Kerb stones'
  },
  {
    id: 'flagstones',
    name: 'Flagstones',
    icon: Hexagon,
    description: 'Flag stones'
  }
];

interface CategoryToggleSelectorProps {
  selectedCategory: string | null;
  onCategorySelect: (category: string) => void;
  className?: string;
}

export function CategoryToggleSelector({
  selectedCategory,
  onCategorySelect,
  className = ""
}: CategoryToggleSelectorProps) {
  return (
    <Card className={className}>
      <CardContent className="p-4">
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground">
            🧪 Select Product Category:
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
            {PRODUCT_CATEGORIES.map((category) => {
              const Icon = category.icon;
              const isSelected = selectedCategory === category.id;
              
              return (
                <Button
                  key={category.id}
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  onClick={() => onCategorySelect(category.id)}
                  className={`
                    h-auto p-3 flex flex-col items-center gap-2 text-xs
                    ${isSelected ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}
                    transition-all duration-200
                  `}
                >
                  <Icon className="h-4 w-4" />
                  <span className="font-medium">{category.name}</span>
                </Button>
              );
            })}
          </div>
          
          {selectedCategory && (
            <div className="mt-3 p-2 bg-muted/50 rounded-md">
              <p className="text-xs text-muted-foreground">
                Selected: <span className="font-medium text-foreground">
                  {PRODUCT_CATEGORIES.find(c => c.id === selectedCategory)?.name}
                </span>
                {' - '}
                {PRODUCT_CATEGORIES.find(c => c.id === selectedCategory)?.description}
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export { PRODUCT_CATEGORIES };