import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar, CalendarIcon, AlertTriangle, Info, CheckCircle, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ProductField, TestModulesAPI } from '@/services/api/testModulesAPI';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface DynamicFormBuilderProps {
  productTypeId: string;
  onSubmit: (formData: Record<string, any>) => void;
  onCancel: () => void;
  initialData?: Record<string, any>;
  mode?: 'create' | 'edit' | 'view';
  memoId?: string;
  plantId?: string;
  officerId?: string;
}

interface FormErrors {
  [fieldName: string]: string;
}

export function DynamicFormBuilder({
  productTypeId,
  onSubmit,
  onCancel,
  initialData = {},
  mode = 'create',
  memoId,
  plantId,
  officerId
}: DynamicFormBuilderProps) {
  const { toast } = useToast();

  // State management
  const [fields, setFields] = useState<ProductField[]>([]);
  const [formData, setFormData] = useState<Record<string, any>>(initialData);
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, File>>({});

  // Load field definitions
  useEffect(() => {
    loadFields();
  }, [productTypeId]);

  // Initialize form data when fields are loaded
  useEffect(() => {
    if (fields.length > 0) {
      const defaultData = { ...initialData };
      
      // Set default values for fields that don't have data
      fields.forEach(field => {
        if (!(field.field_name in defaultData)) {
          switch (field.field_type) {
            case 'boolean':
              defaultData[field.field_name] = false;
              break;
            case 'number':
              defaultData[field.field_name] = '';
              break;
            case 'select':
              defaultData[field.field_name] = '';
              break;
            default:
              defaultData[field.field_name] = '';
          }
        }
      });
      
      setFormData(defaultData);
    }
  }, [fields, initialData]);

  const loadFields = async () => {
    try {
      setLoading(true);
      const fieldDefinitions = await TestModulesAPI.getProductFields(productTypeId);
      setFields(fieldDefinitions);
      
      if (fieldDefinitions.length === 0) {
        toast({
          title: "No Fields Configured",
          description: "This product type has no field definitions. Please configure fields in Reference Data Manager.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Failed to load field definitions:', error);
      toast({
        title: "Error",
        description: "Failed to load form fields. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const validateField = (field: ProductField, value: any): string | null => {
    const validation = TestModulesAPI.validateField(value, field);
    return validation.isValid ? null : validation.message || 'Invalid value';
  };

  const validateForm = (): boolean => {
    setIsValidating(true);
    const newErrors: FormErrors = {};
    
    fields.forEach(field => {
      const value = formData[field.field_name];
      const error = validateField(field, value);
      if (error) {
        newErrors[field.field_name] = error;
      }
    });
    
    setErrors(newErrors);
    setIsValidating(false);
    
    return Object.keys(newErrors).length === 0;
  };

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
    
    // Clear error for this field
    if (errors[fieldName]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[fieldName];
        return newErrors;
      });
    }
  };

  const handleFileUpload = (fieldName: string, file: File) => {
    setUploadedFiles(prev => ({ ...prev, [fieldName]: file }));
    handleFieldChange(fieldName, file.name);
  };

  const handleSubmit = () => {
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form before submitting.",
        variant: "destructive"
      });
      return;
    }

    // Include uploaded files in submission
    const submissionData = {
      ...formData,
      _uploadedFiles: uploadedFiles,
      _metadata: {
        productTypeId,
        memoId,
        plantId,
        officerId,
        mode
      }
    };

    onSubmit(submissionData);
  };

  const renderField = (field: ProductField) => {
    const value = formData[field.field_name];
    const error = errors[field.field_name];
    const isReadOnly = mode === 'view';

    const commonProps = {
      id: field.field_name,
      disabled: isReadOnly || loading,
      className: error ? 'border-destructive' : ''
    };

    switch (field.field_type) {
      case 'text':
        return (
          <Input
            {...commonProps}
            type="text"
            value={value || ''}
            onChange={(e) => handleFieldChange(field.field_name, e.target.value)}
            placeholder={`Enter ${field.field_label.toLowerCase()}`}
          />
        );

      case 'number':
        return (
          <div className="relative">
            <Input
              {...commonProps}
              type="number"
              value={value || ''}
              onChange={(e) => handleFieldChange(field.field_name, e.target.value)}
              placeholder={`Enter ${field.field_label.toLowerCase()}`}
              step="any"
            />
            {field.field_unit && (
              <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-muted-foreground">
                {field.field_unit}
              </span>
            )}
          </div>
        );

      case 'date':
        return (
          <Input
            {...commonProps}
            type="date"
            value={value || ''}
            onChange={(e) => handleFieldChange(field.field_name, e.target.value)}
          />
        );

      case 'select':
        return (
          <Select
            value={value || ''}
            onValueChange={(newValue) => handleFieldChange(field.field_name, newValue)}
            disabled={isReadOnly || loading}
          >
            <SelectTrigger className={error ? 'border-destructive' : ''}>
              <SelectValue placeholder={`Select ${field.field_label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.field_options?.map(option => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'textarea':
        return (
          <Textarea
            {...commonProps}
            value={value || ''}
            onChange={(e) => handleFieldChange(field.field_name, e.target.value)}
            placeholder={`Enter ${field.field_label.toLowerCase()}`}
            rows={3}
          />
        );

      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <Switch
              id={field.field_name}
              checked={Boolean(value)}
              onCheckedChange={(checked) => handleFieldChange(field.field_name, checked)}
              disabled={isReadOnly || loading}
            />
            <Label htmlFor={field.field_name} className="text-sm">
              {value ? 'Yes' : 'No'}
            </Label>
          </div>
        );

      case 'file':
        return (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Input
                {...commonProps}
                type="file"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    handleFileUpload(field.field_name, file);
                  }
                }}
                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              />
              {value && (
                <Badge variant="outline" className="text-xs">
                  {value}
                </Badge>
              )}
            </div>
          </div>
        );

      default:
        return (
          <Input
            {...commonProps}
            type="text"
            value={value || ''}
            onChange={(e) => handleFieldChange(field.field_name, e.target.value)}
            placeholder={`Enter ${field.field_label.toLowerCase()}`}
          />
        );
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm text-muted-foreground">Loading form fields...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (fields.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              No form fields are configured for this product type. 
              <PermissionWrapper permissions={['test_config.manage']}>
                Please configure fields in the Reference Data Manager.
              </PermissionWrapper>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {mode === 'create' && <CheckCircle className="h-5 w-5 text-green-600" />}
          {mode === 'edit' && <Info className="h-5 w-5 text-blue-600" />}
          {mode === 'view' && <Info className="h-5 w-5 text-gray-600" />}
          {mode === 'create' ? 'New Test Entry' : mode === 'edit' ? 'Edit Test Entry' : 'View Test Entry'}
        </CardTitle>
        {memoId && (
          <Badge variant="outline" className="w-fit">
            Memo: {memoId}
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {fields.map((field, index) => (
              <div key={field.id} className="space-y-2">
                <Label 
                  htmlFor={field.field_name}
                  className={`flex items-center gap-2 ${field.is_required ? 'after:content-["*"] after:text-destructive' : ''}`}
                >
                  {field.field_label}
                  {field.field_unit && (
                    <span className="text-xs text-muted-foreground">({field.field_unit})</span>
                  )}
                </Label>
                
                {renderField(field)}
                
                {errors[field.field_name] && (
                  <p className="text-sm text-destructive flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    {errors[field.field_name]}
                  </p>
                )}
                
                {index < fields.length - 1 && <Separator className="my-4" />}
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Validation Summary */}
        {isValidating && Object.keys(errors).length > 0 && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Please fix {Object.keys(errors).length} validation error(s) before submitting.
            </AlertDescription>
          </Alert>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={onCancel}>
            {mode === 'view' ? 'Close' : 'Cancel'}
          </Button>
          
          {mode !== 'view' && (
            <PermissionWrapper permissions={['test_data.create', 'test_data.edit']}>
              <Button 
                onClick={handleSubmit}
                disabled={loading || isValidating}
              >
                {loading ? 'Saving...' : mode === 'create' ? 'Create Entry' : 'Save Changes'}
              </Button>
            </PermissionWrapper>
          )}
        </div>
      </CardContent>
    </Card>
  );
}