import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Download, Upload, FileSpreadsheet } from 'lucide-react';

interface DataImportExportProps {
  category: string;
  tableName?: string;
}

export function DataImportExport({ category, tableName }: DataImportExportProps) {
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportFormat, setExportFormat] = useState<'csv' | 'excel' | 'json'>('csv');

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please upload CSV files only",
        variant: "destructive"
      });
      return;
    }

    setImporting(true);

    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        throw new Error('CSV file must contain headers and at least one data row');
      }

      const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
      const data = lines.slice(1).map(line => {
        const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        return {
          ...row,
          id: `imported_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
      });

      // Validate required fields based on category
      const requiredFields = getRequiredFields(category);
      const invalidRows = data.filter(row => 
        requiredFields.some(field => !row[field] || row[field] === '')
      );

      if (invalidRows.length > 0) {
        throw new Error(`${invalidRows.length} rows are missing required fields: ${requiredFields.join(', ')}`);
      }

      // Import data to localStorage
      if (tableName) {
        const existing = JSON.parse(localStorage.getItem(tableName) || '[]');
        const combined = [...existing, ...data];
        localStorage.setItem(tableName, JSON.stringify(combined));
      }

      toast({
        title: "Import Successful",
        description: `Imported ${data.length} test entries from ${file.name}`
      });

    } catch (error) {
      toast({
        title: "Import Failed",
        description: error instanceof Error ? error.message : "Failed to import data",
        variant: "destructive"
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const handleExport = async () => {
    if (!tableName) {
      toast({
        title: "No Table Selected",
        description: "Please select a database table to export",
        variant: "destructive"
      });
      return;
    }

    setExporting(true);

    try {
      const data = JSON.parse(localStorage.getItem(tableName) || '[]');
      
      if (data.length === 0) {
        toast({
          title: "No Data to Export",
          description: "The selected table contains no data",
          variant: "destructive"
        });
        return;
      }

      let exportData: string;
      let filename: string;
      let mimeType: string;

      switch (exportFormat) {
        case 'csv':
          exportData = convertToCSV(data);
          filename = `${tableName}_export_${new Date().toISOString().split('T')[0]}.csv`;
          mimeType = 'text/csv';
          break;
        case 'json':
          exportData = JSON.stringify(data, null, 2);
          filename = `${tableName}_export_${new Date().toISOString().split('T')[0]}.json`;
          mimeType = 'application/json';
          break;
        case 'excel':
          // For simplicity, export as CSV with .xlsx extension
          exportData = convertToCSV(data);
          filename = `${tableName}_export_${new Date().toISOString().split('T')[0]}.xlsx`;
          mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          break;
        default:
          throw new Error('Unsupported export format');
      }

      // Create and download file
      const blob = new Blob([exportData], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `Exported ${data.length} records to ${filename}`
      });

    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export data",
        variant: "destructive"
      });
    } finally {
      setExporting(false);
    }
  };

  const convertToCSV = (data: any[]): string => {
    if (data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvHeaders = headers.join(',');
    const csvRows = data.map(row => 
      headers.map(header => {
        const value = row[header];
        // Escape commas and quotes in values
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',')
    );
    
    return [csvHeaders, ...csvRows].join('\n');
  };

  const getRequiredFields = (category: string): string[] => {
    const commonFields = ['memo_reference', 'plant_id', 'product_type', 'test_date'];
    
    switch (category) {
      case 'aggregates':
        return [...commonFields, 'moisture_content', 'specific_gravity'];
      case 'blocks':
        return [...commonFields, 'compressive_strength', 'water_absorption'];
      case 'cubes':
        return [...commonFields, 'compressive_strength', 'test_age'];
      case 'pavers':
        return [...commonFields, 'compressive_strength', 'thickness'];
      case 'kerbs':
        return [...commonFields, 'compressive_strength', 'profile_type'];
      default:
        return commonFields;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileSpreadsheet className="h-5 w-5 mr-2" />
          Data Import/Export
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Import Section */}
        <div className="space-y-2">
          <h4 className="font-medium">Import Data</h4>
          <div className="flex items-center space-x-2">
            <Input
              type="file"
              accept=".csv"
              onChange={handleImport}
              disabled={importing || !tableName}
              className="flex-1"
            />
            <Button disabled={importing || !tableName} variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              {importing ? 'Importing...' : 'Import CSV'}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Upload CSV files with test data. Required fields: {getRequiredFields(category).join(', ')}
          </p>
        </div>

        {/* Export Section */}
        <div className="space-y-2">
          <h4 className="font-medium">Export Data</h4>
          <div className="flex items-center space-x-2">
            <Select value={exportFormat} onValueChange={(value: 'csv' | 'excel' | 'json') => setExportFormat(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="excel">Excel</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={handleExport}
              disabled={exporting || !tableName}
              className="flex-1"
            >
              <Download className="h-4 w-4 mr-2" />
              {exporting ? 'Exporting...' : `Export as ${exportFormat.toUpperCase()}`}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Export test data in your preferred format for analysis or backup
          </p>
        </div>
      </CardContent>
    </Card>
  );
}