import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { directInputService } from '@/services/database/DirectInputService';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface FlagstonesTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  memoId?: string;
  plantId?: string;
}

export function FlagstonesTestModal({ isOpen, onClose, onSuccess, memoId, plantId }: FlagstonesTestModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    // General Information
    memo_reference: memoId || '',
    plant_id: plantId || '',
    batch_id: '',
    test_date: new Date().toISOString().split('T')[0],
    operator: '',
    
    // Flagstone Specifications
    flagstone_type: '',
    size_category: '',
    length: '',
    width: '',
    thickness: '',
    surface_texture: '',
    edge_profile: '',
    
    // Physical Properties
    compressive_strength: '',
    flexural_strength: '',
    water_absorption: '',
    freeze_thaw_resistance: '',
    slip_resistance: '',
    abrasion_resistance: '',
    
    // Aesthetic Properties
    color_consistency: '',
    surface_quality: '',
    texture_uniformity: '',
    pattern_alignment: '',
    
    // Dimensional Checks
    thickness_tolerance: '',
    size_tolerance: '',
    flatness: '',
    edge_quality: '',
    
    // Test Conditions
    curing_period: '',
    test_temperature: '',
    test_humidity: '',
    
    // Results
    pass_fail_status: 'pending',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): boolean => {
    const required = ['test_date', 'operator', 'flagstone_type'];
    const missing = required.filter(field => !formData[field as keyof typeof formData]);
    
    if (missing.length > 0) {
      toast({
        title: "Validation Error",
        description: `Missing required fields: ${missing.join(', ')}`,
        variant: "destructive"
      });
      return false;
    }

    // Validate compressive strength (typical minimum: 35 MPa for flagstones)
    if (formData.compressive_strength && parseFloat(formData.compressive_strength) < 35) {
      toast({
        title: "Validation Warning",
        description: "Compressive strength below typical minimum of 35 MPa for flagstones",
        variant: "destructive"
      });
    }

    // Validate water absorption (typical limit: ≤ 6%)
    if (formData.water_absorption && parseFloat(formData.water_absorption) > 6) {
      toast({
        title: "Validation Warning",
        description: "Water absorption exceeds typical limit of 6%",
        variant: "destructive"
      });
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await directInputService.createDirectInputResult({
        product_type: 'flagstones',
        plant_id: formData.plant_id,
        memo_id: formData.memo_reference,
        test_data: formData,
        operator: formData.operator,
        test_date: formData.test_date,
        status: formData.pass_fail_status as 'pass' | 'fail' | 'pending'
      });

      toast({
        title: "Success",
        description: "Flagstones test entry saved successfully"
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving flagstones test:', error);
      toast({
        title: "Error",
        description: "Failed to save flagstones test entry",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Flagstones Test Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* General Information */}
          <Card>
            <CardHeader>
              <CardTitle>General Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="memo_reference">Memo Reference</Label>
                  <Input
                    id="memo_reference"
                    value={formData.memo_reference}
                    onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="batch_id">Batch ID</Label>
                  <Input
                    id="batch_id"
                    value={formData.batch_id}
                    onChange={(e) => handleInputChange('batch_id', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="test_date">Test Date *</Label>
                  <Input
                    id="test_date"
                    type="date"
                    value={formData.test_date}
                    onChange={(e) => handleInputChange('test_date', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="operator">Operator *</Label>
                  <Input
                    id="operator"
                    value={formData.operator}
                    onChange={(e) => handleInputChange('operator', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Flagstone Specifications */}
          <Card>
            <CardHeader>
              <CardTitle>Flagstone Specifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="flagstone_type">Flagstone Type *</Label>
                  <Select value={formData.flagstone_type} onValueChange={(value) => handleInputChange('flagstone_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select flagstone type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="natural_stone">Natural Stone</SelectItem>
                      <SelectItem value="reconstituted_stone">Reconstituted Stone</SelectItem>
                      <SelectItem value="concrete_replica">Concrete Replica</SelectItem>
                      <SelectItem value="pressed_concrete">Pressed Concrete</SelectItem>
                      <SelectItem value="textured_slab">Textured Slab</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="size_category">Size Category</Label>
                  <Select value={formData.size_category} onValueChange={(value) => handleInputChange('size_category', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small (300x300mm)</SelectItem>
                      <SelectItem value="medium">Medium (450x450mm)</SelectItem>
                      <SelectItem value="large">Large (600x600mm)</SelectItem>
                      <SelectItem value="extra_large">Extra Large (900x600mm)</SelectItem>
                      <SelectItem value="custom">Custom Size</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="length">Length (mm)</Label>
                  <Input
                    id="length"
                    type="number"
                    value={formData.length}
                    onChange={(e) => handleInputChange('length', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="width">Width (mm)</Label>
                  <Input
                    id="width"
                    type="number"
                    value={formData.width}
                    onChange={(e) => handleInputChange('width', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="thickness">Thickness (mm)</Label>
                  <Input
                    id="thickness"
                    type="number"
                    value={formData.thickness}
                    onChange={(e) => handleInputChange('thickness', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Physical Properties */}
          <Card>
            <CardHeader>
              <CardTitle>Physical Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="compressive_strength">Compressive Strength (MPa)</Label>
                  <Input
                    id="compressive_strength"
                    type="number"
                    step="0.1"
                    value={formData.compressive_strength}
                    onChange={(e) => handleInputChange('compressive_strength', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="flexural_strength">Flexural Strength (MPa)</Label>
                  <Input
                    id="flexural_strength"
                    type="number"
                    step="0.1"
                    value={formData.flexural_strength}
                    onChange={(e) => handleInputChange('flexural_strength', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                  <Input
                    id="water_absorption"
                    type="number"
                    step="0.1"
                    value={formData.water_absorption}
                    onChange={(e) => handleInputChange('water_absorption', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="slip_resistance">Slip Resistance</Label>
                  <Select value={formData.slip_resistance} onValueChange={(value) => handleInputChange('slip_resistance', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent (R13)</SelectItem>
                      <SelectItem value="very_good">Very Good (R12)</SelectItem>
                      <SelectItem value="good">Good (R11)</SelectItem>
                      <SelectItem value="acceptable">Acceptable (R10)</SelectItem>
                      <SelectItem value="poor">Poor (R9)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality Control */}
          <Card>
            <CardHeader>
              <CardTitle>Quality Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pass_fail_status">Status</Label>
                  <Select value={formData.pass_fail_status} onValueChange={(value) => handleInputChange('pass_fail_status', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="pass">Pass</SelectItem>
                      <SelectItem value="fail">Fail</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="flatness">Flatness</Label>
                  <Select value={formData.flatness} onValueChange={(value) => handleInputChange('flatness', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="acceptable">Acceptable</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <PermissionWrapper permission="tests.create">
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Test Entry'}
            </Button>
          </PermissionWrapper>
        </div>
      </DialogContent>
    </Dialog>
  );
}