import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertTriangle, CheckCircle, Save, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';
import { conformityEngine, ConformityReport } from '@/services/validation/conformityEngine';

interface TestEntryFormProps {
  category: string;
  productType: string;
  plantId: string;
  tableName: string;
  testEntry?: any;
  onSave: (testData: any) => void;
  onCancel: () => void;
}

export function TestEntryForm({
  category,
  productType,
  plantId,
  tableName,
  testEntry,
  onSave,
  onCancel
}: TestEntryFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>({
    memo_reference: '',
    plant_id: plantId,
    product_type: productType,
    test_date: new Date().toISOString().split('T')[0],
    officer_id: '',
    machine_id: '',
    pass_fail_status: 'pending'
  });
  
  const [conformityReport, setConformityReport] = useState<ConformityReport | null>(null);
  const [showValidation, setShowValidation] = useState(false);
  const { data: dropdownOptions, loading } = useAllDropdownOptions();

  useEffect(() => {
    if (testEntry) {
      setFormData(testEntry);
    }
  }, [testEntry]);

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateAndSave = async () => {
    try {
      // Run conformity validation
      const report = await conformityEngine.validateTestData(
        formData,
        category,
        productType
      );
      
      setConformityReport(report);
      
      // Determine pass/fail status based on validation
      const passFailStatus = report.overall_status === 'pass' ? 'pass' : 
                           report.overall_status === 'fail' ? 'fail' : 'pending';
      
      const finalData = {
        ...formData,
        pass_fail_status: passFailStatus
      };

      onSave(finalData);
      
      if (report.overall_status === 'fail') {
        toast({
          title: "Test Entry Saved with Non-Conformities",
          description: `${report.validation_results.filter(r => r.status === 'fail').length} validation errors found`,
          variant: "destructive"
        });
      } else {
        toast({
          title: "Test Entry Saved",
          description: "Test data validated and saved successfully"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to validate and save test entry",
        variant: "destructive"
      });
    }
  };

  const runValidation = async () => {
    try {
      const report = await conformityEngine.validateTestData(
        formData,
        category,
        productType
      );
      setConformityReport(report);
      setShowValidation(true);
    } catch (error) {
      toast({
        title: "Validation Error",
        description: "Failed to run validation checks",
        variant: "destructive"
      });
    }
  };

  const renderCategorySpecificFields = () => {
    switch (category) {
      case 'aggregates':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="moisture_content">Moisture Content (%)</Label>
                <Input
                  id="moisture_content"
                  type="number"
                  step="0.1"
                  value={formData.moisture_content || ''}
                  onChange={(e) => updateField('moisture_content', parseFloat(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="specific_gravity">Specific Gravity</Label>
                <Input
                  id="specific_gravity"
                  type="number"
                  step="0.01"
                  value={formData.specific_gravity || ''}
                  onChange={(e) => updateField('specific_gravity', parseFloat(e.target.value))}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="bulk_density">Bulk Density (kg/m³)</Label>
                <Input
                  id="bulk_density"
                  type="number"
                  value={formData.bulk_density || ''}
                  onChange={(e) => updateField('bulk_density', parseFloat(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="fineness_modulus">Fineness Modulus</Label>
                <Input
                  id="fineness_modulus"
                  type="number"
                  step="0.01"
                  value={formData.fineness_modulus || ''}
                  onChange={(e) => updateField('fineness_modulus', parseFloat(e.target.value))}
                />
              </div>
            </div>
          </>
        );

      case 'blocks':
        return (
          <>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="length">Length (mm)</Label>
                <Input
                  id="length"
                  type="number"
                  value={formData.dimensions?.length || ''}
                  onChange={(e) => updateField('dimensions', {
                    ...formData.dimensions,
                    length: parseFloat(e.target.value)
                  })}
                />
              </div>
              <div>
                <Label htmlFor="width">Width (mm)</Label>
                <Input
                  id="width"
                  type="number"
                  value={formData.dimensions?.width || ''}
                  onChange={(e) => updateField('dimensions', {
                    ...formData.dimensions,
                    width: parseFloat(e.target.value)
                  })}
                />
              </div>
              <div>
                <Label htmlFor="height">Height (mm)</Label>
                <Input
                  id="height"
                  type="number"
                  value={formData.dimensions?.height || ''}
                  onChange={(e) => updateField('dimensions', {
                    ...formData.dimensions,
                    height: parseFloat(e.target.value)
                  })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="compressive_strength">Compressive Strength (MPa)</Label>
                <Input
                  id="compressive_strength"
                  type="number"
                  step="0.1"
                  value={formData.compressive_strength || ''}
                  onChange={(e) => updateField('compressive_strength', parseFloat(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                <Input
                  id="water_absorption"
                  type="number"
                  step="0.1"
                  value={formData.water_absorption || ''}
                  onChange={(e) => updateField('water_absorption', parseFloat(e.target.value))}
                />
              </div>
            </div>
          </>
        );

      case 'cubes':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="compressive_strength">Compressive Strength (MPa)</Label>
                <Input
                  id="compressive_strength"
                  type="number"
                  step="0.1"
                  value={formData.compressive_strength || ''}
                  onChange={(e) => updateField('compressive_strength', parseFloat(e.target.value))}
                />
              </div>
              <div>
                <Label htmlFor="test_age">Test Age (days)</Label>
                <Select value={formData.test_age || ''} onValueChange={(value) => updateField('test_age', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select test age" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="28">28 days</SelectItem>
                    <SelectItem value="56">56 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cube_size">Cube Size (mm)</Label>
                <Select value={formData.cube_size || ''} onValueChange={(value) => updateField('cube_size', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select cube size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100">100mm</SelectItem>
                    <SelectItem value="150">150mm</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="density">Density (kg/m³)</Label>
                <Input
                  id="density"
                  type="number"
                  value={formData.density || ''}
                  onChange={(e) => updateField('density', parseFloat(e.target.value))}
                />
              </div>
            </div>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            {testEntry ? 'Edit Test Entry' : 'New Test Entry'}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={runValidation}>
                <AlertTriangle className="h-4 w-4 mr-2" />
                Validate
              </Button>
              {conformityReport && (
                <Badge variant={
                  conformityReport.overall_status === 'pass' ? 'default' :
                  conformityReport.overall_status === 'fail' ? 'destructive' : 'secondary'
                }>
                  {conformityReport.overall_status === 'pass' && <CheckCircle className="h-3 w-3 mr-1" />}
                  {conformityReport.overall_status === 'fail' && <AlertTriangle className="h-3 w-3 mr-1" />}
                  {conformityReport.overall_status}
                </Badge>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Basic Test Information */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="memo_reference">Memo Reference</Label>
              <Input
                id="memo_reference"
                value={formData.memo_reference}
                onChange={(e) => updateField('memo_reference', e.target.value)}
                placeholder="e.g., RTB240125001"
              />
            </div>
            <div>
              <Label htmlFor="test_date">Test Date</Label>
              <Input
                id="test_date"
                type="date"
                value={formData.test_date}
                onChange={(e) => updateField('test_date', e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="officer_id">Testing Officer</Label>
              <Select value={formData.officer_id} onValueChange={(value) => updateField('officer_id', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select officer" />
                </SelectTrigger>
                <SelectContent>
                  {dropdownOptions?.officers?.map((officer) => (
                    <SelectItem key={officer.id} value={officer.id}>
                      {officer.name}
                    </SelectItem>
                  )) || []}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="machine_id">Testing Machine</Label>
              <Select value={formData.machine_id} onValueChange={(value) => updateField('machine_id', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select machine" />
                </SelectTrigger>
                <SelectContent>
                  {dropdownOptions?.machines?.map((machine) => (
                    <SelectItem key={machine.id} value={machine.id}>
                      {machine.name}
                    </SelectItem>
                  )) || []}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Category-specific fields */}
          {renderCategorySpecificFields()}

          {/* Notes */}
          <div>
            <Label htmlFor="compliance_notes">Notes</Label>
            <Textarea
              id="compliance_notes"
              value={formData.compliance_notes || ''}
              onChange={(e) => updateField('compliance_notes', e.target.value)}
              placeholder="Add any additional notes or observations..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Validation Results */}
      {conformityReport && (
        <Dialog open={showValidation} onOpenChange={setShowValidation}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Validation Results</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span>Overall Status:</span>
                <Badge variant={
                  conformityReport.overall_status === 'pass' ? 'default' :
                  conformityReport.overall_status === 'fail' ? 'destructive' : 'secondary'
                }>
                  {conformityReport.overall_status}
                </Badge>
              </div>
              <div>
                <span>Conformity: {conformityReport.conformity_percentage}%</span>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium">Validation Details:</h4>
                {conformityReport.validation_results.map((result, index) => (
                  <div key={index} className="flex items-center justify-between p-2 border rounded">
                    <span>{result.parameter}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">{result.value}</span>
                      <Badge variant={
                        result.status === 'pass' ? 'default' :
                        result.status === 'fail' ? 'destructive' : 'secondary'
                      }>
                        {result.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          <X className="h-4 w-4 mr-2" />
          Cancel
        </Button>
        <Button onClick={validateAndSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Test Entry
        </Button>
      </div>
    </div>
  );
}