import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { plantTestService } from '@/services/database/plantTestService';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';
import { useProductCategories, useProductTypes, useValidation } from '@/hooks/useTestModulesData';
import { usePlantSpecificData } from '@/hooks/usePlantSpecificData';
import { TestEntryModal } from './TestEntryModal';
import { PlantSpecificDataManager } from './PlantSpecificDataManager';
import { EnhancedAggregatesModal } from '@/components/lab/EnhancedAggregatesModal';
import { 
  Database, 
  TestTube, 
  Plus, 
  Search, 
  Factory, 
  Calendar,
  FileSpreadsheet,
  Mountain,
  Blocks,
  Square,
  Grid3X3,
  Minus,
  Building,
  Settings
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

// Icon mapping for product categories
const CATEGORY_ICONS = {
  aggregates: Mountain,
  blocks: Blocks,
  cubes: Square,
  pavers: Grid3X3,
  kerbs: Minus,
  concrete: Building
};

interface TestDatabase {
  id: string;
  category: string;
  product: string;
  plant: string;
  entries_count: number;
  last_updated: string;
  table_name: string;
}

export function TestModulesHub() {
  // State management
  const [selectedCategory, setSelectedCategory] = useState<string>('aggregates');
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [selectedPlant, setSelectedPlant] = useState<string>('');
  const [testDatabases, setTestDatabases] = useState<TestDatabase[]>([]);
  const [loading, setLoading] = useState(false);
  const [showTestEntryModal, setShowTestEntryModal] = useState(false);
  const [showAggregatesModal, setShowAggregatesModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [showPlantConfig, setShowPlantConfig] = useState(false);

  // Reference data hooks
  const { data: dropdownOptions } = useAllDropdownOptions();
  const { categories } = useProductCategories();
  const { productTypes } = useProductTypes(selectedCategory);
  const { validateProductType, validatePlant } = useValidation();
  
  // Plant-specific data
  const { data: plantData } = usePlantSpecificData(selectedPlant);

  // Load test databases
  const loadTestDatabases = async () => {
    setLoading(true);
    try {
      const databases = await plantTestService.getAllPlantDatabases();
      
      // Transform data to match our interface
      const transformedData: TestDatabase[] = databases.map(db => ({
        id: db.table_name,
        category: db.category,
        product: db.product_type,
        plant: db.plant_name,
        entries_count: db.entry_count,
        last_updated: db.last_updated,
        table_name: db.table_name
      }));
      
      setTestDatabases(transformedData);
    } catch (error) {
      console.error('Error loading test databases:', error);
      toast({
        title: "Loading Failed",
        description: "Failed to load test databases",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Filter databases based on current selection
  const filteredDatabases = testDatabases.filter(db => 
    db.category === selectedCategory &&
    (!selectedProduct || db.product === selectedProduct) &&
    (!selectedPlant || db.plant === selectedPlant)
  );

  useEffect(() => {
    loadTestDatabases();
  }, []);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedProduct('');
    setSelectedPlant('');
  };

  // Handle creating new database with validation
  const handleCreateNewDatabase = async () => {
    if (!selectedProduct || !selectedPlant) {
      toast({
        title: "Missing Information",
        description: "Please select both product and plant before creating a database",
        variant: "destructive"
      });
      return;
    }

    // Validate against reference data
    const [isValidProduct, isValidPlant] = await Promise.all([
      validateProductType(selectedCategory, selectedProduct),
      validatePlant(selectedPlant)
    ]);

    if (!isValidProduct) {
      toast({
        title: "Invalid Product Type",
        description: `Product type "${selectedProduct}" not found in reference data for category "${selectedCategory}"`,
        variant: "destructive"
      });
      return;
    }

    if (!isValidPlant) {
      toast({
        title: "Invalid Plant",
        description: `Plant not found in reference data. Please add it in Reference Data Manager first.`,
        variant: "destructive"
      });
      return;
    }

    try {
      const plantName = dropdownOptions?.plants?.find(p => p.id === selectedPlant)?.name || selectedPlant;
      const tableName = await plantTestService.createPlantDatabase(
        selectedCategory,
        selectedPlant,
        plantName,
        selectedProduct
      );
      
      toast({
        title: "Database Created",
        description: `Successfully created database: ${tableName}`
      });
      
      // Reload databases
      await loadTestDatabases();
    } catch (error: any) {
      console.error('Error creating database:', error);
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create new database",
        variant: "destructive"
      });
    }
  };

  // Handle adding test entry
  const handleAddTestEntry = () => {
    if (!selectedProduct || !selectedPlant) {
      toast({
        title: "Missing Information",
        description: "Please select both product and plant before adding a test entry",
        variant: "destructive"
      });
      return;
    }

    // Find existing database or use current selection
    const existingDb = filteredDatabases.find(db => 
      db.category === selectedCategory && 
      db.product === selectedProduct && 
      db.plant === dropdownOptions?.plants?.find(p => p.id === selectedPlant)?.name
    );

    if (existingDb) {
      setSelectedTable(existingDb.table_name);
      if (selectedCategory === 'aggregates') {
        setShowAggregatesModal(true);
      } else {
        setShowTestEntryModal(true);
      }
    } else {
      toast({
        title: "No Database Found",
        description: "Please create a database first before adding test entries",
        variant: "destructive"
      });
    }
  };

  const handleViewTestData = (database: TestDatabase) => {
    const params = new URLSearchParams({
      category: database.category,
      product: database.product,
      plant: database.plant
    });
    window.location.href = `/test-data-explorer?${params.toString()}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Test Modules</h1>
        <p className="text-muted-foreground">
          Manage test databases and test entries by product category
        </p>
      </div>

      {/* Product Category Toggle */}
      <Card>
        <CardContent className="p-4">
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-muted-foreground">
              🧪 Product Category:
            </h3>
            
            <div className="flex flex-wrap gap-2">
              {categories.length > 0 ? (
                categories.map((category) => {
                  const Icon = CATEGORY_ICONS[category.id as keyof typeof CATEGORY_ICONS];
                  return (
                    <Button
                      key={category.id}
                      variant={selectedCategory === category.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleCategorySelect(category.id)}
                      className="flex items-center space-x-2"
                    >
                      {Icon && <Icon className="h-4 w-4" />}
                      <span>{category.name}</span>
                    </Button>
                  );
                })
              ) : (
                <div className="text-sm text-muted-foreground">
                  Loading categories from Reference Data Manager...
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filter Row */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Product Type</label>
                <Select 
                  value={selectedProduct} 
                  onValueChange={setSelectedProduct}
                  disabled={productTypes.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={
                      productTypes.length === 0 
                        ? "No products found in reference data" 
                        : "Select product type"
                    } />
                  </SelectTrigger>
                <SelectContent>
                  {productTypes.map((productType) => (
                    <SelectItem key={productType} value={productType}>
                      {productType}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Plant</label>
                <Select 
                  value={selectedPlant} 
                  onValueChange={setSelectedPlant}
                  disabled={!dropdownOptions?.plants?.length}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={
                      !dropdownOptions?.plants?.length 
                        ? "No plants found - add plants in Reference Data Manager" 
                        : "Select plant"
                    } />
                  </SelectTrigger>
                <SelectContent>
                  {dropdownOptions?.plants?.filter(plant => plant?.id).map((plant) => (
                    <SelectItem key={`hub-plant-${plant.id}`} value={plant.id}>
                      {plant.name}
                    </SelectItem>
                  )) || []}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <Button 
                  onClick={handleCreateNewDatabase}
                  disabled={!selectedProduct || !selectedPlant || loading || productTypes.length === 0}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Database
                </Button>
              </div>
              
              {selectedPlant && (
                <div className="space-y-2">
                  <Button 
                    variant="outline"
                    onClick={() => setShowPlantConfig(true)}
                    className="w-full"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Plant Configuration
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button 
          variant="outline"
          onClick={handleAddTestEntry}
          disabled={!selectedProduct || !selectedPlant || productTypes.length === 0}
          className="flex items-center gap-2"
        >
          <TestTube className="h-4 w-4" />
          Add Test Entry
        </Button>
        
        {selectedPlant && plantData.machines.length > 0 && (
          <Badge variant="secondary" className="flex items-center gap-1">
            <Factory className="h-3 w-3" />
            {plantData.machines.length} machines configured
          </Badge>
        )}
        
        {selectedPlant && plantData.officers.length > 0 && (
          <Badge variant="secondary" className="flex items-center gap-1">
            <Settings className="h-3 w-3" />
            {plantData.officers.length} officers configured
          </Badge>
        )}
      </div>

      {/* Display Test Databases */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">
          {selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Test Databases
        </h2>

        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div>
          </div>
        ) : filteredDatabases.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Database className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <h3 className="font-medium mb-2">No databases found</h3>
              <p className="text-sm text-muted-foreground">
                Create a new database to begin testing for {selectedCategory}.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDatabases.map((database) => (
              <Card key={database.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span>{database.product}</span>
                    <Badge variant="secondary">
                      {database.category}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Factory className="h-4 w-4 text-muted-foreground" />
                      <span>{database.plant}</span>
                    </div>
                    <Badge className="text-xs">
                      {database.entries_count} entries
                    </Badge>
                  </div>
                  
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-xs text-muted-foreground">
                      Last updated: {new Date(database.last_updated).toLocaleDateString()}
                    </div>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewTestData(database)}
                      className="ml-auto"
                    >
                      <Search className="h-4 w-4 mr-2" />
                      View Data
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Enhanced Aggregates Modal */}
      <EnhancedAggregatesModal
        isOpen={showAggregatesModal}
        onOpenChange={setShowAggregatesModal}
        onSubmit={async (data) => {
          try {
            await plantTestService.createTestEntry('aggregates', selectedTable, data);
            toast({
              title: "Aggregates Test Saved",
              description: "Aggregate test results saved successfully"
            });
            loadTestDatabases();
            setShowAggregatesModal(false);
          } catch (error) {
            console.error('Error saving aggregates test:', error);
            toast({
              title: "Save Failed",
              description: "Failed to save aggregate test results",
              variant: "destructive"
            });
          }
        }}
        isLoading={false}
      />

      {/* Test Entry Modal */}
      <TestEntryModal
        isOpen={showTestEntryModal}
        onClose={() => setShowTestEntryModal(false)}
        category={selectedCategory}
        tableName={selectedTable}
        onSuccess={() => {
          loadTestDatabases();
          setShowTestEntryModal(false);
        }}
      />

      {/* Plant Configuration Modal */}
      {selectedPlant && (
        <PlantSpecificDataManager
          selectedPlant={selectedPlant}
          isOpen={showPlantConfig}
          onClose={() => setShowPlantConfig(false)}
        />
      )}
    </div>
  );
}