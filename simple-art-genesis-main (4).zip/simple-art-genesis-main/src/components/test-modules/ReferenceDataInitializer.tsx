import React, { useEffect } from 'react';
import { useReferenceDataInitialization } from '@/hooks/useReferenceData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Database, CheckCircle, AlertCircle } from 'lucide-react';

export function ReferenceDataInitializer() {
  const { initialize, loading, error } = useReferenceDataInitialization();

  useEffect(() => {
    // Auto-initialize on component mount
    initialize();
  }, [initialize]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Reference Data System
        </CardTitle>
        <CardDescription>
          Initialize reference data tables for Plants, Officers, Machines, Test Types, and more
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
            Initializing reference data tables...
          </div>
        )}
        
        {error && (
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-4 w-4" />
            {error}
          </div>
        )}
        
        {!loading && !error && (
          <div className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-4 w-4" />
            Reference data system initialized successfully
          </div>
        )}
        
        <Button 
          onClick={initialize} 
          disabled={loading}
          variant="outline"
          size="sm"
        >
          {loading ? 'Initializing...' : 'Re-initialize Tables'}
        </Button>
      </CardContent>
    </Card>
  );
}