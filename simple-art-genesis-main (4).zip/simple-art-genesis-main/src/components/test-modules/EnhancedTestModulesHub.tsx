import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Plus, Search, Filter, Settings, TestTube, Building, Package2, 
  Calendar, User, MapPin, Edit, Trash2, Eye, AlertTriangle,
  Database, RefreshCw, FileText, CheckCircle, Clock, Target
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { DynamicFormBuilder } from './DynamicFormBuilder';
import { TestModulesAPI, ProductCategory, ProductType, TestEntry, PlantConfiguration, MemoTestAssignment } from '@/services/api/testModulesAPI';
import { TestModulesMigrationService } from '@/services/database/testModulesMigrationService';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';
import { useUser } from '@/contexts/UserContext';

interface FilterState {
  category: string;
  productType: string;
  plant: string;
  status: string;
  dateFrom: string;
  dateTo: string;
  searchTerm: string;
}

export function EnhancedTestModulesHub() {
  const { toast } = useToast();
  const { user } = useUser();

  // State management
  const [currentTab, setCurrentTab] = useState('entries');
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [testEntries, setTestEntries] = useState<TestEntry[]>([]);
  const [plants, setPlants] = useState<PlantConfiguration[]>([]);
  const [memoAssignments, setMemoAssignments] = useState<MemoTestAssignment[]>([]);
  const [loading, setLoading] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState<{ needed: boolean; reason: string } | null>(null);

  // Form and dialog states
  const [showTestForm, setShowTestForm] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<TestEntry | null>(null);
  const [formMode, setFormMode] = useState<'create' | 'edit' | 'view'>('create');
  const [selectedProductType, setSelectedProductType] = useState<string>('');
  const [selectedMemo, setSelectedMemo] = useState<string>('');
  const [selectedPlant, setSelectedPlant] = useState<string>('');

  // Filters
  const [filters, setFilters] = useState<FilterState>({
    category: '',
    productType: '',
    plant: '',
    status: '',
    dateFrom: '',
    dateTo: '',
    searchTerm: ''
  });

  // Load data on mount
  useEffect(() => {
    initializeSystem();
  }, []);

  // Load product types when category changes
  useEffect(() => {
    if (filters.category) {
      loadProductTypes(filters.category);
    } else {
      loadProductTypes();
    }
  }, [filters.category]);

  // Load test entries when filters change
  useEffect(() => {
    loadTestEntries();
  }, [filters]);

  const initializeSystem = async () => {
    try {
      setLoading(true);

      // Check if migrations are needed
      const migrationCheck = await TestModulesMigrationService.checkMigrationStatus();
      setMigrationStatus(migrationCheck);

      if (migrationCheck.needed) {
        toast({
          title: "Database Setup Required",
          description: "Test modules database needs to be initialized. Click 'Run Migration' to set up.",
          variant: "destructive"
        });
        return;
      }

      // Load all data
      await Promise.all([
        loadCategories(),
        loadProductTypes(),
        loadTestEntries(),
        loadPlants(),
        loadMemoAssignments()
      ]);

    } catch (error) {
      console.error('Failed to initialize test modules:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to initialize test modules. Please check your database connection.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const runMigration = async () => {
    try {
      setLoading(true);
      toast({
        title: "Running Migration",
        description: "Setting up test modules database. This may take a moment..."
      });

      const result = await TestModulesMigrationService.runMigrations();
      
      if (result.success) {
        toast({
          title: "Migration Successful",
          description: `Created ${result.tablesCreated.length} tables and seeded ${result.dataSeeded} records.`
        });
        
        setMigrationStatus({ needed: false, reason: 'Migration completed' });
        
        // Reload data after successful migration
        await initializeSystem();
      } else {
        toast({
          title: "Migration Failed",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Migration failed:', error);
      toast({
        title: "Migration Error",
        description: "Failed to run database migration. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const data = await TestModulesAPI.getProductCategories();
      setCategories(data);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadProductTypes = async (categoryId?: string) => {
    try {
      const data = await TestModulesAPI.getProductTypes(categoryId);
      setProductTypes(data);
    } catch (error) {
      console.error('Failed to load product types:', error);
    }
  };

  const loadTestEntries = async () => {
    try {
      const filterParams = {
        productTypeId: filters.productType || undefined,
        plantId: filters.plant || undefined,
        status: filters.status || undefined,
        dateFrom: filters.dateFrom || undefined,
        dateTo: filters.dateTo || undefined
      };

      const data = await TestModulesAPI.getTestEntries(filterParams);
      
      // Apply search filter locally
      let filteredData = data;
      if (filters.searchTerm) {
        const searchLower = filters.searchTerm.toLowerCase();
        filteredData = data.filter(entry => 
          entry.id.toLowerCase().includes(searchLower) ||
          entry.notes?.toLowerCase().includes(searchLower) ||
          JSON.stringify(entry.test_data).toLowerCase().includes(searchLower)
        );
      }

      setTestEntries(filteredData);
    } catch (error) {
      console.error('Failed to load test entries:', error);
    }
  };

  const loadPlants = async () => {
    try {
      const data = await TestModulesAPI.getPlantConfigurations();
      setPlants(data);
      
      // Set default plant if none selected
      if (data.length > 0 && !selectedPlant) {
        setSelectedPlant(data[0].id);
      }
    } catch (error) {
      console.error('Failed to load plants:', error);
    }
  };

  const loadMemoAssignments = async () => {
    try {
      const data = await TestModulesAPI.getMemoTestAssignments({
        assignedTo: user?.id,
        status: 'pending'
      });
      setMemoAssignments(data);
    } catch (error) {
      console.error('Failed to load memo assignments:', error);
    }
  };

  const handleCreateTest = () => {
    if (!selectedProductType) {
      toast({
        title: "Product Type Required",
        description: "Please select a product type before creating a test entry.",
        variant: "destructive"
      });
      return;
    }

    setSelectedEntry(null);
    setFormMode('create');
    setShowTestForm(true);
  };

  const handleEditTest = (entry: TestEntry) => {
    setSelectedEntry(entry);
    setFormMode('edit');
    setShowTestForm(true);
  };

  const handleViewTest = (entry: TestEntry) => {
    setSelectedEntry(entry);
    setFormMode('view');
    setShowTestForm(true);
  };

  const handleFormSubmit = async (formData: Record<string, any>) => {
    try {
      setLoading(true);

      const testEntry = {
        product_type_id: selectedProductType,
        memo_id: selectedMemo || undefined,
        plant_id: selectedPlant,
        officer_id: user?.id || 'unknown',
        test_date: formData.test_date || new Date().toISOString().split('T')[0],
        test_data: formData,
        status: 'submitted' as const,
        notes: formData.notes || '',
        created_by: user?.id || 'unknown'
      };

      const result = await TestModulesAPI.createTestEntry(testEntry);

      if (result) {
        toast({
          title: "Success",
          description: `Test entry ${formMode === 'create' ? 'created' : 'updated'} successfully.`
        });
        
        setShowTestForm(false);
        await loadTestEntries();
        
        // Refresh memo assignments if memo was involved
        if (selectedMemo) {
          await loadMemoAssignments();
        }
      } else {
        throw new Error('Failed to save test entry');
      }
    } catch (error) {
      console.error('Failed to save test entry:', error);
      toast({
        title: "Error",
        description: `Failed to ${formMode === 'create' ? 'create' : 'update'} test entry. Please try again.`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateFilters = (key: keyof FilterState, value: string) => {
    const actualValue = value === 'all' ? '' : value;
    setFilters(prev => ({ ...prev, [key]: actualValue }));
  };

  const clearFilters = () => {
    setFilters({
      category: '',
      productType: '',
      plant: '',
      status: '',
      dateFrom: '',
      dateTo: '',
      searchTerm: ''
    });
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      draft: 'outline',
      submitted: 'default',
      approved: 'secondary',
      rejected: 'destructive'
    };
    
    return <Badge variant={variants[status] || 'outline'}>{status}</Badge>;
  };

  const getProductTypeName = (productTypeId: string) => {
    const productType = productTypes.find(pt => pt.id === productTypeId);
    return productType?.name || productTypeId;
  };

  const getPlantName = (plantId: string) => {
    const plant = plants.find(p => p.id === plantId);
    return plant?.name || plantId;
  };

  // Show migration prompt if needed
  if (migrationStatus?.needed) {
    return (
      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Database Setup Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {migrationStatus.reason}
              </AlertDescription>
            </Alert>
            
            <PermissionWrapper permissions={['system.migrate']}>
              <Button onClick={runMigration} disabled={loading}>
                {loading ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Running Migration...
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4 mr-2" />
                    Run Migration
                  </>
                )}
              </Button>
            </PermissionWrapper>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Test Modules</h1>
          <p className="text-muted-foreground">
            Manage plant-specific test databases and entries
          </p>
        </div>
        
        <PermissionWrapper permissions={['test_data.create']}>
          <Button onClick={handleCreateTest} disabled={loading}>
            <Plus className="h-4 w-4 mr-2" />
            New Test Entry
          </Button>
        </PermissionWrapper>
      </div>

      {/* Tabs */}
      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList>
          <TabsTrigger value="entries">Test Entries</TabsTrigger>
          <TabsTrigger value="assignments">Memo Assignments</TabsTrigger>
          <TabsTrigger value="configuration">Plant Configuration</TabsTrigger>
        </TabsList>

        {/* Test Entries Tab */}
        <TabsContent value="entries" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <Select value={filters.category || 'all'} onValueChange={(value) => updateFilters('category', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="All categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Product Type</label>
                  <Select value={filters.productType || 'all'} onValueChange={(value) => {
                    updateFilters('productType', value);
                    setSelectedProductType(value === 'all' ? '' : value);
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="All product types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All product types</SelectItem>
                      {productTypes.map(productType => (
                        <SelectItem key={productType.id} value={productType.id}>
                          {productType.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Plant</label>
                  <Select value={filters.plant || 'all'} onValueChange={(value) => updateFilters('plant', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="All plants" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All plants</SelectItem>
                      {plants.map(plant => (
                        <SelectItem key={plant.id} value={plant.id}>
                          {plant.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Status</label>
                  <Select value={filters.status || 'all'} onValueChange={(value) => updateFilters('status', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All statuses</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="submitted">Submitted</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">From Date</label>
                  <Input
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) => updateFilters('dateFrom', e.target.value)}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">To Date</label>
                  <Input
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) => updateFilters('dateTo', e.target.value)}
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="text-sm font-medium">Search</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search test entries..."
                      value={filters.searchTerm}
                      onChange={(e) => updateFilters('searchTerm', e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Test Entries List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Test Entries ({testEntries.length})</span>
                <Button variant="outline" size="sm" onClick={loadTestEntries}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-2" />
                  <p>Loading test entries...</p>
                </div>
              ) : testEntries.length === 0 ? (
                <div className="text-center py-8">
                  <TestTube className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No test entries found. Create your first test entry to get started.
                  </p>
                </div>
              ) : (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-2">
                    {testEntries.map(entry => (
                      <div key={entry.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium">{getProductTypeName(entry.product_type_id)}</span>
                            {getStatusBadge(entry.status)}
                            {entry.memo_id && (
                              <Badge variant="outline" className="text-xs">
                                Memo: {entry.memo_id}
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground space-y-1">
                            <div className="flex items-center gap-4">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {getPlantName(entry.plant_id)}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {new Date(entry.test_date).toLocaleDateString()}
                              </span>
                              <span className="flex items-center gap-1">
                                <User className="h-3 w-3" />
                                {entry.officer_id}
                              </span>
                            </div>
                            {entry.notes && (
                              <p className="text-xs italic">{entry.notes}</p>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleViewTest(entry)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          
                          <PermissionWrapper permissions={['test_data.edit']}>
                            <Button variant="ghost" size="sm" onClick={() => handleEditTest(entry)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          </PermissionWrapper>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Memo Assignments Tab */}
        <TabsContent value="assignments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Pending Test Assignments ({memoAssignments.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {memoAssignments.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No pending test assignments. All tests are up to date!
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {memoAssignments.map(assignment => (
                    <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">Memo: {assignment.memo_id}</span>
                          <Badge variant={assignment.status === 'overdue' ? 'destructive' : 'default'}>
                            {assignment.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <p>Product Type: {getProductTypeName(assignment.product_type_id)}</p>
                          {assignment.due_date && (
                            <p className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              Due: {new Date(assignment.due_date).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <PermissionWrapper permissions={['test_data.create']}>
                        <Button 
                          size="sm"
                          onClick={() => {
                            setSelectedMemo(assignment.memo_id);
                            setSelectedProductType(assignment.product_type_id);
                            handleCreateTest();
                          }}
                        >
                          Create Test
                        </Button>
                      </PermissionWrapper>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Plant Configuration Tab */}
        <TabsContent value="configuration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Plant Configurations
              </CardTitle>
            </CardHeader>
            <CardContent>
              {plants.length === 0 ? (
                <div className="text-center py-8">
                  <Building className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No plant configurations found. Please configure your plants in the Reference Data Manager.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {plants.map(plant => (
                    <Card key={plant.id}>
                      <CardHeader>
                        <CardTitle className="text-lg">{plant.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{plant.location}</p>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div>
                            <span className="text-sm font-medium">Machines: </span>
                            <span className="text-sm">{plant.machines.length}</span>
                          </div>
                          <div>
                            <span className="text-sm font-medium">Officers: </span>
                            <span className="text-sm">{plant.officers.length}</span>
                          </div>
                          {plant.contact_info && Object.keys(plant.contact_info).length > 0 && (
                            <div className="pt-2 border-t">
                              <span className="text-sm font-medium">Contact:</span>
                              <div className="text-xs text-muted-foreground mt-1">
                                {JSON.stringify(plant.contact_info, null, 2)}
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Test Form Dialog */}
      <Dialog open={showTestForm} onOpenChange={setShowTestForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {formMode === 'create' ? 'Create Test Entry' : 
               formMode === 'edit' ? 'Edit Test Entry' : 'View Test Entry'}
            </DialogTitle>
          </DialogHeader>
          
          {selectedProductType && (
            <DynamicFormBuilder
              productTypeId={selectedProductType}
              onSubmit={handleFormSubmit}
              onCancel={() => setShowTestForm(false)}
              initialData={selectedEntry?.test_data}
              mode={formMode}
              memoId={selectedMemo}
              plantId={selectedPlant}
              officerId={user?.id}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}