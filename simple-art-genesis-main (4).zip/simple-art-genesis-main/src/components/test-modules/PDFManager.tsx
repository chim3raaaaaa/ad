import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { Upload, FileText, Download, Eye, Trash2 } from 'lucide-react';

interface PDFFile {
  id: string;
  name: string;
  size: number;
  testId?: string;
  uploadDate: string;
  type: 'calculation_sheet' | 'test_report' | 'certification' | 'other';
}

interface PDFManagerProps {
  testId?: string;
  category?: string;
}

export function PDFManager({ testId, category }: PDFManagerProps) {
  const [files, setFiles] = useState<PDFFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        title: "Invalid File Type",
        description: "Please upload PDF files only",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    
    try {
      // Simulate upload process
      const newFile: PDFFile = {
        id: `pdf_${Date.now()}`,
        name: file.name,
        size: file.size,
        testId,
        uploadDate: new Date().toISOString(),
        type: 'test_report'
      };

      // Store file in localStorage (in real app, would upload to server/storage)
      const fileData = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });

      localStorage.setItem(`pdf_${newFile.id}`, fileData);
      
      const updatedFiles = [...files, newFile];
      setFiles(updatedFiles);
      
      // Store file metadata
      const allFiles = JSON.parse(localStorage.getItem('pdf_files') || '[]');
      allFiles.push(newFile);
      localStorage.setItem('pdf_files', JSON.stringify(allFiles));

      toast({
        title: "PDF Uploaded",
        description: `${file.name} uploaded successfully`
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload PDF file",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDownload = (file: PDFFile) => {
    try {
      const fileData = localStorage.getItem(`pdf_${file.id}`);
      if (!fileData) {
        toast({
          title: "File Not Found",
          description: "PDF file data not found",
          variant: "destructive"
        });
        return;
      }

      const link = document.createElement('a');
      link.href = fileData;
      link.download = file.name;
      link.click();

      toast({
        title: "Download Started",
        description: `Downloading ${file.name}`
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download PDF file",
        variant: "destructive"
      });
    }
  };

  const handleDelete = (fileId: string) => {
    try {
      // Remove file data
      localStorage.removeItem(`pdf_${fileId}`);
      
      // Update file list
      const updatedFiles = files.filter(f => f.id !== fileId);
      setFiles(updatedFiles);
      
      // Update metadata
      const allFiles = JSON.parse(localStorage.getItem('pdf_files') || '[]');
      const filteredFiles = allFiles.filter((f: PDFFile) => f.id !== fileId);
      localStorage.setItem('pdf_files', JSON.stringify(filteredFiles));

      toast({
        title: "PDF Deleted",
        description: "PDF file deleted successfully"
      });
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Failed to delete PDF file",
        variant: "destructive"
      });
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Load files on component mount
  React.useEffect(() => {
    const loadFiles = () => {
      try {
        const allFiles = JSON.parse(localStorage.getItem('pdf_files') || '[]');
        const relevantFiles = testId 
          ? allFiles.filter((f: PDFFile) => f.testId === testId)
          : allFiles;
        setFiles(relevantFiles);
      } catch (error) {
        console.error('Error loading PDF files:', error);
      }
    };

    loadFiles();
  }, [testId]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            PDF Management
          </span>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Upload PDF
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Upload PDF Document</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    disabled={uploading}
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Upload calculation sheets, test reports, or certification documents (PDF only)
                </p>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {files.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No PDF files uploaded yet</p>
            <p className="text-sm">Upload documents to get started</p>
          </div>
        ) : (
          <div className="space-y-2">
            {files.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5 text-red-500" />
                  <div>
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatFileSize(file.size)} • Uploaded {new Date(file.uploadDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDownload(file)}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(file.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}