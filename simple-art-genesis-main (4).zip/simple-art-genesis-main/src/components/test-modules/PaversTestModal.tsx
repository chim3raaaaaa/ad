import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { directInputService } from '@/services/database/DirectInputService';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface PaversTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  memoId?: string;
  plantId?: string;
}

export function PaversTestModal({ isOpen, onClose, onSuccess, memoId, plantId }: PaversTestModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    // General Information
    memo_reference: memoId || '',
    plant_id: plantId || '',
    batch_id: '',
    test_date: new Date().toISOString().split('T')[0],
    operator: '',
    
    // Paver Specifications
    paver_type: '',
    dimensions_length: '',
    dimensions_width: '',
    dimensions_thickness: '',
    surface_finish: '',
    color: '',
    
    // Physical Properties
    compressive_strength: '',
    water_absorption: '',
    abrasion_resistance: '',
    slip_resistance: '',
    frost_resistance: '',
    
    // Quality Control
    dimensional_tolerance: '',
    surface_quality: '',
    edge_quality: '',
    color_consistency: '',
    
    // Test Conditions
    curing_period: '',
    test_temperature: '',
    test_humidity: '',
    
    // Results
    pass_fail_status: 'pending',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): boolean => {
    const required = ['test_date', 'operator', 'paver_type'];
    const missing = required.filter(field => !formData[field as keyof typeof formData]);
    
    if (missing.length > 0) {
      toast({
        title: "Validation Error",
        description: `Missing required fields: ${missing.join(', ')}`,
        variant: "destructive"
      });
      return false;
    }

    // Validate water absorption (typical limit: ≤ 6%)
    if (formData.water_absorption && parseFloat(formData.water_absorption) > 6) {
      toast({
        title: "Validation Warning",
        description: "Water absorption exceeds typical limit of 6%",
        variant: "destructive"
      });
    }

    // Validate compressive strength (typical minimum: 35 MPa)
    if (formData.compressive_strength && parseFloat(formData.compressive_strength) < 35) {
      toast({
        title: "Validation Warning", 
        description: "Compressive strength below typical minimum of 35 MPa",
        variant: "destructive"
      });
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await directInputService.createDirectInputResult({
        product_type: 'pavers',
        plant_id: formData.plant_id,
        memo_id: formData.memo_reference,
        test_data: formData,
        operator: formData.operator,
        test_date: formData.test_date,
        status: formData.pass_fail_status as 'pass' | 'fail' | 'pending'
      });

      toast({
        title: "Success",
        description: "Pavers test entry saved successfully"
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving pavers test:', error);
      toast({
        title: "Error",
        description: "Failed to save pavers test entry",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Pavers Test Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* General Information */}
          <Card>
            <CardHeader>
              <CardTitle>General Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="memo_reference">Memo Reference</Label>
                  <Input
                    id="memo_reference"
                    value={formData.memo_reference}
                    onChange={(e) => handleInputChange('memo_reference', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="batch_id">Batch ID</Label>
                  <Input
                    id="batch_id"
                    value={formData.batch_id}
                    onChange={(e) => handleInputChange('batch_id', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="test_date">Test Date *</Label>
                  <Input
                    id="test_date"
                    type="date"
                    value={formData.test_date}
                    onChange={(e) => handleInputChange('test_date', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="operator">Operator *</Label>
                  <Input
                    id="operator"
                    value={formData.operator}
                    onChange={(e) => handleInputChange('operator', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Paver Specifications */}
          <Card>
            <CardHeader>
              <CardTitle>Paver Specifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="paver_type">Paver Type *</Label>
                  <Select value={formData.paver_type} onValueChange={(value) => handleInputChange('paver_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select paver type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rectangular">Rectangular</SelectItem>
                      <SelectItem value="square">Square</SelectItem>
                      <SelectItem value="interlocking">Interlocking</SelectItem>
                      <SelectItem value="hexagonal">Hexagonal</SelectItem>
                      <SelectItem value="decorative">Decorative</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="surface_finish">Surface Finish</Label>
                  <Select value={formData.surface_finish} onValueChange={(value) => handleInputChange('surface_finish', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select finish" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="smooth">Smooth</SelectItem>
                      <SelectItem value="textured">Textured</SelectItem>
                      <SelectItem value="exposed_aggregate">Exposed Aggregate</SelectItem>
                      <SelectItem value="brushed">Brushed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="dimensions_length">Length (mm)</Label>
                  <Input
                    id="dimensions_length"
                    type="number"
                    value={formData.dimensions_length}
                    onChange={(e) => handleInputChange('dimensions_length', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="dimensions_width">Width (mm)</Label>
                  <Input
                    id="dimensions_width"
                    type="number"
                    value={formData.dimensions_width}
                    onChange={(e) => handleInputChange('dimensions_width', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="dimensions_thickness">Thickness (mm)</Label>
                  <Input
                    id="dimensions_thickness"
                    type="number"
                    value={formData.dimensions_thickness}
                    onChange={(e) => handleInputChange('dimensions_thickness', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Physical Properties */}
          <Card>
            <CardHeader>
              <CardTitle>Physical Properties</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="compressive_strength">Compressive Strength (MPa)</Label>
                  <Input
                    id="compressive_strength"
                    type="number"
                    step="0.1"
                    value={formData.compressive_strength}
                    onChange={(e) => handleInputChange('compressive_strength', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="water_absorption">Water Absorption (%)</Label>
                  <Input
                    id="water_absorption"
                    type="number"
                    step="0.1"
                    value={formData.water_absorption}
                    onChange={(e) => handleInputChange('water_absorption', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="abrasion_resistance">Abrasion Resistance</Label>
                  <Input
                    id="abrasion_resistance"
                    value={formData.abrasion_resistance}
                    onChange={(e) => handleInputChange('abrasion_resistance', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="slip_resistance">Slip Resistance</Label>
                  <Input
                    id="slip_resistance"
                    value={formData.slip_resistance}
                    onChange={(e) => handleInputChange('slip_resistance', e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality Control */}
          <Card>
            <CardHeader>
              <CardTitle>Quality Control</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="pass_fail_status">Status</Label>
                  <Select value={formData.pass_fail_status} onValueChange={(value) => handleInputChange('pass_fail_status', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="pass">Pass</SelectItem>
                      <SelectItem value="fail">Fail</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dimensional_tolerance">Dimensional Tolerance</Label>
                  <Select value={formData.dimensional_tolerance} onValueChange={(value) => handleInputChange('dimensional_tolerance', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select tolerance" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="within_spec">Within Specification</SelectItem>
                      <SelectItem value="minor_deviation">Minor Deviation</SelectItem>
                      <SelectItem value="major_deviation">Major Deviation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <PermissionWrapper permission="tests.create">
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Test Entry'}
            </Button>
          </PermissionWrapper>
        </div>
      </DialogContent>
    </Dialog>
  );
}