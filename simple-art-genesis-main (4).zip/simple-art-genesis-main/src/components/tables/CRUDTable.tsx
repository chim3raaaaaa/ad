import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Search, Filter, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TableColumn {
  id: string;
  name: string;
  type: string;
  sortable?: boolean;
  filterable?: boolean;
}

interface CRUDTableProps {
  tableId: string;
  tableName: string;
  columns: TableColumn[];
  placement?: string;
  showActions?: boolean;
  maxHeight?: string;
}

interface TableRow {
  id: string;
  [key: string]: any;
}

export function CRUDTable({ 
  tableId, 
  tableName, 
  columns, 
  placement, 
  showActions = true,
  maxHeight = "600px"
}: CRUDTableProps) {
  const { toast } = useToast();
  const [data, setData] = useState<TableRow[]>([]);
  const [filteredData, setFilteredData] = useState<TableRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [selectedRow, setSelectedRow] = useState<TableRow | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [formData, setFormData] = useState<Record<string, any>>({});

  useEffect(() => {
    loadTableData();
  }, [tableId]);

  useEffect(() => {
    filterAndSortData();
  }, [data, searchTerm, sortColumn, sortDirection]);

  const getActualTableName = () => {
    return `custom_${tableName.toLowerCase().replace(/\s+/g, '_')}`;
  };

  const loadTableData = async () => {
    try {
      setIsLoading(true);
      
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM ${getActualTableName()} ORDER BY created_at DESC`,
          []
        );
        
        if (result.success) {
          setData(result.data || []);
        } else {
          // Table might not exist yet
          setData([]);
        }
      } else {
        // Fallback to localStorage for web version
        const saved = localStorage.getItem(`table_data_${tableId}`);
        if (saved) {
          setData(JSON.parse(saved));
        }
      }
    } catch (error) {
      console.error('Error loading table data:', error);
      setData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const filterAndSortData = () => {
    let filtered = [...data];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(row =>
        Object.values(row).some(value =>
          String(value).toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    // Apply sorting
    if (sortColumn) {
      filtered.sort((a, b) => {
        const aVal = a[sortColumn];
        const bVal = b[sortColumn];
        
        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
        }
        
        const aStr = String(aVal || '').toLowerCase();
        const bStr = String(bVal || '').toLowerCase();
        
        if (sortDirection === 'asc') {
          return aStr.localeCompare(bStr);
        } else {
          return bStr.localeCompare(aStr);
        }
      });
    }

    setFilteredData(filtered);
  };

  const handleSort = (columnId: string) => {
    if (sortColumn === columnId) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(columnId);
      setSortDirection('asc');
    }
  };

  const createRow = async () => {
    try {
      const cleanData = { ...formData };
      delete cleanData.id; // Remove ID as it will be auto-generated
      
      const columnNames = columns.map(col => col.id.replace(/[^a-zA-Z0-9]/g, '_'));
      const values = columns.map(col => cleanData[col.id] || null);
      const placeholders = columns.map(() => '?').join(', ');

      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT INTO ${getActualTableName()} (${columnNames.join(', ')}) VALUES (${placeholders})`,
          values
        );
        
        if (!result.success) {
          throw new Error(result.error);
        }
      }

      toast({
        title: "Success",
        description: "Record created successfully"
      });

      setShowCreateDialog(false);
      setFormData({});
      loadTableData();

    } catch (error) {
      console.error('Error creating record:', error);
      toast({
        title: "Error",
        description: `Failed to create record: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const updateRow = async () => {
    if (!selectedRow) return;

    try {
      const cleanData = { ...formData };
      delete cleanData.id;
      
      const updateFields = Object.keys(cleanData).map(key => `${key.replace(/[^a-zA-Z0-9]/g, '_')} = ?`);
      const values = Object.values(cleanData);

      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `UPDATE ${getActualTableName()} SET ${updateFields.join(', ')}, updated_at = ? WHERE id = ?`,
          [...values, new Date().toISOString(), selectedRow.id]
        );
        
        if (!result.success) {
          throw new Error(result.error);
        }
      }

      toast({
        title: "Success",
        description: "Record updated successfully"
      });

      setShowEditDialog(false);
      setSelectedRow(null);
      setFormData({});
      loadTableData();

    } catch (error) {
      console.error('Error updating record:', error);
      toast({
        title: "Error",
        description: `Failed to update record: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const deleteRow = async (row: TableRow) => {
    if (!confirm('Are you sure you want to delete this record?')) return;

    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `DELETE FROM ${getActualTableName()} WHERE id = ?`,
          [row.id]
        );
        
        if (!result.success) {
          throw new Error(result.error);
        }
      }

      toast({
        title: "Success",
        description: "Record deleted successfully"
      });

      loadTableData();

    } catch (error) {
      console.error('Error deleting record:', error);
      toast({
        title: "Error",
        description: `Failed to delete record: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const exportData = () => {
    const csvContent = [
      columns.map(col => col.name).join(','),
      ...filteredData.map(row => 
        columns.map(col => {
          const value = row[col.id] || '';
          return typeof value === 'string' && value.includes(',') ? `"${value}"` : value;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tableName}_export.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const openCreateDialog = () => {
    setFormData({});
    setShowCreateDialog(true);
  };

  const openEditDialog = (row: TableRow) => {
    setSelectedRow(row);
    setFormData({ ...row });
    setShowEditDialog(true);
  };

  const renderFormField = (column: TableColumn, value: any, onChange: (value: any) => void) => {
    switch (column.type) {
      case 'INTEGER':
      case 'REAL':
        return (
          <Input
            type="number"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`Enter ${column.name.toLowerCase()}`}
          />
        );
      case 'BOOLEAN':
        return (
          <Select value={value?.toString() || 'false'} onValueChange={(v) => onChange(v === 'true')}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="true">Yes</SelectItem>
              <SelectItem value="false">No</SelectItem>
            </SelectContent>
          </Select>
        );
      case 'DATETIME':
        return (
          <Input
            type="datetime-local"
            value={value ? new Date(value).toISOString().slice(0, 16) : ''}
            onChange={(e) => onChange(e.target.value ? new Date(e.target.value).toISOString() : '')}
          />
        );
      default:
        return (
          <Input
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder={`Enter ${column.name.toLowerCase()}`}
          />
        );
    }
  };

  const formatCellValue = (value: any, column: TableColumn) => {
    if (value === null || value === undefined) return 'N/A';
    
    switch (column.type) {
      case 'BOOLEAN':
        return value ? 'Yes' : 'No';
      case 'DATETIME':
        return new Date(value).toLocaleString();
      default:
        return String(value);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{tableName}</CardTitle>
            {placement && (
              <Badge variant="outline" className="mt-1">
                {placement}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={exportData}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            {showActions && (
              <Button size="sm" onClick={openCreateDialog}>
                <Plus className="w-4 h-4 mr-2" />
                Add Record
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Search and Filter */}
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search records..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <Badge variant="secondary">
            {filteredData.length} records
          </Badge>
        </div>

        {/* Data Table */}
        <div className="border rounded-lg" style={{ maxHeight, overflowY: 'auto' }}>
          <Table>
            <TableHeader>
              <TableRow>
                {columns.map(column => (
                  <TableHead 
                    key={column.id}
                    className={column.sortable ? 'cursor-pointer hover:bg-muted' : ''}
                    onClick={() => column.sortable && handleSort(column.id)}
                  >
                    <div className="flex items-center gap-2">
                      {column.name}
                      {column.sortable && sortColumn === column.id && (
                        <span className="text-xs">
                          {sortDirection === 'asc' ? '↑' : '↓'}
                        </span>
                      )}
                    </div>
                  </TableHead>
                ))}
                {showActions && <TableHead>Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={columns.length + (showActions ? 1 : 0)} className="text-center">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={columns.length + (showActions ? 1 : 0)} className="text-center text-muted-foreground">
                    No records found
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map(row => (
                  <TableRow key={row.id}>
                    {columns.map(column => (
                      <TableCell key={column.id}>
                        {formatCellValue(row[column.id], column)}
                      </TableCell>
                    ))}
                    {showActions && (
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => openEditDialog(row)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteRow(row)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Record</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {columns.map(column => (
              <div key={column.id}>
                <Label>{column.name}</Label>
                {renderFormField(
                  column,
                  formData[column.id],
                  (value) => setFormData(prev => ({ ...prev, [column.id]: value }))
                )}
              </div>
            ))}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
              <Button onClick={createRow}>
                Create
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Record</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {columns.map(column => (
              <div key={column.id}>
                <Label>{column.name}</Label>
                {renderFormField(
                  column,
                  formData[column.id],
                  (value) => setFormData(prev => ({ ...prev, [column.id]: value }))
                )}
              </div>
            ))}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                Cancel
              </Button>
              <Button onClick={updateRow}>
                Update
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}