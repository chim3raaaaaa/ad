import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Edit, Trash2, Send } from "lucide-react";
import { MemoData } from "@/services/database/memoService";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";
import { format } from "date-fns";

interface MemoTableProps {
  memos: MemoData[];
  onViewMemo: (memo: MemoData) => void;
  onEditMemo: (memo: MemoData) => void;
  onDeleteMemo: (memo: MemoData) => void;
  onSubmitToInbox: (memo: MemoData) => void;
  isLoading?: boolean;
}

export function MemoTable({
  memos,
  onViewMemo,
  onEditMemo,
  onDeleteMemo,
  onSubmitToInbox,
  isLoading = false
}: MemoTableProps) {
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'approved':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'rejected':
        return 'destructive';
      case 'draft':
        return 'outline';
      default:
        return 'outline';
    }
  };

  if (isLoading) {
    return (
      <div className="border rounded-lg p-8 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">Loading memos...</p>
      </div>
    );
  }

  if (memos.length === 0) {
    return (
      <div className="border rounded-lg p-8 text-center">
        <p className="text-muted-foreground mb-4">No memos found</p>
        <p className="text-sm text-muted-foreground">
          Create your first memo to get started with test request management.
        </p>
      </div>
    );
  }

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Memo Ref</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Plant</TableHead>
            <TableHead>Product Type</TableHead>
            <TableHead>Officer</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Date</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {memos.map((memo) => (
            <TableRow key={memo.id}>
              <TableCell className="font-medium">{memo.memo_ref}</TableCell>
              <TableCell>
                <Badge variant="outline">{memo.category}</Badge>
              </TableCell>
              <TableCell>{memo.plant}</TableCell>
              <TableCell>{memo.product_type}</TableCell>
              <TableCell>{memo.officer}</TableCell>
              <TableCell>
                <Badge variant={getStatusBadgeVariant(memo.status)}>
                  {memo.status.charAt(0).toUpperCase() + memo.status.slice(1)}
                </Badge>
              </TableCell>
              <TableCell>
                {format(new Date(memo.date_of_sampling), 'MMM dd, yyyy')}
              </TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onViewMemo(memo)}
                    className="h-8 w-8 p-0"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  
                  <PermissionWrapper permission="memo:edit">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEditMemo(memo)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </PermissionWrapper>
                  
                  <PermissionWrapper permission="memo:submit">
                    {memo.status === 'draft' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onSubmitToInbox(memo)}
                        className="h-8 w-8 p-0"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    )}
                  </PermissionWrapper>
                  
                  <PermissionWrapper permission="memo:delete">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDeleteMemo(memo)}
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </PermissionWrapper>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}