import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { format } from "date-fns";
import { CalendarIcon as CalIcon } from "lucide-react";
import { memoService, MemoCategory } from "@/services/database/memoService";
import { useUser } from "@/contexts/UserContext";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface MemoCreateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onMemoCreated: () => void;
}

interface FormData {
  category: string;
  plant: string;
  product_type: string;
  material_type?: string;
  date_of_sampling: Date;
  officer: string;
  machine?: string;
}

export function MemoCreateModal({ open, onOpenChange, onMemoCreated }: MemoCreateModalProps) {
  const [categories, setCategories] = useState<MemoCategory[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const { user: currentUser } = useUser();
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset
  } = useForm<FormData>({
    defaultValues: {
      date_of_sampling: new Date(),
      officer: currentUser?.username || ''
    }
  });

  const selectedCategory = watch('category');
  const selectedPlant = watch('plant');
  const selectedDate = watch('date_of_sampling');

  useEffect(() => {
    if (open) {
      loadCategories();
      reset({
        date_of_sampling: new Date(),
        officer: currentUser?.username || ''
      });
    }
  }, [open, currentUser, reset]);

  const loadCategories = async () => {
    try {
      const data = await memoService.getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Failed to load categories:', error);
      toast({
        title: "Error",
        description: "Failed to load memo categories",
        variant: "destructive"
      });
    }
  };

  const onSubmit = async (data: FormData) => {
    if (!currentUser) {
      toast({
        title: "Error",
        description: "User authentication required",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Generate memo reference
      const memoRef = await memoService.generateMemoRef(data.plant, data.category);
      
      // Create memo
      await memoService.createMemo({
        memo_ref: memoRef,
        category: data.category,
        plant: data.plant,
        product_type: data.product_type,
        material_type: data.material_type,
        date_of_sampling: format(data.date_of_sampling, 'yyyy-MM-dd'),
        officer: data.officer,
        machine: data.machine,
        status: 'draft',
        created_by: currentUser.username
      });

      toast({
        title: "Success",
        description: `Memo ${memoRef} created successfully`
      });

      onMemoCreated();
      onOpenChange(false);
      reset();
    } catch (error) {
      console.error('Failed to create memo:', error);
      toast({
        title: "Error",
        description: "Failed to create memo",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const plants = [
    { id: 'phoenix', name: 'Phoenix' },
    { id: 'riche_terre', name: 'Riche Terre' },
    { id: 'central', name: 'Central Lab' },
    { id: 'port_louis', name: 'Port Louis' }
  ];

  const productTypes = [
    'Aggregates',
    'Concrete Blocks',
    'Pavers',
    'Kerbs',
    'Flagstones',
    'Ready Mix Concrete'
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Memo</DialogTitle>
          <DialogDescription>
            Create a new test request memo for laboratory processing
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="category">Category *</Label>
              <Select onValueChange={(value) => setValue('category', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.category && (
                <p className="text-sm text-destructive">Category is required</p>
              )}
            </div>

            <div>
              <Label htmlFor="plant">Plant *</Label>
              <Select onValueChange={(value) => setValue('plant', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select plant" />
                </SelectTrigger>
                <SelectContent>
                  {plants.map((plant) => (
                    <SelectItem key={plant.id} value={plant.id}>
                      {plant.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.plant && (
                <p className="text-sm text-destructive">Plant is required</p>
              )}
            </div>

            <div>
              <Label htmlFor="product_type">Product Type *</Label>
              <Select onValueChange={(value) => setValue('product_type', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  {productTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.product_type && (
                <p className="text-sm text-destructive">Product type is required</p>
              )}
            </div>

            <div>
              <Label htmlFor="material_type">Material Type</Label>
              <Input
                id="material_type"
                placeholder="e.g., 20mm, Sand, etc."
                {...register('material_type')}
              />
            </div>

            <div>
              <Label htmlFor="officer">Officer *</Label>
              <Input
                id="officer"
                placeholder="Officer name"
                {...register('officer', { required: 'Officer is required' })}
              />
              {errors.officer && (
                <p className="text-sm text-destructive">{errors.officer.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="machine">Machine</Label>
              <Input
                id="machine"
                placeholder="Machine name/number"
                {...register('machine')}
              />
            </div>
          </div>

          <div>
            <Label>Date of Sampling *</Label>
            <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !selectedDate && "text-muted-foreground"
                  )}
                >
                  <CalIcon className="mr-2 h-4 w-4" />
                  {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => {
                    setValue('date_of_sampling', date || new Date());
                    setCalendarOpen(false);
                  }}
                  disabled={(date) => date > new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Creating...' : 'Create Memo'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}