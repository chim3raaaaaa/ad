import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { MemoData } from "@/services/database/memoService";
import { format } from "date-fns";
import { FileText, Download, Calendar, User, MapPin, Package } from "lucide-react";

interface MemoDetailsPanelProps {
  memo: MemoData | null;
  onClose: () => void;
}

export function MemoDetailsPanel({ memo, onClose }: MemoDetailsPanelProps) {
  if (!memo) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Memo Details</CardTitle>
          <CardDescription>Select a memo to view its details</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">No memo selected</p>
        </CardContent>
      </Card>
    );
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'approved':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'rejected':
        return 'destructive';
      case 'draft':
        return 'outline';
      default:
        return 'outline';
    }
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {memo.memo_ref}
            </CardTitle>
            <CardDescription>Memo Details</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div className="flex items-center gap-2">
          <Badge variant={getStatusBadgeVariant(memo.status)}>
            {memo.status.charAt(0).toUpperCase() + memo.status.slice(1)}
          </Badge>
          <Badge variant="outline">{memo.category}</Badge>
        </div>

        <Separator />

        <div className="grid grid-cols-1 gap-4">
          <div className="flex items-center gap-3">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Plant</p>
              <p className="text-sm text-muted-foreground">{memo.plant}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Package className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Product Type</p>
              <p className="text-sm text-muted-foreground">{memo.product_type}</p>
            </div>
          </div>

          {memo.material_type && (
            <div className="flex items-center gap-3">
              <Package className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Material Type</p>
                <p className="text-sm text-muted-foreground">{memo.material_type}</p>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            <User className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Officer</p>
              <p className="text-sm text-muted-foreground">{memo.officer}</p>
            </div>
          </div>

          {memo.machine && (
            <div className="flex items-center gap-3">
              <Package className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Machine</p>
                <p className="text-sm text-muted-foreground">{memo.machine}</p>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Date of Sampling</p>
              <p className="text-sm text-muted-foreground">
                {format(new Date(memo.date_of_sampling), 'MMMM dd, yyyy')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <User className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Created By</p>
              <p className="text-sm text-muted-foreground">{memo.created_by}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Created</p>
              <p className="text-sm text-muted-foreground">
                {format(new Date(memo.created_at), 'MMMM dd, yyyy HH:mm')}
              </p>
            </div>
          </div>
        </div>

        {memo.extracted_data && (
          <>
            <Separator />
            <div>
              <p className="text-sm font-medium mb-2">Extracted Data</p>
              <div className="bg-muted p-3 rounded-md">
                <pre className="text-xs whitespace-pre-wrap">
                  {JSON.stringify(memo.extracted_data, null, 2)}
                </pre>
              </div>
            </div>
          </>
        )}

        {memo.attachments && memo.attachments.length > 0 && (
          <>
            <Separator />
            <div>
              <p className="text-sm font-medium mb-2">Attachments</p>
              <div className="space-y-2">
                {memo.attachments.map((attachment) => (
                  <div
                    key={attachment.id}
                    className="flex items-center justify-between p-2 border rounded-md"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span className="text-sm">{attachment.filename}</span>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}