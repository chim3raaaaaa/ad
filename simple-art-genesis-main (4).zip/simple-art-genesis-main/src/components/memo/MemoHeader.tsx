import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Upload, Download, Printer, Search, Filter } from "lucide-react";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";

interface MemoHeaderProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  selectedCategory: string;
  onCategoryChange: (value: string) => void;
  selectedStatus: string;
  onStatusChange: (value: string) => void;
  categories: Array<{ id: string; name: string }>;
  onCreateMemo: () => void;
  onImportMemo: () => void;
  onExportMemos: () => void;
  onPrintMemos: () => void;
  isFiltersVisible: boolean;
  onToggleFilters: () => void;
}

export function MemoHeader({
  searchTerm,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  selectedStatus,
  onStatusChange,
  categories,
  onCreateMemo,
  onImportMemo,
  onExportMemos,
  onPrintMemos,
  isFiltersVisible,
  onToggleFilters
}: MemoHeaderProps) {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold">Memo Management</h1>
          <Button
            variant="outline"
            size="sm"
            onClick={onToggleFilters}
            className="ml-2"
          >
            <Filter className="h-4 w-4" />
            Filters
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <PermissionWrapper permission="memo:create">
            <Button onClick={onCreateMemo} className="gap-2">
              <Plus className="h-4 w-4" />
              Create Memo
            </Button>
          </PermissionWrapper>
          
          <PermissionWrapper permission="memo:import">
            <Button variant="outline" onClick={onImportMemo} className="gap-2">
              <Upload className="h-4 w-4" />
              Import
            </Button>
          </PermissionWrapper>
          
          <PermissionWrapper permission="memo:export">
            <Button variant="outline" onClick={onExportMemos} className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </PermissionWrapper>
          
          <PermissionWrapper permission="memo:print">
            <Button variant="outline" onClick={onPrintMemos} className="gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
          </PermissionWrapper>
        </div>
      </div>

      {isFiltersVisible && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search memos..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={onCategoryChange}>
            <SelectTrigger>
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedStatus} onValueChange={onStatusChange}>
            <SelectTrigger>
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={() => {
            onSearchChange('');
            onCategoryChange('all');
            onStatusChange('all');
          }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
}