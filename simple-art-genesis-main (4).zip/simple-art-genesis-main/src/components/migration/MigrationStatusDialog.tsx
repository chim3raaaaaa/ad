// Migration Status Dialog Component
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertCircle, Loader2, Database } from 'lucide-react';
import { databaseMigration } from '@/lib/database/migration';

interface MigrationStatusDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MigrationStatusDialog({ open, onOpenChange }: MigrationStatusDialogProps) {
  const [migrationStatus, setMigrationStatus] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (open) {
      checkMigrationStatus();
    }
  }, [open]);

  const checkMigrationStatus = async () => {
    try {
      const status = await databaseMigration.checkMigrationStatus();
      setMigrationStatus(status);
    } catch (error) {
      console.error('Failed to check migration status:', error);
    }
  };

  const runMigrations = async () => {
    setIsRunning(true);
    setResults([]);
    setProgress(0);

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      const migrationResult = await databaseMigration.runMigrations();
      
      clearInterval(progressInterval);
      setProgress(100);
      setResults(migrationResult.results);
      
      // Refresh status after migration
      await checkMigrationStatus();
    } catch (error) {
      console.error('Migration failed:', error);
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Loader2 className="h-4 w-4 animate-spin" />;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Database Migration Status
          </DialogTitle>
          <DialogDescription>
            Check and run database migrations to upgrade your system
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {migrationStatus && (
            <div className="space-y-3">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {migrationStatus.needsMigration 
                    ? 'Migration required: Legacy data detected'
                    : 'System is up to date'
                  }
                </AlertDescription>
              </Alert>

              {migrationStatus.details && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Current Database</h4>
                    <div className="text-xs space-y-1">
                      <div>Users: {migrationStatus.details.unified?.users || 0}</div>
                      <div>Tests: {migrationStatus.details.unified?.tests || 0}</div>
                      <div>Memos: {migrationStatus.details.unified?.memos || 0}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Legacy Data</h4>
                    <div className="text-xs space-y-1">
                      <div>Local Memos: {migrationStatus.details.legacy?.localStorage?.memos || 0}</div>
                      <div>Aggregate Tests: {migrationStatus.details.legacy?.localStorage?.aggregateTests || 0}</div>
                      <div>Concrete Tests: {migrationStatus.details.legacy?.localStorage?.concreteTests || 0}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {isRunning && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Running migrations...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          )}

          {results.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Migration Results</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {results.map((result, index) => (
                  <div key={index} className="flex items-start gap-2 p-2 bg-muted/50 rounded-sm">
                    {getStatusIcon(result.status)}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{result.id}</div>
                      <div className="text-xs text-muted-foreground">{result.description}</div>
                      {result.error && (
                        <div className="text-xs text-red-500 mt-1">{result.error}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Close
            </Button>
            {migrationStatus?.needsMigration && (
              <Button 
                onClick={runMigrations} 
                disabled={isRunning}
                className="bg-primary hover:bg-primary/90"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Running...
                  </>
                ) : (
                  'Run Migrations'
                )}
              </Button>
            )}
            <Button variant="outline" onClick={checkMigrationStatus}>
              Refresh Status
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}