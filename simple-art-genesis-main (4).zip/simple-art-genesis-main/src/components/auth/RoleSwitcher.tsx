import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { Users, Shield, Settings, FlaskConical } from "lucide-react";

// Mock users for role testing - will be replaced with real user data
const mockUsers = [];

const getRoleIcon = (role: string) => {
  switch (role) {
    case 'admin':
      return <Shield className="h-4 w-4" />;
    case 'lab_manager':
      return <Settings className="h-4 w-4" />;
    case 'senior_technician':
    case 'technician':
      return <FlaskConical className="h-4 w-4" />;
    default:
      return <Users className="h-4 w-4" />;
  }
};

const getRoleColor = (role: string) => {
  switch (role) {
    case 'admin':
      return 'destructive';
    case 'lab_manager':
      return 'default';
    case 'senior_technician':
    case 'technician':
      return 'secondary';
    default:
      return 'outline';
  }
};

export function RoleSwitcher() {
  const { user } = useAuth();

  const handleRoleSwitch = (newUser: any) => {
    // For now, just log - in production this would be handled differently
    console.log(`Role switch requested: ${newUser.role} (${newUser.name})`);
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-lg">Role Switcher (Testing)</CardTitle>
        <p className="text-sm text-muted-foreground">
          Switch between different user roles to test access controls
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Current User:</span>
            {user && (
              <>
                 <Badge variant={getRoleColor(user.role)} className="flex items-center gap-1">
                   {getRoleIcon(user.role)}
                   {user.role.replace('_', ' ').toUpperCase()}
                 </Badge>
                 <span className="text-sm text-muted-foreground">
                   {user.name}
                 </span>
              </>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {mockUsers.map((mockUser: any) => (
              <Button
                key={mockUser.id}
                variant={user?.id === mockUser.id ? "default" : "outline"}
                size="sm"
                onClick={() => handleRoleSwitch(mockUser)}
                className="justify-start"
                disabled={user?.id === mockUser.id}
              >
                <div className="flex items-center gap-2">
                  {getRoleIcon(mockUser.role)}
                  <div className="text-left">
                    <div className="font-medium">{mockUser.name}</div>
                    <div className="text-xs opacity-70">
                      {mockUser.role.replace('_', ' ').toUpperCase()}
                    </div>
                  </div>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="text-xs text-muted-foreground mt-3 p-2 bg-muted rounded">
            <strong>Note:</strong> This role switcher is for testing purposes only. 
            In production, user roles would be determined by authentication and stored securely.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}