import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, LineChart, PieChart } from "lucide-react";

interface ChartRendererProps {
  chartType: 'bar' | 'line' | 'pie';
  chartName: string;
  data?: any;
  width?: number;
  height?: number;
}

export function ChartRenderer({ chartType, chartName, data, width = 300, height = 200 }: ChartRendererProps) {
  const renderChart = () => {
    // This is a placeholder for actual chart rendering
    // In a real implementation, you would use a library like Recharts, Chart.js, or D3.js
    
    switch (chartType) {
      case 'bar':
        return (
          <div className="flex items-center justify-center h-full bg-blue-50 border-2 border-dashed border-blue-200 rounded">
            <div className="text-center">
              <BarChart3 className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-blue-700">{chartName}</p>
              <p className="text-xs text-blue-500">Bar Chart</p>
            </div>
          </div>
        );
      case 'line':
        return (
          <div className="flex items-center justify-center h-full bg-green-50 border-2 border-dashed border-green-200 rounded">
            <div className="text-center">
              <LineChart className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-green-700">{chartName}</p>
              <p className="text-xs text-green-500">Line Chart</p>
            </div>
          </div>
        );
      case 'pie':
        return (
          <div className="flex items-center justify-center h-full bg-purple-50 border-2 border-dashed border-purple-200 rounded">
            <div className="text-center">
              <PieChart className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-purple-700">{chartName}</p>
              <p className="text-xs text-purple-500">Pie Chart</p>
            </div>
          </div>
        );
      default:
        return (
          <div className="flex items-center justify-center h-full bg-gray-50 border-2 border-dashed border-gray-200 rounded">
            <p className="text-gray-500">Unknown Chart Type</p>
          </div>
        );
    }
  };

  return (
    <div style={{ width, height }} className="chart-container">
      {renderChart()}
    </div>
  );
}

// Export chart rendering service for use in PDF generation
export const ChartRenderingService = {
  renderChartToCanvas: async (chartType: string, chartName: string, data?: any): Promise<HTMLCanvasElement> => {
    // Create a temporary canvas element for chart rendering
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 300;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('Failed to get canvas context');
    }

    // Simple chart rendering for PDF export
    ctx.fillStyle = '#f8f9fa';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw border
    ctx.strokeStyle = '#e9ecef';
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    
    // Draw chart placeholder
    ctx.fillStyle = '#6c757d';
    ctx.font = '16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(chartName, canvas.width / 2, canvas.height / 2 - 10);
    
    ctx.font = '12px Arial';
    ctx.fillText(`${chartType.charAt(0).toUpperCase() + chartType.slice(1)} Chart`, canvas.width / 2, canvas.height / 2 + 10);
    
    return canvas;
  }
};