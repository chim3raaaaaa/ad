import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Palette, Type, Layout, Monitor, Moon, Sun, Paintbrush2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface ThemeCustomization {
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  borderRadius: number;
  fontSize: number;
  fontFamily: string;
  darkMode: boolean;
  compactMode: boolean;
  animationsEnabled: boolean;
}

interface WidgetTheme {
  backgroundColor: string;
  borderColor: string;
  textColor: string;
  chartColors: string[];
  borderRadius: number;
  padding: number;
  shadow: boolean;
}

export function ThemeCustomizer() {
  const [activeTab, setActiveTab] = useState('global');
  const [globalTheme, setGlobalTheme] = useState<ThemeCustomization>({
    primaryColor: '#0ea5e9',
    accentColor: '#8b5cf6',
    backgroundColor: '#ffffff',
    textColor: '#0f172a',
    borderRadius: 8,
    fontSize: 14,
    fontFamily: 'system',
    darkMode: false,
    compactMode: false,
    animationsEnabled: true
  });

  const [widgetTheme, setWidgetTheme] = useState<WidgetTheme>({
    backgroundColor: '#ffffff',
    borderColor: '#e2e8f0',
    textColor: '#0f172a',
    chartColors: ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'],
    borderRadius: 8,
    padding: 16,
    shadow: true
  });

  const colorPresets = [
    { name: 'Ocean Blue', primary: '#0ea5e9', accent: '#06b6d4' },
    { name: 'Purple Haze', primary: '#8b5cf6', accent: '#a855f7' },
    { name: 'Forest Green', primary: '#10b981', accent: '#059669' },
    { name: 'Sunset Orange', primary: '#f59e0b', accent: '#d97706' },
    { name: 'Cherry Red', primary: '#ef4444', accent: '#dc2626' },
    { name: 'Slate Gray', primary: '#64748b', accent: '#475569' }
  ];

  const fontOptions = [
    { value: 'system', label: 'System Font' },
    { value: 'inter', label: 'Inter' },
    { value: 'roboto', label: 'Roboto' },
    { value: 'poppins', label: 'Poppins' },
    { value: 'source-sans', label: 'Source Sans Pro' }
  ];

  const applyGlobalTheme = () => {
    const root = document.documentElement;
    
    // Convert hex to HSL for CSS custom properties
    const hexToHsl = (hex: string) => {
      const r = parseInt(hex.slice(1, 3), 16) / 255;
      const g = parseInt(hex.slice(3, 5), 16) / 255;
      const b = parseInt(hex.slice(5, 7), 16) / 255;

      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      let h: number, s: number, l: number;

      l = (max + min) / 2;

      if (max === min) {
        h = s = 0;
      } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
          case g: h = (b - r) / d + 2; break;
          case b: h = (r - g) / d + 4; break;
          default: h = 0;
        }
        h /= 6;
      }

      return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
    };

    // Apply theme variables
    root.style.setProperty('--primary', hexToHsl(globalTheme.primaryColor));
    root.style.setProperty('--accent', hexToHsl(globalTheme.accentColor));
    root.style.setProperty('--background', hexToHsl(globalTheme.backgroundColor));
    root.style.setProperty('--foreground', hexToHsl(globalTheme.textColor));
    root.style.setProperty('--radius', `${globalTheme.borderRadius}px`);
    
    // Apply font settings
    root.style.setProperty('--font-size-base', `${globalTheme.fontSize}px`);
    
    // Apply dark mode
    if (globalTheme.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Save to localStorage
    localStorage.setItem('lims-global-theme', JSON.stringify(globalTheme));
    
    toast({
      title: 'Theme Applied',
      description: 'Global theme settings have been updated',
    });
  };

  const applyWidgetTheme = () => {
    // Create CSS for widget theming
    const widgetCSS = `
      .widget-themed {
        background-color: ${widgetTheme.backgroundColor};
        border-color: ${widgetTheme.borderColor};
        color: ${widgetTheme.textColor};
        border-radius: ${widgetTheme.borderRadius}px;
        padding: ${widgetTheme.padding}px;
        ${widgetTheme.shadow ? 'box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);' : ''}
      }
      
      .widget-themed .recharts-wrapper {
        --chart-1: ${widgetTheme.chartColors[0]};
        --chart-2: ${widgetTheme.chartColors[1]};
        --chart-3: ${widgetTheme.chartColors[2]};
        --chart-4: ${widgetTheme.chartColors[3]};
        --chart-5: ${widgetTheme.chartColors[4]};
      }
    `;

    // Remove existing widget theme
    const existingStyle = document.getElementById('widget-theme-style');
    if (existingStyle) {
      existingStyle.remove();
    }

    // Apply new widget theme
    const style = document.createElement('style');
    style.id = 'widget-theme-style';
    style.textContent = widgetCSS;
    document.head.appendChild(style);

    // Save to localStorage
    localStorage.setItem('lims-widget-theme', JSON.stringify(widgetTheme));
    
    toast({
      title: 'Widget Theme Applied',
      description: 'Widget styling has been updated',
    });
  };

  const resetToDefaults = () => {
    setGlobalTheme({
      primaryColor: '#0ea5e9',
      accentColor: '#8b5cf6',
      backgroundColor: '#ffffff',
      textColor: '#0f172a',
      borderRadius: 8,
      fontSize: 14,
      fontFamily: 'system',
      darkMode: false,
      compactMode: false,
      animationsEnabled: true
    });

    setWidgetTheme({
      backgroundColor: '#ffffff',
      borderColor: '#e2e8f0',
      textColor: '#0f172a',
      chartColors: ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'],
      borderRadius: 8,
      padding: 16,
      shadow: true
    });

    // Remove custom styles
    const existingStyle = document.getElementById('widget-theme-style');
    if (existingStyle) {
      existingStyle.remove();
    }

    // Reset CSS variables
    const root = document.documentElement;
    root.style.removeProperty('--primary');
    root.style.removeProperty('--accent');
    root.style.removeProperty('--background');
    root.style.removeProperty('--foreground');
    root.style.removeProperty('--radius');
    root.style.removeProperty('--font-size-base');
    
    document.documentElement.classList.remove('dark');
    
    // Clear localStorage
    localStorage.removeItem('lims-global-theme');
    localStorage.removeItem('lims-widget-theme');
    
    toast({
      title: 'Reset Complete',
      description: 'All theme settings have been reset to defaults',
    });
  };

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Paintbrush2 className="h-5 w-5" />
          Theme Customizer
        </CardTitle>
        <CardDescription>
          Customize the appearance of your dashboard and widgets
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="global" className="gap-2">
              <Layout className="h-4 w-4" />
              Global
            </TabsTrigger>
            <TabsTrigger value="widgets" className="gap-2">
              <Monitor className="h-4 w-4" />
              Widgets
            </TabsTrigger>
            <TabsTrigger value="typography" className="gap-2">
              <Type className="h-4 w-4" />
              Typography
            </TabsTrigger>
          </TabsList>

          <TabsContent value="global" className="space-y-6 mt-6">
            {/* Color Presets */}
            <div>
              <Label className="text-base font-semibold">Color Presets</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                {colorPresets.map((preset) => (
                  <Button
                    key={preset.name}
                    variant="outline"
                    onClick={() => setGlobalTheme(prev => ({
                      ...prev,
                      primaryColor: preset.primary,
                      accentColor: preset.accent
                    }))}
                    className="h-auto p-3 flex flex-col items-center gap-2"
                  >
                    <div className="flex gap-1">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: preset.primary }}
                      />
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: preset.accent }}
                      />
                    </div>
                    <span className="text-xs">{preset.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            {/* Custom Colors */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="primary-color">Primary Color</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="primary-color"
                    type="color"
                    value={globalTheme.primaryColor}
                    onChange={(e) => setGlobalTheme(prev => ({ ...prev, primaryColor: e.target.value }))}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={globalTheme.primaryColor}
                    onChange={(e) => setGlobalTheme(prev => ({ ...prev, primaryColor: e.target.value }))}
                    placeholder="#0ea5e9"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="accent-color">Accent Color</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="accent-color"
                    type="color"
                    value={globalTheme.accentColor}
                    onChange={(e) => setGlobalTheme(prev => ({ ...prev, accentColor: e.target.value }))}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={globalTheme.accentColor}
                    onChange={(e) => setGlobalTheme(prev => ({ ...prev, accentColor: e.target.value }))}
                    placeholder="#8b5cf6"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Settings */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Moon className="h-4 w-4" />
                  <Label>Dark Mode</Label>
                </div>
                <Switch
                  checked={globalTheme.darkMode}
                  onCheckedChange={(checked) => setGlobalTheme(prev => ({ ...prev, darkMode: checked }))}
                />
              </div>

              <div>
                <Label>Border Radius: {globalTheme.borderRadius}px</Label>
                <Slider
                  value={[globalTheme.borderRadius]}
                  onValueChange={([value]) => setGlobalTheme(prev => ({ ...prev, borderRadius: value }))}
                  max={20}
                  min={0}
                  step={1}
                  className="mt-2"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Enable Animations</Label>
                <Switch
                  checked={globalTheme.animationsEnabled}
                  onCheckedChange={(checked) => setGlobalTheme(prev => ({ ...prev, animationsEnabled: checked }))}
                />
              </div>
            </div>

            <Button onClick={applyGlobalTheme} className="w-full">
              Apply Global Theme
            </Button>
          </TabsContent>

          <TabsContent value="widgets" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Background Color</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    type="color"
                    value={widgetTheme.backgroundColor}
                    onChange={(e) => setWidgetTheme(prev => ({ ...prev, backgroundColor: e.target.value }))}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={widgetTheme.backgroundColor}
                    onChange={(e) => setWidgetTheme(prev => ({ ...prev, backgroundColor: e.target.value }))}
                  />
                </div>
              </div>

              <div>
                <Label>Border Color</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    type="color"
                    value={widgetTheme.borderColor}
                    onChange={(e) => setWidgetTheme(prev => ({ ...prev, borderColor: e.target.value }))}
                    className="w-16 h-10 p-1"
                  />
                  <Input
                    value={widgetTheme.borderColor}
                    onChange={(e) => setWidgetTheme(prev => ({ ...prev, borderColor: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            <div>
              <Label>Chart Colors</Label>
              <div className="grid grid-cols-5 gap-2 mt-2">
                {widgetTheme.chartColors.map((color, index) => (
                  <Input
                    key={index}
                    type="color"
                    value={color}
                    onChange={(e) => {
                      const newColors = [...widgetTheme.chartColors];
                      newColors[index] = e.target.value;
                      setWidgetTheme(prev => ({ ...prev, chartColors: newColors }));
                    }}
                    className="w-full h-10 p-1"
                  />
                ))}
              </div>
            </div>

            <div>
              <Label>Padding: {widgetTheme.padding}px</Label>
              <Slider
                value={[widgetTheme.padding]}
                onValueChange={([value]) => setWidgetTheme(prev => ({ ...prev, padding: value }))}
                max={32}
                min={8}
                step={2}
                className="mt-2"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label>Drop Shadow</Label>
              <Switch
                checked={widgetTheme.shadow}
                onCheckedChange={(checked) => setWidgetTheme(prev => ({ ...prev, shadow: checked }))}
              />
            </div>

            <Button onClick={applyWidgetTheme} className="w-full">
              Apply Widget Theme
            </Button>
          </TabsContent>

          <TabsContent value="typography" className="space-y-6 mt-6">
            <div>
              <Label>Font Family</Label>
              <Select 
                value={globalTheme.fontFamily} 
                onValueChange={(value) => setGlobalTheme(prev => ({ ...prev, fontFamily: value }))}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {fontOptions.map((font) => (
                    <SelectItem key={font.value} value={font.value}>
                      {font.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Base Font Size: {globalTheme.fontSize}px</Label>
              <Slider
                value={[globalTheme.fontSize]}
                onValueChange={([value]) => setGlobalTheme(prev => ({ ...prev, fontSize: value }))}
                max={18}
                min={12}
                step={1}
                className="mt-2"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label>Compact Mode</Label>
              <Switch
                checked={globalTheme.compactMode}
                onCheckedChange={(checked) => setGlobalTheme(prev => ({ ...prev, compactMode: checked }))}
              />
            </div>
          </TabsContent>
        </Tabs>

        <Separator className="my-6" />
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={resetToDefaults}>
            Reset to Defaults
          </Button>
          <div className="flex gap-2">
            <Button onClick={applyGlobalTheme}>Apply All Changes</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}