import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Palette, Download, Upload, Check, Sun, Moon, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { themePersistenceService, type CustomTheme, type ThemeColors } from '@/services/themes/themePersistenceService';

export function ThemeEditor() {
  const { toast } = useToast();
  const [themes, setThemes] = useState<CustomTheme[]>([]);
  const [activeTheme, setActiveTheme] = useState<CustomTheme | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<CustomTheme | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importJson, setImportJson] = useState('');

  const [newTheme, setNewTheme] = useState({
    name: '',
    description: '',
    isDark: false,
    colors: {} as ThemeColors
  });

  const defaultColors: ThemeColors = {
    primary: '222.2 84% 4.9%',
    'primary-foreground': '210 40% 98%',
    secondary: '210 40% 96%',
    'secondary-foreground': '222.2 84% 4.9%',
    accent: '210 40% 96%',
    'accent-foreground': '222.2 84% 4.9%',
    destructive: '0 84.2% 60.2%',
    'destructive-foreground': '210 40% 98%',
    muted: '210 40% 96%',
    'muted-foreground': '215.4 16.3% 46.9%',
    card: '0 0% 100%',
    'card-foreground': '222.2 84% 4.9%',
    popover: '0 0% 100%',
    'popover-foreground': '222.2 84% 4.9%',
    border: '214.3 31.8% 91.4%',
    input: '214.3 31.8% 91.4%',
    background: '0 0% 100%',
    foreground: '222.2 84% 4.9%',
    radius: '0.5rem'
  };

  useEffect(() => {
    initializeThemes();
  }, []);

  const initializeThemes = async () => {
    try {
      setIsLoading(true);
      await themePersistenceService.initializeThemesTable();
      await loadThemes();
      await loadActiveTheme();
    } catch (error) {
      console.error('Error initializing themes:', error);
      toast({
        title: "Error",
        description: "Failed to initialize theme system",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadThemes = async () => {
    try {
      const allThemes = await themePersistenceService.getAllThemes();
      setThemes(allThemes);
    } catch (error) {
      console.error('Error loading themes:', error);
    }
  };

  const loadActiveTheme = async () => {
    try {
      const active = await themePersistenceService.getActiveTheme();
      setActiveTheme(active);
    } catch (error) {
      console.error('Error loading active theme:', error);
    }
  };

  const activateTheme = async (themeId: string) => {
    try {
      await themePersistenceService.activateTheme(themeId);
      await loadActiveTheme();
      
      toast({
        title: "Success",
        description: "Theme activated successfully"
      });
    } catch (error) {
      console.error('Error activating theme:', error);
      toast({
        title: "Error",
        description: "Failed to activate theme",
        variant: "destructive"
      });
    }
  };

  const createTheme = async () => {
    try {
      if (!newTheme.name.trim()) {
        toast({
          title: "Validation Error",
          description: "Theme name is required",
          variant: "destructive"
        });
        return;
      }

      const themeToSave = {
        ...newTheme,
        colors: { ...defaultColors, ...newTheme.colors }
      };

      await themePersistenceService.saveTheme(themeToSave);
      await loadThemes();
      
      setShowCreateDialog(false);
      setNewTheme({
        name: '',
        description: '',
        isDark: false,
        colors: {} as ThemeColors
      });

      toast({
        title: "Success",
        description: "Theme created successfully"
      });
    } catch (error) {
      console.error('Error creating theme:', error);
      toast({
        title: "Error",
        description: "Failed to create theme",
        variant: "destructive"
      });
    }
  };

  const updateThemeColor = (colorKey: string, value: string, theme: CustomTheme) => {
    const updatedColors = { ...theme.colors, [colorKey]: value };
    themePersistenceService.updateTheme(theme.id, { colors: updatedColors });
    
    // Update local state
    setThemes(prev => prev.map(t => 
      t.id === theme.id ? { ...t, colors: updatedColors } : t
    ));
    
    // If this is the active theme, apply changes immediately
    if (activeTheme && activeTheme.id === theme.id) {
      themePersistenceService.applyTheme(theme.id);
    }
  };

  const exportTheme = async (themeId: string) => {
    try {
      const themeJson = await themePersistenceService.exportTheme(themeId);
      const blob = new Blob([themeJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `theme_${themeId}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Success",
        description: "Theme exported successfully"
      });
    } catch (error) {
      console.error('Error exporting theme:', error);
      toast({
        title: "Error",
        description: "Failed to export theme",
        variant: "destructive"
      });
    }
  };

  const importTheme = async () => {
    try {
      if (!importJson.trim()) {
        toast({
          title: "Validation Error",
          description: "Please paste theme JSON",
          variant: "destructive"
        });
        return;
      }

      await themePersistenceService.importTheme(importJson);
      await loadThemes();
      
      setShowImportDialog(false);
      setImportJson('');
      
      toast({
        title: "Success",
        description: "Theme imported successfully"
      });
    } catch (error) {
      console.error('Error importing theme:', error);
      toast({
        title: "Error",
        description: "Failed to import theme. Please check the JSON format.",
        variant: "destructive"
      });
    }
  };

  const deleteTheme = async (themeId: string) => {
    if (!confirm('Are you sure you want to delete this theme?')) return;
    
    try {
      await themePersistenceService.deleteTheme(themeId);
      await loadThemes();
      await loadActiveTheme();
      
      toast({
        title: "Success",
        description: "Theme deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting theme:', error);
      toast({
        title: "Error",
        description: "Failed to delete theme",
        variant: "destructive"
      });
    }
  };

  const renderColorInput = (colorKey: string, label: string, theme: CustomTheme) => {
    const value = theme.colors[colorKey as keyof ThemeColors] || '';
    
    return (
      <div key={colorKey} className="space-y-2">
        <Label className="text-xs">{label}</Label>
        <div className="flex gap-2">
          <Input
            value={value}
            onChange={(e) => updateThemeColor(colorKey, e.target.value, theme)}
            placeholder="HSL values (e.g., 222.2 84% 4.9%)"
            className="flex-1 text-xs"
          />
          <div 
            className="w-8 h-8 rounded border"
            style={{ backgroundColor: `hsl(${value})` }}
          />
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading themes...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Theme Editor</h3>
          <p className="text-sm text-muted-foreground">Customize and manage application themes</p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Theme</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Label>Theme JSON</Label>
                <Textarea
                  value={importJson}
                  onChange={(e) => setImportJson(e.target.value)}
                  placeholder="Paste theme JSON here..."
                  rows={10}
                  className="font-mono text-sm"
                />
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowImportDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={importTheme}>
                    Import
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Palette className="w-4 h-4 mr-2" />
                New Theme
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Theme</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Theme Name</Label>
                  <Input
                    value={newTheme.name}
                    onChange={(e) => setNewTheme(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter theme name"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={newTheme.description}
                    onChange={(e) => setNewTheme(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Theme description"
                    rows={2}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={newTheme.isDark}
                    onCheckedChange={(checked) => setNewTheme(prev => ({ ...prev, isDark: checked }))}
                  />
                  <Label>Dark Theme</Label>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createTheme}>
                    Create
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="themes" className="space-y-4">
        <TabsList>
          <TabsTrigger value="themes">All Themes ({themes.length})</TabsTrigger>
          {selectedTheme && (
            <TabsTrigger value="editor">Edit: {selectedTheme.name}</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="themes">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {themes.map(theme => (
              <Card key={theme.id} className="relative">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{theme.name}</CardTitle>
                    <div className="flex items-center gap-2">
                      {theme.isDark ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                      {activeTheme?.id === theme.id && (
                        <Badge variant="default">
                          <Check className="w-3 h-3 mr-1" />
                          Active
                        </Badge>
                      )}
                    </div>
                  </div>
                  {theme.description && (
                    <p className="text-sm text-muted-foreground">{theme.description}</p>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {/* Theme Preview */}
                    <div className="grid grid-cols-6 gap-1 mb-3">
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.primary})` }}
                        title="Primary"
                      />
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.secondary})` }}
                        title="Secondary"
                      />
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.accent})` }}
                        title="Accent"
                      />
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.background})` }}
                        title="Background"
                      />
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.card})` }}
                        title="Card"
                      />
                      <div 
                        className="h-6 rounded"
                        style={{ backgroundColor: `hsl(${theme.colors.destructive})` }}
                        title="Destructive"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      {activeTheme?.id !== theme.id && (
                        <Button 
                          size="sm" 
                          onClick={() => activateTheme(theme.id)}
                          className="flex-1"
                        >
                          Activate
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setSelectedTheme(theme)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => exportTheme(theme.id)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {selectedTheme && (
          <TabsContent value="editor">
            <Card>
              <CardHeader>
                <CardTitle>Editing: {selectedTheme.name}</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Customize theme colors using HSL values. Changes are applied instantly.
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(selectedTheme.colors).map(([key, value]) => (
                    renderColorInput(key, key.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()), selectedTheme)
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}