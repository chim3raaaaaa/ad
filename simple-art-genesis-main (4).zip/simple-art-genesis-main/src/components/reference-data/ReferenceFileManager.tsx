import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import {
  FileText,
  Upload,
  Download,
  Eye,
  Trash2,
  Plus,
  AlertTriangle,
  CheckCircle,
  FileImage,
  FileSpreadsheet
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ReferenceFile {
  id: string;
  name: string;
  type: 'pdf' | 'image' | 'spreadsheet' | 'document';
  category: string;
  description?: string;
  file_path: string;
  file_size: number;
  uploaded_by: string;
  upload_date: string;
  last_accessed?: string;
  access_count: number;
  tags: string[];
  status: 'active' | 'archived';
}

const FILE_CATEGORIES = [
  'Standards',
  'Specifications',
  'Procedures',
  'Calibration Certificates',
  'Reference Images',
  'Templates',
  'Guidelines',
  'Safety Documents',
  'Technical Drawings',
  'Other'
];

const FILE_TYPE_ICONS = {
  pdf: FileText,
  image: FileImage,
  spreadsheet: FileSpreadsheet,
  document: FileText
};

export const ReferenceFileManager: React.FC = () => {
  const [files, setFiles] = useState<ReferenceFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<ReferenceFile | null>(null);
  const [uploadData, setUploadData] = useState({
    name: '',
    category: '',
    description: '',
    tags: '',
    file: null as File | null
  });
  const { toast } = useToast();

  useEffect(() => {
    loadFiles();
  }, []);

  const loadFiles = async () => {
    setLoading(true);
    try {
      // Simulated file data - replace with actual API call
      const mockFiles: ReferenceFile[] = [
        {
          id: '1',
          name: 'BS 882 - Aggregate Standards',
          type: 'pdf',
          category: 'Standards',
          description: 'British Standard for aggregates from natural sources',
          file_path: '/files/bs882.pdf',
          file_size: 2048000,
          uploaded_by: 'Admin',
          upload_date: '2024-01-15',
          access_count: 45,
          tags: ['BS', 'aggregates', 'standards'],
          status: 'active'
        },
        {
          id: '2',
          name: 'Cube Test Procedure',
          type: 'pdf',
          category: 'Procedures',
          description: 'Standard procedure for concrete cube testing',
          file_path: '/files/cube-test-procedure.pdf',
          file_size: 1024000,
          uploaded_by: 'Lab Manager',
          upload_date: '2024-01-20',
          access_count: 23,
          tags: ['cube', 'procedure', 'concrete'],
          status: 'active'
        },
        {
          id: '3',
          name: 'Calibration Certificate - Balance',
          type: 'pdf',
          category: 'Calibration Certificates',
          description: 'Annual calibration certificate for precision balance',
          file_path: '/files/balance-cal-2024.pdf',
          file_size: 512000,
          uploaded_by: 'QC Officer',
          upload_date: '2024-02-01',
          access_count: 12,
          tags: ['calibration', 'balance', '2024'],
          status: 'active'
        }
      ];
      setFiles(mockFiles);
    } catch (error) {
      console.error('Failed to load files:', error);
      toast({
        title: "Load Failed",
        description: "Failed to load reference files",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         file.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         file.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || file.category === selectedCategory;
    return matchesSearch && matchesCategory && file.status === 'active';
  });

  const handleUpload = async () => {
    if (!uploadData.file || !uploadData.name || !uploadData.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and select a file",
        variant: "destructive"
      });
      return;
    }

    try {
      // Simulate file upload
      const newFile: ReferenceFile = {
        id: `file_${Date.now()}`,
        name: uploadData.name,
        type: getFileType(uploadData.file.type),
        category: uploadData.category,
        description: uploadData.description,
        file_path: `/files/${uploadData.file.name}`,
        file_size: uploadData.file.size,
        uploaded_by: 'Current User',
        upload_date: new Date().toISOString().split('T')[0],
        access_count: 0,
        tags: uploadData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        status: 'active'
      };

      setFiles(prev => [...prev, newFile]);
      
      toast({
        title: "Upload Successful",
        description: `${uploadData.name} has been uploaded successfully`
      });

      setIsUploadDialogOpen(false);
      setUploadData({
        name: '',
        category: '',
        description: '',
        tags: '',
        file: null
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirm) return;

    try {
      setFiles(prev => prev.filter(f => f.id !== deleteConfirm.id));
      
      toast({
        title: "File Deleted",
        description: `${deleteConfirm.name} has been deleted successfully`
      });

      setIsDeleteDialogOpen(false);
      setDeleteConfirm(null);
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleView = (file: ReferenceFile) => {
    // Simulate file viewing and increment access count
    setFiles(prev => prev.map(f => 
      f.id === file.id 
        ? { ...f, access_count: f.access_count + 1, last_accessed: new Date().toISOString() }
        : f
    ));
    
    // Open file in new tab/window (simulation)
    window.open(file.file_path, '_blank');
  };

  const handleDownload = (file: ReferenceFile) => {
    // Simulate file download
    const link = document.createElement('a');
    link.href = file.file_path;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download Started",
      description: `Downloading ${file.name}`
    });
  };

  const getFileType = (mimeType: string): ReferenceFile['type'] => {
    if (mimeType.includes('pdf')) return 'pdf';
    if (mimeType.includes('image')) return 'image';
    if (mimeType.includes('spreadsheet') || mimeType.includes('excel') || mimeType.includes('csv')) return 'spreadsheet';
    return 'document';
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return <div className="text-center p-8">Loading reference files...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Reference File Manager
          </CardTitle>
          <CardDescription>
            Manage reference documents, standards, and supporting files for laboratory operations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search and Filter Controls */}
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search files by name, description, or tags..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {FILE_CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={() => setIsUploadDialogOpen(true)}>
              <Upload className="h-4 w-4 mr-2" />
              Upload File
            </Button>
          </div>

          {/* Statistics */}
          <div className="flex items-center gap-4">
            <Badge variant="secondary">{filteredFiles.length} files</Badge>
            <Badge variant="outline">
              {FILE_CATEGORIES.length} categories
            </Badge>
            <Badge variant="outline">
              Total: {formatFileSize(files.reduce((sum, f) => sum + f.file_size, 0))}
            </Badge>
          </div>

          {/* Files Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40px]">Type</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Uploaded</TableHead>
                  <TableHead>Access Count</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="w-[120px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFiles.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      No reference files found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFiles.map((file) => {
                    const IconComponent = FILE_TYPE_ICONS[file.type];
                    return (
                      <TableRow key={file.id}>
                        <TableCell>
                          <IconComponent className="h-4 w-4 text-muted-foreground" />
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{file.name}</div>
                            {file.description && (
                              <div className="text-sm text-muted-foreground truncate max-w-[200px]">
                                {file.description}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{file.category}</Badge>
                        </TableCell>
                        <TableCell>{formatFileSize(file.file_size)}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{file.upload_date}</div>
                            <div className="text-muted-foreground">{file.uploaded_by}</div>
                          </div>
                        </TableCell>
                        <TableCell>{file.access_count}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {file.tags.slice(0, 2).map(tag => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                            {file.tags.length > 2 && (
                              <Badge variant="secondary" className="text-xs">
                                +{file.tags.length - 2}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleView(file)}
                              title="View file"
                            >
                              <Eye className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDownload(file)}
                              title="Download file"
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setDeleteConfirm(file);
                                setIsDeleteDialogOpen(true);
                              }}
                              title="Delete file"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Upload Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Reference File</DialogTitle>
            <DialogDescription>
              Upload a new reference document or supporting file
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="file">File *</Label>
              <Input
                id="file"
                type="file"
                onChange={(e) => setUploadData(prev => ({ 
                  ...prev, 
                  file: e.target.files?.[0] || null 
                }))}
                accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.jpg,.jpeg,.png,.gif"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={uploadData.name}
                onChange={(e) => setUploadData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter file name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select 
                value={uploadData.category} 
                onValueChange={(value) => setUploadData(prev => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {FILE_CATEGORIES.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={uploadData.description}
                onChange={(e) => setUploadData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter file description"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tags">Tags</Label>
              <Input
                id="tags"
                value={uploadData.tags}
                onChange={(e) => setUploadData(prev => ({ ...prev, tags: e.target.value }))}
                placeholder="Enter tags separated by commas"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpload}>
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              This will permanently delete the file "{deleteConfirm?.name}". This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Warning:</strong> Deleting this file may affect laboratory procedures that reference it.
            </AlertDescription>
          </Alert>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete File
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};