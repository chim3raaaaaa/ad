import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
// import { DatePicker } from '@/components/ui/date-picker';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Search, 
  Filter, 
  X, 
  Save, 
  Bookmark, 
  Calendar,
  MoreHorizontal 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SearchFilter {
  field: string;
  operator: 'equals' | 'contains' | 'starts_with' | 'ends_with' | 'greater_than' | 'less_than' | 'between' | 'in';
  value: string | string[] | { from: string; to: string };
  label: string;
}

interface SavedSearch {
  id: string;
  name: string;
  filters: SearchFilter[];
  createdAt: string;
}

interface AdvancedSearchProps {
  availableFields: Array<{
    key: string;
    label: string;
    type: 'text' | 'number' | 'date' | 'select';
    options?: string[];
  }>;
  onSearch: (filters: SearchFilter[]) => void;
  onReset: () => void;
}

export const AdvancedSearch: React.FC<AdvancedSearchProps> = ({
  availableFields,
  onSearch,
  onReset
}) => {
  const [filters, setFilters] = useState<SearchFilter[]>([]);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [saveSearchName, setSaveSearchName] = useState('');
  const [isSearchDialogOpen, setIsSearchDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadSavedSearches();
  }, []);

  const loadSavedSearches = () => {
    // Mock saved searches - in production, load from localStorage or API
    const mockSavedSearches: SavedSearch[] = [
      {
        id: '1',
        name: 'Active Products',
        filters: [
          { field: 'status', operator: 'equals', value: 'active', label: 'Status equals active' }
        ],
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Recent Items',
        filters: [
          { 
            field: 'created_at', 
            operator: 'greater_than', 
            value: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], 
            label: 'Created in last 7 days' 
          }
        ],
        createdAt: new Date().toISOString()
      }
    ];
    setSavedSearches(mockSavedSearches);
  };

  const addFilter = () => {
    if (availableFields.length === 0) return;
    
    const newFilter: SearchFilter = {
      field: availableFields[0].key,
      operator: 'equals',
      value: '',
      label: ''
    };
    setFilters([...filters, newFilter]);
  };

  const updateFilter = (index: number, updates: Partial<SearchFilter>) => {
    const updatedFilters = filters.map((filter, i) => 
      i === index ? { ...filter, ...updates } : filter
    );
    setFilters(updatedFilters);
  };

  const removeFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  const generateFilterLabel = (filter: SearchFilter) => {
    const field = availableFields.find(f => f.key === filter.field);
    const fieldLabel = field?.label || filter.field;
    
    switch (filter.operator) {
      case 'equals':
        return `${fieldLabel} equals "${filter.value}"`;
      case 'contains':
        return `${fieldLabel} contains "${filter.value}"`;
      case 'starts_with':
        return `${fieldLabel} starts with "${filter.value}"`;
      case 'ends_with':
        return `${fieldLabel} ends with "${filter.value}"`;
      case 'greater_than':
        return `${fieldLabel} > ${filter.value}`;
      case 'less_than':
        return `${fieldLabel} < ${filter.value}`;
      case 'between':
        const betweenValue = filter.value as { from: string; to: string };
        return `${fieldLabel} between ${betweenValue.from} and ${betweenValue.to}`;
      case 'in':
        const inValues = Array.isArray(filter.value) ? filter.value : [filter.value];
        return `${fieldLabel} in [${inValues.join(', ')}]`;
      default:
        return `${fieldLabel} ${filter.operator} ${filter.value}`;
    }
  };

  const handleSearch = () => {
    const validFilters = filters.filter(f => f.value !== '' && f.value !== null);
    const filtersWithLabels = validFilters.map(filter => ({
      ...filter,
      label: generateFilterLabel(filter)
    }));
    
    onSearch(filtersWithLabels);
    setIsSearchDialogOpen(false);
  };

  const handleReset = () => {
    setFilters([]);
    onReset();
    setIsSearchDialogOpen(false);
  };

  const saveSearch = () => {
    if (!saveSearchName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a name for the search",
        variant: "destructive"
      });
      return;
    }

    const newSavedSearch: SavedSearch = {
      id: Date.now().toString(),
      name: saveSearchName,
      filters: filters.map(filter => ({
        ...filter,
        label: generateFilterLabel(filter)
      })),
      createdAt: new Date().toISOString()
    };

    setSavedSearches([...savedSearches, newSavedSearch]);
    setSaveSearchName('');
    
    toast({
      title: "Search Saved",
      description: `Search "${newSavedSearch.name}" has been saved`
    });

    // In production, save to localStorage or API
    localStorage.setItem('savedSearches', JSON.stringify([...savedSearches, newSavedSearch]));
  };

  const loadSavedSearch = (savedSearch: SavedSearch) => {
    setFilters(savedSearch.filters);
    onSearch(savedSearch.filters);
    setIsSearchDialogOpen(false);
  };

  const renderFilterValue = (filter: SearchFilter, index: number) => {
    const field = availableFields.find(f => f.key === filter.field);
    
    if (filter.operator === 'between') {
      const betweenValue = filter.value as { from: string; to: string } || { from: '', to: '' };
      return (
        <div className="flex gap-2 items-center">
          <Input
            placeholder="From"
            value={betweenValue.from}
            onChange={(e) => updateFilter(index, { 
              value: { ...betweenValue, from: e.target.value } 
            })}
            className="flex-1"
          />
          <span className="text-muted-foreground">to</span>
          <Input
            placeholder="To"
            value={betweenValue.to}
            onChange={(e) => updateFilter(index, { 
              value: { ...betweenValue, to: e.target.value } 
            })}
            className="flex-1"
          />
        </div>
      );
    }

    if (field?.type === 'select' && field.options) {
      return (
        <Select 
          value={filter.value as string} 
          onValueChange={(value) => updateFilter(index, { value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select value" />
          </SelectTrigger>
          <SelectContent>
            {field.options.map(option => (
              <SelectItem key={option} value={option}>{option}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    if (field?.type === 'date') {
      return (
        <Input
          type="date"
          value={filter.value as string || ''}
          onChange={(e) => updateFilter(index, { value: e.target.value })}
        />
      );
    }

    return (
      <Input
        placeholder="Enter value"
        value={filter.value as string}
        onChange={(e) => updateFilter(index, { value: e.target.value })}
        type={field?.type === 'number' ? 'number' : 'text'}
      />
    );
  };

  const getOperatorOptions = (fieldType: string) => {
    const baseOptions = [
      { value: 'equals', label: 'Equals' },
      { value: 'contains', label: 'Contains' }
    ];

    if (fieldType === 'text') {
      return [
        ...baseOptions,
        { value: 'starts_with', label: 'Starts with' },
        { value: 'ends_with', label: 'Ends with' }
      ];
    }

    if (fieldType === 'number' || fieldType === 'date') {
      return [
        ...baseOptions,
        { value: 'greater_than', label: 'Greater than' },
        { value: 'less_than', label: 'Less than' },
        { value: 'between', label: 'Between' }
      ];
    }

    return baseOptions;
  };

  return (
    <div className="space-y-4">
      {/* Search Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Dialog open={isSearchDialogOpen} onOpenChange={setIsSearchDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Advanced Search
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Advanced Search & Filters
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Saved Searches */}
                <div>
                  <Label className="text-base font-medium">Saved Searches</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {savedSearches.map(search => (
                      <Button
                        key={search.id}
                        variant="outline"
                        size="sm"
                        onClick={() => loadSavedSearch(search)}
                        className="gap-2"
                      >
                        <Bookmark className="h-3 w-3" />
                        {search.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Filter Builder */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <Label className="text-base font-medium">Search Filters</Label>
                    <Button onClick={addFilter} size="sm" variant="outline">
                      Add Filter
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {filters.map((filter, index) => (
                      <Card key={index} className="p-4">
                        <div className="grid grid-cols-12 gap-4 items-end">
                          <div className="col-span-3">
                            <Label>Field</Label>
                            <Select 
                              value={filter.field} 
                              onValueChange={(value) => updateFilter(index, { field: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select field" />
                              </SelectTrigger>
                              <SelectContent>
                                {availableFields.map(field => (
                                  <SelectItem key={field.key} value={field.key}>
                                    {field.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="col-span-2">
                            <Label>Operator</Label>
                            <Select 
                              value={filter.operator} 
                              onValueChange={(value: any) => updateFilter(index, { operator: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Operator" />
                              </SelectTrigger>
                              <SelectContent>
                                {getOperatorOptions(
                                  availableFields.find(f => f.key === filter.field)?.type || 'text'
                                ).map(option => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="col-span-6">
                            <Label>Value</Label>
                            {renderFilterValue(filter, index)}
                          </div>
                          
                          <div className="col-span-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFilter(index)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Save Search */}
                {filters.length > 0 && (
                  <div className="border-t pt-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Save this search as..."
                        value={saveSearchName}
                        onChange={(e) => setSaveSearchName(e.target.value)}
                        className="max-w-xs"
                      />
                      <Button onClick={saveSearch} variant="outline" size="sm">
                        <Save className="h-4 w-4 mr-2" />
                        Save Search
                      </Button>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex justify-end gap-2 border-t pt-4">
                  <Button variant="outline" onClick={handleReset}>
                    Reset
                  </Button>
                  <Button onClick={handleSearch}>
                    Apply Filters
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Active Filters Display */}
      {filters.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {filters.map((filter, index) => (
            <Badge key={index} variant="secondary" className="gap-1">
              {generateFilterLabel(filter)}
              <button
                onClick={() => removeFilter(index)}
                className="ml-1 hover:bg-destructive hover:text-destructive-foreground rounded-full"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
          <Button variant="ghost" size="sm" onClick={handleReset}>
            Clear all
          </Button>
        </div>
      )}
    </div>
  );
};