import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DatasetDefinition } from '@/services/sync/syncTypes';

interface CSVImportDialogProps {
  open: boolean;
  onClose: () => void;
  datasets: DatasetDefinition[];
  onImportComplete: () => void;
}

export const CSVImportDialog: React.FC<CSVImportDialogProps> = ({
  open, onClose, datasets, onImportComplete
}) => {
  const [selectedDataset, setSelectedDataset] = useState('');
  const [file, setFile] = useState<File | null>(null);

  const handleImport = async () => {
    if (!file || !selectedDataset) return;
    // Import logic would go here
    onImportComplete();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Import CSV</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label>Dataset:</label>
            <select 
              value={selectedDataset} 
              onChange={(e) => setSelectedDataset(e.target.value)}
              className="w-full p-2 border rounded"
            >
              <option value="">Select dataset</option>
              {datasets.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label>CSV File:</label>
            <Input 
              type="file" 
              accept=".csv"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
          </div>
          <Button onClick={handleImport} disabled={!file || !selectedDataset}>
            Import
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};