import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { 
  Upload, 
  FileSpreadsheet, 
  CheckCircle, 
  XCircle, 
  Eye, 
  AlertTriangle,
  Download,
  RefreshCw 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { CustomReferenceType } from './CustomReferenceTypeManager';

interface CSVPreviewData {
  headers: string[];
  rows: string[][];
  totalRows: number;
}

interface UploadResult {
  success: boolean;
  message: string;
  rowsImported?: number;
  errors?: string[];
}

interface EnhancedCSVUploadProps {
  customTypes: CustomReferenceType[];
  onUploadComplete: () => void;
}

export function EnhancedCSVUpload({ customTypes, onUploadComplete }: EnhancedCSVUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedType, setSelectedType] = useState<string>('');
  const [csvPreview, setCsvPreview] = useState<CSVPreviewData | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [headerMapping, setHeaderMapping] = useState<Record<string, string>>({});
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Include built-in reference types
  const builtInTypes = [
    { id: 'product_categories', name: 'Product Categories' },
    { id: 'products', name: 'Products' },
    { id: 'grades', name: 'Grades' },
    { id: 'machines', name: 'Machines' },
    { id: 'mould_references', name: 'Mould References' },
    { id: 'plants', name: 'Plants' },
    { id: 'officers', name: 'Officers' },
    { id: 'aggregates', name: 'Aggregates' },
    { id: 'admixtures', name: 'Admixtures' },
    { id: 'free_water', name: 'Free Water' },
    { id: 'cement_types', name: 'Cement Types' },
    { id: 'vibrator_status', name: 'Vibrator Status' },
    { id: 'conformity_options', name: 'Conformity Options' },
    { id: 'test_types', name: 'Test Types' },
    { id: 'climatic_conditions', name: 'Climatic Conditions' },
    { id: 'sampling_places', name: 'Sampling Places' },
    { id: 'sampled_by', name: 'Sampled By' }
  ];

  const allTypes = [
    ...builtInTypes,
    ...customTypes.map(type => ({ id: type.id, name: type.name }))
  ];

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleFileSelect = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please select a CSV file",
        variant: "destructive"
      });
      return;
    }

    setSelectedFile(file);
    setUploadResult(null);

    try {
      const content = await readFileContent(file);
      const preview = parseCSVPreview(content);
      setCsvPreview(preview);
      
      toast({
        title: "File Loaded",
        description: `CSV file loaded with ${preview.totalRows} rows`
      });
    } catch (error) {
      console.error('Failed to read file:', error);
      toast({
        title: "File Error",
        description: "Failed to read the CSV file",
        variant: "destructive"
      });
    }
  };

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => resolve(event.target?.result as string);
      reader.onerror = (error) => reject(error);
      reader.readAsText(file);
    });
  };

  const parseCSVPreview = (content: string): CSVPreviewData => {
    const lines = content.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const rows = lines.slice(1, 6).map(line => 
      line.split(',').map(cell => cell.trim().replace(/"/g, ''))
    );
    
    return {
      headers,
      rows,
      totalRows: lines.length - 1
    };
  };

  const validateCSVData = (type: CustomReferenceType | null): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];

    if (!csvPreview) {
      errors.push('No CSV data to validate');
      return { isValid: false, errors };
    }

    if (!selectedType) {
      errors.push('Please select a reference data type');
      return { isValid: false, errors };
    }

    if (type) {
      // Validate custom type fields
      const requiredFields = type.fields.filter(f => f.required).map(f => f.name);
      const missingFields = requiredFields.filter(field => 
        !csvPreview.headers.includes(field) && !headerMapping[field]
      );
      
      if (missingFields.length > 0) {
        errors.push(`Missing required fields: ${missingFields.join(', ')}`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  };

  const processUpload = async () => {
    if (!selectedFile || !csvPreview || !selectedType) {
      toast({
        title: "Validation Error",
        description: "Please select a file and reference type",
        variant: "destructive"
      });
      return;
    }

    const customType = customTypes.find(t => t.id === selectedType);
    const validation = validateCSVData(customType);
    
    if (!validation.isValid) {
      setUploadResult({
        success: false,
        message: 'Validation failed',
        errors: validation.errors
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const content = await readFileContent(selectedFile);
      setUploadProgress(30);

      // Process the CSV upload
      const result = await uploadCSVData(selectedType, content, customType);
      setUploadProgress(80);

      setUploadResult(result);
      setUploadProgress(100);

      if (result.success) {
        toast({
          title: "Upload Successful",
          description: `Successfully imported ${result.rowsImported} rows`
        });
        onUploadComplete();
        resetForm();
      } else {
        toast({
          title: "Upload Failed",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Upload failed:', error);
      setUploadResult({
        success: false,
        message: `Upload failed: ${error}`,
        errors: [String(error)]
      });
      toast({
        title: "Upload Error",
        description: "An error occurred during upload",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const uploadCSVData = async (
    typeId: string, 
    content: string, 
    customType?: CustomReferenceType
  ): Promise<UploadResult> => {
    const lines = content.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const dataRows = lines.slice(1);

    try {
      if (window.electronAPI) {
        // SQLite implementation
        let tableName = typeId;
        
        if (customType) {
          tableName = customType.tableName;
        }

        // Clear existing data
        await window.electronAPI.executeQuery(`DELETE FROM ${tableName}`);

        // Insert new data
        let insertedRows = 0;
        for (const row of dataRows) {
          if (row.trim()) {
            const values = row.split(',').map(v => v.trim().replace(/"/g, ''));
            const placeholders = values.map(() => '?').join(', ');
            const columns = headers.join(', ');
            
            await window.electronAPI.executeQuery(
              `INSERT INTO ${tableName} (${columns}) VALUES (${placeholders})`,
              values
            );
            insertedRows++;
          }
        }

        return {
          success: true,
          message: 'Data imported successfully',
          rowsImported: insertedRows
        };
      } else {
        // Browser localStorage fallback
        const data = dataRows.map(row => {
          const values = row.split(',').map(v => v.trim().replace(/"/g, ''));
          const obj: Record<string, string> = {};
          headers.forEach((header, index) => {
            obj[header] = values[index] || '';
          });
          obj.id = `${typeId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          return obj;
        });

        localStorage.setItem(`ref_${typeId}`, JSON.stringify(data));
        
        return {
          success: true,
          message: 'Data imported successfully',
          rowsImported: data.length
        };
      }
    } catch (error) {
      console.error('Database error:', error);
      return {
        success: false,
        message: `Database error: ${error}`,
        errors: [String(error)]
      };
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setSelectedType('');
    setCsvPreview(null);
    setUploadResult(null);
    setHeaderMapping({});
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const downloadTemplate = () => {
    const customType = customTypes.find(t => t.id === selectedType);
    if (!customType) return;

    const headers = customType.fields.map(f => f.name).join(',');
    const exampleRow = customType.fields.map(f => {
      switch (f.type) {
        case 'number': return '123';
        case 'date': return '2024-01-01';
        case 'boolean': return 'true';
        case 'select': return f.options?.[0] || 'option1';
        default: return 'example';
      }
    }).join(',');
    
    const csvContent = `${headers}\n${exampleRow}`;
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${customType.name.toLowerCase().replace(/\s+/g, '_')}_template.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* File Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Enhanced CSV Upload
          </CardTitle>
          <CardDescription>
            Upload CSV data for any reference type. Select the type first, then upload your CSV file.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Reference Type Selection */}
          <div className="space-y-2">
            <Label>Reference Data Type *</Label>
            <div className="flex gap-2">
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select reference data type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="select-type" disabled>-- Select Type --</SelectItem>
                  {allTypes.map(type => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedType && customTypes.find(t => t.id === selectedType) && (
                <Button variant="outline" onClick={downloadTemplate}>
                  <Download className="h-4 w-4 mr-2" />
                  Template
                </Button>
              )}
            </div>
          </div>

          {/* Drag & Drop Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragOver 
                ? 'border-primary bg-primary/5' 
                : 'border-muted-foreground/25 hover:border-muted-foreground/50'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <FileSpreadsheet className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <div className="space-y-2">
              <p className="text-lg font-medium">Drop CSV files here or click to browse</p>
              <p className="text-sm text-muted-foreground">
                Supports all reference data types including custom types
              </p>
            </div>
            <Input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileInputChange}
              className="hidden"
            />
            <Button 
              variant="default"
              className="mt-4 bg-primary hover:bg-primary/90"
              onClick={() => fileInputRef.current?.click()}
              disabled={!selectedType}
            >
              <Upload className="h-4 w-4 mr-2" />
              Browse CSV Files
            </Button>
          </div>

          {/* Selected File Info */}
          {selectedFile && (
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileSpreadsheet className="h-5 w-5" />
                    <div>
                      <p className="font-medium">{selectedFile.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(selectedFile.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={resetForm}>
                      Clear
                    </Button>
                    <Button 
                      onClick={processUpload} 
                      disabled={isUploading || !selectedType}
                    >
                      {isUploading ? 'Uploading...' : 'Upload Data'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upload Progress */}
          {isUploading && (
            <div className="space-y-2">
              <Progress value={uploadProgress} />
              <p className="text-sm text-center text-muted-foreground">
                Processing upload... {uploadProgress}%
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* CSV Preview */}
      {csvPreview && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              CSV Preview
            </CardTitle>
            <CardDescription>
              Preview of the first 5 rows from your CSV file ({csvPreview.totalRows} total rows)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  {csvPreview.headers.map((header, index) => (
                    <TableHead key={index}>{header}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {csvPreview.rows.map((row, rowIndex) => (
                  <TableRow key={rowIndex}>
                    {row.map((cell, cellIndex) => (
                      <TableCell key={cellIndex} className="max-w-32 truncate">
                        {cell || <span className="text-muted-foreground italic">empty</span>}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Upload Result */}
      {uploadResult && (
        <Alert variant={uploadResult.success ? "default" : "destructive"}>
          <div className="flex items-center gap-2">
            {uploadResult.success ? (
              <CheckCircle className="h-4 w-4" />
            ) : (
              <XCircle className="h-4 w-4" />
            )}
            <AlertDescription>
              <div className="space-y-2">
                <p className="font-medium">{uploadResult.message}</p>
                {uploadResult.rowsImported && (
                  <p className="text-sm">
                    Successfully imported {uploadResult.rowsImported} rows
                  </p>
                )}
                {uploadResult.errors && uploadResult.errors.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Errors:</p>
                    <ul className="text-sm list-disc list-inside space-y-1">
                      {uploadResult.errors.map((error, index) => (
                        <li key={index}>{error}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </AlertDescription>
          </div>
        </Alert>
      )}
    </div>
  );
}