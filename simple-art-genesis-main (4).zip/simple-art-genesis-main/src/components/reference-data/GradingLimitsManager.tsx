import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Edit, Trash2, Filter, AlertTriangle, CheckCircle, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { sieveConfigurationService, GradingLimit, SieveConfiguration } from '@/services/database/sieveConfigurationService';

const SIEVE_DISPLAY_MAP: Record<string, string> = {
  '0_075': '0.075mm',
  '0_15': '0.15mm',
  '0_3': '0.3mm',
  '0_6': '0.6mm',
  '1_18': '1.18mm',
  '2_36': '2.36mm',
  '5': '5mm',
  '10': '10mm',
  '14': '14mm',
  '16': '16mm',
  '20': '20mm',
  '31_5': '31.5mm',
  '37_5': '37.5mm',
  '45': '45mm',
  '50': '50mm',
  '63': '63mm'
};

interface GradingLimitFormData {
  aggregate_type: string;
  standard: string;
  sieve_size: string;
  min_limit?: number;
  max_limit?: number;
  target_value?: number;
  tolerance: number;
}

export function GradingLimitsManager() {
  const [gradingLimits, setGradingLimits] = useState<GradingLimit[]>([]);
  const [sieveConfigurations, setSieveConfigurations] = useState<SieveConfiguration[]>([]);
  const [aggregateTypes, setAggregateTypes] = useState<string[]>([]);
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedStandard, setSelectedStandard] = useState<string>('');
  const [editingLimit, setEditingLimit] = useState<GradingLimit | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState<GradingLimitFormData>({
    aggregate_type: '',
    standard: '',
    sieve_size: '',
    tolerance: 5.0
  });

  const { toast } = useToast();

  useEffect(() => {
    initializeData();
  }, []);

  useEffect(() => {
    if (selectedType || selectedStandard) {
      loadFilteredLimits();
    }
  }, [selectedType, selectedStandard]);

  const initializeData = async () => {
    try {
      setLoading(true);
      await sieveConfigurationService.initializeTables();
      
      const [limits, configs, types] = await Promise.all([
        sieveConfigurationService.getAllGradingLimits(),
        sieveConfigurationService.getAllSieveConfigurations(),
        sieveConfigurationService.getAggregateTypes()
      ]);
      
      setGradingLimits(limits);
      setSieveConfigurations(configs);
      setAggregateTypes(types);
    } catch (error) {
      console.error('Error initializing data:', error);
      toast({
        title: "Error",
        description: "Failed to initialize grading limits data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadFilteredLimits = async () => {
    try {
      if (selectedType && selectedStandard) {
        const limits = await sieveConfigurationService.getGradingLimits(selectedType, selectedStandard);
        setGradingLimits(limits);
      } else if (selectedType) {
        const allLimits = await sieveConfigurationService.getAllGradingLimits();
        setGradingLimits(allLimits.filter(limit => limit.aggregate_type === selectedType));
      } else {
        const limits = await sieveConfigurationService.getAllGradingLimits();
        setGradingLimits(limits);
      }
    } catch (error) {
      console.error('Error loading filtered limits:', error);
    }
  };

  const handleAddLimit = () => {
    setEditingLimit(null);
    setFormData({
      aggregate_type: selectedType || '',
      standard: '',
      sieve_size: '',
      tolerance: 5.0
    });
    setIsDialogOpen(true);
  };

  const handleEditLimit = (limit: GradingLimit) => {
    setEditingLimit(limit);
    setFormData({
      aggregate_type: limit.aggregate_type,
      standard: limit.standard,
      sieve_size: limit.sieve_size,
      min_limit: limit.min_limit,
      max_limit: limit.max_limit,
      target_value: limit.target_value,
      tolerance: limit.tolerance || 5.0
    });
    setIsDialogOpen(true);
  };

  const handleSaveLimit = async () => {
    try {
      if (!formData.aggregate_type || !formData.standard || !formData.sieve_size) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive"
        });
        return;
      }

      if (editingLimit) {
        await sieveConfigurationService.updateGradingLimit(editingLimit.id, formData);
        toast({
          title: "Success",
          description: "Grading limit updated successfully",
        });
      } else {
        await sieveConfigurationService.saveGradingLimit(formData);
        toast({
          title: "Success",
          description: "Grading limit added successfully",
        });
      }

      setIsDialogOpen(false);
      loadFilteredLimits();
    } catch (error) {
      console.error('Error saving limit:', error);
      toast({
        title: "Error",
        description: "Failed to save grading limit",
        variant: "destructive"
      });
    }
  };

  const handleDeleteLimit = async (limit: GradingLimit) => {
    try {
      await sieveConfigurationService.deleteGradingLimit(limit.id);
      toast({
        title: "Success",
        description: "Grading limit deleted successfully",
      });
      loadFilteredLimits();
    } catch (error) {
      console.error('Error deleting limit:', error);
      toast({
        title: "Error",
        description: "Failed to delete grading limit",
        variant: "destructive"
      });
    }
  };

  const getAvailableSieveSizes = () => {
    if (!formData.aggregate_type) return [];
    
    const config = sieveConfigurations.find(c => c.aggregate_type === formData.aggregate_type);
    return config?.sieve_sizes || [];
  };

  const getUniqueStandards = () => {
    const standards = new Set(gradingLimits.map(limit => limit.standard));
    return Array.from(standards).sort();
  };

  const validateLimit = (limit: GradingLimit) => {
    if (limit.min_limit !== undefined && limit.max_limit !== undefined) {
      return limit.min_limit <= limit.max_limit;
    }
    return true;
  };

  const getStatusIcon = (limit: GradingLimit) => {
    if (validateLimit(limit)) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return <AlertTriangle className="h-4 w-4 text-red-500" />;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading grading limits...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Grading Limits Manager
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Aggregate Type</Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All types</SelectItem>
                  {aggregateTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Standard</Label>
              <Select value={selectedStandard} onValueChange={setSelectedStandard}>
                <SelectTrigger>
                  <SelectValue placeholder="All standards" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All standards</SelectItem>
                  {getUniqueStandards().map((standard) => (
                    <SelectItem key={standard} value={standard}>
                      {standard}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 flex items-end">
              <Button onClick={handleAddLimit} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                Add Limit
              </Button>
            </div>
          </div>

          {/* Limits Table */}
          {gradingLimits.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Aggregate Type</TableHead>
                  <TableHead>Standard</TableHead>
                  <TableHead>Sieve Size</TableHead>
                  <TableHead>Min Limit (%)</TableHead>
                  <TableHead>Max Limit (%)</TableHead>
                  <TableHead>Target (%)</TableHead>
                  <TableHead>Tolerance (%)</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {gradingLimits.map((limit) => (
                  <TableRow key={limit.id}>
                    <TableCell>{getStatusIcon(limit)}</TableCell>
                    <TableCell className="font-medium">{limit.aggregate_type}</TableCell>
                    <TableCell>{limit.standard}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {SIEVE_DISPLAY_MAP[limit.sieve_size] || limit.sieve_size}
                      </Badge>
                    </TableCell>
                    <TableCell>{limit.min_limit || '-'}</TableCell>
                    <TableCell>{limit.max_limit || '-'}</TableCell>
                    <TableCell>{limit.target_value || '-'}</TableCell>
                    <TableCell>{limit.tolerance}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleEditLimit(limit)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDeleteLimit(limit)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                No grading limits found. Add limits to define acceptable ranges for different aggregate types and standards.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingLimit ? 'Edit Grading Limit' : 'Add Grading Limit'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Aggregate Type</Label>
              <Select 
                value={formData.aggregate_type} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, aggregate_type: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select aggregate type" />
                </SelectTrigger>
                <SelectContent>
                  {aggregateTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Standard</Label>
              <Input
                value={formData.standard}
                onChange={(e) => setFormData(prev => ({ ...prev, standard: e.target.value }))}
                placeholder="e.g., BS 882 - Zone M"
              />
            </div>

            <div className="space-y-2">
              <Label>Sieve Size</Label>
              <Select 
                value={formData.sieve_size} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, sieve_size: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select sieve size" />
                </SelectTrigger>
                <SelectContent>
                  {getAvailableSieveSizes().map((size) => (
                    <SelectItem key={size} value={size}>
                      {SIEVE_DISPLAY_MAP[size] || size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Min Limit (%)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={formData.min_limit || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    min_limit: e.target.value ? parseFloat(e.target.value) : undefined 
                  }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Max Limit (%)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={formData.max_limit || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    max_limit: e.target.value ? parseFloat(e.target.value) : undefined 
                  }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Target Value (%)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={formData.target_value || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    target_value: e.target.value ? parseFloat(e.target.value) : undefined 
                  }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Tolerance (%)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={formData.tolerance}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    tolerance: parseFloat(e.target.value) || 5.0 
                  }))}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveLimit}>
              <Save className="mr-2 h-4 w-4" />
              {editingLimit ? 'Update' : 'Add'} Limit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}