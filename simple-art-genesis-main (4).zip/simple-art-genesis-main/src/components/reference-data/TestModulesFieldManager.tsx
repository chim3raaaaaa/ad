import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';
import { TestModulesAPI, ProductCategory, ProductType, ProductField, ValidationRule } from '@/services/api/testModulesAPI';
import { Plus, Edit, Trash2, Settings, Database } from 'lucide-react';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface FieldFormData {
  field_name: string;
  field_label: string;
  field_type: 'text' | 'number' | 'date' | 'select' | 'textarea' | 'boolean' | 'file';
  field_unit?: string;
  is_required: boolean;
  validation_rules: ValidationRule[];
  field_options?: string[];
  sort_order: number;
}

export function TestModulesFieldManager() {
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [fields, setFields] = useState<ProductField[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedProductType, setSelectedProductType] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [fieldFormOpen, setFieldFormOpen] = useState(false);
  const [editingField, setEditingField] = useState<ProductField | null>(null);

  const [fieldForm, setFieldForm] = useState<FieldFormData>({
    field_name: '',
    field_label: '',
    field_type: 'text',
    field_unit: '',
    is_required: false,
    validation_rules: [],
    field_options: [],
    sort_order: 0
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [categoriesData, typesData] = await Promise.all([
        TestModulesAPI.getProductCategories(),
        TestModulesAPI.getProductTypes()
      ]);
      setCategories(categoriesData);
      setProductTypes(typesData);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load test modules data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const loadFields = async (productTypeId: string) => {
    if (!productTypeId) {
      setFields([]);
      return;
    }

    try {
      const fieldsData = await TestModulesAPI.getProductFields(productTypeId);
      setFields(fieldsData);
    } catch (error) {
      console.error('Failed to load fields:', error);
      toast({
        title: 'Error',
        description: 'Failed to load product fields',
        variant: 'destructive'
      });
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedProductType) {
      loadFields(selectedProductType);
    }
  }, [selectedProductType]);

  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId === 'all' ? '' : categoryId);
    setSelectedProductType('');
    setFields([]);
  };

  const handleProductTypeChange = (productTypeId: string) => {
    setSelectedProductType(productTypeId);
  };

  const handleFieldSubmit = async () => {
    if (!selectedProductType) {
      toast({
        title: 'Error',
        description: 'Please select a product type first',
        variant: 'destructive'
      });
      return;
    }

    try {
      const fieldData = {
        ...fieldForm,
        product_type_id: selectedProductType,
        is_active: true,
        created_by: 'current_user' // TODO: Get from auth context
      };

      if (editingField) {
        // Update existing field - would need update endpoint
        toast({
          title: 'Info',
          description: 'Field update functionality coming soon',
        });
      } else {
        const fieldId = await TestModulesAPI.createProductField(fieldData);
        if (fieldId) {
          toast({
            title: 'Success',
            description: 'Field created successfully'
          });
          loadFields(selectedProductType);
          setFieldFormOpen(false);
          resetFieldForm();
        } else {
          throw new Error('Failed to create field');
        }
      }
    } catch (error) {
      console.error('Failed to save field:', error);
      toast({
        title: 'Error',
        description: 'Failed to save field',
        variant: 'destructive'
      });
    }
  };

  const resetFieldForm = () => {
    setFieldForm({
      field_name: '',
      field_label: '',
      field_type: 'text',
      field_unit: '',
      is_required: false,
      validation_rules: [],
      field_options: [],
      sort_order: fields.length
    });
    setEditingField(null);
  };

  const addValidationRule = () => {
    setFieldForm(prev => ({
      ...prev,
      validation_rules: [
        ...prev.validation_rules,
        { type: 'min', value: '', message: '' }
      ]
    }));
  };

  const updateValidationRule = (index: number, rule: ValidationRule) => {
    setFieldForm(prev => ({
      ...prev,
      validation_rules: prev.validation_rules.map((r, i) => i === index ? rule : r)
    }));
  };

  const removeValidationRule = (index: number) => {
    setFieldForm(prev => ({
      ...prev,
      validation_rules: prev.validation_rules.filter((_, i) => i !== index)
    }));
  };

  const filteredProductTypes = productTypes.filter(type => 
    !selectedCategory || type.category_id === selectedCategory
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Test Modules Field Configuration
          </CardTitle>
          <CardDescription>
            Configure dynamic fields for test entry forms across all product categories
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Category and Product Type Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Product Category</Label>
              <Select value={selectedCategory || "all"} onValueChange={handleCategoryChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="productType">Product Type</Label>
              <Select value={selectedProductType || undefined} onValueChange={handleProductTypeChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  {filteredProductTypes.map(type => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Fields Management */}
          {selectedProductType && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Product Fields</h3>
                <PermissionWrapper permissions={['test_module_admin', 'field_config']}>
                  <Dialog open={fieldFormOpen} onOpenChange={setFieldFormOpen}>
                    <DialogTrigger asChild>
                      <Button onClick={resetFieldForm}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Field
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>
                          {editingField ? 'Edit Field' : 'Add New Field'}
                        </DialogTitle>
                        <DialogDescription>
                          Configure a dynamic field for the selected product type
                        </DialogDescription>
                      </DialogHeader>

                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fieldName">Field Name</Label>
                            <Input
                              id="fieldName"
                              value={fieldForm.field_name}
                              onChange={(e) => setFieldForm(prev => ({ ...prev, field_name: e.target.value }))}
                              placeholder="field_name_snake_case"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fieldLabel">Field Label</Label>
                            <Input
                              id="fieldLabel"
                              value={fieldForm.field_label}
                              onChange={(e) => setFieldForm(prev => ({ ...prev, field_label: e.target.value }))}
                              placeholder="Display Label"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fieldType">Field Type</Label>
                            <Select
                              value={fieldForm.field_type}
                              onValueChange={(value: any) => setFieldForm(prev => ({ ...prev, field_type: value }))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="text">Text</SelectItem>
                                <SelectItem value="number">Number</SelectItem>
                                <SelectItem value="date">Date</SelectItem>
                                <SelectItem value="select">Select</SelectItem>
                                <SelectItem value="textarea">Textarea</SelectItem>
                                <SelectItem value="boolean">Boolean</SelectItem>
                                <SelectItem value="file">File</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="fieldUnit">Unit (optional)</Label>
                            <Input
                              id="fieldUnit"
                              value={fieldForm.field_unit || ''}
                              onChange={(e) => setFieldForm(prev => ({ ...prev, field_unit: e.target.value }))}
                              placeholder="mm, kg, %, etc."
                            />
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id="required"
                            checked={fieldForm.is_required}
                            onCheckedChange={(checked) => setFieldForm(prev => ({ ...prev, is_required: checked }))}
                          />
                          <Label htmlFor="required">Required Field</Label>
                        </div>

                        {fieldForm.field_type === 'select' && (
                          <div className="space-y-2">
                            <Label htmlFor="options">Options (one per line)</Label>
                            <Textarea
                              id="options"
                              value={(fieldForm.field_options || []).join('\n')}
                              onChange={(e) => setFieldForm(prev => ({ 
                                ...prev, 
                                field_options: e.target.value.split('\n').filter(Boolean) 
                              }))}
                              placeholder="Option 1&#10;Option 2&#10;Option 3"
                              rows={4}
                            />
                          </div>
                        )}

                        {/* Validation Rules */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label>Validation Rules</Label>
                            <Button type="button" variant="outline" size="sm" onClick={addValidationRule}>
                              <Plus className="h-3 w-3 mr-1" />
                              Add Rule
                            </Button>
                          </div>
                          {fieldForm.validation_rules.map((rule, index) => (
                            <div key={index} className="flex items-center gap-2 p-2 border rounded">
                              <Select
                                value={rule.type}
                                onValueChange={(value: any) => updateValidationRule(index, { ...rule, type: value })}
                              >
                                <SelectTrigger className="w-24">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="min">Min</SelectItem>
                                  <SelectItem value="max">Max</SelectItem>
                                  <SelectItem value="pattern">Pattern</SelectItem>
                                </SelectContent>
                              </Select>
                              <Input
                                placeholder="Value"
                                value={rule.value}
                                onChange={(e) => updateValidationRule(index, { ...rule, value: e.target.value })}
                                className="flex-1"
                              />
                              <Input
                                placeholder="Error message"
                                value={rule.message}
                                onChange={(e) => updateValidationRule(index, { ...rule, message: e.target.value })}
                                className="flex-1"
                              />
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => removeValidationRule(index)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          ))}
                        </div>

                        <div className="flex justify-end gap-2">
                          <Button variant="outline" onClick={() => setFieldFormOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleFieldSubmit}>
                            {editingField ? 'Update' : 'Create'} Field
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </PermissionWrapper>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Field Name</TableHead>
                    <TableHead>Label</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Unit</TableHead>
                    <TableHead>Required</TableHead>
                    <TableHead>Order</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fields.map((field) => (
                    <TableRow key={field.id}>
                      <TableCell className="font-mono text-sm">{field.field_name}</TableCell>
                      <TableCell>{field.field_label}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{field.field_type}</Badge>
                      </TableCell>
                      <TableCell>{field.field_unit || '-'}</TableCell>
                      <TableCell>
                        {field.is_required ? (
                          <Badge variant="destructive">Required</Badge>
                        ) : (
                          <Badge variant="secondary">Optional</Badge>
                        )}
                      </TableCell>
                      <TableCell>{field.sort_order}</TableCell>
                      <TableCell>
                        <PermissionWrapper permissions={['test_module_admin', 'field_config']}>
                          <div className="flex gap-1">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingField(field);
                                setFieldForm({
                                  field_name: field.field_name,
                                  field_label: field.field_label,
                                  field_type: field.field_type,
                                  field_unit: field.field_unit,
                                  is_required: field.is_required,
                                  validation_rules: field.validation_rules,
                                  field_options: field.field_options,
                                  sort_order: field.sort_order
                                });
                                setFieldFormOpen(true);
                              }}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        </PermissionWrapper>
                      </TableCell>
                    </TableRow>
                  ))}
                  {fields.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground">
                        No fields configured for this product type
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}