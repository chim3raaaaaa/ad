import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { RefreshCw, Download, Filter, Eye, Calendar, User, Database } from 'lucide-react';
import { referenceDataAuditService, type AuditLogEntry, type AuditStats } from '@/services/reference-data/auditService';

// Component props
interface AuditTrailProps {
  tableName?: string;
  recordId?: string;
}

export const AuditTrail: React.FC<AuditTrailProps> = ({ tableName, recordId }) => {
  const [auditRecords, setAuditRecords] = useState<AuditLogEntry[]>([]);
  const [auditStats, setAuditStats] = useState<AuditStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterAction, setFilterAction] = useState<string>('all');
  const [filterUser, setFilterUser] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    loadAuditData();
  }, [tableName, recordId, filterAction, filterUser, searchTerm]);

  const loadAuditData = async () => {
    setLoading(true);
    try {
      const filters: any = {
        tableName,
        search: searchTerm,
        action: filterAction === 'all' ? undefined : filterAction,
        limit: 100
      };

      if (filterUser) {
        filters.userId = filterUser;
      }

      const [records, stats] = await Promise.all([
        referenceDataAuditService.getAuditLogs(filters),
        referenceDataAuditService.getAuditStats()
      ]);

      setAuditRecords(records);
      setAuditStats(stats);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load audit trail",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'csv' | 'json' = 'csv') => {
    try {
      const filters: any = {
        tableName,
        search: searchTerm,
        action: filterAction === 'all' ? undefined : filterAction,
        limit: 1000
      };

      const exportData = await referenceDataAuditService.exportAuditLogs(format, filters);
      
      // Create download
      const blob = new Blob([exportData], { type: format === 'csv' ? 'text/csv' : 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `audit-trail-${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: `Audit trail exported as ${format.toUpperCase()}`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export audit trail",
        variant: "destructive"
      });
    }
  };

  const getSeverityBadge = (severity: string) => {
    const variants = {
      low: 'default',
      medium: 'secondary', 
      high: 'destructive',
      critical: 'destructive'
    } as const;

    return (
      <Badge variant={variants[severity as keyof typeof variants] || 'default'}>
        {severity.toUpperCase()}
      </Badge>
    );
  };

  const getActionBadge = (action: string) => {
    const variants = {
      CREATE: 'default',
      UPDATE: 'secondary',
      DELETE: 'destructive',
      UPLOAD_CSV: 'default',
      BULK_UPDATE: 'secondary',
      BULK_DELETE: 'destructive'
    } as const;

    return (
      <Badge variant={variants[action as keyof typeof variants] || 'default'}>
        {action}
      </Badge>
    );
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Audit Trail
              </CardTitle>
              <CardDescription>
                Track all changes and modifications to reference data
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={loadAuditData} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button onClick={() => handleExport('csv')} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              <Button onClick={() => handleExport('json')} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export JSON
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {auditStats && (
            <div className="grid gap-4 md:grid-cols-3 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Total Events</p>
                      <p className="text-2xl font-bold">{auditStats.totalLogs}</p>
                    </div>
                    <Database className="h-8 w-8 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Recent Activity (24h)</p>
                      <p className="text-2xl font-bold">{auditStats.recentActivity}</p>
                    </div>
                    <Calendar className="h-8 w-8 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Active Users</p>
                      <p className="text-2xl font-bold">{auditStats.topUsers.length}</p>
                    </div>
                    <User className="h-8 w-8 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Filters */}
          <div className="flex gap-4">
            <Input
              placeholder="Search changes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-xs"
            />
            <Select value={filterAction} onValueChange={setFilterAction}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="CREATE">Created</SelectItem>
                <SelectItem value="UPDATE">Updated</SelectItem>
                <SelectItem value="DELETE">Deleted</SelectItem>
                <SelectItem value="UPLOAD_CSV">CSV Upload</SelectItem>
                <SelectItem value="BULK_UPDATE">Bulk Update</SelectItem>
                <SelectItem value="BULK_DELETE">Bulk Delete</SelectItem>
              </SelectContent>
            </Select>
            <Input
              placeholder="Filter by user..."
              value={filterUser}
              onChange={(e) => setFilterUser(e.target.value)}
              className="max-w-xs"
            />
          </div>

          {/* Audit Records Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Table</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Changes</TableHead>
                  <TableHead>IP Address</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      Loading audit records...
                    </TableCell>
                  </TableRow>
                ) : auditRecords.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No audit records found
                    </TableCell>
                  </TableRow>
                ) : (
                  auditRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div className="text-sm">
                          {formatTimestamp(record.timestamp)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{record.user_name}</div>
                      </TableCell>
                      <TableCell>{getActionBadge(record.action)}</TableCell>
                      <TableCell className="font-mono text-sm">{record.table_name}</TableCell>
                      <TableCell>{getSeverityBadge(record.severity)}</TableCell>
                      <TableCell className="max-w-md">
                        <div className="space-y-1">
                          {record.changes.slice(0, 2).map((change, index) => (
                            <div key={index} className="text-sm text-muted-foreground truncate">
                              {change}
                            </div>
                          ))}
                          {record.changes.length > 2 && (
                            <div className="text-xs text-muted-foreground">
                              +{record.changes.length - 2} more changes
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {record.ip_address}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};