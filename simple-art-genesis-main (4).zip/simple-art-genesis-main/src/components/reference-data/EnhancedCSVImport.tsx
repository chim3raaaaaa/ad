import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { 
  Upload, 
  FileText, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  X,
  MapPin,
  Settings,
  Eye,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CSVColumn {
  index: number;
  header: string;
  mappedTo?: string;
  dataType?: 'text' | 'number' | 'date' | 'boolean';
  required?: boolean;
  sample?: string[];
}

interface ValidationError {
  row: number;
  column: string;
  value: string;
  error: string;
  severity: 'error' | 'warning';
}

interface ImportTemplate {
  id: string;
  name: string;
  description: string;
  targetTable: string;
  columnMappings: Record<string, string>;
  validationRules: Record<string, any>;
}

interface EnhancedCSVImportProps {
  targetTable: string;
  availableFields: Array<{
    key: string;
    label: string;
    type: 'text' | 'number' | 'date' | 'boolean';
    required?: boolean;
  }>;
  onImport: (data: any[], mappings: Record<string, string>) => Promise<void>;
}

export const EnhancedCSVImport: React.FC<EnhancedCSVImportProps> = ({
  targetTable,
  availableFields,
  onImport
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<string[][]>([]);
  const [columns, setColumns] = useState<CSVColumn[]>([]);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [activeTab, setActiveTab] = useState('upload');
  const [templates, setTemplates] = useState<ImportTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (!uploadedFile) return;

    if (!uploadedFile.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a CSV file",
        variant: "destructive"
      });
      return;
    }

    setFile(uploadedFile);
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      parseCSV(content);
    };
    reader.readAsText(uploadedFile);
  };

  const parseCSV = (content: string) => {
    try {
      const lines = content.split('\n').filter(line => line.trim());
      const data = lines.map(line => {
        const cells = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            cells.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        cells.push(current.trim());
        return cells;
      });

      setCsvData(data);
      
      if (data.length > 0) {
        const headers = data[0];
        const sampleData = data.slice(1, 6); // Get first 5 rows as samples
        
        const csvColumns: CSVColumn[] = headers.map((header, index) => ({
          index,
          header: header.replace(/"/g, ''),
          sample: sampleData.map(row => row[index] || '').filter(Boolean)
        }));
        
        setColumns(csvColumns);
        autoMapColumns(csvColumns);
        setActiveTab('mapping');
      }
    } catch (error) {
      toast({
        title: "Parse Error",
        description: "Failed to parse CSV file",
        variant: "destructive"
      });
    }
  };

  const autoMapColumns = (csvColumns: CSVColumn[]) => {
    const updatedColumns = csvColumns.map(col => {
      const lowercaseHeader = col.header.toLowerCase();
      const matchedField = availableFields.find(field => 
        field.key.toLowerCase() === lowercaseHeader ||
        field.label.toLowerCase() === lowercaseHeader ||
        field.key.toLowerCase().includes(lowercaseHeader) ||
        lowercaseHeader.includes(field.key.toLowerCase())
      );
      
      return {
        ...col,
        mappedTo: matchedField?.key,
        dataType: matchedField?.type || 'text',
        required: matchedField?.required || false
      };
    });
    
    setColumns(updatedColumns);
  };

  const validateData = async () => {
    setIsValidating(true);
    setValidationErrors([]);
    
    try {
      const errors: ValidationError[] = [];
      const dataRows = csvData.slice(1); // Skip header row
      
      dataRows.forEach((row, rowIndex) => {
        columns.forEach(column => {
          const value = row[column.index] || '';
          const fieldConfig = availableFields.find(f => f.key === column.mappedTo);
          
          if (!fieldConfig) return;
          
          // Check required fields
          if (fieldConfig.required && !value.trim()) {
            errors.push({
              row: rowIndex + 2, // +2 because we skip header and 0-based index
              column: column.header,
              value,
              error: `Required field cannot be empty`,
              severity: 'error'
            });
          }
          
          // Validate data types
          if (value.trim()) {
            switch (fieldConfig.type) {
              case 'number':
                if (isNaN(Number(value))) {
                  errors.push({
                    row: rowIndex + 2,
                    column: column.header,
                    value,
                    error: `Expected number, got "${value}"`,
                    severity: 'error'
                  });
                }
                break;
              case 'date':
                if (isNaN(Date.parse(value))) {
                  errors.push({
                    row: rowIndex + 2,
                    column: column.header,
                    value,
                    error: `Invalid date format: "${value}"`,
                    severity: 'error'
                  });
                }
                break;
              case 'boolean':
                const boolValues = ['true', 'false', '1', '0', 'yes', 'no'];
                if (!boolValues.includes(value.toLowerCase())) {
                  errors.push({
                    row: rowIndex + 2,
                    column: column.header,
                    value,
                    error: `Expected boolean value, got "${value}"`,
                    severity: 'warning'
                  });
                }
                break;
            }
          }
        });
      });
      
      setValidationErrors(errors);
      setActiveTab('validation');
      
      if (errors.filter(e => e.severity === 'error').length === 0) {
        toast({
          title: "Validation Passed",
          description: `${dataRows.length} rows validated successfully`
        });
      } else {
        toast({
          title: "Validation Issues Found",
          description: `${errors.filter(e => e.severity === 'error').length} errors need to be fixed`,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Validation Error",
        description: "Failed to validate data",
        variant: "destructive"
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleImport = async () => {
    const errorCount = validationErrors.filter(e => e.severity === 'error').length;
    if (errorCount > 0) {
      toast({
        title: "Cannot Import",
        description: `Please fix ${errorCount} error(s) before importing`,
        variant: "destructive"
      });
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      const dataRows = csvData.slice(1);
      const mappings = columns.reduce((acc, col) => {
        if (col.mappedTo) {
          acc[col.header] = col.mappedTo;
        }
        return acc;
      }, {} as Record<string, string>);

      const processedData = dataRows.map(row => {
        const item: Record<string, any> = {};
        columns.forEach(col => {
          if (col.mappedTo) {
            let value = row[col.index] || '';
            
            // Type conversion
            if (value.trim()) {
              switch (col.dataType) {
                case 'number':
                  item[col.mappedTo] = Number(value);
                  return;
                case 'boolean':
                  item[col.mappedTo] = ['true', '1', 'yes'].includes(value.toLowerCase());
                  return;
                case 'date':
                  item[col.mappedTo] = new Date(value).toISOString();
                  return;
              }
            }
            
            item[col.mappedTo] = value;
          }
        });
        return item;
      });

      // Simulate progress
      for (let i = 0; i <= 100; i += 10) {
        setImportProgress(i);
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      await onImport(processedData, mappings);
      
      toast({
        title: "Import Successful",
        description: `Imported ${processedData.length} records successfully`
      });

      // Reset state
      setFile(null);
      setCsvData([]);
      setColumns([]);
      setValidationErrors([]);
      setActiveTab('upload');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

    } catch (error) {
      toast({
        title: "Import Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
      setImportProgress(0);
    }
  };

  const downloadTemplate = () => {
    const headers = availableFields.map(field => field.label);
    const csvContent = headers.join(',') + '\n';
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${targetTable}_template.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const updateColumnMapping = (columnIndex: number, mappedTo: string) => {
    const updatedColumns = columns.map((col, index) => 
      index === columnIndex 
        ? { 
            ...col, 
            mappedTo,
            dataType: availableFields.find(f => f.key === mappedTo)?.type || 'text',
            required: availableFields.find(f => f.key === mappedTo)?.required || false
          }
        : col
    );
    setColumns(updatedColumns);
  };

  const errorCount = validationErrors.filter(e => e.severity === 'error').length;
  const warningCount = validationErrors.filter(e => e.severity === 'warning').length;
  const mappedColumns = columns.filter(c => c.mappedTo).length;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Enhanced CSV Import
        </CardTitle>
        <CardDescription>
          Import data with advanced mapping, validation, and error handling
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="mapping" disabled={!file}>
              Mapping {mappedColumns > 0 && <Badge className="ml-2">{mappedColumns}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="validation" disabled={!file}>
              Validation {validationErrors.length > 0 && (
                <Badge variant={errorCount > 0 ? "destructive" : "secondary"} className="ml-2">
                  {validationErrors.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="import" disabled={!file || errorCount > 0}>
              Import
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <div className="space-y-4">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Upload CSV File</h3>
                  <p className="text-sm text-muted-foreground">
                    Choose a CSV file to import into {targetTable}
                  </p>
                </div>
                <div className="mt-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button onClick={() => fileInputRef.current?.click()}>
                    Select CSV File
                  </Button>
                </div>
              </div>

              <div className="flex justify-center">
                <Button variant="outline" onClick={downloadTemplate} className="gap-2">
                  <Download className="h-4 w-4" />
                  Download Template
                </Button>
              </div>

              {file && (
                <Alert>
                  <FileText className="h-4 w-4" />
                  <AlertDescription>
                    <strong>File uploaded:</strong> {file.name} ({(file.size / 1024).toFixed(1)} KB)
                    <br />
                    <strong>Rows detected:</strong> {csvData.length - 1} (excluding header)
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          <TabsContent value="mapping" className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Column Mapping</h3>
                <Badge variant="outline">
                  {mappedColumns} of {columns.length} columns mapped
                </Badge>
              </div>

              <div className="space-y-4">
                {columns.map((column, index) => (
                  <Card key={index} className="p-4">
                    <div className="grid grid-cols-12 gap-4 items-start">
                      <div className="col-span-3">
                        <Label className="text-sm font-medium">{column.header}</Label>
                        <div className="text-xs text-muted-foreground mt-1">
                          Column {index + 1}
                        </div>
                      </div>
                      
                      <div className="col-span-3">
                        <Select 
                          value={column.mappedTo || 'none'} 
                          onValueChange={(value) => updateColumnMapping(index, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select field" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">-- No mapping --</SelectItem>
                            {availableFields.map(field => (
                              <SelectItem key={field.key} value={field.key}>
                                {field.label}
                                {field.required && <span className="text-destructive ml-1">*</span>}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="col-span-2">
                        <div className="text-sm">
                          {column.dataType && (
                            <Badge variant="outline" className="text-xs">
                              {column.dataType}
                            </Badge>
                          )}
                          {column.required && (
                            <Badge variant="destructive" className="ml-1 text-xs">
                              Required
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="col-span-4">
                        <div className="text-sm text-muted-foreground">
                          <strong>Sample data:</strong>
                          <div className="mt-1 max-h-20 overflow-y-auto">
                            {column.sample?.slice(0, 3).map((sample, i) => (
                              <div key={i} className="text-xs font-mono bg-muted px-2 py-1 rounded mb-1">
                                {sample || '<empty>'}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end gap-2">
                <Button onClick={validateData} disabled={mappedColumns === 0}>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Validate Data
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="validation" className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Data Validation</h3>
                <div className="flex gap-2">
                  {errorCount > 0 && (
                    <Badge variant="destructive">{errorCount} errors</Badge>
                  )}
                  {warningCount > 0 && (
                    <Badge variant="secondary">{warningCount} warnings</Badge>
                  )}
                  {validationErrors.length === 0 && (
                    <Badge variant="default">✓ All valid</Badge>
                  )}
                </div>
              </div>

              {isValidating ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>Validating data...</p>
                </div>
              ) : validationErrors.length === 0 ? (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    All data validation checks passed! Ready to import {csvData.length - 1} rows.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-4">
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Row</TableHead>
                          <TableHead>Column</TableHead>
                          <TableHead>Value</TableHead>
                          <TableHead>Issue</TableHead>
                          <TableHead>Severity</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {validationErrors.slice(0, 20).map((error, index) => (
                          <TableRow key={index}>
                            <TableCell>{error.row}</TableCell>
                            <TableCell className="font-mono text-sm">{error.column}</TableCell>
                            <TableCell className="font-mono text-sm max-w-32 truncate">
                              {error.value || '<empty>'}
                            </TableCell>
                            <TableCell className="text-sm">{error.error}</TableCell>
                            <TableCell>
                              <Badge variant={error.severity === 'error' ? 'destructive' : 'secondary'}>
                                {error.severity}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {validationErrors.length > 20 && (
                    <p className="text-sm text-muted-foreground text-center">
                      Showing first 20 of {validationErrors.length} issues
                    </p>
                  )}
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={validateData}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Re-validate
                </Button>
                <Button 
                  onClick={() => setActiveTab('import')} 
                  disabled={errorCount > 0}
                >
                  Proceed to Import
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="import" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Ready to Import</h3>
              
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Import Summary:</strong>
                  <ul className="mt-2 space-y-1">
                    <li>• {csvData.length - 1} rows will be imported</li>
                    <li>• {mappedColumns} columns mapped</li>
                    <li>• {warningCount} warnings (will be imported with current values)</li>
                  </ul>
                </AlertDescription>
              </Alert>

              {isImporting && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Import Progress</span>
                      <span>{importProgress}%</span>
                    </div>
                    <Progress value={importProgress} />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setActiveTab('validation')}>
                  Back to Validation
                </Button>
                <Button 
                  onClick={handleImport} 
                  disabled={isImporting || errorCount > 0}
                >
                  {isImporting ? 'Importing...' : `Import ${csvData.length - 1} Records`}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};