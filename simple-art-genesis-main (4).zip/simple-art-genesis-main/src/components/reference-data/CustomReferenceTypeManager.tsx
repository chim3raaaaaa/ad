import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Edit, Trash2, Settings, Type, Hash, Calendar, ToggleLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export interface FieldDefinition {
  id: string;
  name: string;
  type: 'text' | 'number' | 'select' | 'date' | 'boolean';
  required: boolean;
  options?: string[];
  defaultValue?: string;
}

export interface CustomReferenceType {
  id: string;
  name: string;
  description: string;
  icon: string;
  fields: FieldDefinition[];
  tableName: string;
  createdAt: Date;
  isActive: boolean;
}

interface CustomReferenceTypeManagerProps {
  onRefresh: () => void;
}

export function CustomReferenceTypeManager({ onRefresh }: CustomReferenceTypeManagerProps) {
  const [customTypes, setCustomTypes] = useState<CustomReferenceType[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingType, setEditingType] = useState<CustomReferenceType | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    icon: 'Database'
  });
  const [fields, setFields] = useState<FieldDefinition[]>([]);
  const [newField, setNewField] = useState<Partial<FieldDefinition>>({
    name: '',
    type: 'text',
    required: false
  });
  const { toast } = useToast();

  useEffect(() => {
    loadCustomTypes();
  }, []);

  const loadCustomTypes = async () => {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM custom_reference_types WHERE is_active = 1 ORDER BY created_at DESC'
        );
        
        const types = (result.data || []).map((row: any) => ({
          id: row.id,
          name: row.name,
          description: row.description,
          icon: row.icon,
          fields: JSON.parse(row.fields_schema),
          tableName: row.table_name,
          createdAt: new Date(row.created_at),
          isActive: Boolean(row.is_active)
        }));
        setCustomTypes(types);
      } else {
        // Browser fallback
        const stored = localStorage.getItem('custom_reference_types');
        setCustomTypes(stored ? JSON.parse(stored) : []);
      }
    } catch (error) {
      console.error('Failed to load custom types:', error);
      toast({
        title: "Error",
        description: "Failed to load custom reference types",
        variant: "destructive"
      });
    }
  };

  const saveCustomTypes = async (types: CustomReferenceType[]) => {
    try {
      if (window.electronAPI) {
        // Save to SQLite
        for (const type of types) {
          await window.electronAPI.dbRun(
            `INSERT OR REPLACE INTO custom_reference_types 
             (id, name, description, icon, fields_schema, table_name, created_at, is_active, updated_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              type.id,
              type.name,
              type.description,
              type.icon,
              JSON.stringify(type.fields),
              type.tableName,
              type.createdAt.toISOString(),
              type.isActive ? 1 : 0,
              new Date().toISOString()
            ]
          );
        }
      } else {
        // Browser fallback
        localStorage.setItem('custom_reference_types', JSON.stringify(types));
      }
      setCustomTypes(types);
    } catch (error) {
      console.error('Failed to save custom types:', error);
      throw error;
    }
  };

  const createDatabaseTable = async (tableName: string, fields: FieldDefinition[]) => {
    const columnDefinitions = fields.map(field => {
      let columnDef = `${field.name} `;
      switch (field.type) {
        case 'number':
          columnDef += 'REAL';
          break;
        case 'date':
          columnDef += 'DATETIME';
          break;
        case 'boolean':
          columnDef += 'INTEGER';
          break;
        default:
          columnDef += 'TEXT';
      }
      if (field.required) {
        columnDef += ' NOT NULL';
      }
      return columnDef;
    }).join(', ');

    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id TEXT PRIMARY KEY,
        ${columnDefinitions},
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    if (window.electronAPI) {
      await window.electronAPI.dbRun(createTableSQL);
    }
  };

  const handleSaveType = async () => {
    if (!formData.name.trim() || fields.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please provide a name and at least one field",
        variant: "destructive"
      });
      return;
    }

    try {
      const tableName = `custom_${formData.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
      
      // Create database table for this custom type
      await createDatabaseTable(tableName, fields);

      const newType: CustomReferenceType = {
        id: editingType?.id || `custom_${Date.now()}`,
        name: formData.name,
        description: formData.description,
        icon: formData.icon,
        fields: fields,
        tableName: tableName,
        createdAt: editingType?.createdAt || new Date(),
        isActive: true
      };

      let updatedTypes;
      if (editingType) {
        updatedTypes = customTypes.map(type => 
          type.id === editingType.id ? newType : type
        );
      } else {
        updatedTypes = [...customTypes, newType];
      }

      await saveCustomTypes(updatedTypes);
      
      toast({
        title: "Success",
        description: `Reference type "${formData.name}" ${editingType ? 'updated' : 'created'} successfully`
      });

      setIsDialogOpen(false);
      resetForm();
      onRefresh();
    } catch (error) {
      console.error('Failed to save custom type:', error);
      toast({
        title: "Error",
        description: "Failed to save reference type",
        variant: "destructive"
      });
    }
  };

  const handleDeleteType = async (typeId: string) => {
    try {
      const updatedTypes = customTypes.map(type =>
        type.id === typeId ? { ...type, isActive: false } : type
      );
      await saveCustomTypes(updatedTypes);
      
      toast({
        title: "Success",
        description: "Reference type deleted successfully"
      });
    } catch (error) {
      console.error('Failed to delete custom type:', error);
      toast({
        title: "Error",
        description: "Failed to delete reference type",
        variant: "destructive"
      });
    }
  };

  const handleEditType = (type: CustomReferenceType) => {
    setEditingType(type);
    setFormData({
      name: type.name,
      description: type.description,
      icon: type.icon
    });
    setFields([...type.fields]);
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingType(null);
    setFormData({ name: '', description: '', icon: 'Database' });
    setFields([]);
    setNewField({ name: '', type: 'text', required: false });
  };

  const addField = () => {
    if (!newField.name?.trim()) {
      toast({
        title: "Validation Error",
        description: "Field name is required",
        variant: "destructive"
      });
      return;
    }

    const field: FieldDefinition = {
      id: `field_${Date.now()}`,
      name: newField.name!,
      type: newField.type as FieldDefinition['type'],
      required: newField.required || false,
      options: newField.options,
      defaultValue: newField.defaultValue
    };

    setFields([...fields, field]);
    setNewField({ name: '', type: 'text', required: false });
  };

  const removeField = (fieldId: string) => {
    setFields(fields.filter(f => f.id !== fieldId));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'text': return <Type className="h-4 w-4" />;
      case 'number': return <Hash className="h-4 w-4" />;
      case 'date': return <Calendar className="h-4 w-4" />;
      case 'boolean': return <ToggleLeft className="h-4 w-4" />;
      case 'select': return <Settings className="h-4 w-4" />;
      default: return <Type className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Custom Reference Types</h3>
          <p className="text-sm text-muted-foreground">
            Create and manage custom reference data types for your specific needs
          </p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add New Type
        </Button>
      </div>

      {/* Custom Types List */}
      <Card>
        <CardHeader>
          <CardTitle>Custom Reference Types</CardTitle>
          <CardDescription>
            Manage your custom reference data types and their field definitions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {customTypes.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No custom reference types created yet.</p>
              <Button 
                variant="outline" 
                onClick={() => setIsDialogOpen(true)}
                className="mt-4"
              >
                Create Your First Custom Type
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Fields</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customTypes.map(type => (
                  <TableRow key={type.id}>
                    <TableCell className="font-medium">{type.name}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {type.description || 'No description'}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {type.fields.slice(0, 3).map(field => (
                          <Badge key={field.id} variant="outline" className="text-xs">
                            {field.name}
                          </Badge>
                        ))}
                        {type.fields.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{type.fields.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {type.createdAt.toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditType(type)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteType(type.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingType ? 'Edit' : 'Create'} Custom Reference Type
            </DialogTitle>
            <DialogDescription>
              Define a new reference data type with custom fields for your specific needs.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">Type Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Quality Standards"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="icon">Icon</Label>
                <Select 
                  value={formData.icon} 
                  onValueChange={(value) => setFormData({ ...formData, icon: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Database">Database</SelectItem>
                    <SelectItem value="Settings">Settings</SelectItem>
                    <SelectItem value="FileText">Document</SelectItem>
                    <SelectItem value="Users">People</SelectItem>
                    <SelectItem value="Package">Package</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what this reference type is for..."
                rows={2}
              />
            </div>

            {/* Field Definitions */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Field Definitions</h4>
                <Badge variant="outline">{fields.length} fields</Badge>
              </div>

              {/* Add New Field */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Add New Field</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-4">
                    <div className="space-y-2">
                      <Label>Field Name</Label>
                      <Input
                        value={newField.name || ''}
                        onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                        placeholder="Field name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select 
                        value={newField.type || 'text'} 
                        onValueChange={(value) => setNewField({ ...newField, type: value as FieldDefinition['type'] })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">Text</SelectItem>
                          <SelectItem value="number">Number</SelectItem>
                          <SelectItem value="select">Select/Dropdown</SelectItem>
                          <SelectItem value="date">Date</SelectItem>
                          <SelectItem value="boolean">Yes/No</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        Required
                        <Switch
                          checked={newField.required || false}
                          onCheckedChange={(checked) => setNewField({ ...newField, required: checked })}
                        />
                      </Label>
                    </div>
                    <div className="space-y-2">
                      <Label>&nbsp;</Label>
                      <Button onClick={addField} className="w-full">
                        <Plus className="h-4 w-4 mr-1" />
                        Add Field
                      </Button>
                    </div>
                  </div>
                  
                  {newField.type === 'select' && (
                    <div className="space-y-2">
                      <Label>Options (comma-separated)</Label>
                      <Input
                        value={newField.options?.join(', ') || ''}
                        onChange={(e) => setNewField({ 
                          ...newField, 
                          options: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                        })}
                        placeholder="Option 1, Option 2, Option 3"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Current Fields */}
              {fields.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Current Fields</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {fields.map(field => (
                        <div key={field.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            {getTypeIcon(field.type)}
                            <div>
                              <p className="font-medium">{field.name}</p>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Badge variant="outline" className="text-xs">
                                  {field.type}
                                </Badge>
                                {field.required && (
                                  <Badge variant="destructive" className="text-xs">
                                    Required
                                  </Badge>
                                )}
                                {field.options && (
                                  <span className="text-xs">
                                    Options: {field.options.join(', ')}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeField(field.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveType}>
              {editingType ? 'Update' : 'Create'} Type
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}