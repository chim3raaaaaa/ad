import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  MoreHorizontal,
  Check,
  X,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { CustomReferenceType, FieldDefinition } from './CustomReferenceTypeManager';

interface DynamicDataTableProps {
  referenceType: CustomReferenceType;
  onRefresh: () => void;
}

export function DynamicDataTable({ referenceType, onRefresh }: DynamicDataTableProps) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [inlineEditItem, setInlineEditItem] = useState<string | null>(null);
  const [tempEditData, setTempEditData] = useState<Record<string, any>>({});
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, [referenceType]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM ${referenceType.tableName} ORDER BY created_at DESC`
        );
        setData(result || []);
      } else {
        // Browser fallback
        const stored = localStorage.getItem(`ref_${referenceType.id}`);
        setData(stored ? JSON.parse(stored) : []);
      }
    } catch (error) {
      console.error('Failed to load data:', error);
      setData([]);
      toast({
        title: "Error",
        description: `Failed to load ${referenceType.name} data`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveData = async (itemData: Record<string, any>) => {
    try {
      if (window.electronAPI) {
        const columns = Object.keys(itemData).join(', ');
        const placeholders = Object.keys(itemData).map(() => '?').join(', ');
        const values = Object.values(itemData);

        if (editingItem) {
          // Update existing
          const updateColumns = Object.keys(itemData)
            .filter(key => key !== 'id')
            .map(key => `${key} = ?`)
            .join(', ');
          const updateValues = Object.entries(itemData)
            .filter(([key]) => key !== 'id')
            .map(([, value]) => value);

          await window.electronAPI.dbRun(
            `UPDATE ${referenceType.tableName} SET ${updateColumns}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
            [...updateValues, editingItem.id]
          );
        } else {
          // Insert new
          const id = `${referenceType.id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          await window.electronAPI.dbRun(
            `INSERT INTO ${referenceType.tableName} (id, ${columns}) VALUES (?, ${placeholders})`,
            [id, ...values]
          );
        }
      } else {
        // Browser fallback
        const stored = localStorage.getItem(`ref_${referenceType.id}`) || '[]';
        let dataArray = JSON.parse(stored);
        
        if (editingItem) {
          dataArray = dataArray.map((item: any) => 
            item.id === editingItem.id ? { ...item, ...itemData } : item
          );
        } else {
          const newItem = {
            ...itemData,
            id: `${referenceType.id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            created_at: new Date().toISOString()
          };
          dataArray.push(newItem);
        }
        
        localStorage.setItem(`ref_${referenceType.id}`, JSON.stringify(dataArray));
      }

      await loadData();
      return true;
    } catch (error) {
      console.error('Failed to save data:', error);
      throw error;
    }
  };

  const deleteData = async (itemId: string) => {
    try {
      if (window.electronAPI) {
        await window.electronAPI.dbRun(
          `DELETE FROM ${referenceType.tableName} WHERE id = ?`,
          [itemId]
        );
      } else {
        const stored = localStorage.getItem(`ref_${referenceType.id}`) || '[]';
        const dataArray = JSON.parse(stored);
        const filtered = dataArray.filter((item: any) => item.id !== itemId);
        localStorage.setItem(`ref_${referenceType.id}`, JSON.stringify(filtered));
      }

      await loadData();
      setSelectedItems(prev => {
        const newSet = new Set(prev);
        newSet.delete(itemId);
        return newSet;
      });
    } catch (error) {
      console.error('Failed to delete data:', error);
      throw error;
    }
  };

  const filteredData = data.filter(item =>
    referenceType.fields.some(field =>
      String(item[field.name] || '').toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const handleAdd = () => {
    setEditingItem(null);
    setFormData({});
    setIsDialogOpen(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setFormData({ ...item });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      // Validate required fields
      const missingFields = referenceType.fields
        .filter(field => field.required && !formData[field.name])
        .map(field => field.name);

      if (missingFields.length > 0) {
        toast({
          title: "Validation Error",
          description: `Required fields missing: ${missingFields.join(', ')}`,
          variant: "destructive"
        });
        return;
      }

      await saveData(formData);
      toast({
        title: "Success",
        description: `${referenceType.name} ${editingItem ? 'updated' : 'created'} successfully`
      });
      setIsDialogOpen(false);
      setFormData({});
      setEditingItem(null);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to save ${referenceType.name}`,
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (item: any) => {
    if (confirm(`Are you sure you want to delete this ${referenceType.name}?`)) {
      try {
        await deleteData(item.id);
        toast({
          title: "Success",
          description: `${referenceType.name} deleted successfully`
        });
      } catch (error) {
        toast({
          title: "Error",
          description: `Failed to delete ${referenceType.name}`,
          variant: "destructive"
        });
      }
    }
  };

  const handleBulkDelete = async () => {
    if (selectedItems.size === 0) return;
    
    if (confirm(`Are you sure you want to delete ${selectedItems.size} items?`)) {
      try {
        for (const itemId of selectedItems) {
          await deleteData(itemId);
        }
        toast({
          title: "Success",
          description: `${selectedItems.size} items deleted successfully`
        });
        setSelectedItems(new Set());
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete items",
          variant: "destructive"
        });
      }
    }
  };

  const handleInlineEdit = (item: any) => {
    setInlineEditItem(item.id);
    setTempEditData({ ...item });
  };

  const handleInlineSave = async (itemId: string) => {
    try {
      await saveData(tempEditData);
      setInlineEditItem(null);
      setTempEditData({});
      toast({
        title: "Success",
        description: "Item updated successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update item",
        variant: "destructive"
      });
    }
  };

  const handleInlineCancel = () => {
    setInlineEditItem(null);
    setTempEditData({});
  };

  const renderFieldInput = (field: FieldDefinition, value: any, onChange: (value: any) => void) => {
    switch (field.type) {
      case 'number':
        return (
          <Input
            type="number"
            value={value || ''}
            onChange={(e) => onChange(e.target.value ? Number(e.target.value) : '')}
          />
        );
      case 'date':
        return (
          <Input
            type="date"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
          />
        );
      case 'boolean':
        return (
          <Switch
            checked={value || false}
            onCheckedChange={onChange}
          />
        );
      case 'select':
        return (
          <Select value={value || ''} onValueChange={onChange}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map(option => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      default:
        return (
          <Input
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
          />
        );
    }
  };

  const renderCellValue = (field: FieldDefinition, value: any) => {
    switch (field.type) {
      case 'boolean':
        return value ? (
          <Badge variant="default">Yes</Badge>
        ) : (
          <Badge variant="secondary">No</Badge>
        );
      case 'date':
        return value ? new Date(value).toLocaleDateString() : '';
      default:
        return String(value || '');
    }
  };

  const toggleSelectItem = (itemId: string) => {
    const newSet = new Set(selectedItems);
    if (newSet.has(itemId)) {
      newSet.delete(itemId);
    } else {
      newSet.add(itemId);
    }
    setSelectedItems(newSet);
  };

  const selectAllItems = () => {
    if (selectedItems.size === filteredData.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(filteredData.map(item => item.id)));
    }
  };

  return (
    <div className="space-y-4">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={`Search ${referenceType.name}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 w-64"
            />
          </div>
          {selectedItems.size > 0 && (
            <Button variant="destructive" onClick={handleBulkDelete}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Selected ({selectedItems.size})
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={loadData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={handleAdd}>
            <Plus className="h-4 w-4 mr-2" />
            Add {referenceType.name}
          </Button>
        </div>
      </div>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>{referenceType.name}</CardTitle>
          <CardDescription>
            {filteredData.length} of {data.length} items
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-muted-foreground">Loading...</div>
            </div>
          ) : filteredData.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No data found</p>
              <Button variant="outline" onClick={handleAdd} className="mt-4">
                Add First {referenceType.name}
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedItems.size === filteredData.length}
                      onCheckedChange={selectAllItems}
                    />
                  </TableHead>
                  {referenceType.fields.map(field => (
                    <TableHead key={field.id}>{field.name}</TableHead>
                  ))}
                  <TableHead className="w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.map(item => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedItems.has(item.id)}
                        onCheckedChange={() => toggleSelectItem(item.id)}
                      />
                    </TableCell>
                    {referenceType.fields.map(field => (
                      <TableCell key={field.id}>
                        {inlineEditItem === item.id ? (
                          <div className="min-w-32">
                            {renderFieldInput(
                              field,
                              tempEditData[field.name],
                              (value) => setTempEditData(prev => ({ ...prev, [field.name]: value }))
                            )}
                          </div>
                        ) : (
                          <span 
                            className="cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5"
                            onClick={() => handleInlineEdit(item)}
                          >
                            {renderCellValue(field, item[field.name])}
                          </span>
                        )}
                      </TableCell>
                    ))}
                    <TableCell>
                      {inlineEditItem === item.id ? (
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleInlineSave(item.id)}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleInlineCancel}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(item)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? 'Edit' : 'Add'} {referenceType.name}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {referenceType.fields.map(field => (
              <div key={field.id} className="space-y-2">
                <Label>
                  {field.name}
                  {field.required && <span className="text-destructive ml-1">*</span>}
                </Label>
                {renderFieldInput(
                  field,
                  formData[field.name],
                  (value) => setFormData(prev => ({ ...prev, [field.name]: value }))
                )}
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {editingItem ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}