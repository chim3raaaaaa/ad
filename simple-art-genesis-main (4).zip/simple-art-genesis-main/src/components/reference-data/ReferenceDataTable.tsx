import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, Edit, Trash2, RefreshCw } from 'lucide-react';
import { referenceDataBrainService } from '@/lib/services/ReferenceDataBrainService';

type ReferenceDataBrainService = typeof referenceDataBrainService;

interface ReferenceDataTableProps {
  title: string;
  description: string;
  dataType: string;
  service: ReferenceDataBrainService;
}

export function ReferenceDataTable({ title, description, dataType, service }: ReferenceDataTableProps) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      let result: any[] = [];
      switch (dataType) {
        case 'plants':
          result = await service.getPlants();
          break;
        case 'officers':
          result = await service.getOfficers();
          break;
        case 'productCategories':
          result = await service.getProductCategories();
          break;
        case 'products':
          result = await service.getProducts();
          break;
        case 'testTypes':
          result = await service.getTestTypes();
          break;
        case 'machines':
          result = await service.getMachines();
          break;
        case 'materials':
          result = await service.getMaterials();
          break;
        default:
          result = [];
      }
      
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
      console.error(`Error fetching ${dataType}:`, err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [dataType, service]);

  const handleRefresh = () => {
    service.invalidateCache(dataType);
    fetchData();
  };

  const renderTableHeaders = () => {
    switch (dataType) {
      case 'plants':
        return (
          <TableRow>
            <TableHead>Code</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        );
      case 'officers':
        return (
          <TableRow>
            <TableHead>Code</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        );
      case 'productCategories':
        return (
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>Sort Order</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        );
      case 'products':
        return (
          <TableRow>
            <TableHead>Code</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Unit</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        );
      default:
        return (
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        );
    }
  };

  const renderTableRow = (item: any, index: number) => {
    const isActive = item.is_active !== false && item.status !== 'inactive';
    
    switch (dataType) {
      case 'plants':
        return (
          <TableRow key={item.id || index}>
            <TableCell className="font-mono text-sm">{item.code}</TableCell>
            <TableCell className="font-medium">{item.name}</TableCell>
            <TableCell>{item.location || '-'}</TableCell>
            <TableCell>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        );
      case 'officers':
        return (
          <TableRow key={item.id || index}>
            <TableCell className="font-mono text-sm">{item.code}</TableCell>
            <TableCell className="font-medium">{item.name}</TableCell>
            <TableCell>{item.department_id || '-'}</TableCell>
            <TableCell>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        );
      case 'productCategories':
        return (
          <TableRow key={item.id || index}>
            <TableCell className="font-medium">{item.name}</TableCell>
            <TableCell>{item.description || '-'}</TableCell>
            <TableCell>{item.sort_order || 0}</TableCell>
            <TableCell>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        );
      case 'products':
        return (
          <TableRow key={item.id || index}>
            <TableCell className="font-mono text-sm">{item.code}</TableCell>
            <TableCell className="font-medium">{item.name}</TableCell>
            <TableCell>{item.category_id || '-'}</TableCell>
            <TableCell>{item.unit || '-'}</TableCell>
            <TableCell>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        );
      default:
        return (
          <TableRow key={item.id || index}>
            <TableCell className="font-medium">{item.name || 'Unknown'}</TableCell>
            <TableCell>{item.description || '-'}</TableCell>
            <TableCell>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? 'Active' : 'Inactive'}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        );
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Loading {title.toLowerCase()}...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          <CardDescription className="text-destructive">{error}</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={handleRefresh} variant="outline">
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleRefresh} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Add New
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No {title.toLowerCase()} found.</p>
            <Button className="mt-2" size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Add First {title.slice(0, -1)}
            </Button>
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                {renderTableHeaders()}
              </TableHeader>
              <TableBody>
                {data.map((item, index) => renderTableRow(item, index))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}