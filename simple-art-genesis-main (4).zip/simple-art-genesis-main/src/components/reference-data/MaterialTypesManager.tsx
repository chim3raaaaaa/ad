import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localReferenceDataService } from '@/services/storage/localReferenceDataService';

interface MaterialType {
  id: number;
  name: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function MaterialTypesManager() {
  const [materialTypes, setMaterialTypes] = useState<MaterialType[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '' });

  const { toast } = useToast();

  useEffect(() => {
    loadMaterialTypes();
  }, []);

  const loadMaterialTypes = async () => {
    try {
      setLoading(true);
      const data = await localReferenceDataService.getMaterialTypes();
      setMaterialTypes(data);
    } catch (error) {
      console.error('Error loading material types:', error);
      toast({
        title: "Error",
        description: "Failed to load material types",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Error",
        description: "Material type name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      await localReferenceDataService.saveMaterialType(formData);
      
      toast({
        title: "Success",
        description: "Material type created successfully"
      });

      setFormData({ name: '', description: '' });
      setShowCreateModal(false);
      loadMaterialTypes();
    } catch (error) {
      console.error('Error saving material type:', error);
      toast({
        title: "Error",
        description: "Failed to save material type. It may already exist.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (materialType: MaterialType) => {
    if (!confirm(`Are you sure you want to delete "${materialType.name}"?`)) {
      return;
    }

    try {
      await localReferenceDataService.deleteMaterialType(materialType.id.toString());
      
      toast({
        title: "Success",
        description: "Material type deleted successfully"
      });

      loadMaterialTypes();
    } catch (error) {
      console.error('Error deleting material type:', error);
      toast({
        title: "Error",
        description: "Failed to delete material type",
        variant: "destructive"
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5" />
            <div>
              <CardTitle>Material Types</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage material types for sieve grading limits
              </p>
            </div>
          </div>
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Material Type
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Create Material Type</DialogTitle>
                  <DialogDescription>
                    Add a new material type for aggregate testing
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., 4-6mm, All-in 0-31.5mm"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Additional details about this material type"
                      rows={3}
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={loading}>
                    {loading ? 'Creating...' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading && materialTypes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Loading material types...
          </div>
        ) : materialTypes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No material types defined yet. Click "Add Material Type" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {materialTypes.map((materialType) => (
                <TableRow key={materialType.id}>
                  <TableCell className="font-medium">{materialType.name}</TableCell>
                  <TableCell>{materialType.description || '-'}</TableCell>
                  <TableCell>{new Date(materialType.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(materialType)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}