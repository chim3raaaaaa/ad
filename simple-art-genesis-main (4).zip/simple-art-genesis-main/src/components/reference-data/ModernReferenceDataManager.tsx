// Modern Reference Data Manager with local-first sync
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Plus, 
  RefreshCw, 
  Database, 
  AlertTriangle, 
  CheckCircle,
  WifiOff,
  Wifi,
  Clock,
  GitMerge,
  Settings,
  Download,
  Upload
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { modernReferenceDataService } from '@/services/reference-data/modernReferenceDataService';
import { backgroundSyncService } from '@/services/sync/backgroundSyncService';
import { DatasetDefinition, SyncStatus, SyncProgress, SyncConflict } from '@/services/sync/syncTypes';
import { DynamicDatasetManager } from './DynamicDatasetManager';
import { DatasetDefinitionEditor } from './DatasetDefinitionEditor';
import { SyncStatusPanel } from './SyncStatusPanel';
import { ConflictResolutionDialog } from './ConflictResolutionDialog';
import { CSVImportDialog } from './CSVImportDialog';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

export const ModernReferenceDataManager: React.FC = () => {
  const [datasets, setDatasets] = useState<DatasetDefinition[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [syncProgress, setSyncProgress] = useState<SyncProgress | null>(null);
  const [conflicts, setConflicts] = useState<SyncConflict[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<DatasetDefinition | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isConflictDialogOpen, setIsConflictDialogOpen] = useState(false);
  const [selectedConflict, setSelectedConflict] = useState<SyncConflict | null>(null);
  const [isCSVDialogOpen, setIsCSVDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
    setupSyncCallbacks();
    
    // Cleanup on unmount
    return () => {
      backgroundSyncService.onProgress(() => {});
      backgroundSyncService.onStatusChange(() => {});
    };
  }, []);

  const setupSyncCallbacks = () => {
    backgroundSyncService.onProgress((progress: SyncProgress) => {
      setSyncProgress(progress);
      
      if (progress.stage === 'complete') {
        if (progress.progress === 100) {
          toast({
            title: "Sync Complete",
            description: progress.message,
          });
        } else {
          toast({
            title: "Sync Failed",
            description: progress.message,
            variant: "destructive"
          });
        }
        setTimeout(() => setSyncProgress(null), 3000);
      }
    });

    backgroundSyncService.onStatusChange((status: SyncStatus) => {
      setSyncStatus(status);
    });
  };

  const loadData = async () => {
    try {
      setLoading(true);
      const [datasetsData, statusData, conflictsData] = await Promise.all([
        modernReferenceDataService.getDatasetDefinitions(),
        modernReferenceDataService.getSyncStatus(),
        modernReferenceDataService.getConflicts()
      ]);
      
      setDatasets(datasetsData);
      setSyncStatus(statusData);
      setConflicts(conflictsData);
    } catch (error) {
      toast({
        title: "Error Loading Data",
        description: error instanceof Error ? error.message : "Failed to load reference data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDataset = async (definition: Omit<DatasetDefinition, 'id' | 'created_at' | 'updated_at' | 'version'>) => {
    try {
      await modernReferenceDataService.createDatasetDefinition(definition);
      await loadData();
      setIsCreateDialogOpen(false);
      toast({
        title: "Dataset Created",
        description: `Dataset "${definition.name}" has been created successfully.`
      });
    } catch (error) {
      toast({
        title: "Error Creating Dataset",
        description: error instanceof Error ? error.message : "Failed to create dataset",
        variant: "destructive"
      });
    }
  };

  const handleDeleteDataset = async (id: string) => {
    try {
      await modernReferenceDataService.deleteDatasetDefinition(id);
      await loadData();
      toast({
        title: "Dataset Deleted",
        description: "Dataset has been deleted successfully."
      });
    } catch (error) {
      toast({
        title: "Error Deleting Dataset",
        description: error instanceof Error ? error.message : "Failed to delete dataset",
        variant: "destructive"
      });
    }
  };

  const handleSyncNow = async () => {
    try {
      await modernReferenceDataService.forceSyncNow();
      toast({
        title: "Sync Started",
        description: "Synchronization with server has been initiated."
      });
    } catch (error) {
      toast({
        title: "Sync Failed",
        description: error instanceof Error ? error.message : "Failed to start synchronization",
        variant: "destructive"
      });
    }
  };

  const handleConflictSelect = (conflict: SyncConflict) => {
    setSelectedConflict(conflict);
    setIsConflictDialogOpen(true);
  };

  const handleConflictResolve = async (
    conflictId: string,
    resolution: 'local' | 'remote' | 'merge',
    mergedData?: any
  ) => {
    try {
      await modernReferenceDataService.resolveConflict(conflictId, resolution, mergedData);
      await loadData();
      setIsConflictDialogOpen(false);
      toast({
        title: "Conflict Resolved",
        description: "The data conflict has been resolved successfully."
      });
    } catch (error) {
      toast({
        title: "Error Resolving Conflict",
        description: error instanceof Error ? error.message : "Failed to resolve conflict",
        variant: "destructive"
      });
    }
  };

  const renderSyncStatusBadge = () => {
    if (!syncStatus) return null;

    const { connection_status, server_reachable, is_syncing, pending_operations, conflicts } = syncStatus;
    
    if (is_syncing) {
      return <Badge variant="secondary"><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Syncing...</Badge>;
    }
    
    if (!server_reachable) {
      return <Badge variant="destructive"><WifiOff className="w-3 h-3 mr-1" />Offline</Badge>;
    }
    
    if (conflicts > 0) {
      return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" />{conflicts} Conflicts</Badge>;
    }
    
    if (pending_operations > 0) {
      return <Badge variant="outline"><Clock className="w-3 h-3 mr-1" />{pending_operations} Pending</Badge>;
    }
    
    return <Badge variant="default"><CheckCircle className="w-3 h-3 mr-1" />Synced</Badge>;
  };

  const groupDatasetsByCategory = (datasets: DatasetDefinition[]) => {
    return datasets.reduce((acc, dataset) => {
      if (!acc[dataset.category]) {
        acc[dataset.category] = [];
      }
      acc[dataset.category].push(dataset);
      return acc;
    }, {} as Record<string, DatasetDefinition[]>);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin" />
        <span className="ml-2">Loading reference data...</span>
      </div>
    );
  }

  const groupedDatasets = groupDatasetsByCategory(datasets);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Reference Data Manager</h1>
          <p className="text-muted-foreground">
            Manage datasets with local-first synchronization
          </p>
        </div>
        <div className="flex items-center space-x-2">
          {renderSyncStatusBadge()}
          <Button onClick={handleSyncNow} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Sync Now
          </Button>
          <PermissionWrapper permission="manage_reference_data">
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New Dataset
            </Button>
          </PermissionWrapper>
        </div>
      </div>

      {/* Sync Progress */}
      {syncProgress && (
        <Alert>
          <RefreshCw className="w-4 h-4 animate-spin" />
          <AlertDescription>
            {syncProgress.message} ({syncProgress.progress}/{syncProgress.total})
          </AlertDescription>
        </Alert>
      )}

      {/* Conflicts Alert */}
      {conflicts.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            {conflicts.length} data conflicts need resolution.{' '}
            <Button 
              variant="link" 
              className="p-0 h-auto"
              onClick={() => setIsConflictDialogOpen(true)}
            >
              View conflicts
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="datasets" className="w-full">
        <TabsList>
          <TabsTrigger value="datasets">Datasets</TabsTrigger>
          <TabsTrigger value="sync">Sync Status</TabsTrigger>
          <TabsTrigger value="import">Import/Export</TabsTrigger>
        </TabsList>

        <TabsContent value="datasets" className="space-y-6">
          {Object.entries(groupedDatasets).map(([category, categoryDatasets]) => (
            <Card key={category}>
              <CardHeader>
                <CardTitle className="capitalize">{category.replace('_', ' ')}</CardTitle>
                <CardDescription>
                  {categoryDatasets.length} dataset{categoryDatasets.length !== 1 ? 's' : ''}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryDatasets.map((dataset) => (
                    <Card 
                      key={dataset.id} 
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedDataset(dataset)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{dataset.name}</CardTitle>
                          <Database className="w-5 h-5 text-muted-foreground" />
                        </div>
                        <CardDescription>{dataset.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">
                            {dataset.fields.length} fields
                          </span>
                          <Badge variant="outline">v{dataset.version}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}

          {datasets.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Database className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Datasets Found</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first dataset to get started with reference data management.
                </p>
                <PermissionWrapper permission="manage_reference_data">
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Dataset
                  </Button>
                </PermissionWrapper>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="sync">
          <SyncStatusPanel 
            status={syncStatus}
            onSyncNow={handleSyncNow}
            onViewConflicts={() => setIsConflictDialogOpen(true)}
          />
        </TabsContent>

        <TabsContent value="import">
          <Card>
            <CardHeader>
              <CardTitle>Import & Export</CardTitle>
              <CardDescription>
                Bulk import data from CSV files or export existing data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Button onClick={() => setIsCSVDialogOpen(true)} variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Import CSV
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dataset Manager Dialog */}
      {selectedDataset && (
        <DynamicDatasetManager
          dataset={selectedDataset}
          open={!!selectedDataset}
          onClose={() => setSelectedDataset(null)}
          onDelete={() => handleDeleteDataset(selectedDataset.id)}
        />
      )}

      {/* Dataset Definition Editor */}
      <DatasetDefinitionEditor
        open={isCreateDialogOpen}
        onClose={() => setIsCreateDialogOpen(false)}
        onSave={handleCreateDataset}
      />

      {/* Conflict Resolution Dialog */}
      <ConflictResolutionDialog
        open={isConflictDialogOpen}
        onClose={() => setIsConflictDialogOpen(false)}
        conflicts={conflicts}
        onResolve={handleConflictResolve}
        onSelectConflict={handleConflictSelect}
      />

      {/* CSV Import Dialog */}
      <CSVImportDialog
        open={isCSVDialogOpen}
        onClose={() => setIsCSVDialogOpen(false)}
        datasets={datasets}
        onImportComplete={loadData}
      />
    </div>
  );
};