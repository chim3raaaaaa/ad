// Dynamic dataset manager for CRUD operations on reference data
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  AlertTriangle,
  CheckCircle,
  X
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { modernReferenceDataService, ReferenceDataItem } from '@/services/reference-data/modernReferenceDataService';
import { DatasetDefinition, FieldDefinition } from '@/services/sync/syncTypes';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface DynamicDatasetManagerProps {
  dataset: DatasetDefinition;
  open: boolean;
  onClose: () => void;
  onDelete: () => void;
}

interface ItemFormData {
  [key: string]: any;
}

export const DynamicDatasetManager: React.FC<DynamicDatasetManagerProps> = ({
  dataset,
  open,
  onClose,
  onDelete
}) => {
  const [items, setItems] = useState<ReferenceDataItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<ReferenceDataItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItem, setSelectedItem] = useState<ReferenceDataItem | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formData, setFormData] = useState<ItemFormData>({});
  const [loading, setLoading] = useState(true);
  const [isEditMode, setIsEditMode] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadItems();
    }
  }, [open, dataset]);

  useEffect(() => {
    filterItems();
  }, [items, searchTerm]);

  const loadItems = async () => {
    try {
      setLoading(true);
      const data = await modernReferenceDataService.getTableData(dataset.table_name);
      setItems(data);
    } catch (error) {
      toast({
        title: "Error Loading Data",
        description: error instanceof Error ? error.message : "Failed to load data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filterItems = () => {
    if (!searchTerm) {
      setFilteredItems(items);
      return;
    }

    const filtered = items.filter(item => {
      return dataset.fields.some(field => {
        const value = item[field.name];
        return value && value.toString().toLowerCase().includes(searchTerm.toLowerCase());
      });
    });

    setFilteredItems(filtered);
  };

  const handleCreateItem = () => {
    const initialData: ItemFormData = {};
    dataset.fields.forEach(field => {
      if (field.default_value !== undefined) {
        initialData[field.name] = field.default_value;
      } else {
        initialData[field.name] = field.type === 'boolean' ? false : '';
      }
    });

    setFormData(initialData);
    setIsEditMode(false);
    setIsFormOpen(true);
  };

  const handleEditItem = (item: ReferenceDataItem) => {
    const editData: ItemFormData = {};
    dataset.fields.forEach(field => {
      editData[field.name] = item[field.name] || '';
    });

    setFormData(editData);
    setSelectedItem(item);
    setIsEditMode(true);
    setIsFormOpen(true);
  };

  const handleDeleteItem = async (item: ReferenceDataItem) => {
    if (!confirm(`Are you sure you want to delete "${item[getDisplayField()]}"?`)) {
      return;
    }

    try {
      await modernReferenceDataService.deleteTableItem(dataset.table_name, item.id);
      await loadItems();
      toast({
        title: "Item Deleted",
        description: "The item has been deleted successfully."
      });
    } catch (error) {
      toast({
        title: "Error Deleting Item",
        description: error instanceof Error ? error.message : "Failed to delete item",
        variant: "destructive"
      });
    }
  };

  const handleFormSubmit = async () => {
    try {
      if (isEditMode && selectedItem) {
        await modernReferenceDataService.updateTableItem(
          dataset.table_name,
          selectedItem.id,
          formData
        );
        toast({
          title: "Item Updated",
          description: "The item has been updated successfully."
        });
      } else {
        await modernReferenceDataService.createTableItem(dataset.table_name, formData);
        toast({
          title: "Item Created",
          description: "The item has been created successfully."
        });
      }

      await loadItems();
      setIsFormOpen(false);
      setFormData({});
      setSelectedItem(null);
    } catch (error) {
      toast({
        title: isEditMode ? "Error Updating Item" : "Error Creating Item",
        description: error instanceof Error ? error.message : "Operation failed",
        variant: "destructive"
      });
    }
  };

  const handleFormCancel = () => {
    setIsFormOpen(false);
    setFormData({});
    setSelectedItem(null);
    setIsEditMode(false);
  };

  const handleInputChange = (fieldName: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const renderFormField = (field: FieldDefinition) => {
    const value = formData[field.name] || '';

    switch (field.type) {
      case 'select':
        return (
          <select
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            required={field.required}
          >
            <option value="">Select {field.name}</option>
            {field.options?.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );

      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={Boolean(value)}
              onChange={(e) => handleInputChange(field.name, e.target.checked)}
              className="rounded border-input"
            />
            <span className="text-sm">Yes</span>
          </div>
        );

      case 'number':
        return (
          <Input
            type="number"
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            required={field.required}
          />
        );

      case 'date':
        return (
          <Input
            type="date"
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            required={field.required}
          />
        );

      default:
        return (
          <Input
            type="text"
            value={value}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            required={field.required}
          />
        );
    }
  };

  const getDisplayField = (): string => {
    // Try to find a 'name' field, otherwise use the first text field
    const nameField = dataset.fields.find(f => f.name.toLowerCase() === 'name');
    if (nameField) return nameField.name;
    
    const textField = dataset.fields.find(f => f.type === 'text');
    return textField?.name || 'id';
  };

  const formatCellValue = (value: any, field: FieldDefinition): string => {
    if (value === null || value === undefined) return '';
    
    switch (field.type) {
      case 'boolean':
        return value ? 'Yes' : 'No';
      case 'date':
        return new Date(value).toLocaleDateString();
      default:
        return value.toString();
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle>{dataset.name}</DialogTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {dataset.description}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline">
                  {items.length} item{items.length !== 1 ? 's' : ''}
                </Badge>
                <PermissionWrapper permission="manage_reference_data">
                  <Button onClick={handleCreateItem} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Item
                  </Button>
                </PermissionWrapper>
              </div>
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-hidden flex flex-col space-y-4">
            {/* Search */}
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Data Table */}
            <div className="flex-1 overflow-auto border rounded-md">
              {loading ? (
                <div className="flex items-center justify-center h-32">
                  <span>Loading...</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      {dataset.fields.map(field => (
                        <TableHead key={field.id}>{field.name}</TableHead>
                      ))}
                      <TableHead className="w-24">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredItems.map(item => (
                      <TableRow key={item.id}>
                        {dataset.fields.map(field => (
                          <TableCell key={field.id}>
                            {formatCellValue(item[field.name], field)}
                          </TableCell>
                        ))}
                        <TableCell>
                          <div className="flex space-x-1">
                            <PermissionWrapper permission="edit_reference_data">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleEditItem(item)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </PermissionWrapper>
                            <PermissionWrapper permission="delete_reference_data">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteItem(item)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </PermissionWrapper>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredItems.length === 0 && !loading && (
                      <TableRow>
                        <TableCell 
                          colSpan={dataset.fields.length + 1} 
                          className="text-center py-8 text-muted-foreground"
                        >
                          {searchTerm ? 'No items match your search' : 'No items found'}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>

          <DialogFooter>
            <PermissionWrapper permission="delete_reference_data">
              <Button variant="destructive" onClick={onDelete}>
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Dataset
              </Button>
            </PermissionWrapper>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Item Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={handleFormCancel}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? 'Edit Item' : 'Create Item'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 max-h-96 overflow-auto">
            {dataset.fields.map(field => (
              <div key={field.id} className="space-y-2">
                <Label htmlFor={field.name}>
                  {field.name}
                  {field.required && <span className="text-destructive ml-1">*</span>}
                </Label>
                {renderFormField(field)}
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={handleFormCancel}>
              Cancel
            </Button>
            <Button onClick={handleFormSubmit}>
              {isEditMode ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};