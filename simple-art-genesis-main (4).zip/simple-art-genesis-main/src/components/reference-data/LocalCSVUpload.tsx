import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileText, Upload, AlertCircle, CheckCircle, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localReferenceDataService } from '@/services/storage/localReferenceDataService';

interface UploadStatus {
  filename: string;
  status: 'uploading' | 'success' | 'error';
  progress: number;
  rowsImported?: number;
  errors?: string[];
  timestamp: Date;
}

const REFERENCE_TABLES = [
  { value: 'product_categories', label: 'Product Categories', description: 'Product classification and categories' },
  { value: 'products', label: 'Products', description: 'Product master data' },
  { value: 'grades', label: 'Grades', description: 'Material grades and specifications' },
  { value: 'plants', label: 'Plants', description: 'Manufacturing plants and facilities' },
  { value: 'suppliers', label: 'Suppliers', description: 'Supplier contact information' }
];

export function LocalCSVUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [uploadStatus, setUploadStatus] = useState<UploadStatus | null>(null);
  const [uploadHistory, setUploadHistory] = useState<any[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const { toast } = useToast();

  const loadUploadHistory = useCallback(async () => {
    try {
      const history = await localReferenceDataService.getUploadHistory();
      setUploadHistory(history);
    } catch (error) {
      console.error('Failed to load upload history:', error);
    }
  }, []);

  React.useEffect(() => {
    loadUploadHistory();
  }, [loadUploadHistory]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const csvFile = files.find(file => file.name.toLowerCase().endsWith('.csv'));
    
    if (csvFile) {
      setSelectedFile(csvFile);
    } else {
      toast({
        title: "Invalid File",
        description: "Please upload a CSV file",
        variant: "destructive"
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.toLowerCase().endsWith('.csv')) {
      setSelectedFile(file);
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a CSV file",
        variant: "destructive"
      });
    }
  };

  const parseCSV = (text: string): any[] => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length === 0) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      if (values.some(v => v)) { // Skip empty rows
        const row: any = {};
        headers.forEach((header, index) => {
          row[header.toLowerCase().replace(/\s+/g, '_')] = values[index] || '';
        });
        data.push(row);
      }
    }

    return data;
  };

  const handleUpload = async () => {
    if (!selectedFile || !selectedTable) {
      toast({
        title: "Missing Information",
        description: "Please select both a file and target table",
        variant: "destructive"
      });
      return;
    }

    setUploadStatus({
      filename: selectedFile.name,
      status: 'uploading',
      progress: 0,
      timestamp: new Date()
    });

    try {
      const text = await selectedFile.text();
      const csvData = parseCSV(text);

      if (csvData.length === 0) {
        throw new Error('No valid data found in CSV file');
      }

      // Simulate progress updates
      setUploadStatus(prev => prev ? { ...prev, progress: 25 } : null);

      const result = await localReferenceDataService.uploadCSV(selectedTable, csvData);

      setUploadStatus(prev => prev ? { 
        ...prev, 
        status: result.success ? 'success' : 'error',
        progress: 100,
        rowsImported: result.rowsImported,
        errors: result.errors
      } : null);

      if (result.success) {
        toast({
          title: "Upload Successful",
          description: `Imported ${result.rowsImported} rows into ${selectedTable}`
        });
      } else {
        toast({
          title: "Upload Completed with Errors",
          description: `Imported ${result.rowsImported} rows, but some had errors`,
          variant: "destructive"
        });
      }

      // Refresh upload history
      await loadUploadHistory();
      
      // Reset form
      setSelectedFile(null);
      setSelectedTable('');
      
    } catch (error) {
      console.error('Upload failed:', error);
      setUploadStatus(prev => prev ? { 
        ...prev, 
        status: 'error',
        progress: 100,
        errors: [error instanceof Error ? error.message : 'Unknown error']
      } : null);

      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive"
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'partial': return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const downloadSampleCSV = (tableName: string) => {
    const sampleData: Record<string, string> = {
      'product_categories': 'code,name,description,is_active\nCAT001,Concrete Products,Various concrete products,1\nCAT002,Masonry Products,Bricks and blocks,1',
      'products': 'code,name,category_id,description,unit_of_measure,is_active\nPROD001,Standard Brick,CAT002,Standard clay brick,piece,1\nPROD002,Concrete Block,CAT001,Standard concrete block,piece,1',
      'grades': 'code,name,product_type,specifications,is_active\nGRADE001,Grade A,concrete,"{\\"strength\\": \\"25MPa\\"}",1\nGRADE002,Grade B,masonry,"{\\"compression\\": \\"15MPa\\"}",1',
      'plants': 'code,name,location,contact_info,is_active\nPLANT001,Main Plant,City A,"{\\"phone\\": \\"123-456-7890\\"}",1\nPLANT002,Secondary Plant,City B,"{\\"phone\\": \\"098-765-4321\\"}",1',
      'suppliers': 'code,name,contact_person,email,phone,address,is_active\nSUP001,ABC Supplies,John Doe,john@abc.com,123-456-7890,123 Main St,1\nSUP002,XYZ Materials,Jane Smith,jane@xyz.com,098-765-4321,456 Oak Ave,1'
    };

    const csvContent = sampleData[tableName] || 'code,name,description\nSAMPLE001,Sample Item,Sample description';
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tableName}_sample.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            CSV Data Upload
          </CardTitle>
          <CardDescription>
            Upload CSV files to populate reference data tables in your local database
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Target Table Selection */}
          <div className="space-y-2">
            <Label htmlFor="table-select">Target Table</Label>
            <Select value={selectedTable} onValueChange={setSelectedTable}>
              <SelectTrigger>
                <SelectValue placeholder="Select a reference table" />
              </SelectTrigger>
              <SelectContent>
                {REFERENCE_TABLES.map(table => (
                  <SelectItem key={table.value} value={table.value}>
                    <div>
                      <div className="font-medium">{table.label}</div>
                      <div className="text-sm text-muted-foreground">{table.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedTable && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => downloadSampleCSV(selectedTable)}
                className="mt-2"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Sample CSV
              </Button>
            )}
          </div>

          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="file-upload">CSV File</Label>
            <div
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                isDragOver 
                  ? 'border-primary bg-primary/5' 
                  : 'border-muted-foreground/25 hover:border-muted-foreground/50'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              {selectedFile ? (
                <div className="space-y-2">
                  <FileText className="h-8 w-8 mx-auto text-green-600" />
                  <p className="font-medium">{selectedFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </p>
                  <Button variant="outline" size="sm" onClick={() => setSelectedFile(null)}>
                    Remove File
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
                  <p className="text-sm">Drag and drop your CSV file here, or</p>
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".csv"
                    onChange={handleFileSelect}
                    className="max-w-xs mx-auto"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Upload Button */}
          <Button 
            onClick={handleUpload} 
            disabled={!selectedFile || !selectedTable || uploadStatus?.status === 'uploading'}
            className="w-full"
          >
            {uploadStatus?.status === 'uploading' ? 'Uploading...' : 'Upload CSV'}
          </Button>

          {/* Upload Progress */}
          {uploadStatus && (
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{uploadStatus.filename}</span>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(uploadStatus.status)}
                      <Badge variant={uploadStatus.status === 'success' ? 'default' : 'destructive'}>
                        {uploadStatus.status}
                      </Badge>
                    </div>
                  </div>
                  
                  {uploadStatus.status === 'uploading' && (
                    <Progress value={uploadStatus.progress} className="w-full" />
                  )}
                  
                  {uploadStatus.rowsImported !== undefined && (
                    <p className="text-sm text-muted-foreground">
                      Imported {uploadStatus.rowsImported} rows
                    </p>
                  )}
                  
                  {uploadStatus.errors && uploadStatus.errors.length > 0 && (
                    <div className="text-sm text-red-600">
                      <p className="font-medium">Errors:</p>
                      <ul className="list-disc list-inside">
                        {uploadStatus.errors.slice(0, 5).map((error, index) => (
                          <li key={index}>{error}</li>
                        ))}
                        {uploadStatus.errors.length > 5 && (
                          <li>... and {uploadStatus.errors.length - 5} more errors</li>
                        )}
                      </ul>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Upload History */}
      <Card>
        <CardHeader>
          <CardTitle>Upload History</CardTitle>
          <CardDescription>
            Recent CSV uploads and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {uploadHistory.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              No uploads yet
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>File</TableHead>
                  <TableHead>Table</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Rows</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {uploadHistory.map((upload, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{upload.filename}</TableCell>
                    <TableCell>{upload.table_name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(upload.status)}
                        <Badge variant={upload.status === 'success' ? 'default' : 'destructive'}>
                          {upload.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>{upload.rows_imported || 0}</TableCell>
                    <TableCell>
                      {new Date(upload.upload_timestamp).toLocaleDateString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}