import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DatasetDefinition, FieldDefinition } from '@/services/sync/syncTypes';

interface DatasetDefinitionEditorProps {
  open: boolean;
  onClose: () => void;
  onSave: (definition: Omit<DatasetDefinition, 'id' | 'created_at' | 'updated_at' | 'version'>) => void;
}

export const DatasetDefinitionEditor: React.FC<DatasetDefinitionEditorProps> = ({
  open, onClose, onSave
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');

  const handleSave = () => {
    onSave({
      name,
      description,
      category,
      icon: 'Database',
      table_name: name.toLowerCase().replace(/\s+/g, '_'),
      fields: [{ id: '1', name: 'name', type: 'text', required: true }],
      permissions: ['read', 'write'],
      created_by: 'current_user',
      is_active: true
    });
    setName('');
    setDescription('');
    setCategory('');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Dataset</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <Label>Description</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <Label>Category</Label>
            <Input value={category} onChange={(e) => setCategory(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Create</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};