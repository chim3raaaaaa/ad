import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Package, 
  Trash2, 
  Edit, 
  Download, 
  Upload, 
  CheckSquare, 
  AlertTriangle,
  Play,
  Pause,
  RotateCcw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BulkOperationConfig {
  field: string;
  label: string;
  type: 'text' | 'number' | 'select';
  options?: string[];
}

interface BulkOperationsProps {
  selectedItems: any[];
  availableFields: BulkOperationConfig[];
  onBulkUpdate: (updates: Record<string, any>) => Promise<void>;
  onBulkDelete: (items: any[]) => Promise<void>;
  onBulkExport: (items: any[]) => Promise<void>;
  onClearSelection: () => void;
}

export const BulkOperations: React.FC<BulkOperationsProps> = ({
  selectedItems,
  availableFields,
  onBulkUpdate,
  onBulkDelete,
  onBulkExport,
  onClearSelection
}) => {
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [updateFields, setUpdateFields] = useState<Record<string, any>>({});
  const [selectedUpdateFields, setSelectedUpdateFields] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [operationLog, setOperationLog] = useState<string[]>([]);
  const { toast } = useToast();

  const handleBulkUpdate = async () => {
    if (selectedUpdateFields.length === 0) {
      toast({
        title: "No Fields Selected",
        description: "Please select at least one field to update",
        variant: "destructive"
      });
      return;
    }

    const updates = selectedUpdateFields.reduce((acc, field) => {
      if (updateFields[field] !== undefined && updateFields[field] !== '') {
        acc[field] = updateFields[field];
      }
      return acc;
    }, {} as Record<string, any>);

    if (Object.keys(updates).length === 0) {
      toast({
        title: "No Updates",
        description: "Please provide values for the selected fields",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setOperationLog([]);

    try {
      // Simulate progress
      for (let i = 0; i <= 100; i += 10) {
        setProgress(i);
        setOperationLog(prev => [...prev, `Updating ${i}% of ${selectedItems.length} items...`]);
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      await onBulkUpdate(updates);
      
      setOperationLog(prev => [...prev, `✅ Successfully updated ${selectedItems.length} items`]);
      setIsUpdateDialogOpen(false);
      
      toast({
        title: "Bulk Update Complete",
        description: `Updated ${selectedItems.length} items successfully`
      });
    } catch (error) {
      setOperationLog(prev => [...prev, `❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`]);
      toast({
        title: "Bulk Update Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBulkDelete = async () => {
    setIsProcessing(true);
    setProgress(0);
    setOperationLog([]);

    try {
      // Simulate progress
      for (let i = 0; i <= 100; i += 20) {
        setProgress(i);
        setOperationLog(prev => [...prev, `Deleting ${i}% of ${selectedItems.length} items...`]);
        await new Promise(resolve => setTimeout(resolve, 150));
      }

      await onBulkDelete(selectedItems);
      
      setOperationLog(prev => [...prev, `✅ Successfully deleted ${selectedItems.length} items`]);
      setIsDeleteDialogOpen(false);
      onClearSelection();
      
      toast({
        title: "Bulk Delete Complete",
        description: `Deleted ${selectedItems.length} items successfully`
      });
    } catch (error) {
      setOperationLog(prev => [...prev, `❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`]);
      toast({
        title: "Bulk Delete Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBulkExport = async () => {
    setIsProcessing(true);
    try {
      await onBulkExport(selectedItems);
      toast({
        title: "Export Complete",
        description: `Exported ${selectedItems.length} items successfully`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleFieldSelection = (fieldKey: string) => {
    setSelectedUpdateFields(prev => 
      prev.includes(fieldKey) 
        ? prev.filter(f => f !== fieldKey)
        : [...prev, fieldKey]
    );
  };

  const renderFieldInput = (field: BulkOperationConfig) => {
    if (field.type === 'select' && field.options) {
      return (
        <Select 
          value={updateFields[field.field] || ''} 
          onValueChange={(value) => setUpdateFields(prev => ({ ...prev, [field.field]: value }))}
        >
          <SelectTrigger>
            <SelectValue placeholder={`Select ${field.label}`} />
          </SelectTrigger>
          <SelectContent>
            {field.options.map(option => (
              <SelectItem key={option} value={option}>{option}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    return (
      <Input
        type={field.type === 'number' ? 'number' : 'text'}
        placeholder={`Enter ${field.label.toLowerCase()}`}
        value={updateFields[field.field] || ''}
        onChange={(e) => setUpdateFields(prev => ({ 
          ...prev, 
          [field.field]: field.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value 
        }))}
      />
    );
  };

  if (selectedItems.length === 0) {
    return null;
  }

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Bulk Operations
        </CardTitle>
        <CardDescription>
          Perform actions on {selectedItems.length} selected item{selectedItems.length !== 1 ? 's' : ''}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Edit className="h-4 w-4" />
                Bulk Edit ({selectedItems.length})
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Bulk Update {selectedItems.length} Items</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    This will update all {selectedItems.length} selected items. Only checked fields will be updated.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  {availableFields.map(field => (
                    <div key={field.field} className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          checked={selectedUpdateFields.includes(field.field)}
                          onCheckedChange={() => toggleFieldSelection(field.field)}
                        />
                        <Label className="font-medium">{field.label}</Label>
                      </div>
                      {selectedUpdateFields.includes(field.field) && (
                        <div className="ml-6">
                          {renderFieldInput(field)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {isProcessing && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                    
                    <div className="bg-muted p-3 rounded-lg max-h-40 overflow-y-auto">
                      {operationLog.map((log, index) => (
                        <div key={index} className="text-sm text-muted-foreground">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsUpdateDialogOpen(false)}
                    disabled={isProcessing}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleBulkUpdate}
                    disabled={isProcessing || selectedUpdateFields.length === 0}
                  >
                    {isProcessing ? 'Updating...' : 'Update All'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" className="gap-2">
                <Trash2 className="h-4 w-4" />
                Bulk Delete ({selectedItems.length})
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  Confirm Bulk Deletion
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    This action will permanently delete {selectedItems.length} items and cannot be undone.
                    This may also affect related data and test modules.
                  </AlertDescription>
                </Alert>

                {isProcessing && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                    
                    <div className="bg-muted p-3 rounded-lg max-h-40 overflow-y-auto">
                      {operationLog.map((log, index) => (
                        <div key={index} className="text-sm text-muted-foreground">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsDeleteDialogOpen(false)}
                    disabled={isProcessing}
                  >
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={handleBulkDelete}
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'Deleting...' : `Delete ${selectedItems.length} Items`}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Button 
            variant="outline" 
            onClick={handleBulkExport}
            disabled={isProcessing}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Export ({selectedItems.length})
          </Button>

          <Button 
            variant="ghost" 
            onClick={onClearSelection}
            className="gap-2"
          >
            <RotateCcw className="h-4 w-4" />
            Clear Selection
          </Button>
        </div>

        {selectedItems.length > 0 && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="text-sm text-muted-foreground">
              Selected items: {selectedItems.slice(0, 3).map(item => item.name || item.id).join(', ')}
              {selectedItems.length > 3 && ` and ${selectedItems.length - 3} more...`}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};