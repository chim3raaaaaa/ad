import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  Settings, 
  Type, 
  Hash, 
  Calendar, 
  ToggleLeft,
  FileText,
  GripVertical,
  Eye
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

export interface FieldSchema {
  id: string;
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'date' | 'boolean' | 'file' | 'textarea';
  required: boolean;
  options?: string[];
  referenceType?: string; // For binding to reference datasets
  placeholder?: string;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
  order: number;
}

export interface CategorySchema {
  id: string;
  name: string;
  code: string;
  productType: string;
  description: string;
  fields: FieldSchema[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

const FIELD_TYPES = [
  { value: 'text', label: 'Text Input', icon: Type },
  { value: 'number', label: 'Number Input', icon: Hash },
  { value: 'select', label: 'Dropdown', icon: ToggleLeft },
  { value: 'date', label: 'Date Picker', icon: Calendar },
  { value: 'boolean', label: 'Yes/No Switch', icon: ToggleLeft },
  { value: 'file', label: 'File Upload', icon: FileText },
  { value: 'textarea', label: 'Text Area', icon: Type }
];

const REFERENCE_TYPES = [
  'officers',
  'machines', 
  'plants',
  'sampling_locations',
  'climatic_conditions',
  'aggregate_types',
  'products'
];

interface CategorySchemaBuilderProps {
  onRefresh?: () => void;
}

export function CategorySchemaBuilder({ onRefresh }: CategorySchemaBuilderProps) {
  const { toast } = useToast();
  const [schemas, setSchemas] = useState<CategorySchema[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSchema, setEditingSchema] = useState<CategorySchema | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewSchema, setPreviewSchema] = useState<CategorySchema | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    code: '',
    productType: '',
    description: ''
  });

  const [fields, setFields] = useState<FieldSchema[]>([]);
  const [newField, setNewField] = useState<Partial<FieldSchema>>({
    name: '',
    label: '',
    type: 'text',
    required: false,
    order: 0
  });

  // Load existing schemas
  useEffect(() => {
    loadSchemas();
  }, []);

  const loadSchemas = async () => {
    if (!window.electronAPI) return;

    try {
      // Create CategorySchemas table if it doesn't exist
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS CategorySchemas (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          code TEXT NOT NULL UNIQUE,
          product_type TEXT NOT NULL,
          description TEXT,
          fields TEXT NOT NULL, -- JSON array of field definitions
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM CategorySchemas ORDER BY created_at DESC
      `);

      if (result.success && result.data) {
        const parsedSchemas = result.data.map((row: any) => ({
          ...row,
          fields: JSON.parse(row.fields || '[]'),
          isActive: row.is_active === 1
        }));
        setSchemas(parsedSchemas);
      }
    } catch (error) {
      console.error('Error loading schemas:', error);
      toast({
        title: "Error",
        description: "Failed to load category schemas",
        variant: "destructive"
      });
    }
  };

  const handleSaveSchema = async () => {
    if (!formData.name || !formData.code || fields.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and add at least one field",
        variant: "destructive"
      });
      return;
    }

    if (!window.electronAPI) return;

    try {
      const schemaData = {
        id: editingSchema?.id || crypto.randomUUID(),
        name: formData.name,
        code: formData.code,
        product_type: formData.productType,
        description: formData.description,
        fields: JSON.stringify(fields),
        is_active: 1,
        updated_at: new Date().toISOString()
      };

      if (editingSchema) {
        // Update existing schema
        await window.electronAPI.dbRun(`
          UPDATE CategorySchemas 
          SET name = ?, code = ?, product_type = ?, description = ?, fields = ?, updated_at = ?
          WHERE id = ?
        `, [
          schemaData.name,
          schemaData.code,
          schemaData.product_type,
          schemaData.description,
          schemaData.fields,
          schemaData.updated_at,
          editingSchema.id
        ]);
      } else {
        // Create new schema
        await window.electronAPI.dbRun(`
          INSERT INTO CategorySchemas (id, name, code, product_type, description, fields, is_active)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          schemaData.id,
          schemaData.name,
          schemaData.code,
          schemaData.product_type,
          schemaData.description,
          schemaData.fields,
          schemaData.is_active
        ]);
      }

      toast({
        title: "Success",
        description: `Schema ${editingSchema ? 'updated' : 'created'} successfully`
      });

      setIsDialogOpen(false);
      resetForm();
      loadSchemas();
      onRefresh?.();

    } catch (error: any) {
      console.error('Error saving schema:', error);
      toast({
        title: "Error",
        description: error.message?.includes('UNIQUE') ? 
          "A schema with this code already exists" : 
          "Failed to save schema",
        variant: "destructive"
      });
    }
  };

  const handleDeleteSchema = async (id: string) => {
    if (!window.electronAPI) return;
    if (!confirm('Are you sure you want to delete this schema?')) return;

    try {
      await window.electronAPI.dbRun(`DELETE FROM CategorySchemas WHERE id = ?`, [id]);
      toast({
        title: "Success",
        description: "Schema deleted successfully"
      });
      loadSchemas();
      onRefresh?.();
    } catch (error) {
      console.error('Error deleting schema:', error);
      toast({
        title: "Error",
        description: "Failed to delete schema",
        variant: "destructive"
      });
    }
  };

  const handleAddField = () => {
    if (!newField.name || !newField.label) {
      toast({
        title: "Validation Error",
        description: "Field name and label are required",
        variant: "destructive"
      });
      return;
    }

    const field: FieldSchema = {
      id: crypto.randomUUID(),
      name: newField.name!,
      label: newField.label!,
      type: newField.type || 'text',
      required: newField.required || false,
      options: newField.options,
      referenceType: newField.referenceType,
      placeholder: newField.placeholder,
      validation: newField.validation,
      order: fields.length
    };

    setFields([...fields, field]);
    setNewField({
      name: '',
      label: '',
      type: 'text',
      required: false,
      order: 0
    });
  };

  const handleEditSchema = (schema: CategorySchema) => {
    setEditingSchema(schema);
    setFormData({
      name: schema.name,
      code: schema.code,
      productType: schema.productType,
      description: schema.description
    });
    setFields([...schema.fields].sort((a, b) => a.order - b.order));
    setIsDialogOpen(true);
  };

  const handlePreviewSchema = (schema: CategorySchema) => {
    setPreviewSchema(schema);
    setIsPreviewOpen(true);
  };

  const resetForm = () => {
    setEditingSchema(null);
    setFormData({
      name: '',
      code: '',
      productType: '',
      description: ''
    });
    setFields([]);
    setNewField({
      name: '',
      label: '',
      type: 'text',
      required: false,
      order: 0
    });
  };

  const onDragEnd = (result: any) => {
    if (!result.destination) return;

    const items = Array.from(fields);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Update order values
    const updatedItems = items.map((item, index) => ({
      ...item,
      order: index
    }));

    setFields(updatedItems);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Test Category Schema Manager</CardTitle>
              <CardDescription>
                Create and manage dynamic test categories and their field definitions
              </CardDescription>
            </div>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              New Category
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Product Type</TableHead>
                <TableHead>Fields</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schemas.map((schema) => (
                <TableRow key={schema.id}>
                  <TableCell className="font-medium">{schema.name}</TableCell>
                  <TableCell>{schema.code}</TableCell>
                  <TableCell>{schema.productType}</TableCell>
                  <TableCell>{schema.fields.length} fields</TableCell>
                  <TableCell>
                    <Badge variant={schema.isActive ? "default" : "secondary"}>
                      {schema.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handlePreviewSchema(schema)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditSchema(schema)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteSchema(schema.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Schema Builder Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSchema ? 'Edit' : 'Create'} Test Category Schema
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="fields">Fields</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Category Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Concrete Cubes Test"
                  />
                </div>
                <div>
                  <Label htmlFor="code">Category Code</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="e.g., CCT"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="productType">Product Type</Label>
                <Select
                  value={formData.productType}
                  onValueChange={(value) => setFormData({ ...formData, productType: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select product type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aggregates">Aggregates</SelectItem>
                    <SelectItem value="blocks">Blocks</SelectItem>
                    <SelectItem value="pavers">Pavers</SelectItem>
                    <SelectItem value="cubes">Cubes</SelectItem>
                    <SelectItem value="kerbs">Kerbs</SelectItem>
                    <SelectItem value="flagstones">Flagstones</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe this test category..."
                />
              </div>
            </TabsContent>

            <TabsContent value="fields" className="space-y-4">
              {/* Add New Field */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Add New Field</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Field Name</Label>
                      <Input
                        value={newField.name || ''}
                        onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                        placeholder="field_name"
                      />
                    </div>
                    <div>
                      <Label>Display Label</Label>
                      <Input
                        value={newField.label || ''}
                        onChange={(e) => setNewField({ ...newField, label: e.target.value })}
                        placeholder="Display Label"
                      />
                    </div>
                    <div>
                      <Label>Field Type</Label>
                      <Select
                        value={newField.type}
                        onValueChange={(value: any) => setNewField({ ...newField, type: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {FIELD_TYPES.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={newField.required || false}
                      onCheckedChange={(checked) => setNewField({ ...newField, required: checked })}
                    />
                    <Label>Required Field</Label>
                  </div>

                  {newField.type === 'select' && (
                    <div>
                      <Label>Reference Type (Optional)</Label>
                      <Select
                        value={newField.referenceType}
                        onValueChange={(value) => setNewField({ ...newField, referenceType: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Bind to reference data" />
                        </SelectTrigger>
                        <SelectContent>
                          {REFERENCE_TYPES.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type.replace('_', ' ').toUpperCase()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <Button onClick={handleAddField} className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Field
                  </Button>
                </CardContent>
              </Card>

              {/* Fields List */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Current Fields ({fields.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <DragDropContext onDragEnd={onDragEnd}>
                    <Droppable droppableId="fields">
                      {(provided) => (
                        <div {...provided.droppableProps} ref={provided.innerRef}>
                          {fields.map((field, index) => (
                            <Draggable key={field.id} draggableId={field.id} index={index}>
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  className="flex items-center justify-between p-3 border rounded-lg mb-2 bg-background"
                                >
                                  <div className="flex items-center gap-3">
                                    <div {...provided.dragHandleProps}>
                                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                                    </div>
                                    <div>
                                      <div className="font-medium">{field.label}</div>
                                      <div className="text-sm text-muted-foreground">
                                        {field.name} • {field.type}
                                        {field.required && ' • Required'}
                                        {field.referenceType && ` • Ref: ${field.referenceType}`}
                                      </div>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setFields(fields.filter(f => f.id !== field.id))}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </DragDropContext>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveSchema}>
              <Save className="h-4 w-4 mr-2" />
              {editingSchema ? 'Update' : 'Create'} Schema
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Preview: {previewSchema?.name}</DialogTitle>
          </DialogHeader>
          {previewSchema && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><strong>Code:</strong> {previewSchema.code}</div>
                <div><strong>Product Type:</strong> {previewSchema.productType}</div>
              </div>
              <div className="text-sm">
                <strong>Description:</strong> {previewSchema.description}
              </div>
              <div>
                <h4 className="font-medium mb-2">Fields ({previewSchema.fields.length})</h4>
                <div className="space-y-2">
                  {previewSchema.fields
                    .sort((a, b) => a.order - b.order)
                    .map((field) => (
                    <div key={field.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium">{field.label}</div>
                        <div className="text-xs text-muted-foreground">
                          {field.name} • {field.type}
                          {field.required && ' • Required'}
                        </div>
                      </div>
                      <Badge variant="outline">{field.type}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}