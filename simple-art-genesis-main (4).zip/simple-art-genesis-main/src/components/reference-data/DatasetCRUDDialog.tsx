import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Edit, Save, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Field {
  id: string;
  name: string;
  type: 'text' | 'number' | 'select';
  required?: boolean;
  options?: string[];
}

interface DatasetConfig {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  category: string;
  fields: Field[];
  loadData: () => Promise<any[]>;
  saveData: (data: any) => Promise<string | void>;
  deleteData: (id: string) => Promise<void>;
  csvTemplate?: string;
}

interface DatasetCRUDDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit' | 'delete';
  config?: DatasetConfig;
  onSuccess: () => void;
}

const CATEGORIES = [
  { id: 'materials', name: 'Materials & Components' },
  { id: 'personnel', name: 'Personnel & Equipment' },
  { id: 'standards', name: 'Standards & Classifications' },
  { id: 'locations', name: 'Locations & Environment' }
];

const FIELD_TYPES = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'select', label: 'Dropdown' }
];

export function DatasetCRUDDialog({ open, onOpenChange, mode, config, onSuccess }: DatasetCRUDDialogProps) {
  const [formData, setFormData] = useState({
    name: config?.name || '',
    description: config?.description || '',
    category: config?.category || '',
    fields: config?.fields || []
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleAddField = () => {
    setFormData(prev => ({
      ...prev,
      fields: [...prev.fields, { id: Date.now().toString(), name: '', type: 'text', required: false }]
    }));
  };

  const handleUpdateField = (index: number, updates: Partial<Field>) => {
    setFormData(prev => ({
      ...prev,
      fields: prev.fields.map((field, i) => i === index ? { ...field, ...updates } : field)
    }));
  };

  const handleRemoveField = (index: number) => {
    setFormData(prev => ({
      ...prev,
      fields: prev.fields.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async () => {
    if (!formData.name.trim()) {
      toast({
        title: "Error",
        description: "Dataset name is required",
        variant: "destructive"
      });
      return;
    }

    if (mode === 'create' && formData.fields.length === 0) {
      toast({
        title: "Error", 
        description: "At least one field is required",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      if (mode === 'create' || mode === 'edit') {
        // Implementation would save to database or update configuration
        const datasetId = config?.id || `custom_${Date.now()}`;
        
        if (window.electronAPI?.dbQuery) {
          if (mode === 'create') {
            await window.electronAPI.dbQuery(`
              INSERT INTO custom_datasets (id, name, description, category, fields, created_at)
              VALUES (?, ?, ?, ?, ?, ?)
            `, [
              datasetId,
              formData.name,
              formData.description,
              formData.category,
              JSON.stringify(formData.fields),
              new Date().toISOString()
            ]);
          } else {
            await window.electronAPI.dbQuery(`
              UPDATE custom_datasets 
              SET name = ?, description = ?, category = ?, fields = ?
              WHERE id = ?
            `, [
              formData.name,
              formData.description,
              formData.category,
              JSON.stringify(formData.fields),
              config?.id
            ]);
          }
        }
      } else if (mode === 'delete' && config) {
        if (window.electronAPI?.dbQuery) {
          await window.electronAPI.dbQuery('DELETE FROM custom_datasets WHERE id = ?', [config.id]);
        }
      }

      toast({
        title: "Success",
        description: `Dataset ${mode}d successfully`,
      });

      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error(`Error ${mode}ing dataset:`, error);
      toast({
        title: "Error",
        description: `Failed to ${mode} dataset`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getDialogTitle = () => {
    switch (mode) {
      case 'create': return 'Create New Dataset';
      case 'edit': return 'Edit Dataset';
      case 'delete': return 'Delete Dataset';
      default: return 'Dataset Management';
    }
  };

  const getDialogDescription = () => {
    switch (mode) {
      case 'create': return 'Define a new custom dataset with fields and validation rules';
      case 'edit': return 'Modify the dataset configuration and field definitions';
      case 'delete': return 'Are you sure you want to delete this dataset? This action cannot be undone.';
      default: return '';
    }
  };

  if (mode === 'delete') {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="h-5 w-5 text-destructive" />
              {getDialogTitle()}
            </DialogTitle>
            <DialogDescription>{getDialogDescription()}</DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <p className="text-sm text-muted-foreground">
              Dataset: <span className="font-medium">{config?.name}</span>
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              This will permanently delete all data associated with this dataset.
            </p>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleSubmit} disabled={loading}>
              {loading ? 'Deleting...' : 'Delete Dataset'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {mode === 'create' ? <Plus className="h-5 w-5" /> : <Edit className="h-5 w-5" />}
            {getDialogTitle()}
          </DialogTitle>
          <DialogDescription>{getDialogDescription()}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Dataset Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Custom Test Officers"
                disabled={loading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe the purpose and usage of this dataset"
              rows={3}
              disabled={loading}
            />
          </div>

          {/* Fields Configuration */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold">Field Definitions</Label>
              <Button type="button" variant="outline" size="sm" onClick={handleAddField} disabled={loading}>
                <Plus className="mr-2 h-4 w-4" />
                Add Field
              </Button>
            </div>

            {formData.fields.length === 0 ? (
              <div className="text-center py-8 border-2 border-dashed border-muted rounded-lg">
                <p className="text-muted-foreground">No fields defined yet</p>
                <p className="text-sm text-muted-foreground">Click "Add Field" to get started</p>
              </div>
            ) : (
              <div className="space-y-3">
                {formData.fields.map((field, index) => (
                  <div key={field.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <Badge variant="outline">Field {index + 1}</Badge>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveField(index)}
                        disabled={loading}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label>Field Name</Label>
                        <Input
                          value={field.name}
                          onChange={(e) => handleUpdateField(index, { name: e.target.value })}
                          placeholder="e.g., Name"
                          disabled={loading}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Field Type</Label>
                        <Select
                          value={field.type}
                          onValueChange={(value: 'text' | 'number' | 'select') => 
                            handleUpdateField(index, { type: value, options: value === 'select' ? [] : undefined })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {FIELD_TYPES.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Options</Label>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={field.required || false}
                            onChange={(e) => handleUpdateField(index, { required: e.target.checked })}
                            disabled={loading}
                          />
                          <span className="text-sm">Required</span>
                        </div>
                      </div>
                    </div>

                    {field.type === 'select' && (
                      <div className="space-y-2">
                        <Label>Dropdown Options (one per line)</Label>
                        <Textarea
                          value={field.options?.join('\n') || ''}
                          onChange={(e) => handleUpdateField(index, { 
                            options: e.target.value.split('\n').filter(Boolean) 
                          })}
                          placeholder="Option 1&#10;Option 2&#10;Option 3"
                          rows={3}
                          disabled={loading}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            <Save className="mr-2 h-4 w-4" />
            {loading ? 'Saving...' : (mode === 'create' ? 'Create Dataset' : 'Save Changes')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}