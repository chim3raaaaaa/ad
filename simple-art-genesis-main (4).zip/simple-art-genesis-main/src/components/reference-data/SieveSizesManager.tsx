import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Trash2, Grid3X3 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localReferenceDataService } from '@/services/storage/localReferenceDataService';

interface SieveSize {
  id: number;
  name: string;
  size_mm: number;
  field_key: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function SieveSizesManager() {
  const [sieveSizes, setSieveSizes] = useState<SieveSize[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formData, setFormData] = useState({ 
    name: '', 
    size_mm: '', 
    field_key: '', 
    display_order: '' 
  });

  const { toast } = useToast();

  useEffect(() => {
    loadSieveSizes();
  }, []);

  const loadSieveSizes = async () => {
    try {
      setLoading(true);
      const data = await localReferenceDataService.getSieveSizes();
      setSieveSizes(data);
    } catch (error) {
      console.error('Error loading sieve sizes:', error);
      toast({
        title: "Error",
        description: "Failed to load sieve sizes",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.size_mm || !formData.field_key.trim()) {
      toast({
        title: "Error",
        description: "Name, size (mm), and field key are required",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      
      const sieveData = {
        name: formData.name,
        size_mm: parseFloat(formData.size_mm),
        field_key: formData.field_key,
        display_order: formData.display_order ? parseInt(formData.display_order) : sieveSizes.length + 1
      };

      await localReferenceDataService.saveSieveSize(sieveData);
      
      toast({
        title: "Success",
        description: "Sieve size created successfully"
      });

      setFormData({ name: '', size_mm: '', field_key: '', display_order: '' });
      setShowCreateModal(false);
      loadSieveSizes();
    } catch (error) {
      console.error('Error saving sieve size:', error);
      toast({
        title: "Error",
        description: "Failed to save sieve size. Field key may already exist.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (sieveSize: SieveSize) => {
    if (!confirm(`Are you sure you want to delete "${sieveSize.name}"?`)) {
      return;
    }

    try {
      await localReferenceDataService.deleteSieveSize(sieveSize.id.toString());
      
      toast({
        title: "Success",
        description: "Sieve size deleted successfully"
      });

      loadSieveSizes();
    } catch (error) {
      console.error('Error deleting sieve size:', error);
      toast({
        title: "Error",
        description: "Failed to delete sieve size",
        variant: "destructive"
      });
    }
  };

  // Auto-generate field key based on name
  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      field_key: prev.field_key || `sieve_${name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}`
    }));
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Grid3X3 className="h-5 w-5" />
            <div>
              <CardTitle>Sieve Sizes</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage sieve sizes for grading analysis
              </p>
            </div>
          </div>
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Sieve Size
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Create Sieve Size</DialogTitle>
                  <DialogDescription>
                    Add a new sieve size for aggregate grading
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleNameChange(e.target.value)}
                      placeholder="e.g., 5mm, 0.075mm"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="size_mm">Size (mm)</Label>
                    <Input
                      id="size_mm"
                      type="number"
                      step="0.001"
                      value={formData.size_mm}
                      onChange={(e) => setFormData(prev => ({ ...prev, size_mm: e.target.value }))}
                      placeholder="e.g., 5, 0.075"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="field_key">Field Key</Label>
                    <Input
                      id="field_key"
                      value={formData.field_key}
                      onChange={(e) => setFormData(prev => ({ ...prev, field_key: e.target.value }))}
                      placeholder="e.g., sieve_5, sieve_0_075"
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      Used as database column name. Use underscores instead of dots.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="display_order">Display Order (Optional)</Label>
                    <Input
                      id="display_order"
                      type="number"
                      value={formData.display_order}
                      onChange={(e) => setFormData(prev => ({ ...prev, display_order: e.target.value }))}
                      placeholder="Leave empty to add at end"
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={loading}>
                    {loading ? 'Creating...' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading && sieveSizes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Loading sieve sizes...
          </div>
        ) : sieveSizes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No sieve sizes defined yet. Click "Add Sieve Size" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Size (mm)</TableHead>
                <TableHead>Field Key</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sieveSizes.map((sieveSize) => (
                <TableRow key={sieveSize.id}>
                  <TableCell className="font-medium">{sieveSize.name}</TableCell>
                  <TableCell>{sieveSize.size_mm}</TableCell>
                  <TableCell><code className="text-xs">{sieveSize.field_key}</code></TableCell>
                  <TableCell>{sieveSize.display_order}</TableCell>
                  <TableCell>{new Date(sieveSize.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(sieveSize)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}