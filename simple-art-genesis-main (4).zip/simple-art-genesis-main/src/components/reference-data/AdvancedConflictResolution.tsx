// Advanced conflict resolution with field-level merging capabilities
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  GitMerge, 
  AlertTriangle, 
  Clock, 
  User, 
  Database,
  CheckCircle,
  X,
  ArrowRight,
  ArrowLeft,
  RotateCcw
} from 'lucide-react';
import { SyncConflict, DatasetDefinition } from '@/services/sync/syncTypes';
import { modernReferenceDataService } from '@/services/reference-data/modernReferenceDataService';

interface AdvancedConflictResolutionProps {
  open: boolean;
  onClose: () => void;
  conflicts: SyncConflict[];
  onResolve: (conflictId: string, resolution: 'local' | 'remote' | 'merge', mergedData?: any) => void;
}

interface FieldConflict {
  field: string;
  localValue: any;
  remoteValue: any;
  resolved: boolean;
  resolution: 'local' | 'remote' | 'custom';
  customValue?: any;
}

interface ConflictAnalysis {
  totalFields: number;
  conflictedFields: number;
  autoResolvable: number;
  requiresAttention: number;
  fieldConflicts: FieldConflict[];
}

export const AdvancedConflictResolution: React.FC<AdvancedConflictResolutionProps> = ({
  open,
  onClose,
  conflicts,
  onResolve
}) => {
  const [selectedConflict, setSelectedConflict] = useState<SyncConflict | null>(null);
  const [conflictAnalysis, setConflictAnalysis] = useState<ConflictAnalysis | null>(null);
  const [mergedData, setMergedData] = useState<any>({});
  const [resolutionStrategy, setResolutionStrategy] = useState<'auto' | 'manual'>('manual');
  const [datasetDefinitions, setDatasetDefinitions] = useState<DatasetDefinition[]>([]);

  useEffect(() => {
    loadDatasetDefinitions();
  }, []);

  useEffect(() => {
    if (selectedConflict) {
      analyzeConflict(selectedConflict);
    }
  }, [selectedConflict, datasetDefinitions]);

  const loadDatasetDefinitions = async () => {
    try {
      const definitions = await modernReferenceDataService.getDatasetDefinitions();
      setDatasetDefinitions(definitions);
    } catch (error) {
      console.error('Failed to load dataset definitions:', error);
    }
  };

  const analyzeConflict = (conflict: SyncConflict) => {
    const dataset = datasetDefinitions.find(d => d.table_name === conflict.table_name);
    if (!dataset) return;

    const localData = conflict.local_data;
    const remoteData = conflict.remote_data;
    const fieldConflicts: FieldConflict[] = [];

    // Analyze each field for conflicts
    for (const field of dataset.fields) {
      const localValue = localData[field.name];
      const remoteValue = remoteData[field.name];
      
      if (localValue !== remoteValue) {
        const fieldConflict: FieldConflict = {
          field: field.name,
          localValue,
          remoteValue,
          resolved: false,
          resolution: 'local' // Default to local
        };

        // Auto-resolve simple cases
        if (canAutoResolve(field, localValue, remoteValue)) {
          fieldConflict.resolved = true;
          fieldConflict.resolution = getAutoResolution(field, localValue, remoteValue);
        }

        fieldConflicts.push(fieldConflict);
      }
    }

    const analysis: ConflictAnalysis = {
      totalFields: dataset.fields.length,
      conflictedFields: fieldConflicts.length,
      autoResolvable: fieldConflicts.filter(fc => fc.resolved).length,
      requiresAttention: fieldConflicts.filter(fc => !fc.resolved).length,
      fieldConflicts
    };

    setConflictAnalysis(analysis);
    
    // Initialize merged data
    const initialMerged = { ...localData };
    fieldConflicts.forEach(fc => {
      if (fc.resolved) {
        const resolvedValue = fc.resolution === 'local' ? fc.localValue : fc.remoteValue;
        initialMerged[fc.field] = resolvedValue;
      }
    });
    setMergedData(initialMerged);
  };

  const canAutoResolve = (field: any, localValue: any, remoteValue: any): boolean => {
    // Auto-resolve if one value is empty/null
    if (!localValue && remoteValue) return true;
    if (localValue && !remoteValue) return true;
    
    // Auto-resolve timestamps (prefer newer)
    if (field.type === 'date' || field.name.includes('_at')) {
      return true;
    }
    
    // Auto-resolve numeric fields (prefer higher value for version-like fields)
    if (field.type === 'number' && field.name.includes('version')) {
      return true;
    }
    
    return false;
  };

  const getAutoResolution = (field: any, localValue: any, remoteValue: any): 'local' | 'remote' => {
    // Prefer non-empty values
    if (!localValue && remoteValue) return 'remote';
    if (localValue && !remoteValue) return 'local';
    
    // Prefer newer timestamps
    if (field.type === 'date' || field.name.includes('_at')) {
      return new Date(localValue) > new Date(remoteValue) ? 'local' : 'remote';
    }
    
    // Prefer higher version numbers
    if (field.type === 'number' && field.name.includes('version')) {
      return localValue > remoteValue ? 'local' : 'remote';
    }
    
    return 'local'; // Default fallback
  };

  const handleFieldResolution = (fieldName: string, resolution: 'local' | 'remote' | 'custom', customValue?: any) => {
    if (!conflictAnalysis) return;

    const updatedConflicts = conflictAnalysis.fieldConflicts.map(fc => {
      if (fc.field === fieldName) {
        return {
          ...fc,
          resolution,
          customValue,
          resolved: true
        };
      }
      return fc;
    });

    setConflictAnalysis({
      ...conflictAnalysis,
      fieldConflicts: updatedConflicts,
      requiresAttention: updatedConflicts.filter(fc => !fc.resolved).length
    });

    // Update merged data
    const updatedMerged = { ...mergedData };
    if (resolution === 'custom') {
      updatedMerged[fieldName] = customValue;
    } else {
      const conflict = conflictAnalysis.fieldConflicts.find(fc => fc.field === fieldName);
      if (conflict) {
        updatedMerged[fieldName] = resolution === 'local' ? conflict.localValue : conflict.remoteValue;
      }
    }
    setMergedData(updatedMerged);
  };

  const handleAutoResolveAll = () => {
    if (!conflictAnalysis) return;

    const updatedConflicts = conflictAnalysis.fieldConflicts.map(fc => {
      if (!fc.resolved) {
        const dataset = datasetDefinitions.find(d => d.table_name === selectedConflict?.table_name);
        const field = dataset?.fields.find(f => f.name === fc.field);
        
        if (field && canAutoResolve(field, fc.localValue, fc.remoteValue)) {
          return {
            ...fc,
            resolved: true,
            resolution: getAutoResolution(field, fc.localValue, fc.remoteValue)
          };
        }
      }
      return fc;
    });

    setConflictAnalysis({
      ...conflictAnalysis,
      fieldConflicts: updatedConflicts,
      autoResolvable: updatedConflicts.filter(fc => fc.resolved).length,
      requiresAttention: updatedConflicts.filter(fc => !fc.resolved).length
    });

    // Update merged data with auto-resolved values
    const updatedMerged = { ...mergedData };
    updatedConflicts.forEach(fc => {
      if (fc.resolved) {
        updatedMerged[fc.field] = fc.resolution === 'local' ? fc.localValue : fc.remoteValue;
      }
    });
    setMergedData(updatedMerged);
  };

  const handleResolveConflict = () => {
    if (!selectedConflict || !conflictAnalysis) return;

    const hasUnresolvedFields = conflictAnalysis.fieldConflicts.some(fc => !fc.resolved);
    if (hasUnresolvedFields) {
      alert('Please resolve all field conflicts before proceeding.');
      return;
    }

    onResolve(selectedConflict.id, 'merge', mergedData);
    setSelectedConflict(null);
    setConflictAnalysis(null);
  };

  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return 'Empty';
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'object') return JSON.stringify(value);
    return value.toString();
  };

  const getConflictTypeColor = (type: string): string => {
    switch (type) {
      case 'update_update': return 'bg-yellow-500';
      case 'update_delete': return 'bg-red-500';
      case 'delete_update': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getConflictTypeLabel = (type: string): string => {
    switch (type) {
      case 'update_update': return 'Concurrent Updates';
      case 'update_delete': return 'Update vs Delete';
      case 'delete_update': return 'Delete vs Update';
      default: return 'Unknown Conflict';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitMerge className="w-5 h-5" />
            Advanced Conflict Resolution
            <Badge variant="destructive">{conflicts.length} conflicts</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          {selectedConflict ? (
            <div className="h-full flex flex-col space-y-4">
              {/* Conflict Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedConflict(null)}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to List
                  </Button>
                  <div>
                    <h3 className="font-semibold">{selectedConflict.table_name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Record ID: {selectedConflict.record_id}
                    </p>
                  </div>
                </div>
                <Badge className={getConflictTypeColor(selectedConflict.conflict_type)}>
                  {getConflictTypeLabel(selectedConflict.conflict_type)}
                </Badge>
              </div>

              {/* Conflict Analysis Summary */}
              {conflictAnalysis && (
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Conflict Analysis</CardTitle>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={handleAutoResolveAll}
                          disabled={conflictAnalysis.autoResolvable === conflictAnalysis.conflictedFields}
                        >
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Auto-resolve ({conflictAnalysis.autoResolvable})
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold">{conflictAnalysis.totalFields}</div>
                        <div className="text-sm text-muted-foreground">Total Fields</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-yellow-600">{conflictAnalysis.conflictedFields}</div>
                        <div className="text-sm text-muted-foreground">Conflicted</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-green-600">{conflictAnalysis.autoResolvable}</div>
                        <div className="text-sm text-muted-foreground">Auto-resolved</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-red-600">{conflictAnalysis.requiresAttention}</div>
                        <div className="text-sm text-muted-foreground">Need Attention</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Field-by-field resolution */}
              {conflictAnalysis && (
                <div className="flex-1 overflow-auto space-y-3">
                  {conflictAnalysis.fieldConflicts.map((fieldConflict, index) => (
                    <Card key={index} className={`${fieldConflict.resolved ? 'bg-green-50' : 'bg-yellow-50'}`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{fieldConflict.field}</h4>
                          {fieldConflict.resolved ? (
                            <Badge variant="default">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Resolved
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Needs Resolution
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-3 gap-4">
                          {/* Local Value */}
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <User className="w-4 h-4" />
                              <span className="font-medium">Local Value</span>
                            </div>
                            <div className="p-3 bg-blue-50 rounded border">
                              {formatValue(fieldConflict.localValue)}
                            </div>
                            <Button
                              size="sm"
                              variant={fieldConflict.resolution === 'local' ? 'default' : 'outline'}
                              onClick={() => handleFieldResolution(fieldConflict.field, 'local')}
                              className="w-full"
                            >
                              Use Local
                            </Button>
                          </div>

                          {/* Arrow */}
                          <div className="flex items-center justify-center">
                            <ArrowRight className="w-6 h-6 text-muted-foreground" />
                          </div>

                          {/* Remote Value */}
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <Database className="w-4 h-4" />
                              <span className="font-medium">Remote Value</span>
                            </div>
                            <div className="p-3 bg-green-50 rounded border">
                              {formatValue(fieldConflict.remoteValue)}
                            </div>
                            <Button
                              size="sm"
                              variant={fieldConflict.resolution === 'remote' ? 'default' : 'outline'}
                              onClick={() => handleFieldResolution(fieldConflict.field, 'remote')}
                              className="w-full"
                            >
                              Use Remote
                            </Button>
                          </div>
                        </div>

                        {/* Custom resolution option */}
                        {!fieldConflict.resolved && (
                          <div className="mt-4 p-3 border rounded">
                            <label className="block text-sm font-medium mb-2">
                              Custom Value (optional):
                            </label>
                            <div className="flex space-x-2">
                              <input
                                type="text"
                                className="flex-1 px-3 py-2 border rounded"
                                placeholder="Enter custom value..."
                                onChange={(e) => {
                                  if (e.target.value) {
                                    handleFieldResolution(fieldConflict.field, 'custom', e.target.value);
                                  }
                                }}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          ) : (
            /* Conflict List */
            <div className="space-y-4">
              {conflicts.length === 0 ? (
                <div className="text-center py-12">
                  <CheckCircle className="w-12 h-12 mx-auto text-green-500 mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Conflicts</h3>
                  <p className="text-muted-foreground">
                    All data is synchronized successfully.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {conflicts.map((conflict) => (
                    <Card 
                      key={conflict.id} 
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedConflict(conflict)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{conflict.table_name}</h3>
                            <p className="text-sm text-muted-foreground">
                              Record: {conflict.record_id}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getConflictTypeColor(conflict.conflict_type)}>
                              {getConflictTypeLabel(conflict.conflict_type)}
                            </Badge>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Clock className="w-4 h-4 mr-1" />
                              {new Date(conflict.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">
                            {conflict.field_conflicts.length} field conflicts
                          </span>
                          <Button size="sm" variant="outline">
                            Resolve <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          {selectedConflict ? (
            <div className="flex justify-between w-full">
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={() => onResolve(selectedConflict.id, 'local')}
                >
                  Keep All Local
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onResolve(selectedConflict.id, 'remote')}
                >
                  Keep All Remote
                </Button>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setSelectedConflict(null)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleResolveConflict}
                  disabled={conflictAnalysis?.requiresAttention > 0}
                >
                  Apply Merge
                </Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};