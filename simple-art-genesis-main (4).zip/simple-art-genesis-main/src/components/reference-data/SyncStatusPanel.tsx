import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SyncStatus } from '@/services/sync/syncTypes';

interface SyncStatusPanelProps {
  status: SyncStatus | null;
  onSyncNow: () => void;
  onViewConflicts: () => void;
}

export const SyncStatusPanel: React.FC<SyncStatusPanelProps> = ({
  status, onSyncNow, onViewConflicts
}) => {
  if (!status) return <div>Loading...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sync Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between">
            <span>Connection:</span>
            <Badge variant={status.server_reachable ? "default" : "destructive"}>
              {status.server_reachable ? "Online" : "Offline"}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span>Pending Operations:</span>
            <Badge variant="outline">{status.pending_operations}</Badge>
          </div>
          <div className="flex justify-between">
            <span>Conflicts:</span>
            <Badge variant={status.conflicts > 0 ? "destructive" : "default"}>
              {status.conflicts}
            </Badge>
          </div>
          <div className="flex space-x-2">
            <Button onClick={onSyncNow}>Sync Now</Button>
            {status.conflicts > 0 && (
              <Button variant="outline" onClick={onViewConflicts}>
                View Conflicts
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};