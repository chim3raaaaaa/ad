import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { SyncConflict } from '@/services/sync/syncTypes';

interface ConflictResolutionDialogProps {
  open: boolean;
  onClose: () => void;
  conflicts: SyncConflict[];
  onResolve: (conflictId: string, resolution: 'local' | 'remote' | 'merge') => void;
  onSelectConflict: (conflict: SyncConflict) => void;
}

export const ConflictResolutionDialog: React.FC<ConflictResolutionDialogProps> = ({
  open, onClose, conflicts, onResolve
}) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Conflicts ({conflicts.length})</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {conflicts.map(conflict => (
            <div key={conflict.id} className="border p-4 rounded">
              <h3 className="font-semibold">{conflict.table_name}</h3>
              <p className="text-sm text-muted-foreground">{conflict.conflict_type}</p>
              <div className="flex space-x-2 mt-2">
                <Button size="sm" onClick={() => onResolve(conflict.id, 'local')}>
                  Keep Local
                </Button>
                <Button size="sm" onClick={() => onResolve(conflict.id, 'remote')}>
                  Keep Remote
                </Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};