import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Trash2, Award } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { localReferenceDataService } from '@/services/storage/localReferenceDataService';

interface Standard {
  id: number;
  name: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function StandardsManager() {
  const [standards, setStandards] = useState<Standard[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '' });

  const { toast } = useToast();

  useEffect(() => {
    loadStandards();
  }, []);

  const loadStandards = async () => {
    try {
      setLoading(true);
      const data = await localReferenceDataService.getStandards();
      setStandards(data);
    } catch (error) {
      console.error('Error loading standards:', error);
      toast({
        title: "Error",
        description: "Failed to load standards",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Error",
        description: "Standard name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      await localReferenceDataService.saveStandard(formData);
      
      toast({
        title: "Success",
        description: "Standard created successfully"
      });

      setFormData({ name: '', description: '' });
      setShowCreateModal(false);
      loadStandards();
    } catch (error) {
      console.error('Error saving standard:', error);
      toast({
        title: "Error",
        description: "Failed to save standard. It may already exist.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (standard: Standard) => {
    if (!confirm(`Are you sure you want to delete "${standard.name}"?`)) {
      return;
    }

    try {
      await localReferenceDataService.deleteStandard(standard.id.toString());
      
      toast({
        title: "Success",
        description: "Standard deleted successfully"
      });

      loadStandards();
    } catch (error) {
      console.error('Error deleting standard:', error);
      toast({
        title: "Error",
        description: "Failed to delete standard",
        variant: "destructive"
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Award className="h-5 w-5" />
            <div>
              <CardTitle>Standards</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage testing standards for grading limits
              </p>
            </div>
          </div>
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Standard
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Create Standard</DialogTitle>
                  <DialogDescription>
                    Add a new testing standard for grading limits
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., BS Min, BS Max, RDA Min"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Additional details about this standard"
                      rows={3}
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={loading}>
                    {loading ? 'Creating...' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading && standards.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Loading standards...
          </div>
        ) : standards.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No standards defined yet. Click "Add Standard" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {standards.map((standard) => (
                <TableRow key={standard.id}>
                  <TableCell className="font-medium">{standard.name}</TableCell>
                  <TableCell>{standard.description || '-'}</TableCell>
                  <TableCell>{new Date(standard.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(standard)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}