import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Eye, Plus, Database, MoreVertical, Edit, Trash2 } from 'lucide-react';

interface DatasetCardProps {
  config: {
    id: string;
    name: string;
    description: string;
    icon: React.ElementType;
    loadData: () => Promise<any[]>;
  };
  onView: () => void;
  onAdd: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}

export const DatasetCard: React.FC<DatasetCardProps> = ({ config, onView, onAdd, onEdit, onDelete }) => {
  const [recordCount, setRecordCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const loadStats = async () => {
    try {
      setLoading(true);
      const data = await config.loadData();
      setRecordCount(data?.length || 0);
      setLastUpdated(new Date().toLocaleDateString());
    } catch (error) {
      console.error('Failed to load stats:', error);
      setRecordCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, [config]);

  const IconComponent = config.icon;

  const handleDelete = () => {
    setShowDeleteDialog(false);
    onDelete?.();
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3 flex-1">
              <div className="p-2 rounded-lg bg-primary/10">
                <IconComponent className="h-5 w-5 text-primary" />
              </div>
              <div className="min-w-0 flex-1">
                <CardTitle className="text-base font-semibold truncate">{config.name}</CardTitle>
                <CardDescription className="text-sm">{config.description}</CardDescription>
              </div>
            </div>
            <Badge variant="secondary" className="flex items-center gap-1 ml-2">
              <Database className="h-3 w-3" />
              {loading ? '...' : recordCount}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              Last updated: {lastUpdated}
            </div>
            <div className="flex items-center gap-2">
              <Button 
                size="sm" 
                variant="outline"
                onClick={onView}
                className="h-8 px-3"
              >
                <Eye className="h-3 w-3 mr-1" />
                View
              </Button>
              <Button 
                size="sm"
                onClick={onAdd}
                className="h-8 px-3"
              >
                <Plus className="h-3 w-3 mr-1" />
                Add
              </Button>
              {(onEdit || onDelete) && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-8 w-8 p-0"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-40">
                    {onEdit && (
                      <DropdownMenuItem onClick={onEdit} className="cursor-pointer">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                    )}
                    {onDelete && (
                      <DropdownMenuItem 
                        onClick={() => setShowDeleteDialog(true)}
                        className="cursor-pointer text-destructive focus:text-destructive"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Dataset</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{config.name}"? This action cannot be undone and will permanently remove all data in this dataset.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};