import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Network, 
  Link, 
  AlertTriangle, 
  Eye, 
  GitBranch, 
  Database,
  RefreshCw 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DataRelationship {
  fromTable: string;
  fromField: string;
  toTable: string;
  toField: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-many' | 'many-to-one';
  isRequired: boolean;
}

interface DependencyIssue {
  id: string;
  type: 'missing_reference' | 'circular_dependency' | 'orphaned_record' | 'integrity_violation';
  severity: 'low' | 'medium' | 'high' | 'critical';
  table: string;
  record_id: string;
  description: string;
  suggestion: string;
}

interface DataRelationshipViewerProps {
  tableName?: string;
  recordId?: string;
}

export const DataRelationshipViewer: React.FC<DataRelationshipViewerProps> = ({ 
  tableName, 
  recordId 
}) => {
  const [relationships, setRelationships] = useState<DataRelationship[]>([]);
  const [dependencyIssues, setDependencyIssues] = useState<DependencyIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadRelationshipData();
  }, [tableName, recordId]);

  const loadRelationshipData = async () => {
    setLoading(true);
    try {
      // Mock relationship data - in production, this would come from schema analysis
      const mockRelationships: DataRelationship[] = [
        {
          fromTable: 'products',
          fromField: 'category_id',
          toTable: 'product_categories',
          toField: 'category_id',
          type: 'many-to-one',
          isRequired: true
        },
        {
          fromTable: 'machines',
          fromField: 'plant_id',
          toTable: 'plants',
          toField: 'plant_id',
          type: 'many-to-one',
          isRequired: false
        },
        {
          fromTable: 'test_results',
          fromField: 'product_id',
          toTable: 'products',
          toField: 'product_id',
          type: 'many-to-one',
          isRequired: true
        },
        {
          fromTable: 'mould_references',
          fromField: 'machine_id',
          toTable: 'machines',
          toField: 'machine_id',
          type: 'many-to-one',
          isRequired: false
        }
      ];

      const mockIssues: DependencyIssue[] = [
        {
          id: '1',
          type: 'missing_reference',
          severity: 'high',
          table: 'products',
          record_id: 'prod_123',
          description: 'Product references non-existent category "cat_999"',
          suggestion: 'Update category_id to valid category or create missing category'
        },
        {
          id: '2',
          type: 'orphaned_record',
          severity: 'medium',
          table: 'test_results',
          record_id: 'test_456',
          description: 'Test result exists for deleted product "prod_old"',
          suggestion: 'Remove orphaned test results or restore referenced product'
        },
        {
          id: '3',
          type: 'circular_dependency',
          severity: 'critical',
          table: 'products',
          record_id: 'prod_789',
          description: 'Circular reference detected in product hierarchy',
          suggestion: 'Break circular reference by updating parent_id field'
        }
      ];

      setRelationships(mockRelationships);
      setDependencyIssues(mockIssues);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load relationship data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getRelationshipIcon = (type: string) => {
    switch (type) {
      case 'one-to-one':
        return '1:1';
      case 'one-to-many':
        return '1:M';
      case 'many-to-many':
        return 'M:M';
      default:
        return 'M:1';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'destructive';
      case 'high':
        return 'destructive';
      case 'medium':
        return 'secondary';
      case 'low':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'missing_reference':
        return <Link className="h-4 w-4" />;
      case 'circular_dependency':
        return <GitBranch className="h-4 w-4" />;
      case 'orphaned_record':
        return <Database className="h-4 w-4" />;
      case 'integrity_violation':
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getRelatedTables = (table: string) => {
    const related = new Set<string>();
    relationships.forEach(rel => {
      if (rel.fromTable === table) related.add(rel.toTable);
      if (rel.toTable === table) related.add(rel.fromTable);
    });
    return Array.from(related);
  };

  const fixDependencyIssue = async (issueId: string) => {
    try {
      // Mock fix functionality
      toast({
        title: "Issue Fixed",
        description: "Dependency issue has been resolved",
      });
      
      setDependencyIssues(prev => prev.filter(issue => issue.id !== issueId));
    } catch (error) {
      toast({
        title: "Fix Failed",
        description: "Could not resolve dependency issue",
        variant: "destructive"
      });
    }
  };

  const criticalIssues = dependencyIssues.filter(issue => issue.severity === 'critical');
  const highIssues = dependencyIssues.filter(issue => issue.severity === 'high');

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Network className="h-5 w-5" />
          Data Relationships & Dependencies
        </CardTitle>
        <CardDescription>
          Visualize data relationships and identify integrity issues
        </CardDescription>
        <div className="flex gap-2">
          <Button onClick={loadRelationshipData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="relationships" className="space-y-6">
          <TabsList>
            <TabsTrigger value="relationships">Relationships</TabsTrigger>
            <TabsTrigger value="issues" className="relative">
              Issues
              {dependencyIssues.length > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 text-xs">
                  {dependencyIssues.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="diagram">Visual Diagram</TabsTrigger>
          </TabsList>

          <TabsContent value="relationships" className="space-y-4">
            {loading ? (
              <div className="text-center py-8">Loading relationships...</div>
            ) : relationships.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No relationships found
              </div>
            ) : (
              <div className="space-y-4">
                {relationships.map((rel, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className="font-mono">
                          {rel.fromTable}
                        </Badge>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">
                            {rel.fromField}
                          </span>
                          <div className="flex items-center gap-1">
                            <span className="text-xs bg-muted px-2 py-1 rounded">
                              {getRelationshipIcon(rel.type)}
                            </span>
                            <Link className="h-4 w-4 text-muted-foreground" />
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {rel.toField}
                          </span>
                        </div>
                        <Badge variant="outline" className="font-mono">
                          {rel.toTable}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        {rel.isRequired && (
                          <Badge variant="secondary" className="text-xs">
                            Required
                          </Badge>
                        )}
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="issues" className="space-y-4">
            {criticalIssues.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>{criticalIssues.length} critical issue(s)</strong> found that require immediate attention.
                </AlertDescription>
              </Alert>
            )}

            {loading ? (
              <div className="text-center py-8">Checking for issues...</div>
            ) : dependencyIssues.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No dependency issues found ✅
              </div>
            ) : (
              <div className="space-y-4">
                {dependencyIssues.map((issue) => (
                  <Card key={issue.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          {getIssueIcon(issue.type)}
                          <Badge variant={getSeverityColor(issue.severity)}>
                            {issue.severity.toUpperCase()}
                          </Badge>
                          <span className="font-mono text-sm">{issue.table}</span>
                          <span className="text-sm text-muted-foreground">
                            #{issue.record_id}
                          </span>
                        </div>
                        <p className="text-sm">{issue.description}</p>
                        <p className="text-sm text-muted-foreground">
                          <strong>Suggestion:</strong> {issue.suggestion}
                        </p>
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => fixDependencyIssue(issue.id)}
                        variant={issue.severity === 'critical' ? 'destructive' : 'outline'}
                      >
                        Fix
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="diagram" className="space-y-4">
            <div className="border rounded-lg p-8 min-h-[400px] bg-muted/10">
              <div className="text-center text-muted-foreground">
                <Network className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium mb-2">Visual Relationship Diagram</h3>
                <p className="text-sm">
                  Interactive diagram showing table relationships and dependencies
                </p>
                <p className="text-xs mt-2">
                  This feature would render an interactive graph visualization using libraries like D3.js or Cytoscape.js
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};