import React from 'react';
import { AlertCircle, RefreshCw, RotateCcw, Bug } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface ErrorFallbackProps {
  error: Error | null;
  onReset: () => void;
  onReload: () => void;
}

/**
 * Error Fallback UI component for graceful error handling
 */
export const ErrorFallback: React.FC<ErrorFallbackProps> = ({ error, onReset, onReload }) => {
  const [showDetails, setShowDetails] = React.useState(false);

  const copyErrorDetails = () => {
    const errorDetails = {
      message: error?.message || 'Unknown error',
      stack: error?.stack || 'No stack trace available',
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href
    };

    navigator.clipboard.writeText(JSON.stringify(errorDetails, null, 2))
      .then(() => {
        // Could show a toast here
        console.log('Error details copied to clipboard');
      })
      .catch(err => {
        console.error('Failed to copy error details:', err);
      });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-2xl p-6 space-y-6">
        <div className="flex items-center gap-3 text-destructive">
          <AlertCircle className="h-8 w-8" />
          <div>
            <h1 className="text-2xl font-bold">Test Calendar Error</h1>
            <p className="text-muted-foreground">
              Something went wrong with the Test Calendar
            </p>
          </div>
        </div>

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            The Test Calendar encountered an unexpected error. You can try refreshing the page or resetting the component.
          </AlertDescription>
        </Alert>

        {error && (
          <div className="space-y-3">
            <h3 className="font-semibold">Error Details:</h3>
            <div className="text-sm text-muted-foreground p-3 bg-muted rounded-md">
              <p className="font-mono">{error.message}</p>
            </div>

            <Collapsible open={showDetails} onOpenChange={setShowDetails}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full">
                  <Bug className="h-4 w-4 mr-2" />
                  {showDetails ? 'Hide' : 'Show'} Technical Details
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-3">
                <div className="text-xs font-mono bg-muted p-3 rounded-md max-h-40 overflow-auto">
                  <pre className="whitespace-pre-wrap">{error.stack}</pre>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={copyErrorDetails}
                  className="w-full"
                >
                  Copy Error Details
                </Button>
              </CollapsibleContent>
            </Collapsible>
          </div>
        )}

        <div className="flex gap-3 flex-col sm:flex-row">
          <Button onClick={onReset} className="flex-1">
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset Component
          </Button>
          <Button onClick={onReload} variant="outline" className="flex-1">
            <RefreshCw className="h-4 w-4 mr-2" />
            Reload Page
          </Button>
        </div>

        <div className="text-xs text-muted-foreground text-center">
          If this problem persists, please contact the system administrator.
        </div>
      </Card>
    </div>
  );
};