// Dynamic Form Builder for Mix Design Manager
// Phase 2: Dynamic Form Generation & UI Components
// Created: 2025-01-31

import React, { useState, useEffect } from 'react';
import { useForm, Controller, FieldPath } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Loader2, Save, AlertCircle, CheckCircle } from 'lucide-react';
import { mixDesignService, type MixDesignField, type ProductType } from '@/services/database/mixDesignService';
import { useToast } from '@/hooks/use-toast';

export interface DynamicFormProps {
  productTypeId: string;
  initialData?: Record<string, any>;
  mixDesignId?: string;
  isTemplate?: boolean;
  onSave?: (data: Record<string, any>) => void;
  onCancel?: () => void;
  mode?: 'create' | 'edit' | 'view';
  className?: string;
}

export interface FormFieldConfig {
  field: MixDesignField;
  validation: z.ZodType<any>;
  component: React.ComponentType<any>;
}

export const DynamicMixDesignForm: React.FC<DynamicFormProps> = ({
  productTypeId,
  initialData = {},
  mixDesignId,
  isTemplate = false,
  onSave,
  onCancel,
  mode = 'create',
  className = ''
}) => {
  const [fields, setFields] = useState<MixDesignField[]>([]);
  const [productType, setProductType] = useState<ProductType | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  // Load form fields and product type
  useEffect(() => {
    loadFormConfiguration();
  }, [productTypeId]);

  const loadFormConfiguration = async () => {
    try {
      setLoading(true);
      const [formFields, productTypes] = await Promise.all([
        mixDesignService.getMixDesignFields(productTypeId),
        mixDesignService.getProductTypes()
      ]);

      const currentProductType = productTypes.find(pt => pt.id === productTypeId);
      
      setFields(formFields);
      setProductType(currentProductType || null);
    } catch (error) {
      console.error('Failed to load form configuration:', error);
      toast({
        title: "Error",
        description: "Failed to load form configuration",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Generate dynamic Zod schema based on field definitions
  const generateValidationSchema = (fields: MixDesignField[]) => {
    const schemaFields: Record<string, z.ZodType<any>> = {};

    fields.forEach(field => {
      let fieldSchema: z.ZodType<any>;

      switch (field.field_type) {
        case 'text':
          fieldSchema = z.string();
          break;
        case 'textarea':
          fieldSchema = z.string();
          break;
        case 'number':
          fieldSchema = z.coerce.number();
          break;
        case 'select':
          fieldSchema = z.string();
          break;
        case 'date':
          fieldSchema = z.string();
          break;
        default:
          fieldSchema = z.string();
      }

      // Apply validation rules
      if (field.validation_rules) {
        try {
          const rules = JSON.parse(field.validation_rules);
          
          if (field.field_type === 'number') {
            if (rules.min !== undefined) {
              fieldSchema = (fieldSchema as z.ZodNumber).min(rules.min, `Minimum value is ${rules.min}`);
            }
            if (rules.max !== undefined) {
              fieldSchema = (fieldSchema as z.ZodNumber).max(rules.max, `Maximum value is ${rules.max}`);
            }
            if (rules.step !== undefined) {
              fieldSchema = (fieldSchema as z.ZodNumber).step(rules.step, `Value must be in steps of ${rules.step}`);
            }
          }

          if (field.field_type === 'select' && rules.options) {
            fieldSchema = z.enum(rules.options as [string, ...string[]]);
          }

          if (field.field_type === 'text' || field.field_type === 'textarea') {
            if (rules.minLength !== undefined) {
              fieldSchema = (fieldSchema as z.ZodString).min(rules.minLength, `Minimum length is ${rules.minLength}`);
            }
            if (rules.maxLength !== undefined) {
              fieldSchema = (fieldSchema as z.ZodString).max(rules.maxLength, `Maximum length is ${rules.maxLength}`);
            }
            if (rules.pattern) {
              fieldSchema = (fieldSchema as z.ZodString).regex(new RegExp(rules.pattern), rules.patternMessage || 'Invalid format');
            }
          }
        } catch (error) {
          console.warn(`Invalid validation rules for field ${field.field_name}:`, error);
        }
      }

      // Make field optional or required
      if (!field.is_required) {
        fieldSchema = fieldSchema.optional();
      }

      schemaFields[field.field_name] = fieldSchema;
    });

    return z.object(schemaFields);
  };

  // Form setup with dynamic schema
  const schema = generateValidationSchema(fields);
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: initialData,
    mode: 'onChange'
  });

  // Handle form submission
  const onSubmit = async (data: Record<string, any>) => {
    try {
      setSaving(true);
      setValidationErrors({});

      // Validate each field individually for custom messages
      const fieldValidationErrors: Record<string, string> = {};
      
      for (const field of fields) {
        const value = data[field.field_name];
        const validationResult = mixDesignService.validateFieldValue(field, value);
        
        if (!validationResult.isValid && validationResult.error) {
          fieldValidationErrors[field.field_name] = validationResult.error;
        }
      }

      if (Object.keys(fieldValidationErrors).length > 0) {
        setValidationErrors(fieldValidationErrors);
        toast({
          title: "Validation Error",
          description: "Please correct the highlighted fields",
          variant: "destructive"
        });
        return;
      }

      // Call parent save handler
      if (onSave) {
        await onSave(data);
      }

      toast({
        title: "Success",
        description: `Mix design ${mode === 'create' ? 'created' : 'updated'} successfully`,
      });

    } catch (error) {
      console.error('Form submission error:', error);
      toast({
        title: "Error",
        description: `Failed to ${mode === 'create' ? 'create' : 'update'} mix design`,
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  // Render individual field based on type
  const renderField = (field: MixDesignField) => {
    const fieldName = field.field_name as FieldPath<Record<string, any>>;
    const hasError = validationErrors[field.field_name] || form.formState.errors[field.field_name];
    const isReadOnly = mode === 'view';

    const fieldProps = {
      disabled: isReadOnly || saving,
      className: hasError ? 'border-destructive' : ''
    };

    switch (field.field_type) {
      case 'text':
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Input
                {...controllerField}
                {...fieldProps}
                type="text"
                placeholder={field.default_value}
              />
            )}
          />
        );

      case 'textarea':
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Textarea
                {...controllerField}
                {...fieldProps}
                placeholder={field.default_value}
                rows={3}
              />
            )}
          />
        );

      case 'number':
        const rules = field.validation_rules ? JSON.parse(field.validation_rules) : {};
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Input
                {...controllerField}
                {...fieldProps}
                type="number"
                step={rules.step || 'any'}
                min={rules.min}
                max={rules.max}
                placeholder={field.default_value}
              />
            )}
          />
        );

      case 'select':
        const selectRules = field.validation_rules ? JSON.parse(field.validation_rules) : {};
        const options = selectRules.options || [];
        
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Select
                value={controllerField.value}
                onValueChange={controllerField.onChange}
                disabled={fieldProps.disabled}
              >
                <SelectTrigger className={fieldProps.className}>
                  <SelectValue placeholder={`Select ${field.field_label}`} />
                </SelectTrigger>
                <SelectContent>
                  {options.filter((option: string) => option && option.trim()).map((option: string) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        );

      case 'date':
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Input
                {...controllerField}
                {...fieldProps}
                type="date"
              />
            )}
          />
        );

      default:
        return (
          <Controller
            name={fieldName}
            control={form.control}
            render={({ field: controllerField }) => (
              <Input
                {...controllerField}
                {...fieldProps}
                type="text"
                placeholder={field.default_value}
              />
            )}
          />
        );
    }
  };

  if (loading) {
    return (
      <Card className={className}>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin mr-2" />
          <span>Loading form configuration...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              {mode === 'create' ? 'Create' : mode === 'edit' ? 'Edit' : 'View'} Mix Design
              {isTemplate && <Badge variant="secondary">Template</Badge>}
            </CardTitle>
            {productType && (
              <CardDescription>
                Product Type: {productType.name} ({productType.category})
              </CardDescription>
            )}
          </div>
          <div className="flex gap-2">
            {mode !== 'view' && (
              <>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={saving}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  form="mix-design-form"
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </>
                  )}
                </Button>
              </>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <form
          id="mix-design-form"
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6"
        >
          {/* Group fields by categories if needed */}
          {fields.length === 0 ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No fields configured for this product type. Please contact an administrator to set up the form fields.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {fields.map((field, index) => (
                <div key={field.id} className="space-y-2">
                  <Label htmlFor={field.field_name} className="text-sm font-medium">
                    {field.field_label}
                    {field.is_required && <span className="text-destructive ml-1">*</span>}
                    {field.field_unit && (
                      <span className="text-muted-foreground ml-1">({field.field_unit})</span>
                    )}
                  </Label>
                  
                  {renderField(field)}
                  
                  {/* Field validation error */}
                  {(validationErrors[field.field_name] || form.formState.errors[field.field_name]) && (
                    <div className="text-sm text-destructive flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      {validationErrors[field.field_name] || form.formState.errors[field.field_name]?.message?.toString()}
                    </div>
                  )}
                  
                  {/* Field help text from validation rules */}
                  {field.validation_rules && (
                    <div className="text-xs text-muted-foreground">
                      {(() => {
                        try {
                          const rules = JSON.parse(field.validation_rules);
                          const hints: string[] = [];
                          
                          if (field.field_type === 'number') {
                            if (rules.min !== undefined && rules.max !== undefined) {
                              hints.push(`Range: ${rules.min} - ${rules.max}`);
                            } else if (rules.min !== undefined) {
                              hints.push(`Minimum: ${rules.min}`);
                            } else if (rules.max !== undefined) {
                              hints.push(`Maximum: ${rules.max}`);
                            }
                          }
                          
                          return hints.length > 0 ? hints.join(', ') : null;
                        } catch {
                          return null;
                        }
                      })()}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Form-level validation summary */}
          {Object.keys(validationErrors).length > 0 && (
            <>
              <Separator />
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Please correct the following errors:
                  <ul className="list-disc list-inside mt-2">
                    {Object.entries(validationErrors).map(([field, error]) => (
                      <li key={field} className="text-sm">
                        <strong>{fields.find(f => f.field_name === field)?.field_label || field}:</strong> {error}
                      </li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            </>
          )}
        </form>
      </CardContent>
    </Card>
  );
};