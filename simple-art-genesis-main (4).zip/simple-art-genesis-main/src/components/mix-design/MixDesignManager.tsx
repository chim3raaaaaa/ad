// Mix Design Manager Component - Main UI with Dynamic Form Integration
// Phase 2: Dynamic Form Generation & UI Components
// Created: 2025-01-31

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { 
  Plus, 
  Search, 
  Filter, 
  FileText, 
  Edit3, 
  Copy, 
  Trash2, 
  Download, 
  Upload,
  History,
  AlertCircle,
  CheckCircle,
  Clock,
  Archive
} from 'lucide-react';
import { DynamicMixDesignForm } from './DynamicMixDesignForm';
import { mixDesignService, type MixDesign, type ProductType, type MixDesignTemplate } from '@/services/database/mixDesignService';
import { mixDesignDatabaseService } from '@/services/database/mixDesignDatabaseService';
import { useToast } from '@/hooks/use-toast';

export interface MixDesignManagerProps {
  currentUserId: string;
  userRole: string;
  className?: string;
}

const MixDesignManager: React.FC<MixDesignManagerProps> = ({
  currentUserId,
  userRole,
  className = ''
}) => {
  // State management
  const [activeTab, setActiveTab] = useState<'designs' | 'templates' | 'trials'>('designs');
  const [showForm, setShowForm] = useState(false);
  const [selectedDesign, setSelectedDesign] = useState<MixDesign | null>(null);
  const [selectedProductType, setSelectedProductType] = useState<string>('all');
  const [formMode, setFormMode] = useState<'create' | 'edit' | 'view'>('create');
  
  // Data state
  const [mixDesigns, setMixDesigns] = useState<MixDesign[]>([]);
  const [templates, setTemplates] = useState<MixDesignTemplate[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const { toast } = useToast();

  // Initialize component
  useEffect(() => {
    initializeComponent();
  }, []);

  const initializeComponent = async () => {
    try {
      setLoading(true);
      
      // Initialize database if needed
      await mixDesignDatabaseService.initialize();
      
      // Load data
      await Promise.all([
        loadMixDesigns(),
        loadTemplates(),
        loadProductTypes()
      ]);
      
    } catch (error) {
      console.error('Failed to initialize Mix Design Manager:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to load Mix Design Manager",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadMixDesigns = async () => {
    try {
      const designs = await mixDesignService.getMixDesigns();
      setMixDesigns(designs);
    } catch (error) {
      console.error('Failed to load mix designs:', error);
    }
  };

  const loadTemplates = async () => {
    try {
      const templateList = await mixDesignService.getMixDesignTemplates();
      setTemplates(templateList);
    } catch (error) {
      console.error('Failed to load templates:', error);
    }
  };

  const loadProductTypes = async () => {
    try {
      const types = await mixDesignService.getProductTypes();
      setProductTypes(types);
    } catch (error) {
      console.error('Failed to load product types:', error);
    }
  };

  // Form handlers
  const handleCreateNew = () => {
    if (selectedProductType === 'all') {
      toast({
        title: "Product Type Required",
        description: "Please select a specific product type first",
        variant: "destructive"
      });
      return;
    }
    
    setSelectedDesign(null);
    setFormMode('create');
    setShowForm(true);
  };

  const handleEditDesign = (design: MixDesign) => {
    setSelectedDesign(design);
    setSelectedProductType(design.product_type_id);
    setFormMode('edit');
    setShowForm(true);
  };

  const handleViewDesign = (design: MixDesign) => {
    setSelectedDesign(design);
    setSelectedProductType(design.product_type_id);
    setFormMode('view');
    setShowForm(true);
  };

  const handleFormSave = async (data: Record<string, any>) => {
    try {
      if (formMode === 'create') {
        const designData = {
          name: data.name || `New ${productTypes.find(pt => pt.id === selectedProductType)?.name} Design`,
          product_type_id: selectedProductType,
          design_data: JSON.stringify(data),
          status: 'draft' as const,
          created_by: currentUserId,
          is_template: false,
          version_number: 1,
          description: data.description || ''
        };
        
        await mixDesignService.createMixDesign(designData);
        
      } else if (formMode === 'edit' && selectedDesign) {
        await mixDesignService.updateMixDesign(selectedDesign.id, {
          design_data: JSON.stringify(data),
          updated_at: new Date().toISOString()
        });
      }
      
      await loadMixDesigns();
      setShowForm(false);
      setSelectedDesign(null);
      
    } catch (error) {
      console.error('Failed to save mix design:', error);
      throw error; // Re-throw to let form handle error display
    }
  };

  const handleFormCancel = () => {
    setShowForm(false);
    setSelectedDesign(null);
  };

  // Copy design as template
  const handleCopyAsTemplate = async (design: MixDesign) => {
    try {
      const templateData = {
        name: `${design.name} Template`,
        product_type_id: design.product_type_id,
        template_data: design.design_data,
        description: `Template created from ${design.name}`,
        is_public: false,
        created_by: currentUserId,
        usage_count: 0
      };
      
      await mixDesignService.createMixDesignTemplate(templateData);
      await loadTemplates();
      
      toast({
        title: "Template Created",
        description: `Template "${templateData.name}" created successfully`,
      });
      
    } catch (error) {
      console.error('Failed to create template:', error);
      toast({
        title: "Error",
        description: "Failed to create template",
        variant: "destructive"
      });
    }
  };

  // Delete design
  const handleDeleteDesign = async (design: MixDesign) => {
    if (!confirm(`Are you sure you want to delete "${design.name}"?`)) {
      return;
    }
    
    try {
      await mixDesignService.deleteMixDesign(design.id);
      await loadMixDesigns();
      
      toast({
        title: "Design Deleted",
        description: `"${design.name}" has been deleted`,
      });
      
    } catch (error) {
      console.error('Failed to delete design:', error);
      toast({
        title: "Error",
        description: "Failed to delete design",
        variant: "destructive"
      });
    }
  };

  // Filter designs
  const filteredDesigns = mixDesigns.filter(design => {
    const matchesSearch = design.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         design.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || design.status === statusFilter;
    const matchesProductType = selectedProductType === 'all' || design.product_type_id === selectedProductType;
    
    return matchesSearch && matchesStatus && matchesProductType;
  });

  // Status badge color
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'draft': return 'secondary';
      case 'archived': return 'outline';
      case 'under_review': return 'destructive';
      default: return 'secondary';
    }
  };

  // Status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-3 w-3" />;
      case 'draft': return <Edit3 className="h-3 w-3" />;
      case 'archived': return <Archive className="h-3 w-3" />;
      case 'under_review': return <Clock className="h-3 w-3" />;
      default: return <AlertCircle className="h-3 w-3" />;
    }
  };

  if (loading) {
    return (
      <Card className={className}>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Loading Mix Design Manager...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (showForm) {
    return (
      <DynamicMixDesignForm
        productTypeId={selectedProductType}
        initialData={selectedDesign ? JSON.parse(selectedDesign.design_data) : {}}
        mixDesignId={selectedDesign?.id}
        mode={formMode}
        onSave={handleFormSave}
        onCancel={handleFormCancel}
        className={className}
      />
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Mix Design Manager</span>
            <div className="flex items-center gap-2">
              {/* Product Type Selector */}
              <Select value={selectedProductType} onValueChange={setSelectedProductType}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select Product Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Product Types</SelectItem>
                  {productTypes.map(type => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name} ({type.category})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button onClick={handleCreateNew} disabled={selectedProductType === 'all'}>
                <Plus className="h-4 w-4 mr-2" />
                New Design
              </Button>
            </div>
          </CardTitle>
          <CardDescription>
            Create and manage mix designs with dynamic form fields based on product types
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Content Tabs */}
      <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
        <TabsList>
          <TabsTrigger value="designs">Mix Designs ({mixDesigns.length})</TabsTrigger>
          <TabsTrigger value="templates">Templates ({templates.length})</TabsTrigger>
          <TabsTrigger value="trials">Trials</TabsTrigger>
        </TabsList>

        <TabsContent value="designs" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="py-4">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search designs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="under_review">Under Review</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Mix Designs List */}
          {filteredDesigns.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Mix Designs Found</h3>
                <p className="text-muted-foreground mb-4">
                  {selectedProductType 
                    ? "No designs found for the selected product type and filters"
                    : "Select a product type and create your first mix design"}
                </p>
                {selectedProductType && (
                  <Button onClick={handleCreateNew}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create First Design
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDesigns.map(design => (
                <Card key={design.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">{design.name}</CardTitle>
                        <CardDescription className="text-sm">
                          {productTypes.find(pt => pt.id === design.product_type_id)?.name}
                        </CardDescription>
                      </div>
                      <Badge variant={getStatusBadgeVariant(design.status)} className="flex items-center gap-1">
                        {getStatusIcon(design.status)}
                        {design.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    {design.description && (
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {design.description}
                      </p>
                    )}
                    
                    <div className="text-xs text-muted-foreground mb-4">
                      <div>Created: {new Date(design.created_at).toLocaleDateString()}</div>
                      <div>Version: {design.version_number}</div>
                      {design.design_code && <div>Code: {design.design_code}</div>}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline" onClick={() => handleViewDesign(design)}>
                        <FileText className="h-3 w-3" />
                      </Button>
                      
                      {(userRole === 'admin' || userRole === 'manager' || design.created_by === currentUserId) && (
                        <>
                          <Button size="sm" variant="outline" onClick={() => handleEditDesign(design)}>
                            <Edit3 className="h-3 w-3" />
                          </Button>
                          
                          <Button size="sm" variant="outline" onClick={() => handleCopyAsTemplate(design)}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </>
                      )}
                      
                      {(userRole === 'admin' || design.created_by === currentUserId) && (
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleDeleteDesign(design)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Templates feature coming in Phase 3 - this will show reusable mix design templates
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="trials" className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Trial results integration coming in Phase 3 - this will show linked test results and performance analysis
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MixDesignManager;