import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useDataService } from '@/hooks/useDataService';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const memoFormSchema = z.object({
  ref: z.string().min(1, 'Reference is required'),
  product_type: z.string().min(1, 'Product type is required'),
  test_type: z.string().min(1, 'Test type is required'),
  mould_ref: z.string().min(1, 'Mould reference is required'),
  machine_no: z.string().min(1, 'Machine number is required'),
  product: z.string().min(1, 'Product is required'),
  climate_condition: z.string().min(1, 'Climate condition is required'),
  sampling_place: z.string().min(1, 'Sampling place is required'),
  colour: z.string().min(1, 'Colour is required'),
  remarks: z.string().optional(),
});

type MemoFormData = z.infer<typeof memoFormSchema>;

interface ReferenceData {
  labTests: any[];
  labMoulds: any[];
  labGroupCodes: any[];
  climaticConditions: any[];
  colours: any[];
  samplingPlaces: any[];
}

export const DynamicFormWithReferences: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [referenceData, setReferenceData] = useState<ReferenceData>({
    labTests: [],
    labMoulds: [],
    labGroupCodes: [],
    climaticConditions: [],
    colours: [],
    samplingPlaces: []
  });
  
  const dataService = useDataService();
  const { toast } = useToast();

  const form = useForm<MemoFormData>({
    resolver: zodResolver(memoFormSchema),
    defaultValues: {
      ref: '',
      product_type: '',
      test_type: '',
      mould_ref: '',
      machine_no: '',
      product: '',
      climate_condition: '',
      sampling_place: '',
      colour: '',
      remarks: ''
    }
  });

  const watchedProductType = form.watch('product_type');

  // Load reference data on component mount
  useEffect(() => {
    const loadReferenceData = async () => {
      setIsLoading(true);
      try {
        const [
          labTests,
          labMoulds,
          labGroupCodes,
          climaticConditions,
          colours,
          samplingPlaces
        ] = await Promise.all([
          dataService.getReferenceData('lab_tests', true),
          dataService.getReferenceData('lab_mould', true),
          dataService.getReferenceData('lab_group_code', true),
          dataService.getReferenceData('climatic_conditions', true),
          dataService.getReferenceData('colour', true),
          dataService.getReferenceData('sampling_places', true)
        ]);

        setReferenceData({
          labTests,
          labMoulds,
          labGroupCodes,
          climaticConditions,
          colours,
          samplingPlaces
        });
      } catch (error) {
        console.error('Failed to load reference data:', error);
        toast({
          title: 'Warning',
          description: 'Failed to load reference data. Some dropdowns may be empty.',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadReferenceData();
  }, [dataService, toast]);

  // Update sampling places when product type changes
  useEffect(() => {
    if (watchedProductType) {
      const loadFilteredSamplingPlaces = async () => {
        try {
          const filteredPlaces = await dataService.getFilteredSamplingPlaces(watchedProductType);
          setReferenceData(prev => ({
            ...prev,
            samplingPlaces: filteredPlaces
          }));
          
          // Clear sampling place selection if current value is not in filtered list
          const currentSamplingPlace = form.getValues('sampling_place');
          if (currentSamplingPlace && !filteredPlaces.some(place => place.code === currentSamplingPlace)) {
            form.setValue('sampling_place', '');
          }
        } catch (error) {
          console.error('Failed to load filtered sampling places:', error);
        }
      };

      loadFilteredSamplingPlaces();
    }
  }, [watchedProductType, dataService, form]);

  const onSubmit = async (data: MemoFormData) => {
    setIsSubmitting(true);
    try {
      // Transform form data to memo format
      const memoData = {
        ref: data.ref,
        production_data: [
          {
            productionNumber: `P-${Date.now()}`,
            productionDate: new Date().toISOString().split('T')[0],
            testDate: new Date().toISOString().split('T')[0],
            age: '28',
            product: data.product,
            grade: 'Standard',
            machineNo: data.machine_no,
            mouldRef: data.mould_ref,
            blockPositions: ['A1'],
            numberOfSamples: '1',
            blockPositionNumbers: ['1'],
            remarks: data.remarks || '',
            officer: 'System User',
            site: 'Default Site',
            typeOfTest: data.test_type,
            productType: data.product_type,
            climateCondition: data.climate_condition,
            samplingPlace: data.sampling_place,
            colour: data.colour
          }
        ],
        user_id: 'current-user'
      };

      const result = await dataService.createMemo(memoData);
      
      if (result.error) {
        throw new Error(result.error);
      }

      toast({
        title: 'Success',
        description: 'Memo created successfully with reference data.',
      });

      form.reset();
    } catch (error) {
      console.error('Failed to create memo:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create memo',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getUniqueProducts = () => {
    return Array.from(new Set(referenceData.labGroupCodes.map(item => item.lab_product)))
      .filter(Boolean)
      .map(product => ({ code: product, description: product }));
  };

  const getMachinesForProduct = (selectedProduct: string) => {
    return referenceData.labGroupCodes
      .filter(item => item.lab_product === selectedProduct)
      .map(item => ({ code: item.code, description: item.lab_machine }));
  };

  const getTestsForProductType = (productType: string) => {
    return referenceData.labTests.filter(test => 
      !test.product_type || test.product_type === productType || test.product_type === ''
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin" />
          <span className="ml-2">Loading reference data...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Memo with Reference Data</CardTitle>
        <CardDescription>
          Form populated with dynamic reference datasets
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Reference Field */}
              <FormField
                control={form.control}
                name="ref"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reference</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter memo reference" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Product Type */}
              <FormField
                control={form.control}
                name="product_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select product type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="blocks">Blocks</SelectItem>
                        <SelectItem value="aggregates">Aggregates</SelectItem>
                        <SelectItem value="pavings">Pavings</SelectItem>
                        <SelectItem value="concrete">Concrete</SelectItem>
                        <SelectItem value="railway_ballast">Railway Ballast</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Test Type - populated from lab_tests */}
              <FormField
                control={form.control}
                name="test_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Test Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select test type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getTestsForProductType(watchedProductType).map((test) => (
                          <SelectItem key={test.code} value={test.code}>
                            {test.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Mould Reference - populated from lab_mould */}
              <FormField
                control={form.control}
                name="mould_ref"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mould Reference</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select mould reference" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {referenceData.labMoulds.map((mould) => (
                          <SelectItem key={mould.code} value={mould.code}>
                            {mould.description || mould.code}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Product - populated from lab_group_code */}
              <FormField
                control={form.control}
                name="product"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select product" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getUniqueProducts().map((product) => (
                          <SelectItem key={product.code} value={product.code}>
                            {product.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Machine Number - filtered by selected product */}
              <FormField
                control={form.control}
                name="machine_no"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Machine Number</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select machine" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getMachinesForProduct(form.getValues('product')).map((machine) => (
                          <SelectItem key={machine.code} value={machine.code}>
                            {machine.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Climate Condition - populated from climatic_conditions */}
              <FormField
                control={form.control}
                name="climate_condition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Climate Condition</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select climate condition" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {referenceData.climaticConditions.map((condition) => (
                          <SelectItem key={condition.code} value={condition.code}>
                            {condition.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Sampling Place - filtered by product type */}
              <FormField
                control={form.control}
                name="sampling_place"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sampling Place</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sampling place" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {referenceData.samplingPlaces.map((place) => (
                          <SelectItem key={place.code} value={place.code}>
                            {place.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Colour - populated from colour */}
              <FormField
                control={form.control}
                name="colour"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Colour</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select colour" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {referenceData.colours.map((colour) => (
                          <SelectItem key={colour.code} value={colour.code}>
                            {colour.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Remarks */}
            <FormField
              control={form.control}
              name="remarks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Remarks</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter any additional remarks..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating Memo...
                </>
              ) : (
                'Create Memo'
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};