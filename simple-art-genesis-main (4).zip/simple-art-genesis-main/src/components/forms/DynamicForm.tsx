import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, Edit, Trash2, Plus, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { formSubmissionService } from '@/services/forms/formSubmissionService';

interface FormField {
  id: string;
  type: string;
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
  validation?: any;
}

interface FormDefinition {
  id: string;
  name: string;
  description?: string;
  fields: FormField[];
}

interface DynamicFormProps {
  formId: string;
  showSubmissions?: boolean;
  onSubmissionComplete?: (submissionId: string) => void;
}

export function DynamicForm({ formId, showSubmissions = false, onSubmissionComplete }: DynamicFormProps) {
  const { toast } = useToast();
  const [formDef, setFormDef] = useState<FormDefinition | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadFormDefinition();
    if (showSubmissions) {
      loadSubmissions();
    }
  }, [formId, showSubmissions]);

  const loadFormDefinition = async () => {
    try {
      setIsLoading(true);
      const definition = await formSubmissionService.getFormDefinition(formId);
      setFormDef(definition);
      
      // Initialize form data with default values
      const initialData: Record<string, any> = {};
      definition.fields.forEach((field: FormField) => {
        if (field.type === 'checkbox') {
          initialData[field.id] = false;
        } else {
          initialData[field.id] = '';
        }
      });
      setFormData(initialData);
    } catch (error) {
      console.error('Error loading form definition:', error);
      toast({
        title: "Error",
        description: "Failed to load form definition",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadSubmissions = async () => {
    try {
      const data = await formSubmissionService.getFormSubmissions(formId, 100);
      setSubmissions(data);
    } catch (error) {
      console.error('Error loading submissions:', error);
    }
  };

  const handleInputChange = (fieldId: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldId]: value
    }));
    
    // Clear validation error when user starts typing
    if (validationErrors[fieldId]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[fieldId];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    if (!formDef) return false;
    
    const errors: Record<string, string> = {};
    
    formDef.fields.forEach(field => {
      const value = formData[field.id];
      
      // Required field validation
      if (field.required && (!value || value === '')) {
        errors[field.id] = `${field.label} is required`;
      }
      
      // Email validation
      if (field.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        errors[field.id] = 'Please enter a valid email address';
      }
      
      // Number validation
      if (field.type === 'number' && value && isNaN(Number(value))) {
        errors[field.id] = 'Please enter a valid number';
      }
      
      // Custom validation
      if (field.validation && value) {
        if (field.validation.min && String(value).length < field.validation.min) {
          errors[field.id] = `Must be at least ${field.validation.min} characters`;
        }
        if (field.validation.max && String(value).length > field.validation.max) {
          errors[field.id] = `Must be no more than ${field.validation.max} characters`;
        }
        if (field.validation.pattern && !new RegExp(field.validation.pattern).test(value)) {
          errors[field.id] = field.validation.message || 'Invalid format';
        }
      }
    });
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors below",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const submissionId = await formSubmissionService.submitForm(formId, formData);
      
      toast({
        title: "Success",
        description: "Form submitted successfully",
      });

      // Reset form
      const initialData: Record<string, any> = {};
      formDef?.fields.forEach((field: FormField) => {
        if (field.type === 'checkbox') {
          initialData[field.id] = false;
        } else {
          initialData[field.id] = '';
        }
      });
      setFormData(initialData);

      // Reload submissions if showing them
      if (showSubmissions) {
        loadSubmissions();
      }

      // Call completion callback
      if (onSubmissionComplete) {
        onSubmissionComplete(submissionId);
      }

    } catch (error) {
      console.error('Error submitting form:', error);
      toast({
        title: "Submission Error",
        description: error instanceof Error ? error.message : "Failed to submit form",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderFormField = (field: FormField) => {
    const value = formData[field.id];
    const hasError = !!validationErrors[field.id];

    switch (field.type) {
      case 'text':
      case 'email':
      case 'password':
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={field.id}
              type={field.type}
              value={value || ''}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              placeholder={field.placeholder}
              className={hasError ? 'border-red-500' : ''}
            />
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      case 'number':
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={field.id}
              type="number"
              value={value || ''}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              placeholder={field.placeholder}
              className={hasError ? 'border-red-500' : ''}
            />
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      case 'textarea':
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Textarea
              id={field.id}
              value={value || ''}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              placeholder={field.placeholder}
              className={hasError ? 'border-red-500' : ''}
              rows={3}
            />
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      case 'select':
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Select value={value || ''} onValueChange={(newValue) => handleInputChange(field.id, newValue)}>
              <SelectTrigger className={hasError ? 'border-red-500' : ''}>
                <SelectValue placeholder={field.placeholder || 'Select an option'} />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map(option => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      case 'checkbox':
        return (
          <div key={field.id} className="flex items-center space-x-2">
            <Checkbox
              id={field.id}
              checked={value || false}
              onCheckedChange={(checked) => handleInputChange(field.id, checked)}
            />
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      case 'date':
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id}>
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={field.id}
              type="date"
              value={value || ''}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              className={hasError ? 'border-red-500' : ''}
            />
            {hasError && (
              <div className="flex items-center gap-1 text-sm text-red-500">
                <AlertCircle className="w-4 h-4" />
                {validationErrors[field.id]}
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  const deleteSubmission = async (submissionId: string) => {
    try {
      await formSubmissionService.deleteFormSubmission(formId, submissionId);
      toast({
        title: "Success",
        description: "Submission deleted successfully"
      });
      loadSubmissions();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete submission",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading form...</div>
        </CardContent>
      </Card>
    );
  }

  if (!formDef) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">Form not found</div>
        </CardContent>
      </Card>
    );
  }

  if (showSubmissions) {
    return (
      <Tabs defaultValue="form" className="space-y-4">
        <TabsList>
          <TabsTrigger value="form">Form</TabsTrigger>
          <TabsTrigger value="submissions">
            Submissions ({submissions.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="form">
          <Card>
            <CardHeader>
              <CardTitle>{formDef.name}</CardTitle>
              {formDef.description && (
                <p className="text-sm text-muted-foreground">{formDef.description}</p>
              )}
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {formDef.fields.map(renderFormField)}
                <Button type="submit" disabled={isSubmitting} className="w-full">
                  {isSubmitting ? 'Submitting...' : 'Submit'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="submissions">
          <Card>
            <CardHeader>
              <CardTitle>Form Submissions</CardTitle>
            </CardHeader>
            <CardContent>
              {submissions.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  No submissions yet
                </div>
              ) : (
                <div className="space-y-4">
                  {submissions.map((submission) => (
                    <Card key={submission.id} className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <Badge variant="outline">
                          {new Date(submission.submitted_at).toLocaleString()}
                        </Badge>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => deleteSubmission(submission.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        {formDef.fields.map(field => (
                          <div key={field.id}>
                            <span className="font-medium">{field.label}:</span>{' '}
                            <span className="text-muted-foreground">
                              {submission[field.id.replace(/[^a-zA-Z0-9]/g, '_')] || 'N/A'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{formDef.name}</CardTitle>
        {formDef.description && (
          <p className="text-sm text-muted-foreground">{formDef.description}</p>
        )}
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {formDef.fields.map(renderFormField)}
          <Button type="submit" disabled={isSubmitting} className="w-full">
            {isSubmitting ? 'Submitting...' : 'Submit'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}