import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, AlertCircle, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Reference Data Hooks
import {
  useProductCategories,
  useProducts,
  useGrades,
  useMachines,
  useMouldReferences,
  usePlants,
  useOfficers,
  useAggregates,
  useAdmixtures,
  useFreeWaterTypes,
  useCementTypes,
  useVibratorStatuses,
  useConformityOptions,
  useTestTypes,
  useReferenceDataValidation
} from '@/hooks/useReferenceData';

import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';

// ============= FORM FIELD TYPES =============

interface FormFieldConfig {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'reference' | 'date' | 'checkbox';
  required?: boolean;
  referenceType?: 'category' | 'product' | 'grade' | 'machine' | 'mould' | 'plant' | 'officer' | 
                   'aggregate' | 'admixture' | 'water' | 'cement' | 'vibrator' | 'conformity' | 'testType';
  dependsOn?: string; // Field dependency for cascading dropdowns
  validation?: z.ZodType<any>;
  placeholder?: string;
  description?: string;
}

interface EnhancedDynamicFormProps {
  fields: FormFieldConfig[];
  onSubmit: (data: Record<string, any>) => Promise<void>;
  initialData?: Record<string, any>;
  title: string;
  description?: string;
  validateOnSubmit?: boolean;
  showValidationStatus?: boolean;
}

// ============= ENHANCED DYNAMIC FORM COMPONENT =============

export const EnhancedDynamicForm: React.FC<EnhancedDynamicFormProps> = ({
  fields,
  onSubmit,
  initialData = {},
  title,
  description,
  validateOnSubmit = true,
  showValidationStatus = true
}) => {
  const { toast } = useToast();
  const { validateTestData, isValidating } = useReferenceDataValidation();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isValid, setIsValid] = useState<boolean | null>(null);

  // Reference data hooks
  const { data: categories, loading: categoriesLoading } = useProductCategories();
  const { data: allProducts, loading: productsLoading } = useProducts();
  const { data: grades, loading: gradesLoading } = useGrades();
  const { data: machines, loading: machinesLoading } = useMachines();
  const { data: moulds, loading: mouldsLoading } = useMouldReferences();
  const { data: plants, loading: plantsLoading } = usePlants();
  const { data: officers, loading: officersLoading } = useOfficers();
  const { data: aggregates, loading: aggregatesLoading } = useAggregates();
  const { data: admixtures, loading: admixturesLoading } = useAdmixtures();
  const { data: waterTypes, loading: waterLoading } = useFreeWaterTypes();
  const { data: cementTypes, loading: cementLoading } = useCementTypes();
  const { data: vibratorStatuses, loading: vibratorLoading } = useVibratorStatuses();
  const { data: conformityOptions, loading: conformityLoading } = useConformityOptions();
  const { data: testTypes, loading: testTypesLoading } = useTestTypes();

  // Create dynamic form schema based on field configurations
  const createFormSchema = () => {
    const schemaFields: Record<string, z.ZodType<any>> = {};
    
    fields.forEach(field => {
      let fieldSchema: z.ZodType<any>;
      
      if (field.validation) {
        fieldSchema = field.validation;
      } else {
        switch (field.type) {
          case 'number':
            fieldSchema = z.coerce.number();
            break;
          case 'select':
          case 'reference':
            fieldSchema = z.string().min(1, `${field.label} is required`);
            break;
          case 'checkbox':
            fieldSchema = z.boolean();
            break;
          default:
            fieldSchema = z.string();
        }
      }
      
      if (!field.required && field.type !== 'checkbox') {
        fieldSchema = fieldSchema.optional();
      }
      
      schemaFields[field.name] = fieldSchema;
    });
    
    return z.object(schemaFields);
  };

  const form = useForm({
    resolver: zodResolver(createFormSchema()),
    defaultValues: initialData
  });

  const watchedValues = form.watch();

  // Real-time validation
  useEffect(() => {
    if (showValidationStatus && validateOnSubmit) {
      const debounceValidation = setTimeout(async () => {
        const formData = form.getValues();
        const hasRequiredFields = fields
          .filter(f => f.required)
          .every(f => formData[f.name] && formData[f.name] !== '');
        
        if (hasRequiredFields) {
          const validation = await validateTestData(formData);
          setValidationErrors(validation.errors);
          setIsValid(validation.isValid);
        } else {
          setIsValid(null);
          setValidationErrors([]);
        }
      }, 500);

      return () => clearTimeout(debounceValidation);
    }
  }, [watchedValues, validateTestData, showValidationStatus, validateOnSubmit, fields, form]);

  // Get reference data options based on type
  const getReferenceOptions = (referenceType: string, dependentValue?: string) => {
    switch (referenceType) {
      case 'category':
        return categories?.map(c => ({ value: c.category_id, label: c.name })) || [];
      case 'product':
        const filteredProducts = dependentValue 
          ? allProducts?.filter(p => p.category_id === dependentValue) || []
          : allProducts || [];
        return filteredProducts.map(p => ({ value: p.product_id, label: p.name }));
      case 'grade':
        return grades?.map(g => ({ value: g.grade_id, label: g.name })) || [];
      case 'machine':
        return machines?.map(m => ({ value: m.machine_id, label: m.name })) || [];
      case 'mould':
        return moulds?.map(m => ({ value: m.mould_id, label: m.name })) || [];
      case 'plant':
        return plants?.map(p => ({ value: p.plant_id, label: p.name })) || [];
      case 'officer':
        return officers?.map(o => ({ value: o.officer_id, label: o.name })) || [];
      case 'aggregate':
        return aggregates?.map(a => ({ value: a.aggregate_id, label: `${a.name} (${a.size_range})` })) || [];
      case 'admixture':
        return admixtures?.map(a => ({ value: a.admixture_id, label: a.name })) || [];
      case 'water':
        return waterTypes?.map(w => ({ value: w.water_id, label: w.name })) || [];
      case 'cement':
        return cementTypes?.map(c => ({ value: c.cement_id, label: c.name })) || [];
      case 'vibrator':
        return vibratorStatuses?.map(v => ({ value: v.status_id, label: v.name })) || [];
      case 'conformity':
        return conformityOptions?.map(c => ({ value: c.option_id, label: `${c.symbol} - ${c.name}` })) || [];
      case 'testType':
        return testTypes?.map(t => ({ value: t.test_type_id, label: t.name })) || [];
      default:
        return [];
    }
  };

  const isReferenceDataLoading = (referenceType: string) => {
    switch (referenceType) {
      case 'category': return categoriesLoading;
      case 'product': return productsLoading;
      case 'grade': return gradesLoading;
      case 'machine': return machinesLoading;
      case 'mould': return mouldsLoading;
      case 'plant': return plantsLoading;
      case 'officer': return officersLoading;
      case 'aggregate': return aggregatesLoading;
      case 'admixture': return admixturesLoading;
      case 'water': return waterLoading;
      case 'cement': return cementLoading;
      case 'vibrator': return vibratorLoading;
      case 'conformity': return conformityLoading;
      case 'testType': return testTypesLoading;
      default: return false;
    }
  };

  const handleSubmit = async (data: Record<string, any>) => {
    setIsSubmitting(true);
    
    try {
      // Validate against reference data if required
      if (validateOnSubmit) {
        const validation = await validateTestData(data);
        if (!validation.isValid) {
          setValidationErrors(validation.errors);
          setIsValid(false);
          toast({
            title: "Validation Failed",
            description: `Please fix the following errors: ${validation.errors.join(', ')}`,
            variant: "destructive"
          });
          return;
        }
      }

      await onSubmit(data);
      
      toast({
        title: "Success",
        description: "Form submitted successfully",
      });
      
    } catch (error) {
      console.error('Form submission failed:', error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderField = (field: FormFieldConfig) => {
    const dependentValue = field.dependsOn ? watchedValues[field.dependsOn] : undefined;
    
    switch (field.type) {
      case 'select':
      case 'reference':
        if (field.referenceType) {
          const options = getReferenceOptions(field.referenceType, dependentValue);
          const isLoading = isReferenceDataLoading(field.referenceType);
          
          return (
            <FormField
              key={field.name}
              control={form.control}
              name={field.name}
              render={({ field: formField }) => (
                <FormItem>
                  <FormLabel>
                    {field.label}
                    {field.required && <span className="text-destructive ml-1">*</span>}
                    {isLoading && <Loader2 className="h-3 w-3 ml-2 animate-spin inline" />}
                  </FormLabel>
                  <Select 
                    onValueChange={formField.onChange} 
                    defaultValue={formField.value}
                    disabled={isLoading || options.length === 0}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder={field.placeholder || `Select ${field.label.toLowerCase()}`} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-background border shadow-lg z-50">
                      {options.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {field.description && (
                    <p className="text-sm text-muted-foreground">{field.description}</p>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
          );
        }
        break;
        
      case 'number':
        return (
          <FormField
            key={field.name}
            control={form.control}
            name={field.name}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.label}
                  {field.required && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder={field.placeholder}
                    {...formField}
                    onChange={(e) => formField.onChange(e.target.valueAsNumber)}
                  />
                </FormControl>
                {field.description && (
                  <p className="text-sm text-muted-foreground">{field.description}</p>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        );
        
      default:
        return (
          <FormField
            key={field.name}
            control={form.control}
            name={field.name}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.label}
                  {field.required && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    type={field.type === 'date' ? 'date' : 'text'}
                    placeholder={field.placeholder}
                    {...formField}
                  />
                </FormControl>
                {field.description && (
                  <p className="text-sm text-muted-foreground">{field.description}</p>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        );
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          {title}
        </CardTitle>
        {description && (
          <CardDescription>{description}</CardDescription>
        )}
        
        {/* Validation Status */}
        {showValidationStatus && (
          <div className="space-y-2">
            {isValidating && (
              <Alert>
                <Loader2 className="h-4 w-4 animate-spin" />
                <AlertDescription>Validating against reference data...</AlertDescription>
              </Alert>
            )}
            
            {isValid === true && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  All fields validated successfully against reference datasets
                </AlertDescription>
              </Alert>
            )}
            
            {isValid === false && validationErrors.length > 0 && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-1">
                    <p className="font-medium">Reference data validation errors:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {validationErrors.map((error, index) => (
                        <li key={index} className="text-sm">{error}</li>
                      ))}
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              {fields.map(renderField)}
            </div>
            
            <div className="flex justify-between items-center pt-4">
              <div className="flex items-center gap-2">
                {isValid === true && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Validated
                  </Badge>
                )}
                {isValid === false && (
                  <Badge variant="destructive">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    Validation Failed
                  </Badge>
                )}
              </div>
              
              <Button 
                type="submit" 
                disabled={isSubmitting || (validateOnSubmit && isValid === false)}
                className="min-w-[120px]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  'Submit'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};