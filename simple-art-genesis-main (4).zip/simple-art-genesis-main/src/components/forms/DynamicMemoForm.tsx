import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';
import type { ProductCategory, Product, Officer, Plant } from '@/services/database/enhancedReferenceDataService';
import { testModuleService } from '@/services/database/testModuleServices';
import { Loader2, Plus, Trash2 } from 'lucide-react';

interface MemoData {
  title: string;
  description: string;
  categoryId: string;
  productId: string;
  officerId: string;
  labSiteId: string;
  testDate: string;
  productions: ProductionData[];
}

interface ProductionData {
  id: string;
  date: string;
  machine: string;
  mould: string;
  samples: number;
  notes: string;
}

interface DynamicMemoFormProps {
  onSubmit: (memoData: MemoData) => void;
  onCancel: () => void;
  initialData?: Partial<MemoData>;
  isLoading?: boolean;
}

export function DynamicMemoForm({ onSubmit, onCancel, initialData, isLoading }: DynamicMemoFormProps) {
  // Form data state
  const [formData, setFormData] = useState<MemoData>({
    title: '',
    description: '',
    categoryId: '',
    productId: '',
    officerId: '',
    labSiteId: '',
    testDate: new Date().toISOString().split('T')[0],
    productions: []
  });

  // Reference data state
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [officers, setOfficers] = useState<Officer[]>([]);
  const [labSites, setLabSites] = useState<Plant[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Loading states
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadReferenceData();
  }, []);

  useEffect(() => {
    if (initialData) {
      setFormData(prev => ({ ...prev, ...initialData }));
    }
  }, [initialData]);

  useEffect(() => {
    // Filter products when category changes
    if (formData.categoryId) {
      const filtered = products.filter(p => p.category_id === formData.categoryId);
      setFilteredProducts(filtered);
      
      // Clear product selection if it doesn't match the new category
      if (formData.productId && !filtered.find(p => p.product_id === formData.productId)) {
        setFormData(prev => ({ ...prev, productId: '' }));
        setSelectedProduct(null);
      }
    } else {
      setFilteredProducts([]);
      setFormData(prev => ({ ...prev, productId: '' }));
      setSelectedProduct(null);
    }
  }, [formData.categoryId, products]);

  useEffect(() => {
    // Update selected product when product ID changes
    if (formData.productId) {
      const product = products.find(p => p.product_id === formData.productId);
      setSelectedProduct(product || null);
    } else {
      setSelectedProduct(null);
    }
  }, [formData.productId, products]);

  const loadReferenceData = async () => {
    setIsLoadingData(true);
    try {
      const [categoriesData, productsData, officersData, labSitesData] = await Promise.all([
        enhancedReferenceDataService.getProductCategories(),
        enhancedReferenceDataService.getAllProducts(),
        enhancedReferenceDataService.getOfficers(),
        enhancedReferenceDataService.getPlants()
      ]);

      setCategories(categoriesData);
      setProducts(productsData);
      setOfficers(officersData);
      setLabSites(labSitesData);

      // Check if reference data is available
      if (categoriesData.length === 0 || productsData.length === 0) {
        toast({
          title: "Reference Data Missing",
          description: "Please upload product categories and products data first",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Failed to load reference data:', error);
      toast({
        title: "Error",
        description: "Failed to load reference data",
        variant: "destructive"
      });
    } finally {
      setIsLoadingData(false);
    }
  };

  const handleInputChange = (field: keyof MemoData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addProduction = () => {
    const newProduction: ProductionData = {
      id: `prod_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      date: new Date().toISOString().split('T')[0],
      machine: '',
      mould: '',
      samples: 1,
      notes: ''
    };
    
    setFormData(prev => ({
      ...prev,
      productions: [...prev.productions, newProduction]
    }));
  };

  const updateProduction = (id: string, field: keyof ProductionData, value: any) => {
    setFormData(prev => ({
      ...prev,
      productions: prev.productions.map(prod =>
        prod.id === id ? { ...prod, [field]: value } : prod
      )
    }));
  };

  const removeProduction = (id: string) => {
    setFormData(prev => ({
      ...prev,
      productions: prev.productions.filter(prod => prod.id !== id)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title.trim()) {
      toast({ title: "Error", description: "Memo title is required", variant: "destructive" });
      return;
    }
    
    if (!formData.categoryId) {
      toast({ title: "Error", description: "Product category is required", variant: "destructive" });
      return;
    }
    
    if (!formData.productId) {
      toast({ title: "Error", description: "Product selection is required", variant: "destructive" });
      return;
    }
    
    if (!formData.officerId) {
      toast({ title: "Error", description: "Lab officer is required", variant: "destructive" });
      return;
    }
    
    if (!formData.labSiteId) {
      toast({ title: "Error", description: "Lab site is required", variant: "destructive" });
      return;
    }

    if (formData.productions.length === 0) {
      toast({ title: "Error", description: "At least one production entry is required", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit(formData);
      toast({ title: "Success", description: "Memo created successfully" });
    } catch (error) {
      console.error('Failed to submit memo:', error);
      toast({ title: "Error", description: "Failed to create memo", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingData) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading reference data...</span>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Memo Details */}
      <Card>
        <CardHeader>
          <CardTitle>Memo Details</CardTitle>
          <CardDescription>Basic information about the test memo</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Memo Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="Enter memo title"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="testDate">Test Date</Label>
              <Input
                id="testDate"
                type="date"
                value={formData.testDate}
                onChange={(e) => handleInputChange('testDate', e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Enter memo description"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Product Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Product Selection</CardTitle>
          <CardDescription>Select product category and specific product for testing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Product Category</Label>
              <Select value={formData.categoryId} onValueChange={(value) => handleInputChange('categoryId', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.category_id} value={category.category_id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="product">Product</Label>
              <Select 
                value={formData.productId} 
                onValueChange={(value) => handleInputChange('productId', value)}
                disabled={!formData.categoryId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select product" />
                </SelectTrigger>
                <SelectContent>
                  {filteredProducts.map((product) => (
                    <SelectItem key={product.product_id} value={product.product_id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {selectedProduct && (
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium mb-2">Selected Product Details</h4>
              <div className="flex gap-2 flex-wrap">
                <Badge variant="outline">Category: {categories.find(c => c.category_id === selectedProduct.category_id)?.name}</Badge>
                <Badge variant="outline">Test Module: {selectedProduct.test_module}</Badge>
                {selectedProduct.grade_id && <Badge variant="outline">Grade: {selectedProduct.grade_id}</Badge>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Assignment */}
      <Card>
        <CardHeader>
          <CardTitle>Test Assignment</CardTitle>
          <CardDescription>Assign lab officer and testing location</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="officer">Lab Officer</Label>
              <Select value={formData.officerId} onValueChange={(value) => handleInputChange('officerId', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select officer" />
                </SelectTrigger>
                <SelectContent>
                  {officers.map((officer) => (
                    <SelectItem key={officer.officer_id} value={officer.officer_id}>
                      {officer.name} - {officer.role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="labSite">Lab Site</Label>
              <Select value={formData.labSiteId} onValueChange={(value) => handleInputChange('labSiteId', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select lab site" />
                </SelectTrigger>
                <SelectContent>
                  {labSites.map((site) => (
                    <SelectItem key={site.plant_id} value={site.plant_id}>
                      {site.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Production Data */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Production Data
            <Button type="button" variant="outline" size="sm" onClick={addProduction}>
              <Plus className="h-4 w-4 mr-1" />
              Add Production
            </Button>
          </CardTitle>
          <CardDescription>Production details for testing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {formData.productions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No production data added yet.</p>
              <Button type="button" variant="outline" onClick={addProduction} className="mt-2">
                <Plus className="h-4 w-4 mr-1" />
                Add Production Entry
              </Button>
            </div>
          ) : (
            formData.productions.map((production, index) => (
              <div key={production.id} className="border rounded-lg p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Production #{index + 1}</h4>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeProduction(production.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={production.date}
                      onChange={(e) => updateProduction(production.id, 'date', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Machine</Label>
                    <Input
                      value={production.machine}
                      onChange={(e) => updateProduction(production.id, 'machine', e.target.value)}
                      placeholder="Machine ID/Name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Mould</Label>
                    <Input
                      value={production.mould}
                      onChange={(e) => updateProduction(production.id, 'mould', e.target.value)}
                      placeholder="Mould ID/Name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Samples</Label>
                    <Input
                      type="number"
                      min="1"
                      value={production.samples}
                      onChange={(e) => updateProduction(production.id, 'samples', parseInt(e.target.value) || 1)}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={production.notes}
                    onChange={(e) => updateProduction(production.id, 'notes', e.target.value)}
                    placeholder="Production notes..."
                    rows={2}
                  />
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting || isLoading}>
          {isSubmitting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Creating...
            </>
          ) : (
            'Create Memo'
          )}
        </Button>
      </div>
    </form>
  );
}