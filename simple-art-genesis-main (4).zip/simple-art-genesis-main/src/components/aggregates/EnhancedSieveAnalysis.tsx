import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calculator, Save, RefreshCw, TrendingUp } from 'lucide-react';
import { sieveConfigurationService, GradingLimit } from '@/services/database/sieveConfigurationService';
import { LiveSieveChart } from './LiveSieveChart';
import { useToast } from '@/hooks/use-toast';

interface EnhancedSieveAnalysisProps {
  testEntryId: string;
  onDataChange?: (data: any) => void;
  onFinenessModulusChange?: (fm: number) => void;
  initialData?: any;
  aggregateType?: string;
}

const SIEVE_DISPLAY_MAP: Record<string, { label: string; size: number }> = {
  '0_075': { label: '0.075mm', size: 0.075 },
  '0_15': { label: '0.15mm', size: 0.15 },
  '0_3': { label: '0.3mm', size: 0.3 },
  '0_6': { label: '0.6mm', size: 0.6 },
  '1_18': { label: '1.18mm', size: 1.18 },
  '2_36': { label: '2.36mm', size: 2.36 },
  '5': { label: '5mm', size: 5 },
  '10': { label: '10mm', size: 10 },
  '14': { label: '14mm', size: 14 },
  '16': { label: '16mm', size: 16 },
  '20': { label: '20mm', size: 20 },
  '31_5': { label: '31.5mm', size: 31.5 },
  '37_5': { label: '37.5mm', size: 37.5 },
  '45': { label: '45mm', size: 45 },
  '50': { label: '50mm', size: 50 },
  '63': { label: '63mm', size: 63 }
};

export function EnhancedSieveAnalysis({
  testEntryId,
  onDataChange,
  onFinenessModulusChange,
  initialData = {},
  aggregateType: initialAggregateType = ''
}: EnhancedSieveAnalysisProps) {
  const [selectedAggregateType, setSelectedAggregateType] = useState<string>(initialAggregateType);
  const [availableAggregateTypes, setAvailableAggregateTypes] = useState<string[]>([]);
  const [availableSieves, setAvailableSieves] = useState<string[]>([]);
  const [totalSampleMass, setTotalSampleMass] = useState<number>(1000);
  const [sieveData, setSieveData] = useState<Record<string, number>>({});
  const [gradingLimits, setGradingLimits] = useState<Record<string, { min?: number; max?: number; target?: number }>>({});
  const [fineness_modulus, setFinenessModulus] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Initialize data and load configurations
  useEffect(() => {
    initializeData();
  }, []);

  useEffect(() => {
    if (selectedAggregateType) {
      loadSieveConfiguration(selectedAggregateType);
      loadGradingLimits(selectedAggregateType);
    }
  }, [selectedAggregateType]);

  useEffect(() => {
    calculatePercentages();
  }, [sieveData, totalSampleMass]);

  useEffect(() => {
    // Initialize with existing data
    if (initialData && Object.keys(initialData).length > 0) {
      setSieveData(initialData);
    }
  }, [initialData]);

  const initializeData = async () => {
    setLoading(true);
    try {
      await sieveConfigurationService.initializeTables();
      const types = await sieveConfigurationService.getAggregateTypes();
      setAvailableAggregateTypes(types);
      
      if (initialAggregateType) {
        setSelectedAggregateType(initialAggregateType);
      } else if (types.length > 0) {
        setSelectedAggregateType(types[0]);
      }
    } catch (error) {
      console.error('Error initializing data:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to load sieve configurations.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadSieveConfiguration = async (aggregateType: string) => {
    try {
      const config = await sieveConfigurationService.getSieveConfigurationsByType(aggregateType);
      if (config) {
        setAvailableSieves(config.sieve_sizes);
      } else {
        // Fallback to default sieves
        setAvailableSieves(['0_075', '0_15', '0_3', '0_6', '1_18', '2_36', '5', '10', '14', '20']);
      }
    } catch (error) {
      console.error('Error loading sieve configuration:', error);
      setAvailableSieves(['0_075', '0_15', '0_3', '0_6', '1_18', '2_36', '5', '10', '14', '20']);
    }
  };

  const loadGradingLimits = async (aggregateType: string) => {
    try {
      const limits = await sieveConfigurationService.getGradingLimits(aggregateType, 'BS 882');
      const limitsMap: Record<string, { min?: number; max?: number; target?: number }> = {};
      
      limits.forEach(limit => {
        limitsMap[limit.sieve_size] = {
          min: limit.min_limit,
          max: limit.max_limit,
          target: limit.target_value
        };
      });
      
      setGradingLimits(limitsMap);
    } catch (error) {
      console.error('Error loading grading limits:', error);
      setGradingLimits({});
    }
  };

  const updateSieveMass = (sieveSize: string, cumulativeRetained: number) => {
    setSieveData(prev => ({
      ...prev,
      [sieveSize]: cumulativeRetained
    }));
  };

  const calculatePercentages = () => {
    if (totalSampleMass <= 0) return;

    const percentageData: Record<string, number> = {};
    
    availableSieves.forEach(sieveKey => {
      const cumulativeRetained = sieveData[sieveKey] || 0;
      const percentPassing = ((totalSampleMass - cumulativeRetained) / totalSampleMass) * 100;
      percentageData[sieveKey] = Math.max(0, Math.min(100, percentPassing));
    });

    // Calculate fineness modulus for sand
    if (selectedAggregateType?.toLowerCase().includes('sand') || selectedAggregateType?.toLowerCase().includes('fine')) {
      calculateFinenessModulus(percentageData);
    }

    // Trigger data change callback
    onDataChange?.(sieveData);
  };

  const calculateFinenessModulus = (percentageData: Record<string, number>) => {
    try {
      const targetSizes = ['0_15', '0_3', '0_6', '1_18', '2_36'];
      let sumRetained = 0;
      
      targetSizes.forEach(size => {
        const percentPassing = percentageData[size] || 0;
        const percentRetained = 100 - percentPassing;
        sumRetained += percentRetained;
      });

      const fm = sumRetained / 100;
      setFinenessModulus(fm);
      onFinenessModulusChange?.(fm);
    } catch (error) {
      console.error('Error calculating fineness modulus:', error);
    }
  };

  const handleSave = () => {
    onDataChange?.(sieveData);
    toast({
      title: "Success",
      description: "Sieve analysis data saved successfully."
    });
  };

  const getPercentageData = () => {
    const percentages: Record<string, number> = {};
    availableSieves.forEach(sieveKey => {
      const cumulativeRetained = sieveData[sieveKey] || 0;
      const percentPassing = ((totalSampleMass - cumulativeRetained) / totalSampleMass) * 100;
      percentages[sieveKey] = Math.max(0, Math.min(100, percentPassing));
    });
    return percentages;
  };

  const getSieveStatus = (sieveKey: string, percentPassing: number) => {
    const limit = gradingLimits[sieveKey];
    if (!limit) return 'default';
    
    if (limit.min !== undefined && percentPassing < limit.min) return 'destructive';
    if (limit.max !== undefined && percentPassing > limit.max) return 'destructive';
    return 'success';
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin mr-2" />
            Loading sieve configurations...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header and Aggregate Type Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Enhanced Sieve Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Aggregate Type</Label>
              <Select value={selectedAggregateType} onValueChange={setSelectedAggregateType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select aggregate type" />
                </SelectTrigger>
                <SelectContent>
                  {availableAggregateTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="total_sample_mass">Total Sample Mass (g)</Label>
              <Input
                id="total_sample_mass"
                type="number"
                step="0.1"
                value={totalSampleMass}
                onChange={(e) => setTotalSampleMass(parseFloat(e.target.value) || 1000)}
                placeholder="Enter total sample mass"
              />
            </div>
            {fineness_modulus > 0 && (
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Fineness Modulus</Label>
                <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                  <span className="text-xl font-bold">{fineness_modulus.toFixed(2)}</span>
                  <Badge variant={fineness_modulus < 2.3 ? 'default' : fineness_modulus < 3.1 ? 'secondary' : 'destructive'}>
                    {fineness_modulus < 2.3 ? 'Fine' : fineness_modulus < 3.1 ? 'Medium' : 'Coarse'}
                  </Badge>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Main Content: Sieve Inputs + Live Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Compact Sieve Input Grid */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Sieve Data Entry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {availableSieves.map((sieveKey) => {
                const sieveInfo = SIEVE_DISPLAY_MAP[sieveKey];
                if (!sieveInfo) return null;
                
                const cumulativeRetained = sieveData[sieveKey] || 0;
                const percentPassing = ((totalSampleMass - cumulativeRetained) / totalSampleMass) * 100;
                const limitStatus = getSieveStatus(sieveKey, percentPassing);
                const limit = gradingLimits[sieveKey];
                
                return (
                  <div key={sieveKey} className="space-y-1">
                    <Label className="text-xs font-medium">{sieveInfo.label}</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={cumulativeRetained || ''}
                      onChange={(e) => updateSieveMass(sieveKey, parseFloat(e.target.value) || 0)}
                      placeholder="Mass (g)"
                      className={`text-sm ${limitStatus === 'destructive' ? 'border-destructive' : limitStatus === 'success' ? 'border-success' : ''}`}
                    />
                    <div className="flex items-center justify-between text-xs">
                      <span className={`font-medium ${limitStatus === 'destructive' ? 'text-destructive' : limitStatus === 'success' ? 'text-success' : 'text-muted-foreground'}`}>
                        {percentPassing > 0 ? `${percentPassing.toFixed(1)}%` : '--'}
                      </span>
                      {limit && (
                        <span className="text-muted-foreground">
                          {limit.min !== undefined && limit.max !== undefined 
                            ? `${limit.min}-${limit.max}%`
                            : limit.target !== undefined 
                            ? `T:${limit.target}%`
                            : ''
                          }
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="flex gap-2 mt-4">
              <Button onClick={calculatePercentages} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Recalculate
              </Button>
              <Button onClick={handleSave} size="sm" className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Analysis
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Live Sieve Chart */}
        <LiveSieveChart
          sieveData={getPercentageData()}
          aggregateType={selectedAggregateType}
          gradingLimits={gradingLimits}
        />
      </div>
    </div>
  );
}