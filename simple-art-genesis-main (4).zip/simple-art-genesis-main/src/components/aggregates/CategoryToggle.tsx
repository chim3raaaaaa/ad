import React from 'react';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Card } from '@/components/ui/card';

export interface AggregateCategory {
  id: string;
  name: string;
  code: string;
  sieveSizes: string[];
}

export const AGGREGATE_CATEGORIES: AggregateCategory[] = [
  {
    id: 'fine-01-02',
    name: 'Fine Aggregates (01-02)',
    code: '01-02',
    sieveSizes: ['5mm', '2.36mm', '1.18mm', '600um', '300um', '150um', '075um']
  },
  {
    id: 'coarse',
    name: 'Coarse Aggregates',
    code: 'CA',
    sieveSizes: ['20mm', '14mm', '10mm', '5mm', '2.36mm']
  },
  {
    id: 'all-in',
    name: 'All-in Aggregates',
    code: 'AIA',
    sieveSizes: ['20mm', '14mm', '10mm', '5mm', '2.36mm', '1.18mm', '600um', '300um', '150um', '075um']
  }
];

interface CategoryToggleProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function CategoryToggle({ selectedCategory, onCategoryChange }: CategoryToggleProps) {
  return (
    <Card className="p-4 mb-6">
      <div className="space-y-3">
        <h3 className="text-sm font-medium text-muted-foreground">Aggregate Category</h3>
        <ToggleGroup
          type="single"
          value={selectedCategory}
          onValueChange={(value) => value && onCategoryChange(value)}
          className="grid grid-cols-3 gap-2"
        >
          {AGGREGATE_CATEGORIES.map((category) => (
            <ToggleGroupItem
              key={category.id}
              value={category.id}
              className="flex flex-col items-center justify-center p-3 h-auto data-[state=on]:bg-primary data-[state=on]:text-primary-foreground"
            >
              <span className="text-xs font-semibold">{category.code}</span>
              <span className="text-[10px] text-center leading-tight mt-1">
                {category.name}
              </span>
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
      </div>
    </Card>
  );
}