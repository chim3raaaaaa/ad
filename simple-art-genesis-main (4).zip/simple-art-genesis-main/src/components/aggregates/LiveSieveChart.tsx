import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { TrendingUp } from 'lucide-react';

interface LiveSieveChartProps {
  sieveData: Record<string, number>;
  aggregateType: string;
  gradingLimits?: Record<string, { min?: number; max?: number; target?: number }>;
}

const SIEVE_DISPLAY_MAP: Record<string, { label: string; size: number }> = {
  '0_075': { label: '0.075mm', size: 0.075 },
  '0_15': { label: '0.15mm', size: 0.15 },
  '0_3': { label: '0.3mm', size: 0.3 },
  '0_6': { label: '0.6mm', size: 0.6 },
  '1_18': { label: '1.18mm', size: 1.18 },
  '2_36': { label: '2.36mm', size: 2.36 },
  '5': { label: '5mm', size: 5 },
  '10': { label: '10mm', size: 10 },
  '14': { label: '14mm', size: 14 },
  '16': { label: '16mm', size: 16 },
  '20': { label: '20mm', size: 20 },
  '31_5': { label: '31.5mm', size: 31.5 },
  '37_5': { label: '37.5mm', size: 37.5 },
  '45': { label: '45mm', size: 45 },
  '50': { label: '50mm', size: 50 },
  '63': { label: '63mm', size: 63 }
};

export function LiveSieveChart({ sieveData, aggregateType, gradingLimits }: LiveSieveChartProps) {
  const chartData = useMemo(() => {
    const data = Object.entries(sieveData)
      .filter(([key, value]) => value > 0 && SIEVE_DISPLAY_MAP[key])
      .map(([key, value]) => ({
        sieve: key,
        label: SIEVE_DISPLAY_MAP[key].label,
        size: SIEVE_DISPLAY_MAP[key].size,
        actual: value,
        min: gradingLimits?.[key]?.min,
        max: gradingLimits?.[key]?.max,
        target: gradingLimits?.[key]?.target
      }))
      .sort((a, b) => a.size - b.size);

    return data;
  }, [sieveData, gradingLimits]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium">{data.label}</p>
          <p className="text-primary">
            Actual: <span className="font-semibold">{data.actual}%</span>
          </p>
          {data.target && (
            <p className="text-accent">
              Target: <span className="font-semibold">{data.target}%</span>
            </p>
          )}
          {data.min !== undefined && data.max !== undefined && (
            <p className="text-muted-foreground text-sm">
              Range: {data.min}% - {data.max}%
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Live Grading Chart
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            Enter sieve data to see the live chart
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Live Grading Chart - {aggregateType}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 60
              }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="label" 
                stroke="hsl(var(--foreground))"
                angle={-45}
                textAnchor="end"
                height={60}
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--foreground))"
                label={{ value: 'Percentage Passing (%)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              
              {/* Min/Max limit lines if available */}
              {chartData.some(d => d.min !== undefined) && (
                <Line
                  type="monotone"
                  dataKey="min"
                  stroke="hsl(var(--destructive))"
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  dot={false}
                  name="Min Limit"
                />
              )}
              
              {chartData.some(d => d.max !== undefined) && (
                <Line
                  type="monotone"
                  dataKey="max"
                  stroke="hsl(var(--destructive))"
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  dot={false}
                  name="Max Limit"
                />
              )}
              
              {/* Target line if available */}
              {chartData.some(d => d.target !== undefined) && (
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke="hsl(var(--accent))"
                  strokeDasharray="10 5"
                  strokeWidth={2}
                  dot={false}
                  name="Target"
                />
              )}
              
              {/* Actual values line */}
              <Line
                type="monotone"
                dataKey="actual"
                stroke="hsl(var(--primary))"
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                name="Actual Values"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        {/* Chart legend and info */}
        <div className="mt-4 text-sm text-muted-foreground">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-primary"></div>
              <span>Actual Values</span>
            </div>
            {chartData.some(d => d.target !== undefined) && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-0.5 bg-accent" style={{ borderTop: '2px dashed' }}></div>
                <span>Target</span>
              </div>
            )}
            {chartData.some(d => d.min !== undefined || d.max !== undefined) && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-0.5 bg-destructive" style={{ borderTop: '2px dashed' }}></div>
                <span>Limits</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}