import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { AGGREGATE_CATEGORIES } from './CategoryToggle';

interface GradingData {
  [key: string]: number;
}

interface GradingLimits {
  sieve: string;
  min: number;
  max: number;
}

// Standard grading limits for different aggregate types
const GRADING_LIMITS: Record<string, GradingLimits[]> = {
  'fine-01-02': [
    { sieve: '5mm', min: 95, max: 100 },
    { sieve: '2.36mm', min: 80, max: 100 },
    { sieve: '1.18mm', min: 50, max: 85 },
    { sieve: '600um', min: 25, max: 60 },
    { sieve: '300um', min: 10, max: 30 },
    { sieve: '150um', min: 2, max: 10 },
    { sieve: '075um', min: 0, max: 5 }
  ],
  'coarse': [
    { sieve: '20mm', min: 95, max: 100 },
    { sieve: '14mm', min: 90, max: 100 },
    { sieve: '10mm', min: 20, max: 55 },
    { sieve: '5mm', min: 0, max: 10 },
    { sieve: '2.36mm', min: 0, max: 5 }
  ],
  'all-in': [
    { sieve: '20mm', min: 95, max: 100 },
    { sieve: '14mm', min: 85, max: 100 },
    { sieve: '10mm', min: 65, max: 85 },
    { sieve: '5mm', min: 45, max: 75 },
    { sieve: '2.36mm', min: 30, max: 55 },
    { sieve: '1.18mm', min: 20, max: 40 },
    { sieve: '600um', min: 10, max: 25 },
    { sieve: '300um', min: 5, max: 15 },
    { sieve: '150um', min: 2, max: 8 },
    { sieve: '075um', min: 0, max: 5 }
  ]
};

interface GradingConformityCheckerProps {
  category: string;
  gradingData: GradingData;
  onConformityChange?: (isConform: boolean) => void;
}

export function GradingConformityChecker({ 
  category, 
  gradingData, 
  onConformityChange 
}: GradingConformityCheckerProps) {
  const conformityResults = useMemo(() => {
    const limits = GRADING_LIMITS[category] || [];
    const results = limits.map(limit => {
      const value = gradingData[`sieve_${limit.sieve.replace('mm', 'mm').replace('um', 'um')}`] || 0;
      const isConform = value >= limit.min && value <= limit.max;
      return {
        sieve: limit.sieve,
        value,
        min: limit.min,
        max: limit.max,
        isConform,
        status: isConform ? 'pass' : 'fail'
      };
    });

    const overallConformity = results.every(r => r.isConform);
    
    // Notify parent component
    if (onConformityChange) {
      onConformityChange(overallConformity);
    }

    return {
      results,
      overallConformity,
      passCount: results.filter(r => r.isConform).length,
      totalCount: results.length
    };
  }, [category, gradingData, onConformityChange]);

  const finenessModulus = useMemo(() => {
    if (category !== 'fine-01-02') return null;
    
    // Calculate fineness modulus for fine aggregates
    const cumulativeRetained = {
      '2.36mm': 100 - (gradingData.sieve_2_36mm || 0),
      '1.18mm': 100 - (gradingData.sieve_1_18mm || 0),
      '600um': 100 - (gradingData.sieve_600um || 0),
      '300um': 100 - (gradingData.sieve_300um || 0),
      '150um': 100 - (gradingData.sieve_150um || 0)
    };

    const sum = Object.values(cumulativeRetained).reduce((a, b) => a + b, 0);
    return (sum / 100).toFixed(2);
  }, [category, gradingData]);

  const selectedCategory = AGGREGATE_CATEGORIES.find(cat => cat.id === category);

  if (!selectedCategory) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Select Aggregate Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Please select an aggregate category to view grading conformity.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Grading Conformity - {selectedCategory.name}</span>
          <Badge
            variant={conformityResults.overallConformity ? "default" : "destructive"}
            className="flex items-center gap-1"
          >
            {conformityResults.overallConformity ? (
              <CheckCircle className="h-3 w-3" />
            ) : (
              <XCircle className="h-3 w-3" />
            )}
            {conformityResults.overallConformity ? "PASS" : "FAIL"}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-muted-foreground">
          {conformityResults.passCount} of {conformityResults.totalCount} sieves within limits
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Sieve Size</TableHead>
              <TableHead>% Passing</TableHead>
              <TableHead>Limits</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {conformityResults.results.map((result) => (
              <TableRow key={result.sieve}>
                <TableCell className="font-medium">{result.sieve}</TableCell>
                <TableCell>{result.value.toFixed(1)}%</TableCell>
                <TableCell>{result.min} - {result.max}%</TableCell>
                <TableCell>
                  <Badge
                    variant={result.isConform ? "outline" : "destructive"}
                    className="flex items-center gap-1 w-fit"
                  >
                    {result.isConform ? (
                      <CheckCircle className="h-3 w-3" />
                    ) : (
                      <XCircle className="h-3 w-3" />
                    )}
                    {result.status.toUpperCase()}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {finenessModulus && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="flex justify-between items-center">
              <span className="font-medium">Fineness Modulus:</span>
              <span className="text-lg font-bold">{finenessModulus}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}