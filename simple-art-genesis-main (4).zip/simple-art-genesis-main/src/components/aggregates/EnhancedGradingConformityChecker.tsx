import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, AlertTriangle, Calculator, Download, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface GradingLimit {
  id: number;
  material_type: string;
  standard: string;
  sieve_0_075?: number;
  sieve_0_15?: number;
  sieve_0_3?: number;
  sieve_0_6?: number;
  sieve_1_18?: number;
  sieve_2_36?: number;
  sieve_5?: number;
  sieve_10?: number;
  sieve_14?: number;
  sieve_16?: number;
  sieve_20?: number;
  sieve_31_5?: number;
  sieve_37_5?: number;
  sieve_45?: number;
  sieve_50?: number;
  sieve_63?: number;
}

interface GradingResult {
  sieve: string;
  actualValue: number;
  limitValue: number;
  status: 'pass' | 'fail' | 'warning';
  deviation: number;
}

interface ConformityCheckResult {
  overall_status: 'pass' | 'fail' | 'warning';
  conformity_percentage: number;
  material_type: string;
  standard: string;
  results: GradingResult[];
  checked_at: string;
}

const SIEVE_SIZES = [
  { id: '0_075', label: '0.075mm' },
  { id: '0_15', label: '0.15mm' },
  { id: '0_3', label: '0.3mm' },
  { id: '0_6', label: '0.6mm' },
  { id: '1_18', label: '1.18mm' },
  { id: '2_36', label: '2.36mm' },
  { id: '5', label: '5mm' },
  { id: '10', label: '10mm' },
  { id: '14', label: '14mm' },
  { id: '16', label: '16mm' },
  { id: '20', label: '20mm' },
  { id: '31_5', label: '31.5mm' },
  { id: '37_5', label: '37.5mm' },
  { id: '45', label: '45mm' },
  { id: '50', label: '50mm' },
  { id: '63', label: '63mm' }
];

export function EnhancedGradingConformityChecker() {
  const [materialTypes, setMaterialTypes] = useState<string[]>([]);
  const [standards, setStandards] = useState<string[]>([]);
  const [selectedMaterialType, setSelectedMaterialType] = useState<string>('');
  const [selectedStandard, setSelectedStandard] = useState<string>('');
  const [gradingLimits, setGradingLimits] = useState<GradingLimit | null>(null);
  const [actualValues, setActualValues] = useState<Record<string, number>>({});
  const [conformityResult, setConformityResult] = useState<ConformityCheckResult | null>(null);
  const [loading, setLoading] = useState(false);
  
  const { toast } = useToast();

  useEffect(() => {
    loadMaterialTypesAndStandards();
    initializeConformityTable();
  }, []);

  useEffect(() => {
    if (selectedMaterialType && selectedStandard) {
      loadGradingLimits();
    }
  }, [selectedMaterialType, selectedStandard]);

  const initializeConformityTable = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS grading_conformity_checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_type TEXT NOT NULL,
            standard TEXT NOT NULL,
            overall_status TEXT NOT NULL,
            conformity_percentage REAL NOT NULL,
            results TEXT NOT NULL,
            checked_at TEXT NOT NULL
          )
        `);
      }
    } catch (error) {
      console.error('Error creating conformity checks table:', error);
    }
  };

  const loadMaterialTypesAndStandards = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        // Load unique material types
        const materialResult = await window.electronAPI.dbQuery(
          'SELECT DISTINCT material_type FROM grading_limits ORDER BY material_type'
        );
        setMaterialTypes(materialResult.map((row: any) => row.material_type));

        // Load unique standards
        const standardResult = await window.electronAPI.dbQuery(
          'SELECT DISTINCT standard FROM grading_limits ORDER BY standard'
        );
        setStandards(standardResult.map((row: any) => row.standard));
      }
    } catch (error) {
      console.error('Error loading material types and standards:', error);
      toast({
        title: "Error",
        description: "Failed to load material types and standards",
        variant: "destructive"
      });
    }
  };

  const loadGradingLimits = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM grading_limits WHERE material_type = ? AND standard = ?',
          [selectedMaterialType, selectedStandard]
        );
        
        if (result.length > 0) {
          setGradingLimits(result[0]);
        } else {
          setGradingLimits(null);
          toast({
            title: "No Limits Found",
            description: `No grading limits found for ${selectedMaterialType} - ${selectedStandard}`,
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      console.error('Error loading grading limits:', error);
      toast({
        title: "Error",
        description: "Failed to load grading limits",
        variant: "destructive"
      });
    }
  };

  const handleActualValueChange = (sieve: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    setActualValues(prev => ({
      ...prev,
      [sieve]: numValue
    }));
  };

  const checkConformity = async () => {
    if (!gradingLimits || !selectedMaterialType || !selectedStandard) {
      toast({
        title: "Error",
        description: "Please select material type and standard first",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const results: GradingResult[] = [];
      let passCount = 0;
      let failCount = 0;
      let warningCount = 0;

      for (const sieve of SIEVE_SIZES) {
        const actualValue = actualValues[sieve.id];
        const limitValue = gradingLimits[`sieve_${sieve.id}` as keyof GradingLimit] as number;

        if (actualValue !== undefined && limitValue !== undefined) {
          let status: 'pass' | 'fail' | 'warning' = 'pass';
          const deviation = actualValue - limitValue;

          // Determine pass/fail based on standard type
          const isMinStandard = selectedStandard.includes('Min');
          const isMaxStandard = selectedStandard.includes('Max');

          if (isMinStandard && actualValue < limitValue) {
            status = Math.abs(deviation) > 5 ? 'fail' : 'warning'; // 5% tolerance for warnings
          } else if (isMaxStandard && actualValue > limitValue) {
            status = Math.abs(deviation) > 5 ? 'fail' : 'warning';
          }

          if (status === 'pass') passCount++;
          else if (status === 'fail') failCount++;
          else warningCount++;

          results.push({
            sieve: sieve.label,
            actualValue,
            limitValue,
            status,
            deviation
          });
        }
      }

      const overallStatus = failCount > 0 ? 'fail' : warningCount > 0 ? 'warning' : 'pass';
      const conformityPercentage = results.length > 0 ? (passCount / results.length) * 100 : 0;

      const checkResult: ConformityCheckResult = {
        overall_status: overallStatus,
        conformity_percentage: Math.round(conformityPercentage),
        material_type: selectedMaterialType,
        standard: selectedStandard,
        results,
        checked_at: new Date().toISOString()
      };

      setConformityResult(checkResult);

      // Save conformity check to database
      await saveConformityCheck(checkResult);

      toast({
        title: "Conformity Check Complete",
        description: `Overall Status: ${overallStatus.toUpperCase()} - ${conformityPercentage.toFixed(1)}% conformity`,
        variant: overallStatus === 'pass' ? 'default' : 'destructive'
      });

    } catch (error) {
      console.error('Error checking conformity:', error);
      toast({
        title: "Error",
        description: "Failed to check conformity",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveConformityCheck = async (result: ConformityCheckResult) => {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(`
          INSERT INTO grading_conformity_checks 
          (material_type, standard, overall_status, conformity_percentage, results, checked_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [
          result.material_type,
          result.standard,
          result.overall_status,
          result.conformity_percentage,
          JSON.stringify(result.results),
          result.checked_at
        ]);
      }
    } catch (error) {
      console.error('Error saving conformity check:', error);
    }
  };

  const exportResults = () => {
    if (!conformityResult) return;

    const csvContent = [
      ['Sieve Size', 'Actual Value (%)', 'Limit Value (%)', 'Status', 'Deviation (%)'],
      ...conformityResult.results.map(r => [
        r.sieve,
        r.actualValue.toString(),
        r.limitValue.toString(),
        r.status,
        r.deviation.toFixed(2)
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `grading_conformity_${conformityResult.material_type}_${conformityResult.standard}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusIcon = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: 'pass' | 'fail' | 'warning') => {
    const variants = {
      pass: 'default',
      fail: 'destructive',
      warning: 'secondary'
    } as const;

    return (
      <Badge variant={variants[status]} className="flex items-center gap-1">
        {getStatusIcon(status)}
        {status.toUpperCase()}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Enhanced Grading Conformity Checker
          </CardTitle>
          <CardDescription>
            Check aggregate grading results against database-stored limits with full integration
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Material Type and Standard Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Material Type</Label>
              <Select value={selectedMaterialType} onValueChange={setSelectedMaterialType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select material type" />
                </SelectTrigger>
                <SelectContent>
                  {materialTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Standard</Label>
              <Select value={selectedStandard} onValueChange={setSelectedStandard}>
                <SelectTrigger>
                  <SelectValue placeholder="Select standard" />
                </SelectTrigger>
                <SelectContent>
                  {standards.map((standard) => (
                    <SelectItem key={standard} value={standard}>
                      {standard}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 flex items-end">
              <Button onClick={loadGradingLimits} variant="outline" className="w-full">
                <RefreshCw className="mr-2 h-4 w-4" />
                Load Limits
              </Button>
            </div>
          </div>

          {gradingLimits && (
            <>
              {/* Grading Input Table */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Enter Actual Grading Results</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sieve Size</TableHead>
                      <TableHead>Limit Value (%)</TableHead>
                      <TableHead>Actual Value (%)</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {SIEVE_SIZES.map((sieve) => {
                      const limitValue = gradingLimits[`sieve_${sieve.id}` as keyof GradingLimit] as number;
                      const actualValue = actualValues[sieve.id];
                      
                      if (limitValue === undefined || limitValue === null) return null;

                      let status: 'pass' | 'fail' | 'warning' | null = null;
                      if (actualValue !== undefined) {
                        const isMinStandard = selectedStandard.includes('Min');
                        const isMaxStandard = selectedStandard.includes('Max');
                        
                        if (isMinStandard && actualValue < limitValue) {
                          status = Math.abs(actualValue - limitValue) > 5 ? 'fail' : 'warning';
                        } else if (isMaxStandard && actualValue > limitValue) {
                          status = Math.abs(actualValue - limitValue) > 5 ? 'fail' : 'warning';
                        } else {
                          status = 'pass';
                        }
                      }

                      return (
                        <TableRow key={sieve.id}>
                          <TableCell className="font-medium">{sieve.label}</TableCell>
                          <TableCell>{limitValue}</TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              step="0.1"
                              value={actualValue || ''}
                              onChange={(e) => handleActualValueChange(sieve.id, e.target.value)}
                              className="w-24"
                            />
                          </TableCell>
                          <TableCell>
                            {status && getStatusBadge(status)}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>

              <div className="flex gap-2">
                <Button onClick={checkConformity} disabled={loading}>
                  <Calculator className="mr-2 h-4 w-4" />
                  {loading ? 'Checking...' : 'Check Conformity'}
                </Button>
              </div>
            </>
          )}

          {/* Conformity Results */}
          {conformityResult && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Conformity Results</h3>
                <div className="flex gap-2">
                  {getStatusBadge(conformityResult.overall_status)}
                  <Badge variant="outline">
                    {conformityResult.conformity_percentage}% Conformity
                  </Badge>
                </div>
              </div>

              {conformityResult.overall_status !== 'pass' && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Non-conformity detected. Please review the failed/warning sieve sizes below.
                  </AlertDescription>
                </Alert>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sieve Size</TableHead>
                    <TableHead>Actual (%)</TableHead>
                    <TableHead>Limit (%)</TableHead>
                    <TableHead>Deviation</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {conformityResult.results.map((result, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{result.sieve}</TableCell>
                      <TableCell>{result.actualValue}</TableCell>
                      <TableCell>{result.limitValue}</TableCell>
                      <TableCell className={result.deviation !== 0 ? 
                        (result.deviation > 0 ? 'text-red-600' : 'text-blue-600') : ''}>
                        {result.deviation > 0 ? '+' : ''}{result.deviation.toFixed(2)}%
                      </TableCell>
                      <TableCell>{getStatusBadge(result.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="flex gap-2">
                <Button variant="outline" onClick={exportResults}>
                  <Download className="mr-2 h-4 w-4" />
                  Export Results
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}