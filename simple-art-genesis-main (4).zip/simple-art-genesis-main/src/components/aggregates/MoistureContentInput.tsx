import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator, Save, RefreshCw } from 'lucide-react';
import { CalculationFormulaService } from '@/services/database/calculationFormulaService';
import { AggregateCalculationService, MoistureContentData } from '@/services/database/aggregateCalculationService';
import { useToast } from '@/hooks/use-toast';

interface MoistureContentInputProps {
  testEntryId: string;
  onDataChange?: (data: MoistureContentData) => void;
  initialData?: MoistureContentData;
}

export function MoistureContentInput({ testEntryId, onDataChange, initialData }: MoistureContentInputProps) {
  const [ph, setPh] = useState<string>(initialData?.ph?.toString() || '');
  const [ps, setPs] = useState<string>(initialData?.ps?.toString() || '');
  const [wPercent, setWPercent] = useState<number | null>(initialData?.w_percent || null);
  const [calculating, setCalculating] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    calculateMoistureContent();
  }, [ph, ps]);

  const calculateMoistureContent = async () => {
    if (!ph || !ps || isNaN(Number(ph)) || isNaN(Number(ps))) {
      setWPercent(null);
      return;
    }

    const phNum = Number(ph);
    const psNum = Number(ps);

    if (psNum <= 0) {
      setWPercent(null);
      return;
    }

    setCalculating(true);
    try {
      const result = await CalculationFormulaService.evaluateFormula('Moisture Content', {
        Ph: phNum,
        Ps: psNum
      });
      setWPercent(result);
    } catch (error) {
      console.error('Error calculating moisture content:', error);
      toast({
        title: "Calculation Error",
        description: "Failed to calculate moisture content. Please check your inputs.",
        variant: "destructive"
      });
      setWPercent(null);
    } finally {
      setCalculating(false);
    }
  };

  const handleSave = async () => {
    if (!ph || !ps || wPercent === null) {
      toast({
        title: "Invalid Data",
        description: "Please enter valid Ph and Ps values before saving.",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const data = await AggregateCalculationService.saveMoistureContent({
        test_entry_id: testEntryId,
        ph: Number(ph),
        ps: Number(ps),
        w_percent: wPercent
      });

      onDataChange?.(data);
      toast({
        title: "Success",
        description: "Moisture content data saved successfully."
      });
    } catch (error) {
      console.error('Error saving moisture content:', error);
      toast({
        title: "Save Error",
        description: "Failed to save moisture content data.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const getResultBadgeVariant = () => {
    if (wPercent === null) return 'secondary';
    if (wPercent < 1) return 'default';
    if (wPercent < 5) return 'secondary';
    return 'destructive';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Moisture Content Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="ph">Ph (Wet Mass) (g)</Label>
            <Input
              id="ph"
              type="number"
              step="0.01"
              value={ph}
              onChange={(e) => setPh(e.target.value)}
              placeholder="Enter wet mass"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ps">Ps (Dry Mass) (g)</Label>
            <Input
              id="ps"
              type="number"
              step="0.01"
              value={ps}
              onChange={(e) => setPs(e.target.value)}
              placeholder="Enter dry mass"
            />
          </div>
        </div>

        <div className="p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm text-muted-foreground">Moisture Content (w%)</Label>
              <div className="flex items-center gap-2 mt-1">
                {calculating ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <span className="text-2xl font-bold">
                    {wPercent !== null ? `${wPercent.toFixed(2)}%` : '--'}
                  </span>
                )}
                {wPercent !== null && (
                  <Badge variant={getResultBadgeVariant()}>
                    {wPercent < 1 ? 'Very Low' : wPercent < 5 ? 'Normal' : 'High'}
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Formula: (Ph - Ps) / Ps × 100
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={handleSave} 
            disabled={saving || wPercent === null}
            className="flex-1"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Result'}
          </Button>
          <Button 
            variant="outline" 
            onClick={calculateMoistureContent}
            disabled={calculating}
          >
            <RefreshCw className={`h-4 w-4 ${calculating ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}