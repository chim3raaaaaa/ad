import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Beaker, Save, RefreshCw } from 'lucide-react';
import { CalculationFormulaService } from '@/services/database/calculationFormulaService';
import { AggregateCalculationService, MethyleneBlueData } from '@/services/database/aggregateCalculationService';
import { useToast } from '@/hooks/use-toast';

interface MethyleneBlueInputProps {
  testEntryId: string;
  onDataChange?: (data: MethyleneBlueData) => void;
  initialData?: MethyleneBlueData;
}

export function MethyleneBlueInput({ testEntryId, onDataChange, initialData }: MethyleneBlueInputProps) {
  const [dryMass, setDryMass] = useState<string>(initialData?.dry_mass?.toString() || '');
  const [volumeAbsorbed, setVolumeAbsorbed] = useState<string>(initialData?.volume_absorbed?.toString() || '');
  const [dyeVolume, setDyeVolume] = useState<string>(initialData?.dye_volume?.toString() || '');
  const [normality, setNormality] = useState<string>(initialData?.normality?.toString() || '0.01');
  const [mbValue, setMbValue] = useState<number | null>(initialData?.mb_value || null);
  const [calculating, setCalculating] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    calculateMBValue();
  }, [dryMass, volumeAbsorbed, dyeVolume, normality]);

  const calculateMBValue = async () => {
    if (!dryMass || !dyeVolume || !normality || 
        isNaN(Number(dryMass)) || isNaN(Number(dyeVolume)) || isNaN(Number(normality))) {
      setMbValue(null);
      return;
    }

    const dryMassNum = Number(dryMass);
    const dyeVolumeNum = Number(dyeVolume);
    const normalityNum = Number(normality);

    if (dryMassNum <= 0) {
      setMbValue(null);
      return;
    }

    setCalculating(true);
    try {
      const result = await CalculationFormulaService.evaluateFormula('Methylene Blue Value', {
        V1: dyeVolumeNum,
        normality: normalityNum,
        sample_mass: dryMassNum
      });
      setMbValue(result);
    } catch (error) {
      console.error('Error calculating methylene blue value:', error);
      toast({
        title: "Calculation Error",
        description: "Failed to calculate methylene blue value. Please check your inputs.",
        variant: "destructive"
      });
      setMbValue(null);
    } finally {
      setCalculating(false);
    }
  };

  const handleSave = async () => {
    if (!dryMass || !dyeVolume || !normality || mbValue === null) {
      toast({
        title: "Invalid Data",
        description: "Please enter all required values before saving.",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const data = await AggregateCalculationService.saveMethyleneBlue({
        test_entry_id: testEntryId,
        dry_mass: Number(dryMass),
        volume_absorbed: Number(volumeAbsorbed) || 0,
        dye_volume: Number(dyeVolume),
        normality: Number(normality)
      });

      onDataChange?.(data);
      toast({
        title: "Success",
        description: "Methylene blue data saved successfully."
      });
    } catch (error) {
      console.error('Error saving methylene blue:', error);
      toast({
        title: "Save Error",
        description: "Failed to save methylene blue data.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const getMBValueBadgeVariant = () => {
    if (mbValue === null) return 'secondary';
    if (mbValue < 1.5) return 'default';
    if (mbValue < 5) return 'secondary';
    return 'destructive';
  };

  const getMBValueCategory = () => {
    if (mbValue === null) return 'Unknown';
    if (mbValue < 1.5) return 'Low Clay Content';
    if (mbValue < 5) return 'Moderate Clay Content';
    return 'High Clay Content';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Beaker className="h-5 w-5" />
          Methylene Blue Value Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="dry-mass">Dry Sample Mass (g)</Label>
            <Input
              id="dry-mass"
              type="number"
              step="0.01"
              value={dryMass}
              onChange={(e) => setDryMass(e.target.value)}
              placeholder="Enter dry sample mass"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="volume-absorbed">Volume Absorbed (ml)</Label>
            <Input
              id="volume-absorbed"
              type="number"
              step="0.1"
              value={volumeAbsorbed}
              onChange={(e) => setVolumeAbsorbed(e.target.value)}
              placeholder="Enter volume absorbed (optional)"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="dye-volume">Dye Volume V1 (ml)</Label>
            <Input
              id="dye-volume"
              type="number"
              step="0.1"
              value={dyeVolume}
              onChange={(e) => setDyeVolume(e.target.value)}
              placeholder="Enter dye volume"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="normality">Normality</Label>
            <Input
              id="normality"
              type="number"
              step="0.001"
              value={normality}
              onChange={(e) => setNormality(e.target.value)}
              placeholder="Enter normality"
            />
          </div>
        </div>

        <div className="p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm text-muted-foreground">Methylene Blue Value (g/kg)</Label>
              <div className="flex items-center gap-2 mt-1">
                {calculating ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <span className="text-2xl font-bold">
                    {mbValue !== null ? mbValue.toFixed(2) : '--'}
                  </span>
                )}
                {mbValue !== null && (
                  <Badge variant={getMBValueBadgeVariant()}>
                    {getMBValueCategory()}
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-xs text-muted-foreground text-right">
              <div>Formula: (V1 × N × 3.1) / M</div>
              <div className="mt-1 text-xs">V1: Dye volume, N: Normality, M: Sample mass</div>
            </div>
          </div>
        </div>

        {mbValue !== null && (
          <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <Label className="text-sm font-medium">Interpretation</Label>
            <p className="text-sm text-muted-foreground mt-1">
              {mbValue < 1.5 && "The sample shows low clay content, indicating good quality aggregate."}
              {mbValue >= 1.5 && mbValue < 5 && "The sample shows moderate clay content. Monitor for potential issues."}
              {mbValue >= 5 && "The sample shows high clay content. Consider treatment or rejection."}
            </p>
          </div>
        )}

        <div className="flex gap-2">
          <Button 
            onClick={handleSave} 
            disabled={saving || mbValue === null}
            className="flex-1"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Result'}
          </Button>
          <Button 
            variant="outline" 
            onClick={calculateMBValue}
            disabled={calculating}
          >
            <RefreshCw className={`h-4 w-4 ${calculating ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}