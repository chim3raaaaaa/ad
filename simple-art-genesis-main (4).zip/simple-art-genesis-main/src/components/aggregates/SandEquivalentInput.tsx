import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { TestTube, Save, Plus, Trash2 } from 'lucide-react';
import { CalculationFormulaService } from '@/services/database/calculationFormulaService';
import { AggregateCalculationService, SandEquivalentData } from '@/services/database/aggregateCalculationService';
import { useToast } from '@/hooks/use-toast';

interface SandEquivalentInputProps {
  testEntryId: string;
  onDataChange?: (data: SandEquivalentData) => void;
  initialData?: SandEquivalentData;
}

export function SandEquivalentInput({ testEntryId, onDataChange, initialData }: SandEquivalentInputProps) {
  const [s1Readings, setS1Readings] = useState<number[]>(initialData?.s1_readings || [0]);
  const [s2Readings, setS2Readings] = useState<number[]>(initialData?.s2_readings || [0]);
  const [results, setResults] = useState({
    esv: initialData?.esv || 0,
    esp: initialData?.esp || 0,
    meanEsv: initialData?.mean_esv || 0,
    meanEsp: initialData?.mean_esp || 0
  });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    calculateResults();
  }, [s1Readings, s2Readings]);

  const calculateResults = async () => {
    if (s1Readings.length === 0 || s2Readings.length === 0) return;

    try {
      const sumS1 = s1Readings.reduce((a, b) => a + b, 0);
      const sumS2 = s2Readings.reduce((a, b) => a + b, 0);

      if (sumS2 === 0) return;

      const esv = await CalculationFormulaService.evaluateFormula('Sand Equivalent ESV', {
        sum_s1: sumS1,
        sum_s2: sumS2
      });

      // For this example, ESP uses the same calculation
      // In practice, this might be a different measurement
      const esp = esv;
      const meanEsv = s1Readings.length > 0 ? esv : 0;
      const meanEsp = s2Readings.length > 0 ? esp : 0;

      setResults({ esv, esp, meanEsv, meanEsp });
    } catch (error) {
      console.error('Error calculating sand equivalent:', error);
      toast({
        title: "Calculation Error",
        description: "Failed to calculate sand equivalent values.",
        variant: "destructive"
      });
    }
  };

  const addS1Reading = () => {
    setS1Readings([...s1Readings, 0]);
  };

  const addS2Reading = () => {
    setS2Readings([...s2Readings, 0]);
  };

  const removeS1Reading = (index: number) => {
    if (s1Readings.length > 1) {
      setS1Readings(s1Readings.filter((_, i) => i !== index));
    }
  };

  const removeS2Reading = (index: number) => {
    if (s2Readings.length > 1) {
      setS2Readings(s2Readings.filter((_, i) => i !== index));
    }
  };

  const updateS1Reading = (index: number, value: string) => {
    const newReadings = [...s1Readings];
    newReadings[index] = Number(value) || 0;
    setS1Readings(newReadings);
  };

  const updateS2Reading = (index: number, value: string) => {
    const newReadings = [...s2Readings];
    newReadings[index] = Number(value) || 0;
    setS2Readings(newReadings);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const data = await AggregateCalculationService.saveSandEquivalent({
        test_entry_id: testEntryId,
        s1_readings: s1Readings,
        s2_readings: s2Readings
      });

      onDataChange?.(data);
      toast({
        title: "Success",
        description: "Sand equivalent data saved successfully."
      });
    } catch (error) {
      console.error('Error saving sand equivalent:', error);
      toast({
        title: "Save Error",
        description: "Failed to save sand equivalent data.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const getESVBadgeVariant = (value: number) => {
    if (value >= 50) return 'default';
    if (value >= 30) return 'secondary';
    return 'destructive';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TestTube className="h-5 w-5" />
          Sand Equivalent Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* S1 Readings */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">S1 Readings (mm)</Label>
            <Button
              variant="outline"
              size="sm"
              onClick={addS1Reading}
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Reading
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {s1Readings.map((reading, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  type="number"
                  step="0.1"
                  value={reading}
                  onChange={(e) => updateS1Reading(index, e.target.value)}
                  placeholder={`S1 Reading ${index + 1}`}
                />
                {s1Readings.length > 1 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => removeS1Reading(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* S2 Readings */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">S2 Readings (mm)</Label>
            <Button
              variant="outline"
              size="sm"
              onClick={addS2Reading}
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Reading
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {s2Readings.map((reading, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  type="number"
                  step="0.1"
                  value={reading}
                  onChange={(e) => updateS2Reading(index, e.target.value)}
                  placeholder={`S2 Reading ${index + 1}`}
                />
                {s2Readings.length > 1 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => removeS2Reading(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Results */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-muted rounded-lg">
            <Label className="text-xs text-muted-foreground">ESV Value</Label>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xl font-bold">{results.esv.toFixed(1)}</span>
              <Badge variant={getESVBadgeVariant(results.esv)}>
                {results.esv >= 50 ? 'Good' : results.esv >= 30 ? 'Fair' : 'Poor'}
              </Badge>
            </div>
          </div>
          <div className="p-3 bg-muted rounded-lg">
            <Label className="text-xs text-muted-foreground">ESP Value</Label>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xl font-bold">{results.esp.toFixed(1)}</span>
              <Badge variant={getESVBadgeVariant(results.esp)}>
                {results.esp >= 50 ? 'Good' : results.esp >= 30 ? 'Fair' : 'Poor'}
              </Badge>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-muted rounded-lg">
            <Label className="text-xs text-muted-foreground">Mean ESV</Label>
            <div className="text-lg font-semibold">{results.meanEsv.toFixed(1)}</div>
          </div>
          <div className="p-3 bg-muted rounded-lg">
            <Label className="text-xs text-muted-foreground">Mean ESP</Label>
            <div className="text-lg font-semibold">{results.meanEsp.toFixed(1)}</div>
          </div>
        </div>

        <Button 
          onClick={handleSave} 
          disabled={saving}
          className="w-full"
        >
          <Save className="h-4 w-4 mr-2" />
          {saving ? 'Saving...' : 'Save Sand Equivalent Results'}
        </Button>
      </CardContent>
    </Card>
  );
}