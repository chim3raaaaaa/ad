import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { 
  Plus, 
  Minus, 
  Calculator, 
  AlertTriangle,
  CheckCircle,
  Info,
  Save,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRealTimeValidation } from '@/hooks/useRealTimeValidation';
import { ValidationPanel } from '@/components/validation/ValidationPanel';
import { ValidatedInput } from '@/components/validation/ValidatedInput';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';

interface TestEntryFormProps {
  category: string;
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: Record<string, any>;
}

interface FieldConfig {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'textarea';
  required?: boolean;
  options?: string[];
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number;
}

export function TestEntryForm({ 
  category, 
  onSubmit, 
  onCancel, 
  initialData = {} 
}: TestEntryFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>(initialData);
  const [fieldConfigs, setFieldConfigs] = useState<FieldConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Real-time validation
  const { 
    validationResults, 
    isValidating, 
    validateData, 
    hasErrors, 
    isValid 
  } = useRealTimeValidation();

  // Load field configuration based on category
  useEffect(() => {
    loadFieldConfiguration();
  }, [category]);

  // Auto-validate when form data changes
  useEffect(() => {
    if (Object.keys(formData).length > 0) {
      const debounceTimer = setTimeout(() => {
        validateData(formData, category);
      }, 500);

      return () => clearTimeout(debounceTimer);
    }
  }, [formData, category, validateData]);

  const loadFieldConfiguration = async () => {
    setLoading(true);
    try {
      // Get available fields for this category from validation service
      const fields = await EnhancedValidationService.getFieldsForCategory(category);
      
      // Define field configurations based on category
      const configs = getFieldConfigsForCategory(category, fields);
      setFieldConfigs(configs);
    } catch (error) {
      console.error('Error loading field configuration:', error);
      // Fallback to default configuration
      setFieldConfigs(getDefaultFieldConfigs(category));
    } finally {
      setLoading(false);
    }
  };

  const getFieldConfigsForCategory = (cat: string, availableFields: string[]): FieldConfig[] => {
    const baseConfigs: Record<string, FieldConfig[]> = {
      'Aggregates': [
        { name: 'FM', label: 'Fineness Modulus (FM)', type: 'number', required: true, step: 0.1, min: 0, max: 10 },
        { name: 'moisture', label: 'Moisture Content (%)', type: 'number', required: true, step: 0.1, min: 0, max: 20 },
        { name: 'sieve_425', label: 'Sieve 0.425mm (%)', type: 'number', required: true, step: 0.1, min: 0, max: 100 },
        { name: 'sieve_212', label: 'Sieve 0.212mm (%)', type: 'number', required: true, step: 0.1, min: 0, max: 100 },
        { name: 'sieve_150', label: 'Sieve 0.150mm (%)', type: 'number', required: true, step: 0.1, min: 0, max: 100 },
        { name: 'sieve_075', label: 'Sieve 0.075mm (%)', type: 'number', required: true, step: 0.1, min: 0, max: 100 }
      ],
      'Cubes': [
        { name: 'compressive_strength', label: 'Compressive Strength (MPa)', type: 'number', required: true, step: 0.1, min: 0, max: 100 },
        { name: 'density', label: 'Density (kg/m³)', type: 'number', required: true, step: 1, min: 1000, max: 3000 },
        { name: 'test_age', label: 'Test Age (days)', type: 'number', required: true, step: 1, min: 1, max: 365 },
        { name: 'specimen_size', label: 'Specimen Size (mm)', type: 'select', required: true, options: ['100', '150', '200'] }
      ],
      'Pavers': [
        { name: 'compressive_strength', label: 'Compressive Strength (MPa)', type: 'number', required: true, step: 0.1, min: 0, max: 100 },
        { name: 'water_absorption', label: 'Water Absorption (%)', type: 'number', required: true, step: 0.1, min: 0, max: 20 },
        { name: 'thickness', label: 'Thickness (mm)', type: 'number', required: true, step: 1, min: 10, max: 200 },
        { name: 'length', label: 'Length (mm)', type: 'number', required: true, step: 1, min: 50, max: 500 },
        { name: 'width', label: 'Width (mm)', type: 'number', required: true, step: 1, min: 50, max: 500 }
      ]
    };

    // Merge with available fields from validation service
    const baseFields = baseConfigs[cat] || [];
    
    // Add any additional fields found in validation rules that aren't in base config
    availableFields.forEach(field => {
      if (!baseFields.find(f => f.name === field)) {
        baseFields.push({
          name: field,
          label: field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          type: 'number',
          required: false
        });
      }
    });

    return baseFields;
  };

  const getDefaultFieldConfigs = (cat: string): FieldConfig[] => {
    return getFieldConfigsForCategory(cat, []);
  };

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const handleSubmit = async () => {
    // Final validation
    const results = await validateData(formData, category);
    const criticalErrors = results.filter(r => !r.passed && r.severity === 'critical');

    if (criticalErrors.length > 0) {
      toast({
        title: 'Validation Errors',
        description: 'Please fix the validation errors before submitting',
        variant: 'destructive'
      });
      return;
    }

    // Log validation results
    try {
      for (const result of results) {
        await EnhancedValidationService.logValidationResult(
          'test_' + Date.now(),
          result.rule_id,
          result.passed,
          result.message
        );
      }
    } catch (error) {
      console.error('Error logging validation results:', error);
    }

    onSubmit(formData);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 animate-spin mr-2" />
        Loading form configuration...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Form Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            {category} Test Entry
          </h3>
          <p className="text-sm text-muted-foreground">
            Enter test data with real-time validation
          </p>
        </div>
        <Badge variant="outline">
          {fieldConfigs.filter(f => f.required).length} required fields
        </Badge>
      </div>

      <Separator />

      {/* Validation Summary */}
      {validationResults.length > 0 && (
        <Alert className={hasErrors ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'}>
          <div className="flex items-center gap-2">
            {hasErrors ? (
              <AlertTriangle className="w-4 h-4 text-red-500" />
            ) : (
              <CheckCircle className="w-4 h-4 text-green-500" />
            )}
            <AlertDescription>
              {hasErrors 
                ? `${validationResults.filter(r => !r.passed).length} validation error(s) found`
                : 'All validations passed'
              }
            </AlertDescription>
          </div>
        </Alert>
      )}

      {/* Form Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          {fieldConfigs.slice(0, Math.ceil(fieldConfigs.length / 2)).map((field) => (
            <div key={field.name}>
              {field.type === 'select' ? (
                <div className="space-y-2">
                  <Label>{field.label} {field.required && <span className="text-red-500">*</span>}</Label>
                  <Select 
                    value={formData[field.name] || ''} 
                    onValueChange={(value) => handleFieldChange(field.name, value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options?.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : field.type === 'textarea' ? (
                <div className="space-y-2">
                  <Label>{field.label} {field.required && <span className="text-red-500">*</span>}</Label>
                  <Textarea
                    value={formData[field.name] || ''}
                    onChange={(e) => handleFieldChange(field.name, e.target.value)}
                    placeholder={field.placeholder}
                    rows={3}
                  />
                </div>
              ) : (
                <ValidatedInput
                  label={field.label}
                  type={field.type}
                  required={field.required}
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, field.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)}
                  placeholder={field.placeholder}
                  min={field.min}
                  max={field.max}
                  step={field.step}
                />
              )}
            </div>
          ))}
        </div>

        <div className="space-y-4">
          {fieldConfigs.slice(Math.ceil(fieldConfigs.length / 2)).map((field) => (
            <div key={field.name}>
              {field.type === 'select' ? (
                <div className="space-y-2">
                  <Label>{field.label} {field.required && <span className="text-red-500">*</span>}</Label>
                  <Select 
                    value={formData[field.name] || ''} 
                    onValueChange={(value) => handleFieldChange(field.name, value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options?.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : field.type === 'textarea' ? (
                <div className="space-y-2">
                  <Label>{field.label} {field.required && <span className="text-red-500">*</span>}</Label>
                  <Textarea
                    value={formData[field.name] || ''}
                    onChange={(e) => handleFieldChange(field.name, e.target.value)}
                    placeholder={field.placeholder}
                    rows={3}
                  />
                </div>
              ) : (
                <ValidatedInput
                  label={field.label}
                  type={field.type}
                  required={field.required}
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, field.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)}
                  placeholder={field.placeholder}
                  min={field.min}
                  max={field.max}
                  step={field.step}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Validation Panel */}
      {validationResults.length > 0 && (
        <ValidationPanel
          results={validationResults}
          isValidating={isValidating}
          onRevalidate={() => validateData(formData, category)}
          showDetails={true}
        />
      )}

      <Separator />

      {/* Form Actions */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          {isValidating && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <RefreshCw className="w-4 h-4 animate-spin" />
              Validating...
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={hasErrors || isValidating}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {hasErrors ? 'Fix Errors First' : 'Save Test Results'}
          </Button>
        </div>
      </div>
    </div>
  );
}