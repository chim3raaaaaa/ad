import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Calculator, 
  Plus, 
  Minus, 
  Equal, 
  MoreHorizontal,
  Zap,
  Type,
  Hash
} from 'lucide-react';

interface FormulaBuilderProps {
  value: string;
  onChange: (formula: string) => void;
  availableFields?: string[];
}

export function FormulaBuilder({ value, onChange, availableFields = [] }: FormulaBuilderProps) {
  const [cursorPosition, setCursorPosition] = useState(0);

  const insertAtCursor = (text: string) => {
    const before = value.substring(0, cursorPosition);
    const after = value.substring(cursorPosition);
    const newValue = before + text + after;
    onChange(newValue);
    setTimeout(() => {
      setCursorPosition(cursorPosition + text.length);
    }, 0);
  };

  const operators = [
    { label: '>=', symbol: '>=' },
    { label: '<=', symbol: '<=' },
    { label: '>', symbol: '>' },
    { label: '<', symbol: '<' },
    { label: '==', symbol: '==' },
    { label: '!=', symbol: '!=' },
    { label: 'AND', symbol: ' AND ' },
    { label: 'OR', symbol: ' OR ' },
    { label: 'NOT', symbol: 'NOT ' }
  ];

  const functions = [
    { 
      label: 'IF', 
      template: 'IF(condition, true_value, false_value)',
      description: 'Conditional logic'
    },
    { 
      label: 'RANGE', 
      template: 'value >= min_val AND value <= max_val',
      description: 'Range check'
    },
    { 
      label: 'BETWEEN', 
      template: 'value >= 20 AND value <= 60',
      description: 'Between two values'
    }
  ];

  const mathOperators = [
    { label: '+', symbol: ' + ' },
    { label: '-', symbol: ' - ' },
    { label: '*', symbol: ' * ' },
    { label: '/', symbol: ' / ' },
    { label: '%', symbol: ' % ' },
    { label: '(', symbol: '(' },
    { label: ')', symbol: ')' }
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-4 h-4" />
            Formula Builder
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Textarea
              value={value}
              onChange={(e) => {
                onChange(e.target.value);
                setCursorPosition(e.target.selectionStart || 0);
              }}
              onSelect={(e) => {
                setCursorPosition((e.target as HTMLTextAreaElement).selectionStart || 0);
              }}
              placeholder="Build your formula using the tools below..."
              rows={4}
              className="font-mono text-sm"
            />
          </div>

          {/* Available Fields */}
          {availableFields.length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                <Type className="w-4 h-4" />
                Available Fields
              </h4>
              <div className="flex flex-wrap gap-2">
                {availableFields.map((field) => (
                  <Badge
                    key={field}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                    onClick={() => insertAtCursor(field)}
                  >
                    {field}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Comparison Operators */}
          <div>
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <Equal className="w-4 h-4" />
              Comparison & Logic
            </h4>
            <div className="flex flex-wrap gap-2">
              {operators.map((op) => (
                <Button
                  key={op.label}
                  variant="outline"
                  size="sm"
                  onClick={() => insertAtCursor(op.symbol)}
                >
                  {op.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Math Operators */}
          <div>
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <Hash className="w-4 h-4" />
              Math Operators
            </h4>
            <div className="flex flex-wrap gap-2">
              {mathOperators.map((op) => (
                <Button
                  key={op.label}
                  variant="outline"
                  size="sm"
                  onClick={() => insertAtCursor(op.symbol)}
                >
                  {op.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Functions */}
          <div>
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Functions & Templates
            </h4>
            <div className="space-y-2">
              {functions.map((func) => (
                <div
                  key={func.label}
                  className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-muted/50"
                  onClick={() => insertAtCursor(func.template)}
                >
                  <div>
                    <div className="font-medium text-sm">{func.label}</div>
                    <div className="text-xs text-muted-foreground">{func.description}</div>
                  </div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    {func.template}
                  </code>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onChange('')}
            >
              Clear
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => insertAtCursor('value >= 0 AND value <= 100')}
            >
              Range Template
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => insertAtCursor('IF(value > 50, true, false)')}
            >
              IF Template
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}