import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Filter, 
  Search,
  AlertTriangle,
  CheckCircle,
  Play
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { EnhancedValidationService } from '@/services/validation/enhancedValidationService';
import type { ValidationRule } from '@/services/validation/validationTypes';
import { ValidationRuleEditor } from './ValidationRuleEditor';

interface ValidationRuleTableProps {
  onEditRule?: (rule: ValidationRule) => void;
  onTestRule?: (rule: ValidationRule) => void;
}

export function ValidationRuleTable({ onEditRule, onTestRule }: ValidationRuleTableProps) {
  const [rules, setRules] = useState<ValidationRule[]>([]);
  const [filteredRules, setFilteredRules] = useState<ValidationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categories, setCategories] = useState<string[]>([]);
  const [showEditor, setShowEditor] = useState(false);
  const [editingRule, setEditingRule] = useState<ValidationRule | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [ruleToDelete, setRuleToDelete] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadRules();
    loadCategories();
  }, []);

  useEffect(() => {
    filterRules();
  }, [rules, searchTerm, categoryFilter, severityFilter, statusFilter]);

  const loadRules = async () => {
    try {
      // Use direct database query since the service might not have getAllRules method
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(`
          SELECT * FROM validation_rules ORDER BY category, field
        `, []);
        
        const formattedRules = result.map((row: any) => ({
          id: row.id?.toString() || '',
          category: row.category || '',
          field: row.field_name || row.field || '',
          formula: row.formula || row.rule_value || '',
          failure_reason: row.failure_reason || row.error_message || '',
          severity: row.severity || 'critical',
          active: Boolean(row.active),
          created_at: row.created_at || new Date().toISOString(),
          created_by: row.created_by || 'System'
        }));
        
        setRules(formattedRules);
      }
    } catch (error) {
      console.error('Error loading rules:', error);
      toast({
        title: 'Error',
        description: 'Failed to load validation rules',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(`
          SELECT DISTINCT category FROM validation_rules WHERE category IS NOT NULL AND category != ''
          UNION
          SELECT DISTINCT category FROM memos WHERE category IS NOT NULL AND category != ''
        `, []);
        
        const validCategories = result
          .map((row: any) => row.category)
          .filter((cat: string) => cat && cat.trim() !== '');
        
        setCategories(['Aggregates', 'Cubes', 'Pavers', 'Kerbs', 'Flagstones', 'General', ...validCategories]);
      } else {
        setCategories(['Aggregates', 'Cubes', 'Pavers', 'Kerbs', 'Flagstones', 'General']);
      }
    } catch (error) {
      console.error('Error loading categories:', error);
      setCategories(['Aggregates', 'Cubes', 'Pavers', 'Kerbs', 'Flagstones', 'General']);
    }
  };

  const filterRules = () => {
    let filtered = rules;

    if (searchTerm) {
      filtered = filtered.filter(rule =>
        rule.field.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.formula.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.failure_reason.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(rule => rule.category === categoryFilter);
    }

    if (severityFilter !== 'all') {
      filtered = filtered.filter(rule => rule.severity === severityFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(rule => 
        statusFilter === 'active' ? rule.active : !rule.active
      );
    }

    setFilteredRules(filtered);
  };

  const handleToggleRule = async (id: string, active: boolean) => {
    try {
      if (window.electronAPI?.dbRun) {
        await window.electronAPI.dbRun(
          'UPDATE validation_rules SET active = ?, updated_at = ? WHERE id = ?',
          [active ? 1 : 0, new Date().toISOString(), id]
        );
        await loadRules();
        toast({
          title: 'Success',
          description: `Rule ${active ? 'activated' : 'deactivated'} successfully`
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update rule status',
        variant: 'destructive'
      });
    }
  };

  const handleEditRule = (rule: ValidationRule) => {
    setEditingRule(rule);
    setShowEditor(true);
    onEditRule?.(rule);
  };

  const handleDeleteRule = async () => {
    if (!ruleToDelete) return;

    try {
      if (window.electronAPI?.dbRun) {
        await window.electronAPI.dbRun('DELETE FROM validation_rules WHERE id = ?', [ruleToDelete]);
        await loadRules();
        toast({
          title: 'Success',
          description: 'Rule deleted successfully'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete rule',
        variant: 'destructive'
      });
    } finally {
      setShowDeleteDialog(false);
      setRuleToDelete(null);
    }
  };

  const handleSaveRule = async (ruleData: any) => {
    try {
      if (editingRule) {
        await EnhancedValidationService.updateRule(editingRule.id, ruleData);
        toast({
          title: 'Success',
          description: 'Rule updated successfully'
        });
      } else {
        await EnhancedValidationService.addRule(ruleData);
        toast({
          title: 'Success',
          description: 'Rule created successfully'
        });
      }
      await loadRules();
      setShowEditor(false);
      setEditingRule(null);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save rule',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Validation Rules</h3>
          <p className="text-sm text-muted-foreground">
            Manage data validation rules with Excel-style formulas
          </p>
        </div>
        <Button onClick={() => setShowEditor(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Rule
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search rules..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Severities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active Only</SelectItem>
                <SelectItem value="inactive">Inactive Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Rules Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category</TableHead>
                <TableHead>Field</TableHead>
                <TableHead>Formula</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRules.map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell>
                    <Badge variant="outline">{rule.category}</Badge>
                  </TableCell>
                  <TableCell className="font-medium">{rule.field}</TableCell>
                  <TableCell>
                    <code className="text-xs bg-muted px-2 py-1 rounded">
                      {rule.formula.length > 50 
                        ? `${rule.formula.substring(0, 50)}...` 
                        : rule.formula
                      }
                    </code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={rule.severity === 'critical' ? 'destructive' : 'secondary'}>
                      {rule.severity === 'critical' ? (
                        <AlertTriangle className="w-3 h-3 mr-1" />
                      ) : (
                        <CheckCircle className="w-3 h-3 mr-1" />
                      )}
                      {rule.severity}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={rule.active}
                        onCheckedChange={(checked) => handleToggleRule(rule.id, checked)}
                      />
                      <span className="text-sm text-muted-foreground">
                        {rule.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {new Date(rule.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onTestRule?.(rule)}
                        title="Test Rule"
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditRule(rule)}
                        title="Edit Rule"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setRuleToDelete(rule.id);
                          setShowDeleteDialog(true);
                        }}
                        title="Delete Rule"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredRules.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No rules found matching your criteria</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rule Editor Dialog */}
      <ValidationRuleEditor
        open={showEditor}
        onOpenChange={setShowEditor}
        rule={editingRule}
        onSave={handleSaveRule}
        categories={categories}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Validation Rule</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this validation rule? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteRule}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}