import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ValidatedInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  validationStatus?: 'valid' | 'warning' | 'error' | 'none';
  validationMessages?: string[];
  required?: boolean;
}

export function ValidatedInput({ 
  label, 
  validationStatus = 'none',
  validationMessages = [],
  required = false,
  className,
  ...props 
}: ValidatedInputProps) {
  const getStatusColor = () => {
    switch (validationStatus) {
      case 'valid': return 'border-green-500 focus:border-green-500';
      case 'warning': return 'border-yellow-500 focus:border-yellow-500';
      case 'error': return 'border-red-500 focus:border-red-500';
      default: return '';
    }
  };

  const getStatusIcon = () => {
    switch (validationStatus) {
      case 'valid': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-2">
      {label && (
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">
            {label} {required && <span className="text-red-500">*</span>}
          </Label>
          {validationStatus !== 'none' && (
            <div className="flex items-center gap-1">
              {getStatusIcon()}
              <Badge 
                variant={validationStatus === 'error' ? 'destructive' : validationStatus === 'warning' ? 'secondary' : 'default'}
                className="text-xs"
              >
                {validationStatus}
              </Badge>
            </div>
          )}
        </div>
      )}
      
      <div className="relative">
        <Input
          className={cn(
            'pr-10',
            getStatusColor(),
            className
          )}
          {...props}
        />
        {validationStatus !== 'none' && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            {getStatusIcon()}
          </div>
        )}
      </div>

      {validationMessages.length > 0 && (
        <div className="space-y-1">
          {validationMessages.map((message, index) => (
            <Alert 
              key={index} 
              className={cn(
                'py-2',
                validationStatus === 'error' ? 'border-red-200 bg-red-50' :
                validationStatus === 'warning' ? 'border-yellow-200 bg-yellow-50' :
                'border-green-200 bg-green-50'
              )}
            >
              <AlertDescription className="text-sm">
                {message}
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}
    </div>
  );
}