import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Eye, 
  EyeOff,
  RefreshCw
} from 'lucide-react';
import type { ValidationResult } from '@/services/validation/validationTypes';

interface ValidationPanelProps {
  results: ValidationResult[];
  isValidating?: boolean;
  onRevalidate?: () => void;
  showDetails?: boolean;
  onToggleDetails?: () => void;
  className?: string;
}

export function ValidationPanel({ 
  results, 
  isValidating = false,
  onRevalidate,
  showDetails = true,
  onToggleDetails,
  className = ''
}: ValidationPanelProps) {
  const errors = results.filter(r => !r.passed && r.severity === 'critical');
  const warnings = results.filter(r => !r.passed && r.severity === 'warning');
  const passed = results.filter(r => r.passed);

  const getStatusIcon = (result: ValidationResult) => {
    if (result.passed) {
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    }
    return result.severity === 'critical' 
      ? <XCircle className="w-4 h-4 text-red-500" />
      : <AlertTriangle className="w-4 h-4 text-yellow-500" />;
  };

  const getStatusBadge = (result: ValidationResult) => {
    if (result.passed) {
      return <Badge className="bg-green-500">PASS</Badge>;
    }
    return result.severity === 'critical' 
      ? <Badge variant="destructive">FAIL</Badge>
      : <Badge variant="secondary">WARNING</Badge>;
  };

  if (results.length === 0 && !isValidating) {
    return null;
  }

  return (
    <Card className={`border-l-4 ${errors.length > 0 ? 'border-l-red-500' : warnings.length > 0 ? 'border-l-yellow-500' : 'border-l-green-500'} ${className}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            {isValidating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Validating...
              </>
            ) : (
              <>
                {errors.length > 0 ? (
                  <XCircle className="w-4 h-4 text-red-500" />
                ) : warnings.length > 0 ? (
                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
                Validation Results
              </>
            )}
          </CardTitle>
          <div className="flex items-center gap-2">
            {onToggleDetails && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleDetails}
              >
                {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            )}
            {onRevalidate && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onRevalidate}
                disabled={isValidating}
              >
                <RefreshCw className={`w-4 h-4 ${isValidating ? 'animate-spin' : ''}`} />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-2 bg-green-50 rounded-lg">
            <div className="text-lg font-bold text-green-600">{passed.length}</div>
            <div className="text-xs text-green-600">Passed</div>
          </div>
          <div className="text-center p-2 bg-yellow-50 rounded-lg">
            <div className="text-lg font-bold text-yellow-600">{warnings.length}</div>
            <div className="text-xs text-yellow-600">Warnings</div>
          </div>
          <div className="text-center p-2 bg-red-50 rounded-lg">
            <div className="text-lg font-bold text-red-600">{errors.length}</div>
            <div className="text-xs text-red-600">Errors</div>
          </div>
        </div>

        {/* Detailed Results */}
        {showDetails && results.length > 0 && (
          <div className="space-y-2">
            {/* Errors first */}
            {errors.map((result, index) => (
              <Alert key={`error-${index}`} className="border-red-200">
                <div className="flex items-center gap-2">
                  {getStatusIcon(result)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{result.field}</span>
                      {getStatusBadge(result)}
                    </div>
                    <AlertDescription className="mt-1 text-xs">
                      {result.message}
                      {result.actual_value !== undefined && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Current value: {JSON.stringify(result.actual_value)}
                        </div>
                      )}
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            ))}

            {/* Warnings */}
            {warnings.map((result, index) => (
              <Alert key={`warning-${index}`} className="border-yellow-200">
                <div className="flex items-center gap-2">
                  {getStatusIcon(result)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{result.field}</span>
                      {getStatusBadge(result)}
                    </div>
                    <AlertDescription className="mt-1 text-xs">
                      {result.message}
                      {result.actual_value !== undefined && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Current value: {JSON.stringify(result.actual_value)}
                        </div>
                      )}
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            ))}

            {/* Show some passed results if no errors/warnings */}
            {errors.length === 0 && warnings.length === 0 && passed.slice(0, 3).map((result, index) => (
              <Alert key={`passed-${index}`} className="border-green-200">
                <div className="flex items-center gap-2">
                  {getStatusIcon(result)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{result.field}</span>
                      {getStatusBadge(result)}
                    </div>
                    <AlertDescription className="mt-1 text-xs">
                      Validation passed
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            ))}
          </div>
        )}

        {/* Action Message */}
        {errors.length > 0 && (
          <Alert className="border-red-200 bg-red-50">
            <XCircle className="w-4 h-4 text-red-500" />
            <AlertDescription className="text-sm">
              <strong>Action Required:</strong> Please fix the critical validation errors before submitting.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}