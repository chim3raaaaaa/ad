import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Play, 
  CheckCircle, 
  AlertTriangle, 
  FileText,
  RotateCcw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { ValidationRule, ValidationResult } from '@/services/validation/validationTypes';

export function ValidationRunner() {
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [testData, setTestData] = useState('{\n  "value": 25,\n  "FM": 2.5,\n  "moisture": 3.2,\n  "compressive_strength": 30,\n  "slump": 75\n}');
  const [validationResults, setValidationResults] = useState<ValidationResult[]>([]);
  const [activeRules, setActiveRules] = useState<ValidationRule[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadCategories();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      loadRulesForCategory(selectedCategory);
    }
  }, [selectedCategory]);

  const loadCategories = async () => {
    try {
      const categoriesData = await EnhancedValidationService.getProductCategories();
      setCategories(categoriesData);
      if (categoriesData.length > 0) {
        setSelectedCategory(categoriesData[0]);
      }
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const loadRulesForCategory = async (category: string) => {
    try {
      const rules = await EnhancedValidationService.getRulesByCategory(category);
      setActiveRules(rules);
    } catch (error) {
      console.error('Error loading rules:', error);
    }
  };

  const runValidation = async () => {
    if (!selectedCategory || !testData) {
      toast({
        title: 'Error',
        description: 'Please select a category and enter test data',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const data = JSON.parse(testData);
      const results = await EnhancedValidationService.validateTestResult(data, selectedCategory);
      setValidationResults(results);
      
      toast({
        title: 'Validation Complete',
        description: `${results.length} validation results generated`
      });
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        title: 'Error',
        description: 'Failed to run validation. Check your test data format.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const resetValidation = () => {
    setValidationResults([]);
    setTestData('{\n  "value": 25,\n  "FM": 2.5,\n  "moisture": 3.2,\n  "compressive_strength": 30,\n  "slump": 75\n}');
  };

  const sampleDataTemplates = {
    'Aggregates': '{\n  "FM": 2.5,\n  "moisture": 3.2,\n  "sieve_425": 45,\n  "sieve_212": 65,\n  "sieve_150": 75,\n  "sieve_075": 85\n}',
    'Cubes': '{\n  "compressive_strength": 30,\n  "density": 2400,\n  "test_age": 28,\n  "specimen_size": 100\n}',
    'Pavers': '{\n  "compressive_strength": 35,\n  "water_absorption": 5,\n  "thickness": 60,\n  "length": 200,\n  "width": 100\n}',
    'Blocks': '{\n  "compressive_strength": 15,\n  "density": 1800,\n  "thermal_conductivity": 0.8,\n  "dimensions_check": true\n}',
    'Flagstones': '{\n  "thickness": 25,\n  "compressive_strength": 50,\n  "water_absorption": 3,\n  "surface_finish": "smooth"\n}',
    'Kerbs': '{\n  "compressive_strength": 40,\n  "water_absorption": 4,\n  "frost_resistance": true,\n  "dimensional_tolerance": 2\n}'
  };

  const getResultIcon = (passed: boolean, severity: string) => {
    if (passed) {
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    }
    return severity === 'critical' 
      ? <AlertTriangle className="w-4 h-4 text-red-500" />
      : <AlertTriangle className="w-4 h-4 text-yellow-500" />;
  };

  const getResultBadge = (passed: boolean, severity: string) => {
    if (passed) {
      return <Badge className="bg-green-500">PASS</Badge>;
    }
    return severity === 'critical' 
      ? <Badge variant="destructive">FAIL</Badge>
      : <Badge variant="secondary">WARNING</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Validation Simulator</h3>
          <p className="text-sm text-muted-foreground">
            Test validation rules with sample data to preview results
          </p>
        </div>
        <Button onClick={resetValidation} variant="outline">
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Category</label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Test Data (JSON)</label>
                <Textarea
                  value={testData}
                  onChange={(e) => setTestData(e.target.value)}
                  rows={8}
                  className="font-mono text-sm"
                  placeholder="Enter test data in JSON format"
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={runValidation} disabled={loading} className="flex-1">
                  <Play className="w-4 h-4 mr-2" />
                  {loading ? 'Running...' : 'Run Validation'}
                </Button>
                {selectedCategory && sampleDataTemplates[selectedCategory as keyof typeof sampleDataTemplates] && (
                  <Button 
                    variant="outline"
                    onClick={() => setTestData(sampleDataTemplates[selectedCategory as keyof typeof sampleDataTemplates])}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Sample
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Active Rules Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Active Rules ({activeRules.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {activeRules.length === 0 ? (
                <p className="text-muted-foreground text-sm">No active rules for this category</p>
              ) : (
                <div className="space-y-2">
                  {activeRules.map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium text-sm">{rule.field}</div>
                        <code className="text-xs text-muted-foreground">
                          {rule.formula.length > 40 ? `${rule.formula.substring(0, 40)}...` : rule.formula}
                        </code>
                      </div>
                      <Badge variant={rule.severity === 'critical' ? 'destructive' : 'secondary'}>
                        {rule.severity}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Results Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Validation Results</CardTitle>
            </CardHeader>
            <CardContent>
              {validationResults.length === 0 ? (
                <div className="text-center py-8">
                  <Play className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Run validation to see results</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Summary */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {validationResults.filter(r => r.passed).length}
                      </div>
                      <div className="text-sm text-green-600">Passed</div>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">
                        {validationResults.filter(r => !r.passed && r.severity === 'critical').length}
                      </div>
                      <div className="text-sm text-red-600">Failed</div>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600">
                        {validationResults.filter(r => !r.passed && r.severity === 'warning').length}
                      </div>
                      <div className="text-sm text-yellow-600">Warnings</div>
                    </div>
                  </div>

                  {/* Detailed Results */}
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Field</TableHead>
                        <TableHead>Result</TableHead>
                        <TableHead>Message</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {validationResults.map((result, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{result.field}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getResultIcon(result.passed, result.severity)}
                              {getResultBadge(result.passed, result.severity)}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {result.message}
                            {result.actual_value !== undefined && (
                              <div className="text-xs text-muted-foreground mt-1">
                                Value: {JSON.stringify(result.actual_value)}
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}