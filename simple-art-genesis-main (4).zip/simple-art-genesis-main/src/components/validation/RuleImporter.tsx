import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Upload, 
  Download, 
  FileText, 
  AlertTriangle, 
  CheckCircle,
  Eye,
  Save
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { ValidationRule } from '@/services/validation/validationTypes';

export function RuleImporter() {
  const [csvData, setCsvData] = useState('');
  const [previewRules, setPreviewRules] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [importing, setImporting] = useState(false);
  const [exportData, setExportData] = useState('');
  const [showExportDialog, setShowExportDialog] = useState(false);
  const { toast } = useToast();

  const sampleCsv = `category,field,formula,failure_reason,severity
Aggregates,FM,value >= 2.3 AND value <= 3.1,FM out of acceptable range,critical
Aggregates,moisture,value <= 5,Moisture content too high,warning
Aggregates,sieve_425,value >= 35 AND value <= 65,Sieve 425 out of range,critical
Cubes,compressive_strength,value >= 20 AND value <= 60,Compressive strength out of range,critical
Cubes,density,value >= 2200 AND value <= 2600,Density out of acceptable range,warning`;

  const parseCSV = (csvText: string) => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV must have at least a header and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    const requiredHeaders = ['category', 'field', 'formula', 'failure_reason'];
    
    for (const required of requiredHeaders) {
      if (!headers.includes(required)) {
        throw new Error(`Missing required column: ${required}`);
      }
    }

    const rules = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const rule: any = {};
      
      headers.forEach((header, index) => {
        rule[header] = values[index] || '';
      });

      // Validate required fields
      if (!rule.category || !rule.field || !rule.formula || !rule.failure_reason) {
        throw new Error(`Row ${i + 1}: Missing required data`);
      }

      // Set defaults
      rule.severity = rule.severity === 'warning' ? 'warning' : 'critical';
      rule.active = rule.active === 'false' ? false : true;

      rules.push(rule);
    }

    return rules;
  };

  const handlePreview = () => {
    if (!csvData.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter CSV data to preview',
        variant: 'destructive'
      });
      return;
    }

    try {
      const parsedRules = parseCSV(csvData);
      setPreviewRules(parsedRules);
      setShowPreview(true);
    } catch (error) {
      toast({
        title: 'CSV Parse Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const handleImport = async () => {
    setImporting(true);
    try {
      const importedRules = await EnhancedValidationService.importRulesFromCSV(csvData);
      toast({
        title: 'Success',
        description: `Imported ${importedRules.length} validation rules`
      });
      setCsvData('');
      setPreviewRules([]);
      setShowPreview(false);
    } catch (error) {
      toast({
        title: 'Import Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setImporting(false);
    }
  };

  const handleExport = async () => {
    try {
      const csvContent = await EnhancedValidationService.exportRulesToCSV();
      setExportData(csvContent);
      setShowExportDialog(true);
    } catch (error) {
      toast({
        title: 'Export Error',
        description: 'Failed to export validation rules',
        variant: 'destructive'
      });
    }
  };

  const downloadCSV = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: 'Success',
        description: 'CSV data copied to clipboard'
      });
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Rule Import/Export</h3>
          <p className="text-sm text-muted-foreground">
            Import validation rules from CSV or export existing rules
          </p>
        </div>
        <Button onClick={handleExport} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export Rules
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Import Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Import Rules from CSV
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">CSV Data</label>
              <Textarea
                value={csvData}
                onChange={(e) => setCsvData(e.target.value)}
                rows={10}
                className="font-mono text-sm"
                placeholder="Paste your CSV data here..."
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handlePreview} disabled={!csvData.trim()}>
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button 
                onClick={() => setCsvData(sampleCsv)}
                variant="outline"
              >
                <FileText className="w-4 h-4 mr-2" />
                Load Sample
              </Button>
            </div>

            {showPreview && (
              <Alert>
                <CheckCircle className="w-4 h-4" />
                <AlertDescription>
                  Preview successful! Found {previewRules.length} valid rules.
                  <Button 
                    onClick={handleImport} 
                    disabled={importing}
                    className="ml-2"
                    size="sm"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {importing ? 'Importing...' : 'Import Rules'}
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* CSV Format Guide */}
        <Card>
          <CardHeader>
            <CardTitle>CSV Format Guide</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                <strong>Required Columns:</strong>
                <ul className="list-disc list-inside mt-2 text-sm">
                  <li><code>category</code> - Product category (e.g., Aggregates, Cubes)</li>
                  <li><code>field</code> - Field name to validate</li>
                  <li><code>formula</code> - Excel-style validation formula</li>
                  <li><code>failure_reason</code> - Error message when validation fails</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div>
              <strong className="text-sm">Optional Columns:</strong>
              <ul className="list-disc list-inside mt-2 text-sm text-muted-foreground">
                <li><code>severity</code> - "critical" or "warning" (default: critical)</li>
                <li><code>active</code> - "true" or "false" (default: true)</li>
              </ul>
            </div>

            <div>
              <strong className="text-sm">Sample CSV:</strong>
              <pre className="text-xs bg-muted p-3 rounded-lg mt-2 overflow-x-auto">
{`category,field,formula,failure_reason,severity
Aggregates,FM,value >= 2.3 AND value <= 3.1,FM out of range,critical
Cubes,compressive_strength,value >= 20,Strength too low,critical`}
              </pre>
            </div>

            <div>
              <strong className="text-sm">Formula Examples:</strong>
              <ul className="list-disc list-inside mt-2 text-xs text-muted-foreground">
                <li><code>value {'>'}= 20 AND value {'<'}= 60</code></li>
                <li><code>IF(type == "special", value {'>'}= 30, value {'>'}= 20)</code></li>
                <li><code>moisture {'<'}= (FM * 0.5)</code></li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import Preview</DialogTitle>
            <DialogDescription>
              Review the rules before importing. {previewRules.length} rules found.
            </DialogDescription>
          </DialogHeader>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category</TableHead>
                <TableHead>Field</TableHead>
                <TableHead>Formula</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {previewRules.map((rule, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Badge variant="outline">{rule.category}</Badge>
                  </TableCell>
                  <TableCell className="font-medium">{rule.field}</TableCell>
                  <TableCell>
                    <code className="text-xs bg-muted px-2 py-1 rounded">
                      {rule.formula.length > 30 ? `${rule.formula.substring(0, 30)}...` : rule.formula}
                    </code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={rule.severity === 'critical' ? 'destructive' : 'secondary'}>
                      {rule.severity}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={rule.active ? 'default' : 'secondary'}>
                      {rule.active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreview(false)}>
              Cancel
            </Button>
            <Button onClick={handleImport} disabled={importing}>
              <Save className="w-4 h-4 mr-2" />
              {importing ? 'Importing...' : 'Import Rules'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Export Validation Rules</DialogTitle>
            <DialogDescription>
              Copy the CSV data below or download as a file
            </DialogDescription>
          </DialogHeader>

          <Textarea
            value={exportData}
            readOnly
            rows={15}
            className="font-mono text-sm"
          />

          <DialogFooter>
            <Button variant="outline" onClick={() => copyToClipboard(exportData)}>
              Copy to Clipboard
            </Button>
            <Button onClick={() => downloadCSV(exportData, 'validation_rules.csv')}>
              <Download className="w-4 h-4 mr-2" />
              Download CSV
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}