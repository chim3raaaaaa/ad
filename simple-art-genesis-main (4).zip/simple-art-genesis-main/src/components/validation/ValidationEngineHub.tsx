import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  Play, 
  Upload, 
  History,
  Code,
  AlertTriangle
} from 'lucide-react';
import { ValidationRuleTable } from './ValidationRuleTable';
import { ValidationRunner } from './ValidationRunner';
import { RuleImporter } from './RuleImporter';
import { RuleLogs } from './RuleLogs';
import { ValidationRuleEditor } from './ValidationRuleEditor';
import type { ValidationRule } from '@/services/validation/validationTypes';
import { DatabaseInitializationService } from '@/services/database/tableInitializationService';
import { EnhancedValidationService } from '@/services/validation/enhancedValidationService';

export function ValidationEngineHub() {
  const [selectedRule, setSelectedRule] = useState<ValidationRule | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [testRule, setTestRule] = useState<ValidationRule | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  const handleEditRule = (rule: ValidationRule) => {
    setSelectedRule(rule);
    setShowEditor(true);
  };

  const handleTestRule = (rule: ValidationRule) => {
    setTestRule(rule);
    // Could open test runner with pre-filled data
  };

  const handleSaveRule = () => {
    setShowEditor(false);
    setSelectedRule(null);
    // Refresh would be handled by the ValidationRuleTable component
  };

  // Initialize grading limits integration with validation system
  const initializeGradingLimitsIntegration = async () => {
    try {
      if (!window.electronAPI?.dbQuery) return;

      // Add grading validation rules for each material type and standard
      const gradingLimits = await window.electronAPI.dbQuery(
        'SELECT DISTINCT material_type, standard FROM grading_limits'
      );

      for (const limit of gradingLimits) {
        const ruleId = `grading_${limit.material_type}_${limit.standard}`.replace(/[^a-zA-Z0-9_]/g, '_');
        
        // Check if rule already exists
        const existingRule = await window.electronAPI.dbQuery(
          'SELECT id FROM validation_rules WHERE id = ?',
          [ruleId]
        );

        if (existingRule.length === 0) {
          // Create grading validation rule
          await window.electronAPI.dbQuery(`
            INSERT INTO validation_rules (
              id, name, category, parameter, rule_type, formula, severity, standard, description, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            ruleId,
            `Grading Conformity - ${limit.material_type}`,
            'aggregates',
            'grading_results',
            'formula',
            `checkGradingLimits(value, "${limit.material_type}", "${limit.standard}")`,
            'error',
            limit.standard,
            `Check grading conformity for ${limit.material_type} against ${limit.standard} limits`,
            1
          ]);
        }
      }
    } catch (error) {
      console.error('Error initializing grading limits integration:', error);
    }
  };

  // Initialize validation system
  React.useEffect(() => {
    const initializeValidation = async () => {
      try {
        await EnhancedValidationService.initializeTables();
        await initializeGradingLimitsIntegration();
        setIsInitialized(true);
      } catch (error) {
        console.error('Failed to initialize validation system:', error);
      }
    };
    initializeValidation();
  }, []);

  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto"></div>
          <p className="text-muted-foreground">Initializing validation engine...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <AlertTriangle className="w-6 h-6" />
            Validation Engine
          </h2>
          <p className="text-muted-foreground">
            Create and manage data validation rules with Excel-style formulas
          </p>
        </div>
        <Badge variant="secondary" className="px-3 py-1">
          <Code className="w-4 h-4 mr-2" />
          Advanced Validation
        </Badge>
      </div>

      <Tabs defaultValue="rules" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="rules" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Rules Management
          </TabsTrigger>
          <TabsTrigger value="test" className="flex items-center gap-2">
            <Play className="w-4 h-4" />
            Test Validator
          </TabsTrigger>
          <TabsTrigger value="import" className="flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Import/Export
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Validation Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-6">
          <ValidationRuleTable 
            onEditRule={handleEditRule}
            onTestRule={handleTestRule}
          />
        </TabsContent>

        <TabsContent value="test" className="space-y-6">
          <ValidationRunner />
        </TabsContent>

        <TabsContent value="import" className="space-y-6">
          <RuleImporter />
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <RuleLogs />
        </TabsContent>
      </Tabs>

      {/* Rule Editor Dialog */}
      {showEditor && (
        <ValidationRuleEditor
          open={showEditor}
          onOpenChange={setShowEditor}
          rule={selectedRule}
          onSave={handleSaveRule}
          categories={[]} // Will be loaded by the component
        />
      )}
    </div>
  );
}