import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  History, 
  Search, 
  Filter, 
  Download,
  CheckCircle,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { TestResultValidation } from '@/services/validation/validationTypes';

export function RuleLogs() {
  const [logs, setLogs] = useState<TestResultValidation[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<TestResultValidation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const { toast } = useToast();

  useEffect(() => {
    loadLogs();
  }, []);

  useEffect(() => {
    filterLogs();
  }, [logs, searchTerm, statusFilter, severityFilter]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      // For demo purposes, we'll create some sample logs since we don't have a specific test ID
      const sampleLogs: TestResultValidation[] = [
        {
          id: 'log_001',
          test_id: 'test_123',
          rule_id: 'rule_001',
          passed: false,
          failure_reason: 'FM value out of acceptable range',
          evaluated_at: new Date().toISOString(),
          field: 'FM',
          rule_reason: 'FM must be between 2.3 and 3.1'
        },
        {
          id: 'log_002',
          test_id: 'test_124',
          rule_id: 'rule_002',
          passed: true,
          evaluated_at: new Date(Date.now() - 3600000).toISOString(),
          field: 'moisture',
          rule_reason: 'Moisture content validation'
        },
        {
          id: 'log_003',
          test_id: 'test_125',
          rule_id: 'rule_003',
          passed: false,
          failure_reason: 'Compressive strength below minimum threshold',
          evaluated_at: new Date(Date.now() - 7200000).toISOString(),
          field: 'compressive_strength',
          rule_reason: 'Compressive strength must be >= 20 MPa'
        }
      ];
      setLogs(sampleLogs);
    } catch (error) {
      console.error('Error loading logs:', error);
      toast({
        title: 'Error',
        description: 'Failed to load validation logs',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const filterLogs = () => {
    let filtered = logs;

    if (searchTerm) {
      filtered = filtered.filter(log =>
        log.test_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.field?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.failure_reason?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(log => 
        statusFilter === 'passed' ? log.passed : !log.passed
      );
    }

    setFilteredLogs(filtered);
  };

  const exportLogs = () => {
    const csvHeaders = ['Test ID', 'Field', 'Status', 'Reason', 'Evaluated At'];
    const csvRows = filteredLogs.map(log => [
      log.test_id,
      log.field || '',
      log.passed ? 'PASS' : 'FAIL',
      log.failure_reason || log.rule_reason || '',
      new Date(log.evaluated_at).toLocaleString()
    ]);

    const csvContent = [csvHeaders, ...csvRows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'validation_logs.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast({
      title: 'Success',
      description: 'Validation logs exported successfully'
    });
  };

  const getStatusIcon = (passed: boolean) => {
    return passed 
      ? <CheckCircle className="w-4 h-4 text-green-500" />
      : <AlertTriangle className="w-4 h-4 text-red-500" />;
  };

  const getStatusBadge = (passed: boolean) => {
    return passed 
      ? <Badge className="bg-green-500">PASS</Badge>
      : <Badge variant="destructive">FAIL</Badge>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <History className="w-5 h-5" />
            Validation Logs
          </h3>
          <p className="text-sm text-muted-foreground">
            Track validation results and rule execution history
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadLogs} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={exportLogs} variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{logs.length}</div>
              <div className="text-sm text-muted-foreground">Total Validations</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {logs.filter(log => log.passed).length}
              </div>
              <div className="text-sm text-muted-foreground">Passed</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {logs.filter(log => !log.passed).length}
              </div>
              <div className="text-sm text-muted-foreground">Failed</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {logs.length > 0 ? Math.round((logs.filter(log => log.passed).length / logs.length) * 100) : 0}%
              </div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="passed">Passed Only</SelectItem>
                <SelectItem value="failed">Failed Only</SelectItem>
              </SelectContent>
            </Select>

            <div className="text-sm text-muted-foreground flex items-center">
              Showing {filteredLogs.length} of {logs.length} logs
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test ID</TableHead>
                <TableHead>Field</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Evaluated At</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-medium">{log.test_id}</TableCell>
                  <TableCell>
                    {log.field && (
                      <Badge variant="outline">{log.field}</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(log.passed)}
                      {getStatusBadge(log.passed)}
                    </div>
                  </TableCell>
                  <TableCell className="max-w-xs">
                    <div className="text-sm">
                      {log.passed ? (
                        <span className="text-green-600">Validation passed</span>
                      ) : (
                        <span className="text-red-600">
                          {log.failure_reason || log.rule_reason}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {new Date(log.evaluated_at).toLocaleString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredLogs.length === 0 && (
            <div className="text-center py-8">
              <History className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No validation logs found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}