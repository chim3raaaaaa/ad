import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Code, 
  Play, 
  CheckCircle, 
  AlertTriangle, 
  Info,
  BookOpen
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { ValidationRule } from '@/services/validation/validationTypes';

interface ValidationRuleEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rule?: ValidationRule | null;
  onSave: (rule: any) => void;
  categories: string[];
}

export function ValidationRuleEditor({ 
  open, 
  onOpenChange, 
  rule, 
  onSave, 
  categories 
}: ValidationRuleEditorProps) {
  const [formData, setFormData] = useState({
    category: '',
    field: '',
    formula: '',
    failure_reason: '',
    severity: 'critical' as 'warning' | 'critical',
    active: true
  });
  const [testData, setTestData] = useState('{"value": 25, "FM": 2.5, "moisture": 3.2}');
  const [testResult, setTestResult] = useState<{ success: boolean; result?: boolean; error?: string } | null>(null);
  const [availableFields, setAvailableFields] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (rule) {
      setFormData({
        category: rule.category,
        field: rule.field,
        formula: rule.formula,
        failure_reason: rule.failure_reason,
        severity: rule.severity,
        active: rule.active
      });
    } else {
      setFormData({
        category: '',
        field: '',
        formula: '',
        failure_reason: '',
        severity: 'critical',
        active: true
      });
    }
  }, [rule, open]);

  useEffect(() => {
    if (formData.category) {
      loadFieldsForCategory(formData.category);
    }
  }, [formData.category]);

  const loadFieldsForCategory = async (category: string) => {
    try {
      const fields = await EnhancedValidationService.getFieldsForCategory(category);
      setAvailableFields(fields);
    } catch (error) {
      console.error('Error loading fields:', error);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleTestFormula = () => {
    if (!formData.formula || !testData) {
      toast({
        title: 'Error',
        description: 'Please enter both formula and test data',
        variant: 'destructive'
      });
      return;
    }

    try {
      const data = JSON.parse(testData);
      const result = EnhancedValidationService.testFormula(formData.formula, data);
      setTestResult(result);
    } catch (error) {
      setTestResult({
        success: false,
        error: 'Invalid JSON test data'
      });
    }
  };

  const handleSave = () => {
    if (!formData.category || !formData.field || !formData.formula || !formData.failure_reason) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    onSave({
      ...formData,
      created_by: 'current_user'
    });
  };

  const formulaExamples = [
    {
      title: 'Range Check',
      formula: 'value >= 2.3 AND value <= 3.1',
      description: 'Check if value is within acceptable range'
    },
    {
      title: 'Conditional Logic',
      formula: 'IF(FM < 2.3, false, IF(FM > 3.1, false, true))',
      description: 'Use IF statements for complex conditions'
    },
    {
      title: 'Cross-field Validation',
      formula: 'moisture < (FM * 0.5)',
      description: 'Validate relationships between fields'
    },
    {
      title: 'Multiple Conditions',
      formula: '(value >= 35 AND value <= 65) OR (type == "special")',
      description: 'Complex boolean logic with OR conditions'
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {rule ? 'Edit Validation Rule' : 'Create New Validation Rule'}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="editor" className="space-y-4">
          <TabsList>
            <TabsTrigger value="editor">
              <Code className="w-4 h-4 mr-2" />
              Rule Editor
            </TabsTrigger>
            <TabsTrigger value="test">
              <Play className="w-4 h-4 mr-2" />
              Test Formula
            </TabsTrigger>
            <TabsTrigger value="examples">
              <BookOpen className="w-4 h-4 mr-2" />
              Examples
            </TabsTrigger>
          </TabsList>

          <TabsContent value="editor" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="field">Field *</Label>
                  {availableFields.length > 0 ? (
                    <Select value={formData.field} onValueChange={(value) => handleInputChange('field', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select field" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableFields.map(field => (
                          <SelectItem key={field} value={field}>
                            {field}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      id="field"
                      placeholder="Enter field name (e.g., FM, moisture, value)"
                      value={formData.field}
                      onChange={(e) => handleInputChange('field', e.target.value)}
                    />
                  )}
                </div>

                <div>
                  <Label htmlFor="severity">Severity *</Label>
                  <Select value={formData.severity} onValueChange={(value) => handleInputChange('severity', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="critical">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-red-500" />
                          Critical
                        </div>
                      </SelectItem>
                      <SelectItem value="warning">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          Warning
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => handleInputChange('active', checked)}
                  />
                  <Label htmlFor="active">Active</Label>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="formula">Excel-style Formula *</Label>
                  <Textarea
                    id="formula"
                    placeholder="e.g., value >= 2.3 AND value <= 3.1"
                    value={formData.formula}
                    onChange={(e) => handleInputChange('formula', e.target.value)}
                    rows={4}
                    className="font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Use field names as variables. Supports: AND, OR, IF(), comparison operators
                  </p>
                </div>

                <div>
                  <Label htmlFor="failure_reason">Failure Message *</Label>
                  <Textarea
                    id="failure_reason"
                    placeholder="Message displayed when validation fails"
                    value={formData.failure_reason}
                    onChange={(e) => handleInputChange('failure_reason', e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="test" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Your Formula</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="test-formula">Formula to Test</Label>
                  <Input
                    id="test-formula"
                    value={formData.formula}
                    onChange={(e) => handleInputChange('formula', e.target.value)}
                    className="font-mono"
                    placeholder="Enter your formula"
                  />
                </div>

                <div>
                  <Label htmlFor="test-data">Test Data (JSON)</Label>
                  <Textarea
                    id="test-data"
                    value={testData}
                    onChange={(e) => setTestData(e.target.value)}
                    rows={4}
                    className="font-mono text-sm"
                    placeholder='{"value": 25, "FM": 2.5, "moisture": 3.2}'
                  />
                </div>

                <Button onClick={handleTestFormula} className="w-full">
                  <Play className="w-4 h-4 mr-2" />
                  Test Formula
                </Button>

                {testResult && (
                  <Alert className={testResult.success ? 'border-green-500' : 'border-red-500'}>
                    <div className="flex items-center gap-2">
                      {testResult.success ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-500" />
                      )}
                      <AlertDescription>
                        {testResult.success ? (
                          <div>
                            <strong>Result:</strong> {testResult.result ? 'PASS' : 'FAIL'}
                            <br />
                            <span className="text-sm text-muted-foreground">
                              Formula evaluated successfully
                            </span>
                          </div>
                        ) : (
                          <div>
                            <strong>Error:</strong> {testResult.error}
                          </div>
                        )}
                      </AlertDescription>
                    </div>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="examples" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {formulaExamples.map((example, index) => (
                <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      {example.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <code className="text-xs bg-muted p-2 rounded block mb-2">
                      {example.formula}
                    </code>
                    <p className="text-sm text-muted-foreground">
                      {example.description}
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2"
                      onClick={() => handleInputChange('formula', example.formula)}
                    >
                      Use This Formula
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Alert>
              <Info className="w-4 h-4" />
              <AlertDescription>
                <strong>Supported Operators:</strong>
                <ul className="list-disc list-inside mt-2 text-sm">
                  <li>Comparison: <code>&gt;=</code>, <code>&lt;=</code>, <code>&gt;</code>, <code>&lt;</code>, <code>==</code>, <code>!=</code></li>
                  <li>Logical: <code>AND</code>, <code>OR</code>, <code>NOT</code></li>
                  <li>Functions: <code>IF(condition, true_value, false_value)</code></li>
                  <li>Math: <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code>, <code>%</code></li>
                </ul>
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {rule ? 'Update Rule' : 'Create Rule'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}