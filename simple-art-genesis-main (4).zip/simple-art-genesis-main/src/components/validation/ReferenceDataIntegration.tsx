import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Database, 
  FileDown, 
  FileUp, 
  AlertTriangle,
  CheckCircle,
  Info,
  Link as LinkIcon,
  ExternalLink
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { ValidationRule } from '@/services/validation/validationTypes';

interface ReferenceDataIntegrationProps {
  onRulesImported?: (count: number) => void;
  onRulesExported?: () => void;
}

export function ReferenceDataIntegration({ 
  onRulesImported, 
  onRulesExported 
}: ReferenceDataIntegrationProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connected' | 'error'>('disconnected');
  const [referenceDataRules, setReferenceDataRules] = useState<ValidationRule[]>([]);
  const [localRules, setLocalRules] = useState<ValidationRule[]>([]);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'completed' | 'error'>('idle');
  const { toast } = useToast();

  useEffect(() => {
    loadLocalRules();
    checkReferenceDataConnection();
  }, []);

  const loadLocalRules = async () => {
    try {
      const rules = await EnhancedValidationService.getAllRules();
      setLocalRules(rules);
    } catch (error) {
      console.error('Error loading local rules:', error);
    }
  };

  const checkReferenceDataConnection = async () => {
    try {
      // Check if reference data manager is available
      // For now, simulate connection check
      setConnectionStatus('connected');
    } catch (error) {
      setConnectionStatus('error');
    }
  };

  const connectToReferenceData = async () => {
    setIsConnecting(true);
    try {
      // Simulate connection to reference data manager
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Load sample reference data rules
      const sampleReferenceRules: ValidationRule[] = [
        {
          id: 'ref_rule_001',
          category: 'Aggregates',
          field: 'FM',
          formula: 'value >= 2.3 AND value <= 3.1',
          failure_reason: 'FM must be between 2.3 and 3.1 as per reference standards',
          severity: 'critical',
          active: true,
          created_at: new Date().toISOString(),
          created_by: 'reference_data_manager'
        },
        {
          id: 'ref_rule_002',
          category: 'Cubes',
          field: 'compressive_strength',
          formula: 'value >= 20',
          failure_reason: 'Compressive strength must be at least 20 MPa per reference standards',
          severity: 'critical',
          active: true,
          created_at: new Date().toISOString(),
          created_by: 'reference_data_manager'
        }
      ];

      setReferenceDataRules(sampleReferenceRules);
      setConnectionStatus('connected');
      
      toast({
        title: 'Connected Successfully',
        description: `Found ${sampleReferenceRules.length} validation rules in Reference Data Manager`
      });
    } catch (error) {
      setConnectionStatus('error');
      toast({
        title: 'Connection Failed',
        description: 'Unable to connect to Reference Data Manager',
        variant: 'destructive'
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const syncRulesFromReference = async () => {
    setSyncStatus('syncing');
    try {
      let importedCount = 0;
      
      for (const refRule of referenceDataRules) {
        // Check if rule already exists locally
        const existsLocally = localRules.some(localRule => 
          localRule.category === refRule.category && 
          localRule.field === refRule.field &&
          localRule.formula === refRule.formula
        );

        if (!existsLocally) {
          await EnhancedValidationService.addRule({
            category: refRule.category,
            field: refRule.field,
            formula: refRule.formula,
            failure_reason: refRule.failure_reason,
            severity: refRule.severity,
            active: refRule.active,
            created_by: 'reference_data_sync'
          });
          importedCount++;
        }
      }

      await loadLocalRules();
      setSyncStatus('completed');
      
      toast({
        title: 'Sync Completed',
        description: `Imported ${importedCount} new rules from Reference Data Manager`
      });

      onRulesImported?.(importedCount);
    } catch (error) {
      setSyncStatus('error');
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync rules from Reference Data Manager',
        variant: 'destructive'
      });
    }
  };

  const exportRulesToReference = async () => {
    try {
      // Simulate export to reference data manager
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: 'Export Completed',
        description: `Exported ${localRules.length} rules to Reference Data Manager`
      });

      onRulesExported?.();
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'Failed to export rules to Reference Data Manager',
        variant: 'destructive'
      });
    }
  };

  const getConnectionStatusBadge = () => {
    switch (connectionStatus) {
      case 'connected':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case 'error':
        return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="secondary"><Database className="w-3 h-3 mr-1" />Disconnected</Badge>;
    }
  };

  const getSyncStatusBadge = () => {
    switch (syncStatus) {
      case 'syncing':
        return <Badge variant="secondary">Syncing...</Badge>;
      case 'completed':
        return <Badge className="bg-green-500">Sync Complete</Badge>;
      case 'error':
        return <Badge variant="destructive">Sync Error</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <LinkIcon className="w-5 h-5" />
            Reference Data Integration
          </h3>
          <p className="text-sm text-muted-foreground">
            Connect to Reference Data Manager to sync validation rules
          </p>
        </div>
        {getConnectionStatusBadge()}
      </div>

      <Tabs defaultValue="connection" className="space-y-4">
        <TabsList>
          <TabsTrigger value="connection">Connection</TabsTrigger>
          <TabsTrigger value="sync">Sync Rules</TabsTrigger>
          <TabsTrigger value="export">Export Rules</TabsTrigger>
        </TabsList>

        <TabsContent value="connection" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                Reference Data Manager Connection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-medium">Connection Status</h4>
                  <p className="text-sm text-muted-foreground">
                    {connectionStatus === 'connected' 
                      ? 'Successfully connected to Reference Data Manager'
                      : connectionStatus === 'error'
                      ? 'Failed to connect to Reference Data Manager'
                      : 'Not connected to Reference Data Manager'
                    }
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {getConnectionStatusBadge()}
                  <Button
                    onClick={connectToReferenceData}
                    disabled={isConnecting || connectionStatus === 'connected'}
                    variant={connectionStatus === 'connected' ? 'outline' : 'default'}
                  >
                    {isConnecting ? 'Connecting...' : connectionStatus === 'connected' ? 'Reconnect' : 'Connect'}
                  </Button>
                </div>
              </div>

              {connectionStatus === 'connected' && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <AlertDescription>
                    Successfully connected to Reference Data Manager. 
                    Found {referenceDataRules.length} validation rules available for sync.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileDown className="w-4 h-4" />
                Import Rules from Reference Data
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Reference Data Rules</h4>
                  <div className="text-2xl font-bold text-blue-600">{referenceDataRules.length}</div>
                  <p className="text-sm text-muted-foreground">Available rules</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Local Rules</h4>
                  <div className="text-2xl font-bold text-green-600">{localRules.length}</div>
                  <p className="text-sm text-muted-foreground">Current rules</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getSyncStatusBadge()}
                </div>
                <Button
                  onClick={syncRulesFromReference}
                  disabled={connectionStatus !== 'connected' || syncStatus === 'syncing'}
                  className="flex items-center gap-2"
                >
                  <FileDown className="w-4 h-4" />
                  {syncStatus === 'syncing' ? 'Syncing...' : 'Sync Rules'}
                </Button>
              </div>

              {referenceDataRules.length > 0 && (
                <div className="space-y-2">
                  <h5 className="font-medium">Available Reference Rules:</h5>
                  {referenceDataRules.map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <div className="font-medium">{rule.category} - {rule.field}</div>
                        <code className="text-xs text-muted-foreground">{rule.formula}</code>
                      </div>
                      <Badge variant={rule.severity === 'critical' ? 'destructive' : 'secondary'}>
                        {rule.severity}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="export" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileUp className="w-4 h-4" />
                Export Rules to Reference Data
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <Info className="w-4 h-4" />
                <AlertDescription>
                  Export your local validation rules to the Reference Data Manager 
                  to share them across the organization.
                </AlertDescription>
              </Alert>

              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Local Rules to Export</h4>
                <div className="text-2xl font-bold text-blue-600">{localRules.length}</div>
                <p className="text-sm text-muted-foreground">
                  Rules ready for export to Reference Data Manager
                </p>
              </div>

              <Button
                onClick={exportRulesToReference}
                disabled={connectionStatus !== 'connected' || localRules.length === 0}
                className="w-full flex items-center gap-2"
              >
                <FileUp className="w-4 h-4" />
                Export {localRules.length} Rules to Reference Data
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}