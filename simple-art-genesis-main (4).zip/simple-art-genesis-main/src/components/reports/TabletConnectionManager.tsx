import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { 
  Wifi, 
  WifiOff, 
  Tablet, 
  RefreshCw, 
  Settings, 
  Activity,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TabletDevice {
  id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'connecting' | 'error';
  lastSeen: string;
  batteryLevel?: number;
  location?: string;
  dataBuffer?: any[];
}

interface ConnectionSettings {
  wsUrl: string;
  reconnectInterval: number;
  maxReconnectAttempts: number;
  dataProcessingInterval: number;
  enableAutoSync: boolean;
}

export function TabletConnectionManager() {
  const [devices, setDevices] = useState<TabletDevice[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [settings, setSettings] = useState<ConnectionSettings>({
    wsUrl: 'ws://localhost:8080',
    reconnectInterval: 5000,
    maxReconnectAttempts: 10,
    dataProcessingInterval: 1000,
    enableAutoSync: true
  });
  const [showSettings, setShowSettings] = useState(false);
  const [websocket, setWebsocket] = useState<WebSocket | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [incomingData, setIncomingData] = useState<any[]>([]);

  const { toast } = useToast();

  useEffect(() => {
    // Initialize connection on mount
    if (settings.enableAutoSync) {
      connectToTablets();
    }

    // Cleanup on unmount
    return () => {
      if (websocket) {
        websocket.close();
      }
    };
  }, []);

  useEffect(() => {
    // Process incoming data
    if (incomingData.length > 0 && settings.dataProcessingInterval > 0) {
      const interval = setInterval(() => {
        processIncomingData();
      }, settings.dataProcessingInterval);

      return () => clearInterval(interval);
    }
  }, [incomingData, settings.dataProcessingInterval]);

  const connectToTablets = async () => {
    if (connectionStatus === 'connecting' || connectionStatus === 'connected') return;

    setIsConnecting(true);
    setConnectionStatus('connecting');

    try {
      const ws = new WebSocket(settings.wsUrl);
      
      ws.onopen = () => {
        console.log('WebSocket connected to tablet service');
        setConnectionStatus('connected');
        setReconnectAttempts(0);
        setWebsocket(ws);
        
        toast({
          title: "Connected",
          description: "Successfully connected to tablet service"
        });

        // Send device discovery request
        ws.send(JSON.stringify({
          type: 'discover_devices',
          timestamp: new Date().toISOString()
        }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleIncomingMessage(data);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        console.log('WebSocket connection closed');
        setConnectionStatus('disconnected');
        setWebsocket(null);

        // Attempt reconnection if enabled
        if (settings.enableAutoSync && reconnectAttempts < settings.maxReconnectAttempts) {
          setTimeout(() => {
            setReconnectAttempts(prev => prev + 1);
            connectToTablets();
          }, settings.reconnectInterval);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionStatus('disconnected');
        
        toast({
          title: "Connection Error",
          description: "Failed to connect to tablet service",
          variant: "destructive"
        });
      };

    } catch (error) {
      console.error('Failed to establish WebSocket connection:', error);
      setConnectionStatus('disconnected');
      
      toast({
        title: "Connection Failed",
        description: "Unable to connect to tablet service",
        variant: "destructive"
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectFromTablets = () => {
    if (websocket) {
      websocket.close();
    }
    setConnectionStatus('disconnected');
    setDevices([]);
    
    toast({
      title: "Disconnected",
      description: "Disconnected from tablet service"
    });
  };

  const handleIncomingMessage = (data: any) => {
    switch (data.type) {
      case 'device_discovered':
        handleDeviceDiscovered(data.device);
        break;
      case 'device_status_update':
        handleDeviceStatusUpdate(data.deviceId, data.status);
        break;
      case 'test_data':
        handleTestData(data);
        break;
      case 'device_disconnected':
        handleDeviceDisconnected(data.deviceId);
        break;
      default:
        console.log('Unknown message type:', data.type);
    }
  };

  const handleDeviceDiscovered = (device: Omit<TabletDevice, 'id'> & { id?: string }) => {
    const newDevice: TabletDevice = {
      id: device.id || crypto.randomUUID(),
      name: device.name,
      type: device.type,
      status: 'connected',
      lastSeen: new Date().toISOString(),
      batteryLevel: device.batteryLevel,
      location: device.location,
      dataBuffer: []
    };

    setDevices(prev => {
      const existing = prev.find(d => d.id === newDevice.id);
      if (existing) {
        return prev.map(d => d.id === newDevice.id ? { ...d, ...newDevice } : d);
      }
      return [...prev, newDevice];
    });

    toast({
      title: "Device Discovered",
      description: `${device.name} is now connected`
    });
  };

  const handleDeviceStatusUpdate = (deviceId: string, status: TabletDevice['status']) => {
    setDevices(prev => prev.map(device => 
      device.id === deviceId 
        ? { ...device, status, lastSeen: new Date().toISOString() }
        : device
    ));
  };

  const handleTestData = (data: any) => {
    setIncomingData(prev => [...prev, {
      ...data,
      receivedAt: new Date().toISOString()
    }]);

    // Update device data buffer
    if (data.deviceId) {
      setDevices(prev => prev.map(device => 
        device.id === data.deviceId 
          ? { 
              ...device, 
              dataBuffer: [...(device.dataBuffer || []), data],
              lastSeen: new Date().toISOString()
            }
          : device
      ));
    }
  };

  const handleDeviceDisconnected = (deviceId: string) => {
    setDevices(prev => prev.map(device => 
      device.id === deviceId 
        ? { ...device, status: 'disconnected', lastSeen: new Date().toISOString() }
        : device
    ));

    toast({
      title: "Device Disconnected",
      description: "A tablet device has been disconnected",
      variant: "destructive"
    });
  };

  const processIncomingData = async () => {
    if (incomingData.length === 0) return;

    try {
      // Process data through ConcreteProductsAPIService
      const { ConcreteProductsAPIService } = await import('@/services/database/concreteProductsAPIService');
      
      for (const dataPoint of incomingData) {
        if (dataPoint.testType === 'concrete') {
          await ConcreteProductsAPIService.processTabletData(dataPoint);
        }
      }

      // Clear processed data
      setIncomingData([]);

      toast({
        title: "Data Processed",
        description: `Processed ${incomingData.length} data points`
      });

    } catch (error) {
      console.error('Failed to process incoming data:', error);
      toast({
        title: "Processing Error",
        description: "Failed to process some tablet data",
        variant: "destructive"
      });
    }
  };

  const getStatusIcon = (status: TabletDevice['status']) => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'connecting':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'disconnected':
        return <WifiOff className="h-4 w-4 text-gray-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return <WifiOff className="h-4 w-4 text-gray-500" />;
    }
  };

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'text-green-600';
      case 'connecting':
        return 'text-yellow-600';
      case 'disconnected':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Tablet className="h-5 w-5" />
              Tablet Connection Manager
            </div>
            <div className="flex items-center gap-2">
              <div className={`flex items-center gap-2 ${getConnectionStatusColor()}`}>
                {connectionStatus === 'connected' ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
                <span className="text-sm font-medium capitalize">{connectionStatus}</span>
              </div>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">
                Service URL: {settings.wsUrl}
              </div>
              <div className="text-sm text-muted-foreground">
                Connected Devices: {devices.filter(d => d.status === 'connected').length}
              </div>
              <div className="text-sm text-muted-foreground">
                Pending Data: {incomingData.length} items
              </div>
              {reconnectAttempts > 0 && (
                <div className="text-sm text-yellow-600">
                  Reconnect attempts: {reconnectAttempts}/{settings.maxReconnectAttempts}
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Dialog open={showSettings} onOpenChange={setShowSettings}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Connection Settings</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="ws-url">WebSocket URL</Label>
                      <Input
                        id="ws-url"
                        value={settings.wsUrl}
                        onChange={(e) => setSettings(prev => ({ ...prev, wsUrl: e.target.value }))}
                        placeholder="ws://localhost:8080"
                      />
                    </div>
                    <div>
                      <Label htmlFor="reconnect-interval">Reconnect Interval (ms)</Label>
                      <Input
                        id="reconnect-interval"
                        type="number"
                        value={settings.reconnectInterval}
                        onChange={(e) => setSettings(prev => ({ ...prev, reconnectInterval: parseInt(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="max-attempts">Max Reconnect Attempts</Label>
                      <Input
                        id="max-attempts"
                        type="number"
                        value={settings.maxReconnectAttempts}
                        onChange={(e) => setSettings(prev => ({ ...prev, maxReconnectAttempts: parseInt(e.target.value) }))}
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="auto-sync"
                        checked={settings.enableAutoSync}
                        onCheckedChange={(checked) => setSettings(prev => ({ ...prev, enableAutoSync: checked }))}
                      />
                      <Label htmlFor="auto-sync">Enable Auto Sync</Label>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              
              {connectionStatus === 'disconnected' ? (
                <Button 
                  onClick={connectToTablets} 
                  disabled={isConnecting}
                  size="sm"
                >
                  {isConnecting ? (
                    <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Wifi className="h-4 w-4 mr-2" />
                  )}
                  Connect
                </Button>
              ) : (
                <Button 
                  onClick={disconnectFromTablets}
                  variant="outline"
                  size="sm"
                >
                  <WifiOff className="h-4 w-4 mr-2" />
                  Disconnect
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Device List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Connected Devices
          </CardTitle>
        </CardHeader>
        <CardContent>
          {devices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No devices connected. Connect to the tablet service to discover devices.
            </div>
          ) : (
            <div className="space-y-4">
              {devices.map((device) => (
                <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(device.status)}
                      <Tablet className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="font-medium">{device.name}</div>
                      <div className="text-sm text-muted-foreground">{device.type}</div>
                      {device.location && (
                        <div className="text-xs text-muted-foreground">{device.location}</div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {device.batteryLevel !== undefined && (
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        <Progress value={device.batteryLevel} className="w-16" />
                        <span className="text-xs">{device.batteryLevel}%</span>
                      </div>
                    )}
                    <div className="text-right">
                      <div className="text-sm">
                        <Badge variant={device.status === 'connected' ? 'default' : 'secondary'}>
                          {device.status}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Last seen: {new Date(device.lastSeen).toLocaleTimeString()}
                      </div>
                      {device.dataBuffer && device.dataBuffer.length > 0 && (
                        <div className="text-xs text-blue-600">
                          {device.dataBuffer.length} data points
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Processing Status */}
      {incomingData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5" />
              Data Processing Queue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>Pending data points:</span>
                <Badge>{incomingData.length}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Processing interval:</span>
                <span className="text-sm text-muted-foreground">{settings.dataProcessingInterval}ms</span>
              </div>
              <Button 
                onClick={processIncomingData} 
                className="w-full"
                size="sm"
              >
                Process Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}