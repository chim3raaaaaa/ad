import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Download, 
  Share2, 
  Copy, 
  Trash2, 
  Eye, 
  Upload,
  Search,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { ReportsAPI, ReportTemplate, ReportCategory } from '@/services/api/reportsAPI';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface TemplateLibraryProps {
  onTemplateSelect?: (template: ReportTemplate) => void;
  onTemplateEdit?: (template: ReportTemplate) => void;
  selectedProductType?: string;
}

export function TemplateLibrary({ 
  onTemplateSelect, 
  onTemplateEdit, 
  selectedProductType 
}: TemplateLibraryProps) {
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [categories, setCategories] = useState<ReportCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('');
  const [filterOwner, setFilterOwner] = useState<string>('');
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<ReportTemplate | null>(null);
  const [uploadFile, setUploadFile] = useState<File | null>(null);

  const { toast } = useToast();
  const { user } = useUser();

  useEffect(() => {
    loadCategories();
    loadTemplates();
  }, []);

  useEffect(() => {
    loadTemplates();
  }, [selectedProductType, filterType, filterOwner]);

  const loadCategories = async () => {
    try {
      const data = await ReportsAPI.getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadTemplates = async () => {
    setLoading(true);
    try {
      const productType = selectedProductType || filterType || undefined;
      const data = await ReportsAPI.getTemplates(productType);
      
      let filteredData = data;
      
      // Filter by owner
      if (filterOwner === 'mine') {
        filteredData = data.filter(t => t.uploaded_by === user?.username);
      } else if (filterOwner === 'shared') {
        filteredData = data.filter(t => 
          t.shared_with && t.shared_with.length > 0 && t.uploaded_by !== user?.username
        );
      }
      
      setTemplates(filteredData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load templates",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async () => {
    if (!uploadFile) {
      toast({
        title: "Validation Error",
        description: "Please select a file to upload",
        variant: "destructive"
      });
      return;
    }

    try {
      const result = await ReportsAPI.uploadFile(
        uploadFile,
        'template',
        user?.username || 'unknown'
      );

      if (result.success) {
        toast({
          title: "Success",
          description: "Template uploaded successfully"
        });
        
        await loadTemplates();
        setShowUploadDialog(false);
        setUploadFile(null);
      } else {
        throw new Error(result.error || 'Upload failed');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload template",
        variant: "destructive"
      });
    }
  };

  const handleDownload = async (template: ReportTemplate) => {
    try {
      if (template.file_path) {
        // Download actual file
        const link = document.createElement('a');
        link.href = template.file_path;
        link.download = `${template.name}.${template.template_type}`;
        link.click();
      } else {
        // Export template configuration as JSON
        const templateData = {
          name: template.name,
          description: template.description,
          product_type: template.product_type,
          layout_json: template.layout_json,
          template_type: template.template_type,
          exported_at: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(templateData, null, 2)], { 
          type: 'application/json' 
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${template.name}.json`;
        link.click();
        URL.revokeObjectURL(url);
      }
      
      toast({
        title: "Success",
        description: "Template downloaded successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download template",
        variant: "destructive"
      });
    }
  };

  const handleDuplicate = async (template: ReportTemplate) => {
    try {
      const duplicatedTemplate = {
        name: `${template.name} (Copy)`,
        description: template.description,
        product_type: template.product_type,
        layout_json: template.layout_json,
        uploaded_by: user?.username || 'unknown',
        template_type: template.template_type,
        version: 1,
        is_active: true
      };

      const result = await ReportsAPI.saveTemplate(duplicatedTemplate);
      
      if (result) {
        toast({
          title: "Success",
          description: "Template duplicated successfully"
        });
        await loadTemplates();
      } else {
        throw new Error('Failed to duplicate template');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to duplicate template",
        variant: "destructive"
      });
    }
  };

  const handleShare = async (template: ReportTemplate) => {
    setSelectedTemplate(template);
    setShowShareDialog(true);
  };

  const handleDelete = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      // Implementation would depend on ReportsAPI supporting delete
      toast({
        title: "Info",
        description: "Template deletion not yet implemented",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete template",
        variant: "destructive"
      });
    }
  };

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTemplateTypeIcon = (type: string) => {
    switch (type) {
      case 'docx':
        return '📄';
      case 'xlsx':
        return '📊';
      case 'pdf':
        return '📋';
      default:
        return '🎨';
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters & Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search">Search Templates</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search by name or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="filter-type">Product Type</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All types</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filter-owner">Ownership</Label>
              <Select value={filterOwner} onValueChange={setFilterOwner}>
                <SelectTrigger>
                  <SelectValue placeholder="All templates" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All templates</SelectItem>
                  <SelectItem value="mine">My templates</SelectItem>
                  <SelectItem value="shared">Shared with me</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <PermissionWrapper permission="reports.upload_template">
                <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
                  <DialogTrigger asChild>
                    <Button className="w-full">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upload Template</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="template-file">Template File</Label>
                        <Input
                          id="template-file"
                          type="file"
                          accept=".docx,.xlsx,.pdf,.json"
                          onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                        />
                        <p className="text-sm text-muted-foreground mt-1">
                          Supported formats: DOCX, XLSX, PDF, JSON
                        </p>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleUpload}>
                          Upload
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </PermissionWrapper>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Template Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-8">Loading templates...</div>
        ) : filteredTemplates.length === 0 ? (
          <div className="col-span-full text-center py-8 text-muted-foreground">
            No templates found matching your criteria.
          </div>
        ) : (
          filteredTemplates.map((template) => (
            <Card key={template.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{getTemplateTypeIcon(template.template_type)}</span>
                    <div>
                      <CardTitle className="text-base">{template.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {template.description || 'No description'}
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">{template.template_type.toUpperCase()}</Badge>
                  <Badge variant="secondary">
                    {categories.find(c => c.id === template.product_type)?.name || template.product_type}
                  </Badge>
                  {template.shared_with && template.shared_with.length > 0 && (
                    <Badge variant="default">Shared</Badge>
                  )}
                </div>
                
                <div className="text-xs text-muted-foreground">
                  <div>Created by: {template.uploaded_by}</div>
                  <div>Version: {template.version}</div>
                  <div>Updated: {new Date(template.uploaded_at).toLocaleDateString()}</div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {onTemplateSelect && (
                    <Button size="sm" onClick={() => onTemplateSelect(template)}>
                      <Eye className="h-4 w-4 mr-1" />
                      Use
                    </Button>
                  )}
                  
                  <Button size="sm" variant="outline" onClick={() => handleDownload(template)}>
                    <Download className="h-4 w-4" />
                  </Button>
                  
                  <PermissionWrapper permission="reports.create_template">
                    <Button size="sm" variant="outline" onClick={() => handleDuplicate(template)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </PermissionWrapper>
                  
                  {template.uploaded_by === user?.username && (
                    <PermissionWrapper permission="reports.share_template">
                      <Button size="sm" variant="outline" onClick={() => handleShare(template)}>
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </PermissionWrapper>
                  )}
                  
                  {template.uploaded_by === user?.username && (
                    <PermissionWrapper permission="reports.delete_template">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleDelete(template.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </PermissionWrapper>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Template</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Template sharing functionality will be implemented with user role management.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowShareDialog(false)}>
                Cancel
              </Button>
              <Button onClick={() => {
                toast({
                  title: "Info",
                  description: "Sharing functionality not yet implemented",
                  variant: "default"
                });
                setShowShareDialog(false);
              }}>
                Share
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}