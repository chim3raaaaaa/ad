import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Settings, BarChart3 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChartBinding, ChartBindingConfig, ChartFilter, EnhancedAnalyticsDataBinding } from '@/services/reporting/enhancedAnalyticsDataBinding';
import { ChartDefinition } from '@/services/reporting/enhancedAnalyticsIntegration';

interface ChartConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (binding: ChartBinding) => void;
  initialBinding?: ChartBinding;
  elementId: string;
}

interface FilterConfig {
  field: string;
  operator: 'equals' | 'contains' | 'range' | 'greater' | 'less';
  value: string;
  displayName: string;
}

export function ChartConfigurationModal({
  isOpen,
  onClose,
  onSave,
  initialBinding,
  elementId
}: ChartConfigurationModalProps) {
  const { toast } = useToast();
  
  // State management
  const [availableCharts, setAvailableCharts] = useState<ChartDefinition[]>([]);
  const [selectedChartId, setSelectedChartId] = useState<string>('');
  const [dataSource, setDataSource] = useState<'live' | 'memo' | 'template'>('live');
  const [memoId, setMemoId] = useState<string>('');
  const [refreshInterval, setRefreshInterval] = useState<number>(300000); // 5 minutes
  const [filters, setFilters] = useState<FilterConfig[]>([]);
  const [styling, setStyling] = useState({
    width: 400,
    height: 300,
    theme: 'default',
    colors: ['#3b82f6', '#10b981']
  });
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });
  const [productFilters, setProductFilters] = useState<string[]>([]);
  const [plantFilters, setPlantFilters] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  // Load available charts on mount
  useEffect(() => {
    loadAvailableCharts();
  }, []);

  // Initialize form with existing binding
  useEffect(() => {
    if (initialBinding) {
      setSelectedChartId(initialBinding.chartId);
      setDataSource(initialBinding.config.dataSource);
      setMemoId(initialBinding.config.memoId || '');
      setRefreshInterval(initialBinding.refreshInterval || 300000);
      
      // Convert filters
      const filterConfigs = initialBinding.filters.map(f => ({
        field: f.field,
        operator: f.operator,
        value: String(f.value),
        displayName: f.displayName
      }));
      setFilters(filterConfigs);

      // Set styling
      if (initialBinding.config.styling) {
        setStyling({
          width: initialBinding.config.styling.width || 400,
          height: initialBinding.config.styling.height || 300,
          theme: initialBinding.config.styling.theme || 'default',
          colors: initialBinding.config.styling.colors || ['#3b82f6', '#10b981']
        });
      }

      // Set date range
      if (initialBinding.config.dateRange) {
        setDateRange(initialBinding.config.dateRange);
      }

      // Set filters
      setProductFilters(initialBinding.config.productFilter || []);
      setPlantFilters(initialBinding.config.plantFilter || []);
    }
  }, [initialBinding]);

  const loadAvailableCharts = async () => {
    try {
      setLoading(true);
      const charts = await EnhancedAnalyticsDataBinding.getAvailableChartsWithMetadata();
      setAvailableCharts(charts);
      
      if (charts.length > 0 && !selectedChartId) {
        setSelectedChartId(charts[0].id);
      }
    } catch (error) {
      console.error('Failed to load charts:', error);
      toast({
        title: "Error",
        description: "Failed to load available charts",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addFilter = () => {
    setFilters([...filters, {
      field: '',
      operator: 'equals',
      value: '',
      displayName: ''
    }]);
  };

  const removeFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  const updateFilter = (index: number, field: keyof FilterConfig, value: string) => {
    const updated = [...filters];
    updated[index] = { ...updated[index], [field]: value };
    setFilters(updated);
  };

  const handleSave = () => {
    if (!selectedChartId) {
      toast({
        title: "Validation Error",
        description: "Please select a chart type",
        variant: "destructive"
      });
      return;
    }

    // Create binding configuration
    const config: ChartBindingConfig = {
      dataSource,
      memoId: dataSource === 'memo' ? memoId : undefined,
      dateRange: dateRange.start && dateRange.end ? dateRange : undefined,
      productFilter: productFilters.length > 0 ? productFilters : undefined,
      plantFilter: plantFilters.length > 0 ? plantFilters : undefined,
      styling
    };

    // Convert filters
    const chartFilters: ChartFilter[] = filters
      .filter(f => f.field && f.value)
      .map(f => ({
        field: f.field,
        operator: f.operator,
        value: f.operator === 'range' ? 
          { min: parseFloat(f.value.split('-')[0]), max: parseFloat(f.value.split('-')[1]) } :
          f.value,
        displayName: f.displayName || f.field
      }));

    const binding: ChartBinding = {
      chartId: selectedChartId,
      elementId,
      config,
      filters: chartFilters,
      refreshInterval
    };

    onSave(binding);
    onClose();

    toast({
      title: "Success",
      description: "Chart configuration saved successfully"
    });
  };

  const selectedChart = availableCharts.find(c => c.id === selectedChartId);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Configure Chart Element
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Chart Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Chart Type</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="chart-select">Select Chart</Label>
                <Select value={selectedChartId} onValueChange={setSelectedChartId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a chart type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableCharts.map(chart => (
                      <SelectItem key={chart.id} value={chart.id}>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{chart.category}</Badge>
                          <span>{chart.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedChart && (
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    {selectedChart.description}
                  </p>
                  <div className="flex gap-2 mt-2">
                    <Badge>{selectedChart.config.chartType}</Badge>
                    <Badge variant="outline">{selectedChart.category}</Badge>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Data Source Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Data Source</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="data-source">Source Type</Label>
                <Select value={dataSource} onValueChange={(value: 'live' | 'memo' | 'template') => setDataSource(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="live">Live Data</SelectItem>
                    <SelectItem value="memo">Specific Memo</SelectItem>
                    <SelectItem value="template">Template Preview</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {dataSource === 'memo' && (
                <div>
                  <Label htmlFor="memo-id">Memo ID</Label>
                  <Input
                    id="memo-id"
                    value={memoId}
                    onChange={(e) => setMemoId(e.target.value)}
                    placeholder="Enter memo ID..."
                  />
                </div>
              )}

              {dataSource === 'live' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date-start">Start Date</Label>
                    <Input
                      id="date-start"
                      type="date"
                      value={dateRange.start}
                      onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="date-end">End Date</Label>
                    <Input
                      id="date-end"
                      type="date"
                      value={dateRange.end}
                      onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="refresh-interval">Refresh Interval (minutes)</Label>
                <Input
                  id="refresh-interval"
                  type="number"
                  value={refreshInterval / 60000}
                  onChange={(e) => setRefreshInterval(parseInt(e.target.value) * 60000)}
                  min={1}
                  max={1440}
                />
              </div>
            </CardContent>
          </Card>

          {/* Styling Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Chart Styling</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="chart-width">Width (px)</Label>
                  <Input
                    id="chart-width"
                    type="number"
                    value={styling.width}
                    onChange={(e) => setStyling(prev => ({ ...prev, width: parseInt(e.target.value) }))}
                    min={200}
                    max={1200}
                  />
                </div>
                <div>
                  <Label htmlFor="chart-height">Height (px)</Label>
                  <Input
                    id="chart-height"
                    type="number"
                    value={styling.height}
                    onChange={(e) => setStyling(prev => ({ ...prev, height: parseInt(e.target.value) }))}
                    min={150}
                    max={800}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="theme">Theme</Label>
                <Select 
                  value={styling.theme} 
                  onValueChange={(value) => setStyling(prev => ({ ...prev, theme: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="minimal">Minimal</SelectItem>
                    <SelectItem value="vibrant">Vibrant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Filters Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                Data Filters
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addFilter}
                  className="flex items-center gap-2"
                >
                  <Plus className="h-4 w-4" />
                  Add Filter
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {filters.map((filter, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-3">
                    <Label className="text-xs">Field</Label>
                    <Input
                      value={filter.field}
                      onChange={(e) => updateFilter(index, 'field', e.target.value)}
                      placeholder="Field name..."
                      className="text-sm"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-xs">Operator</Label>
                    <Select
                      value={filter.operator}
                      onValueChange={(value) => updateFilter(index, 'operator', value)}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equals">Equals</SelectItem>
                        <SelectItem value="contains">Contains</SelectItem>
                        <SelectItem value="greater">Greater</SelectItem>
                        <SelectItem value="less">Less</SelectItem>
                        <SelectItem value="range">Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-3">
                    <Label className="text-xs">Value</Label>
                    <Input
                      value={filter.value}
                      onChange={(e) => updateFilter(index, 'value', e.target.value)}
                      placeholder={filter.operator === 'range' ? 'min-max' : 'Value...'}
                      className="text-sm"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label className="text-xs">Display Name</Label>
                    <Input
                      value={filter.displayName}
                      onChange={(e) => updateFilter(index, 'displayName', e.target.value)}
                      placeholder="Display name..."
                      className="text-sm"
                    />
                  </div>
                  <div className="col-span-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeFilter(index)}
                      className="h-8 w-8 p-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {filters.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No filters configured. Click "Add Filter" to add data filters.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={loading || !selectedChartId}>
            Save Configuration
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}