import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  FileText, 
  Play, 
  Download,
  Trash2,
  Clock,
  User,
  Copy,
  Eye
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { ReportsAPI } from '@/services/api/reportsAPI';
import { enhancedMemoService } from "@/services/database/enhancedMemoService";
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

interface MemoReportIntegrationProps {
  onReportGenerated?: (reportId: string) => void;
}

export function MemoReportIntegration({ onReportGenerated }: MemoReportIntegrationProps) {
  const [memos, setMemos] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [generatedReports, setGeneratedReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedMemo, setSelectedMemo] = useState<string>('');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [reportParameters, setReportParameters] = useState<any>({});
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);

  const { toast } = useToast();
  const { user } = useUser();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadCompletedMemos(),
        loadTemplates(),
        loadGeneratedReports()
      ]);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCompletedMemos = async () => {
    try {
      // Mock data for now - would integrate with actual memo service
      const data = [
        {
          id: '1',
          memo_ref: 'UBP-AGG-2024-001',
          title: 'Aggregate Testing Batch 1',
          product_type: 'aggregates',
          status: 'completed',
          completed_at: '2024-01-15',
          updated_at: '2024-01-15'
        }
      ];
      setMemos(data);
    } catch (error) {
      console.error('Failed to load completed memos:', error);
      toast({
        title: "Error",
        description: "Failed to load completed memos",
        variant: "destructive"
      });
    }
  };

  const loadTemplates = async () => {
    try {
      const data = await ReportsAPI.getTemplates();
      setTemplates(data);
    } catch (error) {
      console.error('Failed to load templates:', error);
    }
  };

  const loadGeneratedReports = async () => {
    try {
      // This would need to be implemented in ReportsAPI
      // const data = await ReportsAPI.getGeneratedReports();
      // setGeneratedReports(data);
    } catch (error) {
      console.error('Failed to load generated reports:', error);
    }
  };

  const handleGenerateReport = async () => {
    if (!selectedMemo || !selectedTemplate) {
      toast({
        title: "Validation Error",
        description: "Please select both a memo and template",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const report = await ReportsAPI.generateReport(
        selectedTemplate,
        selectedMemo,
        {
          ...reportParameters,
          generatedBy: user?.username || 'unknown',
          includeAttachments: reportParameters.includeAttachments || false,
          watermark: reportParameters.watermark || '',
          format: reportParameters.format || 'pdf'
        }
      );

      if (report) {
        toast({
          title: "Success",
          description: "Report generated successfully"
        });
        
        // Update memo status to indicate report was generated
        await updateMemoReportStatus(selectedMemo, 'report_generated');
        
        await loadGeneratedReports();
        setShowGenerateDialog(false);
        onReportGenerated?.(report.id);
      } else {
        throw new Error('Failed to generate report');
      }
    } catch (error) {
      console.error('Report generation failed:', error);
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateMemoReportStatus = async (memoId: string, status: string) => {
    try {
      // Status update would be implemented via memo service
    } catch (error) {
      console.error('Failed to update memo status:', error);
    }
  };

  const handleBulkReportGeneration = async () => {
    const selectedMemos = memos.filter(m => m.selected);
    
    if (selectedMemos.length === 0 || !selectedTemplate) {
      toast({
        title: "Validation Error",
        description: "Please select memos and a template for bulk generation",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    let successCount = 0;
    let failureCount = 0;

    try {
      for (const memo of selectedMemos) {
        try {
          const report = await ReportsAPI.generateReport(
            selectedTemplate,
            memo.id,
            {
              generatedBy: user?.username || 'unknown',
              batchId: crypto.randomUUID(),
              isBulkGeneration: true
            }
          );

          if (report) {
            successCount++;
            await updateMemoReportStatus(memo.id, 'report_generated');
          } else {
            failureCount++;
          }
        } catch (error) {
          console.error(`Failed to generate report for memo ${memo.id}:`, error);
          failureCount++;
        }
      }

      toast({
        title: "Bulk Generation Complete",
        description: `Generated ${successCount} reports successfully. ${failureCount} failed.`,
        variant: successCount > 0 ? "default" : "destructive"
      });

      await loadGeneratedReports();
    } catch (error) {
      console.error('Bulk report generation failed:', error);
      toast({
        title: "Error",
        description: "Bulk report generation failed",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMemoSelection = (memoId: string, selected: boolean) => {
    setMemos(prev => prev.map(memo => 
      memo.id === memoId ? { ...memo, selected } : memo
    ));
  };

  const handleSelectAll = (selected: boolean) => {
    setMemos(prev => prev.map(memo => ({ ...memo, selected })));
  };

  const downloadReport = async (reportId: string, fileName: string) => {
    try {
      // This would need to be implemented in ReportsAPI
      toast({
        title: "Info",
        description: "Report download functionality to be implemented",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download report",
        variant: "destructive"
      });
    }
  };

  const selectedMemosCount = memos.filter(m => m.selected).length;

  return (
    <div className="space-y-6">
      {/* Generation Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Memo Report Generation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="template-select">Template</Label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <PermissionWrapper permission="reports.generate">
                <Dialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
                  <DialogTrigger asChild>
                    <Button disabled={!selectedTemplate}>
                      <Play className="h-4 w-4 mr-2" />
                      Generate Single Report
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Generate Report</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="memo-select">Select Memo</Label>
                        <Select value={selectedMemo} onValueChange={setSelectedMemo}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select memo" />
                          </SelectTrigger>
                          <SelectContent>
                            {memos.map((memo) => (
                              <SelectItem key={memo.id} value={memo.id}>
                                {memo.memo_ref} - {memo.title}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="watermark">Watermark (optional)</Label>
                        <Input
                          id="watermark"
                          placeholder="e.g., CONFIDENTIAL"
                          value={reportParameters.watermark || ''}
                          onChange={(e) => setReportParameters(prev => ({ 
                            ...prev, 
                            watermark: e.target.value 
                          }))}
                        />
                      </div>

                      <div>
                        <Label htmlFor="notes">Additional Notes</Label>
                        <Textarea
                          id="notes"
                          placeholder="Add any additional notes for this report"
                          value={reportParameters.notes || ''}
                          onChange={(e) => setReportParameters(prev => ({ 
                            ...prev, 
                            notes: e.target.value 
                          }))}
                        />
                      </div>

                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          onClick={() => setShowGenerateDialog(false)}
                        >
                          Cancel
                        </Button>
                        <Button 
                          onClick={handleGenerateReport}
                          disabled={loading || !selectedMemo}
                        >
                          {loading ? "Generating..." : "Generate Report"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </PermissionWrapper>
            </div>
            <div className="flex items-end">
              <PermissionWrapper permission="reports.bulk_generate">
                <Button 
                  variant="outline"
                  onClick={handleBulkReportGeneration}
                  disabled={selectedMemosCount === 0 || !selectedTemplate || loading}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Bulk Generate ({selectedMemosCount})
                </Button>
              </PermissionWrapper>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Completed Memos */}
      <Card>
        <CardHeader>
          <CardTitle>Completed Memos</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading memos...</div>
          ) : memos.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No completed memos found.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedMemosCount === memos.length && memos.length > 0}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                />
                <Label className="text-sm">Select All ({memos.length} memos)</Label>
              </div>
              
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead>Memo Reference</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Product Type</TableHead>
                    <TableHead>Completed Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {memos.map((memo) => (
                    <TableRow key={memo.id}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={memo.selected || false}
                          onChange={(e) => handleMemoSelection(memo.id, e.target.checked)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{memo.memo_ref}</TableCell>
                      <TableCell>{memo.title}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{memo.product_type}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          {new Date(memo.completed_at || memo.updated_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={memo.status === 'report_generated' ? 'default' : 'secondary'}>
                          {memo.status === 'report_generated' ? 'Report Generated' : 'Ready'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedMemo(memo.id);
                              setShowGenerateDialog(true);
                            }}
                          >
                            <Play className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generated Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recently Generated Reports</CardTitle>
        </CardHeader>
        <CardContent>
          {generatedReports.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No reports generated yet.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report ID</TableHead>
                  <TableHead>Memo Reference</TableHead>
                  <TableHead>Template</TableHead>
                  <TableHead>Generated By</TableHead>
                  <TableHead>Generated At</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {generatedReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-mono text-xs">
                      {report.id.slice(0, 8)}...
                    </TableCell>
                    <TableCell>{report.memo_ref}</TableCell>
                    <TableCell>{report.template_name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        {report.generated_by}
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(report.generated_at).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => downloadReport(report.id, `${report.memo_ref}_report.pdf`)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}