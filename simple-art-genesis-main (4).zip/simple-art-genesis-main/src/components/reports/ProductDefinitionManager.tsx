import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit, Trash2, Settings, Hash } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { ReportsAPI, ReportCategory, ProductDefinition, FieldDefinition } from '@/services/api/reportsAPI';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

const FIELD_TYPES = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'date', label: 'Date' },
  { value: 'select', label: 'Select (Dropdown)' },
  { value: 'textarea', label: 'Text Area' },
  { value: 'boolean', label: 'Yes/No' }
];

export function ProductDefinitionManager() {
  const [categories, setCategories] = useState<ReportCategory[]>([]);
  const [products, setProducts] = useState<ProductDefinition[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductDefinition | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  
  const [formData, setFormData] = useState({
    name: '',
    category_id: '',
    field_definitions: [] as FieldDefinition[]
  });

  const [newField, setNewField] = useState({
    name: '',
    token: '',
    type: 'text' as FieldDefinition['type'],
    required: false,
    options: ''
  });

  const { toast } = useToast();
  const { user } = useUser();

  useEffect(() => {
    loadCategories();
    loadProducts();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      loadProducts(selectedCategory);
    } else {
      loadProducts();
    }
  }, [selectedCategory]);

  const loadCategories = async () => {
    try {
      const data = await ReportsAPI.getCategories();
      setCategories(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load categories",
        variant: "destructive"
      });
    }
  };

  const loadProducts = async (categoryId?: string) => {
    setLoading(true);
    try {
      const data = await ReportsAPI.getProductDefinitions(categoryId);
      setProducts(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load product definitions",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const generateToken = (name: string) => {
    return `{{${name.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')}}}`;
  };

  const addField = () => {
    if (!newField.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Field name is required",
        variant: "destructive"
      });
      return;
    }

    const field: FieldDefinition = {
      id: crypto.randomUUID(),
      name: newField.name,
      token: newField.token || generateToken(newField.name),
      type: newField.type,
      required: newField.required,
      options: newField.type === 'select' ? newField.options.split(',').map(opt => opt.trim()).filter(Boolean) : undefined
    };

    setFormData(prev => ({
      ...prev,
      field_definitions: [...prev.field_definitions, field]
    }));

    setNewField({
      name: '',
      token: '',
      type: 'text',
      required: false,
      options: ''
    });
  };

  const removeField = (fieldId: string) => {
    setFormData(prev => ({
      ...prev,
      field_definitions: prev.field_definitions.filter(f => f.id !== fieldId)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.category_id) {
      toast({
        title: "Validation Error",
        description: "Product name and category are required",
        variant: "destructive"
      });
      return;
    }

    if (formData.field_definitions.length === 0) {
      toast({
        title: "Validation Error",
        description: "At least one field definition is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const productData = {
        name: formData.name,
        category_id: formData.category_id,
        field_definitions: formData.field_definitions,
        created_by: user?.username || 'unknown',
        is_active: true
      };

      const result = await ReportsAPI.createProductDefinition(productData);
      
      if (result) {
        toast({
          title: "Success",
          description: "Product definition created successfully"
        });
        
        await loadProducts(selectedCategory);
        resetForm();
      } else {
        throw new Error('Failed to create product definition');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create product definition",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category_id: '',
      field_definitions: []
    });
    setNewField({
      name: '',
      token: '',
      type: 'text',
      required: false,
      options: ''
    });
    setEditingProduct(null);
    setShowCreateDialog(false);
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="w-64">
              <Label htmlFor="category-filter">Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Product Definitions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Product Definitions
          </CardTitle>
          <PermissionWrapper permission="reports.manage_products">
            <Dialog open={showCreateDialog} onOpenChange={(open) => {
              if (!open) resetForm();
              setShowCreateDialog(open);
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingProduct ? 'Edit Product Definition' : 'Create New Product Definition'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="product-name">Product Name</Label>
                      <Input
                        id="product-name"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter product name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="product-category">Category</Label>
                      <Select 
                        value={formData.category_id} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, category_id: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Field Definitions */}
                  <div>
                    <Label className="text-base font-semibold">Field Definitions</Label>
                    
                    {/* Add New Field */}
                    <Card className="mt-2">
                      <CardHeader>
                        <CardTitle className="text-sm">Add Field</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="field-name">Field Name</Label>
                            <Input
                              id="field-name"
                              value={newField.name}
                              onChange={(e) => {
                                const name = e.target.value;
                                setNewField(prev => ({ 
                                  ...prev, 
                                  name,
                                  token: generateToken(name)
                                }));
                              }}
                              placeholder="e.g., Date of Test"
                            />
                          </div>
                          <div>
                            <Label htmlFor="field-token">Token</Label>
                            <Input
                              id="field-token"
                              value={newField.token}
                              onChange={(e) => setNewField(prev => ({ ...prev, token: e.target.value }))}
                              placeholder="e.g., {{date_of_test}}"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="field-type">Field Type</Label>
                            <Select 
                              value={newField.type} 
                              onValueChange={(value: FieldDefinition['type']) => setNewField(prev => ({ ...prev, type: value }))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {FIELD_TYPES.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2 pt-6">
                            <Checkbox
                              id="field-required"
                              checked={newField.required}
                              onCheckedChange={(checked) => setNewField(prev => ({ ...prev, required: !!checked }))}
                            />
                            <Label htmlFor="field-required">Required</Label>
                          </div>
                        </div>
                        {newField.type === 'select' && (
                          <div>
                            <Label htmlFor="field-options">Options (comma-separated)</Label>
                            <Input
                              id="field-options"
                              value={newField.options}
                              onChange={(e) => setNewField(prev => ({ ...prev, options: e.target.value }))}
                              placeholder="Option 1, Option 2, Option 3"
                            />
                          </div>
                        )}
                        <Button type="button" onClick={addField} variant="outline">
                          <Plus className="h-4 w-4 mr-2" />
                          Add Field
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Field List */}
                    {formData.field_definitions.length > 0 && (
                      <div className="mt-4">
                        <Label className="text-sm font-medium">Defined Fields</Label>
                        <div className="mt-2 space-y-2">
                          {formData.field_definitions.map((field) => (
                            <div key={field.id} className="flex items-center justify-between p-3 border rounded-md">
                              <div className="flex items-center gap-4">
                                <div>
                                  <div className="font-medium">{field.name}</div>
                                  <div className="text-sm text-muted-foreground">{field.token}</div>
                                </div>
                                <Badge variant="outline">{field.type}</Badge>
                                {field.required && (
                                  <Badge variant="destructive" className="text-xs">Required</Badge>
                                )}
                              </div>
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => removeField(field.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingProduct ? 'Update' : 'Create'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </PermissionWrapper>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading product definitions...</div>
          ) : products.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No product definitions found. Create your first product definition to get started.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Fields</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>
                      {categories.find(c => c.id === product.category_id)?.name || 'Unknown'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Hash className="h-4 w-4" />
                        {product.field_definitions.length} fields
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={product.is_active ? 'default' : 'secondary'}>
                        {product.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>{product.created_by}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <PermissionWrapper permission="reports.manage_products">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              // Handle edit
                              toast({
                                title: "Info",
                                description: "Edit functionality not yet implemented",
                                variant: "default"
                              });
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              // Handle delete
                              toast({
                                title: "Info",
                                description: "Delete functionality not yet implemented",
                                variant: "default"
                              });
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </PermissionWrapper>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}