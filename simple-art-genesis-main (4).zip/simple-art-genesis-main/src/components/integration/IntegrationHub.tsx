import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Zap, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RotateCcw, 
  Settings, 
  Calendar,
  Chrome,
  Calendar as CalendarIcon,
  Building,
  Clock,
  RefreshCcw
} from 'lucide-react';
import { format } from 'date-fns';
import { crossModuleIntegrationService, type ModuleIntegration } from '@/services/integration/crossModuleIntegrationService';
import { externalCalendarService, type CalendarProvider, type CalendarSyncConfig } from '@/services/calendar/externalCalendarService';
import { toast } from '@/hooks/use-toast';

export function IntegrationHub() {
  const [activeTab, setActiveTab] = useState('modules');
  const [integrations, setIntegrations] = useState<ModuleIntegration[]>([]);
  const [calendarProviders, setCalendarProviders] = useState<CalendarProvider[]>([]);
  const [calendarConfig, setCalendarConfig] = useState<CalendarSyncConfig>({
    autoSync: true,
    syncInterval: 30,
    conflictResolution: 'lims_priority',
    syncDirection: 'bidirectional',
    eventPrefix: '[LIMS]'
  });
  const [loading, setLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string>('');

  useEffect(() => {
    loadIntegrations();
    loadCalendarProviders();
    loadCalendarConfig();
  }, []);

  const loadIntegrations = async () => {
    try {
      const data = await crossModuleIntegrationService.getIntegrationStatus();
      setIntegrations(data);
    } catch (error) {
      console.error('Error loading integrations:', error);
    }
  };

  const loadCalendarProviders = async () => {
    try {
      const providers = externalCalendarService.getProviders();
      setCalendarProviders(providers);
    } catch (error) {
      console.error('Error loading calendar providers:', error);
    }
  };

  const loadCalendarConfig = async () => {
    try {
      const config = externalCalendarService.getConfiguration();
      setCalendarConfig(config);
    } catch (error) {
      console.error('Error loading calendar config:', error);
    }
  };

  const handleSyncAllModules = async () => {
    setLoading(true);
    setSyncStatus('Syncing all modules...');
    
    try {
      const results = await crossModuleIntegrationService.syncAllModules();
      
      const totalUpdated = Object.values(results).reduce((sum, result) => sum + result.recordsUpdated, 0);
      const successCount = Object.values(results).filter(result => result.success).length;
      
      setSyncStatus(`Sync complete: ${successCount}/${Object.keys(results).length} modules, ${totalUpdated} records updated`);
      await loadIntegrations();
      
      toast({
        title: 'Sync Complete',
        description: `Updated ${totalUpdated} records across ${successCount} modules`,
      });
    } catch (error) {
      console.error('Error syncing modules:', error);
      setSyncStatus('Sync failed');
      toast({
        title: 'Sync Failed',
        description: 'Error syncing modules. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConnectCalendar = async (providerId: string) => {
    try {
      // In real implementation, this would open OAuth flow
      const mockCredentials = {
        accessToken: 'mock_token',
        refreshToken: 'mock_refresh',
        calendarId: 'primary'
      };
      
      const success = await externalCalendarService.connectProvider(providerId, mockCredentials);
      if (success) {
        await loadCalendarProviders();
      }
    } catch (error) {
      console.error('Error connecting calendar:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect calendar. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleDisconnectCalendar = async (providerId: string) => {
    try {
      await externalCalendarService.disconnectProvider(providerId);
      await loadCalendarProviders();
    } catch (error) {
      console.error('Error disconnecting calendar:', error);
    }
  };

  const handleSyncCalendars = async () => {
    setLoading(true);
    try {
      const result = await externalCalendarService.syncEvents();
      toast({
        title: 'Calendar Sync Complete',
        description: `Imported ${result.imported}, exported ${result.exported} events. ${result.conflicts} conflicts detected.`,
      });
    } catch (error) {
      console.error('Error syncing calendars:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateCalendarConfig = async () => {
    try {
      await externalCalendarService.updateConfiguration(calendarConfig);
      toast({
        title: 'Configuration Updated',
        description: 'Calendar sync settings have been saved.',
      });
    } catch (error) {
      console.error('Error updating config:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
      case 'connected':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'inactive':
      case 'disconnected':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-400" />;
    }
  };

  const getProviderIcon = (type: string) => {
    switch (type) {
      case 'google':
        return <Chrome className="h-4 w-4" />;
      case 'outlook':
      case 'exchange':
        return <Building className="h-4 w-4" />;
      default:
        return <CalendarIcon className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Integration Hub</h2>
        <p className="text-muted-foreground">
          Manage cross-module integrations and external calendar synchronization
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="modules" className="gap-2">
            <Zap className="h-4 w-4" />
            Modules
          </TabsTrigger>
          <TabsTrigger value="calendars" className="gap-2">
            <Calendar className="h-4 w-4" />
            Calendars
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2">
            <Settings className="h-4 w-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="modules" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Cross-Module Integration
                  </CardTitle>
                  <CardDescription>
                    Real-time data synchronization between dashboard and other modules
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    onClick={handleSyncAllModules} 
                    disabled={loading}
                    className="gap-2"
                  >
                    <RotateCcw className="h-4 w-4" />
                    {loading ? 'Syncing...' : 'Sync All'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {syncStatus && (
                <Alert className="mb-4">
                  <AlertDescription>{syncStatus}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                {integrations.map((integration) => (
                  <div
                    key={integration.moduleId}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getStatusIcon(integration.status)}
                      <div>
                        <div className="font-medium">{integration.name}</div>
                        <div className="text-sm text-muted-foreground">
                          v{integration.version} • {integration.dataEndpoints.length} endpoints
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={integration.status === 'active' ? 'default' : 'secondary'}>
                        {integration.status}
                      </Badge>
                      {integration.lastSync && (
                        <div className="text-xs text-muted-foreground">
                          Last sync: {format(new Date(integration.lastSync), 'MMM dd, HH:mm')}
                        </div>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => crossModuleIntegrationService.syncModule(integration.moduleId)}
                      >
                        <RefreshCcw className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendars" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    External Calendar Integration
                  </CardTitle>
                  <CardDescription>
                    Connect with Google Calendar, Outlook, or Exchange
                  </CardDescription>
                </div>
                <Button 
                  onClick={handleSyncCalendars} 
                  disabled={loading}
                  className="gap-2"
                >
                  <RotateCcw className="h-4 w-4" />
                  Sync Now
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {calendarProviders.map((provider) => (
                  <div
                    key={provider.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getProviderIcon(provider.type)}
                      <div>
                        <div className="font-medium">{provider.name}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-2">
                          {getStatusIcon(provider.status)}
                          {provider.status}
                          {provider.lastSync && (
                            <>
                              • Last sync: {format(new Date(provider.lastSync), 'MMM dd, HH:mm')}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div>
                      {provider.status === 'connected' ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDisconnectCalendar(provider.id)}
                        >
                          Disconnect
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleConnectCalendar(provider.id)}
                        >
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Calendar Sync Settings
              </CardTitle>
              <CardDescription>
                Configure how calendar events are synchronized
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Auto Sync</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically sync calendar events
                  </p>
                </div>
                <Switch
                  checked={calendarConfig.autoSync}
                  onCheckedChange={(checked) => 
                    setCalendarConfig(prev => ({ ...prev, autoSync: checked }))
                  }
                />
              </div>

              <Separator />

              <div>
                <Label htmlFor="sync-interval">Sync Interval (minutes)</Label>
                <Select 
                  value={calendarConfig.syncInterval.toString()} 
                  onValueChange={(value) => 
                    setCalendarConfig(prev => ({ ...prev, syncInterval: Number(value) }))
                  }
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="240">4 hours</SelectItem>
                    <SelectItem value="1440">24 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="sync-direction">Sync Direction</Label>
                <Select 
                  value={calendarConfig.syncDirection} 
                  onValueChange={(value: any) => 
                    setCalendarConfig(prev => ({ ...prev, syncDirection: value }))
                  }
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bidirectional">Bidirectional</SelectItem>
                    <SelectItem value="lims_to_external">LIMS to External Only</SelectItem>
                    <SelectItem value="external_to_lims">External to LIMS Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="conflict-resolution">Conflict Resolution</Label>
                <Select 
                  value={calendarConfig.conflictResolution} 
                  onValueChange={(value: any) => 
                    setCalendarConfig(prev => ({ ...prev, conflictResolution: value }))
                  }
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lims_priority">LIMS Priority</SelectItem>
                    <SelectItem value="external_priority">External Priority</SelectItem>
                    <SelectItem value="manual">Manual Resolution</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="event-prefix">Event Prefix</Label>
                <Input
                  id="event-prefix"
                  value={calendarConfig.eventPrefix}
                  onChange={(e) => 
                    setCalendarConfig(prev => ({ ...prev, eventPrefix: e.target.value }))
                  }
                  placeholder="[LIMS]"
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Prefix added to LIMS events in external calendars
                </p>
              </div>

              <Button onClick={handleUpdateCalendarConfig} className="w-full">
                Save Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}