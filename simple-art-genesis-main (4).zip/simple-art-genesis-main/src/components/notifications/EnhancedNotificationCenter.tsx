import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Bell, 
  BellRing, 
  Check, 
  X, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  XCircle, 
  Trash2,
  FileText,
  Calendar,
  Users,
  Settings,
  Clock,
  Filter,
  Volume2,
  Download,
  Timer,
  ExternalLink
} from 'lucide-react';
import { localNotificationService, LocalNotification } from '@/services/notifications/localNotificationService';
import { NotificationPreferencesPanel } from '@/components/notifications/NotificationPreferencesPanel';
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface NotificationCenterProps {
  className?: string;
}

type NotificationCategory = 'all' | 'system' | 'tests' | 'memos' | 'reports' | 'users';

export function EnhancedNotificationCenter({ className }: NotificationCenterProps) {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<LocalNotification[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState<NotificationCategory>('all');
  const [showPreferences, setShowPreferences] = useState(false);
  const [bellAnimation, setBellAnimation] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadNotifications();

    // Subscribe to notification updates
    const unsubscribe = localNotificationService.subscribe((updatedNotifications) => {
      const newNotifications = updatedNotifications.filter(n => !n.read);
      if (newNotifications.length > 0) {
        setBellAnimation(true);
        setTimeout(() => setBellAnimation(false), 1000);
      }
      setNotifications(updatedNotifications);
    });

    // Listen for custom toast events
    const handleToastEvent = (event: any) => {
      const { title, message, type } = event.detail;
      toast({
        title,
        description: message,
        variant: type === 'error' ? 'destructive' : 'default'
      });
    };

    window.addEventListener('show-toast', handleToastEvent);

    return () => {
      unsubscribe();
      window.removeEventListener('show-toast', handleToastEvent);
    };
  }, [toast]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const data = await localNotificationService.getNotifications({ limit: 100 });
      setNotifications(data);
    } catch (error) {
      console.error('Error loading notifications:', error);
      toast({
        title: "Error",
        description: "Failed to load notifications",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: string) => {
    await localNotificationService.markAsRead(id);
  };

  const handleMarkAllAsRead = async () => {
    await localNotificationService.markAllRead();
    toast({
      title: "Marked as Read",
      description: "All notifications marked as read"
    });
  };

  const handleDeleteNotification = async (id: string) => {
    await localNotificationService.deleteNotification(id);
    toast({
      title: "Deleted",
      description: "Notification deleted"
    });
  };

  const handleClearOld = async () => {
    await localNotificationService.deleteOldNotifications(30);
    toast({
      title: "Cleaned Up",
      description: "Old notifications cleared"
    });
  };

  const handleSnoozeNotification = async (id: string, duration: string) => {
    const snoozeUntil = new Date();
    switch (duration) {
      case '10m':
        snoozeUntil.setMinutes(snoozeUntil.getMinutes() + 10);
        break;
      case '1h':
        snoozeUntil.setHours(snoozeUntil.getHours() + 1);
        break;
      case 'tomorrow':
        snoozeUntil.setDate(snoozeUntil.getDate() + 1);
        snoozeUntil.setHours(9, 0, 0, 0); // 9 AM tomorrow
        break;
      default:
        return;
    }

    await localNotificationService.snoozeNotification(id, snoozeUntil.toISOString());
    toast({
      title: "Snoozed",
      description: `Notification snoozed until ${snoozeUntil.toLocaleString()}`
    });
  };

  const handleNotificationAction = async (notification: LocalNotification) => {
    // Mark as read when clicked
    if (!notification.read) {
      await handleMarkAsRead(notification.id);
    }

    // Navigate to action URL or default location
    setOpen(false);
    if (notification.action_url) {
      navigate(notification.action_url);
    } else {
      // Default navigation based on category and linked_id
      switch (notification.category) {
        case 'memos':
          navigate(`/test-requests${notification.linked_id ? `?memo=${notification.linked_id}` : ''}`);
          break;
        case 'tests':
          navigate(`/test-calendar${notification.linked_id ? `?test=${notification.linked_id}` : ''}`);
          break;
        case 'reports':
          navigate('/reports');
          break;
        case 'users':
          navigate('/users');
          break;
        default:
          navigate('/dashboard');
      }
    }
  };

  const exportNotifications = async () => {
    try {
      const csvContent = [
        'Timestamp,Title,Message,Category,Read,Priority',
        ...notifications.map(n => 
          `"${n.timestamp}","${n.title}","${n.message}","${n.category}","${n.read ? 'Yes' : 'No'}","${n.priority}"`
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `notifications-${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
      
      toast({
        title: "Export Complete",
        description: "Notifications exported to CSV"
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export notifications",
        variant: "destructive"
      });
    }
  };

  const getNotificationIcon = (category: string, type: string) => {
    if (type === 'success') return CheckCircle;
    if (type === 'warning') return AlertTriangle;
    if (type === 'error') return XCircle;
    
    switch (category) {
      case 'tests': return Calendar;
      case 'memos': return FileText;
      case 'reports': return FileText;
      case 'users': return Users;
      default: return Info;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'error': return 'text-red-600';
      default: return 'text-blue-600';
    }
  };

  const getCategoryIcon = (category: NotificationCategory) => {
    switch (category) {
      case 'system': return Settings;
      case 'tests': return Calendar;
      case 'memos': return FileText;
      case 'reports': return FileText;
      case 'users': return Users;
      default: return Bell;
    }
  };

  const filteredNotifications = notifications.filter(notification => 
    activeCategory === 'all' || notification.category === activeCategory
  );

  const unreadCount = notifications.filter(n => !n.read).length;
  const hasUnread = unreadCount > 0;

  const categoryCounts = {
    all: notifications.length,
    system: notifications.filter(n => n.category === 'system').length,
    tests: notifications.filter(n => n.category === 'tests').length,
    memos: notifications.filter(n => n.category === 'memos').length,
    reports: notifications.filter(n => n.category === 'reports').length,
    users: notifications.filter(n => n.category === 'users').length,
  };

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="sm" className={`relative ${className} ${bellAnimation ? 'animate-bounce' : ''}`}>
            {hasUnread ? (
              <BellRing className="h-5 w-5" />
            ) : (
              <Bell className="h-5 w-5" />
            )}
            {hasUnread && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs animate-pulse"
              >
                {unreadCount > 99 ? '99+' : unreadCount}
              </Badge>
            )}
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notifications
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => setShowPreferences(true)}>
                  <Settings className="h-4 w-4 mr-1" />
                  Preferences
                </Button>
                <Button variant="ghost" size="sm" onClick={exportNotifications}>
                  <Download className="h-4 w-4 mr-1" />
                  Export CSV
                </Button>
                {hasUnread && (
                  <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead}>
                    <Check className="h-4 w-4 mr-1" />
                    Mark all read
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={handleClearOld}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Clear old
                </Button>
              </div>
            </DialogTitle>
            <DialogDescription>
              {notifications.length === 0 
                ? 'No notifications yet'
                : `${notifications.length} notification${notifications.length !== 1 ? 's' : ''} ${hasUnread ? `(${unreadCount} unread)` : ''}`
              }
            </DialogDescription>
          </DialogHeader>

          <Tabs value={activeCategory} onValueChange={(value) => setActiveCategory(value as NotificationCategory)}>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all" className="flex items-center gap-1">
                <Filter className="h-3 w-3" />
                All ({categoryCounts.all})
              </TabsTrigger>
              <TabsTrigger value="system" className="flex items-center gap-1">
                <Settings className="h-3 w-3" />
                System ({categoryCounts.system})
              </TabsTrigger>
              <TabsTrigger value="tests" className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                Tests ({categoryCounts.tests})
              </TabsTrigger>
              <TabsTrigger value="memos" className="flex items-center gap-1">
                <FileText className="h-3 w-3" />
                Memos ({categoryCounts.memos})
              </TabsTrigger>
              <TabsTrigger value="reports" className="flex items-center gap-1">
                <FileText className="h-3 w-3" />
                Reports ({categoryCounts.reports})
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                Users ({categoryCounts.users})
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeCategory} className="mt-4">
              <ScrollArea className="max-h-96">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                  </div>
                ) : filteredNotifications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No notifications in this category</p>
                    <p className="text-sm">You're all caught up!</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredNotifications.map((notification) => {
                      const Icon = getNotificationIcon(notification.category, notification.type);
                      const iconColor = getNotificationColor(notification.type);
                      
                      return (
                        <Card 
                          key={notification.id} 
                          className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                            notification.read 
                              ? 'bg-muted/30' 
                              : 'bg-background border-l-4 border-l-primary'
                          }`}
                          onClick={() => handleNotificationAction(notification)}
                        >
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-start gap-2 flex-1">
                                <Icon className={`h-4 w-4 mt-0.5 ${iconColor}`} />
                                <div className="flex-1 min-w-0">
                                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                                    {notification.title}
                                    {!notification.read && (
                                      <Badge variant="destructive" className="text-xs">
                                        New
                                      </Badge>
                                    )}
                                    {notification.priority === 'high' && (
                                      <Badge variant="outline" className="text-xs">
                                        High Priority
                                      </Badge>
                                    )}
                                    {notification.priority === 'critical' && (
                                      <Badge variant="destructive" className="text-xs">
                                        Critical
                                      </Badge>
                                    )}
                                  </CardTitle>
                                  <CardDescription className="text-xs flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                                  </CardDescription>
                                </div>
                              </div>
                              <div className="flex items-center gap-1">
                                {!notification.read && (
                                  <>
                                    <Select onValueChange={(value) => handleSnoozeNotification(notification.id, value)}>
                                      <SelectTrigger className="h-6 w-6 p-0 border-none">
                                        <Timer className="h-3 w-3" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="10m">10 minutes</SelectItem>
                                        <SelectItem value="1h">1 hour</SelectItem>
                                        <SelectItem value="tomorrow">Tomorrow</SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleMarkAsRead(notification.id);
                                      }}
                                      className="h-6 w-6 p-0"
                                    >
                                      <Check className="h-3 w-3" />
                                    </Button>
                                  </>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteNotification(notification.id);
                                  }}
                                  className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <p className="text-sm text-muted-foreground">
                              {notification.message}
                            </p>
                            <div className="flex items-center justify-between mt-2">
                              <Badge variant="secondary" className="text-xs">
                                {notification.category}
                              </Badge>
                              {(notification.action_url || notification.linked_id) && (
                                <Button 
                                  variant="link" 
                                  size="sm" 
                                  className="p-0 h-auto text-primary"
                                >
                                  <ExternalLink className="h-3 w-3 mr-1" />
                                  View Details
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      <NotificationPreferencesPanel 
        open={showPreferences}
        onOpenChange={setShowPreferences}
      />
    </>
  );
}