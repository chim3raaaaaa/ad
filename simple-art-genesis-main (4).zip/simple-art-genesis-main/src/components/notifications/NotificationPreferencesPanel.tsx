import React, { useState, useEffect } from 'react';
import { Settings, Volume2, VolumeX, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { localNotificationService, NotificationSettings } from '@/services/notifications/localNotificationService';

interface NotificationPreferencesPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const NotificationPreferencesPanel = ({
  open,
  onOpenChange
}: NotificationPreferencesPanelProps) => {
  const [settings, setSettings] = useState<NotificationSettings[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const categories = [
    { id: 'system', name: 'System', description: 'App updates, errors, and maintenance' },
    { id: 'tests', name: 'Tests', description: 'Test schedules, due dates, and results' },
    { id: 'memos', name: 'Memos', description: 'Memo creation, updates, and approvals' },
    { id: 'reports', name: 'Reports', description: 'Report generation and status updates' },
    { id: 'users', name: 'Users', description: 'User account and permission changes' },
  ];

  useEffect(() => {
    if (open) {
      loadSettings();
    }
  }, [open]);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const result = await localNotificationService.getNotificationSettings('default_user');
      if (Array.isArray(result)) {
        setSettings(result);
      } else {
        setSettings([]);
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
      toast({
        title: "Error",
        description: "Failed to load notification preferences",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSettingChange = (category: string, key: 'receive' | 'play_sound' | 'toast_enabled', value: boolean) => {
    setSettings(prev => 
      prev.map(setting => 
        setting.category === category 
          ? { ...setting, [key]: value ? 1 : 0 }
          : setting
      )
    );
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      for (const setting of settings) {
        await localNotificationService.updateNotificationSettings('default_user', setting.category, {
          receive: Boolean(setting.receive),
          play_sound: Boolean(setting.play_sound),
          toast_enabled: Boolean(setting.toast_enabled)
        });
      }

      toast({
        title: "Preferences Saved",
        description: "Your notification preferences have been updated",
      });
    } catch (error) {
      console.error('Error saving notification settings:', error);
      toast({
        title: "Error",
        description: "Failed to save notification preferences",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const getSettingForCategory = (category: string) => {
    return settings.find(s => s.category === category) || {
      id: '',
      user_id: 'default_user',
      category,
      receive: 1,
      play_sound: 1,
      toast_enabled: 1,
      created_at: '',
      updated_at: ''
    };
  };

  const testNotification = async (category: string) => {
    try {
      await localNotificationService.addNotification({
        title: 'Test Notification',
        message: `This is a test notification for the ${category} category`,
        category: category as any,
        type: 'info',
        priority: 'normal'
      });
      
      toast({
        title: "Test Sent",
        description: `Test notification sent for ${category} category`,
      });
    } catch (error) {
      console.error('Error sending test notification:', error);
      toast({
        title: "Error",
        description: "Failed to send test notification",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-2xl">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Notification Preferences
          </DialogTitle>
          <DialogDescription>
            Customize how and when you receive notifications
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {categories.map((category) => {
            const setting = getSettingForCategory(category.id);
            
            return (
              <Card key={category.id}>
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base flex items-center gap-2">
                        {category.name}
                        <Badge variant="outline" className="text-xs">
                          {setting.receive ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </CardTitle>
                      <CardDescription className="text-sm">
                        {category.description}
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testNotification(category.id)}
                    >
                      Test
                    </Button>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Receive Notifications */}
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor={`receive-${category.id}`} className="text-sm font-medium">
                        Receive Notifications
                      </Label>
                      <Switch
                        id={`receive-${category.id}`}
                        checked={Boolean(setting.receive)}
                        onCheckedChange={(checked) => 
                          handleSettingChange(category.id, 'receive', checked)
                        }
                      />
                    </div>

                    {/* Play Sound */}
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor={`sound-${category.id}`} className="text-sm font-medium flex items-center gap-1">
                        {setting.play_sound ? <Volume2 className="h-3 w-3" /> : <VolumeX className="h-3 w-3" />}
                        Sound
                      </Label>
                      <Switch
                        id={`sound-${category.id}`}
                        checked={Boolean(setting.play_sound)}
                        onCheckedChange={(checked) => 
                          handleSettingChange(category.id, 'play_sound', checked)
                        }
                        disabled={!setting.receive}
                      />
                    </div>

                    {/* Toast Notifications */}
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor={`toast-${category.id}`} className="text-sm font-medium">
                        Toast Popup
                      </Label>
                      <Switch
                        id={`toast-${category.id}`}
                        checked={Boolean(setting.toast_enabled)}
                        onCheckedChange={(checked) => 
                          handleSettingChange(category.id, 'toast_enabled', checked)
                        }
                        disabled={!setting.receive}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Changes will apply to new notifications
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={saveSettings}
              disabled={saving}
            >
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'Saving...' : 'Save Preferences'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};