import React, { useState } from 'react';
import { useEnhancedNotifications } from '@/hooks/useEnhancedNotifications';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';
import { NotificationPreferencesPanel } from './NotificationPreferencesPanel';
import { 
  Bell, 
  Check, 
  Trash2, 
  Archive, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  XCircle,
  Clock,
  Users,
  FileText,
  Settings,
  Calendar,
  Wifi,
  WifiOff
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

type NotificationCategory = 'all' | 'system' | 'tests' | 'memos' | 'reports' | 'users';

export function NotificationPageContent() {
  const {
    notifications,
    loading,
    error,
    unreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearOldNotifications,
    getByCategory
  } = useEnhancedNotifications();

  const [activeCategory, setActiveCategory] = useState<NotificationCategory>('all');
  const [showPreferences, setShowPreferences] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { hasPermission } = useUser();

  // Check if we're in Electron environment
  const isElectronAvailable = typeof window !== 'undefined' && window.electronAPI;
  const isOffline = !navigator.onLine;

  const getNotificationIcon = (category: string, type: string) => {
    if (category === 'system') return <Settings className="h-4 w-4" />;
    if (category === 'tests') return <Calendar className="h-4 w-4" />;
    if (category === 'memos') return <FileText className="h-4 w-4" />;
    if (category === 'reports') return <FileText className="h-4 w-4" />;
    if (category === 'users') return <Users className="h-4 w-4" />;
    
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4" />;
      case 'error': return <XCircle className="h-4 w-4" />;
      case 'warning': return <AlertTriangle className="h-4 w-4" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  const getNotificationColor = (type: string, read: boolean) => {
    const opacity = read ? 'opacity-60' : '';
    switch (type) {
      case 'success': return `text-green-600 ${opacity}`;
      case 'error': return `text-red-600 ${opacity}`;
      case 'warning': return `text-yellow-600 ${opacity}`;
      default: return `text-blue-600 ${opacity}`;
    }
  };

  const handleNotificationAction = async (notification: any) => {
    if (!notification.read) {
      await markAsRead(notification.id);
    }
    
    // Use enhanced navigation service for better routing
    const { NotificationNavigationService } = await import('@/services/notifications/notificationNavigationService');
    const navigationUrl = NotificationNavigationService.getNavigationUrl(notification);
    navigate(navigationUrl);
  };

  const handleMarkAllAsRead = async () => {
    await markAllAsRead();
    toast({
      title: "Success",
      description: "All notifications marked as read",
    });
  };

  const handleClearOld = async () => {
    await clearOldNotifications();
    toast({
      title: "Success",
      description: "Old notifications cleared",
    });
  };

  const filteredNotifications = activeCategory === 'all' 
    ? notifications 
    : getByCategory(activeCategory);

  const categoryItems = [
    { key: 'all', label: 'All', count: notifications.length },
    { key: 'system', label: 'System', count: getByCategory('system').length },
    { key: 'tests', label: 'Tests', count: getByCategory('tests').length },
    { key: 'memos', label: 'Memos', count: getByCategory('memos').length },
    { key: 'reports', label: 'Reports', count: getByCategory('reports').length },
    { key: 'users', label: 'Users', count: getByCategory('users').length },
  ];

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-lg font-medium">Error loading notifications</p>
          <p className="text-sm text-muted-foreground mb-4">{error}</p>
          <Button 
            onClick={() => window.location.reload()}
            variant="outline"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  // Show connection status if not in Electron and offline
  if (!isElectronAvailable && isOffline) {
    return (
      <div className="space-y-6">
        <Alert variant="destructive">
          <WifiOff className="h-4 w-4" />
          <AlertDescription>
            You're currently offline. Notifications require an internet connection when running in web mode.
            Please check your connection and try again.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Show limited functionality warning if not in Electron
  if (!isElectronAvailable) {
    return (
      <div className="space-y-6">
        <Alert>
          <Wifi className="h-4 w-4" />
          <AlertDescription>
            Running in web mode. Some notification features may be limited. 
            For full functionality, please use the desktop application.
          </AlertDescription>
        </Alert>
        {/* Render the rest of the component with limited functionality */}
        {renderNotificationContent()}
      </div>
    );
  }

  return renderNotificationContent();

  function renderNotificationContent() {

  return (
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            <span className="text-lg font-semibold">Notifications</span>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-2">
                {unreadCount} unread
              </Badge>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowPreferences(true)}
            >
              <Settings className="h-4 w-4 mr-2" />
              Preferences
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleMarkAllAsRead}
              disabled={unreadCount === 0}
            >
              <Check className="h-4 w-4 mr-2" />
              Mark All Read
            </Button>
            <PermissionWrapper permission="notifications:delete">
              <Button
                variant="outline"
                size="sm"
                onClick={handleClearOld}
                disabled={notifications.length === 0}
              >
                <Archive className="h-4 w-4 mr-2" />
                Clear Old
              </Button>
            </PermissionWrapper>
          </div>
        </div>

      {/* Notification Tabs */}
      <Tabs value={activeCategory} onValueChange={(value) => setActiveCategory(value as NotificationCategory)}>
        <TabsList className="grid w-full grid-cols-6">
          {categoryItems.map((item) => (
            <TabsTrigger key={item.key} value={item.key} className="relative">
              {item.label}
              {item.count > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 px-1 text-xs">
                  {item.count}
                </Badge>
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        {categoryItems.map((category) => (
          <TabsContent key={category.key} value={category.key} className="mt-6">
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {loading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <Card key={i}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-full" />
                            <Skeleton className="h-3 w-1/2" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : filteredNotifications.length === 0 ? (
                  <div className="text-center py-12">
                    <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-lg font-medium">No notifications</p>
                    <p className="text-sm text-muted-foreground">
                      {activeCategory === 'all' 
                        ? "You're all caught up!" 
                        : `No ${activeCategory} notifications`}
                    </p>
                  </div>
                ) : (
                  filteredNotifications.map((notification) => (
                    <Card 
                      key={notification.id} 
                      className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                        !notification.read ? 'border-primary/50 bg-primary/5' : ''
                      }`}
                      onClick={() => handleNotificationAction(notification)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={getNotificationColor(notification.type, notification.read)}>
                            {getNotificationIcon(notification.category, notification.type)}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <h4 className={`font-medium ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                                  {notification.title}
                                </h4>
                                <p className={`text-sm mt-1 ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                                  {notification.message}
                                </p>
                              </div>
                              
                              <div className="flex items-center gap-2">
                                {!notification.read && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      markAsRead(notification.id);
                                    }}
                                    className="h-8 w-8 p-0"
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                )}
                                <PermissionWrapper permission="notifications:delete">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      deleteNotification(notification.id);
                                    }}
                                    className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </PermissionWrapper>
                              </div>
                            </div>
                            
                            <div className="flex items-center justify-between mt-2">
                              <Badge variant="outline" className="text-xs">
                                {notification.category}
                              </Badge>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        ))}
        </Tabs>

        {/* Notification Preferences Panel */}
        <NotificationPreferencesPanel 
          open={showPreferences}
          onOpenChange={setShowPreferences}
        />
      </div>
    );
  }
}