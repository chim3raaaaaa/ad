import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Plus, Upload, Database } from 'lucide-react';

interface EmptyStateProps {
  icon?: React.ElementType;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline';
  };
  secondaryAction?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'outline';
  };
}

export function EmptyState({ 
  icon: Icon = FileText, 
  title, 
  description, 
  action, 
  secondaryAction 
}: EmptyStateProps) {
  return (
    <Card className="border-dashed">
      <CardContent className="flex flex-col items-center justify-center py-12 text-center">
        <div className="rounded-full bg-muted p-3 mb-4">
          <Icon className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground mb-6 max-w-md">{description}</p>
        <div className="flex gap-2">
          {action && (
            <Button onClick={action.onClick} variant={action.variant || 'default'}>
              <Plus className="h-4 w-4 mr-2" />
              {action.label}
            </Button>
          )}
          {secondaryAction && (
            <Button onClick={secondaryAction.onClick} variant={secondaryAction.variant || 'outline'}>
              <Upload className="h-4 w-4 mr-2" />
              {secondaryAction.label}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Specific empty states for common use cases
export function EmptyDataState({ onAdd, onImport }: { onAdd?: () => void; onImport?: () => void }) {
  return (
    <EmptyState
      icon={Database}
      title="No data available"
      description="Get started by adding your first entry or importing existing data."
      action={onAdd ? { label: "Add Entry", onClick: onAdd } : undefined}
      secondaryAction={onImport ? { label: "Import Data", onClick: onImport } : undefined}
    />
  );
}

export function EmptyTableState({ onAdd, itemName = "entry" }: { onAdd?: () => void; itemName?: string }) {
  return (
    <EmptyState
      title={`No ${itemName}s found`}
      description={`Create your first ${itemName} to get started with data management.`}
      action={onAdd ? { label: `Add ${itemName}`, onClick: onAdd } : undefined}
    />
  );
}