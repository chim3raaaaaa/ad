// Updated Test Result Manager using unified test service and dynamic forms
import { useState, useEffect } from "react";
import { LabLayout } from "@/components/lab/LabLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Search, 
  TestTube, 
  FileText, 
  Download, 
  Plus, 
  Edit3, 
  Trash2, 
  AlertTriangle,
  Database,
  RefreshCw,
  RotateCcw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";
import { ConcreteProductsTab } from "@/components/lab/ConcreteProductsTab";
import { AggregatesTestModal } from "@/components/test-modules/AggregatesTestModal";
import { directInputService } from "@/services/database/DirectInputService";
import { testDataMigrationService } from "@/services/database/testDataMigrationService";
import { TestModulesAPI } from "@/services/api/testModulesAPI";

export default function TestResultManager() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("concrete-products");

  // Aggregates modal state
  const [showAggregatesModal, setShowAggregatesModal] = useState(false);
  
  // Migration State
  const [showMigrationDialog, setShowMigrationDialog] = useState(false);
  const [migrationInProgress, setMigrationInProgress] = useState(false);
  const [migrationResult, setMigrationResult] = useState<any>(null);
  
  // Loading states
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initializeData();
  }, []);

  // Removed unused useEffect

  const initializeData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Initialize direct input service
      await directInputService.initialize();
      
    } catch (err) {
      console.error('Failed to initialize data:', err);
      setError('Failed to initialize test results system. Some features may not work properly.');
    } finally {
      setIsLoading(false);
    }
  };

  // Simplified handlers for the new product-specific approach
  const handleDataRefresh = () => {
    toast({
      title: "Data Refreshed",
      description: "Test data has been refreshed"
    });
  };

  const handleAggregatesTestSuccess = () => {
    setShowAggregatesModal(false);
    handleDataRefresh();
  };

  const startMigration = async () => {
    setMigrationInProgress(true);
    try {
      const result = await testDataMigrationService.migrateAllTestData();
      setMigrationResult(result);
      
      if (result.success) {
        toast({
          title: "Migration Complete",
          description: `Successfully migrated ${result.migrated} test entries from ${result.tablesMigrated.length} tables`
        });
        handleDataRefresh(); // Refresh data after migration
      } else {
        toast({
          title: "Migration Issues",
          description: `Migration completed with ${result.errors.length} errors`,
          variant: "destructive"
        });
      }
    } catch (err) {
      toast({
        title: "Migration Failed",
        description: "An error occurred during migration",
        variant: "destructive"
      });
    } finally {
      setMigrationInProgress(false);
      setShowMigrationDialog(false);
    }
  };

  // Export functionality can be handled by individual product tabs

  if (isLoading) {
    return (
      <LabLayout>
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin mr-2" />
          <span>Loading test results...</span>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Test Result Manager</h1>
            <p className="text-muted-foreground">
              Unified test data entry and management system for all test categories
            </p>
          </div>
          <div className="flex space-x-2">
            <PermissionWrapper permission="test_results:migrate">
              <Button 
                variant="outline" 
                onClick={() => setShowMigrationDialog(true)}
                disabled={migrationInProgress}
              >
                <Database className="w-4 h-4 mr-2" />
                Migrate Legacy Data
              </Button>
            </PermissionWrapper>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {error}
              <Button variant="link" className="p-0 h-auto ml-2" onClick={initializeData}>
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="concrete-products" className="flex items-center">
              <TestTube className="h-4 w-4 mr-2" />
              Concrete Products
            </TabsTrigger>
            <TabsTrigger value="aggregates" className="flex items-center">
              <FileText className="h-4 w-4 mr-2" />
              Aggregates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="concrete-products" className="space-y-6 mt-6">
            <ConcreteProductsTab />
          </TabsContent>

          <TabsContent value="aggregates" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Aggregates Testing
                  </CardTitle>
                  <Button onClick={() => setShowAggregatesModal(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    New Aggregates Test
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Click "New Aggregates Test" to create aggregate test entries with sieve analysis, physical properties, and mechanical testing results.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Product-specific modals are now handled within ConcreteProductsTab */}
        
        {/* Aggregates Test Modal */}
        <AggregatesTestModal
          isOpen={showAggregatesModal}
          onClose={() => setShowAggregatesModal(false)}
          onSuccess={handleAggregatesTestSuccess}
        />

        {/* Migration Dialog */}
        <Dialog open={showMigrationDialog} onOpenChange={setShowMigrationDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Migrate Legacy Test Data</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                This will migrate existing test data from aggregate_tests, concrete_tests, and other legacy tables
                to the new unified test_entries schema. A backup will be created automatically.
              </p>
              
              {migrationResult && (
                <Alert className={migrationResult.success ? "border-green-500" : "border-red-500"}>
                  <AlertDescription>
                    <strong>Migration Results:</strong><br/>
                    • Migrated: {migrationResult.migrated} entries<br/>
                    • Tables: {migrationResult.tablesMigrated.join(', ')}<br/>
                    {migrationResult.errors.length > 0 && (
                      <>• Errors: {migrationResult.errors.length}</>
                    )}
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowMigrationDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={startMigration} 
                  disabled={migrationInProgress}
                  className="bg-primary hover:bg-primary/90"
                >
                  {migrationInProgress && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
                  Start Migration
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </LabLayout>
  );
}