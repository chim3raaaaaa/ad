import { LabLayout } from "@/components/lab/LabLayout";
import { NotificationPageContent } from "@/components/notifications/NotificationPageContent";

const Notifications = () => {
  return (
    <LabLayout>
      <div className="p-6">
        <NotificationPageContent />
      </div>
    </LabLayout>
  );
};

export default Notifications;