import React, { useEffect } from 'react';
import { Layout } from "react-grid-layout";
import { LabLayout } from "@/components/lab/LabLayout";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { RotateCcw, TrendingUp, BarChart3, Download, Bell, Filter } from "lucide-react";
import { DashboardGrid } from "@/components/dashboard/DashboardGrid";
import { WidgetSelector } from "@/components/dashboard/WidgetSelector";
import { ExportWidget } from "@/components/dashboard/ExportWidget";
import { AdvancedFilterPanel } from "@/components/dashboard/AdvancedFilterPanel";
import { EnhancedNotificationCenter } from "@/components/notifications/EnhancedNotificationCenter";
import { useDashboardWidgets } from "@/hooks/useDashboardWidgets";
import { useUser } from "@/contexts/UserContext";
import { enhancedNotificationService } from "@/services/notifications/enhancedNotificationService";
import { DashboardTestUtility } from "@/components/dashboard/DashboardTestUtility";
import "./Dashboard.css";

const Dashboard = () => {
  const { user } = useUser();
  const {
    widgets,
    loading,
    addWidget,
    removeWidget,
    updateWidgetPositions,
    canEdit
  } = useDashboardWidgets();

  // Initialize notifications and periodic checks
  useEffect(() => {
    enhancedNotificationService.startPeriodicChecks();
  }, []);

  const handleLayoutChange = (layout: Layout[]) => {
    if (!canEdit) return;
    
    const updatedWidgets = widgets.map(widget => {
      const layoutItem = layout.find(item => item.i === widget.id);
      if (layoutItem) {
        return {
          ...widget,
          x: layoutItem.x,
          y: layoutItem.y,
          w: layoutItem.w,
          h: layoutItem.h
        };
      }
      return widget;
    });
    
    updateWidgetPositions(updatedWidgets);
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  if (loading) {
    return (
      <LabLayout>
        <div className="flex items-center justify-center h-full">
          <div className="flex items-center space-x-2">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="text-muted-foreground">Loading dashboard...</p>
          </div>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-background via-background to-muted/20 border-b">
          <div className="p-6 space-y-4">
            {/* Welcome Section */}
            <div className="space-y-1">
              <h1 className="text-3xl font-bold tracking-tight">
                Welcome back, {user?.fullName || user?.username || 'User'}
              </h1>
              <div className="flex items-center space-x-4 text-muted-foreground">
                <p>Monitor your laboratory metrics and analytics in real-time</p>
                <span className="text-sm">•</span>
                <p className="text-sm">{new Date().toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <span className="font-medium">Dashboard</span>
                </div>
                <Separator orientation="vertical" className="h-6" />
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">{widgets.length} widgets</Badge>
                  <Badge variant="outline">Live data</Badge>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Filter className="h-4 w-4" />
                      Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-96">
                    <AdvancedFilterPanel />
                  </SheetContent>
                </Sheet>
                
                <ExportWidget 
                  widgets={widgets}
                />
                
                <DashboardTestUtility />
                
                <Button 
                  variant="outline" 
                  onClick={handleRefresh}
                  size="sm"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>
              
              {/* Add Widget and Notification bell on the right */}
              <div className="flex items-center space-x-2 ml-4">
                <WidgetSelector 
                  onAddWidget={addWidget}
                  disabled={!canEdit}
                  userId={user?.id || 'user_1'}
                />
                
                <EnhancedNotificationCenter />
              </div>
            </div>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="flex-1 p-6 overflow-hidden">
          <DashboardGrid
            widgets={widgets}
            onLayoutChange={handleLayoutChange}
            onRemoveWidget={removeWidget}
            canEdit={canEdit}
          />
        </div>
      </div>
    </LabLayout>
  );
};

export default Dashboard;