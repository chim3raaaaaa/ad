import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Code, 
  Database, 
  Layout, 
  Palette, 
  Settings, 
  Zap, 
  Package,
  Terminal,
  Users,
  FileText,
  Layers,
  Power,
  Activity,
  Shield
} from "lucide-react";
import { LabLayout } from "@/components/lab/LabLayout";
import { FormBuilder } from "@/components/lab/FormBuilder";
import { CustomComponentBuilder } from "@/components/lab/CustomComponentBuilder";
import { APIEndpointManager } from "@/components/lab/APIEndpointManager";
import { ThemeCustomizer } from "@/components/lab/ThemeCustomizer";
import { WorkflowBuilder } from "@/components/lab/WorkflowBuilder";
import { FieldInspector } from "@/components/lab/FieldInspector";
import { DataLinkManager } from "@/components/lab/DataLinkManager";
import { AuditTrail } from "@/components/lab/AuditTrail";
import { DevToolsExporter } from "@/devtools/exports/DevToolsExporter";
import { SQLiteConsole } from "@/components/developer/SQLiteConsole";
import { UserFlowSimulator } from "@/components/developer/UserFlowSimulator";
import { TemplateComposer } from "@/components/developer/TemplateComposer";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";
import { RoleSwitcher } from "@/components/auth/RoleSwitcher";
import ModuleManager from "@/components/lab/ModuleManager";
import { NotificationServiceStatus } from "@/components/developer/NotificationServiceStatus";
import { MemoTestDashboard } from "@/components/lab/MemoTestDashboard";
import { useDeveloperMode } from "@/hooks/useDeveloperMode";
import { useUser } from "@/contexts/UserContext";

export default function Developer() {
  const [activeBuilders, setActiveBuilders] = useState<string[]>([]);
  const { user } = useUser();
  const { 
    isDeveloperMode, 
    canUseDeveloperMode, 
    enableDeveloperMode, 
    disableDeveloperMode 
  } = useDeveloperMode();

  const toolCategories = {
    builders: {
      title: "Builder Tools",
      description: "Create and customize forms, components, and workflows",
      tools: [
        {
          id: "forms",
          title: "Form Builder",
          description: "Create custom forms with advanced validation and conditional logic",
          icon: Layout,
          component: FormBuilder,
          status: "stable"
        },
        {
          id: "components",
          title: "Component Builder", 
          description: "Build reusable UI components with custom properties",
          icon: Layers,
          component: CustomComponentBuilder,
          status: "stable"
        },
        {
          id: "workflows",
          title: "Workflow Builder",
          description: "Design automated business processes and triggers",
          icon: Zap,
          component: WorkflowBuilder,
          status: "beta"
        },
        {
          id: "templates",
          title: "Template Composer",
          description: "Create and share reusable templates across all builders",
          icon: FileText,
          component: TemplateComposer,
          status: "new"
        }
      ]
    },
    system: {
      title: "System Tools",
      description: "Database management, APIs, and system configuration",
      tools: [
        {
          id: "apis",
          title: "API Manager",
          description: "Configure endpoints, test APIs, and manage data connections",
          icon: Zap,
          component: APIEndpointManager,
          status: "stable"
        },
        {
          id: "sqlite",
          title: "SQLite Console",
          description: "Execute SQL queries directly against the database",
          icon: Terminal,
          component: SQLiteConsole,
          status: "new",
          adminOnly: true
        },
        {
          id: "inspector",
          title: "Field Inspector",
          description: "Inspect and modify field properties and constraints",
          icon: Settings,
          component: FieldInspector,
          status: "stable"
        },
        {
          id: "links",
          title: "Data Link Manager",
          description: "Manage data relationships and cross-table linking",
          icon: Database,
          component: DataLinkManager,
          status: "stable"
        }
      ]
    },
    analytics: {
      title: "Analytics Tools", 
      description: "Monitoring, testing, and performance analysis",
      tools: [
        {
          id: "audit",
          title: "Audit Trail",
          description: "Track system activities, changes, and user actions",
          icon: Shield,
          component: AuditTrail,
          status: "stable"
        },
        {
          id: "simulator",
          title: "User Flow Simulator",
          description: "Test role-based access and simulate user experiences",
          icon: Users,
          component: UserFlowSimulator,
          status: "new"
        },
        {
          id: "exporter",
          title: "Schema Exporter",
          description: "Export builder definitions and schemas as JSON",
          icon: Package,
          component: DevToolsExporter,
          status: "stable"
        },
        {
          id: "themes",
          title: "Theme Editor",
          description: "Customize application appearance and styling",
          icon: Palette,
          component: ThemeCustomizer,
          status: "stable",
          adminOnly: true
        }
      ]
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge variant="default">New</Badge>;
      case "beta":
        return <Badge variant="secondary">Beta</Badge>;
      case "stable":
        return <Badge variant="outline">Stable</Badge>;
      default:
        return null;
    }
  };

  const ToolCard = ({ tool, category }: { tool: any; category: string }) => {
    const isActive = activeBuilders.includes(tool.id);
    const isAdminOnly = tool.adminOnly && user?.role !== 'admin';
    
    return (
      <Card className={`transition-all hover:shadow-md ${
        isActive ? 'ring-2 ring-primary' : ''
      } ${isAdminOnly ? 'opacity-60' : ''}`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-muted">
                <tool.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-lg">{tool.title}</CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  {getStatusBadge(tool.status)}
                  {tool.adminOnly && (
                    <Badge variant="destructive" className="text-xs">Admin Only</Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            {tool.description}
          </p>
          
          <Button 
            className="w-full"
            variant={isActive ? "secondary" : "default"}
            onClick={() => {
              if (!isAdminOnly) {
                setActiveBuilders(prev => 
                  prev.includes(tool.id) ? prev : [...prev, tool.id]
                );
              }
            }}
            disabled={isActive || isAdminOnly}
          >
            {isActive ? (
              <>
                <Activity className="w-4 h-4 mr-2" />
                Active
              </>
            ) : isAdminOnly ? (
              <>
                <Shield className="w-4 h-4 mr-2" />
                Admin Required
              </>
            ) : (
              "Launch Tool"
            )}
          </Button>
        </CardContent>
      </Card>
    );
  };

  return (
    <LabLayout>
      <div className="p-6 space-y-6">
        {/* Header Section */}
        <div className="space-y-4">
          <RoleSwitcher />
          
          <PermissionWrapper permission="system.developer_mode">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <Code className="w-6 h-6 text-primary" />
                  <div>
                    <h1 className="text-3xl font-bold text-foreground">
                      Developer Mode
                    </h1>
                    <p className="text-muted-foreground">
                      Advanced tools for customizing and extending your laboratory system
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <Badge variant={isDeveloperMode ? "default" : "secondary"}>
                  <Power className="w-4 h-4 mr-2" />
                  {isDeveloperMode ? "Active" : "Disabled"}
                </Badge>
                
                <Button
                  variant={isDeveloperMode ? "outline" : "default"}
                  onClick={isDeveloperMode ? disableDeveloperMode : enableDeveloperMode}
                >
                  <Power className="w-4 h-4 mr-2" />
                  {isDeveloperMode ? "Disable" : "Enable"}
                </Button>
              </div>
            </div>
          </PermissionWrapper>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Tool Overview</TabsTrigger>
            <TabsTrigger value="builders">Active Builders</TabsTrigger>
            <TabsTrigger value="modules">Module System</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {Object.entries(toolCategories).map(([categoryKey, category]) => (
              <div key={categoryKey} className="space-y-4">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{category.title}</h2>
                  <p className="text-muted-foreground">{category.description}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {category.tools.map((tool) => (
                    <ToolCard key={tool.id} tool={tool} category={categoryKey} />
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="builders" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <MemoTestDashboard />
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <NotificationServiceStatus />
                </CardContent>
              </Card>
            </div>
            
            {activeBuilders.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Code className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold text-foreground mb-2">No Active Builders</h3>
                  <p className="text-muted-foreground text-center">
                    Launch a builder from the Tool Overview tab to start customizing your laboratory system
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {activeBuilders.map((builderId) => {
                  const tool = Object.values(toolCategories)
                    .flatMap(cat => cat.tools)
                    .find(t => t.id === builderId);
                  
                  if (!tool) return null;
                  
                  const BuilderComponent = tool.component;
                  
                  return (
                    <Card key={builderId}>
                      <CardHeader className="flex flex-row items-center justify-between border-b">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-muted">
                            <tool.icon className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <CardTitle>{tool.title}</CardTitle>
                            <p className="text-sm text-muted-foreground">{tool.description}</p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setActiveBuilders(prev => prev.filter(id => id !== builderId));
                          }}
                        >
                          Close
                        </Button>
                      </CardHeader>
                      <CardContent className="p-6">
                        <BuilderComponent />
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="modules" className="space-y-6">
            <Card>
              <CardHeader className="border-b">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <Package className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Module System</CardTitle>
                    <p className="text-muted-foreground">
                      Manage plugins, extensions, and modular components
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <ModuleManager />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </LabLayout>
  );
}