import { useState, useEffect } from "react";
import { LabLayout } from "@/components/lab/LabLayout";
import { MemoHeader } from "@/components/memo/MemoHeader";
import { MemoTable } from "@/components/memo/MemoTable";
import { MemoDetailsPanel } from "@/components/memo/MemoDetailsPanel";
import { MemoCreateModal } from "@/components/memo/MemoCreateModal";
import { memoService, MemoData, MemoCategory } from "@/services/database/memoService";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { dataExportService } from "@/services/export/dataExportService";
// PDF extraction will be implemented when needed

export default function MemoManagement() {
  const [memos, setMemos] = useState<MemoData[]>([]);
  const [categories, setCategories] = useState<MemoCategory[]>([]);
  const [selectedMemo, setSelectedMemo] = useState<MemoData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [isFiltersVisible, setIsFiltersVisible] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { toast } = useToast();
  const { user, hasPermission } = useUser();

  useEffect(() => {
    initializeService();
    loadData();
  }, []);

  const initializeService = async () => {
    try {
      await memoService.initialize();
    } catch (error) {
      console.error('Failed to initialize memo service:', error);
      setError('Failed to initialize memo service. Some features may not work.');
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const [memosData, categoriesData] = await Promise.all([
        loadMemos(),
        loadCategories()
      ]);
    } catch (error) {
      console.error('Failed to load data:', error);
      setError('Failed to load memo data. Please check your connection and try again.');
      toast({
        title: "Error",
        description: "Failed to load memo data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadMemos = async () => {
    const filters: any = {};
    
    if (selectedCategory !== 'all') {
      filters.category = selectedCategory;
    }
    if (selectedStatus !== 'all') {
      filters.status = selectedStatus;
    }
    
    const data = await memoService.getMemos(filters);
    
    // Filter by search term
    const filteredData = searchTerm
      ? data.filter(memo => 
          memo.memo_ref.toLowerCase().includes(searchTerm.toLowerCase()) ||
          memo.officer.toLowerCase().includes(searchTerm.toLowerCase()) ||
          memo.plant.toLowerCase().includes(searchTerm.toLowerCase()) ||
          memo.product_type.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : data;
    
    setMemos(filteredData);
    return filteredData;
  };

  const loadCategories = async () => {
    const data = await memoService.getCategories();
    setCategories(data);
    return data;
  };

  useEffect(() => {
    if (!isLoading) {
      loadMemos();
    }
  }, [searchTerm, selectedCategory, selectedStatus]);

  const handleCreateMemo = () => {
    if (!hasPermission('memos.create')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to create memos",
        variant: "destructive"
      });
      return;
    }
    setIsCreateModalOpen(true);
  };

  const handleImportMemo = async () => {
    if (!hasPermission('memos.create')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to import memos",
        variant: "destructive"
      });
      return;
    }

    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.pdf';
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file && user) {
          try {
            // TODO: Implement PDF extraction
            const extractedData = null;
            
            if (extractedData) {
              // Create memo with extracted data
              const memoRef = await memoService.generateMemoRef(
                extractedData.plant || 'unknown',
                extractedData.category || 'general'
              );
              
              await memoService.createMemo({
                memo_ref: memoRef,
                category: extractedData.category || 'general',
                plant: extractedData.plant || 'unknown',
                product_type: extractedData.productType || 'Unknown',
                date_of_sampling: extractedData.samplingDate || new Date().toISOString().split('T')[0],
                officer: extractedData.officer || user.username,
                status: 'draft',
                created_by: user.username,
                extracted_data: extractedData
              });
              
              // Add attachment
              await memoService.addAttachment(memoRef, file, user.username);
              
              toast({
                title: "Success",
                description: "PDF imported and memo created successfully"
              });
              
              loadMemos();
            } else {
              toast({
                title: "Warning",
                description: "No data could be extracted from the PDF",
                variant: "destructive"
              });
            }
          } catch (error) {
            console.error('PDF import failed:', error);
            toast({
              title: "Error",
              description: "Failed to import PDF file",
              variant: "destructive"
            });
          }
        }
      };
      input.click();
    } catch (error) {
      console.error('Import failed:', error);
      toast({
        title: "Error",
        description: "Import function is not available",
        variant: "destructive"
      });
    }
  };

  const handleExportMemos = async () => {
    if (!hasPermission('memos.view')) {
      toast({
        title: "Access Denied", 
        description: "You don't have permission to export memos",
        variant: "destructive"
      });
      return;
    }

    try {
      // Simple CSV export
      const csvContent = "data:text/csv;charset=utf-8," + 
        "Memo Ref,Category,Plant,Product Type,Officer,Status,Date\n" +
        memos.map(memo => 
          `${memo.memo_ref},${memo.category},${memo.plant},${memo.product_type},${memo.officer},${memo.status},${memo.date_of_sampling}`
        ).join('\n');
      
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", "memos.csv");
      link.click();
      toast({
        title: "Success",
        description: "Memos exported to Excel successfully"
      });
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: "Error",
        description: "Failed to export memos",
        variant: "destructive"
      });
    }
  };

  const handlePrintMemos = async () => {
    if (!hasPermission('memos.view')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to print memos", 
        variant: "destructive"
      });
      return;
    }

    try {
      window.print();
    } catch (error) {
      console.error('Print failed:', error);
      toast({
        title: "Error",
        description: "Failed to print memos",
        variant: "destructive"
      });
    }
  };

  const handleEditMemo = (memo: MemoData) => {
    if (!hasPermission('memos.edit')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit memos",
        variant: "destructive"
      });
      return;
    }
    // TODO: Implement edit modal
    toast({
      title: "Coming Soon",
      description: "Edit functionality will be implemented"
    });
  };

  const handleDeleteMemo = async (memo: MemoData) => {
    if (!hasPermission('memos.delete')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to delete memos",
        variant: "destructive"
      });
      return;
    }

    if (window.confirm(`Are you sure you want to delete memo ${memo.memo_ref}?`)) {
      try {
        await memoService.deleteMemo(memo.id!);
        toast({
          title: "Success",
          description: "Memo deleted successfully"
        });
        loadMemos();
        if (selectedMemo?.id === memo.id) {
          setSelectedMemo(null);
        }
      } catch (error) {
        console.error('Delete failed:', error);
        toast({
          title: "Error",
          description: "Failed to delete memo",
          variant: "destructive"
        });
      }
    }
  };

  const handleSubmitToInbox = async (memo: MemoData) => {
    if (!hasPermission('memos.create')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to submit memos",
        variant: "destructive"
      });
      return;
    }

    try {
      await memoService.submitToInbox(memo.memo_ref);
      await memoService.updateMemo(memo.id!, { status: 'pending' });
      
      toast({
        title: "Success",
        description: "Memo submitted to inbox successfully"
      });
      
      loadMemos();
    } catch (error) {
      console.error('Submit failed:', error);
      toast({
        title: "Error",
        description: "Failed to submit memo to inbox",
        variant: "destructive"
      });
    }
  };

  const handleMemoCreated = () => {
    loadMemos();
  };

  if (error && !isLoading) {
    return (
      <LabLayout>
        <div className="p-6">
          <div className="text-center py-12">
            <h2 className="text-xl font-semibold mb-4">Service Unavailable</h2>
            <p className="text-muted-foreground mb-6">{error}</p>
            <button 
              onClick={loadData}
              className="px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90"
            >
              Retry
            </button>
          </div>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <div className="p-6 space-y-6">
        <MemoHeader
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          selectedStatus={selectedStatus}
          onStatusChange={setSelectedStatus}
          categories={categories}
          onCreateMemo={handleCreateMemo}
          onImportMemo={handleImportMemo}
          onExportMemos={handleExportMemos}
          onPrintMemos={handlePrintMemos}
          isFiltersVisible={isFiltersVisible}
          onToggleFilters={() => setIsFiltersVisible(!isFiltersVisible)}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MemoTable
              memos={memos}
              onViewMemo={setSelectedMemo}
              onEditMemo={handleEditMemo}
              onDeleteMemo={handleDeleteMemo}
              onSubmitToInbox={handleSubmitToInbox}
              isLoading={isLoading}
            />
          </div>
          
          <div className="lg:col-span-1">
            <MemoDetailsPanel
              memo={selectedMemo}
              onClose={() => setSelectedMemo(null)}
            />
          </div>
        </div>

        <MemoCreateModal
          open={isCreateModalOpen}
          onOpenChange={setIsCreateModalOpen}
          onMemoCreated={handleMemoCreated}
        />
      </div>
    </LabLayout>
  );
}