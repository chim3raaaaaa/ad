import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { LabLayout } from '@/components/lab/LabLayout';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';
import TestDataExplorer from '@/modules/test-data-explorer/components/TestDataExplorer';

export default function TestDataExplorerPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const moduleId = searchParams.get('moduleId');
  const testType = searchParams.get('testType');
  const category = searchParams.get('category');

  const handleBack = () => {
    navigate('/test-modules');
  };

  return (
    <LabLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={handleBack}>
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Test Modules
          </Button>
          {category && testType && (
            <div className="text-sm text-muted-foreground">
              Test Modules &gt; {category} &gt; {testType} &gt; View Test Data
            </div>
          )}
        </div>
        
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            {testType ? `Test Data: ${testType}` : 'Test Data Explorer'}
          </h1>
          <p className="text-muted-foreground">
            {category 
              ? `Browse and analyze test data for ${testType} in ${category}`
              : 'Browse, filter, compare, and analyze historical test data across all products'
            }
          </p>
        </div>

        <TestDataExplorer moduleId={moduleId || undefined} testType={testType || undefined} />
      </div>
    </LabLayout>
  );
}