import React from 'react';
import { LabLayout } from '@/components/lab/LabLayout';
import { EnhancedTestModulesHub } from '@/components/test-modules/EnhancedTestModulesHub';

export default function TestModules() {
  return (
    <LabLayout>
      <div className="p-6">
        <EnhancedTestModulesHub />
      </div>
    </LabLayout>
  );
}