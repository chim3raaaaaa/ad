import { LabLayout } from "@/components/lab/LabLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Users as UsersIcon, Shield, UserCheck, Settings, Edit, Trash2 } from "lucide-react";
import { UserActivityLog } from "@/components/lab/UserActivityLog";
import { InternalMessaging } from "@/components/lab/InternalMessaging";
import { UserEditModal } from "@/components/lab/UserEditModal";
import { UserCreateModal } from "@/components/lab/UserCreateModal";
import { RoleEditModal } from "@/components/lab/RoleEditModal";
import { UserDeleteDialog } from "@/components/lab/UserDeleteDialog";
import { RoleManagement } from "@/components/lab/RoleManagement";
import { PermissionWrapper } from "@/components/rbac/PermissionWrapper";
import { useState } from "react";
import { useUser } from "@/contexts/UserContext";
import { usePermissions } from "@/services/rbac/guards";
import { useUsersContext, type User, type Role } from "@/contexts/UsersContext";
import { useToast } from "@/hooks/use-toast";

interface UsersTabProps {
  users: User[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
  onCreateUser: () => void;
  onEditUser: (user: User) => void;
  onDeleteUser: (user: User) => void;
  onEditRole: (user: User) => void;
}

function UsersTab({
  users,
  searchTerm,
  setSearchTerm,
  canCreate,
  canEdit,
  canDelete,
  onCreateUser,
  onEditUser,
  onDeleteUser,
  onEditRole
}: UsersTabProps) {
  const { getRoleByName } = useUsersContext();
  
  const getStatusColor = (status: string) => {
    return status === "active" 
      ? "bg-green-500/20 text-green-700 border-green-500/30"
      : "bg-red-500/20 text-red-700 border-red-500/30";
  };

  const getRoleColor = (roleName: string) => {
    const role = getRoleByName(roleName);
    return role?.color || 'bg-gray-500/20 text-gray-700 border-gray-500/30';
  };

  const getRoleName = (roleName: string) => {
    const role = getRoleByName(roleName);
    return role?.name || 'Unknown Role';
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        {canCreate && (
          <Button onClick={onCreateUser}>
            <Plus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <UsersIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {users.filter(u => u.status === "active").length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Roles</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Departments</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Login</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{user.name}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge className={getRoleColor(user.role)}>
                      {getRoleName(user.role)}
                    </Badge>
                  </TableCell>
                  <TableCell>{user.department}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(user.status)}>
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      {canEdit && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => onEditUser(user)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                      {canDelete && (
                        <Button 
                          variant="destructive"
                          size="sm"
                          onClick={() => onDeleteUser(user)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Users() {
  const { user } = useUser();
  const { canViewUsers, canCreateUsers, canEditUsers, canDeleteUsers, canManageRoles } = usePermissions();
  const { users, roles, addUser, updateUser, deleteUser, addRole, updateRole, deleteRole, getRoleByName } = useUsersContext();
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Real event handlers connected to users context
  const handleCreateUser = async (userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      await addUser(userData, 'defaultpass123');
      setShowCreateModal(false);
      toast({
        title: "User Created",
        description: `User ${userData.name} has been added successfully.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create user.",
        variant: "destructive"
      });
    }
  };

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setShowEditModal(true);
  };

  const handleUpdateUser = async (userId: string, updates: Partial<User>) => {
    try {
      await updateUser(userId, updates);
      setShowEditModal(false);
      setSelectedUser(null);
      toast({
        title: "User Updated",
        description: "User information has been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update user.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteUser = (user: User) => {
    setSelectedUser(user);
    setShowDeleteDialog(true);
  };

  const handleConfirmDelete = () => {
    if (selectedUser) {
      deleteUser(selectedUser.id);
      setShowDeleteDialog(false);
      setSelectedUser(null);
      toast({
        title: "User Deleted", 
        description: `User ${selectedUser.name} has been removed.`
      });
    }
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    getRoleByName(user.role)?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <LabLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
            <p className="text-muted-foreground">
              Manage users, roles, and permissions for the laboratory system.
            </p>
          </div>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList>
            <TabsTrigger value="users">Users</TabsTrigger>
            <PermissionWrapper permission="roles.manage" hideIfNoAccess>
              <TabsTrigger value="roles">Roles & Permissions</TabsTrigger>
            </PermissionWrapper>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="messaging">Internal Messaging</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <PermissionWrapper permission="users.view">
              <UsersTab
                users={filteredUsers}
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                canCreate={canCreateUsers()}
                canEdit={canEditUsers()}
                canDelete={canDeleteUsers()}
                onCreateUser={() => setShowCreateModal(true)}
                onEditUser={handleEditUser}
                onDeleteUser={handleDeleteUser}
                onEditRole={(user) => {
                  setSelectedUser(user);
                  setShowRoleModal(true);
                }}
              />
            </PermissionWrapper>
          </TabsContent>

          <TabsContent value="roles">
            <PermissionWrapper permission="roles.manage">
              <RoleManagement />
            </PermissionWrapper>
          </TabsContent>

          <TabsContent value="activity">
            <UserActivityLog />
          </TabsContent>

          <TabsContent value="messaging">
            <InternalMessaging />
          </TabsContent>
        </Tabs>

        {/* Modals */}
        <UserEditModal
          user={selectedUser}
          isOpen={showEditModal}
          onClose={() => {
            setShowEditModal(false);
            setSelectedUser(null);
          }}
          onSave={(updatedUser) => handleUpdateUser(selectedUser?.id || '', updatedUser)}
          currentUserRole={user?.role || ""}
        />

        <UserCreateModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          onSave={handleCreateUser}
          currentUserRole={user?.role || ""}
        />

        <RoleEditModal
          role={null}
          isOpen={showRoleModal}
          onClose={() => {
            setShowRoleModal(false);
            setSelectedRole(null);
          }}
          onSave={(updatedRole) => {
            if (selectedRole) {
              updateRole(selectedRole.name, updatedRole);
              setShowRoleModal(false);
              setSelectedRole(null);
              toast({
                title: "Role Updated",
                description: "Role has been updated successfully."
              });
            }
          }}
          currentUserRole={user?.role || ""}
        />

        <UserDeleteDialog
          user={selectedUser}
          isOpen={showDeleteDialog}
          onClose={() => {
            setShowDeleteDialog(false);
            setSelectedUser(null);
          }}
          onConfirm={handleConfirmDelete}
          currentUserRole={user?.role || ""}
        />
      </div>
    </LabLayout>
  );
}