import { LabLayout } from "@/components/lab/LabLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, TrendingDown, Activity, Clock, FileText, Users, Calendar, Download, Settings, Filter, Plus, Eye, BarChart3, PieChart as PieChartIcon, LineChart as LineChartIcon } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { CustomGraphCreator } from "@/components/lab/CustomGraphCreator";
import { useMemoContext } from "@/contexts/MemoContext";
import type { AnalyticsData } from "@/types";

// ============= INTERFACES =============

interface Memo {
  id: string;
  memo_ref: string;
  product_type: string;
  plant_id: string;
  plant_name?: string;
  officer_id: string;
  status: string;
  created_at: string;
  updated_at: string;
  scheduled_date?: string;
  completed_date?: string;
  test_type?: string;
  extractedData?: {
    testType?: string;
    productType?: string;
    plantName?: string;
  };
}

interface TestResult {
  id: string;
  memo_ref: string;
  test_type: string;
  results: any;
  created_at: string;
}

interface Plant {
  plant_id: string;
  name: string;
}

interface ProductCategory {
  category_id: string;
  name: string;
}

interface TestType {
  type_id: string;
  name: string;
}

interface DrillDownData {
  title: string;
  data: Memo[];
  isOpen: boolean;
}

interface PerformanceMetrics {
  testsPerWeek: number;
  onTimeCompletionRate: number;
  delayedTests: number;
  avgTurnaroundDays: number;
}

interface CustomGraph {
  graph_id: string;
  name: string;
  chart_type: 'bar' | 'line' | 'pie';
  x_field: string;
  y_field: string;
  created_at: string;
  config: any;
}

// ============= ANALYTICS SERVICE =============

class AnalyticsService {
  private async executeQuery(query: string, params: any[] = []): Promise<any> {
    try {
      if (window.electronAPI) {
        return await window.electronAPI.dbQuery(query, params);
      } else {
        // Web fallback - localStorage simulation
        return this.simulateQuery(query);
      }
    } catch (error) {
      console.error('Analytics query failed:', error);
      throw error;
    }
  }

  private simulateQuery(query: string): any {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('memos')) {
      return JSON.parse(localStorage.getItem('analytics_memos') || '[]');
    }
    if (lowerQuery.includes('plants')) {
      return [
        { plant_id: 'plant1', name: 'Port Louis Plant' },
        { plant_id: 'plant2', name: 'Curepipe Plant' }
      ];
    }
    if (lowerQuery.includes('product_categories')) {
      return [
        { category_id: 'cat1', name: 'Blocks' },
        { category_id: 'cat2', name: 'Pavers' }
      ];
    }
    return [];
  }

  async initializeAnalyticsTables(): Promise<void> {
    const createCustomGraphsQuery = `
      CREATE TABLE IF NOT EXISTS saved_graphs (
        graph_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        chart_type TEXT NOT NULL,
        x_field TEXT NOT NULL,
        y_field TEXT NOT NULL,
        config TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1
      )
    `;
    
    await this.executeQuery(createCustomGraphsQuery);
  }

  async getMemos(): Promise<Memo[]> {
    try {
      return await this.executeQuery(`
        SELECT m.*, p.name as plant_name 
        FROM memos m 
        LEFT JOIN plants p ON m.plant_id = p.plant_id 
        ORDER BY m.created_at DESC
      `);
    } catch {
      return [];
    }
  }

  async getTestResults(): Promise<TestResult[]> {
    try {
      return await this.executeQuery('SELECT * FROM test_results ORDER BY created_at DESC');
    } catch {
      return [];
    }
  }

  async getPlants(): Promise<Plant[]> {
    try {
      return await this.executeQuery('SELECT * FROM plants WHERE is_active = 1');
    } catch {
      return [];
    }
  }

  async getProductCategories(): Promise<ProductCategory[]> {
    try {
      return await this.executeQuery('SELECT * FROM product_categories WHERE is_active = 1');
    } catch {
      return [];
    }
  }

  async getTestTypes(): Promise<TestType[]> {
    try {
      return await this.executeQuery('SELECT DISTINCT test_type as type_id, test_type as name FROM test_results');
    } catch {
      return [];
    }
  }

  async saveCustomGraph(graph: Omit<CustomGraph, 'graph_id' | 'created_at'>): Promise<string> {
    const graphId = `graph_${Date.now()}`;
    
    await this.executeQuery(`
      INSERT INTO saved_graphs (graph_id, name, chart_type, x_field, y_field, config, created_by, created_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      graphId,
      graph.name,
      graph.chart_type,
      graph.x_field,
      graph.y_field,
      JSON.stringify(graph.config),
      'current_user',
      new Date().toISOString(),
      1
    ]);

    return graphId;
  }

  async getCustomGraphs(): Promise<CustomGraph[]> {
    return await this.executeQuery('SELECT * FROM saved_graphs WHERE is_active = 1 ORDER BY created_at DESC');
  }

  async deleteCustomGraph(graphId: string): Promise<void> {
    await this.executeQuery('UPDATE saved_graphs SET is_active = 0 WHERE graph_id = ?', [graphId]);
  }
}

const analyticsService = new AnalyticsService();

// ============= MAIN ANALYTICS COMPONENT =============

export default function Analytics() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    totalTests: 0,
    completedTests: 0,
    pendingTests: 0,
    activeUsers: 1,
    completionRate: 0
  });
  const [monthlyData, setMonthlyData] = useState<Array<{ month: string; tests: number; completed: number; pending: number }>>([]);
  const [testTypeData, setTestTypeData] = useState<Array<{ name: string; value: number; color: string }>>([]);
  const [performanceData, setPerformanceData] = useState<Array<{ week: string; efficiency: number; onTime: number; testsPerWeek: number }>>([]);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics>({
    testsPerWeek: 0,
    onTimeCompletionRate: 0,
    delayedTests: 0,
    avgTurnaroundDays: 0
  });
  
  // Data sources
  const [memos, setMemos] = useState<Memo[]>([]);
  const [filteredMemos, setFilteredMemos] = useState<Memo[]>([]);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [productCategories, setProductCategories] = useState<ProductCategory[]>([]);
  const [testTypes, setTestTypes] = useState<TestType[]>([]);
  const [customGraphs, setCustomGraphs] = useState<CustomGraph[]>([]);
  
  // UI State
  const [isLoading, setIsLoading] = useState(true);
  const [drillDownData, setDrillDownData] = useState<DrillDownData>({ title: '', data: [], isOpen: false });
  const [isCustomGraphOpen, setIsCustomGraphOpen] = useState(false);
  
  // Filters
  const [filters, setFilters] = useState({
    dateRange: { start: '', end: '' },
    plantId: 'all',
    productCategory: 'all',
    testType: 'all',
    timePeriod: '6months'
  });

  const { toast } = useToast();
  const { memos: contextMemos } = useMemoContext();

  useEffect(() => {
    loadAnalyticsData();
  }, [contextMemos]);

  useEffect(() => {
    applyFilters();
  }, [filters, memos]);

  const loadAnalyticsData = async () => {
    setIsLoading(true);
    try {
      await analyticsService.initializeAnalyticsTables();
      
      // Try context first, fallback to SQLite
      let memosData: Memo[] = [];
      if (!contextMemos || contextMemos.length === 0) {
        console.log('Context empty, using SQLite fallback');
        memosData = await analyticsService.getMemos();
        
        if (memosData.length === 0) {
          // Generate sample data for demonstration
          memosData = generateSampleMemos();
        }
      } else {
        memosData = contextMemos.map(m => ({
          id: m.id,
          memo_ref: m.id, // Using id as memo_ref since memoRef doesn't exist
          product_type: m.extractedData?.product || 'Unknown',
          plant_id: m.extractedData?.site || 'unknown',
          plant_name: m.extractedData?.site || 'Unknown Plant',
          officer_id: m.extractedData?.officer || 'unknown',
          status: m.status || 'pending',
          created_at: m.createdAt,
          updated_at: m.updatedAt || m.createdAt,
          scheduled_date: undefined, // Not available in context
          completed_date: undefined, // Not available in context
          test_type: m.extractedData?.testType || 'Unknown',
          extractedData: m.extractedData
        }));
      }
      
      setMemos(memosData);
      
      // Load reference data
      const [plantsData, categoriesData, testTypesData, graphsData] = await Promise.all([
        analyticsService.getPlants(),
        analyticsService.getProductCategories(),
        analyticsService.getTestTypes(),
        analyticsService.getCustomGraphs()
      ]);
      
      setPlants(plantsData);
      setProductCategories(categoriesData);
      setTestTypes(testTypesData);
      setCustomGraphs(graphsData);
      
      // Calculate analytics from real data
      calculateAnalytics(memosData);
      
    } catch (error) {
      console.error("Error loading analytics data:", error);
      toast({
        title: "Error",
        description: "Failed to load analytics data",
        variant: "destructive"
      });
    }
    setIsLoading(false);
  };

  const generateSampleMemos = (): Memo[] => {
    const sampleMemos: Memo[] = [];
    const testTypes = ['Compressive Strength', 'Aggregate Testing', 'Moisture Content', 'Los Angeles Value'];
    const productTypes = ['Blocks', 'Pavers', 'Kerbs', 'Aggregates'];
    const statuses = ['completed', 'pending', 'in_progress'];
    
    for (let i = 0; i < 50; i++) {
      const createdDate = new Date();
      createdDate.setDate(createdDate.getDate() - Math.floor(Math.random() * 180)); // Last 6 months
      
      const scheduledDate = new Date(createdDate);
      scheduledDate.setDate(scheduledDate.getDate() + Math.floor(Math.random() * 7) + 1);
      
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const completedDate = status === 'completed' ? 
        new Date(scheduledDate.getTime() + Math.random() * 7 * 24 * 60 * 60 * 1000) : undefined;
      
      sampleMemos.push({
        id: `memo_${i + 1}`,
        memo_ref: `MEM-${String(i + 1).padStart(3, '0')}`,
        product_type: productTypes[Math.floor(Math.random() * productTypes.length)],
        plant_id: `plant_${Math.floor(Math.random() * 2) + 1}`,
        plant_name: Math.random() > 0.5 ? 'Port Louis Plant' : 'Curepipe Plant',
        officer_id: `officer_${Math.floor(Math.random() * 3) + 1}`,
        status,
        created_at: createdDate.toISOString(),
        updated_at: createdDate.toISOString(),
        scheduled_date: scheduledDate.toISOString(),
        completed_date: completedDate?.toISOString(),
        test_type: testTypes[Math.floor(Math.random() * testTypes.length)],
        extractedData: {
          testType: testTypes[Math.floor(Math.random() * testTypes.length)],
          productType: productTypes[Math.floor(Math.random() * productTypes.length)]
        }
      });
    }
    
    return sampleMemos;
  };

  const applyFilters = () => {
    let filtered = [...memos];
    
    // Date range filter
    if (filters.dateRange.start) {
      filtered = filtered.filter(m => new Date(m.created_at) >= new Date(filters.dateRange.start));
    }
    if (filters.dateRange.end) {
      filtered = filtered.filter(m => new Date(m.created_at) <= new Date(filters.dateRange.end));
    }
    
    // Plant filter
    if (filters.plantId && filters.plantId !== 'all') {
      filtered = filtered.filter(m => m.plant_id === filters.plantId);
    }
    
    // Product category filter
    if (filters.productCategory && filters.productCategory !== 'all') {
      filtered = filtered.filter(m => m.product_type === filters.productCategory);
    }
    
    // Test type filter
    if (filters.testType && filters.testType !== 'all') {
      filtered = filtered.filter(m => m.test_type === filters.testType);
    }
    
    // Time period filter
    const now = new Date();
    let cutoffDate = new Date();
    
    switch (filters.timePeriod) {
      case '1month':
        cutoffDate.setMonth(now.getMonth() - 1);
        break;
      case '3months':
        cutoffDate.setMonth(now.getMonth() - 3);
        break;
      case '6months':
        cutoffDate.setMonth(now.getMonth() - 6);
        break;
      case '1year':
        cutoffDate.setFullYear(now.getFullYear() - 1);
        break;
    }
    
    filtered = filtered.filter(m => new Date(m.created_at) >= cutoffDate);
    
    setFilteredMemos(filtered);
    calculateAnalytics(filtered);
  };

  const calculateAnalytics = (memosData: Memo[]) => {
    // Basic analytics
    const totalTests = memosData.length;
    const completedTests = memosData.filter(m => m.status === 'completed').length;
    const pendingTests = memosData.filter(m => m.status === 'pending').length;
    const completionRate = totalTests > 0 ? (completedTests / totalTests) * 100 : 0;

    setAnalyticsData({
      totalTests,
      completedTests,
      pendingTests,
      activeUsers: 1,
      completionRate: Math.round(completionRate * 100) / 100
    });

    // Monthly data
    const monthlyStats = memosData.reduce((acc, memo) => {
      const month = new Date(memo.created_at).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
      if (!acc[month]) {
        acc[month] = { month, tests: 0, completed: 0, pending: 0 };
      }
      acc[month].tests++;
      if (memo.status === 'completed') acc[month].completed++;
      if (memo.status === 'pending') acc[month].pending++;
      return acc;
    }, {} as Record<string, any>);

    setMonthlyData(Object.values(monthlyStats));

    // Test type distribution
    const testTypeCounts = memosData.reduce((acc, memo) => {
      const testType = memo.test_type || 'Unknown';
      acc[testType] = (acc[testType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe', '#8dd1e1', '#d084d0'];
    const typeData = Object.entries(testTypeCounts).map(([name, value], index) => ({
      name,
      value,
      color: colors[index % colors.length]
    }));
    setTestTypeData(typeData);

    // Performance metrics
    calculatePerformanceMetrics(memosData);
  };

  const calculatePerformanceMetrics = (memosData: Memo[]) => {
    const now = new Date();
    const weeklyData: { [key: string]: { tests: number; onTime: number; week: string } } = {};
    
    // Group by weeks
    for (let i = 0; i < 12; i++) {
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - (i * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);
      
      const weekLabel = `Week ${12 - i}`;
      const weekMemos = memosData.filter(m => {
        const memoDate = new Date(m.created_at);
        return memoDate >= weekStart && memoDate < weekEnd;
      });
      
      const onTimeTests = weekMemos.filter(m => {
        if (!m.scheduled_date || !m.completed_date) return false;
        return new Date(m.completed_date) <= new Date(m.scheduled_date);
      }).length;
      
      weeklyData[weekLabel] = {
        tests: weekMemos.length,
        onTime: weekMemos.length > 0 ? (onTimeTests / weekMemos.length) * 100 : 0,
        week: weekLabel
      };
    }
    
    const performanceArray = Object.values(weeklyData).map(week => ({
      week: week.week,
      efficiency: Math.min(100, Math.max(0, week.onTime + Math.random() * 10 - 5)),
      onTime: week.onTime,
      testsPerWeek: week.tests
    }));
    
    setPerformanceData(performanceArray);
    
    // Calculate overall metrics
    const avgTestsPerWeek = performanceArray.reduce((sum, week) => sum + week.testsPerWeek, 0) / performanceArray.length;
    const completedMemos = memosData.filter(m => m.completed_date && m.scheduled_date);
    const onTimeTests = completedMemos.filter(m => new Date(m.completed_date!) <= new Date(m.scheduled_date!));
    const onTimeRate = completedMemos.length > 0 ? (onTimeTests.length / completedMemos.length) * 100 : 0;
    const delayedTests = completedMemos.length - onTimeTests.length;
    
    // Calculate average turnaround time
    const turnaroundTimes = completedMemos.map(m => {
      const scheduled = new Date(m.scheduled_date!);
      const completed = new Date(m.completed_date!);
      return Math.abs(completed.getTime() - scheduled.getTime()) / (1000 * 60 * 60 * 24);
    });
    const avgTurnaround = turnaroundTimes.length > 0 ? 
      turnaroundTimes.reduce((sum, days) => sum + days, 0) / turnaroundTimes.length : 0;
    
    setPerformanceMetrics({
      testsPerWeek: Math.round(avgTestsPerWeek * 10) / 10,
      onTimeCompletionRate: Math.round(onTimeRate * 10) / 10,
      delayedTests,
      avgTurnaroundDays: Math.round(avgTurnaround * 10) / 10
    });
  };

  const handleChartClick = (chartType: string, data: any) => {
    let filteredData: Memo[] = [];
    let title = '';
    
    switch (chartType) {
      case 'monthly':
        filteredData = filteredMemos.filter(m => {
          const memoMonth = new Date(m.created_at).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
          return memoMonth === data.month;
        });
        title = `Tests for ${data.month}`;
        break;
        
      case 'testType':
        filteredData = filteredMemos.filter(m => m.test_type === data.name);
        title = `${data.name} Tests`;
        break;
        
      case 'performance':
        // Get tests from that specific week
        const weekIndex = parseInt(data.week.split(' ')[1]) - 1;
        const now = new Date();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - ((12 - weekIndex - 1) * 7));
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 7);
        
        filteredData = filteredMemos.filter(m => {
          const memoDate = new Date(m.created_at);
          return memoDate >= weekStart && memoDate < weekEnd;
        });
        title = `Tests for ${data.week}`;
        break;
    }
    
    setDrillDownData({ title, data: filteredData, isOpen: true });
  };

  const handleExportPDF = async () => {
    try {
      const { PDFGenerator } = await import('@/lib/pdfGenerator');
      
      const dashboardData = {
        activeMemos: analyticsData.totalTests,
        pendingTests: analyticsData.pendingTests,
        testsInProgress: analyticsData.totalTests - analyticsData.completedTests - analyticsData.pendingTests,
        completedToday: analyticsData.completedTests,
        monthlyTrendsData: performanceData,
        testStatusData: testTypeData,
        testRequestsData: monthlyData,
        performanceMetrics,
        filters
      };

      const pdfBlob = await PDFGenerator.generateDashboardReport(dashboardData);
      const filename = `analytics-dashboard-${new Date().toISOString().split('T')[0]}.pdf`;
      
      PDFGenerator.downloadBlob(pdfBlob, filename);
      
      toast({ 
        title: "Export Complete", 
        description: "Analytics dashboard exported as PDF successfully." 
      });
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "Export Failed",
        description: "Failed to export analytics report",
        variant: "destructive"
      });
    }
  };

  const handleExportCSV = async () => {
    try {
      const headers = ['Memo Ref', 'Date', 'Test Type', 'Status', 'Product', 'Plant', 'Officer', 'Scheduled Date', 'Completed Date'];
      const rows = filteredMemos.map(memo => [
        memo.memo_ref,
        new Date(memo.created_at).toLocaleDateString(),
        memo.test_type || 'Unknown',
        memo.status,
        memo.product_type,
        memo.plant_name || 'Unknown',
        memo.officer_id,
        memo.scheduled_date ? new Date(memo.scheduled_date).toLocaleDateString() : '',
        memo.completed_date ? new Date(memo.completed_date).toLocaleDateString() : ''
      ]);
      
      const csvContent = [headers, ...rows]
        .map(row => row.map(cell => `"${cell}"`).join(','))
        .join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-data-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "CSV Export Complete",
        description: `Exported ${filteredMemos.length} records to CSV`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export CSV",
        variant: "destructive"
      });
    }
  };

  const handleMemoClick = (memo: Memo) => {
    // Navigate to Test Result Manager with memo pre-selected
    const url = `/test-result-manager?memo=${memo.memo_ref}`;
    window.location.href = url;
  };

  const clearFilters = () => {
    setFilters({
      dateRange: { start: '', end: '' },
      plantId: 'all',
      productCategory: 'all',
      testType: 'all',
      timePeriod: '6months'
    });
  };

  if (isLoading) {
    return (
      <LabLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Activity className="h-8 w-8 animate-spin mx-auto mb-4" />
            <p>Loading analytics data...</p>
          </div>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
            <p className="text-muted-foreground">
              Laboratory performance metrics with real-time data and drill-down capabilities
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={handleExportPDF}>
              <FileText className="h-4 w-4 mr-2" />
              Export PDF
            </Button>
            <Button onClick={() => setIsCustomGraphOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              New Graph
            </Button>
          </div>
        </div>

        {/* Advanced Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Advanced Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
              <div>
                <Label>Start Date</Label>
                <Input
                  type="date"
                  value={filters.dateRange.start}
                  onChange={(e) => setFilters(prev => ({
                    ...prev,
                    dateRange: { ...prev.dateRange, start: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label>End Date</Label>
                <Input
                  type="date"
                  value={filters.dateRange.end}
                  onChange={(e) => setFilters(prev => ({
                    ...prev,
                    dateRange: { ...prev.dateRange, end: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label>Plant</Label>
                <Select value={filters.plantId} onValueChange={(value) => setFilters(prev => ({ ...prev, plantId: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="All plants" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Plants</SelectItem>
                    {plants.map(plant => (
                      <SelectItem key={plant.plant_id} value={plant.plant_id}>
                        {plant.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Product Category</Label>
                <Select value={filters.productCategory} onValueChange={(value) => setFilters(prev => ({ ...prev, productCategory: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="All products" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Products</SelectItem>
                    {productCategories.map(cat => (
                      <SelectItem key={cat.category_id} value={cat.name}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Test Type</Label>
                <Select value={filters.testType} onValueChange={(value) => setFilters(prev => ({ ...prev, testType: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="All tests" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tests</SelectItem>
                    {testTypes.map(type => (
                      <SelectItem key={type.type_id} value={type.name}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Time Period</Label>
                <Select value={filters.timePeriod} onValueChange={(value) => setFilters(prev => ({ ...prev, timePeriod: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1month">Last Month</SelectItem>
                    <SelectItem value="3months">Last 3 Months</SelectItem>
                    <SelectItem value="6months">Last 6 Months</SelectItem>
                    <SelectItem value="1year">Last Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-between items-center mt-4">
              <Badge variant="secondary">
                Showing {filteredMemos.length} of {memos.length} records
              </Badge>
              <Button variant="outline" onClick={clearFilters}>
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tests</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.totalTests}</div>
              <p className="text-xs text-muted-foreground">
                From {memos.length} total records
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.completionRate}%</div>
              <p className="text-xs text-muted-foreground">
                {analyticsData.completedTests} of {analyticsData.totalTests} completed
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Tests/Week</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{performanceMetrics.testsPerWeek}</div>
              <p className="text-xs text-muted-foreground">
                {performanceMetrics.delayedTests} delayed tests
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">On-Time Rate</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{performanceMetrics.onTimeCompletionRate}%</div>
              <p className="text-xs text-muted-foreground">
                Avg {performanceMetrics.avgTurnaroundDays} days turnaround
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Charts with Drill-Down */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Monthly Test Volume (Click to drill down)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar 
                    dataKey="completed" 
                    fill="#8884d8" 
                    name="Completed" 
                    onClick={(data) => handleChartClick('monthly', data)}
                    className="cursor-pointer"
                  />
                  <Bar 
                    dataKey="pending" 
                    fill="#82ca9d" 
                    name="Pending"
                    onClick={(data) => handleChartClick('monthly', data)}
                    className="cursor-pointer"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChartIcon className="h-5 w-5" />
                Test Distribution by Type (Click to filter)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={testTypeData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    onClick={(data) => handleChartClick('testType', data)}
                    className="cursor-pointer"
                  >
                    {testTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Performance Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LineChartIcon className="h-5 w-5" />
              Performance Trends (Click points for weekly details)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="efficiency" 
                  stroke="#8884d8" 
                  name="Efficiency %" 
                  onClick={(data) => handleChartClick('performance', data)}
                  className="cursor-pointer"
                />
                <Line 
                  type="monotone" 
                  dataKey="onTime" 
                  stroke="#82ca9d" 
                  name="On-time Delivery %" 
                  onClick={(data) => handleChartClick('performance', data)}
                  className="cursor-pointer"
                />
                <Line 
                  type="monotone" 
                  dataKey="testsPerWeek" 
                  stroke="#ffc658" 
                  name="Tests per Week"
                  onClick={(data) => handleChartClick('performance', data)}
                  className="cursor-pointer"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Custom Graphs Section */}
        {customGraphs.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Custom Graphs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {customGraphs.map(graph => (
                  <Card key={graph.graph_id} className="cursor-pointer hover:shadow-md">
                    <CardHeader>
                      <CardTitle className="text-sm">{graph.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-muted-foreground">
                        {graph.chart_type} chart: {graph.x_field} vs {graph.y_field}
                      </p>
                      <div className="flex justify-between mt-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => analyticsService.deleteCustomGraph(graph.graph_id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Drill-Down Modal */}
        <Dialog open={drillDownData.isOpen} onOpenChange={(open) => setDrillDownData(prev => ({ ...prev, isOpen: open }))}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{drillDownData.title}</DialogTitle>
              <DialogDescription>
                Detailed records for the selected data point ({drillDownData.data.length} records)
              </DialogDescription>
            </DialogHeader>
            
            <div className="mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Memo Ref</TableHead>
                    <TableHead>Test Type</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Plant</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {drillDownData.data.map(memo => (
                    <TableRow key={memo.id}>
                      <TableCell className="font-medium">{memo.memo_ref}</TableCell>
                      <TableCell>{memo.test_type}</TableCell>
                      <TableCell>{memo.product_type}</TableCell>
                      <TableCell>{memo.plant_name}</TableCell>
                      <TableCell>
                        <Badge variant={memo.status === 'completed' ? 'default' : 'secondary'}>
                          {memo.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(memo.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleMemoClick(memo)}
                        >
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setDrillDownData(prev => ({ ...prev, isOpen: false }))}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Custom Graph Creator Dialog */}
        <Dialog open={isCustomGraphOpen} onOpenChange={setIsCustomGraphOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Custom Graph</DialogTitle>
              <DialogDescription>
                Build a custom chart using your lab data fields
              </DialogDescription>
            </DialogHeader>
            
            <CustomGraphCreator userId="current_user" />
          </DialogContent>
        </Dialog>
      </div>
    </LabLayout>
  );
}