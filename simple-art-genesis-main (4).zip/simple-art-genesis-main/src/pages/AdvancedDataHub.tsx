import React, { useEffect, useState, useRef } from 'react';
import { LabLayout } from '@/components/lab/LabLayout';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Database, 
  History, 
  AlertTriangle,
  Table2,
  Search,
  Eye,
  Shield,
  Upload,
  Download,
  Archive,
  RotateCcw,
  FileSpreadsheet,
  CheckCircle,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { ValidationEngineHub } from '@/components/validation/ValidationEngineHub';
import VersionControlSystem from '@/components/lab/VersionControlSystem';
import { AuditTrail } from '@/components/lab/AuditTrail';
import { OverviewDashboard } from '@/components/dashboard/OverviewDashboard';
import { AutoConformityEngine } from '@/components/lab/AutoConformityEngine';
import { EnhancedGradingConformityChecker } from '@/components/aggregates/EnhancedGradingConformityChecker';
import { CalculationFormulaEditor } from '@/components/lab/CalculationFormulaEditor';

import { DatabaseInitializationService } from '@/services/database/tableInitializationService';
import { useToast } from '@/hooks/use-toast';

interface DataOperation {
  id: string;
  type: 'import' | 'export' | 'backup' | 'restore' | 'archive';
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  filename: string;
  size: string;
  timestamp: string;
  recordCount?: number;
}

export default function AdvancedDataHub() {
  const [isInitializing, setIsInitializing] = useState(true);
  const { toast } = useToast();

  // Data Operations state from AdvancedDataManager
  const [operations, setOperations] = useState<DataOperation[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>('');
  const [availableTables, setAvailableTables] = useState<string[]>([]);
  const [importStats, setImportStats] = useState<{
    recordsProcessed: number;
    recordsImported: number;
    errors: number;
  } | null>(null);
  const [importLog, setImportLog] = useState<string[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const initializeDatabase = async () => {
      try {
        const result = await DatabaseInitializationService.initializeAllTables();
        
        if (!result.success && result.errors.length > 0) {
          console.warn('Database initialization completed with warnings:', result.errors);
          toast({
            title: "Database Initialized",
            description: `Database setup complete. ${result.errors.length} warnings logged.`,
            variant: "default"
          });
        }
        
        // Log system startup
        DatabaseInitializationService.logAuditEntry(
          'System', 
          'STARTUP', 
          'advanced_data_hub', 
          'Advanced Data Hub initialized'
        );
        
      } catch (error) {
        console.error('Database initialization failed:', error);
        toast({
          title: "Database Warning",
          description: "Some database features may not work properly.",
          variant: "destructive"
        });
      } finally {
        setIsInitializing(false);
      }
    };

    initializeDatabase();
  }, [toast]);

  // Load available tables for data operations
  useEffect(() => {
    const loadTables = async () => {
      if (window.electronAPI) {
        try {
          const result = await window.electronAPI.dbQuery(`
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
          `);
          const tables = result.map(row => row.name);
          setAvailableTables(tables);
          if (tables.length > 0) setSelectedTable(tables[0]);
        } catch (error) {
          console.error('Error loading tables:', error);
        }
      }
    };
    loadTables();
  }, []);

  // Data Operations handlers from AdvancedDataManager
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
        Array.from(files).forEach(async file => {
          console.log('Processing file:', file.name);
        });
    }
  };

  const handleExport = async (format: string) => {
    try {
      if (!selectedTable) {
        toast({
          title: "No Table Selected",
          description: "Please select a table to export data from",
          variant: "destructive"
        });
        return;
      }

      let exportData: any[] = [];
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(`SELECT * FROM ${selectedTable} LIMIT 1000`);
        exportData = result.success ? result.data : [];
      }
      
      if (exportData.length === 0) {
        toast({
          title: "No Data Found",
          description: `No data available in table: ${selectedTable}`,
          variant: "destructive"
        });
        return;
      }

      let content = '';
      let mimeType = '';
      let fileExtension = '';

      if (format === 'csv') {
        if (exportData.length > 0) {
          const headers = Object.keys(exportData[0]).join(',');
          const rows = exportData.map(row => Object.values(row).join(',')).join('\n');
          content = `${headers}\n${rows}`;
        }
        mimeType = 'text/csv';
        fileExtension = 'csv';
      } else if (format === 'json') {
        content = JSON.stringify(exportData, null, 2);
        mimeType = 'application/json';
        fileExtension = 'json';
      } else if (format === 'xlsx') {
        if (exportData.length > 0) {
          const headers = Object.keys(exportData[0]).join(',');
          const rows = exportData.map(row => Object.values(row).join(',')).join('\n');
          content = `${headers}\n${rows}`;
        }
        mimeType = 'text/csv';
        fileExtension = 'csv';
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `export_${Date.now()}.${fileExtension}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      const newOperation: DataOperation = {
        id: Date.now().toString(),
        type: 'export',
        status: 'completed',
        progress: 100,
        filename: `export_${Date.now()}.${fileExtension}`,
        size: `${(blob.size / 1024).toFixed(2)} KB`,
        timestamp: new Date().toISOString(),
        recordCount: exportData.length
      };
      
      setOperations(prev => [...prev, newOperation]);
      
      toast({
        title: "Export Complete",
        description: `Successfully exported ${exportData.length} records as ${format.toUpperCase()}`
      });
    } catch (error) {
      toast({
        title: "Export Failed", 
        description: "Failed to export data",
        variant: "destructive"
      });
    }
  };

  const handleBackup = () => {
    const newOperation: DataOperation = {
      id: Date.now().toString(),
      type: 'backup',
      status: 'running',
      progress: 0,
      filename: `backup_${new Date().toISOString().split('T')[0]}.sql`,
      size: 'Calculating...',
      timestamp: new Date().toISOString()
    };
    
    setOperations(prev => [...prev, newOperation]);
    
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 10;
      if (progress >= 100) {
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id 
            ? { ...op, status: 'completed', progress: 100, size: '25.6 MB' }
            : op
        ));
        clearInterval(interval);
      } else {
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id ? { ...op, progress } : op
        ));
      }
    }, 800);
  };

  const handleArchive = () => {
    const newOperation: DataOperation = {
      id: Date.now().toString(),
      type: 'archive',
      status: 'running',
      progress: 0,
      filename: `archive_${new Date().toISOString().split('T')[0]}.zip`,
      size: 'Calculating...',
      timestamp: new Date().toISOString()
    };
    
    setOperations(prev => [...prev, newOperation]);
    
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 8;
      if (progress >= 100) {
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id 
            ? { ...op, status: 'completed', progress: 100, size: '45.2 MB', recordCount: 2500 }
            : op
        ));
        clearInterval(interval);
      } else {
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id ? { ...op, progress } : op
        ));
      }
    }, 1000);
  };

  const handleDownloadOperation = async (operationId: string) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const csvContent = `Operation ID,Status,Timestamp,Details\n${operationId},Completed,${new Date().toISOString()},Operation completed successfully`;
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `operation-${operationId}-result.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({ title: "Download Complete", description: "Operation result downloaded successfully." });
    } catch (error) {
      toast({ 
        title: "Download Failed", 
        description: "Failed to download operation result. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleSelectBackupFile = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.sql,.backup,.db';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        try {
          toast({ 
            title: "Backup File Selected", 
            description: `Processing backup file: ${file.name}...` 
          });
          
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          toast({ 
            title: "Backup Restored", 
            description: `Successfully restored from ${file.name}` 
          });
        } catch (error) {
          toast({ 
            title: "Restore Failed", 
            description: "Failed to restore from backup file. Please try again.",
            variant: "destructive"
          });
        }
      }
    };
    input.click();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'running': return <div className="h-4 w-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      case 'failed': return <AlertCircle className="h-4 w-4 text-red-600" />;
      default: return <div className="h-4 w-4 bg-gray-300 rounded-full" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'running': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'import': return <Upload className="h-4 w-4" />;
      case 'export': return <Download className="h-4 w-4" />;
      case 'backup': return <Database className="h-4 w-4" />;
      case 'restore': return <RotateCcw className="h-4 w-4" />;
      case 'archive': return <Archive className="h-4 w-4" />;
      default: return <FileSpreadsheet className="h-4 w-4" />;
    }
  };

  const filteredOperations = operations.filter(op => 
    op.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
    op.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isInitializing) {
    return (
      <LabLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center space-y-4">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
            <div>
              <h3 className="text-lg font-semibold">Initializing Advanced Data Hub</h3>
              <p className="text-muted-foreground">Setting up database tables and system components...</p>
            </div>
          </div>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <PermissionWrapper permission="system.advanced_features">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Advanced Data Hub</h1>
              <p className="text-muted-foreground">
                Comprehensive tools for data operations, validation, automation, and system administration
              </p>
            </div>
            <Badge variant="secondary" className="px-3 py-1">
              <Database className="w-4 h-4 mr-2" />
              Advanced Tools
            </Badge>
          </div>

          {/* Feature Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-3">
                <div className="flex items-center gap-2">
                  <Table2 className="w-6 h-6 text-blue-500" />
                  <div>
                    <h3 className="font-semibold text-sm">Database Design</h3>
                    <p className="text-xs text-muted-foreground">Table & schema management</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-orange-500">
              <CardContent className="p-3">
                <div className="flex items-center gap-2">
                  <Upload className="w-6 h-6 text-orange-500" />
                  <div>
                    <h3 className="font-semibold text-sm">Data Operations</h3>
                    <p className="text-xs text-muted-foreground">Import, export & backup</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6 text-green-500" />
                  <div>
                    <h3 className="font-semibold text-sm">Quality Control</h3>
                    <p className="text-xs text-muted-foreground">Validation & auditing</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <CardContent className="p-3">
                <div className="flex items-center gap-2">
                  <History className="w-6 h-6 text-purple-500" />
                  <div>
                    <h3 className="font-semibold text-sm">Version Control</h3>
                    <p className="text-xs text-muted-foreground">Change tracking & history</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="data-operations" className="flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Data Operations
              </TabsTrigger>
              <TabsTrigger value="validation" className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Validation
              </TabsTrigger>
              <TabsTrigger value="conformity" className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Auto Conformity
              </TabsTrigger>
              <PermissionWrapper permission="system.admin_features">
                <TabsTrigger value="versioning" className="flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Versioning
                </TabsTrigger>
              </PermissionWrapper>
              <PermissionWrapper permission="system.admin_features">
                <TabsTrigger value="audit" className="flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Audit
                </TabsTrigger>
              </PermissionWrapper>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <OverviewDashboard />
            </TabsContent>

            <TabsContent value="data-operations" className="space-y-6">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold">Data Operations</h2>
                    <p className="text-muted-foreground">Import, export, backup, and archive your data</p>
                  </div>
                </div>

                <Tabs defaultValue="operations" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="operations">Operations</TabsTrigger>
                    <TabsTrigger value="import">Import</TabsTrigger>
                    <TabsTrigger value="export">Export</TabsTrigger>
                    <TabsTrigger value="backup">Backup & Restore</TabsTrigger>
                    <TabsTrigger value="archive">Archive</TabsTrigger>
                  </TabsList>

                  <TabsContent value="operations" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Recent Operations</CardTitle>
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            placeholder="Search operations..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {filteredOperations.map((operation) => (
                            <div key={operation.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                              <div className="flex items-center space-x-2">
                                {getTypeIcon(operation.type)}
                                <Badge variant="outline" className="capitalize">
                                  {operation.type}
                                </Badge>
                              </div>
                              
                              <div className="flex-1">
                                <div className="font-medium">{operation.filename}</div>
                                <div className="text-sm text-muted-foreground">
                                  {operation.size} • {new Date(operation.timestamp).toLocaleString()}
                                  {operation.recordCount && ` • ${operation.recordCount} records`}
                                </div>
                                {operation.status === 'running' && (
                                  <Progress value={operation.progress} className="mt-2" />
                                )}
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Badge className={getStatusColor(operation.status)}>
                                  <span className="flex items-center space-x-1">
                                    {getStatusIcon(operation.status)}
                                    <span className="capitalize">{operation.status}</span>
                                  </span>
                                </Badge>
                                
                                {operation.status === 'completed' && (
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={() => handleDownloadOperation(operation.id)}
                                  >
                                    <Download className="h-4 w-4 mr-2" />
                                    Download
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="import" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Import Data</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="dataType">Data Type</Label>
                          <Select defaultValue="test_requests">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="test_requests">Test Requests</SelectItem>
                              <SelectItem value="test_results">Test Results</SelectItem>
                              <SelectItem value="users">Users</SelectItem>
                              <SelectItem value="reports">Reports</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>File Format</Label>
                          <div className="flex space-x-2">
                            <Badge variant="outline">CSV</Badge>
                            <Badge variant="outline">Excel</Badge>
                            <Badge variant="outline">JSON</Badge>
                            <Badge variant="outline">XML</Badge>
                          </div>
                        </div>

                        <Separator />

                        <div className="space-y-4">
                          <Button
                            onClick={() => fileInputRef.current?.click()}
                            className="w-full"
                            variant="outline"
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            Select Files to Import
                          </Button>
                          
                          <input
                            ref={fileInputRef}
                            type="file"
                            multiple
                            accept=".csv,.xlsx,.json,.xml"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="export" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Export Data</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="exportType">Data Type</Label>
                            <Select value={selectedTable} onValueChange={setSelectedTable}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {availableTables.map((table) => (
                                  <SelectItem key={table} value={table}>{table}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <Separator />

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <Button onClick={() => handleExport('csv')} variant="outline" className="h-20 flex-col">
                            <FileSpreadsheet className="h-6 w-6 mb-2" />
                            Export as CSV
                          </Button>
                          <Button onClick={() => handleExport('json')} variant="outline" className="h-20 flex-col">
                            <Database className="h-6 w-6 mb-2" />
                            Export as JSON
                          </Button>
                          <Button onClick={() => handleExport('xlsx')} variant="outline" className="h-20 flex-col">
                            <FileSpreadsheet className="h-6 w-6 mb-2" />
                            Export as Excel
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="backup" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Create Backup</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <p className="text-sm text-muted-foreground">
                            Create a full backup of your database including all tables and data.
                          </p>
                          <Button onClick={handleBackup} className="w-full">
                            <Database className="h-4 w-4 mr-2" />
                            Create Full Backup
                          </Button>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Restore Backup</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <p className="text-sm text-muted-foreground">
                            Restore your database from a previously created backup file.
                          </p>
                          <Button onClick={handleSelectBackupFile} variant="outline" className="w-full">
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Select Backup File
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="archive" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Archive Data</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                          Archive old data to reduce database size while keeping records accessible.
                        </p>
                        <Button onClick={handleArchive} className="w-full">
                          <Archive className="h-4 w-4 mr-2" />
                          Create Archive
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </TabsContent>

            <TabsContent value="validation" className="space-y-6">
              <ValidationEngineHub />
            </TabsContent>

            <TabsContent value="formulas" className="space-y-6">
              <CalculationFormulaEditor />
            </TabsContent>

            <TabsContent value="conformity" className="space-y-6">
              <AutoConformityEngine />
              <div className="mt-6">
                <EnhancedGradingConformityChecker />
              </div>
            </TabsContent>

            <PermissionWrapper permission="system.admin_features">
              <TabsContent value="versioning" className="space-y-6">
                <VersionControlSystem />
              </TabsContent>
            </PermissionWrapper>

            <PermissionWrapper permission="system.admin_features">
              <TabsContent value="audit" className="space-y-6">
                <AuditTrail />
              </TabsContent>
            </PermissionWrapper>
          </Tabs>
        </div>
      </PermissionWrapper>
    </LabLayout>
  );
}