import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  FlaskConical, 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Calendar,
  Target,
  Beaker,
  AlertTriangle,
  CheckCircle,
  Database,
  Download,
  FileText,
  History,
  Link,
  Copy,
  Save,
  RefreshCw,
  RotateCcw,
  Eye
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { LabLayout } from '@/components/lab/LabLayout';
import {
  useProductCategories, 
  useCementTypes, 
  useAggregates, 
  useAdmixtures, 
  useFreeWaterTypes 
} from '@/hooks/useReferenceData';

// ============= MIX DESIGN INTERFACES =============

interface MixDesign {
  id: string;
  name: string;
  product_type: string; // blocks, pavers, kerbs, etc.
  category_id: string;
  cement_type_id: string;
  cement_content: number; // kg/m³
  water_cement_ratio: number;
  free_water_id: string;
  aggregates: Array<{
    aggregate_id: string;
    percentage: number;
    weight_per_m3: number;
  }>;
  admixtures: Array<{
    admixture_id: string;
    dosage: number; // kg/m³ or %
    dosage_unit: 'kg/m3' | 'percent';
  }>;
  effective_date_start: string;
  effective_date_end?: string;
  trial_results?: {
    compressive_strength_7d?: number;
    compressive_strength_28d?: number;
    slump?: number;
    density?: number;
    water_absorption?: number;
    notes?: string;
    linked_memo_ref?: string;
    is_manual_entry?: boolean;
  };
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface MixDesignFormData {
  name: string;
  product_type: string;
  category_id: string;
  cement_type_id: string;
  cement_content: number;
  water_cement_ratio: number;
  free_water_id: string;
  effective_date_start: string;
  effective_date_end: string;
  aggregates: Array<{
    aggregate_id: string;
    percentage: number;
    weight_per_m3: number;
  }>;
  admixtures: Array<{
    admixture_id: string;
    dosage: number;
    dosage_unit: 'kg/m3' | 'percent';
  }>;
  trial_results: {
    compressive_strength_7d: number;
    compressive_strength_28d: number;
    slump: number;
    density: number;
    water_absorption: number;
    notes: string;
    linked_memo_ref: string;
    is_manual_entry: boolean;
  };
}

interface MixDesignVersion {
  version_id: string;
  mix_id: string;
  snapshot_json: string;
  created_at: string;
  user_id: string;
}

interface MixDesignTemplate {
  template_id: string;
  name: string;
  product_type: string;
  template_data: string; // JSON
  created_by: string;
  created_at: string;
  is_active: boolean;
}

interface AuditLog {
  log_id: string;
  action: string;
  target_id: string;
  user_id: string;
  timestamp: string;
  details: string;
}

// ============= MIX DESIGN SERVICE =============

class MixDesignService {
  private async executeQuery(query: string, params: any[] = []): Promise<any> {
    try {
      if (window.electronAPI) {
        return await window.electronAPI.dbQuery(query, params);
      } else {
        // Web fallback - localStorage simulation
        return this.simulateQuery(query, params);
      }
    } catch (error) {
      console.error('Mix design query failed:', error);
      throw error;
    }
  }

  private simulateQuery(query: string, params: any[]): any {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('create table')) {
      return { success: true };
    }
    
    if (lowerQuery.includes('insert')) {
      const data = JSON.parse(localStorage.getItem('mix_designs') || '[]');
      const newRecord = { 
        id: `mix_${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true,
        ...params 
      };
      data.push(newRecord);
      localStorage.setItem('mix_designs', JSON.stringify(data));
      return { success: true, lastInsertRowid: newRecord.id };
    }
    
    if (lowerQuery.includes('select')) {
      const data = JSON.parse(localStorage.getItem('mix_designs') || '[]');
      return data;
    }
    
    if (lowerQuery.includes('update')) {
      const data = JSON.parse(localStorage.getItem('mix_designs') || '[]');
      // Simple update simulation
      localStorage.setItem('mix_designs', JSON.stringify(data));
      return { success: true };
    }
    
    return { success: true };
  }

  async initializeMixDesignTables(): Promise<void> {
    // Main mix designs table
    const createMixDesignsQuery = `
      CREATE TABLE IF NOT EXISTS mix_designs (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        product_type TEXT NOT NULL,
        category_id TEXT NOT NULL,
        cement_type_id TEXT NOT NULL,
        cement_content REAL NOT NULL,
        water_cement_ratio REAL NOT NULL,
        free_water_id TEXT NOT NULL,
        aggregates TEXT NOT NULL, -- JSON
        admixtures TEXT NOT NULL, -- JSON
        effective_date_start TEXT NOT NULL,
        effective_date_end TEXT,
        trial_results TEXT, -- JSON
        is_active BOOLEAN DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `;
    
    // Version control table
    const createVersionsQuery = `
      CREATE TABLE IF NOT EXISTS mix_design_versions (
        version_id TEXT PRIMARY KEY,
        mix_id TEXT NOT NULL,
        snapshot_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        user_id TEXT NOT NULL,
        FOREIGN KEY (mix_id) REFERENCES mix_designs (id)
      )
    `;
    
    // Templates table
    const createTemplatesQuery = `
      CREATE TABLE IF NOT EXISTS mix_design_templates (
        template_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        product_type TEXT NOT NULL,
        template_data TEXT NOT NULL, -- JSON
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1
      )
    `;
    
    // Audit log table
    const createAuditQuery = `
      CREATE TABLE IF NOT EXISTS mix_design_audit_log (
        log_id TEXT PRIMARY KEY,
        action TEXT NOT NULL,
        target_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        details TEXT
      )
    `;
    
    await this.executeQuery(createMixDesignsQuery);
    await this.executeQuery(createVersionsQuery);
    await this.executeQuery(createTemplatesQuery);
    await this.executeQuery(createAuditQuery);
  }

  // ============= CORE MIX DESIGN METHODS =============

  async getAllMixDesigns(): Promise<MixDesign[]> {
    return await this.executeQuery('SELECT * FROM mix_designs ORDER BY created_at DESC');
  }

  async getMixDesignsByProductType(productType: string): Promise<MixDesign[]> {
    return await this.executeQuery(
      'SELECT * FROM mix_designs WHERE product_type = ? AND is_active = 1 ORDER BY effective_date_start DESC',
      [productType]
    );
  }

  async getActiveMixDesign(productType: string, date: string): Promise<MixDesign | null> {
    const results = await this.executeQuery(`
      SELECT * FROM mix_designs 
      WHERE product_type = ? 
        AND is_active = 1 
        AND effective_date_start <= ? 
        AND (effective_date_end IS NULL OR effective_date_end >= ?)
      ORDER BY effective_date_start DESC 
      LIMIT 1
    `, [productType, date, date]);
    
    return results.length > 0 ? results[0] : null;
  }

  async saveMixDesign(mixDesign: MixDesignFormData, userId: string = 'system'): Promise<string> {
    const id = `mix_${Date.now()}`;
    
    // Save main mix design
    await this.executeQuery(`
      INSERT INTO mix_designs (
        id, name, product_type, category_id, cement_type_id, cement_content,
        water_cement_ratio, free_water_id, aggregates, admixtures,
        effective_date_start, effective_date_end, trial_results,
        is_active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      id,
      mixDesign.name,
      mixDesign.product_type,
      mixDesign.category_id,
      mixDesign.cement_type_id,
      mixDesign.cement_content,
      mixDesign.water_cement_ratio,
      mixDesign.free_water_id,
      JSON.stringify(mixDesign.aggregates),
      JSON.stringify(mixDesign.admixtures),
      mixDesign.effective_date_start,
      mixDesign.effective_date_end || null,
      JSON.stringify(mixDesign.trial_results),
      1,
      new Date().toISOString(),
      new Date().toISOString()
    ]);

    // Create version snapshot
    await this.createVersion(id, mixDesign, userId);
    
    // Log audit
    await this.logAudit('create_mix', id, userId, `Created mix design: ${mixDesign.name}`);

    return id;
  }

  async updateMixDesign(id: string, mixDesign: Partial<MixDesignFormData>, userId: string = 'system'): Promise<void> {
    // Update main record
    const setClause = Object.keys(mixDesign)
      .map(key => `${key} = ?`)
      .join(', ');
    
    const values = Object.values(mixDesign);
    values.push(new Date().toISOString()); // updated_at
    values.push(id); // WHERE id = ?

    await this.executeQuery(`
      UPDATE mix_designs 
      SET ${setClause}, updated_at = ?
      WHERE id = ?
    `, values);
    
    // Create version snapshot
    await this.createVersion(id, mixDesign, userId);
    
    // Log audit
    await this.logAudit('update_mix', id, userId, `Updated mix design: ${mixDesign.name || 'Unknown'}`);
  }

  async deleteMixDesign(id: string, userId: string = 'system'): Promise<void> {
    // Soft delete - mark as inactive
    await this.executeQuery(
      'UPDATE mix_designs SET is_active = 0, updated_at = ? WHERE id = ?',
      [new Date().toISOString(), id]
    );
    
    // Log audit
    await this.logAudit('delete_mix', id, userId, 'Deleted mix design');
  }

  // ============= VERSION CONTROL METHODS =============

  async createVersion(mixId: string, mixData: any, userId: string): Promise<string> {
    const versionId = `ver_${Date.now()}`;
    
    await this.executeQuery(`
      INSERT INTO mix_design_versions (version_id, mix_id, snapshot_json, created_at, user_id)
      VALUES (?, ?, ?, ?, ?)
    `, [
      versionId,
      mixId,
      JSON.stringify(mixData),
      new Date().toISOString(),
      userId
    ]);
    
    return versionId;
  }

  async getVersionHistory(mixId: string): Promise<MixDesignVersion[]> {
    return await this.executeQuery(
      'SELECT * FROM mix_design_versions WHERE mix_id = ? ORDER BY created_at DESC',
      [mixId]
    );
  }

  async restoreVersion(versionId: string, userId: string): Promise<string> {
    // Get version data
    const versions = await this.executeQuery(
      'SELECT * FROM mix_design_versions WHERE version_id = ?',
      [versionId]
    );
    
    if (versions.length === 0) {
      throw new Error('Version not found');
    }
    
    const version = versions[0];
    const mixData = JSON.parse(version.snapshot_json);
    
    // Create new mix design from version
    const newId = await this.saveMixDesign(mixData, userId);
    
    // Log audit
    await this.logAudit('restore_version', newId, userId, `Restored from version: ${versionId}`);
    
    return newId;
  }

  // ============= EXPORT METHODS =============

  async exportToPDF(mixId: string, userId: string): Promise<void> {
    // Get mix design data
    const designs = await this.executeQuery('SELECT * FROM mix_designs WHERE id = ?', [mixId]);
    if (designs.length === 0) throw new Error('Mix design not found');
    
    const design = designs[0];
    
    // Here we would integrate with PDF generation service
    // For now, just log the export
    await this.logAudit('export_pdf', mixId, userId, `Exported PDF for: ${design.name}`);
  }

  async exportToCSV(designs: MixDesign[], userId: string): Promise<string> {
    const headers = [
      'ID', 'Name', 'Product Type', 'W/C Ratio', 'Cement Content', 
      'Effective Start', 'Effective End', '28d Strength', 'Created At'
    ];
    
    const rows = designs.map(design => [
      design.id,
      design.name,
      design.product_type,
      design.water_cement_ratio,
      design.cement_content,
      design.effective_date_start,
      design.effective_date_end || '',
      design.trial_results?.compressive_strength_28d || '',
      design.created_at
    ]);
    
    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
    
    // Log audit
    await this.logAudit('export_csv', 'bulk', userId, `Exported ${designs.length} mix designs to CSV`);
    
    return csvContent;
  }

  // ============= TEMPLATE METHODS =============

  async saveAsTemplate(mixId: string, templateName: string, userId: string): Promise<string> {
    // Get mix design
    const designs = await this.executeQuery('SELECT * FROM mix_designs WHERE id = ?', [mixId]);
    if (designs.length === 0) throw new Error('Mix design not found');
    
    const design = designs[0];
    const templateId = `tpl_${Date.now()}`;
    
    await this.executeQuery(`
      INSERT INTO mix_design_templates (template_id, name, product_type, template_data, created_by, created_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [
      templateId,
      templateName,
      design.product_type,
      JSON.stringify(design),
      userId,
      new Date().toISOString(),
      1
    ]);
    
    await this.logAudit('save_template', templateId, userId, `Saved template: ${templateName}`);
    
    return templateId;
  }

  async getTemplates(productType?: string): Promise<MixDesignTemplate[]> {
    const query = productType 
      ? 'SELECT * FROM mix_design_templates WHERE product_type = ? AND is_active = 1 ORDER BY created_at DESC'
      : 'SELECT * FROM mix_design_templates WHERE is_active = 1 ORDER BY created_at DESC';
    
    const params = productType ? [productType] : [];
    return await this.executeQuery(query, params);
  }

  async loadFromTemplate(templateId: string): Promise<MixDesignFormData> {
    const templates = await this.executeQuery(
      'SELECT * FROM mix_design_templates WHERE template_id = ?',
      [templateId]
    );
    
    if (templates.length === 0) {
      throw new Error('Template not found');
    }
    
    const templateData = JSON.parse(templates[0].template_data);
    
    // Convert to form data format, removing ID and timestamps
    return {
      name: `${templateData.name} (from template)`,
      product_type: templateData.product_type,
      category_id: templateData.category_id,
      cement_type_id: templateData.cement_type_id,
      cement_content: templateData.cement_content,
      water_cement_ratio: templateData.water_cement_ratio,
      free_water_id: templateData.free_water_id,
      effective_date_start: '',
      effective_date_end: '',
      aggregates: templateData.aggregates || [],
      admixtures: templateData.admixtures || [],
      trial_results: {
        compressive_strength_7d: 0,
        compressive_strength_28d: 0,
        slump: 0,
        density: 0,
        water_absorption: 0,
        notes: '',
        linked_memo_ref: '',
        is_manual_entry: true
      }
    };
  }

  // ============= TRIAL RESULTS LINKING METHODS =============

  async getMemoReferences(): Promise<Array<{memo_ref: string, created_at: string}>> {
    try {
      return await this.executeQuery('SELECT memo_ref, created_at FROM memos ORDER BY created_at DESC LIMIT 100');
    } catch {
      return []; // Table may not exist
    }
  }

  async getTestResults(memoRef: string): Promise<any> {
    try {
      // This would query the appropriate test results table based on memo
      return await this.executeQuery(
        'SELECT * FROM test_results WHERE memo_ref = ? ORDER BY created_at DESC LIMIT 1',
        [memoRef]
      );
    } catch {
      return null;
    }
  }

  // ============= AUDIT METHODS =============

  async logAudit(action: string, targetId: string, userId: string, details?: string): Promise<void> {
    const logId = `log_${Date.now()}`;
    
    await this.executeQuery(`
      INSERT INTO mix_design_audit_log (log_id, action, target_id, user_id, timestamp, details)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      logId,
      action,
      targetId,
      userId,
      new Date().toISOString(),
      details || ''
    ]);
  }

  async getAuditLog(targetId?: string): Promise<AuditLog[]> {
    const query = targetId
      ? 'SELECT * FROM mix_design_audit_log WHERE target_id = ? ORDER BY timestamp DESC'
      : 'SELECT * FROM mix_design_audit_log ORDER BY timestamp DESC LIMIT 100';
    
    const params = targetId ? [targetId] : [];
    return await this.executeQuery(query, params);
  }
}

const mixDesignService = new MixDesignService();

// ============= MIX DESIGN FORM COMPONENT =============

interface MixDesignFormProps {
  mixDesign?: MixDesign | null;
  onSave: (data: MixDesignFormData) => Promise<void>;
  onCancel: () => void;
  memoRefs?: Array<{memo_ref: string, created_at: string}>;
  templates?: MixDesignTemplate[];
  onLoadTemplate?: (templateId: string) => void;
}

const MixDesignForm: React.FC<MixDesignFormProps> = ({ 
  mixDesign, 
  onSave, 
  onCancel, 
  memoRefs = [], 
  templates = [],
  onLoadTemplate
}) => {
  const { data: categories } = useProductCategories();
  const { data: cementTypes } = useCementTypes();
  const { data: aggregates } = useAggregates();
  const { data: admixtures } = useAdmixtures();
  const { data: waterTypes } = useFreeWaterTypes();

  const [formData, setFormData] = useState<MixDesignFormData>({
    name: '',
    product_type: '',
    category_id: '',
    cement_type_id: '',
    cement_content: 0,
    water_cement_ratio: 0,
    free_water_id: '',
    effective_date_start: '',
    effective_date_end: '',
    aggregates: [],
    admixtures: [],
    trial_results: {
      compressive_strength_7d: 0,
      compressive_strength_28d: 0,
      slump: 0,
      density: 0,
      water_absorption: 0,
      notes: '',
      linked_memo_ref: '',
      is_manual_entry: true
    }
  });

  useEffect(() => {
    if (mixDesign) {
      setFormData({
        name: mixDesign.name,
        product_type: mixDesign.product_type,
        category_id: mixDesign.category_id,
        cement_type_id: mixDesign.cement_type_id,
        cement_content: mixDesign.cement_content,
        water_cement_ratio: mixDesign.water_cement_ratio,
        free_water_id: mixDesign.free_water_id,
        effective_date_start: mixDesign.effective_date_start,
        effective_date_end: mixDesign.effective_date_end || '',
        aggregates: mixDesign.aggregates,
        admixtures: mixDesign.admixtures,
        trial_results: {
          compressive_strength_7d: mixDesign.trial_results?.compressive_strength_7d || 0,
          compressive_strength_28d: mixDesign.trial_results?.compressive_strength_28d || 0,
          slump: mixDesign.trial_results?.slump || 0,
          density: mixDesign.trial_results?.density || 0,
          water_absorption: mixDesign.trial_results?.water_absorption || 0,
          notes: mixDesign.trial_results?.notes || '',
          linked_memo_ref: mixDesign.trial_results?.linked_memo_ref || '',
          is_manual_entry: mixDesign.trial_results?.is_manual_entry ?? true
        }
      });
    }
  }, [mixDesign]);

  const addAggregate = () => {
    setFormData(prev => ({
      ...prev,
      aggregates: [...prev.aggregates, { aggregate_id: '', percentage: 0, weight_per_m3: 0 }]
    }));
  };

  const removeAggregate = (index: number) => {
    setFormData(prev => ({
      ...prev,
      aggregates: prev.aggregates.filter((_, i) => i !== index)
    }));
  };

  const updateAggregate = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      aggregates: prev.aggregates.map((agg, i) => 
        i === index ? { ...agg, [field]: value } : agg
      )
    }));
  };

  const addAdmixture = () => {
    setFormData(prev => ({
      ...prev,
      admixtures: [...prev.admixtures, { admixture_id: '', dosage: 0, dosage_unit: 'kg/m3' }]
    }));
  };

  const removeAdmixture = (index: number) => {
    setFormData(prev => ({
      ...prev,
      admixtures: prev.admixtures.filter((_, i) => i !== index)
    }));
  };

  const updateAdmixture = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      admixtures: prev.admixtures.map((adm, i) => 
        i === index ? { ...adm, [field]: value } : adm
      )
    }));
  };

  const handleMemoRefChange = async (memoRef: string) => {
    setFormData(prev => ({
      ...prev,
      trial_results: {
        ...prev.trial_results,
        linked_memo_ref: memoRef,
        is_manual_entry: !memoRef
      }
    }));
    
    if (memoRef) {
      try {
        const testResults = await mixDesignService.getTestResults(memoRef);
        if (testResults && testResults.length > 0) {
          const result = testResults[0];
          setFormData(prev => ({
            ...prev,
            trial_results: {
              ...prev.trial_results,
              compressive_strength_7d: result.compressive_strength_7d || 0,
              compressive_strength_28d: result.compressive_strength_28d || 0,
              slump: result.slump || 0,
              density: result.density || 0,
              water_absorption: result.water_absorption || 0,
              is_manual_entry: false
            }
          }));
        }
      } catch (error) {
        console.error('Failed to load test results:', error);
      }
    }
  };

  const handleSubmit = async () => {
    await onSave(formData);
  };

  const filteredTemplates = templates.filter(t => t.product_type === formData.product_type);

  return (
    <div className="space-y-6">
      {/* Template Selection */}
      {!mixDesign && templates.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Copy className="h-5 w-5" />
              Load from Template
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Select onValueChange={onLoadTemplate}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select a template to load" />
                </SelectTrigger>
                <SelectContent>
                  {filteredTemplates.map(template => (
                    <SelectItem key={template.template_id} value={template.template_id}>
                      {template.name} ({template.product_type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Mix Design Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter mix design name"
              />
            </div>
            
            <div>
              <Label htmlFor="product_type">Product Type *</Label>
              <Select 
                value={formData.product_type} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, product_type: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select product type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="blocks">Blocks</SelectItem>
                  <SelectItem value="pavers">Pavers</SelectItem>
                  <SelectItem value="kerbs">Kerbs</SelectItem>
                  <SelectItem value="flags">Flags</SelectItem>
                  <SelectItem value="concrete">Concrete</SelectItem>
                  <SelectItem value="aggregates">Aggregates</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="category_id">Category</Label>
              <Select 
                value={formData.category_id} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, category_id: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map(cat => (
                    <SelectItem key={cat.category_id} value={cat.category_id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="cement_type_id">Cement Type *</Label>
              <Select 
                value={formData.cement_type_id} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, cement_type_id: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select cement type" />
                </SelectTrigger>
                <SelectContent>
                  {cementTypes?.map(cement => (
                    <SelectItem key={cement.cement_id} value={cement.cement_id}>
                      {cement.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="cement_content">Cement Content (kg/m³) *</Label>
              <Input
                id="cement_content"
                type="number"
                value={formData.cement_content}
                onChange={(e) => setFormData(prev => ({ ...prev, cement_content: parseFloat(e.target.value) || 0 }))}
              />
            </div>

            <div>
              <Label htmlFor="water_cement_ratio">Water/Cement Ratio *</Label>
              <Input
                id="water_cement_ratio"
                type="number"
                step="0.01"
                value={formData.water_cement_ratio}
                onChange={(e) => setFormData(prev => ({ ...prev, water_cement_ratio: parseFloat(e.target.value) || 0 }))}
              />
            </div>

            <div>
              <Label htmlFor="free_water_id">Free Water Type *</Label>
              <Select 
                value={formData.free_water_id} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, free_water_id: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select water type" />
                </SelectTrigger>
                <SelectContent>
                  {waterTypes?.map(water => (
                    <SelectItem key={water.water_id} value={water.water_id}>
                      {water.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="effective_date_start">Effective Start Date *</Label>
              <Input
                id="effective_date_start"
                type="date"
                value={formData.effective_date_start}
                onChange={(e) => setFormData(prev => ({ ...prev, effective_date_start: e.target.value }))}
              />
            </div>
            
            <div>
              <Label htmlFor="effective_date_end">Effective End Date</Label>
              <Input
                id="effective_date_end"
                type="date"
                value={formData.effective_date_end}
                onChange={(e) => setFormData(prev => ({ ...prev, effective_date_end: e.target.value }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Aggregates */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Aggregates
            <Button onClick={addAggregate} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Aggregate
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {formData.aggregates.map((aggregate, index) => (
              <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <Label>Aggregate Type</Label>
                  <Select 
                    value={aggregate.aggregate_id} 
                    onValueChange={(value) => updateAggregate(index, 'aggregate_id', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select aggregate" />
                    </SelectTrigger>
                    <SelectContent>
                      {aggregates?.map(agg => (
                        <SelectItem key={agg.aggregate_id} value={agg.aggregate_id}>
                          {agg.name} ({agg.size_range})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="w-32">
                  <Label>Percentage (%)</Label>
                  <Input
                    type="number"
                    value={aggregate.percentage}
                    onChange={(e) => updateAggregate(index, 'percentage', parseFloat(e.target.value) || 0)}
                  />
                </div>
                
                <div className="w-32">
                  <Label>Weight (kg/m³)</Label>
                  <Input
                    type="number"
                    value={aggregate.weight_per_m3}
                    onChange={(e) => updateAggregate(index, 'weight_per_m3', parseFloat(e.target.value) || 0)}
                  />
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeAggregate(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Admixtures */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Admixtures
            <Button onClick={addAdmixture} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Admixture
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {formData.admixtures.map((admixture, index) => (
              <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <Label>Admixture Type</Label>
                  <Select 
                    value={admixture.admixture_id} 
                    onValueChange={(value) => updateAdmixture(index, 'admixture_id', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select admixture" />
                    </SelectTrigger>
                    <SelectContent>
                      {admixtures?.map(adm => (
                        <SelectItem key={adm.admixture_id} value={adm.admixture_id}>
                          {adm.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="w-32">
                  <Label>Dosage</Label>
                  <Input
                    type="number"
                    value={admixture.dosage}
                    onChange={(e) => updateAdmixture(index, 'dosage', parseFloat(e.target.value) || 0)}
                  />
                </div>
                
                <div className="w-32">
                  <Label>Unit</Label>
                  <Select 
                    value={admixture.dosage_unit} 
                    onValueChange={(value) => updateAdmixture(index, 'dosage_unit', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg/m3">kg/m³</SelectItem>
                      <SelectItem value="percent">%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeAdmixture(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Trial Results with Linking */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Beaker className="h-5 w-5" />
            Trial Results (Optional)
          </CardTitle>
          <CardDescription>
            Link to existing test results or enter manually
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Data Source Toggle */}
          <div className="flex items-center gap-4 p-4 border rounded-lg">
            <div className="flex items-center gap-2">
              <Switch 
                checked={!formData.trial_results.is_manual_entry}
                onCheckedChange={(checked) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    is_manual_entry: !checked
                  }
                }))}
              />
              <Label>Link to Lab Test Results</Label>
            </div>
            
            {!formData.trial_results.is_manual_entry && (
              <div className="flex-1">
                <Select 
                  value={formData.trial_results.linked_memo_ref}
                  onValueChange={handleMemoRefChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select memo reference" />
                  </SelectTrigger>
                  <SelectContent>
                    {memoRefs.map(memo => (
                      <SelectItem key={memo.memo_ref} value={memo.memo_ref}>
                        {memo.memo_ref} - {new Date(memo.created_at).toLocaleDateString()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>7-Day Strength (MPa)</Label>
              <Input
                type="number"
                value={formData.trial_results.compressive_strength_7d}
                disabled={!formData.trial_results.is_manual_entry}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    compressive_strength_7d: parseFloat(e.target.value) || 0
                  }
                }))}
              />
            </div>
            
            <div>
              <Label>28-Day Strength (MPa)</Label>
              <Input
                type="number"
                value={formData.trial_results.compressive_strength_28d}
                disabled={!formData.trial_results.is_manual_entry}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    compressive_strength_28d: parseFloat(e.target.value) || 0
                  }
                }))}
              />
            </div>
            
            <div>
              <Label>Slump (mm)</Label>
              <Input
                type="number"
                value={formData.trial_results.slump}
                disabled={!formData.trial_results.is_manual_entry}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    slump: parseFloat(e.target.value) || 0
                  }
                }))}
              />
            </div>
            
            <div>
              <Label>Density (kg/m³)</Label>
              <Input
                type="number"
                value={formData.trial_results.density}
                disabled={!formData.trial_results.is_manual_entry}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    density: parseFloat(e.target.value) || 0
                  }
                }))}
              />
            </div>
            
            <div>
              <Label>Water Absorption (%)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.trial_results.water_absorption}
                disabled={!formData.trial_results.is_manual_entry}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  trial_results: {
                    ...prev.trial_results,
                    water_absorption: parseFloat(e.target.value) || 0
                  }
                }))}
              />
            </div>
          </div>
          
          <div className="mt-4">
            <Label>Notes</Label>
            <Textarea
              value={formData.trial_results.notes}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                trial_results: {
                  ...prev.trial_results,
                  notes: e.target.value
                }
              }))}
              placeholder="Additional notes about the trial results..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSubmit}>
          {mixDesign ? 'Update' : 'Create'} Mix Design
        </Button>
      </div>
    </div>
  );
};

// ============= MAIN MIX DESIGN MANAGER COMPONENT =============

export const MixDesignManager: React.FC = () => {
  const [mixDesigns, setMixDesigns] = useState<MixDesign[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProductType, setSelectedProductType] = useState<string>('');
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [editingMixDesign, setEditingMixDesign] = useState<MixDesign | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<MixDesign | null>(null);
  const [isVersionDialogOpen, setIsVersionDialogOpen] = useState(false);
  const [versionsData, setVersionsData] = useState<MixDesignVersion[]>([]);
  const [selectedMixForVersions, setSelectedMixForVersions] = useState<MixDesign | null>(null);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [templates, setTemplates] = useState<MixDesignTemplate[]>([]);
  const [templateName, setTemplateName] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<MixDesignTemplate | null>(null);
  const [memoRefs, setMemoRefs] = useState<Array<{memo_ref: string, created_at: string}>>([]);
  const { toast } = useToast();

  const loadMixDesigns = async () => {
    setLoading(true);
    try {
      await mixDesignService.initializeMixDesignTables();
      const designs = await mixDesignService.getAllMixDesigns();
      setMixDesigns(designs);
      
      // Load memo references
      const memos = await mixDesignService.getMemoReferences();
      setMemoRefs(memos);
      
      // Load templates
      const templatesData = await mixDesignService.getTemplates();
      setTemplates(templatesData);
    } catch (error) {
      console.error('Failed to load mix designs:', error);
      toast({
        title: "Load Failed",
        description: "Failed to load mix designs",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMixDesigns();
  }, []);

  const filteredMixDesigns = mixDesigns.filter(design => {
    const matchesSearch = design.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         design.product_type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !selectedProductType || selectedProductType === 'all' || design.product_type === selectedProductType;
    return matchesSearch && matchesType && design.is_active;
  });

  const handleSaveMixDesign = async (formData: MixDesignFormData) => {
    try {
      if (editingMixDesign) {
        await mixDesignService.updateMixDesign(editingMixDesign.id, formData);
        toast({
          title: "Updated",
          description: "Mix design updated successfully"
        });
      } else {
        await mixDesignService.saveMixDesign(formData);
        toast({
          title: "Created",
          description: "Mix design created successfully"
        });
      }
      
      setIsFormDialogOpen(false);
      setEditingMixDesign(null);
      await loadMixDesigns();
    } catch (error) {
      toast({
        title: "Save Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleDeleteMixDesign = async () => {
    if (!deleteConfirm) return;

    try {
      await mixDesignService.deleteMixDesign(deleteConfirm.id);
      
      toast({
        title: "Deleted",
        description: "Mix design deleted successfully"
      });

      setIsDeleteDialogOpen(false);
      setDeleteConfirm(null);
      await loadMixDesigns();
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleExportPDF = async (mixId: string) => {
    try {
      await mixDesignService.exportToPDF(mixId, 'current_user');
      toast({
        title: "PDF Export",
        description: "Mix design exported to PDF successfully"
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleExportCSV = async () => {
    try {
      const csvContent = await mixDesignService.exportToCSV(filteredMixDesigns, 'current_user');
      
      // Download CSV file
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `mix_designs_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "CSV Export",
        description: "Mix designs exported to CSV successfully"
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleViewVersionHistory = async (mixDesign: MixDesign) => {
    try {
      const versions = await mixDesignService.getVersionHistory(mixDesign.id);
      setVersionsData(versions);
      setSelectedMixForVersions(mixDesign);
      setIsVersionDialogOpen(true);
    } catch (error) {
      toast({
        title: "Version Load Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleRestoreVersion = async (versionId: string) => {
    try {
      await mixDesignService.restoreVersion(versionId, 'current_user');
      toast({
        title: "Version Restored",
        description: "Mix design version restored as new design"
      });
      setIsVersionDialogOpen(false);
      await loadMixDesigns();
    } catch (error) {
      toast({
        title: "Restore Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleSaveAsTemplate = async (mixDesign: MixDesign) => {
    setSelectedTemplate(mixDesign as any);
    setIsTemplateDialogOpen(true);
  };

  const handleCreateTemplate = async () => {
    if (!selectedTemplate || !templateName) return;
    
    try {
      await mixDesignService.saveAsTemplate(selectedTemplate.template_id, templateName, 'current_user');
      toast({
        title: "Template Saved",
        description: "Mix design saved as template successfully"
      });
      setIsTemplateDialogOpen(false);
      setTemplateName('');
      setSelectedTemplate(null);
      await loadMixDesigns();
    } catch (error) {
      toast({
        title: "Template Save Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const handleLoadTemplate = async (templateId: string) => {
    try {
      const templateData = await mixDesignService.loadFromTemplate(templateId);
      setEditingMixDesign(templateData as any);
      setIsFormDialogOpen(true);
    } catch (error) {
      toast({
        title: "Template Load Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive"
      });
    }
  };

  const openAddDialog = () => {
    setEditingMixDesign(null);
    setIsFormDialogOpen(true);
  };

  const openEditDialog = (mixDesign: MixDesign) => {
    setEditingMixDesign(mixDesign);
    setIsFormDialogOpen(true);
  };

  const openDeleteDialog = (mixDesign: MixDesign) => {
    setDeleteConfirm(mixDesign);
    setIsDeleteDialogOpen(true);
  };

  const productTypes = ['blocks', 'pavers', 'kerbs', 'flags', 'concrete', 'aggregates'];

  if (loading) {
    return <div className="text-center p-8">Loading mix designs...</div>;
  }

  return (
    <LabLayout>
      <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <FlaskConical className="h-8 w-8" />
        <div>
          <h1 className="text-3xl font-bold">Mix Design Manager</h1>
          <p className="text-muted-foreground">
            Create and manage mix designs with version control, templates, and export capabilities
          </p>
        </div>
      </div>

      <Alert>
        <Database className="h-4 w-4" />
        <AlertDescription>
          <strong>Enhanced Features:</strong> Mix designs now include version control, template system, PDF/CSV export, and automatic linking to lab test results.
        </AlertDescription>
      </Alert>

      {/* Enhanced Filters and Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search mix designs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Select value={selectedProductType} onValueChange={setSelectedProductType}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="All product types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All product types</SelectItem>
            {productTypes.map(type => (
              <SelectItem key={type} value={type} className="capitalize">
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Badge variant="secondary">{filteredMixDesigns.length} designs</Badge>
      </div>
      
      <div className="flex gap-2">
        <Button onClick={handleExportCSV} variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
        <Button onClick={openAddDialog}>
          <Plus className="h-4 w-4 mr-2" />
          Add Mix Design
        </Button>
      </div>
    </div>

    {/* Enhanced Mix Designs Grid */}
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {filteredMixDesigns.map((design) => (
        <Card key={design.id} className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="truncate">{design.name}</span>
              <Badge variant="outline" className="capitalize">
                {design.product_type}
              </Badge>
            </CardTitle>
            <CardDescription>
              <div className="space-y-1">
                <p>W/C Ratio: {design.water_cement_ratio}</p>
                <p>Cement: {design.cement_content} kg/m³</p>
                <p className="text-xs">
                  Effective: {new Date(design.effective_date_start).toLocaleDateString()}
                  {design.effective_date_end && ` - ${new Date(design.effective_date_end).toLocaleDateString()}`}
                </p>
              </div>
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium mb-1">Aggregates:</p>
                <div className="flex flex-wrap gap-1">
                  {design.aggregates.slice(0, 3).map((agg, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {agg.percentage}%
                    </Badge>
                  ))}
                  {design.aggregates.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{design.aggregates.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>
              
              {design.trial_results?.compressive_strength_28d && (
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    28d: {design.trial_results.compressive_strength_28d} MPa
                  </span>
                  {design.trial_results.linked_memo_ref && (
                    <Link className="h-3 w-3 text-blue-500" />
                  )}
                </div>
              )}
              
              {/* Enhanced Action Buttons */}
              <div className="flex justify-between gap-1">
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleExportPDF(design.id)}
                    title="Export PDF"
                  >
                    <FileText className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleViewVersionHistory(design)}
                    title="Version History"
                  >
                    <History className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSaveAsTemplate(design)}
                    title="Save as Template"
                  >
                    <Save className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(design)}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openDeleteDialog(design)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>

    {filteredMixDesigns.length === 0 && (
      <Card>
        <CardContent className="text-center py-12">
          <FlaskConical className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No mix designs found</h3>
          <p className="text-muted-foreground mb-4">
            Create your first mix design to get started
          </p>
          <Button onClick={openAddDialog}>
            <Plus className="h-4 w-4 mr-2" />
            Add Mix Design
          </Button>
        </CardContent>
      </Card>
    )}

    {/* Enhanced Form Dialog */}
    <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {editingMixDesign ? 'Edit' : 'Create'} Mix Design
          </DialogTitle>
          <DialogDescription>
            {editingMixDesign ? 'Update the mix design details' : 'Create a new mix design with materials and proportions'}
          </DialogDescription>
        </DialogHeader>
        
        <MixDesignForm
          mixDesign={editingMixDesign}
          onSave={handleSaveMixDesign}
          onCancel={() => setIsFormDialogOpen(false)}
          memoRefs={memoRefs}
          templates={templates}
          onLoadTemplate={handleLoadTemplate}
        />
      </DialogContent>
    </Dialog>

    {/* Version History Dialog */}
    <Dialog open={isVersionDialogOpen} onOpenChange={setIsVersionDialogOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Version History - {selectedMixForVersions?.name}
          </DialogTitle>
          <DialogDescription>
            View and restore previous versions of this mix design
          </DialogDescription>
        </DialogHeader>
        
        <div className="max-h-96 overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Version</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Modified By</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {versionsData.map((version, index) => (
                <TableRow key={version.version_id}>
                  <TableCell>
                    <Badge variant={index === 0 ? "default" : "secondary"}>
                      {index === 0 ? "Current" : `v${versionsData.length - index}`}
                    </Badge>
                  </TableCell>
                  <TableCell>{new Date(version.created_at).toLocaleString()}</TableCell>
                  <TableCell>{version.user_id}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRestoreVersion(version.version_id)}
                        disabled={index === 0}
                      >
                        <RotateCcw className="h-3 w-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsVersionDialogOpen(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    {/* Template Save Dialog */}
    <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy className="h-5 w-5" />
            Save as Template
          </DialogTitle>
          <DialogDescription>
            Save this mix design as a reusable template
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="template_name">Template Name</Label>
            <Input
              id="template_name"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="Enter template name"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleCreateTemplate} disabled={!templateName}>
            Save Template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    {/* Delete Confirmation Dialog */}
    <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Confirm Deletion
          </DialogTitle>
          <DialogDescription>
            This action will delete the mix design and all its versions. Do you want to proceed?
          </DialogDescription>
        </DialogHeader>
        
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Warning:</strong> This mix design may be linked to existing test records. Deleting it could affect historical data.
          </AlertDescription>
        </Alert>

        <DialogFooter>
          <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={handleDeleteMixDesign}>
            Delete Mix Design
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </div>
  </LabLayout>
);
};