// Updated Reference Data Manager page to replace the old one
import React from 'react';
import { LabLayout } from '@/components/lab/LabLayout';
import { ModernReferenceDataManager } from '@/components/reference-data/ModernReferenceDataManager';

export default function ReferenceDataManager() {
  return (
    <LabLayout>
      <ModernReferenceDataManager />
    </LabLayout>
  );
}