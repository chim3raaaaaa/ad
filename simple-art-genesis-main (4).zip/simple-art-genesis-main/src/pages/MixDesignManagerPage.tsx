// Mix Design Manager Integration Page
// Phase 3: Complete Integration
// Created: 2025-01-31

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertCircle, CheckCircle, Settings, Database } from 'lucide-react';
import { LabLayout } from '@/components/lab/LabLayout';
import MixDesignManager from '@/components/mix-design/MixDesignManager';
import { mixDesignDatabaseService } from '@/services/database/mixDesignDatabaseService';
import { useToast } from '@/hooks/use-toast';

const MixDesignManagerPage: React.FC = () => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);
  const [initStatus, setInitStatus] = useState<any>(null);
  const { toast } = useToast();

  // Mock user context - in real app this would come from auth
  const currentUser = {
    id: 'user-1',
    role: 'lab_technician' as const
  };

  useEffect(() => {
    initializeMixDesignSystem();
  }, []);

  const initializeMixDesignSystem = async () => {
    try {
      setIsInitializing(true);
      setInitError(null);

      // Check initialization status first
      const status = await mixDesignDatabaseService.getInitializationStatus();
      setInitStatus(status);

      if (!status.isInitialized || !status.tablesExist) {
        // Initialize the database system
        await mixDesignDatabaseService.initialize();
        
        toast({
          title: "System Initialized",
          description: "Mix Design Manager is ready to use",
        });
      }

      setIsInitialized(true);
    } catch (error) {
      console.error('Failed to initialize Mix Design system:', error);
      setInitError(error instanceof Error ? error.message : 'Unknown initialization error');
      
      toast({
        title: "Initialization Failed",
        description: "Failed to initialize Mix Design Manager",
        variant: "destructive"
      });
    } finally {
      setIsInitializing(false);
    }
  };

  const handleRetryInitialization = () => {
    initializeMixDesignSystem();
  };

  if (isInitializing) {
    return (
      <LabLayout>
        <div className="container mx-auto py-8">
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <div className="text-center space-y-4">
                <Loader2 className="h-8 w-8 animate-spin mx-auto" />
                <h3 className="text-lg font-semibold">Initializing Mix Design Manager</h3>
                <p className="text-muted-foreground">
                  Setting up database schema and loading configuration...
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </LabLayout>
    );
  }

  if (initError || !isInitialized) {
    return (
      <LabLayout>
        <div className="container mx-auto py-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-destructive" />
                Initialization Error
              </CardTitle>
              <CardDescription>
                Failed to initialize Mix Design Manager
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {initError || 'Unknown error occurred during initialization'}
                </AlertDescription>
              </Alert>
              
              {initStatus && (
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div>Status Information:</div>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Tables Exist: {initStatus.tablesExist ? '✓' : '✗'}</li>
                    <li>Has Data: {initStatus.hasData ? '✓' : '✗'}</li>
                    <li>Migration Status: {initStatus.migrationStatus?.migrationComplete ? 'Complete' : 'Pending'}</li>
                  </ul>
                </div>
              )}
              
              <Button onClick={handleRetryInitialization}>
                <Database className="h-4 w-4 mr-2" />
                Retry Initialization
              </Button>
            </CardContent>
          </Card>
        </div>
      </LabLayout>
    );
  }

  return (
    <LabLayout>
      <div className="container mx-auto py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Mix Design Manager</h1>
            <p className="text-muted-foreground">
              Create and manage mix designs with dynamic forms and validation
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="text-sm text-muted-foreground">System Ready</span>
          </div>
        </div>

        {/* System Status */}
        {initStatus && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              Mix Design Manager is initialized with {initStatus.hasData ? 'existing data' : 'default templates'}. 
              {initStatus.migrationStatus?.migrationComplete && ' Legacy data migration completed.'}
            </AlertDescription>
          </Alert>
        )}

        {/* Main Mix Design Manager Component */}
        <MixDesignManager
          currentUserId={currentUser.id}
          userRole={currentUser.role}
          className="space-y-6"
        />
      </div>
    </LabLayout>
  );
};

export default MixDesignManagerPage;