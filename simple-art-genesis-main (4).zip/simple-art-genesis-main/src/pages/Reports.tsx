import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  FileText, 
  Download, 
  Send, 
  Eye, 
  Save,
  X,
  Plus,
  Edit,
  Upload,
  Trash2,
  Type,
  Image,
  Table,
  PieChart,
  BarChart,
  LineChart,
  BarChart3,
  FileSpreadsheet,
  Hash,
  Calendar as CalendarIcon,
  MapPin,
  TestTube,
  Beaker,
  Target,
  TrendingUp,
  Activity,
  Database,
  Paperclip,
  Building,
  User,
  GripVertical,
  Copy,
  Search,
  Filter,
  RefreshCw,
  AlertTriangle,
  Package2,
  Layers,
  Settings,
  Palette,
  FileCheck,
  FolderOpen,
  CloudUpload,
  Link2,
  Zap,
  Heading1,
  PenTool,
  Minus,
  Gauge,
  Grid3x3,
  Square,
  Grid3X3,
  Move,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize,
  Signature,
  QrCode,
  FilePlus,
  ChevronDown,
  MoreVertical,
  CheckCircle,
  PlayCircle,
  Clock,
  XCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { useReportGeneration } from "@/hooks/useReportGeneration";
import { LabLayout } from "@/components/lab/LabLayout";
import { PDFGenerator } from "@/lib/pdfGenerator";
import { enhancedMemoService, EnhancedMemoData } from "@/services/database/enhancedMemoService";
import { memoTestService, MemoTestAssignment } from "@/services/database/memoTestService";
import { DataBindingService, ReportData } from "@/services/reporting/dataBindingService";
import { EnhancedAnalyticsIntegration } from "@/services/reporting/enhancedAnalyticsIntegration";
import { ReportsAPI, ReportCategory as APIReportCategory, ProductDefinition } from '@/services/api/reportsAPI';
import { CategoryManagement } from '@/components/reports/CategoryManagement';
import { ProductDefinitionManager } from '@/components/reports/ProductDefinitionManager';
import { TemplateLibrary } from '@/components/reports/TemplateLibrary';
import { ChartConfigurationModal } from '@/components/reports/ChartConfigurationModal';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';
import { EnhancedAnalyticsDataBinding, ChartBinding, AnalyticsElement } from '@/services/reporting/enhancedAnalyticsDataBinding';

// Use the API interfaces
type ReportCategory = APIReportCategory;
type ReportProduct = ProductDefinition;

interface ReportElement {
  id: string;
  type: 'static' | 'field' | 'chart' | 'attachment';
  subtype: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  config?: any;
}

interface CanvasElement {
  id: string;
  elementId: string;
  type: 'static' | 'field' | 'chart' | 'attachment';
  subtype: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation?: number;
  config?: any;
  content?: any;
}

interface ReportTemplate {
  id: string;
  name: string;
  description: string;
  categoryId: string;
  productId: string;
  elements: CanvasElement[];
  version: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface ChartConfig {
  id: string;
  name: string;
  type: 'bar' | 'pie' | 'line' | 'scatter';
  dataSource: string;
  filters?: any;
  settings?: any;
}

export default function Reports() {
  const [currentView, setCurrentView] = useState<'designer' | 'categories' | 'products' | 'templates'>('designer');
  // Core state management
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [activeTab, setActiveTab] = useState('static');
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<CanvasElement | null>(null);
  const [draggedElement, setDraggedElement] = useState<ReportElement | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [gridSize, setGridSize] = useState(20);
  const [zoomLevel, setZoomLevel] = useState(100);
  
  // Template management
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [currentTemplate, setCurrentTemplate] = useState<ReportTemplate | null>(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showLoadDialog, setShowLoadDialog] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  
  // Memo-based report generation
  const [reportMode, setReportMode] = useState<'template' | 'memo'>('template');
  const [completedMemos, setCompletedMemos] = useState<EnhancedMemoData[]>([]);
  const [selectedMemo, setSelectedMemo] = useState<string>('');
  const [memoData, setMemoData] = useState<ReportData | null>(null);
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [uploadedTemplates, setUploadedTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [showMemoReportDialog, setShowMemoReportDialog] = useState(false);
  
  // Search and filter
  const [searchTerm, setSearchTerm] = useState('');
  const [elementFilter, setElementFilter] = useState('all');
  
  // Chart configuration
  const [showChartConfig, setShowChartConfig] = useState(false);
  const [selectedElementForChart, setSelectedElementForChart] = useState<CanvasElement | null>(null);
  const [chartBindings, setChartBindings] = useState<Map<string, ChartBinding>>(new Map());
  const [analyticsElements, setAnalyticsElements] = useState<Map<string, AnalyticsElement>>(new Map());
  
  // File upload
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  // Refs
  const canvasRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const { user } = useUser();
  const {
    generateFromCanvas,
    saveTemplate: saveTemplateToDb,
    loadTemplate,
    uploadTemplate,
    getTemplatesByProduct,
    getAnalyticsCharts,
    getChartData,
    isGenerating
  } = useReportGeneration();

  // Initialize system on mount
  useEffect(() => {
    initializeSystem();
  }, []);

  const initializeSystem = async () => {
    try {
      await ReportsAPI.initializeSchema();
      await loadCategories();
      await loadProductDefinitions();
      setIsSystemInitialized(true);
    } catch (error) {
      console.error('Failed to initialize reports system:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to initialize reports system. Some features may not work properly.",
        variant: "destructive"
      });
    }
  };

  const loadCategories = async () => {
    try {
      const data = await ReportsAPI.getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadProductDefinitions = async () => {
    try {
      const data = await ReportsAPI.getProductDefinitions();
      setProductDefinitions(data);
    } catch (error) {
      console.error('Failed to load product definitions:', error);
    }
  };

  const loadProducts = async () => {
    try {
      if (selectedCategory) {
        const allProducts = await ReportsAPI.getProductDefinitions();
        const categoryProducts = allProducts.filter(p => p.category_id === selectedCategory);
        setProducts(categoryProducts);
      }
    } catch (error) {
      console.error('Failed to load products for category:', error);
    }
  };

  // Initialize services
  const dataBindingService = new DataBindingService();
  const analyticsService = new EnhancedAnalyticsIntegration();

  // Dynamic data from API
  const [categories, setCategories] = useState<APIReportCategory[]>([]);
  const [products, setProducts] = useState<ProductDefinition[]>([]);
  const [productDefinitions, setProductDefinitions] = useState<ProductDefinition[]>([]);
  const [isSystemInitialized, setIsSystemInitialized] = useState(false);

  // Static elements for tab 1
  const staticElements: ReportElement[] = [
    {
      id: 'text-field',
      type: 'static',
      subtype: 'text',
      name: 'Text Field',
      icon: <Type className="h-4 w-4" />,
      description: 'Add custom text content'
    },
    {
      id: 'heading-1',
      type: 'static',
      subtype: 'heading',
      name: 'Heading',
      icon: <Heading1 className="h-4 w-4" />,
      description: 'Add section heading'
    },
    {
      id: 'line-separator',
      type: 'static',
      subtype: 'line',
      name: 'Line',
      icon: <Minus className="h-4 w-4" />,
      description: 'Add horizontal line'
    },
    {
      id: 'logo-image',
      type: 'static',
      subtype: 'logo',
      name: 'Logo',
      icon: <Image className="h-4 w-4" />,
      description: 'Add company logo'
    },
    {
      id: 'data-table',
      type: 'static',
      subtype: 'table',
      name: 'Table',
      icon: <Table className="h-4 w-4" />,
      description: 'Add data table'
    }
  ];

  // Chart elements for tab 3
  const chartElements: ReportElement[] = [
    {
      id: 'bar-chart',
      type: 'chart',
      subtype: 'bar',
      name: 'Bar Chart',
      icon: <BarChart className="h-4 w-4" />,
      description: 'Show data as bars'
    },
    {
      id: 'pie-chart',
      type: 'chart',
      subtype: 'pie',
      name: 'Pie Chart',
      icon: <PieChart className="h-4 w-4" />,
      description: 'Show data as pie slices'
    },
    {
      id: 'line-chart',
      type: 'chart',
      subtype: 'line',
      name: 'Line Chart',
      icon: <LineChart className="h-4 w-4" />,
      description: 'Show trends over time'
    },
    {
      id: 'scatter-chart',
      type: 'chart',
      subtype: 'scatter',
      name: 'Scatter Plot',
      icon: <TrendingUp className="h-4 w-4" />,
      description: 'Show data relationships'
    }
  ];

  // Attachment elements for tab 4
  const attachmentElements: ReportElement[] = [
    {
      id: 'digital-signature',
      type: 'attachment',
      subtype: 'signature',
      name: 'Digital Signature',
      icon: <Signature className="h-4 w-4" />,
      description: 'Add signature placeholder'
    },
    {
      id: 'qr-code',
      type: 'attachment',
      subtype: 'qr',
      name: 'QR Code',
      icon: <QrCode className="h-4 w-4" />,
      description: 'Add memo QR code'
    },
    {
      id: 'file-attachment',
      type: 'attachment',
      subtype: 'file',
      name: 'File Reference',
      icon: <Paperclip className="h-4 w-4" />,
      description: 'Link external file'
    },
    {
      id: 'image-upload',
      type: 'attachment',
      subtype: 'image',
      name: 'Image Upload',
      icon: <Image className="h-4 w-4" />,
      description: 'Upload and place image'
    }
  ];

  // Get current product fields
  const getCurrentProductFields = useCallback((): ReportElement[] => {
    if (!selectedCategory || !selectedProduct) return [];
    
    const productDef = productDefinitions.find(p => 
      p.id === selectedProduct && p.category_id === selectedCategory
    );
    
    return productDef?.field_definitions.map(field => ({
      id: field.id,
      type: 'field' as const,
      subtype: field.type,
      name: field.name,
      icon: <Hash className="h-4 w-4" />,
      description: field.token,
      config: { token: field.token, required: field.required }
    })) || [];
  }, [selectedCategory, selectedProduct, productDefinitions]);

  // Get filtered elements based on current tab
  const getElementsForTab = useCallback((): ReportElement[] => {
    switch (activeTab) {
      case 'static':
        return staticElements;
      case 'fields':
        return getCurrentProductFields();
      case 'charts':
        return chartElements;
      case 'attachments':
        return attachmentElements;
      default:
        return [];
    }
  }, [activeTab, getCurrentProductFields]);

  // Filter elements based on search term
  const filteredElements = getElementsForTab().filter(element =>
    element.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    element.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle drag start
  const handleDragStart = useCallback((element: ReportElement) => {
    setDraggedElement(element);
  }, []);

  // Handle drop on canvas
  const handleCanvasDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedElement || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const scaleFactor = zoomLevel / 100;
    const x = Math.round(((e.clientX - rect.left) / scaleFactor) / gridSize) * gridSize;
    const y = Math.round(((e.clientY - rect.top) / scaleFactor) / gridSize) * gridSize;

    const newElement: CanvasElement = {
      id: `element-${Date.now()}`,
      elementId: draggedElement.id,
      type: draggedElement.type,
      subtype: draggedElement.subtype,
      name: draggedElement.name,
      x: snapToGrid ? x : (e.clientX - rect.left) / scaleFactor,
      y: snapToGrid ? y : (e.clientY - rect.top) / scaleFactor,
      width: 200,
      height: 50,
      rotation: 0,
      config: draggedElement.config
    };

    setCanvasElements(prev => [...prev, newElement]);
    setDraggedElement(null);
    
    toast({
      title: "Element Added",
      description: `${draggedElement.name} has been added to the canvas.`
    });
  }, [draggedElement, gridSize, snapToGrid, zoomLevel, toast]);

  // Handle element selection
  const handleElementSelect = useCallback((element: CanvasElement) => {
    setSelectedElement(element);
  }, []);

  // Handle element deletion
  const handleElementDelete = useCallback((elementId: string) => {
    setCanvasElements(prev => prev.filter(el => el.id !== elementId));
    if (selectedElement?.id === elementId) {
      setSelectedElement(null);
    }
  }, [selectedElement]);

  // Handle element update
  const handleElementUpdate = useCallback((elementId: string, updates: Partial<CanvasElement>) => {
    setCanvasElements(prev => prev.map(el => 
      el.id === elementId ? { ...el, ...updates } : el
    ));
    
    if (selectedElement?.id === elementId) {
      setSelectedElement(prev => prev ? { ...prev, ...updates } : null);
    }
  }, [selectedElement]);

  // Save template
  const handleSaveTemplate = useCallback(async () => {
    if (!templateName.trim() || !selectedCategory || !selectedProduct) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    const template: ReportTemplate = {
      id: currentTemplate?.id || `template-${Date.now()}`,
      name: templateName,
      description: templateDescription,
      categoryId: selectedCategory,
      productId: selectedProduct,
      elements: canvasElements,
      version: "1.0",
      createdBy: user?.username || 'Unknown',
      createdAt: currentTemplate?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    try {
      setLoading(true);
      // Save to SQLite database
      await saveTemplateToDb(templateName, canvasElements.map(el => ({
        id: el.id,
        type: el.type,
        name: el.name,
        x: el.x,
        y: el.y,
        width: el.width,
        height: el.height,
        content: el.config
      })), selectedCategory);
      
      setTemplates(prev => {
        const existing = prev.findIndex(t => t.id === template.id);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = template;
          return updated;
        }
        return [...prev, template];
      });
      
      setCurrentTemplate(template);
      setShowSaveDialog(false);
      
      toast({
        title: "Template Saved",
        description: `Template "${templateName}" has been saved successfully.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save template. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [templateName, templateDescription, selectedCategory, selectedProduct, canvasElements, currentTemplate, user, saveTemplateToDb, toast]);

  // Export functions
  const handleExportPDF = useCallback(async () => {
    if (canvasElements.length === 0) {
      toast({
        title: "Error",
        description: "Canvas is empty. Add some elements first.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const blob = await generateFromCanvas(canvasElements.map(el => ({
        id: el.id,
        type: el.type,
        name: el.name,
        x: el.x,
        y: el.y,
        width: el.width,
        height: el.height,
        content: el.config
      })));
      
      if (blob) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${templateName || 'report'}.pdf`;
        link.click();
        URL.revokeObjectURL(url);
        
        toast({
          title: "Export Successful",
          description: "PDF report has been generated and downloaded."
        });
      }
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [canvasElements, templateName, generateFromCanvas, toast]);

  // Preview toggle handler
  const handlePreviewToggle = useCallback(() => {
    // Generate preview PDF when toggling preview mode
    handleExportPDF();
  }, [handleExportPDF]);

  // Clear template handler
  const handleClearTemplate = useCallback(() => {
    setCanvasElements([]);
    setSelectedElement(null);
    setTemplateName('');
    setTemplateDescription('');
    setCurrentTemplate(null);
    toast({
      title: "Template Cleared",
      description: "Canvas has been cleared successfully."
    });
  }, [toast]);

  // New template handler
  const handleNewTemplate = useCallback(() => {
    handleClearTemplate();
    setShowSaveDialog(false);
    toast({
      title: "New Template",
      description: "Started a new template. Canvas cleared."
    });
  }, [handleClearTemplate, toast]);

  // Delete selected block handler
  const handleDeleteSelectedBlock = useCallback(() => {
    if (selectedElement) {
      setCanvasElements(prev => prev.filter(el => el.id !== selectedElement.id));
      setSelectedElement(null);
      toast({
        title: "Block Deleted",
        description: "Selected block has been removed from canvas."
      });
    }
  }, [selectedElement, toast]);

  // Upload template handler (wrapping existing handleTemplateUpload)
  const handleUploadTemplate = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  // Template upload handler
  const handleTemplateUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!selectedCategory) {
      toast({
        title: "Error",
        description: "Please select a category first.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      setUploadProgress(0);
      
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      const success = await uploadTemplate(file, selectedCategory, user?.username || 'Unknown');
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      setTimeout(() => {
        setUploadProgress(0);
        setShowUploadDialog(false);
      }, 1000);

      if (success) {
        toast({
          title: "Upload Successful",
          description: "Template has been uploaded and parsed successfully."
        });
        
        // Refresh templates list
        const updatedTemplates = await getTemplatesByProduct(selectedProduct);
        // Update templates state here
      } else {
        throw new Error("Upload failed");
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload template. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, selectedProduct, user, uploadTemplate, getTemplatesByProduct, toast]);

  // Memo-based report generation functions
  const loadCompletedMemos = useCallback(async () => {
    try {
      setLoading(true);
      const completed = await enhancedMemoService.searchMemos({
        status: 'Completed',
        ...(selectedCategory && { category: selectedCategory })
      });
      setCompletedMemos(completed);
    } catch (error) {
      console.error('Failed to load completed memos:', error);
      toast({
        title: "Error",
        description: "Failed to load completed memos.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, toast]);

  const handleMemoSelection = useCallback(async (memoRef: string) => {
    if (!memoRef) return;

    try {
      setLoading(true);
      
      // Get memo details
      const memo = completedMemos.find(m => m.memo_ref === memoRef);
      if (!memo) return;

      // Get test results for the memo
      const testAssignments = await memoTestService.getMemoTestAssignments(memoRef);
      const testResults = testAssignments.filter(test => test.status === 'completed');
      
      // Get analytics data if available (simplified for now)
      const analyticsData = {
        charts: await getAnalyticsCharts(),
        summary: {}
      };

      // Create report data structure
      const reportData: ReportData = {
        memoId: memo.id,
        memoRef: memo.memo_ref,
        testData: {
          plant: memo.plant,
          officer: memo.officer,
          category: memo.category,
          productType: memo.product_type,
          testType: memo.test_type,
          dateCreated: memo.date_created,
          dateCompleted: memo.date_completed,
          productionData: memo.production_data,
          testResults: testResults.reduce((acc, test) => ({
            ...acc,
            ...test.test_results
          }), {})
        },
        analyticsData: analyticsData,
        attachments: memo.attachments || []
      };

      setMemoData(reportData);
      setSelectedMemo(memoRef);

      // Auto-select all available fields
      const availableFields = Object.keys(reportData.testData.testResults || {});
      setSelectedFields(availableFields);

      toast({
        title: "Memo Loaded",
        description: `Data loaded for memo ${memoRef}`
      });

    } catch (error) {
      console.error('Failed to load memo data:', error);
      toast({
        title: "Error",
        description: "Failed to load memo data.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [completedMemos, analyticsService, toast]);

  const handleFieldToggle = useCallback((fieldName: string, checked: boolean) => {
    setSelectedFields(prev => 
      checked 
        ? [...prev, fieldName]
        : prev.filter(f => f !== fieldName)
    );
  }, []);

  const generateMemoReport = useCallback(async () => {
    if (!memoData || !selectedTemplate) {
      toast({
        title: "Error",
        description: "Please select a memo and template first.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);

      // Generate PDF with memo data
      const reportElements = selectedFields.map((fieldName, index) => {
        const value = fieldName === 'memo_ref' ? memoData.memoRef :
                     fieldName === 'plant' ? memoData.testData.plant :
                     fieldName === 'officer' ? memoData.testData.officer :
                     fieldName === 'category' ? memoData.testData.category :
                     fieldName === 'date_created' ? memoData.testData.dateCreated :
                     memoData.testData.testResults?.[fieldName];

        return {
          id: `memo-field-${index}`,
          type: 'field' as const,
          name: fieldName.replace(/_/g, ' '),
          x: 50,
          y: 80 + (index * 30),
          width: 400,
          height: 25,
          content: {
            token: `{{${fieldName}}}`,
            value: String(value || 'N/A'),
            fieldName: fieldName
          }
        };
      });

      // Add header
      const headerElement = {
        id: 'report-header',
        type: 'static' as const,
        name: 'Report Header',
        x: 50,
        y: 30,
        width: 500,
        height: 40,
        content: {
          text: `Test Report - ${memoData.memoRef}`,
          fontSize: 18,
          fontWeight: 'bold'
        }
      };

      const allElements = [headerElement, ...reportElements];

      // Generate PDF
      const blob = await generateFromCanvas(allElements);

      if (blob) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${memoData.memoRef}-report.pdf`;
        link.click();
        URL.revokeObjectURL(url);

        // Close dialog and show success
        setShowMemoReportDialog(false);
        toast({
          title: "Report Generated",
          description: `Report for memo ${memoData.memoRef} has been generated successfully.`
        });
      }

    } catch (error) {
      console.error('Failed to generate report:', error);
      toast({
        title: "Error",
        description: "Failed to generate report.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [memoData, selectedTemplate, selectedFields, dataBindingService, generateFromCanvas, toast]);

  // Initialize component
  useEffect(() => {
    // Load initial data
    const initializeData = async () => {
      try {
        // Load available charts from analytics
        const charts = await getAnalyticsCharts();
        // Update chart elements with actual data
      } catch (error) {
        console.error('Failed to initialize data:', error);
      }
    };

    initializeData();
  }, [getAnalyticsCharts]);

  // Load completed memos when category changes
  useEffect(() => {
    if (reportMode === 'memo') {
      loadCompletedMemos();
    }
  }, [selectedCategory, reportMode, loadCompletedMemos]);

  // Load products when category changes
  useEffect(() => {
    if (selectedCategory) {
      loadProducts();
    }
  }, [selectedCategory]);

  // Set first product as default when products load
  useEffect(() => {
    if (products.length > 0 && !selectedProduct) {
      setSelectedProduct(products[0].id);
    }
  }, [products, selectedProduct]);

  // Chart configuration handlers
  const handleElementDoubleClick = (element: CanvasElement) => {
    if (element.type === 'chart') {
      setSelectedElementForChart(element);
      setShowChartConfig(true);
    } else {
      setSelectedElement(element);
    }
  };

  const handleChartConfigSave = async (binding: ChartBinding) => {
    if (!selectedElementForChart) return;

    try {
      // Update chart bindings
      const newBindings = new Map(chartBindings);
      newBindings.set(selectedElementForChart.id, binding);
      setChartBindings(newBindings);

      // Bind chart data
      const analyticsElement = await EnhancedAnalyticsDataBinding.bindChartData(binding);
      const newAnalyticsElements = new Map(analyticsElements);
      newAnalyticsElements.set(selectedElementForChart.id, analyticsElement);
      setAnalyticsElements(newAnalyticsElements);

      // Update canvas element with chart data
      setCanvasElements(prev => prev.map(el => 
        el.id === selectedElementForChart.id 
          ? { ...el, data: analyticsElement.data, title: analyticsElement.title }
          : el
      ));

      toast({
        title: "Success",
        description: "Chart configuration saved and data loaded"
      });
    } catch (error) {
      console.error('Failed to save chart configuration:', error);
      toast({
        title: "Error",
        description: "Failed to save chart configuration",
        variant: "destructive"
      });
    }
  };

  // Refresh analytics data
  const refreshAnalyticsData = async () => {
    try {
      const promises = Array.from(chartBindings.entries()).map(async ([elementId, binding]) => {
        const element = await EnhancedAnalyticsDataBinding.refreshChartData(binding);
        return [elementId, element];
      });

      const results = await Promise.all(promises);
      const newAnalyticsElements = new Map(analyticsElements);
      
      results.forEach(([elementId, element]) => {
        newAnalyticsElements.set(elementId as string, element as AnalyticsElement);
      });
      
      setAnalyticsElements(newAnalyticsElements);
      
      // Update canvas elements with fresh data
      setCanvasElements(prev => prev.map(el => {
        const analyticsElement = newAnalyticsElements.get(el.id);
        return analyticsElement ? { ...el, data: analyticsElement.data } : el;
      }));

      toast({
        title: "Success",
        description: "Analytics data refreshed"
      });
    } catch (error) {
      console.error('Failed to refresh analytics data:', error);
      toast({
        title: "Error",
        description: "Failed to refresh analytics data",
        variant: "destructive"
      });
    }
  };

  return (
    <LabLayout>
      <div className="flex flex-col h-screen overflow-hidden">
        {/* Header with category/product selectors and main actions */}
        <div className="flex-shrink-0 border-b bg-background p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold">Report Generator</h1>
              <Badge variant="outline" className="text-sm">
                Advanced Designer
              </Badge>
              
              {/* Report Mode Toggle */}
              <div className="flex items-center space-x-2 ml-8">
                <Button
                  variant={reportMode === 'template' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setReportMode('template')}
                >
                  Template Designer
                </Button>
                <Button
                  variant={reportMode === 'memo' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setReportMode('memo')}
                >
                  Memo Reports
                </Button>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowUploadDialog(true)}
                disabled={loading}
              >
                <Upload className="h-4 w-4 mr-2" />
                Import Template
              </Button>
              
              <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" disabled={canvasElements.length === 0 || loading}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Template
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Save Report Template</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Template Name</Label>
                      <Input
                        value={templateName}
                        onChange={(e) => setTemplateName(e.target.value)}
                        placeholder="Enter template name..."
                      />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <Textarea
                        value={templateDescription}
                        onChange={(e) => setTemplateDescription(e.target.value)}
                        placeholder="Describe this template..."
                        rows={3}
                      />
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSaveTemplate} disabled={loading}>
                        {loading ? "Saving..." : "Save Template"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button
                onClick={refreshAnalyticsData}
                disabled={chartBindings.size === 0 || loading}
                size="sm"
                variant="outline"
                className="mr-2"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Analytics
              </Button>
              
              <Button
                onClick={handleExportPDF}
                disabled={canvasElements.length === 0 || loading}
                size="sm"
              >
                {loading ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-2" />
                    Export PDF
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Category and Product Selectors / Memo Selection */}
          {reportMode === 'template' ? (
            <div className="flex items-center space-x-4">
              <div className="flex-1 max-w-xs">
                <Label className="text-sm font-medium">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select category..." />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 max-w-xs">
                <Label className="text-sm font-medium">Product</Label>
                <Select 
                  value={selectedProduct} 
                  onValueChange={setSelectedProduct}
                  disabled={!selectedCategory}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select product..." />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <div className="flex-1 max-w-xs">
                <Label className="text-sm font-medium">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select category..." />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 max-w-xs">
                <Label className="text-sm font-medium">Completed Memo</Label>
                <Select 
                  value={selectedMemo} 
                  onValueChange={handleMemoSelection}
                  disabled={!selectedCategory}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select completed memo..." />
                  </SelectTrigger>
                  <SelectContent>
                    {completedMemos.map((memo) => (
                      <SelectItem key={memo.memo_ref} value={memo.memo_ref}>
                        {memo.memo_ref} - {memo.product_type || memo.category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 max-w-xs">
                <Label className="text-sm font-medium">Template</Label>
                <Select 
                  value={selectedTemplate} 
                  onValueChange={setSelectedTemplate}
                  disabled={!selectedMemo}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select template..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default-template">Default Template</SelectItem>
                    <SelectItem value="detailed-template">Detailed Template</SelectItem>
                    <SelectItem value="summary-template">Summary Template</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={() => setShowMemoReportDialog(true)}
                disabled={!selectedMemo || !selectedTemplate}
                size="sm"
              >
                <Eye className="h-4 w-4 mr-2" />
                Configure Report
              </Button>
            </div>
          )}

          {/* Design Controls - Only show in template mode */}
          {reportMode === 'template' && (
            <div className="flex items-center space-x-4 ml-auto">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={snapToGrid}
                  onCheckedChange={setSnapToGrid}
                  id="snap-to-grid"
                />
                <Label htmlFor="snap-to-grid" className="text-sm">Snap to Grid</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={isPreviewMode}
                  onCheckedChange={setIsPreviewMode}
                  id="preview-mode"
                />
                <Label htmlFor="preview-mode" className="text-sm">Preview Mode</Label>
              </div>
              
              <div className="flex items-center space-x-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.max(50, zoomLevel - 10))}
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <span className="text-sm w-12 text-center">{zoomLevel}%</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.min(200, zoomLevel + 10))}
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Main Content Area - Fixed Layout */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar - Element Palette */}
          <div className="w-80 flex-shrink-0 border-r bg-muted/30 flex flex-col overflow-hidden">
            <div className="p-4 border-b">
              <h3 className="font-semibold mb-3">Design Elements</h3>
              
              {/* Search */}
              <div className="relative mb-3">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search elements..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-8"
                />
              </div>
            </div>

            {/* Tabs for different element types */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
              <TabsList className="grid w-full grid-cols-4 m-4 mb-2">
                <TabsTrigger value="static" className="text-xs">Static</TabsTrigger>
                <TabsTrigger value="fields" className="text-xs" disabled={!selectedProduct}>Fields</TabsTrigger>
                <TabsTrigger value="charts" className="text-xs">Charts</TabsTrigger>
                <TabsTrigger value="attachments" className="text-xs">Files</TabsTrigger>
              </TabsList>
              
              <ScrollArea className="flex-1 px-4">
                <TabsContent value="static" className="mt-0">
                  <div className="space-y-2">
                    {filteredElements.map((element) => (
                      <div
                        key={element.id}
                        draggable
                        onDragStart={() => handleDragStart(element)}
                        className="flex items-center p-3 border rounded-lg hover:bg-accent cursor-move transition-colors"
                      >
                        <div className="mr-3 text-muted-foreground">
                          {element.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{element.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{element.description}</p>
                        </div>
                        <GripVertical className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="fields" className="mt-0">
                  {!selectedProduct ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Database className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Select a product to view available fields</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {filteredElements.map((element) => (
                        <div
                          key={element.id}
                          draggable
                          onDragStart={() => handleDragStart(element)}
                          className="flex items-center p-3 border rounded-lg hover:bg-accent cursor-move transition-colors"
                        >
                          <div className="mr-3 text-muted-foreground">
                            {element.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{element.name}</p>
                            <p className="text-xs text-muted-foreground truncate font-mono">{element.description}</p>
                          </div>
                          {element.config?.required && (
                            <Badge variant="secondary" className="text-xs">Required</Badge>
                          )}
                          <GripVertical className="h-4 w-4 text-muted-foreground ml-2" />
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="charts" className="mt-0">
                  <div className="space-y-2">
                    {filteredElements.map((element) => (
                      <div
                        key={element.id}
                        draggable
                        onDragStart={() => handleDragStart(element)}
                        className="flex items-center p-3 border rounded-lg hover:bg-accent cursor-move transition-colors"
                      >
                        <div className="mr-3 text-muted-foreground">
                          {element.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{element.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{element.description}</p>
                        </div>
                        <GripVertical className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="attachments" className="mt-0">
                  <div className="space-y-2">
                    {filteredElements.map((element) => (
                      <div
                        key={element.id}
                        draggable
                        onDragStart={() => handleDragStart(element)}
                        className="flex items-center p-3 border rounded-lg hover:bg-accent cursor-move transition-colors"
                      >
                        <div className="mr-3 text-muted-foreground">
                          {element.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{element.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{element.description}</p>
                        </div>
                        <GripVertical className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </ScrollArea>
            </Tabs>
          </div>

          {/* Canvas Area - Flexible and Scrollable */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-auto bg-gray-50">
              <div
                ref={canvasRef}
                className="relative min-h-full min-w-full bg-white m-4 shadow-lg"
                style={{
                  width: 'calc(100% - 2rem)',
                  height: `${Math.max(600, canvasElements.reduce((max, el) => Math.max(max, el.y + el.height), 0) + 100)}px`,
                  transform: `scale(${zoomLevel / 100})`,
                  transformOrigin: 'top left',
                  backgroundImage: snapToGrid 
                    ? `radial-gradient(circle, #e5e7eb 1px, transparent 1px)`
                    : 'none',
                  backgroundSize: snapToGrid ? `${gridSize}px ${gridSize}px` : 'auto'
                }}
                onDrop={handleCanvasDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => setSelectedElement(null)}
              >
                {/* Canvas Elements */}
                {canvasElements.map((element) => (
                  <div
                    key={element.id}
                    className={`absolute border-2 rounded-md transition-all cursor-move ${
                      selectedElement?.id === element.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 bg-white hover:border-gray-400'
                    } ${isPreviewMode ? 'pointer-events-none' : ''}`}
                    style={{
                      left: element.x,
                      top: element.y,
                      width: element.width,
                      height: element.height,
                      transform: `rotate(${element.rotation || 0}deg)`,
                      zIndex: selectedElement?.id === element.id ? 10 : 1
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (!isPreviewMode) {
                        handleElementSelect(element);
                      }
                    }}
                  >
                    {/* Element Content */}
                    <div className="w-full h-full flex items-center justify-center p-2 text-sm">
                      <div className="flex items-center space-x-2">
                        {/* Get icon based on element type */}
                        {(() => {
                          const iconMap = {
                            text: <Type className="h-4 w-4" />,
                            heading: <Heading1 className="h-4 w-4" />,
                            line: <Minus className="h-4 w-4" />,
                            logo: <Image className="h-4 w-4" />,
                            table: <Table className="h-4 w-4" />,
                            bar: <BarChart className="h-4 w-4" />,
                            pie: <PieChart className="h-4 w-4" />,
                            scatter: <TrendingUp className="h-4 w-4" />,
                            signature: <Signature className="h-4 w-4" />,
                            qr: <QrCode className="h-4 w-4" />,
                            file: <Paperclip className="h-4 w-4" />,
                            image: <Image className="h-4 w-4" />,
                            date: <CalendarIcon className="h-4 w-4" />,
                            number: <Hash className="h-4 w-4" />,
                            select: <ChevronDown className="h-4 w-4" />,
                            textarea: <FileText className="h-4 w-4" />
                          };
                          return iconMap[element.subtype as keyof typeof iconMap] || <Square className="h-4 w-4" />;
                        })()}
                        <span className="truncate">{element.name}</span>
                      </div>
                    </div>

                    {/* Delete Button */}
                    {selectedElement?.id === element.id && !isPreviewMode && (
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute -top-3 -right-3 h-6 w-6 p-0 rounded-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleElementDelete(element.id);
                        }}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}

                    {/* Resize Handles */}
                    {selectedElement?.id === element.id && !isPreviewMode && (
                      <>
                        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-blue-500 rounded-full cursor-se-resize" />
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full cursor-ne-resize" />
                        <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-blue-500 rounded-full cursor-sw-resize" />
                        <div className="absolute -top-1 -left-1 w-3 h-3 bg-blue-500 rounded-full cursor-nw-resize" />
                      </>
                    )}
                  </div>
                ))}

                {/* Empty State */}
                {canvasElements.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <Layers className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-medium mb-2">Start Building Your Report</h3>
                      <p className="text-sm mb-4 max-w-md">
                        Drag elements from the sidebar to create your custom report template.
                        {!selectedCategory && " Select a category and product first."}
                      </p>
                      {!selectedCategory && (
                        <Alert className="max-w-md mx-auto">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>
                            Please select a category and product to enable field elements.
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Sidebar - Properties */}
          <div className="w-80 flex-shrink-0 border-l bg-muted/30 flex flex-col overflow-hidden">
            <div className="p-4 border-b">
              <h3 className="font-semibold">Properties</h3>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              {selectedElement ? (
                <div className="space-y-4">
                  {/* Element Info */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Element Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-xs">Name</Label>
                        <Input
                          value={selectedElement.name}
                          onChange={(e) => handleElementUpdate(selectedElement.id, { name: e.target.value })}
                          className="h-8 mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Type</Label>
                        <Input
                          value={`${selectedElement.type} - ${selectedElement.subtype}`}
                          className="h-8 mt-1"
                          readOnly
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Position & Size */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Position & Size</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">X Position</Label>
                          <Input
                            type="number"
                            value={selectedElement.x}
                            onChange={(e) => handleElementUpdate(selectedElement.id, { x: parseInt(e.target.value) || 0 })}
                            className="h-8 mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Y Position</Label>
                          <Input
                            type="number"
                            value={selectedElement.y}
                            onChange={(e) => handleElementUpdate(selectedElement.id, { y: parseInt(e.target.value) || 0 })}
                            className="h-8 mt-1"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Width</Label>
                          <Input
                            type="number"
                            value={selectedElement.width}
                            onChange={(e) => handleElementUpdate(selectedElement.id, { width: parseInt(e.target.value) || 100 })}
                            className="h-8 mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Height</Label>
                          <Input
                            type="number"
                            value={selectedElement.height}
                            onChange={(e) => handleElementUpdate(selectedElement.id, { height: parseInt(e.target.value) || 50 })}
                            className="h-8 mt-1"
                          />
                        </div>
                      </div>
                      <div>
                        <Label className="text-xs">Rotation (degrees)</Label>
                        <Input
                          type="number"
                          value={selectedElement.rotation || 0}
                          onChange={(e) => handleElementUpdate(selectedElement.id, { rotation: parseInt(e.target.value) || 0 })}
                          className="h-8 mt-1"
                          min="-180"
                          max="180"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Element-specific properties */}
                  {selectedElement.type === 'field' && selectedElement.config && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Field Properties</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <Label className="text-xs">Token</Label>
                          <Input
                            value={selectedElement.config.token || ''}
                            className="h-8 mt-1 font-mono text-xs"
                            readOnly
                          />
                        </div>
                        {selectedElement.config.required && (
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary" className="text-xs">Required Field</Badge>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Select an element to view properties</p>
                </div>
              )}
            </ScrollArea>
          </div>
        </div>

        {/* Memo Report Configuration Dialog */}
        <Dialog open={showMemoReportDialog} onOpenChange={setShowMemoReportDialog}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Configure Memo Report</DialogTitle>
            </DialogHeader>
            {memoData && (
              <div className="grid grid-cols-2 gap-6">
                {/* Left: Field Selection */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Select Fields to Include</h3>
                  <ScrollArea className="h-64 border rounded-lg p-4">
                    <div className="space-y-3">
                      {Object.entries(memoData.testData.testResults || {}).map(([fieldName, value]) => (
                        <div key={fieldName} className="flex items-center space-x-3">
                          <Checkbox
                            checked={selectedFields.includes(fieldName)}
                            onCheckedChange={(checked) => handleFieldToggle(fieldName, checked as boolean)}
                          />
                          <div className="flex-1">
                            <Label className="text-sm font-medium">{fieldName}</Label>
                            <p className="text-xs text-muted-foreground">
                              Value: {String(value)}
                            </p>
                          </div>
                        </div>
                      ))}
                      
                      {/* Standard memo fields */}
                      <Separator />
                      <div className="space-y-3">
                        <h4 className="text-sm font-semibold">Memo Information</h4>
                        {[
                          { key: 'memo_ref', label: 'Memo Reference', value: memoData.memoRef },
                          { key: 'plant', label: 'Plant', value: memoData.testData.plant },
                          { key: 'officer', label: 'Officer', value: memoData.testData.officer },
                          { key: 'category', label: 'Category', value: memoData.testData.category },
                          { key: 'date_created', label: 'Date Created', value: memoData.testData.dateCreated }
                        ].map(({ key, label, value }) => (
                          <div key={key} className="flex items-center space-x-3">
                            <Checkbox
                              checked={selectedFields.includes(key)}
                              onCheckedChange={(checked) => handleFieldToggle(key, checked as boolean)}
                            />
                            <div className="flex-1">
                              <Label className="text-sm font-medium">{label}</Label>
                              <p className="text-xs text-muted-foreground">
                                Value: {String(value)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </ScrollArea>
                </div>

                {/* Right: Report Preview & Actions */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Report Preview</h3>
                  <div className="border rounded-lg p-4 bg-muted/20 min-h-64">
                    <div className="space-y-3">
                      <div className="text-center border-b pb-2 mb-4">
                        <h2 className="text-lg font-bold">Test Report</h2>
                        <p className="text-sm text-muted-foreground">
                          Memo: {memoData.memoRef}
                        </p>
                      </div>
                      
                      {selectedFields.map((fieldName) => {
                        const value = fieldName === 'memo_ref' ? memoData.memoRef :
                                    fieldName === 'plant' ? memoData.testData.plant :
                                    fieldName === 'officer' ? memoData.testData.officer :
                                    fieldName === 'category' ? memoData.testData.category :
                                    fieldName === 'date_created' ? memoData.testData.dateCreated :
                                    memoData.testData.testResults?.[fieldName];
                        
                        return (
                          <div key={fieldName} className="flex justify-between text-sm">
                            <span className="font-medium">{fieldName.replace(/_/g, ' ')}:</span>
                            <span>{String(value)}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-charts" />
                      <Label htmlFor="include-charts">Include Analytics Charts</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-signature" />
                      <Label htmlFor="include-signature">Include Signature Block</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-qr" />
                      <Label htmlFor="include-qr">Include QR Code</Label>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      onClick={generateMemoReport}
                      disabled={selectedFields.length === 0 || loading}
                      className="flex-1"
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4 mr-2" />
                          Generate PDF
                        </>
                      )}
                    </Button>
                    <Button variant="outline" onClick={() => setShowMemoReportDialog(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Upload Dialog */}
        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Import Template</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="text-center border-2 border-dashed border-muted-foreground/25 rounded-lg p-8">
                <CloudUpload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-4">
                  Upload DOCX, XLSX, or PDF templates to convert them
                </p>
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={loading || !selectedCategory}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".docx,.xlsx,.pdf"
                  className="hidden"
                  onChange={handleTemplateUpload}
                />
              </div>
              
              {uploadProgress > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} />
                </div>
              )}
              
              {!selectedCategory && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Please select a category before uploading templates.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Chart Configuration Modal */}
      <ChartConfigurationModal
        isOpen={showChartConfig}
        onClose={() => {
          setShowChartConfig(false);
          setSelectedElementForChart(null);
        }}
        onSave={handleChartConfigSave}
        elementId={selectedElementForChart?.id || ''}
        initialBinding={selectedElementForChart ? chartBindings.get(selectedElementForChart.id) : undefined}
      />
    </LabLayout>
  );
}