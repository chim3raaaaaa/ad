import { useState, useEffect, useCallback, useMemo } from "react";
import { Calendar, Download, Settings, CheckSquare, FileText } from "lucide-react";
import { LabLayout } from "@/components/lab/LabLayout";
import { TestCalendarView } from "@/components/lab/TestCalendarView";
import { TestListView } from "@/components/lab/TestListView";
import { TestCalendarFilters } from "@/components/lab/TestCalendarFilters";
import { BatchOperationsPanel } from "@/components/test-calendar/BatchOperationsPanel";
import { ExportPanel } from "@/components/test-calendar/ExportPanel";
import { PerformanceMonitor } from "@/components/test-calendar/PerformanceMonitor";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTestCalendarService } from "@/hooks/useTestCalendarService";
import { TestCalendarFilters as CalendarFilters } from "@/services/database/realTimeTestCalendarService";
import { TestCalendarEvent } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { TestCalendarErrorBoundary } from "@/components/error/TestCalendarErrorBoundary";
import { TestCalendarInlineDrawer } from "@/components/test-calendar/TestCalendarInlineDrawer";
import { TestCalendarNotifications } from "@/components/test-calendar/TestCalendarNotifications";
import { TestScheduleModal } from "@/components/test-calendar/TestScheduleModal";
import { MemoDetailsModal } from "@/components/test-calendar/MemoDetailsModal";
import { realTimePerformanceService } from "@/services/calendar/realTimePerformanceService";
import { useDebounce } from "@/hooks/useDebounce";

const TestCalendar = () => {
  const [activeView, setActiveView] = useState<"calendar" | "list">("calendar");
  const [calendarViewMode, setCalendarViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [filters, setFilters] = useState<CalendarFilters>({});
  const [isMarkingDone, setIsMarkingDone] = useState<string | null>(null);
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showPerformanceModal, setShowPerformanceModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(true);
  const [selectedEventForDrawer, setSelectedEventForDrawer] = useState<TestCalendarEvent | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { events, loading, error, fetchEvents, markTestDone, refreshEvents, isRetrying } = useTestCalendarService();
  const { toast } = useToast();
  
  // Debounce filters to prevent rapid API calls
  const debouncedFilters = useDebounce(filters, 300);
  
  // Performance monitoring - get real metrics
  const [performanceMetrics, setPerformanceMetrics] = useState(realTimePerformanceService.getMetrics());
  
  // Simple pagination for events
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 50;
  
  const filteredEvents = useMemo(() => {
    if (!searchQuery) return events;
    return events.filter(event => 
      JSON.stringify(event).toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [events, searchQuery]);
  
  const totalPages = Math.ceil(filteredEvents.length / ITEMS_PER_PAGE);
  const optimizedEvents = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredEvents.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredEvents, currentPage]);
  
  const nextPage = () => setCurrentPage(prev => Math.min(prev + 1, totalPages));
  const prevPage = () => setCurrentPage(prev => Math.max(prev - 1, 1));

  // Refetch when debounced filters change
  useEffect(() => {
    fetchEvents(debouncedFilters);
  }, [debouncedFilters, fetchEvents]);

  const alertCounts = useMemo(() => {
    if (!events || events.length === 0) return { overdue: 0, dueToday: 0 };
    
    const overdueCount = events.filter(e => e.status === 'overdue').length;
    const dueTodayCount = events.filter(e => 
      (e.remaining_days || 0) === 0 && e.status !== 'overdue'
    ).length;
    
    return { overdue: overdueCount, dueToday: dueTodayCount };
  }, [events]);

  // Selection handlers
  const handleSelectEvent = useCallback((eventId: string, selected: boolean) => {
    setSelectedEvents(prev => 
      selected 
        ? [...prev, eventId]
        : prev.filter(id => id !== eventId)
    );
  }, []);

  const handleSelectAll = useCallback((checked: boolean) => {
    setSelectedEvents(checked ? optimizedEvents.map(e => e.id) : []);
  }, [optimizedEvents]);

  const handleClearSelection = useCallback(() => {
    setSelectedEvents([]);
    setShowBatchModal(false); // Close the batch modal when clearing
  }, []);

  const handleBatchRefresh = useCallback(() => {
    refreshEvents(debouncedFilters);
  }, [refreshEvents, debouncedFilters]);

  const handleViewMemoDetails = useCallback((memoId: string) => {
    toast({
      title: "Memo Details",
      description: `Opening memo ${memoId} details...`,
    });
    // This would navigate to memo details page in a real implementation
  }, [toast]);

  useEffect(() => {
    // Check for alerts on page load
    if (!loading && !error && (alertCounts.overdue > 0 || alertCounts.dueToday > 0)) {
      let message = "";
      if (alertCounts.dueToday > 0) {
        message += `🧪 ${alertCounts.dueToday} test${alertCounts.dueToday > 1 ? 's' : ''} due today`;
      }
      if (alertCounts.overdue > 0) {
        if (message) message += "\n";
        message += `❗ ${alertCounts.overdue} test${alertCounts.overdue > 1 ? 's are' : ' is'} overdue`;
      }

      toast({
        title: "Test Reminders",
        description: message,
        duration: 5000,
      });
    }
  }, [alertCounts, loading, error, toast]);

  const handleMarkDone = useCallback(async (eventId: string) => {
    setIsMarkingDone(eventId);
    
    try {
      const success = await markTestDone(eventId);
      
      if (success) {
        toast({
          title: "Success",
          description: "Test marked as completed",
        });
        // Refetch with current debounced filters
        fetchEvents(debouncedFilters);
      } else {
        throw new Error('Failed to mark test as done');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to mark test as done",
        variant: "destructive",
      });
    } finally {
      setIsMarkingDone(null);
    }
  }, [markTestDone, toast, fetchEvents, debouncedFilters]);

  if (loading && !events.length) {
    return (
      <LabLayout>
        <div className="p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">
              {isRetrying ? 'Retrying connection...' : 'Loading test calendar...'}
            </div>
          </div>
        </div>
      </LabLayout>
    );
  }

  if (error) {
    return (
      <LabLayout>
        <div className="p-6">
          <Card className="p-6">
            <div className="text-center text-destructive">
              <p>Error loading test calendar: {error}</p>
              <Button onClick={() => fetchEvents(filters)} className="mt-4">
                Retry
              </Button>
            </div>
          </Card>
        </div>
      </LabLayout>
    );
  }

  return (
    <TestCalendarErrorBoundary>
      <LabLayout>
        <div className="p-6 space-y-6">
          {/* Header with Advanced Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="h-6 w-6" />
              <div>
                <h1 className="text-2xl font-bold">Test Calendar</h1>
                <p className="text-sm text-muted-foreground">
                  Lab test reminders and scheduling
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={showBatchModal ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setShowBatchModal(true);
                  if (selectedEvents.length === 0) {
                    toast({
                      title: "Batch Operations",
                      description: "Select events from the calendar to perform batch operations",
                    });
                  }
                }}
                className={selectedEvents.length > 0 ? "bg-primary/10" : ""}
              >
                <CheckSquare className="h-4 w-4 mr-2" />
                Batch ({selectedEvents.length})
              </Button>
              
              <Button
                variant={showExportModal ? "default" : "outline"}
                size="sm"
                onClick={() => setShowExportModal(true)}
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              
              <Button
                variant={showPerformanceModal ? "default" : "outline"}
                size="sm"
                onClick={() => setShowPerformanceModal(true)}
              >
                <Settings className="h-4 w-4 mr-2" />
                Performance
              </Button>
            </div>
          </div>

          <TestCalendarFilters 
            filters={filters} 
            onFiltersChange={setFilters}
          />

          {/* Notifications Panel */}
          {showNotifications && events.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-muted-foreground">Active Alerts</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowNotifications(false)}
                  className="text-xs"
                >
                  Hide Notifications
                </Button>
              </div>
              <TestCalendarNotifications 
                events={events}
                onDismiss={(eventId) => {
                  console.log(`Dismissed notification for event: ${eventId}`);
                }}
              />
            </div>
          )}

           {loading && events.length > 0 && (
            <div className="text-sm text-muted-foreground text-center">
              {isRetrying ? 'Retrying...' : 'Updating...'}
            </div>
          )}

          <Tabs value={activeView} onValueChange={(value) => setActiveView(value as "calendar" | "list")}>
            <TabsList className="grid w-fit grid-cols-2">
              <TabsTrigger value="calendar">Calendar View</TabsTrigger>
              <TabsTrigger value="list">List View</TabsTrigger>
            </TabsList>

            <TabsContent value="calendar" className="mt-6">
              <TestCalendarView 
                events={optimizedEvents || []} 
                onMarkDone={handleMarkDone}
                selectedEvents={selectedEvents}
                onSelectEvent={handleSelectEvent}
                showSelection={showBatchModal}
                viewMode={calendarViewMode}
                onViewModeChange={setCalendarViewMode}
                onViewMemoDetails={handleViewMemoDetails}
                onAddTest={(date) => {
                  toast({
                    title: "Add Test",
                    description: `Add test functionality for ${date.toLocaleDateString()} will be implemented in the test modules.`,
                  });
                }}
                onFilterByDate={(date) => {
                  const dateStr = date.toISOString().split('T')[0];
                  setFilters(prev => ({
                    ...prev,
                    startDate: dateStr,
                    endDate: dateStr
                  }));
                  toast({
                    title: "Date Filter Applied",
                    description: `Showing events for ${date.toLocaleDateString()}`,
                  });
                }}
              />
            </TabsContent>

            <TabsContent value="list" className="mt-6">
              <TestListView 
                events={optimizedEvents || []} 
                onMarkDone={handleMarkDone}
                selectedEvents={selectedEvents}
                onSelectEvent={handleSelectEvent}
                showSelection={showBatchModal}
              />
            </TabsContent>
          </Tabs>
          
          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              <Button
                variant="outline"
                size="sm"
                onClick={prevPage}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              
              <span className="text-sm text-muted-foreground">
                Page {currentPage} of {totalPages}
              </span>
              
              <Button
                variant="outline"
                size="sm"
                onClick={nextPage}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          )}
          
          {/* Modal Components */}
          <BatchOperationsPanel
            selectedEvents={selectedEvents}
            onClearSelection={handleClearSelection}
            onRefresh={handleBatchRefresh}
            isOpen={showBatchModal}
            onClose={() => setShowBatchModal(false)}
          />
          
          <ExportPanel
            events={filteredEvents as TestCalendarEvent[]}
            isOpen={showExportModal}
            onClose={() => setShowExportModal(false)}
          />
          
          <PerformanceMonitor
            metrics={realTimePerformanceService.getMetrics()}
            isOpen={showPerformanceModal}
            onClose={() => setShowPerformanceModal(false)}
          />

          {/* Inline Detail Drawer */}
          <TestCalendarInlineDrawer
            event={selectedEventForDrawer}
            isOpen={!!selectedEventForDrawer}
            onClose={() => setSelectedEventForDrawer(null)}
            onMarkDone={handleMarkDone}
            onViewMemoDetails={handleViewMemoDetails}
          />
        </div>
      </LabLayout>
    </TestCalendarErrorBoundary>
  );
};

export default TestCalendar;