// React hook for unified data service integration
import { useState, useEffect, useCallback } from 'react';
import { unifiedDataService, type ApiResponse, type QueryOptions } from '@/lib/database/UnifiedDataService';
import { databaseMigration } from '@/lib/database/migration';

export function useUnifiedData() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [migrationStatus, setMigrationStatus] = useState<any>(null);

  // Initialize service and run migrations if needed
  useEffect(() => {
    const initialize = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Check if migration is needed
        const status = await databaseMigration.checkMigrationStatus();
        setMigrationStatus(status);

        // Initialize the unified data service
        await unifiedDataService.initialize();

        // Run migrations if needed
        if (status.needsMigration) {
          console.log('Running database migrations...');
          const migrationResult = await databaseMigration.runMigrations();
          if (!migrationResult.success) {
            console.warn('Some migrations failed:', migrationResult.results);
          }
        }

        setIsInitialized(true);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to initialize database');
        console.error('Database initialization failed:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initialize();
  }, []);

  // Health check
  const checkHealth = useCallback(async () => {
    try {
      return await unifiedDataService.healthCheck();
    } catch (err) {
      return {
        status: 'unhealthy',
        details: { error: err instanceof Error ? err.message : 'Unknown error' }
      };
    }
  }, []);

  return {
    isInitialized,
    isLoading,
    error,
    migrationStatus,
    service: unifiedDataService,
    checkHealth
  };
}

// Hook for memos
export function useMemos(options: QueryOptions = {}) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isInitialized } = useUnifiedData();

  const fetchMemos = useCallback(async () => {
    if (!isInitialized) return;

    try {
      setLoading(true);
      setError(null);
      const response = await unifiedDataService.getMemos(options);
      
      if (response.success && response.data) {
        setData(response.data);
      } else {
        setError(response.error || 'Failed to fetch memos');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [isInitialized, options]);

  useEffect(() => {
    fetchMemos();
  }, [fetchMemos]);

  const createMemo = useCallback(async (memo: any) => {
    try {
      const response = await unifiedDataService.createMemo(memo);
      if (response.success) {
        await fetchMemos(); // Refresh list
        return response;
      }
      throw new Error(response.error);
    } catch (err) {
      throw err;
    }
  }, [fetchMemos]);

  return {
    data,
    loading,
    error,
    refetch: fetchMemos,
    createMemo
  };
}

// Hook for test entries
export function useTestEntries(options: QueryOptions = {}) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isInitialized } = useUnifiedData();

  const fetchTestEntries = useCallback(async () => {
    if (!isInitialized) return;

    try {
      setLoading(true);
      setError(null);
      const response = await unifiedDataService.getTestEntries(options);
      
      if (response.success && response.data) {
        setData(response.data);
      } else {
        setError(response.error || 'Failed to fetch test entries');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [isInitialized, options]);

  useEffect(() => {
    fetchTestEntries();
  }, [fetchTestEntries]);

  const createTestEntry = useCallback(async (entry: any) => {
    try {
      const response = await unifiedDataService.createTestEntry(entry);
      if (response.success) {
        await fetchTestEntries(); // Refresh list
        return response;
      }
      throw new Error(response.error);
    } catch (err) {
      throw err;
    }
  }, [fetchTestEntries]);

  return {
    data,
    loading,
    error,
    refetch: fetchTestEntries,
    createTestEntry
  };
}

// Hook for reference data
export function useReferenceData(tableName: string, options: QueryOptions = {}) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isInitialized } = useUnifiedData();

  const fetchReferenceData = useCallback(async () => {
    if (!isInitialized || !tableName) return;

    try {
      setLoading(true);
      setError(null);
      const response = await unifiedDataService.getReferenceData(tableName, options);
      
      if (response.success && response.data) {
        setData(response.data);
      } else {
        setError(response.error || `Failed to fetch ${tableName}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [isInitialized, tableName, options]);

  useEffect(() => {
    fetchReferenceData();
  }, [fetchReferenceData]);

  return {
    data,
    loading,
    error,
    refetch: fetchReferenceData
  };
}

// Hook for RBAC permissions
export function usePermissions(userId: string) {
  const [permissions, setPermissions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const { isInitialized } = useUnifiedData();

  useEffect(() => {
    const fetchPermissions = async () => {
      if (!isInitialized || !userId) return;

      try {
        setLoading(true);
        const userPermissions = await unifiedDataService.getUserPermissions(userId);
        setPermissions(userPermissions);
      } catch (err) {
        console.error('Failed to fetch user permissions:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPermissions();
  }, [isInitialized, userId]);

  const hasPermission = useCallback((permission: string) => {
    return permissions.includes(permission);
  }, [permissions]);

  return {
    permissions,
    loading,
    hasPermission
  };
}