import { useState, useEffect } from 'react';
import { enhancedNotificationService, type EnhancedNotification } from '@/services/notifications/enhancedNotificationService';
import { useUser } from '@/contexts/UserContext';

export function useEnhancedNotifications() {
  const [notifications, setNotifications] = useState<EnhancedNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useUser();

  useEffect(() => {
    const loadNotifications = async () => {
      try {
        setLoading(true);
        const data = await enhancedNotificationService.loadNotifications();
        setNotifications(data);
        setError(null);
      } catch (err) {
        console.error('Error loading notifications:', err);
        setError('Failed to load notifications');
      } finally {
        setLoading(false);
      }
    };

    loadNotifications();

    // Subscribe to notification updates
    const unsubscribe = enhancedNotificationService.subscribe((updatedNotifications) => {
      setNotifications(updatedNotifications);
    });

    // Start periodic checks for new notifications
    enhancedNotificationService.startPeriodicChecks();

    return () => {
      unsubscribe();
      enhancedNotificationService.stopPeriodicChecks();
    };
  }, []);

  const createNotification = async (notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>) => {
    try {
      await enhancedNotificationService.createNotification(notification);
    } catch (err) {
      console.error('Error creating notification:', err);
    }
  };

  const markAsRead = async (id: string) => {
    try {
      await enhancedNotificationService.markAsRead(id);
    } catch (err) {
      console.error('Error marking notification as read:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await enhancedNotificationService.markAllAsRead();
    } catch (err) {
      console.error('Error marking all notifications as read:', err);
    }
  };

  const deleteNotification = async (id: string) => {
    try {
      await enhancedNotificationService.deleteNotification(id);
    } catch (err) {
      console.error('Error deleting notification:', err);
    }
  };

  const clearOldNotifications = async () => {
    try {
      await enhancedNotificationService.clearOldNotifications();
    } catch (err) {
      console.error('Error clearing old notifications:', err);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;
  const getByCategory = (category: string) => notifications.filter(n => n.category === category);

  return {
    notifications,
    loading,
    error,
    unreadCount,
    createNotification,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearOldNotifications,
    getByCategory
  };
}