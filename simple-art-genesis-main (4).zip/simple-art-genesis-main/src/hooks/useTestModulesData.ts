import { useState, useEffect } from 'react';
import { plantTestService, ProductCategory } from '@/services/database/plantTestService';

export function useProductCategories() {
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadCategories = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await plantTestService.getProductCategories();
      setCategories(result);
    } catch (err) {
      console.error('Error loading product categories:', err);
      setError('Failed to load product categories');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  return { categories, loading, error, reload: loadCategories };
}

export function useProductTypes(category: string) {
  const [productTypes, setProductTypes] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadProductTypes = async () => {
    if (!category) {
      setProductTypes([]);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const result = await plantTestService.getProductTypesForCategory(category);
      setProductTypes(result);
    } catch (err) {
      console.error('Error loading product types:', err);
      setError('Failed to load product types');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProductTypes();
  }, [category]);

  return { productTypes, loading, error, reload: loadProductTypes };
}

export function useValidation() {
  const validateProductType = async (category: string, productType: string): Promise<boolean> => {
    try {
      return await plantTestService.validateProductType(category, productType);
    } catch (error) {
      console.error('Error validating product type:', error);
      return false;
    }
  };

  const validatePlant = async (plantId: string): Promise<boolean> => {
    try {
      return await plantTestService.validatePlant(plantId);
    } catch (error) {
      console.error('Error validating plant:', error);
      return false;
    }
  };

  return { validateProductType, validatePlant };
}