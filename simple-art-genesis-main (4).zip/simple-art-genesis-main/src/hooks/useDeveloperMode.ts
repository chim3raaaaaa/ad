import { useDeveloperContext } from '@/contexts/DeveloperContext';
import { useUser } from '@/contexts/UserContext';

export const useDeveloperMode = () => {
  const { user } = useUser();
  const {
    isDeveloperMode,
    setDeveloperMode,
    showFloatingPanel,
    setShowFloatingPanel,
    debugMode,
    setDebugMode,
    isRolePreview,
    setRolePreview,
    originalRole,
    setOriginalRole
  } = useDeveloperContext();

  // Check if user has developer permissions (case-insensitive)
  const canUseDeveloperMode = user?.role?.toLowerCase() === 'admin';

  // Enable developer mode (bypass permission check)
  const enableDeveloperMode = () => {
    console.log('Enabling developer mode...');
    setDeveloperMode(true);
  };

  // Disable developer mode
  const disableDeveloperMode = () => {
    setDeveloperMode(false);
  };

  // Toggle floating panel
  const toggleFloatingPanel = () => {
    if (isDeveloperMode && canUseDeveloperMode) {
      setShowFloatingPanel(!showFloatingPanel);
    }
  };

  // Toggle debug mode
  const toggleDebugMode = () => {
    if (isDeveloperMode && canUseDeveloperMode) {
      setDebugMode(!debugMode);
    }
  };

  // Start role preview
  const startRolePreview = (newRole: string) => {
    if (isDeveloperMode && canUseDeveloperMode && !isRolePreview) {
      setOriginalRole(user?.role || null);
      setRolePreview(true);
    }
  };

  // Exit role preview
  const exitRolePreview = () => {
    if (isRolePreview) {
      setRolePreview(false);
      setOriginalRole(null);
    }
  };

  // Enhanced role preview function
  const setRolePreviewMode = (enabled: boolean, role?: string) => {
    if (enabled && !isRolePreview && role) {
      setOriginalRole(user?.role || null);
      setRolePreview(true);
    } else if (!enabled && isRolePreview) {
      setRolePreview(false);
      setOriginalRole(null);
    }
  };

  return {
    // State (bypass permission filtering)
    isDeveloperMode: isDeveloperMode,
    showFloatingPanel: showFloatingPanel && isDeveloperMode,
    debugMode: debugMode && isDeveloperMode,
    isRolePreview,
    originalRole,
    canUseDeveloperMode,

    // Actions
    enableDeveloperMode,
    disableDeveloperMode,
    toggleFloatingPanel,
    toggleDebugMode,
    startRolePreview,
    exitRolePreview,
    setRolePreview: setRolePreviewMode,
    setDeveloperMode,
    setShowFloatingPanel,
    setDebugMode
  };
};