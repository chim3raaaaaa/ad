import { useState, useEffect, useCallback } from 'react';
import { useDashboardLayout } from './useDashboardLayout';
import { widgetDataService, type DashboardData } from '@/services/dashboard/widgetDataService';
import { useUser } from '@/contexts/UserContext';
import type { DashboardWidget } from '@/types/dashboard';

export interface GridWidget extends DashboardWidget {
  data?: any;
}

export const useDashboardGrid = () => {
  const { user } = useUser();
  const userId = user?.id || 'user_1';
  
  const {
    currentLayout,
    availableWidgets,
    isLocked,
    loading: layoutLoading,
    error: layoutError,
    removeWidget,
    addWidget,
    updateWidgetPositions,
    getEnabledWidgets,
    canEditLayout,
    refresh: refreshLayout
  } = useDashboardLayout(userId, user?.role === 'admin');

  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [dataError, setDataError] = useState<string | null>(null);

  // Load dashboard data
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setDataLoading(true);
      setDataError(null);
      const data = await widgetDataService.getDashboardData();
      setDashboardData(data);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setDataError(error instanceof Error ? error.message : 'Failed to load dashboard data');
    } finally {
      setDataLoading(false);
    }
  };

  // Transform widgets with data
  const getWidgetsWithData = useCallback((): GridWidget[] => {
    if (!dashboardData) return [];
    
    const enabledWidgets = getEnabledWidgets();
    
    return enabledWidgets.map(widget => {
      let data = null;
      
      switch (widget.type) {
        case 'welcome':
          data = { userName: user?.fullName || 'User' };
          break;
        case 'kpi':
          data = getKPIData(widget.id, dashboardData);
          break;
        case 'chart':
          data = getChartData(widget.id, dashboardData);
          break;
        case 'calendar':
          data = { events: dashboardData.upcomingTestCalendar };
          break;
        default:
          break;
      }
      
      return { ...widget, data };
    });
  }, [dashboardData, getEnabledWidgets, user?.fullName]);

  const handleLayoutChange = useCallback((newLayout: any[]) => {
    if (!currentLayout || !canEditLayout()) return;
    
    const updatedWidgets = availableWidgets.map(widget => {
      const layoutItem = newLayout.find(item => item.i === widget.id);
      if (layoutItem) {
        return {
          ...widget,
          x: layoutItem.x,
          y: layoutItem.y,
          w: layoutItem.w,
          h: layoutItem.h
        };
      }
      return widget;
    });
    
    updateWidgetPositions(updatedWidgets);
  }, [currentLayout, availableWidgets, canEditLayout, updateWidgetPositions]);

  const handleRemoveWidget = useCallback((widgetId: string) => {
    removeWidget(widgetId);
  }, [removeWidget]);

  const handleAddWidget = useCallback((widget: DashboardWidget) => {
    console.log('useDashboardGrid: Adding widget:', widget);
    addWidget(widget);
  }, [addWidget]);

  const refreshAll = useCallback(() => {
    refreshLayout();
    loadDashboardData();
  }, [refreshLayout]);

  return {
    // Layout state
    currentLayout,
    isLocked,
    canEdit: canEditLayout(),
    
    // Data state
    widgets: getWidgetsWithData(),
    dashboardData,
    
    // Loading states
    loading: layoutLoading || dataLoading,
    error: layoutError || dataError,
    
    // Actions
    onLayoutChange: handleLayoutChange,
    onRemoveWidget: handleRemoveWidget,
    onAddWidget: handleAddWidget,
    refresh: refreshAll
  };
};

// Helper functions for widget data
function getKPIData(widgetId: string, dashboardData: DashboardData) {
  // Handle both old hardcoded IDs and new predefined widget IDs
  if (widgetId.includes('kpi-total-memos') || widgetId === 'active-memos') {
    return {
      title: 'Total Memos',
      value: dashboardData.totalMemos,
      description: 'Current month submissions',
      color: 'text-blue-600'
    };
  }
  
  if (widgetId.includes('kpi-tests-due') || widgetId === 'pending-tests') {
    return {
      title: 'Tests Due Today',
      value: dashboardData.testsDueToday,
      description: 'Scheduled for today',
      color: 'text-orange-600'
    };
  }
  
  if (widgetId.includes('kpi-active-users') || widgetId === 'connection-status') {
    return {
      title: 'Active Users',
      value: dashboardData.activeUsersThisWeek,
      description: 'This week',
      color: 'text-green-600'
    };
  }
  
  // Legacy hardcoded IDs
  switch (widgetId) {
    case 'tests-in-progress':
      return {
        title: 'Block Fail Rate',
        value: `${dashboardData.blockFailRate}%`,
        description: 'Compressive test failures',
        color: 'text-red-600'
      };
    case 'completed-today':
      return {
        title: 'Pending Retests',
        value: dashboardData.pendingRetests,
        description: 'Awaiting retest completion',
        color: 'text-yellow-600'
      };
    default:
      return null;
  }
}

function getChartData(widgetId: string, dashboardData: DashboardData) {
  switch (widgetId) {
    case 'test-requests-chart':
      return {
        type: 'bar',
        data: dashboardData.mostTestedProducts,
        dataKey: 'count',
        nameKey: 'product'
      };
    case 'test-results-chart':
      return {
        type: 'pie',
        data: dashboardData.testStatusDistribution,
        dataKey: 'value',
        nameKey: 'name'
      };
    case 'monthly-trends-chart':
      return {
        type: 'line',
        data: dashboardData.monthlyTrends,
        dataKey: 'tests',
        nameKey: 'month'
      };
    default:
      return null;
  }
}