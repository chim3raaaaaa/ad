import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

export interface ReferenceFile {
  id: string;
  name: string;
  type: 'pdf' | 'image' | 'spreadsheet' | 'document';
  category: string;
  description?: string;
  file_path: string;
  file_size: number;
  uploaded_by: string;
  upload_date: string;
  last_accessed?: string;
  access_count: number;
  tags: string[];
  status: 'active' | 'archived';
}

export const useReferenceFileManager = () => {
  const [files, setFiles] = useState<ReferenceFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const loadFiles = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Check if running in Electron
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.dbQuery(
          'SELECT * FROM reference_files WHERE status = ? ORDER BY upload_date DESC',
          ['active']
        );
        setFiles(result || []);
      } else {
        // Browser storage fallback
        const storedFiles = localStorage.getItem('reference_files');
        const files = storedFiles ? JSON.parse(storedFiles) : [];
        setFiles(files.filter((f: ReferenceFile) => f.status === 'active'));
      }
    } catch (err) {
      console.error('Error loading reference files:', err);
      setError('Failed to load reference files');
      toast({
        title: "Load Error",
        description: "Failed to load reference files",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveFile = async (file: File, metadata: Omit<ReferenceFile, 'id' | 'file_path' | 'file_size' | 'upload_date' | 'access_count' | 'status'>) => {
    try {
      const newFile: ReferenceFile = {
        ...metadata,
        id: `file_${Date.now()}`,
        file_path: `/reference_files/${file.name}`,
        file_size: file.size,
        upload_date: new Date().toISOString(),
        access_count: 0,
        status: 'active'
      };

      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        // Save file to Electron
        const savedPath = await (window as any).electronAPI.saveFile(
          await file.arrayBuffer(),
          `reference_files/${file.name}`
        );
        
        newFile.file_path = savedPath;

        // Save metadata to database
        await (window as any).electronAPI.dbRun(
          `INSERT INTO reference_files 
           (id, name, type, category, description, file_path, file_size, uploaded_by, upload_date, last_accessed, access_count, tags, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newFile.id,
            newFile.name,
            newFile.type,
            newFile.category,
            newFile.description || '',
            newFile.file_path,
            newFile.file_size,
            newFile.uploaded_by,
            newFile.upload_date,
            newFile.last_accessed || '',
            newFile.access_count,
            JSON.stringify(newFile.tags),
            newFile.status
          ]
        );
      } else {
        // Browser storage - save metadata only (file would need separate handling)
        const storedFiles = localStorage.getItem('reference_files');
        const files = storedFiles ? JSON.parse(storedFiles) : [];
        files.push(newFile);
        localStorage.setItem('reference_files', JSON.stringify(files));
      }

      setFiles(prev => [...prev, newFile]);
      
      toast({
        title: "File Uploaded",
        description: `${newFile.name} has been uploaded successfully`
      });

      return newFile;
    } catch (err) {
      console.error('Error saving file:', err);
      toast({
        title: "Upload Error",
        description: "Failed to upload file",
        variant: "destructive"
      });
      throw err;
    }
  };

  const deleteFile = async (fileId: string) => {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await (window as any).electronAPI.dbRun(
          'UPDATE reference_files SET status = ? WHERE id = ?',
          ['archived', fileId]
        );
      } else {
        const storedFiles = localStorage.getItem('reference_files');
        const files = storedFiles ? JSON.parse(storedFiles) : [];
        const updatedFiles = files.map((f: ReferenceFile) => 
          f.id === fileId ? { ...f, status: 'archived' } : f
        );
        localStorage.setItem('reference_files', JSON.stringify(updatedFiles));
      }

      setFiles(prev => prev.filter(f => f.id !== fileId));
      
      toast({
        title: "File Deleted",
        description: "File has been archived successfully"
      });
    } catch (err) {
      console.error('Error deleting file:', err);
      toast({
        title: "Delete Error",
        description: "Failed to delete file",
        variant: "destructive"
      });
      throw err;
    }
  };

  const updateAccessCount = async (fileId: string) => {
    try {
      const updatedFiles = files.map(f => 
        f.id === fileId 
          ? { ...f, access_count: f.access_count + 1, last_accessed: new Date().toISOString() }
          : f
      );
      setFiles(updatedFiles);

      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await (window as any).electronAPI.dbRun(
          'UPDATE reference_files SET access_count = access_count + 1, last_accessed = ? WHERE id = ?',
          [new Date().toISOString(), fileId]
        );
      } else {
        localStorage.setItem('reference_files', JSON.stringify(updatedFiles));
      }
    } catch (err) {
      console.error('Error updating access count:', err);
    }
  };

  const searchFiles = (searchTerm: string, category?: string) => {
    return files.filter(file => {
      const matchesSearch = !searchTerm || 
        file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        file.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        file.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = !category || category === 'all' || file.category === category;
      
      return matchesSearch && matchesCategory && file.status === 'active';
    });
  };

  const getFilesByCategory = (category: string) => {
    return files.filter(f => f.category === category && f.status === 'active');
  };

  const getFileStats = () => {
    const totalFiles = files.filter(f => f.status === 'active').length;
    const totalSize = files.reduce((sum, f) => f.status === 'active' ? sum + f.file_size : sum, 0);
    const categoryCounts = files.reduce((acc, f) => {
      if (f.status === 'active') {
        acc[f.category] = (acc[f.category] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    return {
      totalFiles,
      totalSize,
      categoryCounts
    };
  };

  useEffect(() => {
    // Initialize table on first load
    const initializeTable = async () => {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        try {
          await (window as any).electronAPI.dbRun(`
            CREATE TABLE IF NOT EXISTS reference_files (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              type TEXT NOT NULL,
              category TEXT NOT NULL,
              description TEXT,
              file_path TEXT NOT NULL,
              file_size INTEGER NOT NULL,
              uploaded_by TEXT NOT NULL,
              upload_date TEXT NOT NULL,
              last_accessed TEXT,
              access_count INTEGER DEFAULT 0,
              tags TEXT DEFAULT '[]',
              status TEXT DEFAULT 'active',
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
          `);
        } catch (err) {
          console.error('Error creating reference_files table:', err);
        }
      }
    };

    initializeTable();
    loadFiles();
  }, []);

  return {
    files,
    loading,
    error,
    loadFiles,
    saveFile,
    deleteFile,
    updateAccessCount,
    searchFiles,
    getFilesByCategory,
    getFileStats
  };
};