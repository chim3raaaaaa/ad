import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import EnhancedValidationService from '@/services/validation/enhancedValidationService';
import type { ValidationResult } from '@/services/validation/validationTypes';

export interface ValidationHookResult {
  validationResults: ValidationResult[];
  isValidating: boolean;
  validateData: (data: Record<string, any>, category: string) => Promise<ValidationResult[]>;
  clearResults: () => void;
  hasErrors: boolean;
  hasWarnings: boolean;
  isValid: boolean;
}

export function useRealTimeValidation(): ValidationHookResult {
  const [validationResults, setValidationResults] = useState<ValidationResult[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const { toast } = useToast();

  const validateData = useCallback(async (data: Record<string, any>, category: string): Promise<ValidationResult[]> => {
    setIsValidating(true);
    try {
      const results = await EnhancedValidationService.validateTestResult(data, category);
      setValidationResults(results);
      
      // Show toast for critical failures
      const criticalFailures = results.filter(r => !r.passed && r.severity === 'critical');
      if (criticalFailures.length > 0) {
        toast({
          title: 'Validation Errors',
          description: `${criticalFailures.length} critical validation error(s) found`,
          variant: 'destructive'
        });
      }
      
      return results;
    } catch (error) {
      console.error('Validation error:', error);
      toast({
        title: 'Validation Error',
        description: 'Failed to validate data',
        variant: 'destructive'
      });
      return [];
    } finally {
      setIsValidating(false);
    }
  }, [toast]);

  const clearResults = useCallback(() => {
    setValidationResults([]);
  }, []);

  const hasErrors = validationResults.some(r => !r.passed && r.severity === 'critical');
  const hasWarnings = validationResults.some(r => !r.passed && r.severity === 'warning');
  const isValid = !hasErrors;

  return {
    validationResults,
    isValidating,
    validateData,
    clearResults,
    hasErrors,
    hasWarnings,
    isValid
  };
}

// Hook for validating specific fields in real-time
export function useFieldValidation(category: string) {
  const [fieldResults, setFieldResults] = useState<Record<string, ValidationResult[]>>({});
  const [isValidating, setIsValidating] = useState(false);

  const validateField = useCallback(async (fieldName: string, value: any, allData: Record<string, any> = {}) => {
    setIsValidating(true);
    try {
      // Get rules for this specific field
      const rules = await EnhancedValidationService.getRulesByCategory(category);
      const fieldRules = rules.filter(rule => rule.field === fieldName);
      
      if (fieldRules.length === 0) {
        setFieldResults(prev => ({ ...prev, [fieldName]: [] }));
        return [];
      }

      // Create test data with the field value
      const testData = { ...allData, [fieldName]: value };
      const results = await EnhancedValidationService.validateTestResult(testData, category);
      const fieldSpecificResults = results.filter(r => r.field === fieldName);
      
      setFieldResults(prev => ({ ...prev, [fieldName]: fieldSpecificResults }));
      return fieldSpecificResults;
    } catch (error) {
      console.error('Field validation error:', error);
      return [];
    } finally {
      setIsValidating(false);
    }
  }, [category]);

  const getFieldStatus = (fieldName: string): 'valid' | 'warning' | 'error' | 'none' => {
    const results = fieldResults[fieldName] || [];
    if (results.length === 0) return 'none';
    
    const hasError = results.some(r => !r.passed && r.severity === 'critical');
    const hasWarning = results.some(r => !r.passed && r.severity === 'warning');
    
    if (hasError) return 'error';
    if (hasWarning) return 'warning';
    return 'valid';
  };

  const getFieldMessages = (fieldName: string): string[] => {
    const results = fieldResults[fieldName] || [];
    return results.filter(r => !r.passed).map(r => r.message);
  };

  return {
    validateField,
    getFieldStatus,
    getFieldMessages,
    isValidating,
    fieldResults
  };
}