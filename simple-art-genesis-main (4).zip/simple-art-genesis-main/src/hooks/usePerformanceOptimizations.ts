import { useState, useEffect, useMemo, useCallback } from 'react';
import { useDebounce } from './useDebounce';

// Cache for dropdown options
const dropdownCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export function useDropdownCache<T>(key: string, fetchFunction: () => Promise<T>) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    // Check cache first
    const cached = dropdownCache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      setData(cached.data);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const result = await fetchFunction();
      setData(result);
      
      // Update cache
      dropdownCache.set(key, {
        data: result,
        timestamp: Date.now()
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, [key, fetchFunction]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const clearCache = useCallback(() => {
    dropdownCache.delete(key);
    fetchData();
  }, [key, fetchData]);

  return { data, loading, error, refresh: fetchData, clearCache };
}

export function useSearchableDropdown<T>(
  items: T[],
  searchKey: keyof T,
  searchTerm: string
) {
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const filteredItems = useMemo(() => {
    if (!debouncedSearchTerm) return items;
    
    return items.filter(item => {
      const value = item[searchKey];
      if (typeof value === 'string') {
        return value.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      }
      return false;
    });
  }, [items, searchKey, debouncedSearchTerm]);

  return filteredItems;
}

export function useBulkOperations<T>(
  items: T[],
  keyExtractor: (item: T) => string
) {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  const toggleItem = useCallback((item: T) => {
    const key = keyExtractor(item);
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      return newSet;
    });
  }, [keyExtractor]);

  const toggleSelectAll = useCallback(() => {
    if (selectAll) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(items.map(keyExtractor)));
    }
    setSelectAll(!selectAll);
  }, [selectAll, items, keyExtractor]);

  const clearSelection = useCallback(() => {
    setSelectedItems(new Set());
    setSelectAll(false);
  }, []);

  const getSelectedItems = useCallback(() => {
    return items.filter(item => selectedItems.has(keyExtractor(item)));
  }, [items, selectedItems, keyExtractor]);

  useEffect(() => {
    const allSelected = items.length > 0 && items.every(item => selectedItems.has(keyExtractor(item)));
    setSelectAll(allSelected);
  }, [items, selectedItems, keyExtractor]);

  return {
    selectedItems,
    selectAll,
    toggleItem,
    toggleSelectAll,
    clearSelection,
    getSelectedItems,
    selectedCount: selectedItems.size
  };
}

export function useVirtualizedList<T>(
  items: T[],
  itemHeight: number,
  containerHeight: number
) {
  const [scrollTop, setScrollTop] = useState(0);

  const visibleRange = useMemo(() => {
    const startIndex = Math.floor(scrollTop / itemHeight);
    const endIndex = Math.min(
      startIndex + Math.ceil(containerHeight / itemHeight) + 1,
      items.length
    );
    
    return { startIndex, endIndex };
  }, [scrollTop, itemHeight, containerHeight, items.length]);

  const visibleItems = useMemo(() => {
    return items.slice(visibleRange.startIndex, visibleRange.endIndex);
  }, [items, visibleRange]);

  const totalHeight = items.length * itemHeight;

  const handleScroll = useCallback((event: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(event.currentTarget.scrollTop);
  }, []);

  return {
    visibleItems,
    visibleRange,
    totalHeight,
    handleScroll,
    paddingTop: visibleRange.startIndex * itemHeight,
    paddingBottom: (items.length - visibleRange.endIndex) * itemHeight
  };
}

// Performance monitoring hook
export function usePerformanceMonitor(componentName: string) {
  useEffect(() => {
    const startTime = performance.now();
    
    return () => {
      const endTime = performance.now();
      const renderTime = endTime - startTime;
      
      if (renderTime > 100) { // Log slow renders
        console.warn(`Slow render detected in ${componentName}: ${renderTime.toFixed(2)}ms`);
      }
    };
  });

  const measureOperation = useCallback((operationName: string, operation: () => void | Promise<void>) => {
    const startTime = performance.now();
    
    const result = operation();
    
    if (result instanceof Promise) {
      return result.finally(() => {
        const endTime = performance.now();
        console.log(`${componentName} - ${operationName}: ${(endTime - startTime).toFixed(2)}ms`);
      });
    } else {
      const endTime = performance.now();
      console.log(`${componentName} - ${operationName}: ${(endTime - startTime).toFixed(2)}ms`);
      return result;
    }
  }, [componentName]);

  return { measureOperation };
}