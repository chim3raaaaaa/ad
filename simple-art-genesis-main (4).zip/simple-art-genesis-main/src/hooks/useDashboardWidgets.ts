import { useState, useEffect, useCallback } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useToast } from '@/hooks/use-toast';
import { usePermissions } from '@/services/rbac/guards';
import { dashboardService } from '@/services/database/dashboardService';
import type { DashboardWidget, DashboardLayout } from '@/types/dashboard';

export const useDashboardWidgets = () => {
  const { user } = useUser();
  const { toast } = useToast();
  const { canManageDashboard, canEditDashboard } = usePermissions();
  const [widgets, setWidgets] = useState<DashboardWidget[]>([]);
  const [currentLayout, setCurrentLayout] = useState<DashboardLayout | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const userId = user?.id || 'user_1';

  useEffect(() => {
    loadDashboard();
  }, [userId]);

  const loadDashboard = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      await dashboardService.initializeTables();
      const layout = await dashboardService.getCurrentLayout(userId);
      
      if (layout) {
        setCurrentLayout(layout);
        // Filter only enabled widgets
        const enabledWidgets = layout.widgets.filter(w => w.enabled);
        setWidgets(enabledWidgets);
      } else {
        // No layout found, show error
        setError('No dashboard layout found. Please contact administrator.');
      }
    } catch (error) {
      console.error('Error loading dashboard:', error);
      setError('Failed to load dashboard. Please try again or contact support.');
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [userId, toast]);

  const addWidget = useCallback(async (widget: DashboardWidget) => {
    if (!canEditDashboard()) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit the dashboard",
        variant: "destructive"
      });
      return;
    }

    if (!currentLayout) {
      toast({
        title: "Error",
        description: "No active layout found",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Adding widget:', widget);
      await dashboardService.addWidget(userId, currentLayout.id, widget);
      await loadDashboard(); // Reload to get fresh data
      
      toast({
        title: "Widget Added",
        description: `${widget.title} has been added to your dashboard`
      });
    } catch (error) {
      console.error('Error adding widget:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add widget",
        variant: "destructive"
      });
    }
  }, [userId, currentLayout, canEditDashboard, loadDashboard, toast]);

  const removeWidget = useCallback(async (widgetId: string) => {
    if (!canEditDashboard()) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit the dashboard",
        variant: "destructive"
      });
      return;
    }

    if (!currentLayout) {
      toast({
        title: "Error",
        description: "No active layout found",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Removing widget:', widgetId);
      await dashboardService.removeWidget(userId, currentLayout.id, widgetId);
      await loadDashboard(); // Reload to get fresh data
      
      toast({
        title: "Widget Removed",
        description: "Widget has been removed from your dashboard"
      });
    } catch (error) {
      console.error('Error removing widget:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove widget",
        variant: "destructive"
      });
    }
  }, [userId, currentLayout, canEditDashboard, loadDashboard, toast]);

  const updateWidgetPositions = useCallback(async (updatedWidgets: DashboardWidget[]) => {
    if (!canEditDashboard()) {
      return;
    }

    if (!currentLayout) {
      toast({
        title: "Error",
        description: "No active layout found",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Updating widget positions:', updatedWidgets);
      await dashboardService.updateWidgetPositions(userId, currentLayout.id, updatedWidgets);
      // Don't reload dashboard to avoid interrupting drag operations
      setWidgets(updatedWidgets);
    } catch (error) {
      console.error('Error updating widget positions:', error);
      toast({
        title: "Error",
        description: "Failed to save widget positions",
        variant: "destructive"
      });
    }
  }, [userId, currentLayout, canEditDashboard, toast]);

  const refreshDashboard = useCallback(() => {
    loadDashboard();
  }, [loadDashboard]);

  return {
    widgets,
    currentLayout,
    loading,
    error,
    addWidget,
    removeWidget,
    updateWidgetPositions,
    refreshDashboard,
    canEdit: canEditDashboard(),
    canManage: canManageDashboard()
  };
};