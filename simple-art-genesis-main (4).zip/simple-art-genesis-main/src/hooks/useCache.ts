import { useState, useCallback, useRef } from 'react';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresAt: number;
}

interface CacheOptions {
  ttl?: number; // Time to live in milliseconds
  maxSize?: number; // Maximum number of entries
}

/**
 * Custom hook for implementing in-memory caching with TTL support
 */
export function useCache<T>(options: CacheOptions = {}) {
  const { ttl = 5 * 60 * 1000, maxSize = 100 } = options; // Default 5 minutes TTL
  
  const cache = useRef(new Map<string, CacheEntry<T>>());
  const [cacheSize, setCacheSize] = useState(0);

  const get = useCallback((key: string): T | null => {
    const entry = cache.current.get(key);
    
    if (!entry) {
      return null;
    }

    if (Date.now() > entry.expiresAt) {
      cache.current.delete(key);
      setCacheSize(cache.current.size);
      return null;
    }

    return entry.data;
  }, []);

  const set = useCallback((key: string, data: T, customTtl?: number): void => {
    const effectiveTtl = customTtl || ttl;
    const now = Date.now();
    
    // Remove expired entries if we're at max capacity
    if (cache.current.size >= maxSize) {
      const keysToDelete: string[] = [];
      
      for (const [k, entry] of cache.current.entries()) {
        if (now > entry.expiresAt) {
          keysToDelete.push(k);
        }
      }
      
      keysToDelete.forEach(k => cache.current.delete(k));
      
      // If still at capacity, remove oldest entry
      if (cache.current.size >= maxSize) {
        const firstKey = cache.current.keys().next().value;
        if (firstKey) {
          cache.current.delete(firstKey);
        }
      }
    }

    cache.current.set(key, {
      data,
      timestamp: now,
      expiresAt: now + effectiveTtl
    });
    
    setCacheSize(cache.current.size);
  }, [ttl, maxSize]);

  const remove = useCallback((key: string): boolean => {
    const deleted = cache.current.delete(key);
    if (deleted) {
      setCacheSize(cache.current.size);
    }
    return deleted;
  }, []);

  const clear = useCallback((): void => {
    cache.current.clear();
    setCacheSize(0);
  }, []);

  const has = useCallback((key: string): boolean => {
    const entry = cache.current.get(key);
    if (!entry) return false;
    
    if (Date.now() > entry.expiresAt) {
      cache.current.delete(key);
      setCacheSize(cache.current.size);
      return false;
    }
    
    return true;
  }, []);

  const cleanup = useCallback((): number => {
    const now = Date.now();
    const keysToDelete: string[] = [];
    
    for (const [key, entry] of cache.current.entries()) {
      if (now > entry.expiresAt) {
        keysToDelete.push(key);
      }
    }
    
    keysToDelete.forEach(key => cache.current.delete(key));
    setCacheSize(cache.current.size);
    
    return keysToDelete.length;
  }, []);

  return {
    get,
    set,
    remove,
    clear,
    has,
    cleanup,
    size: cacheSize
  };
}