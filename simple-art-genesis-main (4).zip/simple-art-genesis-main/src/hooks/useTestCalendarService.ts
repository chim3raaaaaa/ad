import { useState, useEffect, useCallback } from 'react';
import { TestCalendarEvent, TestCalendarFilters } from '../services/database/realTimeTestCalendarService';
import { testCalendarDataService } from '../services/calendar/testCalendarDataService';
import { realTimePerformanceService } from '../services/calendar/realTimePerformanceService';
import { testCalendarCache } from '../services/cache/testCalendarCache';
import { useRetry } from './useRetry';

export function useTestCalendarService() {
  const [events, setEvents] = useState<TestCalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { retry, isRetrying } = useRetry({ maxAttempts: 3, baseDelay: 1000 });

  const fetchEvents = useCallback(async (filters?: TestCalendarFilters) => {
    setLoading(true);
    setError(null);
    
    // Start performance monitoring
    realTimePerformanceService.startTimer('pageLoad');
    realTimePerformanceService.startTimer('api');
    
    // Check cache first
    const cachedEvents = testCalendarCache.getEvents(filters);
    if (cachedEvents) {
      realTimePerformanceService.recordCacheHit();
      realTimePerformanceService.endTimer('pageLoad');
      realTimePerformanceService.updateEventsCount(cachedEvents.length);
      setEvents(cachedEvents);
      setLoading(false);
      return;
    }
    
    try {
      const data = await retry(async () => {
        await testCalendarDataService.initialize();
        return await testCalendarDataService.getTestEvents(filters);
      });
      
      realTimePerformanceService.endTimer('api');
      realTimePerformanceService.endTimer('pageLoad');
      realTimePerformanceService.updateEventsCount(data.length);
      
      setEvents(data);
      // Cache the results
      testCalendarCache.setEvents(data, filters);
      console.log(`Fetched ${data.length} test events with filters:`, filters);
    } catch (err) {
      realTimePerformanceService.endTimer('api');
      realTimePerformanceService.endTimer('pageLoad');
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch test events';
      setError(errorMessage);
      console.error('Error in useTestCalendarService.fetchEvents:', err);
      setEvents([]); // Clear events on error
    } finally {
      setLoading(false);
    }
  }, [retry]);

  const markTestDone = useCallback(async (eventId: string) => {
    try {
      const success = await retry(async () => {
        return await testCalendarDataService.markTestDone(eventId);
      });
      
      if (success) {
        // Invalidate cache after successful update
        testCalendarCache.invalidateEvents();
        // Refresh events to show updated data
        await fetchEvents();
      }
      
      console.log(`Mark test done result for ${eventId}:`, success);
      return success;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to mark test as done';
      setError(errorMessage);
      console.error('Error in useTestCalendarService.markTestDone:', err);
      return false;
    }
  }, [retry, fetchEvents]);

  const refreshEvents = useCallback(async (filters?: TestCalendarFilters) => {
    // Invalidate cache before refresh
    testCalendarCache.invalidateEvents();
    await fetchEvents(filters);
  }, [fetchEvents]);

  // Initial load without filters
  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  return {
    events,
    loading: loading || isRetrying,
    error,
    fetchEvents,
    markTestDone,
    refreshEvents,
    isRetrying
  };
}