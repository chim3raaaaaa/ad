import { useState, useEffect, useCallback } from 'react';
import { useDataService } from './useDataService';

// Mock data removed - using empty arrays
const getMockTestData = (filters: TestDataFilters): TestDataEntry[] => {
  return [];
};

export interface TestDataEntry {
  id: string;
  module_id: string;
  test_type: string;
  batch_id?: string;
  product_type?: string;
  test_date: string;
  site?: string;
  memo_reference?: string;
  operator?: string;
  test_results: Record<string, any>;
  calculated_fields?: Record<string, any>;
  pass_fail_status: 'pass' | 'fail' | 'pending';
  source: 'manual' | 'imported' | 'liveshare';
  raw_data?: any;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface TestDataFilters {
  moduleId?: string;
  testType?: string;
  productType?: string;
  site?: string;
  operator?: string;
  passFail?: string;
  source?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
}

export function useTestDataEntries(filters: TestDataFilters = {}) {
  const dataService = useDataService();
  const [data, setData] = useState<TestDataEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await (dataService as any).getTestDataEntries({
        ...filters,
        limit: 1000
      });
      
      if (response.error) {
        setError(response.error);
        // Provide fallback mock data when running in browser
        setData(getMockTestData(filters));
      } else {
        setData(response.data || []);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch test data');
      // Provide fallback mock data on error
      setData(getMockTestData(filters));
    } finally {
      setLoading(false);
    }
  }, [dataService, filters]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const exportData = useCallback(async (format: 'csv' | 'excel' | 'pdf' = 'csv') => {
    try {
      const response = await (dataService as any).exportTestData(filters, format);
      if (response.error) {
        throw new Error(response.error);
      }
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to export data');
      return null;
    }
  }, [dataService, filters]);

  return {
    data,
    loading,
    error,
    refetch: fetchData,
    exportData
  };
}