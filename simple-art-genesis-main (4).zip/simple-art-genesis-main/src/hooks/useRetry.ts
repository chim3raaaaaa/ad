import { useState, useCallback } from 'react';

interface RetryOptions {
  maxAttempts?: number;
  baseDelay?: number;
  maxDelay?: number;
  backoffFactor?: number;
}

interface RetryState {
  isRetrying: boolean;
  attempt: number;
  lastError: Error | null;
}

/**
 * Custom hook for implementing exponential backoff retry logic
 */
export function useRetry(options: RetryOptions = {}) {
  const {
    maxAttempts = 3,
    baseDelay = 1000,
    maxDelay = 10000,
    backoffFactor = 2
  } = options;

  const [retryState, setRetryState] = useState<RetryState>({
    isRetrying: false,
    attempt: 0,
    lastError: null
  });

  const calculateDelay = useCallback((attempt: number): number => {
    const delay = baseDelay * Math.pow(backoffFactor, attempt);
    return Math.min(delay, maxDelay);
  }, [baseDelay, backoffFactor, maxDelay]);

  const retry = useCallback(async <T>(
    operation: () => Promise<T>,
    onError?: (error: Error, attempt: number) => void
  ): Promise<T> => {
    setRetryState(prev => ({ ...prev, isRetrying: true, attempt: 0 }));

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        const result = await operation();
        setRetryState({
          isRetrying: false,
          attempt: 0,
          lastError: null
        });
        return result;
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error));
        
        setRetryState(prev => ({
          ...prev,
          attempt: attempt + 1,
          lastError: err
        }));

        if (onError) {
          onError(err, attempt + 1);
        }

        if (attempt === maxAttempts - 1) {
          setRetryState(prev => ({ ...prev, isRetrying: false }));
          throw err;
        }

        // Wait before next attempt
        if (attempt < maxAttempts - 1) {
          const delay = calculateDelay(attempt);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    throw new Error('Maximum retry attempts exceeded');
  }, [maxAttempts, calculateDelay]);

  const reset = useCallback(() => {
    setRetryState({
      isRetrying: false,
      attempt: 0,
      lastError: null
    });
  }, []);

  return {
    retry,
    reset,
    ...retryState
  };
}