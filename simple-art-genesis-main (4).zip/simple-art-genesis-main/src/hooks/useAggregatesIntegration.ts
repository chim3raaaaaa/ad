import { useState, useEffect } from 'react';
import { aggregateTestService } from '@/services/database/aggregateTestService';
import { useAllDropdownOptions } from '@/hooks/useReferenceData';

export function useAggregatesIntegration() {
  const [memoOptions, setMemoOptions] = useState<Array<{ id: string; title: string; plant_id: string; machine_no: string; aggregate_type: string }>>([]);
  const [aggregateTypes, setAggregateTypes] = useState<Array<{ id: string; name: string }>>([]);
  const [loading, setLoading] = useState(false);
  
  const { data: dropdownOptions } = useAllDropdownOptions();

  const loadMemoOptions = async () => {
    setLoading(true);
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(`
          SELECT 
            id,
            title,
            plant_id,
            machine_no,
            aggregate_type
          FROM memos 
          WHERE category = 'aggregates'
          ORDER BY created_at DESC
        `);
        
        if (result.success) {
          setMemoOptions(result.data || []);
        }
      }
    } catch (error) {
      console.error('Error loading memo options:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAggregateTypes = () => {
    if (dropdownOptions?.aggregateTypes) {
      setAggregateTypes(dropdownOptions.aggregateTypes);
    }
  };

  useEffect(() => {
    loadMemoOptions();
  }, []);

  useEffect(() => {
    if (dropdownOptions) {
      loadAggregateTypes();
    }
  }, [dropdownOptions]);

  const createTestEntry = async (tableName: string, data: any) => {
    return await aggregateTestService.createTestEntry(tableName, data);
  };

  const getPlantDatabases = async () => {
    return await aggregateTestService.getPlantDatabases();
  };

  const createPlantDatabase = async (plantId: string, plantName: string, productType: string) => {
    return await aggregateTestService.createPlantDatabase(plantId, plantName, productType);
  };

  return {
    memoOptions,
    aggregateTypes,
    loading,
    loadMemoOptions,
    createTestEntry,
    getPlantDatabases,
    createPlantDatabase,
    dropdownOptions
  };
}