import { useState, useEffect } from 'react';
import { memoTestService, MemoTestAssignment, MemoTestDashboardData, MemoWithTests } from '@/services/database/memoTestService';

export function useMemoTestSystem() {
  const [memos, setMemos] = useState<MemoTestDashboardData[]>([]);
  const [pendingTests, setPendingTests] = useState<MemoTestAssignment[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load dashboard data
  const loadMemos = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await memoTestService.getDashboardData();
      setMemos(data);
    } catch (err) {
      console.error('Error loading memos:', err);
      setError('Failed to load memo data');
    } finally {
      setLoading(false);
    }
  };

  // Load pending tests
  const loadPendingTests = async (category?: string) => {
    setLoading(true);
    setError(null);
    try {
      const tests = await memoTestService.getPendingTests(category);
      setPendingTests(tests);
    } catch (err) {
      console.error('Error loading pending tests:', err);
      setError('Failed to load pending tests');
    } finally {
      setLoading(false);
    }
  };

  // Create memo with tests
  const createMemoWithTests = async (data: MemoWithTests): Promise<string> => {
    try {
      const memoRef = await memoTestService.createMemoWithTests(data);
      await loadMemos();
      await loadPendingTests();
      return memoRef;
    } catch (err) {
      console.error('Error creating memo with tests:', err);
      throw err;
    }
  };

  // Update test status
  const updateTestStatus = async (assignmentId: string, status: MemoTestAssignment['status'], testResults?: Record<string, any>): Promise<void> => {
    try {
      await memoTestService.updateTestStatus(assignmentId, status, testResults);
      await loadMemos();
      await loadPendingTests();
    } catch (err) {
      console.error('Error updating test status:', err);
      throw err;
    }
  };

  // Get memo by reference
  const getMemoByRef = async (memoRef: string): Promise<MemoTestDashboardData | null> => {
    try {
      return await memoTestService.getMemoByRef(memoRef);
    } catch (err) {
      console.error('Error getting memo by reference:', err);
      return null;
    }
  };

  // Submit test result
  const submitTestResult = async (assignmentId: string, testResults: Record<string, any>): Promise<void> => {
    try {
      await memoTestService.submitTestResult(assignmentId, testResults);
      await loadMemos();
      await loadPendingTests();
    } catch (err) {
      console.error('Error submitting test result:', err);
      throw err;
    }
  };

  // Get test assignments for a memo
  const getMemoTestAssignments = async (memoRef: string): Promise<MemoTestAssignment[]> => {
    try {
      return await memoTestService.getMemoTestAssignments(memoRef);
    } catch (err) {
      console.error('Error getting memo test assignments:', err);
      return [];
    }
  };

  // Delete memo
  const deleteMemo = async (memoRef: string): Promise<void> => {
    try {
      await memoTestService.deleteMemo(memoRef);
      await loadMemos();
      await loadPendingTests();
    } catch (err) {
      console.error('Error deleting memo:', err);
      throw err;
    }
  };

  // Refresh all data
  const refreshData = async () => {
    await Promise.all([loadMemos(), loadPendingTests()]);
  };

  // Initialize data on mount
  useEffect(() => {
    loadMemos();
    loadPendingTests();
  }, []);

  return {
    memos,
    pendingTests,
    loading,
    error,
    createMemoWithTests,
    updateTestStatus,
    getMemoByRef,
    submitTestResult,
    getMemoTestAssignments,
    deleteMemo,
    refreshData,
    loadPendingTests
  };
}