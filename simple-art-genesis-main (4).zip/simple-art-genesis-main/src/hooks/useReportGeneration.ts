import { useState, useCallback, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { TemplateToPdfService, CanvasBlock, ReportTemplate } from '@/services/reporting/templateToPdfService';
import { DataBindingService } from '@/services/reporting/dataBindingService';
import { EnhancedReportsService } from '@/services/database/enhancedReportsService';
import { EnhancedAnalyticsIntegration } from '@/services/reporting/enhancedAnalyticsIntegration';
import { FileUploadService } from '@/services/storage/fileUploadService';

export interface UseReportGenerationReturn {
  generateFromCanvas: (blocks: CanvasBlock[], memoId?: string, templateName?: string) => Promise<Blob | null>;
  generateFromTemplate: (template: ReportTemplate, memoId?: string) => Promise<Blob | null>;
  generatePreview: (blocks: CanvasBlock[], templateName?: string) => Promise<Blob | null>;
  saveTemplate: (name: string, blocks: CanvasBlock[], productType: string) => Promise<boolean>;
  loadTemplate: (templateId: string) => Promise<ReportTemplate | null>;
  bindMemoToTemplate: (memoId: string) => Promise<any>;
  uploadTemplate: (file: File, productType: string, uploadedBy: string) => Promise<boolean>;
  getTemplatesByProduct: (productType: string) => Promise<ReportTemplate[]>;
  getAnalyticsCharts: () => Promise<any[]>;
  getChartData: (chartId: string, memoId?: string) => Promise<any>;
  deleteTemplate: (templateId: string) => Promise<boolean>;
  isGenerating: boolean;
  isInitialized: boolean;
}

export function useReportGeneration(): UseReportGenerationReturn {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const { toast } = useToast();
  const dataBindingService = new DataBindingService();

  // Initialize services on mount
  useEffect(() => {
    const initialize = async () => {
      try {
        await EnhancedReportsService.initializeSchema();
        await FileUploadService.initializeDirectories();
        setIsInitialized(true);
      } catch (error) {
        console.error('Failed to initialize report services:', error);
        toast({
          title: "Initialization Error",
          description: "Failed to initialize report generation services",
          variant: "destructive"
        });
      }
    };

    initialize();
  }, [toast]);

  // Generate PDF from canvas blocks
  const generateFromCanvas = useCallback(async (
    blocks: CanvasBlock[], 
    memoId?: string, 
    templateName?: string
  ): Promise<Blob | null> => {
    setIsGenerating(true);
    
    try {
      const template: ReportTemplate = {
        id: `temp_${Date.now()}`,
        name: templateName || 'Temporary Template',
        productType: 'general',
        blocks,
        layoutJson: JSON.stringify(blocks)
      };

      let reportData;
      
      if (memoId) {
        reportData = await dataBindingService.bindMemoData(memoId);
      } else {
        reportData = await dataBindingService.bindMemoData('mock');
      }

      const pdfBlob = await TemplateToPdfService.generateFromTemplate(
        template, 
        reportData,
        memoId ? 'UBP Internal Use' : 'PREVIEW MODE'
      );

      toast({
        title: "Report Generated",
        description: "Report generated successfully"
      });
      
      return pdfBlob;
      
    } catch (error) {
      console.error('Error generating report:', error);
      toast({
        title: "Generation Error",
        description: "Failed to generate report",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [toast]);

  // Generate PDF from saved template
  const generateFromTemplate = useCallback(async (
    template: ReportTemplate, 
    memoId?: string
  ): Promise<Blob | null> => {
    setIsGenerating(true);
    
    try {
      let reportData;
      
      if (memoId) {
        reportData = await dataBindingService.bindMemoData(memoId);
      } else {
        reportData = await dataBindingService.bindMemoData('mock');
      }

      const pdfBlob = await TemplateToPdfService.generateFromTemplate(
        template, 
        reportData,
        memoId ? 'UBP Internal Use' : 'PREVIEW MODE'
      );

      toast({
        title: "Report Generated",
        description: "Report generated successfully from template"
      });
      
      return pdfBlob;
      
    } catch (error) {
      console.error('Error generating from template:', error);
      toast({
        title: "Generation Error", 
        description: "Failed to generate report from template",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [toast]);

  // Generate preview with mock data
  const generatePreview = useCallback(async (
    blocks: CanvasBlock[], 
    templateName?: string
  ): Promise<Blob | null> => {
    setIsGenerating(true);
    
    try {
      const template: ReportTemplate = {
        id: `preview_${Date.now()}`,
        name: templateName || 'Preview Template',
        productType: 'general',
        blocks,
        layoutJson: JSON.stringify(blocks)
      };

      const pdfBlob = await TemplateToPdfService.generatePreview(template);
      
      toast({
        title: "Preview Generated",
        description: "Preview generated successfully"
      });
      
      return pdfBlob;
      
    } catch (error) {
      console.error('Error generating preview:', error);
      toast({
        title: "Preview Error",
        description: "Failed to generate preview",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, [toast]);

  // Save template to database
  const saveTemplate = useCallback(async (
    name: string, 
    blocks: CanvasBlock[], 
    productType: string
  ): Promise<boolean> => {
    try {
      const templateId = await EnhancedReportsService.saveTemplate({
        name,
        product_type: productType,
        layout_json: JSON.stringify(blocks),
        uploaded_by: 'current_user',
        template_type: 'canvas',
        version: 1,
        is_active: true
      });

      if (!templateId) {
        throw new Error('Failed to save template');
      }

      toast({
        title: "Template Saved",
        description: `Template "${name}" has been saved successfully`,
      });

      return true;
    } catch (error) {
      console.error('Failed to save template:', error);
      toast({
        title: "Save Template Error",
        description: "Failed to save the template",
        variant: "destructive"
      });
      return false;
    }
  }, [toast]);

  // Load a saved template
  const loadTemplate = useCallback(async (templateId: string): Promise<ReportTemplate | null> => {
    try {
      const template = await EnhancedReportsService.getTemplateById(templateId);
      
      if (!template) {
        toast({
          title: "Template Not Found",
          description: "The requested template could not be found",
          variant: "destructive"
        });
        return null;
      }

      return {
        id: template.id,
        name: template.name,
        productType: template.product_type,
        layoutJson: template.layout_json,
        blocks: JSON.parse(template.layout_json || '[]')
      };
    } catch (error) {
      console.error('Failed to load template:', error);
      toast({
        title: "Load Template Error",
        description: "Failed to load the selected template",
        variant: "destructive"
      });
      return null;
    }
  }, [toast]);

  // Bind memo data for live preview
  const bindMemoToTemplate = useCallback(async (memoId: string): Promise<any> => {
    try {
      return await dataBindingService.bindMemoData(memoId);
    } catch (error) {
      console.error('Failed to bind memo data:', error);
      return null;
    }
  }, [dataBindingService]);

  // Upload template file (DOCX, XLSX, PDF)
  const uploadTemplate = useCallback(async (
    file: File, 
    productType: string, 
    uploadedBy: string
  ): Promise<boolean> => {
    try {
      const uploadedFile = await FileUploadService.uploadFile(file, 'template', uploadedBy);

      if (!uploadedFile) {
        throw new Error('Failed to upload file');
      }

      const templateId = await EnhancedReportsService.saveTemplate({
        name: file.name.replace(/\.[^/.]+$/, ''),
        product_type: productType,
        layout_json: JSON.stringify([]),
        uploaded_by: uploadedBy,
        file_path: uploadedFile.storedPath,
        template_type: uploadedFile.fileType.includes('docx') ? 'docx' : 
                      uploadedFile.fileType.includes('xlsx') ? 'xlsx' : 'pdf',
        version: 1,
        is_active: true
      });

      if (!templateId) {
        throw new Error('Failed to save template record');
      }

      toast({
        title: "Template Uploaded",
        description: `Template "${file.name}" has been uploaded successfully`,
      });

      return true;
    } catch (error) {
      console.error('Failed to upload template:', error);
      toast({
        title: "Upload Error",
        description: "Failed to upload template file",
        variant: "destructive"
      });
      return false;
    }
  }, [toast]);

  // Get templates by product type
  const getTemplatesByProduct = useCallback(async (productType: string): Promise<ReportTemplate[]> => {
    try {
      const templates = await EnhancedReportsService.getTemplatesByProductType(productType);
      
      return templates.map(template => ({
        id: template.id,
        name: template.name,
        productType: template.product_type,
        layoutJson: template.layout_json,
        blocks: JSON.parse(template.layout_json || '[]')
      }));
    } catch (error) {
      console.error('Failed to get templates:', error);
      return [];
    }
  }, []);

  // Get available analytics charts with enhanced metadata
  const getAnalyticsCharts = useCallback(async () => {
    try {
      const { EnhancedAnalyticsDataBinding } = await import('@/services/reporting/enhancedAnalyticsDataBinding');
      return await EnhancedAnalyticsDataBinding.getAvailableChartsWithMetadata();
    } catch (error) {
      console.error('Failed to get analytics charts:', error);
      toast({
        title: "Error",
        description: "Failed to load analytics charts",
        variant: "destructive"
      });
      return [];
    }
  }, [toast]);

  // Get chart data with enhanced binding support
  const getChartData = useCallback(async (chartId: string, memoId?: string) => {
    try {
      const { EnhancedAnalyticsDataBinding } = await import('@/services/reporting/enhancedAnalyticsDataBinding');
      
      // Create a basic binding for data retrieval
      const binding = EnhancedAnalyticsDataBinding.createChartBinding(chartId, 'temp', {
        dataSource: memoId ? 'memo' : 'live',
        memoId
      });
      
      const element = await EnhancedAnalyticsDataBinding.bindChartData(binding);
      return element.data;
    } catch (error) {
      console.error('Failed to get chart data:', error);
      toast({
        title: "Error",
        description: "Failed to load chart data",
        variant: "destructive"
      });
      return null;
    }
  }, [toast]);

  // Delete template
  const deleteTemplate = useCallback(async (templateId: string): Promise<boolean> => {
    try {
      const success = await EnhancedReportsService.deleteTemplate(templateId);
      
      if (success) {
        toast({
          title: "Template Deleted",
          description: "Template has been deleted successfully",
        });
      }
      
      return success;
    } catch (error) {
      console.error('Failed to delete template:', error);
      toast({
        title: "Delete Error",
        description: "Failed to delete template",
        variant: "destructive"
      });
      return false;
    }
  }, [toast]);

  return {
    generateFromCanvas,
    generateFromTemplate,
    generatePreview,
    saveTemplate,
    loadTemplate,
    bindMemoToTemplate,
    uploadTemplate,
    getTemplatesByProduct,
    getAnalyticsCharts,
    getChartData,
    deleteTemplate,
    isGenerating,
    isInitialized
  };
}