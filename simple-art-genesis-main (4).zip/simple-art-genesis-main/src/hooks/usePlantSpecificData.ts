import { useState, useEffect } from 'react';
import { plantSpecificService, PlantSpecificData, PlantConfiguration } from '@/services/database/plantSpecificService';

export interface PlantSpecificDataHook {
  machines: Array<{ id: string; name: string; category?: string; plant_id: string }>;
  officers: Array<{ id: string; name: string; department?: string; role?: string; plant_id: string }>;
  sampling_methods: Array<{ id: string; name: string; description?: string; plant_id: string }>;
  climatic_conditions: Array<{ id: string; name: string; description?: string; plant_id: string }>;
}

export function usePlantSpecificData(plantId: string | null) {
  const [data, setData] = useState<PlantSpecificDataHook>({
    machines: [],
    officers: [],
    sampling_methods: [],
    climatic_conditions: []
  });
  const [configuration, setConfiguration] = useState<PlantConfiguration | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    if (!plantId) {
      setData({
        machines: [],
        officers: [],
        sampling_methods: [],
        climatic_conditions: []
      });
      setConfiguration(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await plantSpecificService.initializePlantSpecificTables();
      
      const [plantData, config] = await Promise.all([
        plantSpecificService.getAllPlantSpecificData(plantId),
        plantSpecificService.getPlantConfiguration(plantId)
      ]);

      setData(plantData);
      setConfiguration(config);
    } catch (err) {
      console.error('Error loading plant-specific data:', err);
      setError('Failed to load plant-specific data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [plantId]);

  const addMachine = async (name: string, category?: string) => {
    if (!plantId) return;
    
    try {
      await plantSpecificService.addPlantMachine(plantId, name, category);
      await loadData(); // Reload data
    } catch (err) {
      console.error('Error adding machine:', err);
      throw err;
    }
  };

  const addOfficer = async (name: string, department?: string, role?: string) => {
    if (!plantId) return;
    
    try {
      await plantSpecificService.addPlantOfficer(plantId, name, department, role);
      await loadData(); // Reload data
    } catch (err) {
      console.error('Error adding officer:', err);
      throw err;
    }
  };

  const updateConfiguration = async (config: Partial<PlantConfiguration>) => {
    if (!plantId) return;
    
    try {
      await plantSpecificService.updatePlantConfiguration({
        ...config,
        plant_id: plantId
      });
      await loadData(); // Reload data
    } catch (err) {
      console.error('Error updating configuration:', err);
      throw err;
    }
  };

  const validateTestData = async (category: string, testType: string, testData: any) => {
    if (!plantId) return { isValid: true, errors: [] };
    
    return await plantSpecificService.validateTestData(plantId, category, testType, testData);
  };

  return {
    data,
    configuration,
    loading,
    error,
    addMachine,
    addOfficer,
    updateConfiguration,
    validateTestData,
    reload: loadData
  };
}

// Hook for getting machines filtered by plant and category
export function usePlantMachines(plantId: string | null, category?: string) {
  const [machines, setMachines] = useState<Array<{ id: string; name: string; category?: string }>>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadMachines = async () => {
      if (!plantId) {
        setMachines([]);
        return;
      }

      setLoading(true);
      try {
        await plantSpecificService.initializePlantSpecificTables();
        const plantMachines = await plantSpecificService.getPlantMachines(plantId, category);
        setMachines(plantMachines);
      } catch (error) {
        console.error('Error loading plant machines:', error);
        setMachines([]);
      } finally {
        setLoading(false);
      }
    };

    loadMachines();
  }, [plantId, category]);

  return { machines, loading };
}

// Hook for getting officers filtered by plant and department
export function usePlantOfficers(plantId: string | null, department?: string) {
  const [officers, setOfficers] = useState<Array<{ id: string; name: string; department?: string; role?: string }>>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadOfficers = async () => {
      if (!plantId) {
        setOfficers([]);
        return;
      }

      setLoading(true);
      try {
        await plantSpecificService.initializePlantSpecificTables();
        const plantOfficers = await plantSpecificService.getPlantOfficers(plantId, department);
        setOfficers(plantOfficers);
      } catch (error) {
        console.error('Error loading plant officers:', error);
        setOfficers([]);
      } finally {
        setLoading(false);
      }
    };

    loadOfficers();
  }, [plantId, department]);

  return { officers, loading };
}