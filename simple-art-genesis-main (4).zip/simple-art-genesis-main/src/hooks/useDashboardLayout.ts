import { useState, useEffect } from 'react';
import { dashboardService } from '@/services/database/dashboardService';
import type { DashboardLayout, DashboardWidget, DashboardState } from '@/types/dashboard';
import { useToast } from '@/hooks/use-toast';

export const useDashboardLayout = (userId: string, isAdmin: boolean = false) => {
  const [state, setState] = useState<DashboardState>({
    currentLayout: null,
    availableWidgets: [],
    isLocked: false,
    isAdmin,
    loading: true,
    error: null
  });

  const { toast } = useToast();

  useEffect(() => {
    initializeDashboard();
  }, [userId]);

  const initializeDashboard = async () => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      await dashboardService.initializeTables();
      let layout = await dashboardService.getCurrentLayout(userId);
      
      if (!layout) {
        // Create a default layout if none exists
        await dashboardService.ensureDefaultLayout(userId);
        layout = await dashboardService.getCurrentLayout(userId);
      }
      
      if (layout) {
        setState(prev => ({
          ...prev,
          currentLayout: layout,
          availableWidgets: layout.widgets,
          isLocked: layout.locked,
          loading: false
        }));
      } else {
        // If still no layout, create one manually
        const defaultLayout = {
          id: `default_${userId}_${Date.now()}`,
          user_id: userId,
          name: 'Default Layout',
          widgets: [],
          locked: false,
          is_default: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        
        await dashboardService.saveLayout(defaultLayout);
        setState(prev => ({
          ...prev,
          currentLayout: defaultLayout,
          availableWidgets: [],
          isLocked: false,
          loading: false
        }));
      }
    } catch (error) {
      console.error('Failed to initialize dashboard:', error);
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Failed to load dashboard',
        loading: false
      }));
    }
  };

  const removeWidget = async (widgetId: string) => {
    if (!state.currentLayout) return;
    
    if (state.isLocked && !state.isAdmin) {
      toast({
        title: "Action Blocked",
        description: "Dashboard layout is locked by admin",
        variant: "destructive"
      });
      return;
    }

    try {
      await dashboardService.removeWidget(userId, state.currentLayout.id, widgetId);
      
      const updatedLayout = {
        ...state.currentLayout,
        widgets: state.currentLayout.widgets.map(widget => 
          widget.id === widgetId 
            ? { ...widget, enabled: false }
            : widget
        ),
        updated_at: new Date().toISOString()
      };

      setState(prev => ({
        ...prev,
        currentLayout: updatedLayout,
        availableWidgets: updatedLayout.widgets
      }));

      toast({
        title: "Widget Removed",
        description: "Widget has been removed from your dashboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove widget",
        variant: "destructive"
      });
    }
  };

  const addWidget = async (widget: DashboardWidget) => {
    console.log('useDashboardLayout: Adding widget:', widget);
    if (!state.currentLayout) return;
    
    if (state.isLocked && !state.isAdmin) {
      toast({
        title: "Action Blocked",
        description: "Dashboard layout is locked by admin",
        variant: "destructive"
      });
      return;
    }

    try {
      await dashboardService.addWidget(userId, state.currentLayout.id, widget);
      
      const updatedLayout = {
        ...state.currentLayout,
        widgets: [...state.currentLayout.widgets.filter(w => w.id !== widget.id), widget],
        updated_at: new Date().toISOString()
      };

      setState(prev => ({
        ...prev,
        currentLayout: updatedLayout,
        availableWidgets: updatedLayout.widgets
      }));

      toast({
        title: "Widget Added",
        description: "Widget has been added to your dashboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add widget",
        variant: "destructive"
      });
    }
  };

  const updateWidgetPositions = async (widgets: DashboardWidget[]) => {
    if (!state.currentLayout) return;
    
    if (state.isLocked && !state.isAdmin) {
      return; // Silently ignore position updates for locked layouts
    }

    try {
      await dashboardService.updateWidgetPositions(userId, state.currentLayout.id, widgets);
      
      const updatedLayout = {
        ...state.currentLayout,
        widgets,
        updated_at: new Date().toISOString()
      };

      setState(prev => ({
        ...prev,
        currentLayout: updatedLayout,
        availableWidgets: widgets
      }));
    } catch (error) {
      console.error('Failed to update widget positions:', error);
    }
  };

  const toggleLockStatus = async () => {
    if (!state.currentLayout || !state.isAdmin) return;

    try {
      const newLockedStatus = !state.isLocked;
      await dashboardService.updateLayoutLockStatus(state.currentLayout.id, newLockedStatus);
      
      setState(prev => ({
        ...prev,
        isLocked: newLockedStatus,
        currentLayout: prev.currentLayout ? {
          ...prev.currentLayout,
          locked: newLockedStatus,
          updated_at: new Date().toISOString()
        } : null
      }));

      toast({
        title: newLockedStatus ? "Dashboard Locked" : "Dashboard Unlocked",
        description: newLockedStatus 
          ? "Layout is now locked and cannot be modified by users"
          : "Layout can now be modified by users"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update lock status",
        variant: "destructive"
      });
    }
  };

  const getEnabledWidgets = () => {
    return state.availableWidgets.filter(widget => widget.enabled);
  };

  const canEditLayout = () => {
    return !state.isLocked || state.isAdmin;
  };

  return {
    ...state,
    removeWidget,
    addWidget,
    updateWidgetPositions,
    toggleLockStatus,
    getEnabledWidgets,
    canEditLayout,
    refresh: initializeDashboard
  };
};