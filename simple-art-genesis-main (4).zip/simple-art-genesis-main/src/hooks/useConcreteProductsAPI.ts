import { useState, useEffect } from "react";
import { directInputService } from "@/services/database/DirectInputService";
import { useToast } from "@/hooks/use-toast";

interface TabletAppConnection {
  id: string;
  deviceName: string;
  lastSync: Date;
  isConnected: boolean;
}

interface ConcreteProductsAPIState {
  isConnected: boolean;
  lastSyncTime: Date | null;
  connectedDevices: TabletAppConnection[];
  pendingExternalData: any[];
}

export function useConcreteProductsAPI() {
  const { toast } = useToast();
  const [apiState, setApiState] = useState<ConcreteProductsAPIState>({
    isConnected: false,
    lastSyncTime: null,
    connectedDevices: [],
    pendingExternalData: []
  });

  // Simulate connection status for now (will be replaced with actual WebSocket/API)
  useEffect(() => {
    // Remove mock devices - connection status will be determined by actual tablet connectivity
    const checkConnections = () => {
      // For now, set as disconnected until real tablet integration
      setApiState(prev => ({
        ...prev,
        isConnected: false,
        lastSyncTime: null,
        connectedDevices: []
      }));
    };

    checkConnections(); // Initial check
  }, []);

  // Simulate receiving external data from tablet apps
  const receiveExternalData = async (data: any) => {
    try {
      // Transform data to match our interface
      const enrichedData = {
        product_type: data.product_type || 'blocks',
        memo_reference: data.memo_reference,
        operator: data.operator_name,
        test_date: data.test_date,
        status: 'pending' as const,
        test_data: {
          ...data,
          data_source: 'tablet_app',
          external_id: `tablet_${Date.now()}`,
          received_at: new Date().toISOString()
        }
      };

      const result = await directInputService.createDirectInputResult(enrichedData);
      
      toast({
        title: "External Data Received",
        description: `Test result from tablet app saved successfully`,
        variant: "default"
      });
      
      return { success: true, data: result };
    } catch (error) {
      console.error('Failed to process external data:', error);
      toast({
        title: "External Data Error", 
        description: "Failed to process tablet app data",
        variant: "destructive"
      });
      
      return { success: false, error: error.message };
    }
  };

  // Simulate batch data import from tablet
  const receiveBatchData = async (batchData: any[]) => {
    const results = [];
    
    for (const item of batchData) {
      const result = await receiveExternalData(item);
      results.push(result);
    }
    
    const successCount = results.filter(r => r.success).length;
    const failureCount = results.length - successCount;
    
    toast({
      title: "Batch Import Complete",
      description: `${successCount} records imported, ${failureCount} failed`,
      variant: successCount === results.length ? "default" : "destructive"
    });
    
    return results;
  };

  // Get connection health status
  const getConnectionHealth = () => {
    const connectedCount = apiState.connectedDevices.filter(d => d.isConnected).length;
    const totalDevices = apiState.connectedDevices.length;
    
    return {
      healthy: connectedCount > 0,
      connectedDevices: connectedCount,
      totalDevices,
      status: connectedCount === 0 ? 'offline' : 
              connectedCount === totalDevices ? 'excellent' : 'partial'
    };
  };

  // Test connection to a specific tablet
  const testTabletConnection = async (tabletId: string) => {
    // Simulate testing connection
    return new Promise<boolean>((resolve) => {
      setTimeout(() => {
        const success = Math.random() > 0.2;
        resolve(success);
      }, 1000);
    });
  };

  return {
    apiState,
    receiveExternalData,
    receiveBatchData,
    getConnectionHealth,
    testTabletConnection,
    isConnected: apiState.isConnected,
    lastSyncTime: apiState.lastSyncTime,
    connectedDevices: apiState.connectedDevices
  };
}