import { useState, useCallback, useMemo } from 'react';
import { DashboardWidget } from '@/types/dashboard';

export interface FilterCriteria {
  dateRange?: {
    start: string;
    end: string;
  };
  status?: string[];
  priority?: string[];
  testType?: string[];
  plant?: string[];
  searchTerm?: string;
  customFilters?: Record<string, any>;
}

export interface DrillDownPath {
  level: number;
  title: string;
  filters: FilterCriteria;
  timestamp: string;
}

export interface AdvancedFilterState {
  activeFilters: FilterCriteria;
  drillDownPath: DrillDownPath[];
  filteredData: Record<string, any>;
  isFiltering: boolean;
}

export function useAdvancedFiltering() {
  const [filterState, setFilterState] = useState<AdvancedFilterState>({
    activeFilters: {},
    drillDownPath: [],
    filteredData: {},
    isFiltering: false
  });

  const applyFilter = useCallback((criteria: Partial<FilterCriteria>) => {
    setFilterState(prev => ({
      ...prev,
      activeFilters: {
        ...prev.activeFilters,
        ...criteria
      },
      isFiltering: Object.keys(criteria).length > 0
    }));
  }, []);

  const clearFilter = useCallback((filterKey?: keyof FilterCriteria) => {
    setFilterState(prev => {
      if (!filterKey) {
        // Clear all filters
        return {
          ...prev,
          activeFilters: {},
          drillDownPath: [],
          isFiltering: false
        };
      }
      
      // Clear specific filter
      const { [filterKey]: _, ...remainingFilters } = prev.activeFilters;
      return {
        ...prev,
        activeFilters: remainingFilters,
        isFiltering: Object.keys(remainingFilters).length > 0
      };
    });
  }, []);

  const drillDown = useCallback((title: string, filters: FilterCriteria) => {
    setFilterState(prev => ({
      ...prev,
      drillDownPath: [
        ...prev.drillDownPath,
        {
          level: prev.drillDownPath.length,
          title,
          filters,
          timestamp: new Date().toISOString()
        }
      ],
      activeFilters: {
        ...prev.activeFilters,
        ...filters
      },
      isFiltering: true
    }));
  }, []);

  const drillUp = useCallback((toLevel?: number) => {
    setFilterState(prev => {
      const targetLevel = toLevel ?? Math.max(0, prev.drillDownPath.length - 1);
      const newPath = prev.drillDownPath.slice(0, targetLevel);
      
      // Reconstruct filters from remaining path
      const combinedFilters = newPath.reduce((acc, pathItem) => ({
        ...acc,
        ...pathItem.filters
      }), {} as FilterCriteria);

      return {
        ...prev,
        drillDownPath: newPath,
        activeFilters: combinedFilters,
        isFiltering: Object.keys(combinedFilters).length > 0
      };
    });
  }, []);

  const filterWidgetData = useCallback((widgetId: string, rawData: any[]) => {
    const { activeFilters } = filterState;
    
    if (!rawData || rawData.length === 0) return rawData;

    let filteredData = [...rawData];

    // Apply date range filter
    if (activeFilters.dateRange) {
      const { start, end } = activeFilters.dateRange;
      filteredData = filteredData.filter(item => {
        const itemDate = item.date || item.created_at || item.timestamp;
        if (!itemDate) return true;
        return itemDate >= start && itemDate <= end;
      });
    }

    // Apply status filter
    if (activeFilters.status && activeFilters.status.length > 0) {
      filteredData = filteredData.filter(item => 
        activeFilters.status!.includes(item.status)
      );
    }

    // Apply priority filter
    if (activeFilters.priority && activeFilters.priority.length > 0) {
      filteredData = filteredData.filter(item => 
        activeFilters.priority!.includes(item.priority)
      );
    }

    // Apply test type filter
    if (activeFilters.testType && activeFilters.testType.length > 0) {
      filteredData = filteredData.filter(item => 
        activeFilters.testType!.includes(item.test_type || item.type)
      );
    }

    // Apply plant filter
    if (activeFilters.plant && activeFilters.plant.length > 0) {
      filteredData = filteredData.filter(item => 
        activeFilters.plant!.includes(item.plant || item.lab_site)
      );
    }

    // Apply search term filter
    if (activeFilters.searchTerm) {
      const searchTerm = activeFilters.searchTerm.toLowerCase();
      filteredData = filteredData.filter(item => {
        const searchableFields = [
          item.title, item.name, item.memo_ref, item.description,
          item.test_type, item.product, item.comments
        ];
        
        return searchableFields.some(field => 
          field && field.toString().toLowerCase().includes(searchTerm)
        );
      });
    }

    // Apply custom filters
    if (activeFilters.customFilters) {
      Object.entries(activeFilters.customFilters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          filteredData = filteredData.filter(item => {
            if (Array.isArray(value)) {
              return value.includes(item[key]);
            }
            return item[key] === value;
          });
        }
      });
    }

    return filteredData;
  }, [filterState]);

  const getFilterSummary = useMemo(() => {
    const { activeFilters } = filterState;
    const summary: string[] = [];

    if (activeFilters.dateRange) {
      summary.push(`Date: ${activeFilters.dateRange.start} to ${activeFilters.dateRange.end}`);
    }

    if (activeFilters.status && activeFilters.status.length > 0) {
      summary.push(`Status: ${activeFilters.status.join(', ')}`);
    }

    if (activeFilters.priority && activeFilters.priority.length > 0) {
      summary.push(`Priority: ${activeFilters.priority.join(', ')}`);
    }

    if (activeFilters.testType && activeFilters.testType.length > 0) {
      summary.push(`Test Type: ${activeFilters.testType.join(', ')}`);
    }

    if (activeFilters.plant && activeFilters.plant.length > 0) {
      summary.push(`Plant: ${activeFilters.plant.join(', ')}`);
    }

    if (activeFilters.searchTerm) {
      summary.push(`Search: "${activeFilters.searchTerm}"`);
    }

    return summary;
  }, [filterState.activeFilters]);

  const hasActiveFilters = useMemo(() => 
    Object.keys(filterState.activeFilters).length > 0
  , [filterState.activeFilters]);

  const getBreadcrumbs = useMemo(() => {
    return [
      { title: 'Dashboard', level: -1 },
      ...filterState.drillDownPath
    ];
  }, [filterState.drillDownPath]);

  return {
    filterState,
    applyFilter,
    clearFilter,
    drillDown,
    drillUp,
    filterWidgetData,
    getFilterSummary,
    hasActiveFilters,
    getBreadcrumbs
  };
}