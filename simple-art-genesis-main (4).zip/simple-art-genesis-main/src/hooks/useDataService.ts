// Custom React hooks for using the data service
// This provides a clean interface between React components and the data layer

import { useState, useEffect } from 'react';
import { dataService } from '@/services/api';
import type {
  Memo,
  TestRequest,
  UserProfile,
  AnalyticsData,
  PaginatedResponse,
  QueryOptions
} from '@/services/api';

// Memo hooks
export function useMemos(options: QueryOptions = {}) {
  const [data, setData] = useState<PaginatedResponse<Memo>>({
    data: [],
    count: 0,
    page: 1,
    totalPages: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMemos = async () => {
    try {
      setLoading(true);
      const response = await dataService.getMemos(options);
      setData(response);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch memos');
    } finally {
      setLoading(false);
    }
  };

  const createMemo = async (memo: Omit<Memo, 'id' | 'created_at'>) => {
    try {
      const response = await dataService.createMemo(memo);
      if (!response.error) {
        await fetchMemos(); // Refresh list
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create memo');
      throw err;
    }
  };

  const updateMemo = async (id: string, memo: Partial<Memo>) => {
    try {
      const response = await dataService.updateMemo(id, memo);
      if (!response.error) {
        await fetchMemos(); // Refresh list
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update memo');
      throw err;
    }
  };

  const deleteMemo = async (id: string) => {
    try {
      const response = await dataService.deleteMemo(id);
      if (!response.error) {
        await fetchMemos(); // Refresh list
        return true;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete memo');
      throw err;
    }
  };

  useEffect(() => {
    fetchMemos();
  }, [JSON.stringify(options)]);

  return {
    data,
    loading,
    error,
    refetch: fetchMemos,
    createMemo,
    updateMemo,
    deleteMemo
  };
}

// Test Request hooks
export function useTestRequests(options: QueryOptions = {}) {
  const [data, setData] = useState<PaginatedResponse<TestRequest>>({
    data: [],
    count: 0,
    page: 1,
    totalPages: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTestRequests = async () => {
    try {
      setLoading(true);
      const response = await dataService.getTestRequests(options);
      setData(response);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch test requests');
    } finally {
      setLoading(false);
    }
  };

  const createTestRequest = async (testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const response = await dataService.createTestRequest(testRequest);
      if (!response.error) {
        await fetchTestRequests(); // Refresh list
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create test request');
      throw err;
    }
  };

  const updateTestRequest = async (id: string, testRequest: Partial<TestRequest>) => {
    try {
      const response = await dataService.updateTestRequest(id, testRequest);
      if (!response.error) {
        await fetchTestRequests(); // Refresh list
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update test request');
      throw err;
    }
  };

  const deleteTestRequest = async (id: string) => {
    try {
      const response = await dataService.deleteTestRequest(id);
      if (!response.error) {
        await fetchTestRequests(); // Refresh list
        return true;
      }
      throw new Error(response.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete test request');
      throw err;
    }
  };

  useEffect(() => {
    fetchTestRequests();
  }, [JSON.stringify(options)]);

  return {
    data,
    loading,
    error,
    refetch: fetchTestRequests,
    createTestRequest,
    updateTestRequest,
    deleteTestRequest
  };
}

// User Profile hooks
export function useUserProfiles(options: QueryOptions = {}) {
  const [data, setData] = useState<PaginatedResponse<UserProfile>>({
    data: [],
    count: 0,
    page: 1,
    totalPages: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUserProfiles = async () => {
    try {
      setLoading(true);
      const response = await dataService.getUserProfiles(options);
      setData(response);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch user profiles');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserProfiles();
  }, [JSON.stringify(options)]);

  return {
    data,
    loading,
    error,
    refetch: fetchUserProfiles
  };
}

// Analytics hooks
export function useAnalytics() {
  const [data, setData] = useState<AnalyticsData>({
    totalTests: 0,
    completedTests: 0,
    pendingTests: 0,
    activeUsers: 0,
    completionRate: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const response = await dataService.getAnalyticsData();
      if (!response.error) {
        setData(response.data);
        setError(null);
      } else {
        throw new Error(response.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch analytics');
    } finally {
      setLoading(false);
    }
  };

  const getMonthlyData = async () => {
    try {
      const response = await dataService.getMonthlyTestData();
      if (!response.error) {
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      console.error('Failed to fetch monthly data:', err);
      return [];
    }
  };

  const getTestTypeDistribution = async () => {
    try {
      const response = await dataService.getTestTypeDistribution();
      if (!response.error) {
        return response.data;
      }
      throw new Error(response.error);
    } catch (err) {
      console.error('Failed to fetch test type distribution:', err);
      return [];
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  return {
    data,
    loading,
    error,
    refetch: fetchAnalytics,
    getMonthlyData,
    getTestTypeDistribution
  };
}

// Export the data service instance for direct access
export function useDataService() {
  return dataService;
}