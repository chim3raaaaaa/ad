import { useState, useEffect } from 'react';
import { useDataService } from './useDataService';

export interface DeveloperDataHook {
  // Custom Components
  components: any[];
  loadComponents: () => Promise<void>;
  createComponent: (component: any) => Promise<any>;
  updateComponent: (id: string, updates: any) => Promise<any>;
  deleteComponent: (id: string) => Promise<boolean>;

  // Workflows
  workflows: any[];
  loadWorkflows: () => Promise<void>;
  createWorkflow: (workflow: any) => Promise<any>;
  updateWorkflow: (id: string, updates: any) => Promise<any>;
  deleteWorkflow: (id: string) => Promise<boolean>;
  executeWorkflow: (workflowId: string, inputData?: any) => Promise<any>;
  workflowExecutions: any[];
  loadWorkflowExecutions: (workflowId?: string) => Promise<void>;

  // API Endpoints
  apiEndpoints: any[];
  loadApiEndpoints: () => Promise<void>;
  createApiEndpoint: (endpoint: any) => Promise<any>;
  updateApiEndpoint: (id: string, updates: any) => Promise<any>;
  deleteApiEndpoint: (id: string) => Promise<boolean>;
  apiLogs: any[];
  loadApiLogs: (endpointId?: string) => Promise<void>;

  // Custom Forms (already implemented in existing service)
  customForms: any[];
  loadCustomForms: () => Promise<void>;
  createCustomForm: (form: any) => Promise<any>;
  updateCustomForm: (id: string, updates: any) => Promise<any>;
  deleteCustomForm: (id: string) => Promise<boolean>;

  // Custom Tables (already implemented in existing service)
  customTables: any[];
  loadCustomTables: () => Promise<void>;
  createCustomTable: (table: any) => Promise<any>;
  updateCustomTable: (id: string, updates: any) => Promise<any>;
  deleteCustomTable: (id: string) => Promise<boolean>;

  // Data Links (already implemented in existing service)
  dataLinks: any[];
  loadDataLinks: () => Promise<void>;
  createDataLink: (link: any) => Promise<any>;
  updateDataLink: (id: string, updates: any) => Promise<any>;
  deleteDataLink: (id: string) => Promise<boolean>;

  // Loading states
  isLoading: boolean;
  error: string | null;
}

export const useDeveloperData = (): DeveloperDataHook => {
  const dataService = useDataService();
  
  const [components, setComponents] = useState<any[]>([]);
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [workflowExecutions, setWorkflowExecutions] = useState<any[]>([]);
  const [apiEndpoints, setApiEndpoints] = useState<any[]>([]);
  const [apiLogs, setApiLogs] = useState<any[]>([]);
  const [customForms, setCustomForms] = useState<any[]>([]);
  const [customTables, setCustomTables] = useState<any[]>([]);
  const [dataLinks, setDataLinks] = useState<any[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Custom Components methods
  const loadComponents = async () => {
    setIsLoading(true);
    setError(null);
    try {
      if (dataService && 'getCustomComponents' in dataService) {
        const result = await (dataService as any).getCustomComponents();
        setComponents(result || []);
      }
    } catch (err) {
      setError('Failed to load components');
      console.error('Error loading components:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const createComponent = async (component: any) => {
    setError(null);
    try {
      if (dataService && 'createCustomComponent' in dataService) {
        const result = await (dataService as any).createCustomComponent({
          ...component,
          created_by: 'current_user' // TODO: Get from auth context
        });
        setComponents(prev => [result, ...prev]);
        return result;
      }
    } catch (err) {
      setError('Failed to create component');
      console.error('Error creating component:', err);
      throw err;
    }
  };

  const updateComponent = async (id: string, updates: any) => {
    setError(null);
    try {
      if (dataService && 'updateCustomComponent' in dataService) {
        const result = await (dataService as any).updateCustomComponent(id, updates);
        setComponents(prev => prev.map(c => c.id === id ? result : c));
        return result;
      }
    } catch (err) {
      setError('Failed to update component');
      console.error('Error updating component:', err);
      throw err;
    }
  };

  const deleteComponent = async (id: string) => {
    setError(null);
    try {
      if (dataService && 'deleteCustomComponent' in dataService) {
        const success = await (dataService as any).deleteCustomComponent(id);
        if (success) {
          setComponents(prev => prev.filter(c => c.id !== id));
        }
        return success;
      }
      return false;
    } catch (err) {
      setError('Failed to delete component');
      console.error('Error deleting component:', err);
      throw err;
    }
  };

  // Workflows methods
  const loadWorkflows = async () => {
    setIsLoading(true);
    setError(null);
    try {
      if (dataService && 'getWorkflows' in dataService) {
        const result = await (dataService as any).getWorkflows();
        setWorkflows(result || []);
      }
    } catch (err) {
      setError('Failed to load workflows');
      console.error('Error loading workflows:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const createWorkflow = async (workflow: any) => {
    setError(null);
    try {
      if (dataService && 'createWorkflow' in dataService) {
        const result = await (dataService as any).createWorkflow({
          ...workflow,
          created_by: 'current_user' // TODO: Get from auth context
        });
        setWorkflows(prev => [result, ...prev]);
        return result;
      }
    } catch (err) {
      setError('Failed to create workflow');
      console.error('Error creating workflow:', err);
      throw err;
    }
  };

  const updateWorkflow = async (id: string, updates: any) => {
    setError(null);
    try {
      if (dataService && 'updateWorkflow' in dataService) {
        const result = await (dataService as any).updateWorkflow(id, updates);
        setWorkflows(prev => prev.map(w => w.id === id ? result : w));
        return result;
      }
    } catch (err) {
      setError('Failed to update workflow');
      console.error('Error updating workflow:', err);
      throw err;
    }
  };

  const deleteWorkflow = async (id: string) => {
    setError(null);
    try {
      if (dataService && 'deleteWorkflow' in dataService) {
        const success = await (dataService as any).deleteWorkflow(id);
        if (success) {
          setWorkflows(prev => prev.filter(w => w.id !== id));
        }
        return success;
      }
      return false;
    } catch (err) {
      setError('Failed to delete workflow');
      console.error('Error deleting workflow:', err);
      throw err;
    }
  };

  const executeWorkflow = async (workflowId: string, inputData: any = {}) => {
    setError(null);
    try {
      if (dataService && 'executeWorkflow' in dataService) {
        const result = await (dataService as any).executeWorkflow(workflowId, inputData);
        await loadWorkflowExecutions(); // Refresh executions list
        return result;
      }
    } catch (err) {
      setError('Failed to execute workflow');
      console.error('Error executing workflow:', err);
      throw err;
    }
  };

  const loadWorkflowExecutions = async (workflowId?: string) => {
    setError(null);
    try {
      if (dataService && 'getWorkflowExecutions' in dataService) {
        const result = await (dataService as any).getWorkflowExecutions(workflowId);
        setWorkflowExecutions(result || []);
      }
    } catch (err) {
      setError('Failed to load workflow executions');
      console.error('Error loading workflow executions:', err);
    }
  };

  // API Endpoints methods
  const loadApiEndpoints = async () => {
    setIsLoading(true);
    setError(null);
    try {
      if (dataService && 'getApiEndpoints' in dataService) {
        const result = await (dataService as any).getApiEndpoints();
        setApiEndpoints(result || []);
      }
    } catch (err) {
      setError('Failed to load API endpoints');
      console.error('Error loading API endpoints:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const createApiEndpoint = async (endpoint: any) => {
    setError(null);
    try {
      if (dataService && 'createApiEndpoint' in dataService) {
        const result = await (dataService as any).createApiEndpoint({
          ...endpoint,
          created_by: 'current_user' // TODO: Get from auth context
        });
        setApiEndpoints(prev => [result, ...prev]);
        return result;
      }
    } catch (err) {
      setError('Failed to create API endpoint');
      console.error('Error creating API endpoint:', err);
      throw err;
    }
  };

  const updateApiEndpoint = async (id: string, updates: any) => {
    setError(null);
    try {
      if (dataService && 'updateApiEndpoint' in dataService) {
        const result = await (dataService as any).updateApiEndpoint(id, updates);
        setApiEndpoints(prev => prev.map(e => e.id === id ? result : e));
        return result;
      }
    } catch (err) {
      setError('Failed to update API endpoint');
      console.error('Error updating API endpoint:', err);
      throw err;
    }
  };

  const deleteApiEndpoint = async (id: string) => {
    setError(null);
    try {
      if (dataService && 'deleteApiEndpoint' in dataService) {
        const success = await (dataService as any).deleteApiEndpoint(id);
        if (success) {
          setApiEndpoints(prev => prev.filter(e => e.id !== id));
        }
        return success;
      }
      return false;
    } catch (err) {
      setError('Failed to delete API endpoint');
      console.error('Error deleting API endpoint:', err);
      throw err;
    }
  };

  const loadApiLogs = async (endpointId?: string) => {
    setError(null);
    try {
      if (dataService && 'getApiLogs' in dataService) {
        const result = await (dataService as any).getApiLogs(endpointId);
        setApiLogs(result || []);
      }
    } catch (err) {
      setError('Failed to load API logs');
      console.error('Error loading API logs:', err);
    }
  };

  // Existing methods for forms, tables, and data links would use existing methods
  const loadCustomForms = async () => {
    // Implementation would use existing custom forms methods
    console.log('Custom forms loading - to be implemented with existing service methods');
  };

  const createCustomForm = async (form: any) => {
    console.log('Custom form creation - to be implemented with existing service methods');
    return form;
  };

  const updateCustomForm = async (id: string, updates: any) => {
    console.log('Custom form update - to be implemented with existing service methods');
    return updates;
  };

  const deleteCustomForm = async (id: string) => {
    console.log('Custom form deletion - to be implemented with existing service methods');
    return true;
  };

  const loadCustomTables = async () => {
    console.log('Custom tables loading - to be implemented with existing service methods');
  };

  const createCustomTable = async (table: any) => {
    console.log('Custom table creation - to be implemented with existing service methods');
    return table;
  };

  const updateCustomTable = async (id: string, updates: any) => {
    console.log('Custom table update - to be implemented with existing service methods');
    return updates;
  };

  const deleteCustomTable = async (id: string) => {
    console.log('Custom table deletion - to be implemented with existing service methods');
    return true;
  };

  const loadDataLinks = async () => {
    console.log('Data links loading - to be implemented with existing service methods');
  };

  const createDataLink = async (link: any) => {
    console.log('Data link creation - to be implemented with existing service methods');
    return link;
  };

  const updateDataLink = async (id: string, updates: any) => {
    console.log('Data link update - to be implemented with existing service methods');
    return updates;
  };

  const deleteDataLink = async (id: string) => {
    console.log('Data link deletion - to be implemented with existing service methods');
    return true;
  };

  // Load initial data when the hook is first used
  useEffect(() => {
    loadComponents();
    loadWorkflows();
    loadApiEndpoints();
    loadCustomForms();
    loadCustomTables();
    loadDataLinks();
  }, [dataService]);

  return {
    // Components
    components,
    loadComponents,
    createComponent,
    updateComponent,
    deleteComponent,

    // Workflows
    workflows,
    loadWorkflows,
    createWorkflow,
    updateWorkflow,
    deleteWorkflow,
    executeWorkflow,
    workflowExecutions,
    loadWorkflowExecutions,

    // API Endpoints
    apiEndpoints,
    loadApiEndpoints,
    createApiEndpoint,
    updateApiEndpoint,
    deleteApiEndpoint,
    apiLogs,
    loadApiLogs,

    // Forms, Tables, Links (placeholder implementations)
    customForms,
    loadCustomForms,
    createCustomForm,
    updateCustomForm,
    deleteCustomForm,
    customTables,
    loadCustomTables,
    createCustomTable,
    updateCustomTable,
    deleteCustomTable,
    dataLinks,
    loadDataLinks,
    createDataLink,
    updateDataLink,
    deleteDataLink,

    // States
    isLoading,
    error
  };
};
