import { useState, useEffect, useCallback } from 'react';
import { referenceDataBrainService } from '@/lib/services/ReferenceDataBrainService';
import type {
  Plant,
  Officer,
  ProductCategory,
  Product,
  TestType,
  Machine,
  Material
} from '@/lib/services/ReferenceDataBrainService';

interface UseReferenceDataResult<T> {
  data: T[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook to fetch reference data with caching and real-time updates
 */
export function useReferenceData<T>(
  dataType: string,
  fetcher: () => Promise<T[]>
): UseReferenceDataResult<T> {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await fetcher();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
      console.error(`Error fetching ${dataType}:`, err);
    } finally {
      setLoading(false);
    }
  }, [fetcher, dataType]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    // Subscribe to real-time updates
    const unsubscribe = referenceDataBrainService.subscribeToUpdates(dataType, () => {
      fetchData();
    });

    return unsubscribe;
  }, [dataType, fetchData]);

  return {
    data,
    loading,
    error,
    refetch: fetchData
  };
}

// ============ SPECIFIC HOOKS FOR EACH DATA TYPE ============

export function useReferenceDataBrainPlants(): UseReferenceDataResult<Plant> {
  return useReferenceData('plants', () => referenceDataBrainService.getPlants());
}

export function useReferenceDataBrainOfficers(): UseReferenceDataResult<Officer> {
  return useReferenceData('officers', () => referenceDataBrainService.getOfficers());
}

export function useReferenceDataBrainProductCategories(): UseReferenceDataResult<ProductCategory> {
  return useReferenceData('productCategories', () => referenceDataBrainService.getProductCategories());
}

export function useReferenceDataBrainProducts(categoryId?: string): UseReferenceDataResult<Product> {
  const cacheKey = categoryId ? `products_${categoryId}` : 'products';
  return useReferenceData(cacheKey, () => referenceDataBrainService.getProducts(categoryId));
}

export function useReferenceDataBrainTestTypes(): UseReferenceDataResult<TestType> {
  return useReferenceData('testTypes', () => referenceDataBrainService.getTestTypes());
}

export function useReferenceDataBrainMachines(): UseReferenceDataResult<Machine> {
  return useReferenceData('machines', () => referenceDataBrainService.getMachines());
}

export function useReferenceDataBrainMaterials(): UseReferenceDataResult<Material> {
  return useReferenceData('materials', () => referenceDataBrainService.getMaterials());
}

// ============ UNIFIED DROPDOWN OPTIONS HOOK ============

interface DropdownOption {
  id: string;
  name: string;
  value: string;
  category?: string;
  metadata?: Record<string, any>;
}

interface AllDropdownOptions {
  plants: DropdownOption[];
  officers: DropdownOption[];
  productCategories: DropdownOption[];
  products: DropdownOption[];
  testTypes: DropdownOption[];
  machines: DropdownOption[];
  moistureConditions: DropdownOption[];
  samplingPlaces: DropdownOption[];
  climaticConditions: DropdownOption[];
  aggregateTypes: DropdownOption[];
  gradingLimits: DropdownOption[];
  standards: DropdownOption[];
  materialTypes: DropdownOption[];
  sieveSizes: DropdownOption[];
}

export function useAllDropdownOptions(): UseReferenceDataResult<AllDropdownOptions> {
  const [data, setData] = useState<AllDropdownOptions>({
    plants: [],
    officers: [],
    productCategories: [],
    products: [],
    testTypes: [],
    machines: [],
    moistureConditions: [],
    samplingPlaces: [],
    climaticConditions: [],
    aggregateTypes: [],
    gradingLimits: [],
    standards: [],
    materialTypes: [],
    sieveSizes: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await referenceDataBrainService.getAllDropdownOptions();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch dropdown options');
      console.error('Error fetching dropdown options:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    // Subscribe to any cache updates
    const unsubscribe = referenceDataBrainService.on('cache-invalidated', fetchData);
    const unsubscribeAll = referenceDataBrainService.on('cache-cleared', fetchData);

    return () => {
      referenceDataBrainService.off('cache-invalidated', fetchData);
      referenceDataBrainService.off('cache-cleared', fetchData);
    };
  }, [fetchData]);

  return {
    data: [data] as any, // Wrap in array to match interface
    loading,
    error,
    refetch: fetchData
  };
}

// ============ INITIALIZATION HOOK ============

export function useReferenceDataBrainInitialization() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const initialize = useCallback(async () => {
    if (isInitialized || isInitializing) return;

    try {
      setIsInitializing(true);
      setError(null);
      await referenceDataBrainService.initialize();
      setIsInitialized(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initialize reference data');
      console.error('Error initializing reference data brain:', err);
    } finally {
      setIsInitializing(false);
    }
  }, [isInitialized, isInitializing]);

  useEffect(() => {
    initialize();
  }, [initialize]);

  useEffect(() => {
    const handleInitialized = () => setIsInitialized(true);
    referenceDataBrainService.on('initialized', handleInitialized);

    return () => {
      referenceDataBrainService.off('initialized', handleInitialized);
    };
  }, []);

  return {
    isInitialized,
    isInitializing,
    error,
    initialize,
    service: referenceDataBrainService
  };
}