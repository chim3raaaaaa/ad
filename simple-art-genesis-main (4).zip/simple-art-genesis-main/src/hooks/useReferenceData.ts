import { useState, useEffect, useCallback } from 'react';
import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';
import { referenceDataService } from '@/services/database/referenceDataService';
import type {
  ProductCategory,
  Product,
  Grade,
  Machine,
  MouldReference,
  Plant,
  Officer,
  Aggregate,
  Admixture,
  FreeWater,
  CementType,
  VibratorStatus,
  ConformityOption,
  TestType
} from '@/services/database/enhancedReferenceDataService';
import type {
  AggregateType,
  MoistureCondition,
  SamplingPlace,
  ClimaticCondition,
  SampledBy,
  GradingLimit
} from '@/services/database/referenceDataService';

// ============= REFERENCE DATA HOOKS =============

export const useProductCategories = () => {
  const [data, setData] = useState<ProductCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const categories = await enhancedReferenceDataService.getProductCategories();
      setData(categories);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch product categories');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useProducts = (categoryId?: string) => {
  const [data, setData] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const products = categoryId 
        ? await enhancedReferenceDataService.getProductsByCategory(categoryId)
        : await enhancedReferenceDataService.getAllProducts();
      setData(products);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch products');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, [categoryId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useGrades = () => {
  const [data, setData] = useState<Grade[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const grades = await enhancedReferenceDataService.getGrades();
      setData(grades);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch grades');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useMachines = () => {
  const [data, setData] = useState<Machine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const machines = await enhancedReferenceDataService.getMachines();
      setData(machines);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch machines');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useMouldReferences = () => {
  const [data, setData] = useState<MouldReference[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const moulds = await enhancedReferenceDataService.getMouldReferences();
      setData(moulds);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch mould references');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const usePlants = () => {
  const [data, setData] = useState<Plant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const plants = await enhancedReferenceDataService.getPlants();
      setData(plants);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch plants');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useOfficers = () => {
  const [data, setData] = useState<Officer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const officers = await enhancedReferenceDataService.getOfficers();
      setData(officers);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch officers');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useAggregates = () => {
  const [data, setData] = useState<Aggregate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const aggregates = await enhancedReferenceDataService.getAggregates();
      setData(aggregates);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch aggregates');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useAdmixtures = () => {
  const [data, setData] = useState<Admixture[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const admixtures = await enhancedReferenceDataService.getAdmixtures();
      setData(admixtures);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch admixtures');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useFreeWaterTypes = () => {
  const [data, setData] = useState<FreeWater[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const waterTypes = await enhancedReferenceDataService.getFreeWaterTypes();
      setData(waterTypes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch free water types');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useCementTypes = () => {
  const [data, setData] = useState<CementType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const cementTypes = await enhancedReferenceDataService.getCementTypes();
      setData(cementTypes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch cement types');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useVibratorStatuses = () => {
  const [data, setData] = useState<VibratorStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const statuses = await enhancedReferenceDataService.getVibratorStatuses();
      setData(statuses);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch vibrator statuses');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useConformityOptions = () => {
  const [data, setData] = useState<ConformityOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const options = await enhancedReferenceDataService.getConformityOptions();
      setData(options);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch conformity options');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useTestTypes = () => {
  const [data, setData] = useState<TestType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const testTypes = await enhancedReferenceDataService.getTestTypes();
      setData(testTypes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch test types');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

// ============= VALIDATION HOOKS =============

export const useReferenceDataValidation = () => {
  const [isValidating, setIsValidating] = useState(false);

  const validateTestData = useCallback(async (testData: Record<string, any>) => {
    setIsValidating(true);
    try {
      const result = await enhancedReferenceDataService.validateTestData(testData);
      return result;
    } catch (error) {
      return {
        isValid: false,
        errors: [error instanceof Error ? error.message : 'Validation failed']
      };
    } finally {
      setIsValidating(false);
    }
  }, []);

  return { validateTestData, isValidating };
};

// ============= NEW AGGREGATE-SPECIFIC REFERENCE DATA HOOKS =============

export const useAggregateTypes = () => {
  const [data, setData] = useState<AggregateType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const aggregateTypes = await referenceDataService.getAggregateTypes();
      setData(aggregateTypes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch aggregate types');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useMoistureConditions = () => {
  const [data, setData] = useState<MoistureCondition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const conditions = await referenceDataService.getMoistureConditions();
      setData(conditions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch moisture conditions');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useSamplingPlaces = () => {
  const [data, setData] = useState<SamplingPlace[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const places = await referenceDataService.getSamplingPlaces();
      setData(places);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch sampling places');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useClimaticConditions = () => {
  const [data, setData] = useState<ClimaticCondition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const conditions = await referenceDataService.getClimaticConditions();
      setData(conditions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch climatic conditions');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useSampledBy = () => {
  const [data, setData] = useState<SampledBy[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const sampledBy = await referenceDataService.getSampledBy();
      setData(sampledBy);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch sampled by options');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

export const useGradingLimits = (category?: string) => {
  const [data, setData] = useState<GradingLimit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const limits = await referenceDataService.getGradingLimits(category);
      setData(limits);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch grading limits');
      setData([]);
    } finally {
      setLoading(false);
    }
  }, [category]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};

// Hook for initializing all reference data
export const useReferenceDataInitialization = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const initialize = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      await referenceDataService.initializeTables();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initialize reference data');
    } finally {
      setLoading(false);
    }
  }, []);

  return { initialize, loading, error };
};

// Unified dropdown options hook
export const useAllDropdownOptions = () => {
  const [data, setData] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const options = await referenceDataService.getAllDropdownOptions();
      setData(options);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch dropdown options');
      setData({});
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};