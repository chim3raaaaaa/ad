import { useState, useEffect, useMemo } from "react";
import { TestCalendarEvent } from "@/services/database/realTimeTestCalendarService";

interface CalendarWidgetService {
  data: TestCalendarEvent[] | null;
  loading: boolean;
  error: string | null;
}

export const useCalendarWidget = (): CalendarWidgetService => {
  const [data, setData] = useState<TestCalendarEvent[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Mock data removed - using empty arrays
  const mockData = useMemo(() => [], []);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setData(mockData);
      setLoading(false);
    }, 100);

    return () => clearTimeout(timer);
  }, [mockData]);

  return {
    data,
    loading,
    error
  };
};