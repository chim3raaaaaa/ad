import { createModule } from '@/services/modules/moduleRegistry';
import type { ModuleConfig, ModuleSchema, ModuleComponent, ModuleLogic } from '@/services/api/types';

// Module configuration
const config: ModuleConfig = {
  name: 'Reports Module',
  version: '1.0.0',
  description: 'Template-based report generation and management',
  author: 'Laboratory System',
  license: 'MIT',
  dependencies: ['core@1.0.0'],
  tags: ['reports', 'templates', 'pdf', 'certificates'],
  category: 'reports',
  permissions: ['reports.view', 'reports.create', 'reports.template.edit'],
  minAppVersion: '1.0.0'
};

// Database schema
const schema: ModuleSchema = {
  tables: [
    {
      name: 'report_templates',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'name', type: 'string', required: true },
        { name: 'description', type: 'text', required: false },
        { name: 'category', type: 'string', required: true },
        { name: 'template_type', type: 'string', required: true }, // 'test_report', 'certificate', 'summary'
        { name: 'template_html', type: 'text', required: true },
        { name: 'template_css', type: 'text', required: false },
        { name: 'data_schema', type: 'json', required: true },
        { name: 'variables', type: 'json', required: false },
        { name: 'header_footer', type: 'json', required: false },
        { name: 'page_settings', type: 'json', required: false },
        { name: 'active', type: 'boolean', required: true, default: true },
        { name: 'created_by', type: 'string', required: true },
        { name: 'created_at', type: 'timestamp', required: true },
        { name: 'updated_at', type: 'timestamp', required: true }
      ]
    },
    {
      name: 'generated_reports',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'template_id', type: 'uuid', required: true },
        { name: 'report_name', type: 'string', required: true },
        { name: 'data_source_id', type: 'string', required: true },
        { name: 'data_source_type', type: 'string', required: true }, // 'test_request', 'memo', 'cube_test'
        { name: 'report_data', type: 'json', required: true },
        { name: 'file_path', type: 'string', required: false },
        { name: 'file_size', type: 'number', required: false },
        { name: 'status', type: 'string', required: true, default: 'generating' },
        { name: 'generated_by', type: 'string', required: true },
        { name: 'generated_at', type: 'timestamp', required: true },
        { name: 'download_count', type: 'number', required: true, default: 0 }
      ],
      relationships: [
        {
          type: '1:N',
          table: 'report_templates',
          foreignKey: 'template_id'
        }
      ]
    },
    {
      name: 'report_signatures',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'report_id', type: 'uuid', required: true },
        { name: 'signatory_role', type: 'string', required: true },
        { name: 'signatory_name', type: 'string', required: true },
        { name: 'signature_image', type: 'string', required: false },
        { name: 'signed_at', type: 'timestamp', required: true },
        { name: 'signature_hash', type: 'string', required: true }
      ],
      relationships: [
        {
          type: '1:N',
          table: 'generated_reports',
          foreignKey: 'report_id'
        }
      ]
    }
  ]
};

// Components
const components: ModuleComponent[] = [
  {
    name: 'ReportTemplateEditor',
    type: 'form',
    path: '/modules/reports/components/ReportTemplateEditor',
    permissions: ['reports.template.edit'],
    props: {
      htmlEditor: true,
      cssEditor: true,
      variableInsertion: true,
      previewMode: true,
      dataSchema: true
    }
  },
  {
    name: 'ReportGenerator',
    type: 'modal',
    path: '/modules/reports/components/ReportGenerator',
    permissions: ['reports.create'],
    props: {
      templateSelection: true,
      dataSourcePicker: true,
      customization: true,
      batchGeneration: true
    }
  },
  {
    name: 'ReportLibrary',
    type: 'list',
    path: '/modules/reports/components/ReportLibrary',
    permissions: ['reports.view'],
    props: {
      filters: ['template', 'date_range', 'status', 'generated_by'],
      sorting: true,
      preview: true,
      bulk_operations: true
    }
  },
  {
    name: 'CertificateGenerator',
    type: 'form',
    path: '/modules/reports/components/CertificateGenerator',
    permissions: ['reports.create'],
    props: {
      digitalSignatures: true,
      qrCodeGeneration: true,
      watermarks: true,
      templateCustomization: true
    }
  },
  {
    name: 'ReportPreview',
    type: 'modal',
    path: '/modules/reports/components/ReportPreview',
    permissions: ['reports.view'],
    props: {
      pdfViewer: true,
      annotations: true,
      printing: true,
      sharing: true
    }
  }
];

// Business logic
const logic: ModuleLogic = {
  calculations: {
    report_file_size: 'LENGTH(generated_pdf_data)',
    generation_time: 'generated_at - created_at',
    template_usage_count: 'COUNT(generated_reports WHERE template_id = ?)',
    average_generation_time: 'AVG(generation_time) GROUP BY template_id'
  },
  validations: {
    template_html: 'value.length > 0 && value.includes("{{data}}")',
    data_schema: 'JSON.parse(value) && value.fields',
    report_name: 'value.length > 0 && value.length <= 255',
    page_settings: 'value.format && ["A4", "Letter", "A3"].includes(value.format)'
  },
  workflows: [
    {
      name: 'report_generation',
      steps: [
        {
          id: 'template_selection',
          type: 'manual',
          config: {
            title: 'Select Template',
            description: 'Choose a report template',
            template_categories: ['test_reports', 'certificates', 'summaries', 'custom']
          }
        },
        {
          id: 'data_collection',
          type: 'automated',
          config: {
            title: 'Collect Data',
            description: 'Gather required data from sources',
            data_validation: true,
            missing_data_handling: 'prompt'
          }
        },
        {
          id: 'template_processing',
          type: 'automated',
          config: {
            title: 'Process Template',
            description: 'Merge data with template',
            variable_substitution: true,
            conditional_rendering: true
          }
        },
        {
          id: 'pdf_generation',
          type: 'automated',
          config: {
            title: 'Generate PDF',
            description: 'Convert HTML to PDF',
            quality_settings: 'high',
            include_metadata: true
          }
        },
        {
          id: 'signature_workflow',
          type: 'manual',
          config: {
            title: 'Digital Signatures',
            description: 'Apply required signatures',
            signature_sequence: ['technician', 'supervisor', 'manager'],
            optional: true
          }
        },
        {
          id: 'finalization',
          type: 'automated',
          config: {
            title: 'Finalize Report',
            description: 'Apply final formatting and security',
            watermark: true,
            encryption: false,
            archive: true
          }
        }
      ]
    },
    {
      name: 'template_creation',
      steps: [
        {
          id: 'template_design',
          type: 'manual',
          config: {
            title: 'Design Template',
            description: 'Create HTML/CSS template',
            wysiwyg_editor: true,
            variable_helpers: true
          }
        },
        {
          id: 'data_mapping',
          type: 'manual',
          config: {
            title: 'Map Data Fields',
            description: 'Define data schema and variables',
            schema_builder: true,
            field_validation: true
          }
        },
        {
          id: 'template_testing',
          type: 'manual',
          config: {
            title: 'Test Template',
            description: 'Test with sample data',
            sample_data_generation: true,
            preview_modes: ['desktop', 'mobile', 'print']
          }
        },
        {
          id: 'approval',
          type: 'manual',
          config: {
            title: 'Template Approval',
            description: 'Review and approve template',
            approval_workflow: true,
            version_control: true
          }
        }
      ]
    }
  ]
};

// Export the module
export default createModule(config, schema, components, logic);