import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calculator, Save, AlertCircle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CubeTestFormProps {
  testId?: string;
  onSave?: (data: any) => void;
  onCancel?: () => void;
  readonly?: boolean;
}

interface CubeTestData {
  test_id: string;
  sample_id: string;
  cube_size: number;
  test_date: Date | undefined;
  age_days: number;
  load_kn: number;
  operator: string;
  remarks: string;
  standard_id: string;
  
  // Calculated fields
  strength_mpa?: number;
  density?: number;
  compliance_status?: 'PASS' | 'FAIL' | 'PENDING';
}

const cubeStandards = [
  { id: 'bs1881', name: 'BS 1881', cube_size: 150, min_strength: 20 },
  { id: 'astm_c39', name: 'ASTM C39', cube_size: 150, min_strength: 25 },
  { id: 'en12390', name: 'EN 12390', cube_size: 150, min_strength: 30 }
];

export default function CubeTestForm({ testId, onSave, onCancel, readonly = false }: CubeTestFormProps) {
  const [formData, setFormData] = useState<CubeTestData>({
    test_id: '',
    sample_id: '',
    cube_size: 150,
    test_date: undefined,
    age_days: 28,
    load_kn: 0,
    operator: '',
    remarks: '',
    standard_id: 'bs1881'
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (testId) {
      loadTestData(testId);
    } else {
      generateTestId();
    }
  }, [testId]);

  useEffect(() => {
    calculateDerivedValues();
  }, [formData.load_kn, formData.cube_size, formData.standard_id]);

  const loadTestData = async (id: string) => {
    try {
      // In a real implementation, load from dataService
      // const response = await dataService.getCubeTestById(id);
      // setFormData(response.data);
      console.log('Loading test data for:', id);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load test data',
        variant: 'destructive'
      });
    }
  };

  const generateTestId = () => {
    const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    setFormData(prev => ({ ...prev, test_id: `CT${timestamp}${random}` }));
  };

  const calculateDerivedValues = () => {
    if (formData.load_kn > 0 && formData.cube_size > 0) {
      // Calculate strength in MPa
      const area_mm2 = formData.cube_size * formData.cube_size;
      const strength_mpa = (formData.load_kn * 1000) / area_mm2;
      
      // Get standard requirements
      const standard = cubeStandards.find(s => s.id === formData.standard_id);
      const compliance_status = standard && strength_mpa >= standard.min_strength ? 'PASS' : 'FAIL';
      
      setFormData(prev => ({
        ...prev,
        strength_mpa: Math.round(strength_mpa * 100) / 100,
        compliance_status
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.test_id) newErrors.test_id = 'Test ID is required';
    if (!formData.sample_id) newErrors.sample_id = 'Sample ID is required';
    if (formData.cube_size <= 0 || formData.cube_size > 300) {
      newErrors.cube_size = 'Cube size must be between 1 and 300mm';
    }
    if (!formData.test_date) newErrors.test_date = 'Test date is required';
    if (formData.age_days <= 0 || formData.age_days > 365) {
      newErrors.age_days = 'Age must be between 1 and 365 days';
    }
    if (formData.load_kn <= 0 || formData.load_kn > 10000) {
      newErrors.load_kn = 'Load must be between 0 and 10000 kN';
    }
    if (!formData.operator) newErrors.operator = 'Operator is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast({
        title: 'Validation Error',
        description: 'Please correct the errors before saving',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      // In a real implementation, save to dataService
      // const response = await dataService.saveCubeTest(formData);
      
      toast({
        title: 'Success',
        description: 'Cube test saved successfully'
      });
      
      onSave?.(formData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save cube test',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof CubeTestData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when field is updated
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const selectedStandard = cubeStandards.find(s => s.id === formData.standard_id);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Cube Compression Test
            {formData.compliance_status && (
              <Badge variant={formData.compliance_status === 'PASS' ? 'default' : 'destructive'}>
                {formData.compliance_status === 'PASS' ? (
                  <CheckCircle className="w-3 h-3 mr-1" />
                ) : (
                  <AlertCircle className="w-3 h-3 mr-1" />
                )}
                {formData.compliance_status}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Test Identification */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="test_id">Test ID</Label>
              <Input
                id="test_id"
                value={formData.test_id}
                onChange={(e) => updateField('test_id', e.target.value)}
                disabled={readonly}
                className={errors.test_id ? 'border-destructive' : ''}
              />
              {errors.test_id && (
                <p className="text-xs text-destructive">{errors.test_id}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="sample_id">Sample ID</Label>
              <Input
                id="sample_id"
                value={formData.sample_id}
                onChange={(e) => updateField('sample_id', e.target.value)}
                disabled={readonly}
                className={errors.sample_id ? 'border-destructive' : ''}
              />
              {errors.sample_id && (
                <p className="text-xs text-destructive">{errors.sample_id}</p>
              )}
            </div>
          </div>

          {/* Test Parameters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cube_size">Cube Size (mm)</Label>
              <Input
                id="cube_size"
                type="number"
                value={formData.cube_size}
                onChange={(e) => updateField('cube_size', Number(e.target.value))}
                disabled={readonly}
                className={errors.cube_size ? 'border-destructive' : ''}
              />
              {errors.cube_size && (
                <p className="text-xs text-destructive">{errors.cube_size}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="age_days">Age (days)</Label>
              <Input
                id="age_days"
                type="number"
                value={formData.age_days}
                onChange={(e) => updateField('age_days', Number(e.target.value))}
                disabled={readonly}
                className={errors.age_days ? 'border-destructive' : ''}
              />
              {errors.age_days && (
                <p className="text-xs text-destructive">{errors.age_days}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="test_date">Test Date</Label>
              <Input
                id="test_date"
                type="date"
                value={formData.test_date ? formData.test_date.toISOString().split('T')[0] : ''}
                onChange={(e) => updateField('test_date', e.target.value ? new Date(e.target.value) : undefined)}
                disabled={readonly}
                className={errors.test_date ? 'border-destructive' : ''}
              />
              {errors.test_date && (
                <p className="text-xs text-destructive">{errors.test_date}</p>
              )}
            </div>
          </div>

          {/* Standard and Load */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="standard_id">Test Standard</Label>
              <Select 
                value={formData.standard_id} 
                onValueChange={(value) => updateField('standard_id', value)}
                disabled={readonly}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select standard" />
                </SelectTrigger>
                <SelectContent>
                  {cubeStandards.map((standard) => (
                    <SelectItem key={standard.id} value={standard.id}>
                      {standard.name} (Min: {standard.min_strength} MPa)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="load_kn">Maximum Load (kN)</Label>
              <Input
                id="load_kn"
                type="number"
                step="0.1"
                value={formData.load_kn}
                onChange={(e) => updateField('load_kn', Number(e.target.value))}
                disabled={readonly}
                className={errors.load_kn ? 'border-destructive' : ''}
              />
              {errors.load_kn && (
                <p className="text-xs text-destructive">{errors.load_kn}</p>
              )}
            </div>
          </div>

          {/* Calculated Results */}
          {formData.strength_mpa !== undefined && (
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2">Calculated Results</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <Label>Compressive Strength</Label>
                  <p className="font-mono text-lg">
                    {formData.strength_mpa.toFixed(2)} MPa
                  </p>
                </div>
                <div>
                  <Label>Required Minimum</Label>
                  <p className="font-mono text-lg">
                    {selectedStandard?.min_strength} MPa
                  </p>
                </div>
                <div>
                  <Label>Compliance</Label>
                  <Badge variant={formData.compliance_status === 'PASS' ? 'default' : 'destructive'}>
                    {formData.compliance_status}
                  </Badge>
                </div>
              </div>
            </div>
          )}

          {/* Operator and Remarks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="operator">Operator</Label>
              <Input
                id="operator"
                value={formData.operator}
                onChange={(e) => updateField('operator', e.target.value)}
                disabled={readonly}
                className={errors.operator ? 'border-destructive' : ''}
              />
              {errors.operator && (
                <p className="text-xs text-destructive">{errors.operator}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="remarks">Remarks</Label>
              <Textarea
                id="remarks"
                value={formData.remarks}
                onChange={(e) => updateField('remarks', e.target.value)}
                disabled={readonly}
                rows={3}
              />
            </div>
          </div>

          {/* Actions */}
          {!readonly && (
            <div className="flex justify-end gap-2">
              {onCancel && (
                <Button variant="outline" onClick={onCancel}>
                  Cancel
                </Button>
              )}
              <Button onClick={handleSave} disabled={loading}>
                <Save className="w-4 h-4 mr-2" />
                {loading ? 'Saving...' : 'Save Test'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}