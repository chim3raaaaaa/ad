import { createModule } from '@/services/modules/moduleRegistry';
import type { ModuleConfig, ModuleSchema, ModuleComponent, ModuleLogic } from '@/services/api/types';

// Module configuration
const config: ModuleConfig = {
  name: 'Cube Test Module',
  version: '1.0.0',
  description: 'Complete cube testing workflow for concrete strength testing',
  author: 'Laboratory System',
  license: 'MIT',
  dependencies: ['core@1.0.0'],
  tags: ['testing', 'concrete', 'strength', 'cube'],
  category: 'testing',
  permissions: ['cube_test.view', 'cube_test.create', 'cube_test.edit'],
  minAppVersion: '1.0.0'
};

// Database schema
const schema: ModuleSchema = {
  tables: [
    {
      name: 'cube_tests',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'test_id', type: 'string', required: true },
        { name: 'sample_id', type: 'string', required: true },
        { name: 'cube_size', type: 'number', required: true, default: 150 },
        { name: 'test_date', type: 'date', required: true },
        { name: 'age_days', type: 'number', required: true },
        { name: 'load_kn', type: 'number', required: false },
        { name: 'strength_mpa', type: 'number', required: false },
        { name: 'density', type: 'number', required: false },
        { name: 'operator', type: 'string', required: true },
        { name: 'remarks', type: 'text', required: false },
        { name: 'status', type: 'string', required: true, default: 'pending' },
        { name: 'created_at', type: 'timestamp', required: true },
        { name: 'updated_at', type: 'timestamp', required: true }
      ],
      relationships: [
        {
          type: '1:N',
          table: 'test_requests',
          foreignKey: 'test_request_id'
        }
      ]
    },
    {
      name: 'cube_test_standards',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'standard_name', type: 'string', required: true },
        { name: 'cube_size', type: 'number', required: true },
        { name: 'min_strength', type: 'number', required: false },
        { name: 'max_strength', type: 'number', required: false },
        { name: 'test_ages', type: 'json', required: true, default: '[7, 28]' },
        { name: 'calculation_formula', type: 'text', required: true },
        { name: 'active', type: 'boolean', required: true, default: true }
      ]
    }
  ],
  views: [
    {
      name: 'cube_test_summary',
      query: `
        SELECT 
          ct.*,
          tr.client_name,
          tr.sample_description,
          cts.standard_name
        FROM cube_tests ct
        LEFT JOIN test_requests tr ON ct.test_request_id = tr.id
        LEFT JOIN cube_test_standards cts ON ct.standard_id = cts.id
      `
    }
  ]
};

// Components
const components: ModuleComponent[] = [
  {
    name: 'CubeTestForm',
    type: 'form',
    path: '/modules/cube-test/components/CubeTestForm',
    permissions: ['cube_test.create', 'cube_test.edit'],
    props: {
      fields: ['test_id', 'sample_id', 'cube_size', 'test_date', 'age_days', 'operator'],
      validation: true,
      autoCalculate: true
    }
  },
  {
    name: 'CubeTestList',
    type: 'list',
    path: '/modules/cube-test/components/CubeTestList',
    permissions: ['cube_test.view'],
    props: {
      pagination: true,
      sorting: true,
      filtering: true,
      export: true
    }
  },
  {
    name: 'CubeTestDetail',
    type: 'detail',
    path: '/modules/cube-test/components/CubeTestDetail',
    permissions: ['cube_test.view'],
    props: {
      showHistory: true,
      allowEdit: true,
      showCalculations: true
    }
  },
  {
    name: 'CubeTestDashboard',
    type: 'dashboard',
    path: '/modules/cube-test/components/CubeTestDashboard',
    permissions: ['cube_test.view'],
    props: {
      widgets: ['summary', 'recent_tests', 'strength_chart', 'compliance_rate']
    }
  }
];

// Business logic
const logic: ModuleLogic = {
  calculations: {
    strength_mpa: 'load_kn * 1000 / (cube_size * cube_size)', // Convert kN to MPa
    density: 'mass_kg / (cube_size/1000)^3', // kg/m³
    compliance_rate: 'strength_mpa >= standard.min_strength ? "PASS" : "FAIL"'
  },
  validations: {
    cube_size: 'value > 0 && value <= 300',
    load_kn: 'value > 0 && value <= 10000',
    age_days: 'value > 0 && value <= 365',
    test_date: 'new Date(value) <= new Date()'
  },
  workflows: [
    {
      name: 'cube_test_workflow',
      steps: [
        {
          id: 'sample_preparation',
          type: 'manual',
          config: {
            title: 'Sample Preparation',
            description: 'Prepare cube samples according to standard',
            required_fields: ['sample_id', 'cube_size', 'preparation_date'],
            estimated_time: 30
          }
        },
        {
          id: 'curing',
          type: 'wait',
          config: {
            title: 'Curing Period',
            description: 'Allow samples to cure for specified period',
            duration_field: 'age_days',
            notifications: true
          }
        },
        {
          id: 'testing',
          type: 'manual',
          config: {
            title: 'Strength Testing',
            description: 'Perform compression test on cured samples',
            required_fields: ['load_kn', 'operator', 'test_date'],
            auto_calculations: ['strength_mpa', 'compliance_rate']
          }
        },
        {
          id: 'reporting',
          type: 'automated',
          config: {
            title: 'Report Generation',
            description: 'Generate test report and certificates',
            template: 'cube_test_report',
            auto_send: true
          }
        }
      ]
    }
  ]
};

// Export the module
export default createModule(config, schema, components, logic);