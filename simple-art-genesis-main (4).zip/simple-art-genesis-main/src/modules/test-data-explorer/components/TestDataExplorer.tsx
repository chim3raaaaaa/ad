import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, TrendingUp, Calendar, User, Building, Search as SearchIcon, FileSpreadsheet, FileText, Download, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { Search, Filter, BarChart3, Grid, Settings, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { useTestDataEntries, type TestDataEntry } from '@/hooks/useTestDataService';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Node,
  Edge,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, ScatterChart, Scatter } from 'recharts';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface TestDataExplorerProps {
  moduleId?: string;
  testType?: string;
}

// Chart data preparation
const prepareChartData = (entries: TestDataEntry[]) => {
  return entries.map(entry => ({
    date: format(new Date(entry.test_date), 'MMM dd'),
    testResult: entry.test_results?.value || 0,
    operator: entry.operator || 'Unknown',
    passFail: entry.pass_fail_status,
    batchId: entry.batch_id || 'N/A'
  })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

// Calculation engine for derived fields
const calculateDerivedFields = (entry: TestDataEntry) => {
  const results = entry.test_results || {};
  const calculated: Record<string, any> = {};

  // W/C Ratio calculation
  if (results.water && results.cement) {
    calculated.wcRatio = (results.water / results.cement).toFixed(2);
  }

  // Strength efficiency
  if (results.compressive_strength && results.cement_content) {
    calculated.strengthEfficiency = (results.compressive_strength / results.cement_content).toFixed(2);
  }

  // Aggregate ratio
  if (results.fine_aggregate && results.coarse_aggregate) {
    calculated.aggregateRatio = (results.fine_aggregate / results.coarse_aggregate).toFixed(2);
  }

  // Mean strength for multiple specimens
  if (results.specimens && Array.isArray(results.specimens)) {
    const mean = results.specimens.reduce((sum: number, spec: any) => sum + (spec.strength || 0), 0) / results.specimens.length;
    calculated.meanStrength = mean.toFixed(2);
  }

  return calculated;
};

// Pass/Fail determination based on thresholds
const determinePassFail = (entry: TestDataEntry, thresholds: any = {}) => {
  const value = entry.test_results?.value || entry.test_results?.compressive_strength || 0;
  const minThreshold = thresholds.min_value || 0;
  const maxThreshold = thresholds.max_value || Infinity;

  if (value < minThreshold || value > maxThreshold) {
    return 'fail';
  }
  return 'pass';
};

export default function TestDataExplorer({ moduleId, testType }: TestDataExplorerProps) {
  const [filters, setFilters] = useState({
    moduleId: moduleId || '',
    testType: testType || '',
    productType: '',
    site: '',
    operator: '',
    passFail: '',
    source: '',
    startDate: '',
    endDate: '',
    search: ''
  });

  const { data: entries, loading, error, refetch, exportData } = useTestDataEntries(filters);
  const [viewMode, setViewMode] = useState<'table' | 'chart' | 'flow'>('table');
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    'test_date', 'batch_id', 'test_type', 'operator', 'pass_fail_status'
  ]);
  const [showCalculated, setShowCalculated] = useState(false);
  const [selectedEntries, setSelectedEntries] = useState<string[]>([]);
  const [sortConfig, setSortConfig] = useState<{key: string, direction: 'asc' | 'desc'} | null>(null);
  const [groupBy, setGroupBy] = useState<string>('none');
  const [chartType, setChartType] = useState<'line' | 'bar' | 'scatter'>('line');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  // Flow chart state
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  const productTypes = ['Concrete', 'Blocks', 'Cubes', 'Mix Design', 'Aggregates', 'Pavers', 'Kerbs'];
  const sources = ['manual', 'imported', 'liveshare'];
  const passFailOptions = ['pass', 'fail', 'pending'];
  const availableColumns = [
    'test_date', 'batch_id', 'test_type', 'product_type', 'site', 
    'operator', 'pass_fail_status', 'source', 'memo_reference'
  ];

  useEffect(() => {
    if (error) {
      toast.error(error);
    }
  }, [error]);

  useEffect(() => {
    // Auto-apply filters when moduleId or testType changes and force refetch
    console.log('Filters applied:', filters);
    refetch();
  }, [moduleId, testType, refetch]);

  // Prepare enhanced entries with calculated fields
  const enhancedEntries = entries.map(entry => ({
    ...entry,
    calculatedFields: calculateDerivedFields(entry),
    computedPassFail: determinePassFail(entry)
  }));

  // Apply sorting
  const sortedEntries = sortConfig 
    ? [...enhancedEntries].sort((a, b) => {
        const aVal = a[sortConfig.key as keyof typeof a] || '';
        const bVal = b[sortConfig.key as keyof typeof b] || '';
        if (sortConfig.direction === 'asc') {
          return aVal > bVal ? 1 : -1;
        }
        return aVal < bVal ? 1 : -1;
      })
    : enhancedEntries;

  // Apply grouping
  const groupedEntries = groupBy && groupBy !== 'none'
    ? sortedEntries.reduce((groups, entry) => {
        const key = entry[groupBy as keyof typeof entry] as string || 'Other';
        if (!groups[key]) groups[key] = [];
        groups[key].push(entry);
        return groups;
      }, {} as Record<string, typeof sortedEntries>)
    : { 'All': sortedEntries };

  const handleFilterChange = (key: string, value: string) => {
    // Convert "all" and "none" to empty strings for filtering
    const filterValue = (value === 'all' || value === 'none') ? '' : value;
    setFilters(prev => ({ ...prev, [key]: filterValue }));
  };

  const clearFilters = () => {
    setFilters({
      moduleId: moduleId || '',
      testType: testType || '',
      productType: '',
      site: '',
      operator: '',
      passFail: '',
      source: '',
      startDate: '',
      endDate: '',
      search: ''
    });
    setGroupBy('none'); // Reset grouping to "none" instead of empty string
  };

  const handleExport = async (format: 'csv' | 'excel' | 'pdf') => {
    try {
      const blob = await exportData(format);
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `test-data-${format}-${new Date().toISOString().split('T')[0]}.${format}`;
        a.click();
        URL.revokeObjectURL(url);
        toast.success(`✅ Export successful - ${format.toUpperCase()} file downloaded`);
      }
    } catch (error) {
      toast.error(`❌ Export failed: ${error}`);
    }
  };

  const handleSort = (key: string) => {
    setSortConfig(current => {
      if (current?.key === key) {
        return current.direction === 'asc' 
          ? { key, direction: 'desc' }
          : null;
      }
      return { key, direction: 'asc' };
    });
  };

  const handleColumnToggle = (column: string) => {
    setSelectedColumns(prev => 
      prev.includes(column) 
        ? prev.filter(c => c !== column)
        : [...prev, column]
    );
  };

  const handleEntrySelection = (entryId: string) => {
    setSelectedEntries(prev => 
      prev.includes(entryId)
        ? prev.filter(id => id !== entryId)
        : [...prev, entryId]
    );
  };

  const handleSelectAll = () => {
    if (selectedEntries.length === enhancedEntries.length) {
      setSelectedEntries([]);
    } else {
      setSelectedEntries(enhancedEntries.map(e => e.id));
    }
  };

  const toggleGroup = (groupName: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupName)) {
        newSet.delete(groupName);
      } else {
        newSet.add(groupName);
      }
      return newSet;
    });
  };

  const renderTableCell = (entry: any, column: string) => {
    const value = entry[column];
    
    switch (column) {
      case 'test_date':
        return format(new Date(value), 'MMM dd, yyyy');
      case 'pass_fail_status':
        const status = entry.computedPassFail || value;
        return (
          <Badge 
            variant={status === 'pass' ? 'default' : status === 'fail' ? 'destructive' : 'secondary'}
            className={status === 'fail' ? 'bg-red-100 text-red-800 border-red-300' : ''}
          >
            {status === 'pass' && <CheckCircle className="w-3 h-3 mr-1" />}
            {status === 'fail' && <AlertTriangle className="w-3 h-3 mr-1" />}
            {status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
            {status}
          </Badge>
        );
      case 'source':
        return <Badge variant="outline">{value}</Badge>;
      case 'test_results':
        return (
          <div className="text-sm">
            {showCalculated && entry.calculatedFields ? (
              <div className="space-y-1">
                {Object.entries(entry.calculatedFields).map(([key, val]) => (
                  <div key={key} className="text-xs text-muted-foreground">
                    {key}: {String(val)}
                  </div>
                ))}
              </div>
            ) : (
              <div>
                {Object.entries(value || {}).slice(0, 2).map(([key, val]) => (
                  <div key={key} className="text-xs">
                    {key}: {String(val)}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      default:
        return value || '-';
    }
  };

  const chartData = prepareChartData(enhancedEntries);

  const renderChart = () => {
    switch (chartType) {
      case 'line':
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="testResult" stroke="#8884d8" strokeWidth={2} />
          </LineChart>
        );
      case 'bar':
        return (
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="testResult" fill="#8884d8" />
          </BarChart>
        );
      case 'scatter':
        return (
          <ScatterChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis dataKey="testResult" />
            <Tooltip />
            <Scatter dataKey="testResult" fill="#8884d8" />
          </ScatterChart>
        );
      default:
        return <div>Chart type not supported</div>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center space-y-2">
          <div className="animate-spin h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading test data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header with Breadcrumb */}
      <div className="space-y-4">
        <div className="text-sm text-muted-foreground font-medium">
          <span className="font-bold">Test Modules</span> 
          <span className="mx-2">›</span> 
          <span className="font-bold">Aggregates</span>
          <span className="mx-2">›</span> 
          <span className="font-bold">Silt & Clay content</span>
          <span className="mx-2">›</span> 
          <span className="font-bold">View Test Data</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <BarChart3 className="h-6 w-6" />
              Test Data: Silt & Clay content - % by mass passing 75µm sieve
            </h2>
            <p className="text-muted-foreground mt-1">
              Browse and analyze test data for this procedure • {enhancedEntries.length} entries found
              {selectedEntries.length > 0 && ` • ${selectedEntries.length} selected`}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => setViewMode('table')} 
                    className={viewMode === 'table' ? 'bg-muted' : ''}>
              <Grid className="h-4 w-4 mr-2" />
              Table
            </Button>
            <Button variant="outline" size="sm" onClick={() => setViewMode('chart')}
                    className={viewMode === 'chart' ? 'bg-muted' : ''}>
              <BarChart3 className="h-4 w-4 mr-2" />
              Charts
            </Button>
            <Button variant="outline" size="sm" onClick={() => setViewMode('flow')}
                    className={viewMode === 'flow' ? 'bg-muted' : ''}>
              <Settings className="h-4 w-4 mr-2" />
              Flow
            </Button>
          </div>
        </div>
      </div>

      <Separator />

      {/* Advanced Filter Panel */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Advanced Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Product Type</Label>
              <Select value={filters.productType || 'all'} onValueChange={(value) => handleFilterChange('productType', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  {productTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Test Site</Label>
              <Input 
                placeholder="Enter site..."
                value={filters.site}
                onChange={(e) => handleFilterChange('site', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Operator</Label>
              <Input 
                placeholder="Enter operator..."
                value={filters.operator}
                onChange={(e) => handleFilterChange('operator', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Pass/Fail Status</Label>
              <Select value={filters.passFail || 'all'} onValueChange={(value) => handleFilterChange('passFail', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  {passFailOptions.map(status => (
                    <SelectItem key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Source</Label>
              <Select value={filters.source || 'all'} onValueChange={(value) => handleFilterChange('source', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All sources</SelectItem>
                  {sources.map(source => (
                    <SelectItem key={source} value={source}>
                      {source.charAt(0).toUpperCase() + source.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Start Date</Label>
              <Input 
                type="date"
                value={filters.startDate}
                onChange={(e) => handleFilterChange('startDate', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>End Date</Label>
              <Input 
                type="date"
                value={filters.endDate}
                onChange={(e) => handleFilterChange('endDate', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Search</Label>
              <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search all fields..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-6 pt-4 border-t">
            <div className="flex items-center space-x-2">
              <Button variant="outline" onClick={clearFilters}>
                Clear All Filters
              </Button>
              <Button variant="outline" onClick={clearFilters}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => handleExport('csv')}>
                <BarChart3 className="h-4 w-4 mr-2" />
                📊 Export CSV
              </Button>
              <Button variant="outline" onClick={() => handleExport('excel')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                📤 Export Excel
              </Button>
              <Button variant="outline" onClick={() => handleExport('pdf')}>
                <FileText className="h-4 w-4 mr-2" />
                📄 Export PDF
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* View Controls */}
      <Card>
        <CardContent className="py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Switch 
                  id="show-calculated"
                  checked={showCalculated}
                  onCheckedChange={setShowCalculated}
                />
                <Label htmlFor="show-calculated">Show Calculated Fields</Label>
              </div>

              {viewMode === 'table' && (
                <>
                  <Separator orientation="vertical" className="h-6" />
                  <div className="flex items-center space-x-2">
                    <Label>Group by:</Label>
                    <Select value={groupBy} onValueChange={setGroupBy}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="No grouping" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No grouping</SelectItem>
                        <SelectItem value="product_type">Product Type</SelectItem>
                        <SelectItem value="site">Site</SelectItem>
                        <SelectItem value="operator">Operator</SelectItem>
                        <SelectItem value="pass_fail_status">Pass/Fail</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {viewMode === 'chart' && (
                <>
                  <Separator orientation="vertical" className="h-6" />
                  <div className="flex items-center space-x-2">
                    <Label>Chart Type:</Label>
                    <Select value={chartType} onValueChange={(value: 'line' | 'bar' | 'scatter') => setChartType(value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="line">Line Chart</SelectItem>
                        <SelectItem value="bar">Bar Chart</SelectItem>
                        <SelectItem value="scatter">Scatter Plot</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>

            {viewMode === 'table' && (
              <Collapsible>
                <CollapsibleTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4 mr-2" />
                    Customize Columns
                    <ChevronDown className="h-4 w-4 ml-2" />
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="absolute right-0 mt-2 p-4 bg-background border rounded-lg shadow-lg z-10">
                  <div className="grid grid-cols-2 gap-2 min-w-96">
                    {availableColumns.map(column => (
                      <div key={column} className="flex items-center space-x-2">
                        <Checkbox 
                          id={column}
                          checked={selectedColumns.includes(column)}
                          onCheckedChange={() => handleColumnToggle(column)}
                        />
                        <Label htmlFor={column} className="text-sm">
                          {column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </Label>
                      </div>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            )}
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Main Content Tabs */}
      <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as any)}>
        <TabsContent value="table">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Test Data Table</CardTitle>
                {selectedEntries.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      Compare Selected ({selectedEntries.length})
                    </Button>
                    <Button variant="outline" size="sm">
                      Bulk Actions
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {Object.entries(groupedEntries).map(([groupName, groupEntries]) => (
                <div key={groupName} className="mb-6">
                  {groupBy !== 'none' && (
                    <Collapsible
                      open={expandedGroups.has(groupName)}
                      onOpenChange={() => toggleGroup(groupName)}
                    >
                      <CollapsibleTrigger asChild>
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start p-4 h-auto mb-3 hover:bg-muted/50"
                        >
                          <div className="flex items-center gap-3">
                            {expandedGroups.has(groupName) ? 
                              <ChevronDown className="h-4 w-4" /> : 
                              <ChevronRight className="h-4 w-4" />
                            }
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold text-lg">{groupName}</h3>
                              <Badge variant="secondary">{groupEntries.length} entries</Badge>
                              <div className="ml-2 flex gap-1">
                                {groupEntries.some(e => e.computedPassFail === 'fail') && (
                                  <Badge variant="destructive" className="text-xs">
                                    {groupEntries.filter(e => e.computedPassFail === 'fail').length} Failed
                                  </Badge>
                                )}
                                <Badge variant="default" className="text-xs">
                                  {groupEntries.filter(e => e.computedPassFail === 'pass').length} Passed
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </Button>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="rounded-md border overflow-hidden">
                          <Table>
                            <TableHeader className="sticky top-0 bg-background z-10">
                              <TableRow>
                                <TableHead className="w-12 sticky left-0 bg-background z-20">
                                  <Checkbox 
                                    checked={selectedEntries.length === enhancedEntries.length}
                                    onCheckedChange={handleSelectAll}
                                  />
                                </TableHead>
                                {selectedColumns.map(column => (
                                  <TableHead 
                                    key={column}
                                    className="cursor-pointer hover:bg-muted/50"
                                    onClick={() => handleSort(column)}
                                  >
                                    <div className="flex items-center gap-1">
                                      {column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                      {sortConfig?.key === column && (
                                        <span className="text-xs">
                                          {sortConfig.direction === 'asc' ? '↑' : '↓'}
                                        </span>
                                      )}
                                    </div>
                                  </TableHead>
                                ))}
                                {showCalculated && <TableHead>Calculated Fields</TableHead>}
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {groupEntries.map((entry, index) => (
                                <TableRow 
                                  key={entry.id}
                                  className={`
                                    ${index % 2 === 0 ? 'bg-background' : 'bg-muted/20'}
                                    ${selectedEntries.includes(entry.id) ? 'bg-muted/50' : ''}
                                    ${entry.computedPassFail === 'fail' ? 'bg-red-50 dark:bg-red-950/20 font-semibold' : ''}
                                    hover:bg-muted/30 transition-colors
                                  `}
                                >
                                  <TableCell className="sticky left-0 bg-inherit z-10">
                                    <Checkbox 
                                      checked={selectedEntries.includes(entry.id)}
                                      onCheckedChange={() => handleEntrySelection(entry.id)}
                                    />
                                  </TableCell>
                                  {selectedColumns.map(column => (
                                    <TableCell key={column}>
                                      {renderTableCell(entry, column)}
                                    </TableCell>
                                  ))}
                                  {showCalculated && (
                                    <TableCell>
                                      <div className="p-2 bg-muted/30 rounded text-xs space-y-1">
                                        <div className="text-xs font-medium text-muted-foreground mb-1">Calculated Fields</div>
                                        {Object.entries(entry.calculatedFields || {}).map(([key, value]) => (
                                          <div key={key} className="flex justify-between">
                                            <span className="text-muted-foreground">{key}:</span>
                                            <span className="font-mono">{value}</span>
                                          </div>
                                        ))}
                                      </div>
                                    </TableCell>
                                  )}
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                  
                  {groupBy === 'none' && (
                    <div className="rounded-md border overflow-hidden">
                      <Table>
                        <TableHeader className="sticky top-0 bg-background z-10">
                          <TableRow>
                            <TableHead className="w-12 sticky left-0 bg-background z-20">
                              <Checkbox 
                                checked={selectedEntries.length === enhancedEntries.length}
                                onCheckedChange={handleSelectAll}
                              />
                            </TableHead>
                            {selectedColumns.map(column => (
                              <TableHead 
                                key={column}
                                className="cursor-pointer hover:bg-muted/50"
                                onClick={() => handleSort(column)}
                              >
                                <div className="flex items-center gap-1">
                                  {column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                  {sortConfig?.key === column && (
                                    <span className="text-xs">
                                      {sortConfig.direction === 'asc' ? '↑' : '↓'}
                                    </span>
                                  )}
                                </div>
                              </TableHead>
                            ))}
                            {showCalculated && <TableHead>Calculated Fields</TableHead>}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {groupEntries.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={selectedColumns.length + 2} className="text-center py-12">
                                <div className="flex flex-col items-center gap-4 text-muted-foreground">
                                  <div className="text-6xl">📭</div>
                                  <div className="space-y-2">
                                    <p className="text-lg font-medium">No test data available yet</p>
                                    <p className="text-sm">Try adjusting your filters or import some test data</p>
                                  </div>
                                  <Button variant="outline" onClick={clearFilters}>
                                    Clear Filters
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ) : (
                            groupEntries.map((entry, index) => (
                              <TableRow 
                                key={entry.id}
                                className={`
                                  ${index % 2 === 0 ? 'bg-background' : 'bg-muted/20'}
                                  ${selectedEntries.includes(entry.id) ? 'bg-muted/50' : ''}
                                  ${entry.computedPassFail === 'fail' ? 'bg-red-50 dark:bg-red-950/20 font-semibold' : ''}
                                  hover:bg-muted/30 transition-colors
                                `}
                              >
                                <TableCell className="sticky left-0 bg-inherit z-10">
                                  <Checkbox 
                                    checked={selectedEntries.includes(entry.id)}
                                    onCheckedChange={() => handleEntrySelection(entry.id)}
                                  />
                                </TableCell>
                                {selectedColumns.map(column => (
                                  <TableCell key={column}>
                                    {renderTableCell(entry, column)}
                                  </TableCell>
                                ))}
                                {showCalculated && (
                                  <TableCell>
                                    <div className="p-2 bg-muted/30 rounded text-xs space-y-1">
                                      <div className="text-xs font-medium text-muted-foreground mb-1">Calculated Fields</div>
                                      {Object.entries(entry.calculatedFields || {}).map(([key, value]) => (
                                        <div key={key} className="flex justify-between">
                                          <span className="text-muted-foreground">{key}:</span>
                                          <span className="font-mono">{value}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </TableCell>
                                )}
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chart">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Data Visualization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  {renderChart()}
                </ResponsiveContainer>
              </div>
              
              {chartData.length === 0 && (
                <div className="flex items-center justify-center h-96 text-muted-foreground">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No data available for visualization</p>
                    <p className="text-sm">Adjust your filters to see chart data</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flow">
          <Card>
            <CardHeader>
              <CardTitle>Data Flow Diagram</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 border rounded-lg">
                <ReactFlow
                  nodes={nodes}
                  edges={edges}
                  onNodesChange={onNodesChange}
                  onEdgesChange={onEdgesChange}
                  onConnect={(params) => setEdges((eds) => addEdge(params, eds))}
                  fitView
                >
                  <MiniMap />
                  <Controls />
                  <Background />
                </ReactFlow>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Flow diagram feature coming soon - visualize data relationships and processing flows
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}