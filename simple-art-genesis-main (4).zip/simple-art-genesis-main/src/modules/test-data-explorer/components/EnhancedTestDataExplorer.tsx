import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Database, BarChart3, Shield, Brain, Upload, Activity } from 'lucide-react';

// Import all the new components
import AdvancedFiltering from '@/components/test-data-explorer/AdvancedFiltering';
import ComparisonViewer from '@/components/test-data-explorer/ComparisonViewer';
import ConformityChecker from '@/components/test-data-explorer/ConformityChecker';
import DatasetLoader from '@/components/test-data-explorer/DatasetLoader';
import PerformanceAnalytics from '@/components/test-data-explorer/PerformanceAnalytics';
import PredictiveAssistant from '@/components/test-data-explorer/PredictiveAssistant';

// Import the original component for the main data view
import TestDataExplorer from './TestDataExplorer';

interface EnhancedTestDataExplorerProps {
  moduleId?: string;
  testType?: string;
}

export default function EnhancedTestDataExplorer({ moduleId, testType }: EnhancedTestDataExplorerProps) {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleDataImported = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="explorer" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="explorer" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Data Explorer
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="conformity" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Conformity
          </TabsTrigger>
          <TabsTrigger value="comparison" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Comparison
          </TabsTrigger>
          <TabsTrigger value="assistant" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            AI Assistant
          </TabsTrigger>
          <TabsTrigger value="import" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Import
          </TabsTrigger>
        </TabsList>

        <TabsContent value="explorer">
          <TestDataExplorer key={refreshKey} moduleId={moduleId} testType={testType} />
        </TabsContent>

        <TabsContent value="analytics">
          <PerformanceAnalytics entries={[]} />
        </TabsContent>

        <TabsContent value="conformity">
          <ConformityChecker entries={[]} selectedEntries={[]} />
        </TabsContent>

        <TabsContent value="comparison">
          <ComparisonViewer selectedEntries={[]} allEntries={[]} onClearSelection={() => {}} />
        </TabsContent>

        <TabsContent value="assistant">
          <PredictiveAssistant entries={[]} selectedEntries={[]} />
        </TabsContent>

        <TabsContent value="import">
          <Card>
            <CardHeader>
              <CardTitle>Import Test Data</CardTitle>
            </CardHeader>
            <CardContent>
              <DatasetLoader onDataImported={handleDataImported} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}