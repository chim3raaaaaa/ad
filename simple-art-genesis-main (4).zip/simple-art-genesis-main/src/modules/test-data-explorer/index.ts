export { default as TestDataExplorer } from './components/TestDataExplorer';

export const testDataExplorerModule = {
  config: {
    name: 'Test Data Explorer',
    version: '1.0.0',
    description: 'Browse, filter, compare, and analyze historical test data',
    author: 'Lab System',
    dependencies: [],
    tags: ['test', 'data', 'analysis'],
    category: 'testing' as const,
    permissions: ['data.read', 'data.export', 'data.import'],
    minAppVersion: '1.0.0'
  },
  schema: {
    tables: [
      {
        name: 'test_data_entries',
        columns: [
          { name: 'id', type: 'string', required: true },
          { name: 'module_id', type: 'string', required: true },
          { name: 'test_results', type: 'json', required: true }
        ]
      }
    ],
    entities: [],
    relationships: []
  },
  components: [{ 
    name: 'TestDataExplorer', 
    path: './components/TestDataExplorer.tsx',
    type: 'list' as const,
    permissions: ['data.read']
  }],
  logic: {},
  enabled: true
};