import { createModule } from '@/services/modules/moduleRegistry';
import type { ModuleConfig, ModuleSchema, ModuleComponent, ModuleLogic } from '@/services/api/types';

// Module configuration
const config: ModuleConfig = {
  name: 'Dashboard Module',
  version: '1.0.0',
  description: 'Customizable dashboard widgets and layouts',
  author: 'Laboratory System',
  license: 'MIT',
  dependencies: ['core@1.0.0'],
  tags: ['dashboard', 'widgets', 'analytics', 'visualization'],
  category: 'dashboard',
  permissions: ['dashboard.view', 'dashboard.customize'],
  minAppVersion: '1.0.0'
};

// Database schema
const schema: ModuleSchema = {
  tables: [
    {
      name: 'dashboard_layouts',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'user_id', type: 'uuid', required: true },
        { name: 'name', type: 'string', required: true },
        { name: 'layout_config', type: 'json', required: true },
        { name: 'is_default', type: 'boolean', required: true, default: false },
        { name: 'created_at', type: 'timestamp', required: true },
        { name: 'updated_at', type: 'timestamp', required: true }
      ]
    },
    {
      name: 'widget_instances',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'dashboard_id', type: 'uuid', required: true },
        { name: 'widget_type', type: 'string', required: true },
        { name: 'widget_config', type: 'json', required: true },
        { name: 'position', type: 'json', required: true },
        { name: 'size', type: 'json', required: true },
        { name: 'enabled', type: 'boolean', required: true, default: true },
        { name: 'created_at', type: 'timestamp', required: true }
      ],
      relationships: [
        {
          type: '1:N',
          table: 'dashboard_layouts',
          foreignKey: 'dashboard_id'
        }
      ]
    },
    {
      name: 'widget_templates',
      columns: [
        { name: 'id', type: 'uuid', required: true },
        { name: 'name', type: 'string', required: true },
        { name: 'description', type: 'text', required: false },
        { name: 'widget_type', type: 'string', required: true },
        { name: 'default_config', type: 'json', required: true },
        { name: 'category', type: 'string', required: true },
        { name: 'permissions', type: 'json', required: true },
        { name: 'active', type: 'boolean', required: true, default: true }
      ]
    }
  ]
};

// Components
const components: ModuleComponent[] = [
  {
    name: 'DashboardBuilder',
    type: 'dashboard',
    path: '/modules/dashboard/components/DashboardBuilder',
    permissions: ['dashboard.customize'],
    props: {
      dragAndDrop: true,
      gridLayout: true,
      widgetLibrary: true,
      previewMode: true
    }
  },
  {
    name: 'WidgetLibrary',
    type: 'modal',
    path: '/modules/dashboard/components/WidgetLibrary',
    permissions: ['dashboard.customize'],
    props: {
      categories: ['analytics', 'charts', 'tables', 'forms', 'external'],
      search: true,
      preview: true
    }
  },
  {
    name: 'TestSummaryWidget',
    type: 'widget',
    path: '/modules/dashboard/components/TestSummaryWidget',
    permissions: ['dashboard.view'],
    props: {
      dataSource: 'test_requests',
      refreshInterval: 300,
      chartType: 'summary'
    }
  },
  {
    name: 'PerformanceChartWidget',
    type: 'widget',
    path: '/modules/dashboard/components/PerformanceChartWidget',
    permissions: ['dashboard.view'],
    props: {
      chartTypes: ['line', 'bar', 'pie', 'scatter'],
      timeRanges: ['1d', '7d', '30d', '90d'],
      customizable: true
    }
  },
  {
    name: 'RecentActivityWidget',
    type: 'widget',
    path: '/modules/dashboard/components/RecentActivityWidget',
    permissions: ['dashboard.view'],
    props: {
      activityTypes: ['tests', 'memos', 'users', 'reports'],
      maxItems: 10,
      realTime: true
    }
  },
  {
    name: 'KPIWidget',
    type: 'widget',
    path: '/modules/dashboard/components/KPIWidget',
    permissions: ['dashboard.view'],
    props: {
      metrics: ['completion_rate', 'avg_turnaround', 'quality_score'],
      visualization: ['number', 'gauge', 'progress'],
      targets: true
    }
  }
];

// Business logic
const logic: ModuleLogic = {
  calculations: {
    completion_rate: '(completed_tests / total_tests) * 100',
    avg_turnaround_time: 'SUM(completion_time - created_time) / COUNT(*)',
    productivity_score: '(completed_tests * quality_weight) / total_time',
    efficiency_ratio: 'actual_time / estimated_time'
  },
  validations: {
    layout_config: 'JSON.parse(value) && value.cols && value.rows',
    widget_position: 'x >= 0 && y >= 0 && w > 0 && h > 0',
    refresh_interval: 'value >= 30 && value <= 3600'
  },
  workflows: [
    {
      name: 'dashboard_customization',
      steps: [
        {
          id: 'layout_selection',
          type: 'manual',
          config: {
            title: 'Select Layout',
            description: 'Choose a dashboard layout template',
            templates: ['default', 'analytics', 'operational', 'executive']
          }
        },
        {
          id: 'widget_selection',
          type: 'manual',
          config: {
            title: 'Add Widgets',
            description: 'Select and configure widgets',
            widget_library: true,
            drag_drop: true
          }
        },
        {
          id: 'data_configuration',
          type: 'manual',
          config: {
            title: 'Configure Data Sources',
            description: 'Set up data connections and filters',
            data_sources: ['test_requests', 'memos', 'users', 'analytics']
          }
        },
        {
          id: 'permissions_setup',
          type: 'automated',
          config: {
            title: 'Apply Permissions',
            description: 'Configure widget-level permissions',
            role_based: true
          }
        },
        {
          id: 'preview_test',
          type: 'manual',
          config: {
            title: 'Preview and Test',
            description: 'Test dashboard functionality',
            preview_mode: true,
            test_data: true
          }
        }
      ]
    }
  ]
};

// Export the module
export default createModule(config, schema, components, logic);