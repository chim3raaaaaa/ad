import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import { UserProvider } from "@/contexts/UserContext";
import { MemoProvider } from "@/contexts/MemoContext";
import { TestResultProvider } from "@/contexts/TestResultContext";
import { DeveloperProvider } from "@/contexts/DeveloperContext";
import { UsersProvider } from "@/contexts/UsersContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { FloatingDeveloperPanel } from "@/components/developer/FloatingDeveloperPanel";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import TestCalendar from "./pages/TestCalendar";
import Notifications from "./pages/Notifications";
import TestModules from "./pages/TestModules";
import TestDataExplorer from "./pages/TestDataExplorer";
import MemoManagement from "./pages/MemoManagement";

import AdvancedDataHub from "./pages/AdvancedDataHub";

import TestResultManager from "./pages/TestResultManager";
import Reports from "./pages/Reports";
import Users from "./pages/Users";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";
import Integrations from "./pages/Integrations";
import Developer from "./pages/Developer";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

import ReferenceDataManager from "./pages/ReferenceDataManager";
import MixDesignManagerPage from "./pages/MixDesignManagerPage";

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <UserProvider>
        <UsersProvider>
          <TestResultProvider>
            <DeveloperProvider>
              <MemoProvider>
            <TooltipProvider>
              <BrowserRouter>
                <Routes>
                  <Route path="/login" element={<Login />} />
                  <Route path="/" element={<ProtectedRoute><Index /></ProtectedRoute>} />
                  <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                  <Route path="/test-calendar" element={<ProtectedRoute><TestCalendar /></ProtectedRoute>} />
                  <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
                   <Route path="/test-modules" element={<ProtectedRoute><TestModules /></ProtectedRoute>} />
                   <Route path="/test-data-explorer" element={<ProtectedRoute><TestDataExplorer /></ProtectedRoute>} />
                   <Route path="/memos" element={<ProtectedRoute><MemoManagement /></ProtectedRoute>} />
                   
                   <Route path="/advanced-data" element={<ProtectedRoute><AdvancedDataHub /></ProtectedRoute>} />
                  
                  <Route path="/test-result-manager" element={<ProtectedRoute><TestResultManager /></ProtectedRoute>} />
                  <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
                  <Route path="/users" element={<ProtectedRoute><Users /></ProtectedRoute>} />
                  <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
                  <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
                  <Route path="/integrations" element={<ProtectedRoute><Integrations /></ProtectedRoute>} />
                  
                  <Route path="/reference-data-manager" element={<ProtectedRoute><ReferenceDataManager /></ProtectedRoute>} />
                  <Route path="/mix-design-manager" element={<ProtectedRoute><MixDesignManagerPage /></ProtectedRoute>} />
                  <Route path="/developer" element={<ProtectedRoute><Developer /></ProtectedRoute>} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
                <FloatingDeveloperPanel />
                <Toaster />
              </BrowserRouter>
            </TooltipProvider>
            </MemoProvider>
            </DeveloperProvider>
          </TestResultProvider>
        </UsersProvider>
      </UserProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;