import { TestCalendarEvent } from '@/types';

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface BatchOperationResult {
  success: number;
  failed: number;
  errors: string[];
}

export class BatchOperationsService {
  private static isElectron = typeof window !== 'undefined' && !!window.electronAPI;

  static async markMultipleDone(
    eventIds: string[], 
    onProgress?: (completed: number, total: number) => void
  ): Promise<BatchOperationResult> {
    const result: BatchOperationResult = {
      success: 0,
      failed: 0,
      errors: []
    };

    for (let i = 0; i < eventIds.length; i++) {
      try {
        if (this.isElectron) {
          const updateResult = await window.electronAPI.dbRun(
            `UPDATE test_schedule 
             SET status = 'completed', completed_at = ?, completed_by = ? 
             WHERE id = ?`,
            [new Date().toISOString(), 'current_user', eventIds[i]]
          );
          
          if (!updateResult.success) {
            throw new Error(updateResult.error || 'Database update failed');
          }
        }
        
        result.success++;
        onProgress?.(i + 1, eventIds.length);
      } catch (error) {
        result.failed++;
        result.errors.push(`Failed to mark event ${eventIds[i]}: ${error}`);
      }
    }

    return result;
  }

  static async bulkStatusUpdate(
    eventIds: string[], 
    status: string,
    onProgress?: (completed: number, total: number) => void
  ): Promise<BatchOperationResult> {
    const result: BatchOperationResult = {
      success: 0,
      failed: 0,
      errors: []
    };

    for (let i = 0; i < eventIds.length; i++) {
      try {
        if (this.isElectron) {
          const updateResult = await window.electronAPI.dbRun(
            `UPDATE test_schedule SET status = ? WHERE id = ?`,
            [status, eventIds[i]]
          );
          
          if (!updateResult.success) {
            throw new Error(updateResult.error || 'Database update failed');
          }
        }
        
        result.success++;
        onProgress?.(i + 1, eventIds.length);
      } catch (error) {
        result.failed++;
        result.errors.push(`Failed to update event ${eventIds[i]}: ${error}`);
      }
    }

    return result;
  }

  static async bulkDelete(
    eventIds: string[],
    onProgress?: (completed: number, total: number) => void
  ): Promise<BatchOperationResult> {
    const result: BatchOperationResult = {
      success: 0,
      failed: 0,
      errors: []
    };

    for (let i = 0; i < eventIds.length; i++) {
      try {
        if (this.isElectron) {
          const deleteResult = await window.electronAPI.dbRun(
            `DELETE FROM test_schedule WHERE id = ?`,
            [eventIds[i]]
          );
          
          if (!deleteResult.success) {
            throw new Error(deleteResult.error || 'Database deletion failed');
          }
        }
        
        result.success++;
        onProgress?.(i + 1, eventIds.length);
      } catch (error) {
        result.failed++;
        result.errors.push(`Failed to delete event ${eventIds[i]}: ${error}`);
      }
    }

    return result;
  }
}