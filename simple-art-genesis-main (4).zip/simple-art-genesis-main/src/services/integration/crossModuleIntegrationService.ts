import { DashboardWidget } from '@/types/dashboard';
import { enhancedNotificationService } from '@/services/notifications/enhancedNotificationService';

export interface ModuleIntegration {
  moduleId: string;
  name: string;
  version: string;
  dataEndpoints: string[];
  permissions: string[];
  lastSync: string;
  status: 'active' | 'inactive' | 'error';
}

export interface CrossModuleData {
  sourceModule: string;
  targetModule: string;
  dataType: string;
  lastUpdated: string;
  records: number;
}

export interface SyncResult {
  success: boolean;
  recordsUpdated: number;
  errors: string[];
  duration: number;
}

class CrossModuleIntegrationService {
  private integrations: Map<string, ModuleIntegration> = new Map();
  private syncInProgress = false;

  constructor() {
    this.initializeIntegrations();
  }

  private async initializeIntegrations() {
    // Register default module integrations
    const defaultIntegrations: ModuleIntegration[] = [
      {
        moduleId: 'reference-data',
        name: 'Reference Data Manager',
        version: '1.0.0',
        dataEndpoints: ['/api/plants', '/api/products', '/api/test-types'],
        permissions: ['read', 'write'],
        lastSync: new Date().toISOString(),
        status: 'active'
      },
      {
        moduleId: 'test-modules',
        name: 'Test Modules Hub',
        version: '1.0.0',
        dataEndpoints: ['/api/test-results', '/api/test-schedules'],
        permissions: ['read'],
        lastSync: new Date().toISOString(),
        status: 'active'
      },
      {
        moduleId: 'user-management',
        name: 'User Management',
        version: '1.0.0',
        dataEndpoints: ['/api/users', '/api/roles', '/api/permissions'],
        permissions: ['read'],
        lastSync: new Date().toISOString(),
        status: 'active'
      },
      {
        moduleId: 'test-calendar',
        name: 'Test Calendar',
        version: '1.0.0',
        dataEndpoints: ['/api/calendar-events', '/api/schedules'],
        permissions: ['read', 'write'],
        lastSync: new Date().toISOString(),
        status: 'active'
      }
    ];

    defaultIntegrations.forEach(integration => {
      this.integrations.set(integration.moduleId, integration);
    });
  }

  async syncAllModules(): Promise<Record<string, SyncResult>> {
    if (this.syncInProgress) {
      throw new Error('Sync already in progress');
    }

    this.syncInProgress = true;
    const results: Record<string, SyncResult> = {};

    try {
      const syncPromises = Array.from(this.integrations.values()).map(async integration => {
        const result = await this.syncModule(integration.moduleId);
        results[integration.moduleId] = result;
        return result;
      });

      await Promise.all(syncPromises);

      // Only notify on sync failures, not routine successes
      const hasErrors = Object.values(results).some(result => !result.success);
      if (hasErrors) {
        const failedModules = Object.entries(results)
          .filter(([_, result]) => !result.success)
          .map(([moduleId, _]) => moduleId);
        
        await enhancedNotificationService.createNotification({
          type: 'error',
          category: 'system',
          title: 'Module Sync Failed',
          message: `Failed to sync modules: ${failedModules.join(', ')}. Check system logs for details.`,
          priority: 'high'
        });
      }

    } finally {
      this.syncInProgress = false;
    }

    return results;
  }

  async syncModule(moduleId: string): Promise<SyncResult> {
    const startTime = Date.now();
    const integration = this.integrations.get(moduleId);
    
    if (!integration) {
      return {
        success: false,
        recordsUpdated: 0,
        errors: [`Module ${moduleId} not found`],
        duration: Date.now() - startTime
      };
    }

    try {
      let totalUpdated = 0;
      const errors: string[] = [];

      // Sync based on module type
      switch (moduleId) {
        case 'reference-data':
          totalUpdated += await this.syncReferenceData();
          break;
        case 'test-modules':
          totalUpdated += await this.syncTestModules();
          break;
        case 'user-management':
          totalUpdated += await this.syncUserData();
          break;
        case 'test-calendar':
          totalUpdated += await this.syncCalendarData();
          break;
        default:
          errors.push(`Unknown module type: ${moduleId}`);
      }

      // Update integration status
      integration.lastSync = new Date().toISOString();
      integration.status = errors.length > 0 ? 'error' : 'active';

      return {
        success: errors.length === 0,
        recordsUpdated: totalUpdated,
        errors,
        duration: Date.now() - startTime
      };
    } catch (error) {
      console.error(`Error syncing module ${moduleId}:`, error);
      integration.status = 'error';
      
      return {
        success: false,
        recordsUpdated: 0,
        errors: [error instanceof Error ? error.message : 'Unknown error'],
        duration: Date.now() - startTime
      };
    }
  }

  private async syncReferenceData(): Promise<number> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return 0;

    try {
      // Sync plants data
      const plantsResult = await window.electronAPI.dbQuery(`
        SELECT DISTINCT 
          json_extract(value, '$.plant') as plant_name,
          COUNT(*) as usage_count
        FROM memos, json_each(production_data)
        WHERE json_extract(value, '$.plant') IS NOT NULL
        GROUP BY json_extract(value, '$.plant')
      `);

      let updated = 0;
      if (plantsResult.success) {
        // Update reference data table with plant usage statistics
        for (const plant of plantsResult.data) {
          await window.electronAPI.dbQuery(`
            INSERT OR REPLACE INTO reference_data (category, value, metadata, updated_at)
            VALUES ('plants', ?, ?, ?)
          `, [
            plant.plant_name,
            JSON.stringify({ usage_count: plant.usage_count }),
            new Date().toISOString()
          ]);
          updated++;
        }
      }

      // Sync test types
      const testTypesResult = await window.electronAPI.dbQuery(`
        SELECT DISTINCT test_type, COUNT(*) as usage_count
        FROM test_requests
        GROUP BY test_type
      `);

      if (testTypesResult.success) {
        for (const testType of testTypesResult.data) {
          await window.electronAPI.dbQuery(`
            INSERT OR REPLACE INTO reference_data (category, value, metadata, updated_at)
            VALUES ('test_types', ?, ?, ?)
          `, [
            testType.test_type,
            JSON.stringify({ usage_count: testType.usage_count }),
            new Date().toISOString()
          ]);
          updated++;
        }
      }

      return updated;
    } catch (error) {
      console.error('Error syncing reference data:', error);
      return 0;
    }
  }

  private async syncTestModules(): Promise<number> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return 0;

    try {
      // Sync test completion status from various test modules
      const testModulesResult = await window.electronAPI.dbQuery(`
        SELECT 
          id as memo_id,
          status,
          updated_at
        FROM memos
        WHERE status IN ('completed', 'failed')
        AND updated_at > datetime('now', '-24 hours')
      `);

      let updated = 0;
      if (testModulesResult.success) {
        // Update dashboard cache with latest test results
        for (const test of testModulesResult.data) {
          await window.electronAPI.dbQuery(`
            INSERT OR REPLACE INTO dashboard_cache (key, value, expires_at)
            VALUES (?, ?, ?)
          `, [
            `test_result_${test.memo_id}`,
            JSON.stringify({
              status: test.status,
              completed_at: test.updated_at
            }),
            new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
          ]);
          updated++;
        }
      }

      return updated;
    } catch (error) {
      console.error('Error syncing test modules:', error);
      return 0;
    }
  }

  private async syncUserData(): Promise<number> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return 0;

    try {
      // Sync user activity data for dashboard analytics
      const userActivityResult = await window.electronAPI.dbQuery(`
        SELECT 
          user_id,
          COUNT(*) as activity_count,
          MAX(created_at) as last_activity
        FROM memos
        WHERE created_at > datetime('now', '-7 days')
        GROUP BY user_id
      `);

      let updated = 0;
      if (userActivityResult.success) {
        for (const user of userActivityResult.data) {
          await window.electronAPI.dbQuery(`
            INSERT OR REPLACE INTO dashboard_cache (key, value, expires_at)
            VALUES (?, ?, ?)
          `, [
            `user_activity_${user.user_id}`,
            JSON.stringify({
              activity_count: user.activity_count,
              last_activity: user.last_activity
            }),
            new Date(Date.now() + 60 * 60 * 1000).toISOString() // 1 hour
          ]);
          updated++;
        }
      }

      return updated;
    } catch (error) {
      console.error('Error syncing user data:', error);
      return 0;
    }
  }

  private async syncCalendarData(): Promise<number> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return 0;

    try {
      // Sync calendar events with dashboard scheduling
      const calendarResult = await window.electronAPI.dbQuery(`
        SELECT 
          id,
          scheduled_date,
          scheduled_time,
          test_type,
          status,
          priority
        FROM scheduled_tests
        WHERE scheduled_date >= date('now')
        ORDER BY scheduled_date, scheduled_time
      `);

      let updated = 0;
      if (calendarResult.success) {
        // Update dashboard with upcoming tests
        await window.electronAPI.dbQuery(`
          INSERT OR REPLACE INTO dashboard_cache (key, value, expires_at)
          VALUES (?, ?, ?)
        `, [
          'upcoming_tests',
          JSON.stringify(calendarResult.data),
          new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutes
        ]);
        updated = calendarResult.data.length;
      }

      return updated;
    } catch (error) {
      console.error('Error syncing calendar data:', error);
      return 0;
    }
  }

  async getIntegrationStatus(): Promise<ModuleIntegration[]> {
    return Array.from(this.integrations.values());
  }

  async updateWidgetWithCrossModuleData(widget: DashboardWidget): Promise<any> {
    const widgetConfig = widget.data?.config;
    if (!widgetConfig) return null;

    try {
      // Check if widget needs cross-module data
      const crossModuleQueries = this.buildCrossModuleQueries(widgetConfig);
      
      if (crossModuleQueries.length === 0) {
        return null; // No cross-module dependencies
      }

      const results: any[] = [];
      
      for (const query of crossModuleQueries) {
        const data = await this.executeCrossModuleQuery(query);
        if (data) {
          results.push(data);
        }
      }

      return this.mergeCrossModuleResults(results);
    } catch (error) {
      console.error('Error updating widget with cross-module data:', error);
      return null;
    }
  }

  private buildCrossModuleQueries(config: any): Array<{ module: string; query: string; params: any[] }> {
    const queries: Array<{ module: string; query: string; params: any[] }> = [];

    // Add reference data enrichment
    if (config.source_table === 'memos') {
      queries.push({
        module: 'reference-data',
        query: `
          SELECT category, value, metadata
          FROM reference_data
          WHERE category IN ('plants', 'test_types', 'products')
        `,
        params: []
      });
    }

    // Add user activity data
    queries.push({
      module: 'user-management',
      query: `
        SELECT key, value
        FROM dashboard_cache
        WHERE key LIKE 'user_activity_%'
        AND expires_at > datetime('now')
      `,
      params: []
    });

    return queries;
  }

  private async executeCrossModuleQuery(query: { module: string; query: string; params: any[] }): Promise<any> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return null;

    try {
      const result = await window.electronAPI.dbQuery(query.query, query.params);
      return result.success ? { module: query.module, data: result.data } : null;
    } catch (error) {
      console.error(`Error executing cross-module query for ${query.module}:`, error);
      return null;
    }
  }

  private mergeCrossModuleResults(results: any[]): any {
    const merged: Record<string, any> = {};

    results.forEach(result => {
      if (result && result.data) {
        merged[result.module] = result.data;
      }
    });

    return merged;
  }

  async enableRealTimeSync(): Promise<void> {
    // Set up periodic sync every 5 minutes
    setInterval(async () => {
      try {
        await this.syncAllModules();
      } catch (error) {
        console.error('Error in periodic sync:', error);
      }
    }, 5 * 60 * 1000);

    // Initial sync
    await this.syncAllModules();
  }
}

export const crossModuleIntegrationService = new CrossModuleIntegrationService();