// Integration service for connecting Reference Data Manager with existing modules
// Updated: 2025-01-31 - Removed Node.js EventEmitter dependency for browser compatibility
import { modernReferenceDataService } from '../reference-data/modernReferenceDataService';
import { backgroundSyncService } from '../sync/backgroundSyncService';

// Browser-compatible EventEmitter implementation
class SimpleEventEmitter {
  private events: Record<string, Function[]> = {};

  on(event: string, listener: Function) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(listener);
  }

  off(event: string, listener: Function) {
    if (!this.events[event]) return;
    this.events[event] = this.events[event].filter(l => l !== listener);
  }

  emit(event: string, ...args: any[]) {
    if (!this.events[event]) return;
    this.events[event].forEach(listener => listener(...args));
  }
}

interface ReferenceDataChangeEvent {
  table_name: string;
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
  record_id: string;
  data: any;
  timestamp: string;
}

interface ModuleIntegrationConfig {
  moduleId: string;
  requiredDatasets: string[];
  subscriptions: string[];
  permissions: string[];
}

export class ReferenceDataIntegrationService extends SimpleEventEmitter {
  private static instance: ReferenceDataIntegrationService;
  private registeredModules: Map<string, ModuleIntegrationConfig> = new Map();
  private dataCache: Map<string, any[]> = new Map();
  private lastCacheUpdate: Map<string, string> = new Map();

  private constructor() {
    super();
    this.setupEventListeners();
    this.initializeDefaultIntegrations();
  }

  public static getInstance(): ReferenceDataIntegrationService {
    if (!ReferenceDataIntegrationService.instance) {
      ReferenceDataIntegrationService.instance = new ReferenceDataIntegrationService();
    }
    return ReferenceDataIntegrationService.instance;
  }

  // Setup event listeners for sync operations
  private setupEventListeners(): void {
    backgroundSyncService.onStatusChange((status) => {
      if (status.pending_operations === 0 && status.conflicts === 0) {
        // Sync completed successfully, refresh caches
        this.refreshAllCaches();
      }
    });
  }

  // Initialize integrations with existing modules
  private initializeDefaultIntegrations(): void {
    // Test Modules integration
    this.registerModule({
      moduleId: 'test-modules',
      requiredDatasets: [
        'product_categories',
        'products', 
        'grades',
        'plants',
        'officers',
        'machines'
      ],
      subscriptions: [
        'product_categories',
        'products',
        'grades'
      ],
      permissions: ['read_reference_data']
    });

    // Memo Management integration
    this.registerModule({
      moduleId: 'memo-management',
      requiredDatasets: [
        'plants',
        'officers',
        'product_categories',
        'products'
      ],
      subscriptions: [
        'plants',
        'officers'
      ],
      permissions: ['read_reference_data']
    });

    // Analytics integration
    this.registerModule({
      moduleId: 'analytics',
      requiredDatasets: [
        'plants',
        'product_categories',
        'products',
        'test_types',
        'officers'
      ],
      subscriptions: [
        'plants',
        'product_categories',
        'products'
      ],
      permissions: ['read_reference_data']
    });

    // Aggregates module integration
    this.registerModule({
      moduleId: 'aggregates',
      requiredDatasets: [
        'material_types',
        'standards',
        'sieve_sizes',
        'plants',
        'officers',
        'machines',
        'grading_limits'
      ],
      subscriptions: [
        'material_types',
        'standards',
        'sieve_sizes',
        'grading_limits'
      ],
      permissions: ['read_reference_data']
    });
  }

  // Register a module for integration
  public registerModule(config: ModuleIntegrationConfig): void {
    this.registeredModules.set(config.moduleId, config);
    
    // Pre-cache required datasets
    this.preloadModuleData(config);
    
    this.emit('module_registered', {
      moduleId: config.moduleId,
      requiredDatasets: config.requiredDatasets
    });
  }

  // Unregister a module
  public unregisterModule(moduleId: string): void {
    const config = this.registeredModules.get(moduleId);
    if (config) {
      // Clear cached data for this module
      config.requiredDatasets.forEach(dataset => {
        this.dataCache.delete(`${moduleId}_${dataset}`);
      });
      
      this.registeredModules.delete(moduleId);
      this.emit('module_unregistered', { moduleId });
    }
  }

  // Get reference data for a specific module
  public async getModuleReferenceData(
    moduleId: string, 
    datasetName: string,
    forceRefresh: boolean = false
  ): Promise<any[]> {
    const config = this.registeredModules.get(moduleId);
    if (!config) {
      throw new Error(`Module ${moduleId} is not registered`);
    }

    if (!config.requiredDatasets.includes(datasetName)) {
      throw new Error(`Dataset ${datasetName} is not required by module ${moduleId}`);
    }

    const cacheKey = `${moduleId}_${datasetName}`;
    const lastUpdate = this.lastCacheUpdate.get(cacheKey);
    
    // Check cache freshness (5 minutes)
    const isCacheValid = lastUpdate && 
      Date.now() - new Date(lastUpdate).getTime() < 5 * 60 * 1000;

    if (!forceRefresh && isCacheValid && this.dataCache.has(cacheKey)) {
      return this.dataCache.get(cacheKey) || [];
    }

    // Fetch fresh data
    const data = await this.fetchDatasetData(datasetName);
    this.dataCache.set(cacheKey, data);
    this.lastCacheUpdate.set(cacheKey, new Date().toISOString());

    return data;
  }

  // Get dropdown options for forms
  public async getDropdownOptions(
    moduleId: string,
    datasetName: string,
    valueField: string = 'id',
    labelField: string = 'name'
  ): Promise<Array<{ value: string; label: string; data?: any }>> {
    const data = await this.getModuleReferenceData(moduleId, datasetName);
    
    return data.map(item => ({
      value: item[valueField]?.toString() || '',
      label: item[labelField]?.toString() || 'Unnamed',
      data: item
    }));
  }

  // Get filtered reference data
  public async getFilteredReferenceData(
    moduleId: string,
    datasetName: string,
    filters: Record<string, any>
  ): Promise<any[]> {
    const data = await this.getModuleReferenceData(moduleId, datasetName);
    
    return data.filter(item => {
      return Object.entries(filters).every(([key, value]) => {
        if (value === undefined || value === null || value === '') {
          return true; // Skip empty filters
        }
        return item[key] === value;
      });
    });
  }

  // Subscribe to data changes for a module
  public subscribeToChanges(moduleId: string, callback: (event: ReferenceDataChangeEvent) => void): void {
    const config = this.registeredModules.get(moduleId);
    if (!config) {
      throw new Error(`Module ${moduleId} is not registered`);
    }

    const eventName = `data_change_${moduleId}`;
    this.on(eventName, callback);
  }

  // Unsubscribe from data changes
  public unsubscribeFromChanges(moduleId: string, callback: (event: ReferenceDataChangeEvent) => void): void {
    const eventName = `data_change_${moduleId}`;
    this.off(eventName, callback);
  }

  // Notify modules of data changes
  public notifyDataChange(event: ReferenceDataChangeEvent): void {
    // Invalidate caches for affected modules
    this.registeredModules.forEach((config, moduleId) => {
      if (config.subscriptions.includes(event.table_name)) {
        const cacheKey = `${moduleId}_${event.table_name}`;
        this.dataCache.delete(cacheKey);
        this.lastCacheUpdate.delete(cacheKey);
        
        // Emit event to subscribed modules
        const eventName = `data_change_${moduleId}`;
        this.emit(eventName, event);
      }
    });

    // Emit global change event
    this.emit('reference_data_changed', event);
  }

  // Get module status and health
  public getModuleStatus(moduleId: string): {
    registered: boolean;
    requiredDatasets: string[];
    cachedDatasets: string[];
    lastUpdate: string | null;
    dataHealth: Record<string, { count: number; lastUpdate: string | null }>;
  } {
    const config = this.registeredModules.get(moduleId);
    if (!config) {
      return {
        registered: false,
        requiredDatasets: [],
        cachedDatasets: [],
        lastUpdate: null,
        dataHealth: {}
      };
    }

    const cachedDatasets = config.requiredDatasets.filter(dataset => 
      this.dataCache.has(`${moduleId}_${dataset}`)
    );

    const dataHealth: Record<string, { count: number; lastUpdate: string | null }> = {};
    config.requiredDatasets.forEach(dataset => {
      const cacheKey = `${moduleId}_${dataset}`;
      const data = this.dataCache.get(cacheKey) || [];
      dataHealth[dataset] = {
        count: data.length,
        lastUpdate: this.lastCacheUpdate.get(cacheKey) || null
      };
    });

    const lastUpdateTimes = Object.values(dataHealth)
      .map(h => h.lastUpdate)
      .filter(Boolean) as string[];
    
    const lastUpdate = lastUpdateTimes.length > 0 
      ? lastUpdateTimes.sort().pop() || null
      : null;

    return {
      registered: true,
      requiredDatasets: config.requiredDatasets,
      cachedDatasets,
      lastUpdate,
      dataHealth
    };
  }

  // Pre-load data for a module
  private async preloadModuleData(config: ModuleIntegrationConfig): Promise<void> {
    try {
      const promises = config.requiredDatasets.map(async (dataset) => {
        const data = await this.fetchDatasetData(dataset);
        const cacheKey = `${config.moduleId}_${dataset}`;
        this.dataCache.set(cacheKey, data);
        this.lastCacheUpdate.set(cacheKey, new Date().toISOString());
      });

      await Promise.all(promises);
      
      this.emit('module_data_preloaded', {
        moduleId: config.moduleId,
        datasets: config.requiredDatasets
      });
    } catch (error) {
      console.error(`Failed to preload data for module ${config.moduleId}:`, error);
    }
  }

  // Fetch dataset data from the service
  private async fetchDatasetData(datasetName: string): Promise<any[]> {
    try {
      // Try to get from dataset definitions first
      const definitions = await modernReferenceDataService.getDatasetDefinitions();
      const definition = definitions.find(d => d.table_name === datasetName);
      
      if (definition) {
        return await modernReferenceDataService.getTableData(datasetName);
      }

      // Fallback to legacy reference data service methods
      return await this.fetchLegacyData(datasetName);
    } catch (error) {
      console.error(`Failed to fetch data for dataset ${datasetName}:`, error);
      return [];
    }
  }

  // Fallback for legacy reference data
  private async fetchLegacyData(datasetName: string): Promise<any[]> {
    // Import legacy service methods as needed
    const { referenceDataService } = await import('../database/referenceDataService');
    
    switch (datasetName) {
      case 'plants':
        return await referenceDataService.getPlants();
      case 'officers':
        return await referenceDataService.getOfficers();
      case 'machines':
        return await referenceDataService.getMachines();
      case 'product_categories':
        return await referenceDataService.getProductCategories();
      case 'products':
        return await referenceDataService.getProducts();
      case 'grades':
        return []; // Grades will be handled by modern service
      case 'grading_limits':
        return []; // Grading limits will be handled by modern service
      default:
        console.warn(`Unknown legacy dataset: ${datasetName}`);
        return [];
    }
  }

  // Refresh all cached data
  private async refreshAllCaches(): Promise<void> {
    const refreshPromises: Promise<void>[] = [];

    this.registeredModules.forEach((config, moduleId) => {
      const promise = this.preloadModuleData(config);
      refreshPromises.push(promise);
    });

    await Promise.all(refreshPromises);
    this.emit('caches_refreshed');
  }

  // Batch get multiple datasets for a module
  public async getMultipleDatasets(
    moduleId: string,
    datasetNames: string[]
  ): Promise<Record<string, any[]>> {
    const results: Record<string, any[]> = {};
    
    const promises = datasetNames.map(async (datasetName) => {
      try {
        const data = await this.getModuleReferenceData(moduleId, datasetName);
        results[datasetName] = data;
      } catch (error) {
        console.error(`Failed to fetch ${datasetName} for module ${moduleId}:`, error);
        results[datasetName] = [];
      }
    });

    await Promise.all(promises);
    return results;
  }

  // Create React hook for module integration
  public createModuleHook(moduleId: string) {
    return {
      useReferenceData: (datasetName: string) => {
        // This would be implemented as a React hook in the actual module
        // For now, return the service methods
        return {
          data: () => this.getModuleReferenceData(moduleId, datasetName),
          options: (valueField?: string, labelField?: string) => 
            this.getDropdownOptions(moduleId, datasetName, valueField, labelField),
          filtered: (filters: Record<string, any>) => 
            this.getFilteredReferenceData(moduleId, datasetName, filters),
          refresh: () => this.getModuleReferenceData(moduleId, datasetName, true)
        };
      },
      
      subscribeToChanges: (callback: (event: ReferenceDataChangeEvent) => void) => 
        this.subscribeToChanges(moduleId, callback),
      
      getModuleStatus: () => this.getModuleStatus(moduleId)
    };
  }
}

// Export singleton instance
export const referenceDataIntegration = ReferenceDataIntegrationService.getInstance();

// Export integration hooks for existing modules
export const testModulesIntegration = referenceDataIntegration.createModuleHook('test-modules');
export const memoManagementIntegration = referenceDataIntegration.createModuleHook('memo-management');
export const analyticsIntegration = referenceDataIntegration.createModuleHook('analytics');
export const aggregatesIntegration = referenceDataIntegration.createModuleHook('aggregates');