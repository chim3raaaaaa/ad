import { toast } from '@/hooks/use-toast';

export interface ScheduleConstraint {
  id: string;
  name: string;
  type: 'lab_capacity' | 'equipment' | 'technician' | 'holiday' | 'priority';
  value: number;
  startDate?: string;
  endDate?: string;
  daysOfWeek?: number[]; // 0-6, Sunday to Saturday
}

export interface TestScheduleRequest {
  memoId: string;
  testType: string;
  productionDate: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  estimatedDuration: number; // in hours
  requiredEquipment?: string[];
  preferredTechnician?: string;
  dueDate?: string;
}

export interface ScheduledTest {
  id: string;
  memoId: string;
  testType: string;
  scheduledDate: string;
  scheduledTime: string;
  estimatedEndTime: string;
  assignedTechnician?: string;
  assignedEquipment?: string[];
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'rescheduled';
  priority: 'low' | 'medium' | 'high' | 'critical';
  conflictLevel: 'none' | 'minor' | 'major';
  autoScheduled: boolean;
}

export interface LabCapacitySnapshot {
  date: string;
  totalCapacity: number;
  usedCapacity: number;
  availableSlots: Array<{
    startTime: string;
    endTime: string;
    technician?: string;
    equipment?: string[];
  }>;
  conflicts: Array<{
    type: 'overbooked' | 'equipment_conflict' | 'technician_unavailable';
    severity: 'low' | 'medium' | 'high';
    description: string;
  }>;
}

class SmartSchedulingService {
  private constraints: ScheduleConstraint[] = [];
  private scheduledTests: ScheduledTest[] = [];

  constructor() {
    this.initializeDefaultConstraints();
    this.loadSchedulingData();
  }

  private initializeDefaultConstraints() {
    this.constraints = [
      {
        id: 'lab-capacity',
        name: 'Daily Lab Capacity',
        type: 'lab_capacity',
        value: 8, // 8 tests per day
      },
      {
        id: 'standard-hours',
        name: 'Standard Working Hours',
        type: 'lab_capacity',
        value: 8, // 8 hours per day
        daysOfWeek: [1, 2, 3, 4, 5] // Monday to Friday
      },
      {
        id: 'high-priority-boost',
        name: 'High Priority Time Allocation',
        type: 'priority',
        value: 2 // 2x priority multiplier
      }
    ];
  }

  private async loadSchedulingData() {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      // Create scheduling tables if they don't exist
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS scheduled_tests (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          test_type TEXT NOT NULL,
          scheduled_date TEXT NOT NULL,
          scheduled_time TEXT NOT NULL,
          estimated_end_time TEXT NOT NULL,
          assigned_technician TEXT,
          assigned_equipment TEXT,
          status TEXT DEFAULT 'scheduled',
          priority TEXT DEFAULT 'medium',
          conflict_level TEXT DEFAULT 'none',
          auto_scheduled INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS scheduling_constraints (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          type TEXT NOT NULL,
          value REAL NOT NULL,
          start_date TEXT,
          end_date TEXT,
          days_of_week TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Load existing scheduled tests
      const result = await window.electronAPI.dbQuery('SELECT * FROM scheduled_tests ORDER BY scheduled_date, scheduled_time');
      if (result.success) {
        this.scheduledTests = result.data.map(this.mapRowToScheduledTest);
      }
    } catch (error) {
      console.error('Error initializing scheduling database:', error);
    }
  }

  async scheduleTest(request: TestScheduleRequest): Promise<ScheduledTest | null> {
    try {
      // Calculate optimal scheduling date
      const optimalDate = await this.calculateOptimalDate(request);
      const timeSlot = await this.findOptimalTimeSlot(optimalDate, request);

      if (!timeSlot) {
        toast({
          title: 'Scheduling Conflict',
          description: 'No available time slots found. Please try a different date.',
          variant: 'destructive'
        });
        return null;
      }

      const scheduledTest: ScheduledTest = {
        id: crypto.randomUUID(),
        memoId: request.memoId,
        testType: request.testType,
        scheduledDate: optimalDate,
        scheduledTime: timeSlot.startTime,
        estimatedEndTime: timeSlot.endTime,
        assignedTechnician: timeSlot.technician,
        assignedEquipment: request.requiredEquipment,
        status: 'scheduled',
        priority: request.priority,
        conflictLevel: timeSlot.conflictLevel || 'none',
        autoScheduled: true
      };

      // Save to database
      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      if (isElectron) {
        await window.electronAPI.dbQuery(`
          INSERT INTO scheduled_tests 
          (id, memo_id, test_type, scheduled_date, scheduled_time, estimated_end_time, 
           assigned_technician, assigned_equipment, status, priority, conflict_level, auto_scheduled)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          scheduledTest.id,
          scheduledTest.memoId,
          scheduledTest.testType,
          scheduledTest.scheduledDate,
          scheduledTest.scheduledTime,
          scheduledTest.estimatedEndTime,
          scheduledTest.assignedTechnician || null,
          JSON.stringify(scheduledTest.assignedEquipment || []),
          scheduledTest.status,
          scheduledTest.priority,
          scheduledTest.conflictLevel,
          scheduledTest.autoScheduled ? 1 : 0
        ]);
      }

      this.scheduledTests.push(scheduledTest);

      toast({
        title: 'Test Scheduled Successfully',
        description: `Test scheduled for ${optimalDate} at ${timeSlot.startTime}`,
      });

      return scheduledTest;
    } catch (error) {
      console.error('Error scheduling test:', error);
      toast({
        title: 'Scheduling Error',
        description: 'Failed to schedule test. Please try again.',
        variant: 'destructive'
      });
      return null;
    }
  }

  private async calculateOptimalDate(request: TestScheduleRequest): Promise<string> {
    const productionDate = new Date(request.productionDate);
    const standardTestDate = new Date(productionDate);
    standardTestDate.setDate(standardTestDate.getDate() + 28); // Standard 28-day cycle

    // Apply priority adjustments
    let targetDate = new Date(standardTestDate);
    
    if (request.priority === 'critical') {
      targetDate.setDate(targetDate.getDate() - 7); // Rush by 1 week
    } else if (request.priority === 'high') {
      targetDate.setDate(targetDate.getDate() - 3); // Rush by 3 days
    }

    // Find the next available working day
    while (!this.isWorkingDay(targetDate)) {
      targetDate.setDate(targetDate.getDate() + 1);
    }

    return targetDate.toISOString().split('T')[0];
  }

  private async findOptimalTimeSlot(date: string, request: TestScheduleRequest): Promise<{
    startTime: string;
    endTime: string;
    technician?: string;
    conflictLevel?: 'none' | 'minor' | 'major';
  } | null> {
    const capacity = await this.getLabCapacity(date);
    
    // Standard working hours: 8 AM to 5 PM
    const workingHours = [
      { start: '08:00', end: '10:00' },
      { start: '10:00', end: '12:00' },
      { start: '13:00', end: '15:00' }, // After lunch
      { start: '15:00', end: '17:00' }
    ];

    for (const slot of workingHours) {
      const slotStart = new Date(`${date}T${slot.start}:00`);
      const slotEnd = new Date(`${date}T${slot.end}:00`);
      
      // Check if slot has capacity
      const conflictLevel = this.checkSlotConflicts(date, slot.start, slot.end);
      
      if (conflictLevel !== 'major') {
        return {
          startTime: slot.start,
          endTime: slot.end,
          technician: capacity.availableSlots[0]?.technician,
          conflictLevel
        };
      }
    }

    return null;
  }

  private isWorkingDay(date: Date): boolean {
    const dayOfWeek = date.getDay();
    return dayOfWeek >= 1 && dayOfWeek <= 5; // Monday to Friday
  }

  private async getLabCapacity(date: string): Promise<LabCapacitySnapshot> {
    const testsOnDate = this.scheduledTests.filter(test => test.scheduledDate === date);
    const totalCapacity = 8; // 8 tests per day
    const usedCapacity = testsOnDate.length;

    return {
      date,
      totalCapacity,
      usedCapacity,
      availableSlots: this.generateAvailableSlots(date, testsOnDate),
      conflicts: this.detectConflicts(testsOnDate)
    };
  }

  private generateAvailableSlots(date: string, existingTests: ScheduledTest[]): Array<{
    startTime: string;
    endTime: string;
    technician?: string;
  }> {
    const slots = [];
    const workingHours = ['08:00', '10:00', '13:00', '15:00'];
    
    for (let i = 0; i < workingHours.length; i++) {
      const startTime = workingHours[i];
      const endTime = i < workingHours.length - 1 ? workingHours[i + 1] : '17:00';
      
      const isOccupied = existingTests.some(test => 
        test.scheduledTime === startTime
      );
      
      if (!isOccupied) {
        slots.push({
          startTime,
          endTime,
          technician: `Tech-${i + 1}`
        });
      }
    }
    
    return slots;
  }

  private checkSlotConflicts(date: string, startTime: string, endTime: string): 'none' | 'minor' | 'major' {
    const testsInSlot = this.scheduledTests.filter(test => 
      test.scheduledDate === date && 
      test.scheduledTime === startTime
    );

    if (testsInSlot.length === 0) return 'none';
    if (testsInSlot.length === 1) return 'minor';
    return 'major';
  }

  private detectConflicts(tests: ScheduledTest[]): Array<{
    type: 'overbooked' | 'equipment_conflict' | 'technician_unavailable';
    severity: 'low' | 'medium' | 'high';
    description: string;
  }> {
    const conflicts = [];
    
    if (tests.length > 8) {
      conflicts.push({
        type: 'overbooked' as const,
        severity: 'high' as const,
        description: `Lab overbooked: ${tests.length} tests scheduled (max 8)`
      });
    }

    return conflicts;
  }

  private mapRowToScheduledTest(row: any): ScheduledTest {
    return {
      id: row.id,
      memoId: row.memo_id,
      testType: row.test_type,
      scheduledDate: row.scheduled_date,
      scheduledTime: row.scheduled_time,
      estimatedEndTime: row.estimated_end_time,
      assignedTechnician: row.assigned_technician,
      assignedEquipment: row.assigned_equipment ? JSON.parse(row.assigned_equipment) : [],
      status: row.status,
      priority: row.priority,
      conflictLevel: row.conflict_level,
      autoScheduled: Boolean(row.auto_scheduled)
    };
  }

  async getScheduleForDate(date: string): Promise<ScheduledTest[]> {
    return this.scheduledTests.filter(test => test.scheduledDate === date);
  }

  async getScheduleForDateRange(startDate: string, endDate: string): Promise<ScheduledTest[]> {
    return this.scheduledTests.filter(test => 
      test.scheduledDate >= startDate && test.scheduledDate <= endDate
    );
  }

  async rescheduleTest(testId: string, newDate: string, newTime: string): Promise<boolean> {
    const testIndex = this.scheduledTests.findIndex(test => test.id === testId);
    if (testIndex === -1) return false;

    const test = this.scheduledTests[testIndex];
    test.scheduledDate = newDate;
    test.scheduledTime = newTime;
    test.status = 'rescheduled';

    // Update database
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      await window.electronAPI.dbQuery(
        'UPDATE scheduled_tests SET scheduled_date = ?, scheduled_time = ?, status = ? WHERE id = ?',
        [newDate, newTime, 'rescheduled', testId]
      );
    }

    return true;
  }

  async batchScheduleFromMemos(): Promise<{ scheduled: number; failed: number }> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return { scheduled: 0, failed: 0 };

    try {
      // Get unscheduled memos with production data
      const result = await window.electronAPI.dbQuery(`
        SELECT id, memo_ref, production_data
        FROM memos 
        WHERE id NOT IN (SELECT memo_id FROM scheduled_tests)
        AND json_extract(production_data, '$[0].production_date') IS NOT NULL
        LIMIT 50
      `);

      if (!result.success) return { scheduled: 0, failed: 0 };

      let scheduled = 0;
      let failed = 0;

      for (const memo of result.data) {
        try {
          const productionData = JSON.parse(memo.production_data || '[]');
          if (productionData.length > 0 && productionData[0].production_date) {
            const request: TestScheduleRequest = {
              memoId: memo.id,
              testType: 'standard',
              productionDate: productionData[0].production_date,
              priority: 'medium',
              estimatedDuration: 2
            };

            const result = await this.scheduleTest(request);
            if (result) {
              scheduled++;
            } else {
              failed++;
            }
          }
        } catch (error) {
          console.error(`Error scheduling memo ${memo.id}:`, error);
          failed++;
        }
      }

      return { scheduled, failed };
    } catch (error) {
      console.error('Error in batch scheduling:', error);
      return { scheduled: 0, failed: 0 };
    }
  }
}

export const smartSchedulingService = new SmartSchedulingService();