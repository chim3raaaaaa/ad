// Real audit logging service for tracking system events
export interface AuditEvent {
  user: string;
  action: string;
  resource: string;
  details?: string;
  ip_address?: string;
  severity?: 'info' | 'warning' | 'critical';
}

export class AuditLogger {
  static async logEvent(event: AuditEvent): Promise<void> {
    try {
      if (window.electronAPI) {
        // Ensure audit table exists
        const createTableSQL = `
          CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            user TEXT NOT NULL,
            action TEXT NOT NULL,
            resource TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            severity TEXT DEFAULT 'info'
          )
        `;
        await window.electronAPI.dbRun(createTableSQL);
        
        // Insert audit log entry
        const insertSQL = `
          INSERT INTO audit_logs (user, action, resource, details, ip_address, severity)
          VALUES (?, ?, ?, ?, ?, ?)
        `;
        
        await window.electronAPI.dbRun(insertSQL, [
          event.user,
          event.action,
          event.resource,
          event.details || '',
          event.ip_address || '127.0.0.1',
          event.severity || 'info'
        ]);
      } else {
        // Fallback to console logging
        console.log('AUDIT:', event);
      }
    } catch (error) {
      console.error('Failed to log audit event:', error);
    }
  }

  // Convenience methods for common audit events
  static async logTableCreation(user: string, tableName: string): Promise<void> {
    await this.logEvent({
      user,
      action: 'CREATE_TABLE',
      resource: 'table',
      details: `Created table: ${tableName}`,
      severity: 'info'
    });
  }

  static async logDataImport(user: string, records: number, tableName?: string): Promise<void> {
    await this.logEvent({
      user,
      action: 'IMPORT_DATA',
      resource: 'data',
      details: `Imported ${records} records${tableName ? ` into ${tableName}` : ''}`,
      severity: 'info'
    });
  }

  static async logDataExport(user: string, format: string, records: number): Promise<void> {
    await this.logEvent({
      user,
      action: 'EXPORT_DATA',
      resource: 'data',
      details: `Exported ${records} records as ${format}`,
      severity: 'info'
    });
  }

  static async logVersionSave(user: string, tableName: string, version: string): Promise<void> {
    await this.logEvent({
      user,
      action: 'SAVE_VERSION',
      resource: 'version_control',
      details: `Saved version ${version} of table ${tableName}`,
      severity: 'info'
    });
  }

  static async logSystemError(user: string, error: string): Promise<void> {
    await this.logEvent({
      user,
      action: 'SYSTEM_ERROR',
      resource: 'system',
      details: error,
      severity: 'critical'
    });
  }
}