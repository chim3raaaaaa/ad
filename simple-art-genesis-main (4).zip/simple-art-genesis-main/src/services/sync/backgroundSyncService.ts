// Background synchronization service
import { localSyncService } from './localSyncService';
import { createSyncServerAPI, SyncServerAPI } from './syncServerAPI';
import { SyncProgress, SyncStatus, SyncConflict } from './syncTypes';

export class BackgroundSyncService {
  private syncAPI: SyncServerAPI;
  private isRunning = false;
  private syncInterval: NodeJS.Timeout | null = null;
  private progressCallback?: (progress: SyncProgress) => void;
  private statusCallback?: (status: SyncStatus) => void;

  constructor() {
    this.syncAPI = createSyncServerAPI();
    this.startPeriodicSync();
  }

  // Set callback for sync progress updates
  onProgress(callback: (progress: SyncProgress) => void): void {
    this.progressCallback = callback;
  }

  // Set callback for sync status updates
  onStatusChange(callback: (status: SyncStatus) => void): void {
    this.statusCallback = callback;
  }

  // Start periodic synchronization
  startPeriodicSync(intervalMinutes: number = 5): void {
    this.stopPeriodicSync();
    
    this.syncInterval = setInterval(() => {
      if (navigator.onLine && !this.isRunning) {
        this.performSync().catch(console.error);
      }
    }, intervalMinutes * 60 * 1000);
  }

  // Stop periodic synchronization
  stopPeriodicSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }

  // Perform full synchronization
  async performSync(force: boolean = false): Promise<void> {
    if (this.isRunning && !force) {
      console.log('Sync already in progress');
      return;
    }

    this.isRunning = true;
    
    try {
      await this.updateStatus();
      
      // Check server connectivity
      const isConnected = await this.checkServerConnectivity();
      if (!isConnected) {
        console.log('Server not reachable, skipping sync');
        return;
      }

      // Sync dataset definitions first
      await this.syncDatasetDefinitions();
      
      // Push local changes
      await this.pushLocalChanges();
      
      // Pull remote changes
      await this.pullRemoteChanges();
      
      // Update last sync timestamp
      await localSyncService.updateLastSync();
      
      this.emitProgress({
        stage: 'complete',
        progress: 100,
        total: 100,
        message: 'Synchronization completed successfully'
      });

    } catch (error) {
      console.error('Sync failed:', error);
      this.emitProgress({
        stage: 'complete',
        progress: 0,
        total: 100,
        message: `Synchronization failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
      throw error;
    } finally {
      this.isRunning = false;
      await this.updateStatus();
    }
  }

  // Check server connectivity
  private async checkServerConnectivity(): Promise<boolean> {
    this.emitProgress({
      stage: 'connecting',
      progress: 0,
      total: 100,
      message: 'Checking server connectivity...'
    });

    try {
      return await this.syncAPI.checkConnectivity();
    } catch (error) {
      return false;
    }
  }

  // Sync dataset definitions
  private async syncDatasetDefinitions(): Promise<void> {
    this.emitProgress({
      stage: 'downloading',
      progress: 10,
      total: 100,
      current_table: 'dataset_definitions',
      message: 'Syncing dataset definitions...'
    });

    try {
      const status = await localSyncService.getSyncStatus();
      const response = await this.syncAPI.getDatasetDefinitions(status.last_sync || undefined);
      
      if (response.success && response.data) {
        for (const definition of response.data) {
          await localSyncService.saveDatasetDefinition(definition);
        }
      }
    } catch (error) {
      console.error('Failed to sync dataset definitions:', error);
    }
  }

  // Push local changes to server
  private async pushLocalChanges(): Promise<void> {
    this.emitProgress({
      stage: 'uploading',
      progress: 30,
      total: 100,
      message: 'Uploading local changes...'
    });

    try {
      const pendingOps = await localSyncService.getPendingOperations();
      
      if (pendingOps.length === 0) {
        return;
      }

      // Split operations into batches
      const batchSize = 100;
      for (let i = 0; i < pendingOps.length; i += batchSize) {
        const batch = pendingOps.slice(i, i + batchSize);
        
        this.emitProgress({
          stage: 'uploading',
          progress: 30 + (i / pendingOps.length) * 30,
          total: 100,
          message: `Uploading changes... (${i + batch.length}/${pendingOps.length})`
        });

        const response = await this.syncAPI.pushOperations(batch);
        
        if (response.success) {
          // Mark operations as synced
          const syncedIds = batch.map(op => op.id);
          await localSyncService.markOperationsSynced(syncedIds);
          
          // Handle any conflicts
          if (response.data?.conflicts && response.data.conflicts.length > 0) {
            for (const conflict of response.data.conflicts) {
              await localSyncService.saveConflict(conflict);
            }
          }
        }
      }
    } catch (error) {
      console.error('Failed to push local changes:', error);
      throw error;
    }
  }

  // Pull remote changes from server
  private async pullRemoteChanges(): Promise<void> {
    this.emitProgress({
      stage: 'downloading',
      progress: 60,
      total: 100,
      message: 'Downloading remote changes...'
    });

    try {
      const status = await localSyncService.getSyncStatus();
      const response = await this.syncAPI.pullChanges(status.last_sync || '1970-01-01T00:00:00.000Z');
      
      if (response.success && response.data) {
        const { operations, conflicts } = response.data;
        
        // Apply remote operations
        for (let i = 0; i < operations.length; i++) {
          const operation = operations[i];
          
          this.emitProgress({
            stage: 'downloading',
            progress: 60 + (i / operations.length) * 30,
            total: 100,
            current_table: operation.table_name,
            message: `Applying changes to ${operation.table_name}...`
          });

          await this.applyRemoteOperation(operation);
        }
        
        // Handle conflicts
        for (const conflict of conflicts) {
          await localSyncService.saveConflict(conflict);
        }
      }
    } catch (error) {
      console.error('Failed to pull remote changes:', error);
      throw error;
    }
  }

  // Apply a remote operation locally
  private async applyRemoteOperation(operation: any): Promise<void> {
    try {
      const isElectron = typeof window !== 'undefined' && (window as any).electronAPI;
      
      if (!isElectron) {
        // Browser fallback - apply to localStorage
        const key = `reference_data_${operation.table_name}`;
        const existing = JSON.parse(localStorage.getItem(key) || '[]');
        
        switch (operation.operation) {
          case 'INSERT':
            existing.push(operation.data);
            break;
          case 'UPDATE':
            const updateIndex = existing.findIndex((item: any) => item.id === operation.data.id);
            if (updateIndex >= 0) {
              existing[updateIndex] = { ...existing[updateIndex], ...operation.data };
            }
            break;
          case 'DELETE':
            const deleteIndex = existing.findIndex((item: any) => item.id === operation.data.id);
            if (deleteIndex >= 0) {
              existing.splice(deleteIndex, 1);
            }
            break;
        }
        
        localStorage.setItem(key, JSON.stringify(existing));
        return;
      }

      // Electron implementation
      switch (operation.operation) {
        case 'INSERT':
          const insertColumns = Object.keys(operation.data);
          const insertPlaceholders = insertColumns.map(() => '?').join(', ');
          const insertValues = Object.values(operation.data);
          
          await (window as any).electronAPI.dbRun(
            `INSERT OR IGNORE INTO ${operation.table_name} (${insertColumns.join(', ')}) VALUES (${insertPlaceholders})`,
            insertValues
          );
          break;

        case 'UPDATE':
          const updateColumns = Object.keys(operation.data).filter(key => key !== 'id');
          const updateSetClause = updateColumns.map(col => `${col} = ?`).join(', ');
          const updateValues = [...updateColumns.map(col => operation.data[col]), operation.data.id];
          
          await (window as any).electronAPI.dbRun(
            `UPDATE ${operation.table_name} SET ${updateSetClause} WHERE id = ?`,
            updateValues
          );
          break;

        case 'DELETE':
          await (window as any).electronAPI.dbRun(
            `DELETE FROM ${operation.table_name} WHERE id = ?`,
            [operation.data.id]
          );
          break;
      }
    } catch (error) {
      console.error(`Failed to apply ${operation.operation} operation:`, error);
      // Continue with other operations even if one fails
    }
  }

  // Get current sync status
  async getSyncStatus(): Promise<SyncStatus> {
    const baseStatus = await localSyncService.getSyncStatus();
    
    // Check server connectivity
    const serverReachable = await this.syncAPI.checkConnectivity();
    
    return {
      ...baseStatus,
      is_syncing: this.isRunning,
      server_reachable: serverReachable
    };
  }

  // Force immediate sync
  async forceSyncNow(): Promise<void> {
    return this.performSync(true);
  }

  // Get unresolved conflicts
  async getConflicts(): Promise<SyncConflict[]> {
    return localSyncService.getUnresolvedConflicts();
  }

  // Resolve a conflict
  async resolveConflict(
    conflictId: string,
    resolution: 'local' | 'remote' | 'merge',
    mergedData?: any
  ): Promise<void> {
    try {
      // Report resolution to server
      await this.syncAPI.resolveConflict(conflictId, resolution, mergedData);
      
      // Mark as resolved locally
      await localSyncService.resolveConflict(conflictId, resolution, mergedData);
    } catch (error) {
      console.error('Failed to resolve conflict:', error);
      throw error;
    }
  }

  // Helper methods
  private emitProgress(progress: SyncProgress): void {
    if (this.progressCallback) {
      this.progressCallback(progress);
    }
  }

  private async updateStatus(): Promise<void> {
    if (this.statusCallback) {
      const status = await this.getSyncStatus();
      this.statusCallback(status);
    }
  }

  // Cleanup
  destroy(): void {
    this.stopPeriodicSync();
    this.isRunning = false;
  }
}

export const backgroundSyncService = new BackgroundSyncService();