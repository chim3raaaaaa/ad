// Local sync service for managing offline operations and synchronization
import { v4 as uuidv4 } from 'uuid';
import { 
  SyncOperation, 
  DatasetDefinition, 
  SyncConflict, 
  AuditLogEntry, 
  SyncStatus, 
  SyncProgress,
  DeviceInfo 
} from './syncTypes';

export class LocalSyncService {
  private deviceId: string;
  private userId: string;
  private isElectron: boolean;

  constructor() {
    this.deviceId = this.getOrCreateDeviceId();
    this.userId = this.getCurrentUserId();
    this.isElectron = typeof window !== 'undefined' && (window as any).electronAPI;
    this.initializeSyncTables();
  }

  private getOrCreateDeviceId(): string {
    let deviceId = localStorage.getItem('device_id');
    if (!deviceId) {
      deviceId = uuidv4();
      localStorage.setItem('device_id', deviceId);
    }
    return deviceId;
  }

  private getCurrentUserId(): string {
    // Get current user from auth context or localStorage
    return localStorage.getItem('current_user_id') || 'anonymous';
  }

  // Initialize sync-related tables
  private async initializeSyncTables(): Promise<void> {
    if (!this.isElectron) return;

    const tables = [
      // Sync operations queue
      `CREATE TABLE IF NOT EXISTS sync_operations (
        id TEXT PRIMARY KEY,
        table_name TEXT NOT NULL,
        operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
        data TEXT NOT NULL,
        version INTEGER DEFAULT 1,
        device_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        synced INTEGER DEFAULT 0,
        conflict_resolved INTEGER DEFAULT 0
      )`,
      
      // Dataset definitions
      `CREATE TABLE IF NOT EXISTS dataset_definitions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        category TEXT NOT NULL,
        icon TEXT,
        table_name TEXT NOT NULL UNIQUE,
        fields TEXT NOT NULL,
        permissions TEXT,
        version INTEGER DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        is_active INTEGER DEFAULT 1
      )`,
      
      // Sync conflicts
      `CREATE TABLE IF NOT EXISTS sync_conflicts (
        id TEXT PRIMARY KEY,
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        local_data TEXT NOT NULL,
        remote_data TEXT NOT NULL,
        field_conflicts TEXT NOT NULL,
        conflict_type TEXT NOT NULL,
        created_at TEXT NOT NULL,
        resolved INTEGER DEFAULT 0,
        resolution TEXT
      )`,
      
      // Audit log
      `CREATE TABLE IF NOT EXISTS audit_log (
        id TEXT PRIMARY KEY,
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        operation TEXT NOT NULL,
        old_values TEXT,
        new_values TEXT,
        user_id TEXT NOT NULL,
        device_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        sync_version INTEGER DEFAULT 1
      )`,
      
      // Sync metadata
      `CREATE TABLE IF NOT EXISTS sync_metadata (
        id TEXT PRIMARY KEY DEFAULT 'singleton',
        last_sync TEXT,
        sync_version INTEGER DEFAULT 1,
        device_info TEXT
      )`
    ];

    try {
      for (const sql of tables) {
        await (window as any).electronAPI.dbRun(sql);
      }
      
      // Initialize device info
      await this.updateDeviceInfo();
    } catch (error) {
      console.error('Failed to initialize sync tables:', error);
      throw error;
    }
  }

  // Queue a sync operation
  async queueOperation(
    tableName: string,
    operation: 'INSERT' | 'UPDATE' | 'DELETE',
    data: any,
    recordId?: string
  ): Promise<void> {
    const syncOp: SyncOperation = {
      id: uuidv4(),
      table_name: tableName,
      operation,
      data: { ...data, id: recordId || data.id },
      version: 1,
      device_id: this.deviceId,
      user_id: this.userId,
      timestamp: new Date().toISOString(),
      synced: false
    };

    // Log audit entry
    await this.logAuditEntry(tableName, recordId || data.id, operation, data);

    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT INTO sync_operations 
         (id, table_name, operation, data, version, device_id, user_id, timestamp, synced) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          syncOp.id,
          syncOp.table_name,
          syncOp.operation,
          JSON.stringify(syncOp.data),
          syncOp.version,
          syncOp.device_id,
          syncOp.user_id,
          syncOp.timestamp,
          0
        ]
      );
    } else {
      // Browser fallback
      const operations = JSON.parse(localStorage.getItem('sync_operations') || '[]');
      operations.push(syncOp);
      localStorage.setItem('sync_operations', JSON.stringify(operations));
    }
  }

  // Get pending operations
  async getPendingOperations(): Promise<SyncOperation[]> {
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT * FROM sync_operations WHERE synced = 0 ORDER BY timestamp ASC'
      );
      return result.map((row: any) => ({
        ...row,
        data: JSON.parse(row.data),
        synced: Boolean(row.synced),
        conflict_resolved: Boolean(row.conflict_resolved)
      }));
    } else {
      const operations = JSON.parse(localStorage.getItem('sync_operations') || '[]');
      return operations.filter((op: SyncOperation) => !op.synced);
    }
  }

  // Mark operations as synced
  async markOperationsSynced(operationIds: string[]): Promise<void> {
    if (this.isElectron) {
      const placeholders = operationIds.map(() => '?').join(',');
      await (window as any).electronAPI.dbRun(
        `UPDATE sync_operations SET synced = 1 WHERE id IN (${placeholders})`,
        operationIds
      );
    } else {
      const operations = JSON.parse(localStorage.getItem('sync_operations') || '[]');
      const updated = operations.map((op: SyncOperation) => 
        operationIds.includes(op.id) ? { ...op, synced: true } : op
      );
      localStorage.setItem('sync_operations', JSON.stringify(updated));
    }
  }

  // Dataset definitions management
  async saveDatasetDefinition(definition: DatasetDefinition): Promise<void> {
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT OR REPLACE INTO dataset_definitions 
         (id, name, description, category, icon, table_name, fields, permissions, version, created_by, created_at, updated_at, is_active) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          definition.id,
          definition.name,
          definition.description,
          definition.category,
          definition.icon,
          definition.table_name,
          JSON.stringify(definition.fields),
          JSON.stringify(definition.permissions),
          definition.version,
          definition.created_by,
          definition.created_at,
          definition.updated_at,
          definition.is_active ? 1 : 0
        ]
      );
    } else {
      const definitions = JSON.parse(localStorage.getItem('dataset_definitions') || '[]');
      const index = definitions.findIndex((d: DatasetDefinition) => d.id === definition.id);
      if (index >= 0) {
        definitions[index] = definition;
      } else {
        definitions.push(definition);
      }
      localStorage.setItem('dataset_definitions', JSON.stringify(definitions));
    }
  }

  async getDatasetDefinitions(): Promise<DatasetDefinition[]> {
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT * FROM dataset_definitions WHERE is_active = 1 ORDER BY category, name'
      );
      return result.map((row: any) => ({
        ...row,
        fields: JSON.parse(row.fields),
        permissions: JSON.parse(row.permissions || '[]'),
        is_active: Boolean(row.is_active)
      }));
    } else {
      const definitions = JSON.parse(localStorage.getItem('dataset_definitions') || '[]');
      return definitions.filter((d: DatasetDefinition) => d.is_active);
    }
  }

  // Conflict management
  async saveConflict(conflict: SyncConflict): Promise<void> {
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT INTO sync_conflicts 
         (id, table_name, record_id, local_data, remote_data, field_conflicts, conflict_type, created_at, resolved) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          conflict.id,
          conflict.table_name,
          conflict.record_id,
          JSON.stringify(conflict.local_data),
          JSON.stringify(conflict.remote_data),
          JSON.stringify(conflict.field_conflicts),
          conflict.conflict_type,
          conflict.created_at,
          0
        ]
      );
    } else {
      const conflicts = JSON.parse(localStorage.getItem('sync_conflicts') || '[]');
      conflicts.push(conflict);
      localStorage.setItem('sync_conflicts', JSON.stringify(conflicts));
    }
  }

  async getUnresolvedConflicts(): Promise<SyncConflict[]> {
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT * FROM sync_conflicts WHERE resolved = 0 ORDER BY created_at ASC'
      );
      return result.map((row: any) => ({
        ...row,
        local_data: JSON.parse(row.local_data),
        remote_data: JSON.parse(row.remote_data),
        field_conflicts: JSON.parse(row.field_conflicts),
        resolved: Boolean(row.resolved)
      }));
    } else {
      const conflicts = JSON.parse(localStorage.getItem('sync_conflicts') || '[]');
      return conflicts.filter((c: SyncConflict) => !c.resolved);
    }
  }

  async resolveConflict(conflictId: string, resolution: 'local' | 'remote' | 'merge', mergedData?: any): Promise<void> {
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        'UPDATE sync_conflicts SET resolved = 1, resolution = ? WHERE id = ?',
        [resolution, conflictId]
      );
    } else {
      const conflicts = JSON.parse(localStorage.getItem('sync_conflicts') || '[]');
      const updated = conflicts.map((c: SyncConflict) => 
        c.id === conflictId ? { ...c, resolved: true, resolution } : c
      );
      localStorage.setItem('sync_conflicts', JSON.stringify(updated));
    }
  }

  // Audit logging
  private async logAuditEntry(
    tableName: string,
    recordId: string,
    operation: 'INSERT' | 'UPDATE' | 'DELETE',
    newValues?: any,
    oldValues?: any
  ): Promise<void> {
    const entry: AuditLogEntry = {
      id: uuidv4(),
      table_name: tableName,
      record_id: recordId,
      operation,
      old_values: oldValues,
      new_values: newValues,
      user_id: this.userId,
      device_id: this.deviceId,
      timestamp: new Date().toISOString(),
      sync_version: 1
    };

    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT INTO audit_log 
         (id, table_name, record_id, operation, old_values, new_values, user_id, device_id, timestamp, sync_version) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          entry.id,
          entry.table_name,
          entry.record_id,
          entry.operation,
          JSON.stringify(entry.old_values),
          JSON.stringify(entry.new_values),
          entry.user_id,
          entry.device_id,
          entry.timestamp,
          entry.sync_version
        ]
      );
    }
  }

  // Get sync status
  async getSyncStatus(): Promise<SyncStatus> {
    const pendingOps = await this.getPendingOperations();
    const conflicts = await this.getUnresolvedConflicts();
    
    let lastSync = null;
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT last_sync FROM sync_metadata WHERE id = "singleton"'
      );
      lastSync = result[0]?.last_sync || null;
    } else {
      lastSync = localStorage.getItem('last_sync');
    }

    return {
      last_sync: lastSync,
      pending_operations: pendingOps.length,
      conflicts: conflicts.length,
      is_syncing: false,
      connection_status: navigator.onLine ? 'online' : 'offline',
      server_reachable: false // Will be updated by actual connectivity check
    };
  }

  // Update device info
  private async updateDeviceInfo(): Promise<void> {
    const deviceInfo: DeviceInfo = {
      device_id: this.deviceId,
      device_name: navigator.userAgent || 'Unknown Device',
      user_id: this.userId,
      last_seen: new Date().toISOString(),
      sync_version: 1
    };

    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT OR REPLACE INTO sync_metadata (id, device_info) VALUES (?, ?)`,
        ['singleton', JSON.stringify(deviceInfo)]
      );
    }
  }

  // Update last sync timestamp
  async updateLastSync(): Promise<void> {
    const now = new Date().toISOString();
    
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT OR REPLACE INTO sync_metadata (id, last_sync) VALUES (?, ?)`,
        ['singleton', now]
      );
    } else {
      localStorage.setItem('last_sync', now);
    }
  }
}

export const localSyncService = new LocalSyncService();