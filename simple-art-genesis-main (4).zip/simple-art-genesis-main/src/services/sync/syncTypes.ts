// Core sync types and interfaces for local-first architecture

export interface SyncOperation {
  id: string;
  table_name: string;
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
  data: any;
  version: number;
  device_id: string;
  user_id: string;
  timestamp: string;
  synced: boolean;
  conflict_resolved?: boolean;
}

export interface DatasetDefinition {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  table_name: string;
  fields: FieldDefinition[];
  permissions: string[];
  version: number;
  created_by: string;
  created_at: string;
  updated_at: string;
  is_active: boolean;
}

export interface FieldDefinition {
  id: string;
  name: string;
  type: 'text' | 'number' | 'select' | 'date' | 'boolean' | 'file';
  required: boolean;
  default_value?: any;
  options?: string[];
  validation_rules?: ValidationRule[];
  foreign_key?: ForeignKeyDefinition;
}

export interface ValidationRule {
  type: 'min' | 'max' | 'regex' | 'unique' | 'custom';
  value: any;
  message: string;
}

export interface ForeignKeyDefinition {
  table: string;
  field: string;
  display_field?: string;
}

export interface SyncConflict {
  id: string;
  table_name: string;
  record_id: string;
  local_data: any;
  remote_data: any;
  field_conflicts: string[];
  conflict_type: 'update_update' | 'update_delete' | 'delete_update';
  created_at: string;
  resolved: boolean;
  resolution?: 'local' | 'remote' | 'merge';
}

export interface AuditLogEntry {
  id: string;
  table_name: string;
  record_id: string;
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
  old_values?: any;
  new_values?: any;
  user_id: string;
  device_id: string;
  timestamp: string;
  sync_version: number;
}

export interface SyncStatus {
  last_sync: string | null;
  pending_operations: number;
  conflicts: number;
  is_syncing: boolean;
  connection_status: 'online' | 'offline';
  server_reachable: boolean;
}

export interface ServerResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  conflicts?: SyncConflict[];
  sync_timestamp: string;
}

export interface SyncProgress {
  stage: 'connecting' | 'uploading' | 'downloading' | 'resolving_conflicts' | 'complete';
  progress: number;
  total: number;
  current_table?: string;
  message: string;
}

export interface DeviceInfo {
  device_id: string;
  device_name: string;
  user_id: string;
  last_seen: string;
  sync_version: number;
}