// Sync server API client for communicating with central reference data server
import { 
  SyncOperation, 
  DatasetDefinition, 
  ServerResponse, 
  SyncConflict,
  AuditLogEntry 
} from './syncTypes';

export interface SyncServerConfig {
  baseUrl: string;
  apiKey?: string;
  timeout?: number;
}

export class SyncServerAPI {
  private config: SyncServerConfig;

  constructor(config: SyncServerConfig) {
    this.config = {
      timeout: 30000,
      ...config
    };
  }

  private async makeRequest<T>(
    endpoint: string,
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
    body?: any
  ): Promise<ServerResponse<T>> {
    const url = `${this.config.baseUrl}${endpoint}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.config.apiKey) {
      headers['Authorization'] = `Bearer ${this.config.apiKey}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(url, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  // Dataset definitions sync
  async getDatasetDefinitions(lastSync?: string): Promise<ServerResponse<DatasetDefinition[]>> {
    const params = lastSync ? `?since=${encodeURIComponent(lastSync)}` : '';
    return this.makeRequest<DatasetDefinition[]>(`/api/datasets${params}`);
  }

  async createDatasetDefinition(definition: DatasetDefinition): Promise<ServerResponse<DatasetDefinition>> {
    return this.makeRequest<DatasetDefinition>('/api/datasets', 'POST', definition);
  }

  async updateDatasetDefinition(id: string, definition: Partial<DatasetDefinition>): Promise<ServerResponse<DatasetDefinition>> {
    return this.makeRequest<DatasetDefinition>(`/api/datasets/${id}`, 'PUT', definition);
  }

  async deleteDatasetDefinition(id: string): Promise<ServerResponse<boolean>> {
    return this.makeRequest<boolean>(`/api/datasets/${id}`, 'DELETE');
  }

  // Data synchronization
  async pushOperations(operations: SyncOperation[]): Promise<ServerResponse<{ processed: number; conflicts: SyncConflict[] }>> {
    return this.makeRequest('/api/sync/push', 'POST', { operations });
  }

  async pullChanges(
    lastSync: string,
    tables?: string[]
  ): Promise<ServerResponse<{ operations: SyncOperation[]; conflicts: SyncConflict[] }>> {
    const body = {
      last_sync: lastSync,
      tables: tables || []
    };
    return this.makeRequest('/api/sync/pull', 'POST', body);
  }

  // Table data operations
  async getTableData(
    tableName: string,
    lastSync?: string,
    limit?: number,
    offset?: number
  ): Promise<ServerResponse<{ data: any[]; total: number; has_more: boolean }>> {
    const params = new URLSearchParams();
    if (lastSync) params.set('since', lastSync);
    if (limit) params.set('limit', limit.toString());
    if (offset) params.set('offset', offset.toString());
    
    const queryString = params.toString();
    const endpoint = `/api/data/${tableName}${queryString ? `?${queryString}` : ''}`;
    
    return this.makeRequest(endpoint);
  }

  async createTableRecord(tableName: string, data: any): Promise<ServerResponse<any>> {
    return this.makeRequest(`/api/data/${tableName}`, 'POST', data);
  }

  async updateTableRecord(tableName: string, id: string, data: any): Promise<ServerResponse<any>> {
    return this.makeRequest(`/api/data/${tableName}/${id}`, 'PUT', data);
  }

  async deleteTableRecord(tableName: string, id: string): Promise<ServerResponse<boolean>> {
    return this.makeRequest(`/api/data/${tableName}/${id}`, 'DELETE');
  }

  // CSV import/export
  async uploadCSV(
    tableName: string,
    csvData: FormData,
    mappings: Record<string, string>
  ): Promise<ServerResponse<{ imported: number; errors: string[] }>> {
    const url = `${this.config.baseUrl}/api/import/${tableName}`;
    const headers: Record<string, string> = {};

    if (this.config.apiKey) {
      headers['Authorization'] = `Bearer ${this.config.apiKey}`;
    }

    // Add mappings to FormData
    csvData.append('mappings', JSON.stringify(mappings));

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.json();
  }

  async exportCSV(
    tableName: string,
    filters?: Record<string, any>
  ): Promise<Blob> {
    const params = filters ? `?${new URLSearchParams(filters).toString()}` : '';
    const url = `${this.config.baseUrl}/api/export/${tableName}${params}`;
    const headers: Record<string, string> = {};

    if (this.config.apiKey) {
      headers['Authorization'] = `Bearer ${this.config.apiKey}`;
    }

    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.blob();
  }

  // Conflict resolution
  async reportConflict(conflict: SyncConflict): Promise<ServerResponse<boolean>> {
    return this.makeRequest('/api/conflicts', 'POST', conflict);
  }

  async resolveConflict(
    conflictId: string,
    resolution: 'local' | 'remote' | 'merge',
    mergedData?: any
  ): Promise<ServerResponse<boolean>> {
    return this.makeRequest(`/api/conflicts/${conflictId}/resolve`, 'POST', {
      resolution,
      merged_data: mergedData
    });
  }

  // Audit log
  async pushAuditLog(entries: AuditLogEntry[]): Promise<ServerResponse<{ processed: number }>> {
    return this.makeRequest('/api/audit', 'POST', { entries });
  }

  async getAuditLog(
    tableName?: string,
    recordId?: string,
    since?: string,
    limit?: number
  ): Promise<ServerResponse<AuditLogEntry[]>> {
    const params = new URLSearchParams();
    if (tableName) params.set('table', tableName);
    if (recordId) params.set('record', recordId);
    if (since) params.set('since', since);
    if (limit) params.set('limit', limit.toString());
    
    const queryString = params.toString();
    const endpoint = `/api/audit${queryString ? `?${queryString}` : ''}`;
    
    return this.makeRequest(endpoint);
  }

  // Health and connectivity
  async healthCheck(): Promise<ServerResponse<{ status: string; version: string; timestamp: string }>> {
    return this.makeRequest('/api/health');
  }

  async checkConnectivity(): Promise<boolean> {
    try {
      const response = await this.healthCheck();
      return response.success;
    } catch (error) {
      return false;
    }
  }

  // Schema management
  async getSchema(tableName?: string): Promise<ServerResponse<Record<string, any>>> {
    const endpoint = tableName ? `/api/schema/${tableName}` : '/api/schema';
    return this.makeRequest(endpoint);
  }

  async createTable(tableName: string, schema: any): Promise<ServerResponse<boolean>> {
    return this.makeRequest('/api/schema/create', 'POST', {
      table_name: tableName,
      schema
    });
  }

  async alterTable(tableName: string, changes: any): Promise<ServerResponse<boolean>> {
    return this.makeRequest('/api/schema/alter', 'POST', {
      table_name: tableName,
      changes
    });
  }

  async dropTable(tableName: string): Promise<ServerResponse<boolean>> {
    return this.makeRequest(`/api/schema/${tableName}`, 'DELETE');
  }
}

// Default configuration - will be overridden by actual server setup
export const createSyncServerAPI = (config?: Partial<SyncServerConfig>): SyncServerAPI => {
  const defaultConfig: SyncServerConfig = {
    baseUrl: 'http://localhost:3001', // Local HTTP server
    timeout: 30000,
    ...config
  };
  
  return new SyncServerAPI(defaultConfig);
};