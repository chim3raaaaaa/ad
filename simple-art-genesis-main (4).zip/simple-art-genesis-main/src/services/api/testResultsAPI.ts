// Cross-platform API service for test results
import { AggregateTestEntry } from '@/services/database/aggregateTestService';

export interface TestResultAPIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface ConcreteTestResult {
  id?: string;
  memo_reference: string;
  production_date: string;
  test_date: string;
  age_days: number;
  operator_name: string;
  machine_no: string;
  product: string;
  load_kn: number;
  weight_kg: number;
  strength_mpa: number;
  status: 'pass' | 'fail' | 'pending';
  product_type: string;
  created_by?: string;
  data_source?: string;
  sync_status?: string;
  external_id?: string;
  created_at?: string;
  updated_at?: string;
}

export interface TabletConnection {
  device_id: string;
  device_name: string;
  operator_name?: string;
  location?: string;
  is_connected: boolean;
  last_ping: Date;
  status: 'online' | 'offline' | 'disconnected';
}

export class TestResultsAPI {
  private static baseUrl = '/api/test-results'; // Will be configured based on environment
  
  // Initialize API service
  static async initialize(): Promise<void> {
    console.log('Initializing Test Results API...');
    
    // In Electron, ensure database tables exist
    if (window.electronAPI) {
      await this.initializeElectronTables();
    }
  }

  private static async initializeElectronTables(): Promise<void> {
    try {
      // Create aggregate tests table with correct naming
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS aggregate_tests (
          id TEXT PRIMARY KEY,
          memo_reference TEXT NOT NULL,
          production_date TEXT,
          test_date TEXT NOT NULL,
          sampling_date TEXT,
          plant_id TEXT,
          officer_id TEXT,
          aggregate_type_id TEXT,
          machine_no TEXT,
          sampling_place_id TEXT,
          moisture_condition_id TEXT,
          climatic_condition_id TEXT,
          sampled_by_id TEXT,
          material_type TEXT,
          sample_id TEXT,
          location TEXT,
          remarks TEXT,
          
          -- Sieve analysis columns
          sieve_0_075 REAL, sieve_0_15 REAL, sieve_0_3 REAL, sieve_0_6 REAL,
          sieve_1_18 REAL, sieve_2_36 REAL, sieve_5 REAL, sieve_10 REAL,
          sieve_075 REAL, sieve_150 REAL, sieve_300 REAL, sieve_600 REAL,
          sieve_118 REAL, sieve_236 REAL, sieve_475 REAL, sieve_950 REAL,
          sieve_2 REAL, sieve_14 REAL, sieve_20 REAL, sieve_28 REAL, sieve_40 REAL,
          
          -- Physical properties
          specific_gravity REAL, bulk_density REAL, water_absorption REAL,
          moisture_content REAL, fineness_modulus REAL, sand_equivalent REAL,
          methylene_blue REAL, los_angeles_abrasion REAL, aggregate_impact_value REAL,
          aggregate_crushing_value REAL, flakiness_index REAL, elongation_index REAL,
          soundness_test REAL, bulk_density_loose REAL, bulk_density_compacted REAL,
          bulk_density_ssd REAL, bulk_density_apparent REAL, bulk_density_oven_dried REAL,
          organic_impurities REAL,
          
          -- Results
          observations TEXT,
          grading_conformity TEXT DEFAULT 'pending' CHECK (grading_conformity IN ('pass', 'fail', 'pending')),
          cleanliness_conformity TEXT DEFAULT 'pending' CHECK (cleanliness_conformity IN ('pass', 'fail', 'pending')),
          test_performed BOOLEAN DEFAULT 0,
          calculation_sheet_path TEXT,
          
          -- Metadata
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          created_by TEXT
        )
      `);

      // Create concrete tests table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS concrete_tests (
          id TEXT PRIMARY KEY,
          memo_reference TEXT,
          production_date TEXT,
          test_date TEXT,
          age_days INTEGER,
          operator_name TEXT,
          machine_no TEXT,
          product TEXT,
          load_kn REAL,
          weight_kg REAL,
          strength_mpa REAL,
          status TEXT DEFAULT 'pending' CHECK (status IN ('pass', 'fail', 'pending')),
          product_type TEXT,
          created_by TEXT,
          data_source TEXT DEFAULT 'manual',
          sync_status TEXT DEFAULT 'local',
          external_id TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create tablet connections table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS tablet_connections (
          device_id TEXT PRIMARY KEY,
          device_name TEXT NOT NULL,
          operator_name TEXT,
          location TEXT,
          is_connected BOOLEAN DEFAULT 0,
          last_ping TEXT,
          status TEXT DEFAULT 'offline' CHECK (status IN ('online', 'offline', 'disconnected')),
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      console.log('Electron database tables initialized');
    } catch (error) {
      console.error('Failed to initialize Electron tables:', error);
    }
  }

  // AGGREGATE TEST RESULTS API
  static async getAggregateTests(filters?: {
    memo_reference?: string;
    plant_id?: string;
    start_date?: string;
    end_date?: string;
    officer_id?: string;
  }): Promise<TestResultAPIResponse<AggregateTestEntry[]>> {
    try {
      if (window.electronAPI) {
        return await this.getElectronAggregateTests(filters);
      } else {
        return await this.getBrowserAggregateTests(filters);
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  private static async getElectronAggregateTests(filters?: any): Promise<TestResultAPIResponse<AggregateTestEntry[]>> {
    let query = 'SELECT * FROM aggregate_tests WHERE 1=1';
    const params: any[] = [];

    if (filters?.memo_reference) {
      query += ' AND memo_reference LIKE ?';
      params.push(`%${filters.memo_reference}%`);
    }
    if (filters?.plant_id) {
      query += ' AND plant_id = ?';
      params.push(filters.plant_id);
    }
    if (filters?.start_date) {
      query += ' AND test_date >= ?';
      params.push(filters.start_date);
    }
    if (filters?.end_date) {
      query += ' AND test_date <= ?';
      params.push(filters.end_date);
    }
    if (filters?.officer_id) {
      query += ' AND officer_id = ?';
      params.push(filters.officer_id);
    }

    query += ' ORDER BY test_date DESC';

    const result = await window.electronAPI.dbQuery(query, params);
    return { success: result.success, data: result.data || [], error: result.error };
  }

  private static async getBrowserAggregateTests(filters?: any): Promise<TestResultAPIResponse<AggregateTestEntry[]>> {
    // Fallback to localStorage or REST API call
    const storedData = localStorage.getItem('aggregate_tests') || '[]';
    let data = JSON.parse(storedData);

    if (filters) {
      data = data.filter((entry: AggregateTestEntry) => {
        if (filters.memo_reference && !entry.memo_reference?.toLowerCase().includes(filters.memo_reference.toLowerCase())) return false;
        if (filters.plant_id && entry.plant_id !== filters.plant_id) return false;
        if (filters.start_date && entry.test_date < filters.start_date) return false;
        if (filters.end_date && entry.test_date > filters.end_date) return false;
        if (filters.officer_id && entry.officer_id !== filters.officer_id) return false;
        return true;
      });
    }

    return { success: true, data };
  }

  static async createAggregateTest(testData: Omit<AggregateTestEntry, 'id' | 'created_at' | 'updated_at'>): Promise<TestResultAPIResponse<AggregateTestEntry>> {
    try {
      const newTest: AggregateTestEntry = {
        ...testData,
        id: `agg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      if (window.electronAPI) {
        const fields = Object.keys(newTest).join(', ');
        const placeholders = Object.keys(newTest).map(() => '?').join(', ');
        const values = Object.values(newTest);
        
        const result = await window.electronAPI.dbRun(
          `INSERT INTO aggregate_tests (${fields}) VALUES (${placeholders})`,
          values
        );
        
        if (result.success) {
          return { success: true, data: newTest };
        } else {
          return { success: false, error: result.error };
        }
      } else {
        const storedData = localStorage.getItem('aggregate_tests') || '[]';
        const data = JSON.parse(storedData);
        data.push(newTest);
        localStorage.setItem('aggregate_tests', JSON.stringify(data));
        return { success: true, data: newTest };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async updateAggregateTest(id: string, updates: Partial<AggregateTestEntry>): Promise<TestResultAPIResponse<void>> {
    try {
      const updatedData = { ...updates, updated_at: new Date().toISOString() };

      if (window.electronAPI) {
        const fields = Object.keys(updatedData).map(key => `${key} = ?`).join(', ');
        const values = [...Object.values(updatedData), id];
        
        const result = await window.electronAPI.dbRun(
          `UPDATE aggregate_tests SET ${fields} WHERE id = ?`,
          values
        );
        
        return { success: result.success, error: result.error };
      } else {
        const storedData = localStorage.getItem('aggregate_tests') || '[]';
        const data = JSON.parse(storedData);
        const index = data.findIndex((entry: AggregateTestEntry) => entry.id === id);
        
        if (index !== -1) {
          data[index] = { ...data[index], ...updatedData };
          localStorage.setItem('aggregate_tests', JSON.stringify(data));
          return { success: true };
        } else {
          return { success: false, error: 'Test entry not found' };
        }
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async deleteAggregateTest(id: string): Promise<TestResultAPIResponse<void>> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun('DELETE FROM aggregate_tests WHERE id = ?', [id]);
        return { success: result.success, error: result.error };
      } else {
        const storedData = localStorage.getItem('aggregate_tests') || '[]';
        const data = JSON.parse(storedData);
        const filteredData = data.filter((entry: AggregateTestEntry) => entry.id !== id);
        localStorage.setItem('aggregate_tests', JSON.stringify(filteredData));
        return { success: true };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // CONCRETE TEST RESULTS API
  static async getConcreteTests(filters?: {
    memo_reference?: string;
    product_type?: string;
    start_date?: string;
    end_date?: string;
    status?: string;
  }): Promise<TestResultAPIResponse<ConcreteTestResult[]>> {
    try {
      if (window.electronAPI) {
        return await this.getElectronConcreteTests(filters);
      } else {
        return await this.getBrowserConcreteTests(filters);
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  private static async getElectronConcreteTests(filters?: any): Promise<TestResultAPIResponse<ConcreteTestResult[]>> {
    let query = 'SELECT * FROM concrete_tests WHERE 1=1';
    const params: any[] = [];

    if (filters?.memo_reference) {
      query += ' AND memo_reference LIKE ?';
      params.push(`%${filters.memo_reference}%`);
    }
    if (filters?.product_type) {
      query += ' AND product_type = ?';
      params.push(filters.product_type);
    }
    if (filters?.start_date) {
      query += ' AND test_date >= ?';
      params.push(filters.start_date);
    }
    if (filters?.end_date) {
      query += ' AND test_date <= ?';
      params.push(filters.end_date);
    }
    if (filters?.status) {
      query += ' AND status = ?';
      params.push(filters.status);
    }

    query += ' ORDER BY test_date DESC LIMIT 100';

    const result = await window.electronAPI.dbQuery(query, params);
    return { success: result.success, data: result.data || [], error: result.error };
  }

  private static async getBrowserConcreteTests(filters?: any): Promise<TestResultAPIResponse<ConcreteTestResult[]>> {
    const storedData = localStorage.getItem('concrete_tests') || '[]';
    let data = JSON.parse(storedData);

    if (filters) {
      data = data.filter((entry: ConcreteTestResult) => {
        if (filters.memo_reference && !entry.memo_reference?.toLowerCase().includes(filters.memo_reference.toLowerCase())) return false;
        if (filters.product_type && entry.product_type !== filters.product_type) return false;
        if (filters.start_date && entry.test_date < filters.start_date) return false;
        if (filters.end_date && entry.test_date > filters.end_date) return false;
        if (filters.status && entry.status !== filters.status) return false;
        return true;
      });
    }

    return { success: true, data: data.slice(0, 100) };
  }

  static async createConcreteTest(testData: Omit<ConcreteTestResult, 'id' | 'created_at' | 'updated_at'>): Promise<TestResultAPIResponse<ConcreteTestResult>> {
    try {
      const newTest: ConcreteTestResult = {
        ...testData,
        id: `concrete_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        status: testData.strength_mpa >= 20 ? 'pass' : 'fail', // Auto-calculate status
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      if (window.electronAPI) {
        const fields = Object.keys(newTest).join(', ');
        const placeholders = Object.keys(newTest).map(() => '?').join(', ');
        const values = Object.values(newTest);
        
        const result = await window.electronAPI.dbRun(
          `INSERT INTO concrete_tests (${fields}) VALUES (${placeholders})`,
          values
        );
        
        if (result.success) {
          return { success: true, data: newTest };
        } else {
          return { success: false, error: result.error };
        }
      } else {
        const storedData = localStorage.getItem('concrete_tests') || '[]';
        const data = JSON.parse(storedData);
        data.push(newTest);
        localStorage.setItem('concrete_tests', JSON.stringify(data));
        return { success: true, data: newTest };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async updateConcreteTest(id: string, updates: Partial<ConcreteTestResult>): Promise<TestResultAPIResponse<void>> {
    try {
      const updatedData = { ...updates, updated_at: new Date().toISOString() };

      if (window.electronAPI) {
        const fields = Object.keys(updatedData).map(key => `${key} = ?`).join(', ');
        const values = [...Object.values(updatedData), id];
        
        const result = await window.electronAPI.dbRun(
          `UPDATE concrete_tests SET ${fields} WHERE id = ?`,
          values
        );
        
        return { success: result.success, error: result.error };
      } else {
        const storedData = localStorage.getItem('concrete_tests') || '[]';
        const data = JSON.parse(storedData);
        const index = data.findIndex((entry: ConcreteTestResult) => entry.id === id);
        
        if (index !== -1) {
          data[index] = { ...data[index], ...updatedData };
          localStorage.setItem('concrete_tests', JSON.stringify(data));
          return { success: true };
        } else {
          return { success: false, error: 'Test entry not found' };
        }
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async deleteConcreteTest(id: string): Promise<TestResultAPIResponse<void>> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun('DELETE FROM concrete_tests WHERE id = ?', [id]);
        return { success: result.success, error: result.error };
      } else {
        const storedData = localStorage.getItem('concrete_tests') || '[]';
        const data = JSON.parse(storedData);
        const filteredData = data.filter((entry: ConcreteTestResult) => entry.id !== id);
        localStorage.setItem('concrete_tests', JSON.stringify(filteredData));
        return { success: true };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // TABLET CONNECTIVITY API
  static async getTabletConnections(): Promise<TestResultAPIResponse<TabletConnection[]>> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery('SELECT * FROM tablet_connections ORDER BY last_ping DESC');
        return { success: result.success, data: result.data || [], error: result.error };
      } else {
        const storedData = localStorage.getItem('tablet_connections') || '[]';
        return { success: true, data: JSON.parse(storedData) };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async registerTabletDevice(deviceInfo: Omit<TabletConnection, 'is_connected' | 'last_ping' | 'status'>): Promise<TestResultAPIResponse<TabletConnection>> {
    try {
      const newDevice: TabletConnection = {
        ...deviceInfo,
        is_connected: true,
        last_ping: new Date(),
        status: 'online'
      };

      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO tablet_connections 
           (device_id, device_name, operator_name, location, is_connected, last_ping, status, updated_at) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newDevice.device_id,
            newDevice.device_name,
            newDevice.operator_name,
            newDevice.location,
            1,
            newDevice.last_ping.toISOString(),
            newDevice.status,
            new Date().toISOString()
          ]
        );
        
        if (result.success) {
          return { success: true, data: newDevice };
        } else {
          return { success: false, error: result.error };
        }
      } else {
        const storedData = localStorage.getItem('tablet_connections') || '[]';
        const data = JSON.parse(storedData);
        const existingIndex = data.findIndex((d: TabletConnection) => d.device_id === newDevice.device_id);
        
        if (existingIndex !== -1) {
          data[existingIndex] = newDevice;
        } else {
          data.push(newDevice);
        }
        
        localStorage.setItem('tablet_connections', JSON.stringify(data));
        return { success: true, data: newDevice };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  static async updateTabletStatus(deviceId: string, status: 'online' | 'offline' | 'disconnected'): Promise<TestResultAPIResponse<void>> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbRun(
          'UPDATE tablet_connections SET status = ?, last_ping = ?, updated_at = ? WHERE device_id = ?',
          [status, new Date().toISOString(), new Date().toISOString(), deviceId]
        );
        
        return { success: result.success, error: result.error };
      } else {
        const storedData = localStorage.getItem('tablet_connections') || '[]';
        const data = JSON.parse(storedData);
        const device = data.find((d: TabletConnection) => d.device_id === deviceId);
        
        if (device) {
          device.status = status;
          device.last_ping = new Date();
          localStorage.setItem('tablet_connections', JSON.stringify(data));
          return { success: true };
        } else {
          return { success: false, error: 'Device not found' };
        }
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // MEMO INTEGRATION
  static async linkTestToMemo(testId: string, memoId: string, testType: 'aggregate' | 'concrete'): Promise<TestResultAPIResponse<void>> {
    try {
      if (window.electronAPI) {
        // Update memo status when test is linked
        await window.electronAPI.dbRun(
          `UPDATE memos SET status = 'in_progress', updated_at = ? WHERE id = ?`,
          [new Date().toISOString(), memoId]
        );
        
        // Link test to memo
        const table = testType === 'aggregate' ? 'aggregate_tests' : 'concrete_tests';
        const result = await window.electronAPI.dbRun(
          `UPDATE ${table} SET memo_reference = ?, updated_at = ? WHERE id = ?`,
          [memoId, new Date().toISOString(), testId]
        );
        
        return { success: result.success, error: result.error };
      } else {
        // Handle in localStorage
        const testKey = testType === 'aggregate' ? 'aggregate_tests' : 'concrete_tests';
        const testData = JSON.parse(localStorage.getItem(testKey) || '[]');
        const testIndex = testData.findIndex((t: any) => t.id === testId);
        
        if (testIndex !== -1) {
          testData[testIndex].memo_reference = memoId;
          testData[testIndex].updated_at = new Date().toISOString();
          localStorage.setItem(testKey, JSON.stringify(testData));
          
          // Update memo status
          const memoData = JSON.parse(localStorage.getItem('memos') || '[]');
          const memoIndex = memoData.findIndex((m: any) => m.id === memoId);
          if (memoIndex !== -1) {
            memoData[memoIndex].status = 'in_progress';
            memoData[memoIndex].updated_at = new Date().toISOString();
            localStorage.setItem('memos', JSON.stringify(memoData));
          }
          
          return { success: true };
        } else {
          return { success: false, error: 'Test not found' };
        }
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // MIGRATION UTILITIES
  static async migrateOldTableNames(): Promise<TestResultAPIResponse<{ migratedTables: string[] }>> {
    if (!window.electronAPI) {
      return { success: false, error: 'Migration only available in Electron mode' };
    }

    try {
      const migratedTables: string[] = [];
      
      // Find old table names ending with _aggregates_tests
      const tablesResult = await window.electronAPI.dbQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%_aggregates_tests'"
      );
      
      if (tablesResult.success && tablesResult.data?.length) {
        for (const table of tablesResult.data) {
          const oldTableName = table.name;
          
          // Copy data to new standardized table
          await window.electronAPI.dbRun(`
            INSERT OR IGNORE INTO aggregate_tests 
            SELECT * FROM ${oldTableName}
          `);
          
          // Drop old table after successful migration
          await window.electronAPI.dbRun(`DROP TABLE IF EXISTS ${oldTableName}`);
          migratedTables.push(oldTableName);
        }
      }

      return { 
        success: true, 
        data: { migratedTables },
        message: `Migrated ${migratedTables.length} tables to new naming convention`
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}