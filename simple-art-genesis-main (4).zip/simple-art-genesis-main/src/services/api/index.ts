// Main API service - supports both browser and Electron
import { BrowserDataService } from '../storage/browserStorage';
import { ElectronDataService } from '../storage/electronDataService';
// import { MockDataService } from './mockService'; // Keep for reference
import type { IDataService } from './interface';

// Initialize the data service based on environment
const initializeDataService = (): IDataService => {
  // Check if running in Electron
  if (typeof window !== 'undefined' && (window as any).electronAPI) {
    return new ElectronDataService();
  }
  
  // Fall back to browser-based service
  return new BrowserDataService();
};

// Current implementation - auto-detect Electron or browser
const currentDataService: IDataService = initializeDataService();

// Export the service
export const dataService = currentDataService;

// Export types for consumers
export type { IDataService } from './interface';
export type {
  Memo,
  TestRequest,
  UserProfile,
  UserRole,
  AnalyticsData,
  ApiResponse,
  PaginatedResponse,
  QueryOptions
} from './types';

// To switch to a local backend in the future, you would:
// 1. Create a new LocalDataService that implements IDataService
// 2. Change the currentDataService assignment above
// 3. All components using dataService will automatically use the new backend

/*
Example for future local backend:

import { LocalDataService } from './localService';

const currentDataService: IDataService = new LocalDataService();
*/