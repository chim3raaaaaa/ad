# Data Service Architecture

This directory contains the data access layer for the Laboratory Management System. It's designed to be easily swappable between different backend implementations (Supabase, local database, external APIs, etc.).

## Architecture Overview

```
src/services/api/
├── types.ts          # Core data types and interfaces
├── interface.ts      # IDataService interface definition
├── mockService.ts    # Mock implementation for development
├── supabaseService.ts # Supabase implementation (create when database is ready)
├── index.ts          # Main export - easy backend switching
└── README.md         # This file
```

## Key Files

### `types.ts`
Defines all core data types used throughout the application:
- `Memo` - Laboratory memo with production data
- `TestRequest` - Test request management
- `UserProfile` - User information beyond authentication
- `UserRole` - Role-based access control
- `AnalyticsData` - Analytics and reporting data
- Response and pagination types

### `interface.ts`
Defines the `IDataService` interface that all backend implementations must follow. This ensures consistent API across different backends.

### `index.ts`
The main export file where you can easily switch between implementations:

```typescript
// Current: Mock service for development
const currentDataService: IDataService = new MockDataService();

// Future: Switch to Supabase when database is ready
// const currentDataService: IDataService = new SupabaseDataService();

// Future: Switch to local backend for Electron
// const currentDataService: IDataService = new LocalDataService();
```

## Usage in Components

### Direct Usage
```typescript
import { dataService } from '@/services/api';

// In a component
const memos = await dataService.getMemos({ page: 1, limit: 10 });
```

### Using Custom Hooks
```typescript
import { useMemos, useAnalytics } from '@/hooks/useDataService';

function MyComponent() {
  const { data, loading, error, createMemo } = useMemos();
  const { data: analytics } = useAnalytics();
  
  // Use the data...
}
```

## Backend Implementations

### Current: Mock Service
- Uses in-memory data for development
- Simulates real API behavior
- No external dependencies
- Perfect for UI development and testing

### Future: Supabase Service
- Will connect to Supabase database
- Handles authentication integration
- Real-time subscriptions
- Cloud-hosted solution

### Future: Local Service (for Electron)
- SQLite database
- File system operations
- Offline capabilities
- Desktop-specific features

## Switching Backends

To switch from mock to Supabase:

1. **Set up Supabase database** with proper tables and RLS policies
2. **Uncomment SupabaseDataService** import in `index.ts`
3. **Change the assignment**:
   ```typescript
   // Change this line:
   const currentDataService: IDataService = new MockDataService();
   
   // To this:
   const currentDataService: IDataService = new SupabaseDataService();
   ```
4. **No other code changes needed** - all components will automatically use the new backend

To add a local backend for Electron:

1. **Create `localService.ts`** that implements `IDataService`
2. **Add to imports** in `index.ts`
3. **Switch the assignment** when building for Electron

## Data Flow

```
React Components
       ↓
Custom Hooks (useDataService.ts)
       ↓
Data Service Interface (index.ts)
       ↓
Implementation (MockService / SupabaseService / LocalService)
       ↓
Backend (Mock Data / Supabase / SQLite)
```

## Benefits of This Architecture

1. **Easy Backend Switching** - Change one line to switch backends
2. **Type Safety** - All data structures are typed
3. **Consistent API** - Same interface regardless of backend
4. **Testable** - Easy to mock for unit tests
5. **Scalable** - Add new backends without changing existing code
6. **Development Friendly** - Mock service allows UI development without backend

## Migration Path

1. **Phase 1**: Development with Mock Service ✅
2. **Phase 2**: Web deployment with Supabase (next step)
3. **Phase 3**: Desktop app with Local Service (future)
4. **Phase 4**: Hybrid deployments (cloud + local)

This architecture ensures smooth transitions between deployment targets while maintaining code consistency and developer productivity.