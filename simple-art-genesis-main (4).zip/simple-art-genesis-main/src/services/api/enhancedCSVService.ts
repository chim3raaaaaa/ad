import { toast } from '@/hooks/use-toast';
import { enhancedReferenceDataService } from '@/services/database/enhancedReferenceDataService';

export interface CSVUploadResult {
  success: boolean;
  rowsImported: number;
  tableName: string;
  errors: string[];
  timestamp: string;
}

export interface CSVExportResult {
  success: boolean;
  filename: string;
  rowCount: number;
  error?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  tablesChecked: number;
  timestamp: string;
}

// Enhanced CSV mapping for our reference data tables
const REFERENCE_TABLE_MAPPING: Record<string, {
  serviceName: string;
  importMethod: string;
  requiredFields: string[];
  sampleData: any[];
}> = {
  'product_categories.csv': {
    serviceName: 'productCategories',
    importMethod: 'importProductCategories',
    requiredFields: ['category_id', 'name', 'test_module'],
    sampleData: [
      { category_id: 'SAMPLE_CAT', name: 'Sample Category', description: 'Example category', test_module: 'blocks' }
    ]
  },
  'products.csv': {
    serviceName: 'products',
    importMethod: 'importProducts',
    requiredFields: ['product_id', 'name', 'category_id', 'product_code', 'test_module'],
    sampleData: [
      { product_id: 'SAMPLE_PROD', name: 'Sample Product', category_id: 'SAMPLE_CAT', product_code: 'SP001', test_module: 'blocks' }
    ]
  },
  'grades.csv': {
    serviceName: 'grades',
    importMethod: 'addGrade',
    requiredFields: ['name'],
    sampleData: [
      { name: 'M25', mpa_value: 25, description: '25 MPa strength grade' }
    ]
  },
  'plants.csv': {
    serviceName: 'plants',
    importMethod: 'importPlants',
    requiredFields: ['plant_id', 'name'],
    sampleData: [
      { plant_id: 'SAMPLE_PLANT', name: 'Sample Plant', location: 'Sample Location', code: 'SP' }
    ]
  },
  'officers.csv': {
    serviceName: 'officers',
    importMethod: 'importOfficers',
    requiredFields: ['officer_id', 'name'],
    sampleData: [
      { officer_id: 'SAMPLE_OFF', name: 'Sample Officer', role: 'Lab Technician', department: 'QC' }
    ]
  },
  'machines.csv': {
    serviceName: 'machines',
    importMethod: 'importMachines',
    requiredFields: ['machine_id', 'name'],
    sampleData: [
      { machine_id: 'SAMPLE_MACH', name: 'Sample Machine', type: 'Testing Equipment', location: 'Lab Floor 1' }
    ]
  },
  'aggregates.csv': {
    serviceName: 'aggregates',
    importMethod: 'importAggregates',
    requiredFields: ['aggregate_id', 'name', 'size_range'],
    sampleData: [
      { aggregate_id: 'SAMPLE_AGG', name: 'Sample Aggregate', size_range: '0-4mm', type: 'Fine', density: 2.65 }
    ]
  },
  'admixtures.csv': {
    serviceName: 'admixtures',
    importMethod: 'importAdmixtures',
    requiredFields: ['admixture_id', 'name'],
    sampleData: [
      { admixture_id: 'SAMPLE_ADM', name: 'Sample Admixture', type: 'Plasticizer', supplier: 'Sample Supplier' }
    ]
  },
  'conformity_options.csv': {
    serviceName: 'conformityOptions',
    importMethod: 'addConformityOption',
    requiredFields: ['symbol', 'name'],
    sampleData: [
      { symbol: '✓', name: 'Conform', description: 'Test result conforms to specification' }
    ]
  },
  'cement_types.csv': {
    serviceName: 'cementTypes',
    importMethod: 'addCementType',
    requiredFields: ['name'],
    sampleData: [
      { name: 'OPC 53', type: 'OPC', grade: '53', supplier: 'Sample Supplier' }
    ]
  },
  'vibrator_status.csv': {
    serviceName: 'vibratorStatus',
    importMethod: 'addVibratorStatus',
    requiredFields: ['name', 'code'],
    sampleData: [
      { name: 'Vibrated', code: 'VIB', description: 'Sample was vibrated during preparation' }
    ]
  },
  'test_types.csv': {
    serviceName: 'testTypes',
    importMethod: 'addTestType',
    requiredFields: ['name'],
    sampleData: [
      { name: 'Standard Test', category: 'blocks', standard: 'BS 812', equipment_required: 'Standard Testing Kit' }
    ]
  },
  'climatic_conditions.csv': {
    serviceName: 'climaticConditions',
    importMethod: 'addClimaticCondition',
    requiredFields: ['name'],
    sampleData: [
      { name: 'Sunny', description: 'Clear sunny conditions' }
    ]
  },
  'sampling_places.csv': {
    serviceName: 'samplingPlaces',
    importMethod: 'addSamplingPlace',
    requiredFields: ['name'],
    sampleData: [
      { name: 'Under Conveyor', location: 'Production Line', description: 'Sampling point under conveyor belt' }
    ]
  },
  'sampled_by.csv': {
    serviceName: 'sampledBy',
    importMethod: 'addSampledBy',
    requiredFields: ['name'],
    sampleData: [
      { name: 'Lab Technician', role: 'Technician', certification: 'Basic Sampling' }
    ]
  },
  'free_water.csv': {
    serviceName: 'freeWater',
    importMethod: 'addFreeWater',
    requiredFields: ['name', 'source'],
    sampleData: [
      { name: 'Tap Water', source: 'Municipal Supply', quality_grade: 'Potable', ph_value: 7.2 }
    ]
  },
  'mould_references.csv': {
    serviceName: 'mouldReferences',
    importMethod: 'addMouldReference',
    requiredFields: ['name', 'code'],
    sampleData: [
      { name: 'Standard Cube Mould', code: 'SCM-100', dimensions: '100x100x100mm', position_numbers: '1,2,3,4' }
    ]
  }
};

class EnhancedCSVService {
  
  // Parse CSV content into array of objects
  private parseCSV(content: string): any[] {
    const lines = content.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = this.parseCSVLine(lines[0]);
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = this.parseCSVLine(lines[i]);
      if (values.length === headers.length) {
        const row: any = {};
        headers.forEach((header, index) => {
          row[header.trim()] = values[index].trim();
        });
        data.push(row);
      }
    }

    return data;
  }

  // Parse a single CSV line handling quotes and commas
  private parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current);
    return result.map(item => item.replace(/^"|"$/g, ''));
  }

  // Upload CSV data to appropriate reference table
  async uploadCSV(file: File): Promise<CSVUploadResult> {
    try {
      const filename = file.name.toLowerCase();
      const tableConfig = REFERENCE_TABLE_MAPPING[filename];
      
      if (!tableConfig) {
        return {
          success: false,
          rowsImported: 0,
          tableName: filename,
          errors: [`Unsupported file: ${filename}. Supported files: ${Object.keys(REFERENCE_TABLE_MAPPING).join(', ')}`],
          timestamp: new Date().toISOString()
        };
      }

      // Read and parse CSV content
      const content = await file.text();
      const data = this.parseCSV(content);

      if (data.length === 0) {
        return {
          success: false,
          rowsImported: 0,
          tableName: tableConfig.serviceName,
          errors: ['CSV file contains no data rows'],
          timestamp: new Date().toISOString()
        };
      }

      // Validate required fields
      const errors: string[] = [];
      const firstRow = data[0];
      const missingFields = tableConfig.requiredFields.filter(field => !firstRow.hasOwnProperty(field));
      
      if (missingFields.length > 0) {
        errors.push(`Missing required columns: ${missingFields.join(', ')}`);
      }

      if (errors.length > 0) {
        return {
          success: false,
          rowsImported: 0,
          tableName: tableConfig.serviceName,
          errors,
          timestamp: new Date().toISOString()
        };
      }

      // Import data using the appropriate service method
      let rowsImported = 0;
      const importErrors: string[] = [];

      if (tableConfig.importMethod.startsWith('import')) {
        // Use bulk import methods
        try {
          await (enhancedReferenceDataService as any)[tableConfig.importMethod](data);
          rowsImported = data.length;
        } catch (error) {
          importErrors.push(`Bulk import failed: ${error}`);
        }
      } else {
        // Use individual add methods
        for (let i = 0; i < data.length; i++) {
          try {
            await (enhancedReferenceDataService as any)[tableConfig.importMethod](data[i]);
            rowsImported++;
          } catch (error) {
            importErrors.push(`Row ${i + 2}: ${error}`);
          }
        }
      }

      return {
        success: rowsImported > 0,
        rowsImported,
        tableName: tableConfig.serviceName,
        errors: importErrors,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error('CSV upload failed:', error);
      return {
        success: false,
        rowsImported: 0,
        tableName: file.name,
        errors: [`Upload failed: ${error}`],
        timestamp: new Date().toISOString()
      };
    }
  }

  // Export all reference data to CSV files
  async exportAllData(): Promise<CSVExportResult[]> {
    const results: CSVExportResult[] = [];
    
    try {
      // Initialize service tables
      await enhancedReferenceDataService.initializeAllReferenceTables();

      // Export each table
      for (const [filename, config] of Object.entries(REFERENCE_TABLE_MAPPING)) {
        try {
          const methodName = `get${config.serviceName.charAt(0).toUpperCase() + config.serviceName.slice(1)}`;
          const data = await (enhancedReferenceDataService as any)[methodName]();
          
          if (data && data.length > 0) {
            const csv = this.convertToCSV(data);
            this.downloadCSV(csv, filename);
            
            results.push({
              success: true,
              filename,
              rowCount: data.length
            });
          } else {
            results.push({
              success: false,
              filename,
              rowCount: 0,
              error: 'No data found'
            });
          }
        } catch (error) {
          results.push({
            success: false,
            filename,
            rowCount: 0,
            error: `Export failed: ${error}`
          });
        }
      }

      return results;
    } catch (error) {
      console.error('Export all data failed:', error);
      throw error;
    }
  }

  // Convert data array to CSV string
  private convertToCSV(data: any[]): string {
    if (data.length === 0) return '';

    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          const stringValue = value !== null && value !== undefined ? String(value) : '';
          // Escape quotes and wrap in quotes if contains comma
          return stringValue.includes(',') || stringValue.includes('"') 
            ? `"${stringValue.replace(/"/g, '""')}"` 
            : stringValue;
        }).join(',')
      )
    ].join('\n');

    return csvContent;
  }

  // Download CSV file
  private downloadCSV(csvContent: string, filename: string): void {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }

  // Generate CSV template for a specific table
  async generateTemplate(filename: string): Promise<void> {
    const config = REFERENCE_TABLE_MAPPING[filename];
    if (!config) {
      throw new Error(`Unknown template: ${filename}`);
    }

    const template = this.convertToCSV(config.sampleData);
    this.downloadCSV(template, filename);
  }

  // Validate all reference data
  async validateAllData(): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];
    let tablesChecked = 0;

    try {
      // Initialize service
      await enhancedReferenceDataService.initializeAllReferenceTables();

      // Check each reference table
      for (const [filename, config] of Object.entries(REFERENCE_TABLE_MAPPING)) {
        try {
          tablesChecked++;
          const methodName = `get${config.serviceName.charAt(0).toUpperCase() + config.serviceName.slice(1)}`;
          const data = await (enhancedReferenceDataService as any)[methodName]();
          
          if (!data || data.length === 0) {
            warnings.push(`${config.serviceName}: No data found - consider adding sample data`);
          } else {
            // Check for missing required fields in existing data
            const firstRow = data[0];
            const missingFields = config.requiredFields.filter(field => !firstRow.hasOwnProperty(field) || !firstRow[field]);
            
            if (missingFields.length > 0) {
              errors.push(`${config.serviceName}: Missing required fields in data: ${missingFields.join(', ')}`);
            }

            // Check for duplicates based on ID fields
            const idField = Object.keys(firstRow).find(key => key.includes('_id'));
            if (idField) {
              const ids = data.map((item: any) => item[idField]);
              const duplicates = ids.filter((id: any, index: number) => ids.indexOf(id) !== index);
              if (duplicates.length > 0) {
                errors.push(`${config.serviceName}: Duplicate IDs found: ${[...new Set(duplicates)].join(', ')}`);
              }
            }
          }
        } catch (error) {
          errors.push(`${config.serviceName}: Validation failed - ${error}`);
        }
      }

      return {
        isValid: errors.length === 0,
        errors,
        warnings,
        tablesChecked,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error('Data validation failed:', error);
      return {
        isValid: false,
        errors: [`Global validation failed: ${error}`],
        warnings,
        tablesChecked,
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get supported file information
  getSupportedFiles(): any[] {
    return Object.entries(REFERENCE_TABLE_MAPPING).map(([filename, config]) => ({
      filename,
      description: `${config.serviceName} reference data`,
      tableName: config.serviceName,
      requiredFields: config.requiredFields,
      sampleCount: config.sampleData.length
    }));
  }
}

export const enhancedCSVService = new EnhancedCSVService();