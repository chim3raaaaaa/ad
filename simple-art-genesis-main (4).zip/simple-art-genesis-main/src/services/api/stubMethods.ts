// Stub implementations for missing interface methods
import type { ApiResponse } from './types';

export const stubAuditMethods = {
  async createAuditLog(entry: any): Promise<ApiResponse<any>> {
    console.log('Audit log (stub):', entry);
    return { data: entry };
  },

  async getAuditLogs(filters?: any): Promise<any[]> {
    console.log('Get audit logs (stub):', filters);
    return [];
  }
};

export const stubSchemaMethods = {
  async getTables(): Promise<string[]> {
    console.log('Get tables (stub)');
    return ['memos', 'test_requests', 'user_profiles', 'user_roles'];
  },

  async getTableSchema(tableName: string): Promise<any> {
    console.log('Get table schema (stub):', tableName);
    return null;
  },

  async executeSQL(sql: string): Promise<any> {
    console.log('Execute SQL (stub):', sql);
    return {};
  },

  async createDataRelationship(relationship: any): Promise<ApiResponse<any>> {
    console.log('Create data relationship (stub):', relationship);
    return { data: relationship };
  },

  async deleteDataRelationship(id: string): Promise<ApiResponse<boolean>> {
    console.log('Delete data relationship (stub):', id);
    return { data: true };
  },

  async getDataRelationships(): Promise<any[]> {
    console.log('Get data relationships (stub)');
    return [];
  }
};

export const stubUserMethods = {
  async getUserProfile(id: string): Promise<ApiResponse<any>> {
    console.log('Get user profile (stub):', id);
    return { data: null, error: 'Not implemented' };
  }
};

export const stubValidationMethods = {
  async createValidationResult(result: any): Promise<ApiResponse<any>> {
    console.log('Create validation result (stub):', result);
    return { data: result };
  }
};