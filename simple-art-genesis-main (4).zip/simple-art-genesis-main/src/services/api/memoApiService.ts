// Backend API service for memo operations using SQLite
import { ApiClient } from '@/lib/apiClient';

export interface MemoReferenceData {
  categories: string[];
  products: Record<string, ProductInfo[]>;
  labTests: Record<string, TestInfo[]>;
  machines: Record<string, MachineInfo[]>;
  moulds: Record<string, MouldInfo[]>;
  officers: OfficerInfo[];
  labSites: string[];
}

export interface ProductInfo {
  code: string;
  name: string;
  grade: number;
  category: string;
}

export interface TestInfo {
  code: string;
  name: string;
  type: string;
}

export interface MachineInfo {
  code: string;
  name: string;
  labSite: string;
}

export interface MouldInfo {
  code: string;
  name: string;
  machineNo: string;
}

export interface OfficerInfo {
  id: string;
  name: string;
  labSite: string;
}

export interface MemoSubmissionData {
  reference: string;
  date: string;
  labSite: string;
  officerInCharge: string;
  lorry: string;
  blocksCount: number;
  typeOfTest: string;
  testPerformed: string;
  retest: string;
  postedBy: string;
  productions: ProductionSubmissionData[];
  testRemarks?: string;
  remarks?: string;
}

export interface ProductionSubmissionData {
  productionDate: string;
  testDate: string;
  ageDays: number;
  category: string;
  product: string;
  gradeMpa: string;
  machineNo: string;
  mouldRef: string;
  sampleCount: number;
  blockPosition: string;
  remarks: string;
}

class MemoApiService {
  private baseUrl = '/api/memo';

  // Generate next unique reference ID with category-specific prefix
  async generateNextReference(category?: string): Promise<string> {
    try {
      // Determine prefix based on category
      let prefix = 'RTB'; // Default for blocks
      switch (category) {
        case 'cubes':
          prefix = 'RTC';
          break;
        case 'pavers':
          prefix = 'RTP';
          break;
        case 'kerbs':
          prefix = 'RTK';
          break;
        case 'flagstones':
          prefix = 'RTF';
          break;
        case 'aggregates':
          prefix = 'RTA';
          break;
        default:
          prefix = 'RTB'; // blocks or default
      }

      if (window.electronAPI) {
        // Use Electron SQLite for reference generation
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yy = String(today.getFullYear()).slice(-2);
        
        // Get next counter from database with atomic increment
        const dateKey = `${dd}${mm}${yy}`;
        const counterResult = await window.electronAPI.dbRun(
          `INSERT INTO memo_counters (date_key, counter) 
           VALUES (?, 1) 
           ON CONFLICT(date_key) 
           DO UPDATE SET counter = counter + 1 
           RETURNING counter`,
          [dateKey]
        );

        let counter = 1;
        if (counterResult.success && counterResult.data) {
          counter = counterResult.data.counter;
        } else {
          // Fallback: query current max counter
          const maxResult = await window.electronAPI.dbQuery(
            'SELECT MAX(counter) as max_counter FROM memo_counters WHERE date_key = ?',
            [dateKey]
          );
          if (maxResult.success && maxResult.data?.[0]?.max_counter) {
            counter = maxResult.data[0].max_counter + 1;
          }
        }

        return `${prefix}${dd}${mm}${yy}${String(counter).padStart(3, '0')}`;
      } else {
        // Fallback for web environment
        const timestamp = Date.now().toString().slice(-6);
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yy = String(today.getFullYear()).slice(-2);
        return `${prefix}${dd}${mm}${yy}${timestamp}`;
      }
    } catch (error) {
      console.error('Failed to generate reference:', error);
      throw new Error('Failed to generate unique reference');
    }
  }

  // Load all reference data for dropdowns
  async loadReferenceData(): Promise<MemoReferenceData> {
    try {
      if (!window.electronAPI) {
        // Return fallback data for web environment
        return {
          categories: ['Concrete Blocks', 'Paving Blocks', 'Kerb Stones'],
          products: {
            'Concrete Blocks': [
              { code: 'CB150', name: 'Concrete Block 150mm', grade: 15, category: 'Concrete Blocks' },
              { code: 'CB200', name: 'Concrete Block 200mm', grade: 20, category: 'Concrete Blocks' }
            ],
            'Paving Blocks': [
              { code: 'PB60', name: 'Paving Block 60mm', grade: 25, category: 'Paving Blocks' }
            ]
          },
          labTests: {
            'Compressive': [
              { code: 'CS7', name: 'Compressive Strength 7 days', type: 'Compressive' },
              { code: 'CS28', name: 'Compressive Strength 28 days', type: 'Compressive' }
            ]
          },
          machines: {
            'Main Lab': [
              { code: 'M001', name: 'Machine 001', labSite: 'Main Lab' },
              { code: 'M002', name: 'Machine 002', labSite: 'Main Lab' }
            ]
          },
          moulds: {
            'M001': [
              { code: 'MR001', name: 'Mould Reference 001', machineNo: 'M001' }
            ]
          },
          officers: [
            { id: 'officer1', name: 'Lab Officer 1', labSite: 'Main Lab' },
            { id: 'officer2', name: 'Lab Officer 2', labSite: 'Main Lab' }
          ],
          labSites: ['Main Lab', 'Site Lab A', 'Site Lab B']
        };
      }

      // Create reference tables if they don't exist
      await this.initializeReferenceTables();

      // Load categories - use existing memos data to populate
      const categoriesResult = await window.electronAPI.dbQuery(
        `SELECT DISTINCT 
           json_extract(content, '$.testPerformed') as category 
         FROM memos 
         WHERE json_extract(content, '$.testPerformed') IS NOT NULL 
         ORDER BY category`
      );

      // Load products from production data in memos
      const productsResult = await window.electronAPI.dbQuery(
        `SELECT DISTINCT 
           json_extract(production.value, '$.product') as product,
           json_extract(production.value, '$.gradeMpa') as grade,
           json_extract(content, '$.testPerformed') as category
         FROM memos, json_each(json_extract(content, '$.productions')) as production
         WHERE json_extract(production.value, '$.product') IS NOT NULL 
         ORDER BY category, product`
      );

      // Load officers from current users/profiles
      const officersResult = await window.electronAPI.dbQuery(
        'SELECT DISTINCT author_id as name FROM memos WHERE author_id IS NOT NULL'
      );

      // Load lab sites from memo data
      const labSitesResult = await window.electronAPI.dbQuery(
        `SELECT DISTINCT 
           json_extract(content, '$.labSite') as lab_site 
         FROM memos 
         WHERE json_extract(content, '$.labSite') IS NOT NULL 
         ORDER BY lab_site`
      );

      // Load machines from production data
      const machinesResult = await window.electronAPI.dbQuery(
        `SELECT DISTINCT 
           json_extract(production.value, '$.machineNo') as machine_no,
           json_extract(content, '$.labSite') as lab_site
         FROM memos, json_each(json_extract(content, '$.productions')) as production
         WHERE json_extract(production.value, '$.machineNo') IS NOT NULL 
         ORDER BY lab_site, machine_no`
      );

      // Load moulds from production data
      const mouldsResult = await window.electronAPI.dbQuery(
        `SELECT DISTINCT 
           json_extract(production.value, '$.mouldRef') as mould_ref,
           json_extract(production.value, '$.machineNo') as machine_no
         FROM memos, json_each(json_extract(content, '$.productions')) as production
         WHERE json_extract(production.value, '$.mouldRef') IS NOT NULL 
         ORDER BY machine_no, mould_ref`
      );

      // Process results
      const categories = categoriesResult.success && categoriesResult.data 
        ? categoriesResult.data.map(r => r.category).filter(Boolean)
        : ['Compressive Strength', 'Density Test', 'Water Absorption'];
      
      const products: Record<string, ProductInfo[]> = {};
      if (productsResult.success && productsResult.data) {
        productsResult.data.forEach(p => {
          if (!p.product || !p.category) return;
          if (!products[p.category]) products[p.category] = [];
          products[p.category].push({
            code: p.product.substring(0, 6).toUpperCase(),
            name: p.product,
            grade: parseFloat(p.grade) || 15,
            category: p.category
          });
        });
      }

      // Add fallback products if none found
      if (Object.keys(products).length === 0) {
        products['Compressive Strength'] = [
          { code: 'CB150', name: 'Concrete Block 150mm', grade: 15, category: 'Compressive Strength' },
          { code: 'CB200', name: 'Concrete Block 200mm', grade: 20, category: 'Compressive Strength' }
        ];
      }

      const labTests: Record<string, TestInfo[]> = {
        'Standard': [
          { code: 'CS7', name: 'Compressive Strength 7 days', type: 'Standard' },
          { code: 'CS28', name: 'Compressive Strength 28 days', type: 'Standard' },
          { code: 'DT', name: 'Density Test', type: 'Standard' },
          { code: 'WA', name: 'Water Absorption', type: 'Standard' }
        ]
      };

      const machines: Record<string, MachineInfo[]> = {};
      if (machinesResult.success && machinesResult.data) {
        machinesResult.data.forEach(m => {
          if (!m.machine_no || !m.lab_site) return;
          if (!machines[m.lab_site]) machines[m.lab_site] = [];
          machines[m.lab_site].push({
            code: m.machine_no,
            name: `Machine ${m.machine_no}`,
            labSite: m.lab_site
          });
        });
      }

      // Add fallback machines if none found
      if (Object.keys(machines).length === 0) {
        machines['Main Lab'] = [
          { code: 'M001', name: 'Machine 001', labSite: 'Main Lab' },
          { code: 'M002', name: 'Machine 002', labSite: 'Main Lab' }
        ];
      }

      const moulds: Record<string, MouldInfo[]> = {};
      if (mouldsResult.success && mouldsResult.data) {
        mouldsResult.data.forEach(m => {
          if (!m.mould_ref || !m.machine_no) return;
          if (!moulds[m.machine_no]) moulds[m.machine_no] = [];
          moulds[m.machine_no].push({
            code: m.mould_ref,
            name: `Mould ${m.mould_ref}`,
            machineNo: m.machine_no
          });
        });
      }

      const officers = officersResult.success && officersResult.data 
        ? officersResult.data.map((o, index) => ({
            id: `officer${index + 1}`,
            name: o.name || 'Lab Officer',
            labSite: 'Main Lab'
          }))
        : [
            { id: 'officer1', name: 'Lab Officer 1', labSite: 'Main Lab' },
            { id: 'officer2', name: 'Lab Officer 2', labSite: 'Main Lab' }
          ];

      const labSites = labSitesResult.success && labSitesResult.data 
        ? labSitesResult.data.map(r => r.lab_site).filter(Boolean)
        : ['Main Lab', 'Site Lab A', 'Site Lab B'];

      return {
        categories,
        products,
        labTests,
        machines,
        moulds,
        officers,
        labSites
      };
    } catch (error) {
      console.error('Failed to load reference data:', error);
      // Return fallback data on error
      return {
        categories: ['Compressive Strength', 'Density Test', 'Water Absorption'],
        products: {
          'Compressive Strength': [
            { code: 'CB150', name: 'Concrete Block 150mm', grade: 15, category: 'Compressive Strength' }
          ]
        },
        labTests: {
          'Standard': [
            { code: 'CS7', name: 'Compressive Strength 7 days', type: 'Standard' }
          ]
        },
        machines: {
          'Main Lab': [
            { code: 'M001', name: 'Machine 001', labSite: 'Main Lab' }
          ]
        },
        moulds: {
          'M001': [
            { code: 'MR001', name: 'Mould Reference 001', machineNo: 'M001' }
          ]
        },
        officers: [
          { id: 'officer1', name: 'Lab Officer 1', labSite: 'Main Lab' }
        ],
        labSites: ['Main Lab']
      };
    }
  }

  // Initialize reference tables if they don't exist
  private async initializeReferenceTables(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      // Create lab_product table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS lab_product (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL,
          name TEXT NOT NULL,
          grade REAL NOT NULL,
          category TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create lab_tests table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS lab_tests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL,
          name TEXT NOT NULL,
          type TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create lab_group_code table (machines)
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS lab_group_code (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          machine_no TEXT NOT NULL,
          machine_name TEXT NOT NULL,
          lab_site TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create lab_mould table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS lab_mould (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL,
          name TEXT NOT NULL,
          machine_no TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);

      console.log('Reference tables initialized successfully');
    } catch (error) {
      console.error('Failed to initialize reference tables:', error);
    }
  }

  // Calculate age between dates
  calculateAge(productionDate: string, testDate: string): number {
    if (!productionDate || !testDate) return 0;
    
    const prod = new Date(productionDate);
    const test = new Date(testDate);
    const diffTime = test.getTime() - prod.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 0 ? diffDays : 0;
  }

  // Submit memo with validation
  async submitMemo(memoData: MemoSubmissionData): Promise<{ success: boolean; id?: string; error?: string }> {
    try {
      // Validate required fields
      if (!memoData.reference || !memoData.labSite || !memoData.officerInCharge) {
        return { success: false, error: 'Missing required fields' };
      }

      if (!window.electronAPI) {
        return { success: false, error: 'Database access not available' };
      }

      // Check reference uniqueness
      const existingResult = await window.electronAPI.dbQuery(
        'SELECT id FROM memos WHERE title = ?',
        [memoData.reference]
      );

      if (existingResult.success && existingResult.data.length > 0) {
        return { success: false, error: 'Reference number already exists' };
      }

      // Insert memo record
      const memoId = `memo-${Date.now()}`;
      const memoInsertResult = await window.electronAPI.dbRun(
        `INSERT INTO memos (id, title, content, type, priority, tags, created_at, updated_at, author_id, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          memoId,
          memoData.reference,
          JSON.stringify({
            labSite: memoData.labSite,
            officerInCharge: memoData.officerInCharge,
            lorry: memoData.lorry,
            blocksCount: memoData.blocksCount,
            typeOfTest: memoData.typeOfTest,
            testPerformed: memoData.testPerformed,
            retest: memoData.retest,
            productions: memoData.productions,
            testRemarks: memoData.testRemarks,
            remarks: memoData.remarks
          }),
          'memo',
          'medium',
          JSON.stringify([memoData.typeOfTest, memoData.labSite]),
          new Date().toISOString(),
          new Date().toISOString(),
          memoData.postedBy,
          'pending'
        ]
      );

      if (!memoInsertResult.success) {
        return { success: false, error: 'Failed to save memo' };
      }

      return { success: true, id: memoId };
    } catch (error) {
      console.error('Failed to submit memo:', error);
      return { success: false, error: 'Failed to submit memo' };
    }
  }
}

export const memoApiService = new MemoApiService();