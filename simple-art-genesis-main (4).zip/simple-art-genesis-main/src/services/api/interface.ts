// Abstract interface for data services
// This allows us to easily swap between Supabase and local backends

import type {
  Memo,
  TestRequest,
  UserProfile,
  UserRole,
  AnalyticsData,
  ApiResponse,
  PaginatedResponse,
  QueryOptions,
  Module,
  ModuleInstance,
  ModuleMarketplace,
  ValidationRule,
  ValidationResult,
  TestSchedule,
  ScheduleTemplate,
  TableRelationship,
  NavigationPath,
  DataVersion,
  ChangeRequest,
  ApprovalWorkflow
} from './types';

export interface IDataService {
  // Memo operations
  getMemos(options?: QueryOptions): Promise<PaginatedResponse<Memo>>;
  getMemoById(id: string): Promise<ApiResponse<Memo>>;
  createMemo(memo: Omit<Memo, 'id' | 'created_at'>): Promise<ApiResponse<Memo>>;
  updateMemo(id: string, memo: Partial<Memo>): Promise<ApiResponse<Memo>>;
  deleteMemo(id: string): Promise<ApiResponse<boolean>>;

  // Test Request operations
  getTestRequests(options?: QueryOptions): Promise<PaginatedResponse<TestRequest>>;
  getTestRequestById(id: string): Promise<ApiResponse<TestRequest>>;
  createTestRequest(testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestRequest>>;
  updateTestRequest(id: string, testRequest: Partial<TestRequest>): Promise<ApiResponse<TestRequest>>;
  deleteTestRequest(id: string): Promise<ApiResponse<boolean>>;

  // User Profile operations
  getUserProfiles(options?: QueryOptions): Promise<PaginatedResponse<UserProfile>>;
  getUserProfileById(id: string): Promise<ApiResponse<UserProfile>>;
  createUserProfile(profile: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserProfile>>;
  updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<ApiResponse<UserProfile>>;
  deleteUserProfile(id: string): Promise<ApiResponse<boolean>>;

  // User Role operations
  getUserRoles(): Promise<ApiResponse<UserRole[]>>;
  getUserRoleById(id: string): Promise<ApiResponse<UserRole>>;
  createUserRole(role: Omit<UserRole, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserRole>>;
  updateUserRole(id: string, role: Partial<UserRole>): Promise<ApiResponse<UserRole>>;
  deleteUserRole(id: string): Promise<ApiResponse<boolean>>;

  // Analytics operations
  getAnalyticsData(): Promise<ApiResponse<AnalyticsData>>;
  getMonthlyTestData(): Promise<ApiResponse<any[]>>;
  getTestTypeDistribution(): Promise<ApiResponse<any[]>>;

  // Authentication operations (if needed beyond Supabase auth)
  getCurrentUser(): Promise<ApiResponse<UserProfile | null>>;
  
  // Module System operations
  getModules(options?: QueryOptions): Promise<PaginatedResponse<Module>>;
  getModuleById(id: string): Promise<ApiResponse<Module>>;
  installModule(moduleData: any): Promise<ApiResponse<Module>>;
  uninstallModule(id: string): Promise<ApiResponse<boolean>>;
  enableModule(id: string): Promise<ApiResponse<boolean>>;
  disableModule(id: string): Promise<ApiResponse<boolean>>;
  updateModule(id: string, updates: Partial<Module>): Promise<ApiResponse<Module>>;
  
  // Module Instance operations
  getModuleInstances(moduleId?: string): Promise<ApiResponse<ModuleInstance[]>>;
  createModuleInstance(instance: Omit<ModuleInstance, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ModuleInstance>>;
  updateModuleInstance(id: string, updates: Partial<ModuleInstance>): Promise<ApiResponse<ModuleInstance>>;
  deleteModuleInstance(id: string): Promise<ApiResponse<boolean>>;
  
  // Module Marketplace operations
  getMarketplaceModules(options?: QueryOptions): Promise<PaginatedResponse<ModuleMarketplace>>;
  downloadModule(marketplaceId: string): Promise<ApiResponse<any>>;
  
  // Module Import/Export
  exportModule(id: string): Promise<ApiResponse<Blob>>;
  importModule(file: File): Promise<ApiResponse<Module>>;
  
  // Phase 6: Advanced Data Features
  
  // Validation Rules Engine
  getValidationRules(options?: QueryOptions): Promise<PaginatedResponse<ValidationRule>>;
  getValidationRuleById(id: string): Promise<ApiResponse<ValidationRule>>;
  createValidationRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ValidationRule>>;
  updateValidationRule(id: string, rule: Partial<ValidationRule>): Promise<ApiResponse<ValidationRule>>;
  deleteValidationRule(id: string): Promise<ApiResponse<boolean>>;
  validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ApiResponse<ValidationResult[]>>;
  getValidationResults(options?: QueryOptions): Promise<PaginatedResponse<ValidationResult>>;
  
  // Smart Date Calculator
  getTestSchedules(options?: QueryOptions): Promise<PaginatedResponse<TestSchedule>>;
  createTestSchedule(schedule: Omit<TestSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestSchedule>>;
  generateSchedulesFromTemplate(templateId: string, sampleIds: string[]): Promise<ApiResponse<TestSchedule[]>>;
  getScheduleTemplates(): Promise<ApiResponse<ScheduleTemplate[]>>;
  createScheduleTemplate(template: Omit<ScheduleTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ScheduleTemplate>>;
  updateScheduleTemplate(id: string, template: Partial<ScheduleTemplate>): Promise<ApiResponse<ScheduleTemplate>>;
  
  // Linked Table Views
  getTableRelationships(tableName?: string): Promise<ApiResponse<TableRelationship[]>>;
  getRelatedRecords(tableName: string, recordId: string, relationship: string): Promise<ApiResponse<any[]>>;
  getNavigationPath(tableName: string, recordId: string): Promise<ApiResponse<NavigationPath[]>>;
  
  // Version Control System
  getDataVersions(tableName: string, recordId: string): Promise<ApiResponse<DataVersion[]>>;
  createDataVersion(version: Omit<DataVersion, 'id' | 'created_at'>): Promise<ApiResponse<DataVersion>>;
  compareVersions(versionId1: string, versionId2: string): Promise<ApiResponse<any>>;
  rollbackToVersion(versionId: string): Promise<ApiResponse<boolean>>;
  getChangeRequests(options?: QueryOptions): Promise<PaginatedResponse<ChangeRequest>>;
  createChangeRequest(request: Omit<ChangeRequest, 'id' | 'requested_at'>): Promise<ApiResponse<ChangeRequest>>;
  approveChangeRequest(requestId: string, comments?: string): Promise<ApiResponse<ChangeRequest>>;
  rejectChangeRequest(requestId: string, comments: string): Promise<ApiResponse<ChangeRequest>>;
  getApprovalWorkflows(): Promise<ApiResponse<ApprovalWorkflow[]>>;
  
  // File operations (for future local backend)
  uploadFile?(file: File, path: string): Promise<ApiResponse<string>>;
  downloadFile?(path: string): Promise<ApiResponse<Blob>>;
  deleteFile?(path: string): Promise<ApiResponse<boolean>>;
  
  // Reference Dataset operations
  uploadReferenceDataset(tableName: string, csvData: any[], replaceExisting?: boolean): Promise<{ success: boolean; rowsInserted: number; error?: string }>;
  getReferenceData(tableName: string, activeOnly?: boolean): Promise<any[]>;
  getFilteredSamplingPlaces(productType: string): Promise<any[]>;
  
  // Audit Trail operations
  createAuditLog(entry: any): Promise<ApiResponse<any>>;
  getAuditLogs(filters?: any): Promise<any[]>;
  
  // Schema operations
  getTables(): Promise<string[]>;
  getTableSchema(tableName: string): Promise<any>;
  executeSQL(sql: string): Promise<any>;
  createDataRelationship(relationship: any): Promise<ApiResponse<any>>;
  deleteDataRelationship(id: string): Promise<ApiResponse<boolean>>;
  getDataRelationships(): Promise<any[]>;
  
  // Extended user operations
  getUserProfile(id: string): Promise<ApiResponse<UserProfile>>;
  
  // Validation result operations
  createValidationResult(result: any): Promise<ApiResponse<any>>;
}