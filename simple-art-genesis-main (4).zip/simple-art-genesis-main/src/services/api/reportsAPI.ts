// Cross-platform Reports API Service

export interface ReportTemplate {
  id: string;
  name: string;
  description?: string;
  product_type: string;
  layout_json: string;
  uploaded_by: string;
  uploaded_at: string;
  file_path?: string;
  template_type: 'canvas' | 'docx' | 'xlsx' | 'pdf';
  version: number;
  is_active: boolean;
  shared_with?: string[];
  owner_id?: string;
}

export interface ReportCategory {
  id: string;
  name: string;
  description: string;
  created_by: string;
  is_active: boolean;
}

export interface ProductDefinition {
  id: string;
  name: string;
  category_id: string;
  field_definitions: FieldDefinition[];
  created_by: string;
  is_active: boolean;
}

export interface FieldDefinition {
  id: string;
  name: string;
  token: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea' | 'boolean';
  required: boolean;
  options?: string[];
  validation?: any;
}

export interface AnalyticsChart {
  id: string;
  chart_type: string;
  name: string;
  description: string;
  data_source: string;
  config: any;
  created_by: string;
  is_public: boolean;
}

export interface GeneratedReport {
  id: string;
  memo_id: string;
  template_id: string;
  generated_by: string;
  generated_at: string;
  file_path: string;
  parameters: any;
  status: 'generating' | 'completed' | 'failed';
}

export class ReportsAPI {
  private static isElectron = typeof window !== 'undefined' && window.electronAPI;

  // Initialize database tables
  static async initializeSchema(): Promise<boolean> {
    if (this.isElectron) {
      return this.initializeElectronSchema();
    } else {
      return this.initializeSupabaseSchema();
    }
  }

  private static async initializeElectronSchema(): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const queries = [
        // Report categories
        `CREATE TABLE IF NOT EXISTS report_categories (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          created_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_active BOOLEAN DEFAULT 1
        )`,

        // Product definitions
        `CREATE TABLE IF NOT EXISTS product_definitions (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          category_id TEXT NOT NULL,
          field_definitions TEXT NOT NULL,
          created_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_active BOOLEAN DEFAULT 1,
          FOREIGN KEY (category_id) REFERENCES report_categories (id)
        )`,

        // Report templates (enhanced)
        `CREATE TABLE IF NOT EXISTS report_templates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          product_type TEXT NOT NULL,
          layout_json TEXT NOT NULL,
          uploaded_by TEXT NOT NULL,
          uploaded_at TEXT NOT NULL,
          file_path TEXT,
          template_type TEXT DEFAULT 'canvas',
          version INTEGER DEFAULT 1,
          is_active BOOLEAN DEFAULT 1,
          shared_with TEXT,
          owner_id TEXT
        )`,

        // Analytics charts
        `CREATE TABLE IF NOT EXISTS analytics_charts (
          id TEXT PRIMARY KEY,
          chart_type TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          data_source TEXT NOT NULL,
          config TEXT NOT NULL,
          created_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_public BOOLEAN DEFAULT 1
        )`,

        // Generated reports
        `CREATE TABLE IF NOT EXISTS generated_reports (
          id TEXT PRIMARY KEY,
          memo_id TEXT,
          template_id TEXT NOT NULL,
          generated_by TEXT NOT NULL,
          generated_at TEXT NOT NULL,
          file_path TEXT NOT NULL,
          parameters TEXT,
          status TEXT DEFAULT 'completed',
          FOREIGN KEY (template_id) REFERENCES report_templates (id)
        )`
      ];

      for (const query of queries) {
        const result = await window.electronAPI.dbRun(query);
        if (!result.success) {
          throw new Error(`Failed to create table: ${result.error}`);
        }
      }

      await this.insertDefaultData();
      return true;
    } catch (error) {
      console.error('Failed to initialize Electron schema:', error);
      return false;
    }
  }

  private static async initializeSupabaseSchema(): Promise<boolean> {
    // In production, this would be handled by migrations
    // For now, we'll assume the schema exists in Supabase
    try {
      await this.insertDefaultDataSupabase();
      return true;
    } catch (error) {
      console.error('Failed to initialize Supabase schema:', error);
      return false;
    }
  }

  // Category Management
  static async getCategories(): Promise<ReportCategory[]> {
    try {
      if (this.isElectron) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM report_categories WHERE is_active = 1 ORDER BY name'
        );
        return result.success ? result.data : [];
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Categories API not available');
        return this.getMockCategories();
      }
    } catch (error) {
      console.error('Failed to get categories:', error);
      return [];
    }
  }

  static async createCategory(category: Omit<ReportCategory, 'id'>): Promise<string | null> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      if (this.isElectron) {
        const result = await window.electronAPI.dbRun(
          `INSERT INTO report_categories (id, name, description, created_by, created_at, is_active)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [id, category.name, category.description, category.created_by, now, category.is_active]
        );
        return result.success ? id : null;
      } else {
        // Browser mode - would need REST API endpoint
        const mockCategory = { ...category, id, created_at: now };
        console.warn('Browser environment: Category creation not available');
        return id; // Return mock success
      }
    } catch (error) {
      console.error('Failed to create category:', error);
      return null;
    }
  }

  // Product Definition Management
  static async getProductDefinitions(categoryId?: string): Promise<ProductDefinition[]> {
    try {
      if (this.isElectron) {
        let query = 'SELECT * FROM product_definitions WHERE is_active = 1';
        const params: string[] = [];
        
        if (categoryId) {
          query += ' AND category_id = ?';
          params.push(categoryId);
        }
        
        query += ' ORDER BY name';
        
        const result = await window.electronAPI.dbQuery(query, params);
        return result.success ? result.data.map((row: any) => ({
          ...row,
          field_definitions: JSON.parse(row.field_definitions)
        })) : [];
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Product definitions API not available');
        return this.getMockProductDefinitions(categoryId);
      }
    } catch (error) {
      console.error('Failed to get product definitions:', error);
      return [];
    }
  }

  static async createProductDefinition(product: Omit<ProductDefinition, 'id'>): Promise<string | null> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      if (this.isElectron) {
        const result = await window.electronAPI.dbRun(
          `INSERT INTO product_definitions (id, name, category_id, field_definitions, created_by, created_at, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            id,
            product.name,
            product.category_id,
            JSON.stringify(product.field_definitions),
            product.created_by,
            now,
            product.is_active
          ]
        );
        return result.success ? id : null;
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Product definition creation not available');
        return id; // Return mock success
      }
    } catch (error) {
      console.error('Failed to create product definition:', error);
      return null;
    }
  }

  // Template Management
  static async getTemplates(productType?: string): Promise<ReportTemplate[]> {
    try {
      if (this.isElectron) {
        let query = 'SELECT * FROM report_templates WHERE is_active = 1';
        const params: string[] = [];
        
        if (productType) {
          query += ' AND product_type = ?';
          params.push(productType);
        }
        
        query += ' ORDER BY uploaded_at DESC';
        
        const result = await window.electronAPI.dbQuery(query, params);
        return result.success ? result.data.map((row: any) => ({
          ...row,
          shared_with: row.shared_with ? JSON.parse(row.shared_with) : []
        })) : [];
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Templates API not available');
        return this.getMockTemplates(productType);
      }
    } catch (error) {
      console.error('Failed to get templates:', error);
      return [];
    }
  }

  static async saveTemplate(template: Omit<ReportTemplate, 'id' | 'uploaded_at'>): Promise<string | null> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      if (this.isElectron) {
        const result = await window.electronAPI.dbRun(
          `INSERT INTO report_templates 
           (id, name, description, product_type, layout_json, uploaded_by, uploaded_at, 
            file_path, template_type, version, is_active, shared_with, owner_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id,
            template.name,
            template.description,
            template.product_type,
            template.layout_json,
            template.uploaded_by,
            now,
            template.file_path,
            template.template_type,
            template.version,
            template.is_active,
            JSON.stringify(template.shared_with || []),
            template.owner_id
          ]
        );
        return result.success ? id : null;
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Template save not available');
        return id; // Return mock success
      }
    } catch (error) {
      console.error('Failed to save template:', error);
      return null;
    }
  }

  // Analytics Charts Management
  static async getAnalyticsCharts(): Promise<AnalyticsChart[]> {
    try {
      if (this.isElectron) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM analytics_charts WHERE is_public = 1 ORDER BY name'
        );
        return result.success ? result.data.map((row: any) => ({
          ...row,
          config: JSON.parse(row.config)
        })) : [];
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Analytics charts API not available');
        return this.getMockAnalyticsCharts();
      }
    } catch (error) {
      console.error('Failed to get analytics charts:', error);
      return [];
    }
  }

  // Get chart data for specific chart
  static async getChartData(chartId: string, memoId?: string, filters?: Record<string, any>): Promise<any> {
    try {
      if (this.isElectron) {
        // Get chart definition first
        const chartResult = await window.electronAPI.dbQuery(
          `SELECT * FROM analytics_charts WHERE id = ?`,
          [chartId]
        );

        if (!chartResult.success || chartResult.data.length === 0) {
          return null;
        }

        // Use the enhanced analytics integration for Electron
        const { EnhancedAnalyticsIntegration } = await import('../reporting/enhancedAnalyticsIntegration');
        return await EnhancedAnalyticsIntegration.getChartData(chartId, memoId, filters);
      } else {
        // API fallback - implement based on your backend
        const endpoint = `/api/analytics/charts/${chartId}/data`;
        const params = new URLSearchParams();
        
        if (memoId) params.append('memoId', memoId);
        if (filters) params.append('filters', JSON.stringify(filters));
        
        const url = params.toString() ? `${endpoint}?${params}` : endpoint;
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch chart data: ${response.statusText}`);
        }
        
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get chart data:', error);
      return null;
    }
  }

  static async createAnalyticsChart(chart: Omit<AnalyticsChart, 'id'>): Promise<string | null> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      if (this.isElectron) {
        const result = await window.electronAPI.dbRun(
          `INSERT INTO analytics_charts 
           (id, chart_type, name, description, data_source, config, created_by, created_at, is_public)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id,
            chart.chart_type,
            chart.name,
            chart.description,
            chart.data_source,
            JSON.stringify(chart.config),
            chart.created_by,
            now,
            chart.is_public
          ]
        );
        return result.success ? id : null;
      } else {
        // Browser mode - would need REST API endpoint
        console.warn('Browser environment: Analytics chart creation not available');
        return id; // Return mock success
      }
    } catch (error) {
      console.error('Failed to create analytics chart:', error);
      return null;
    }
  }

  // File Upload Management (Cross-platform)
  static async uploadFile(file: File, category: string, uploadedBy: string): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      if (this.isElectron) {
        // Use existing FileUploadService for Electron
        const { FileUploadService } = await import('../storage/fileUploadService');
        const result = await FileUploadService.uploadFile(file, category as any, uploadedBy);
        return { success: !!result, data: result };
      } else {
        // Browser mode - would need proper file upload API
        console.warn('Browser environment: File upload not available');
        return { 
          success: false, 
          error: 'File upload not available in browser mode' 
        };
      }
    } catch (error) {
      console.error('File upload failed:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Upload failed' 
      };
    }
  }

  // Generate Report from Template
  static async generateReport(templateId: string, memoId: string, parameters: any = {}): Promise<GeneratedReport | null> {
    try {
      const template = await this.getTemplateById(templateId);
      if (!template) throw new Error('Template not found');

      // Get memo data
      const memoData = await this.getMemoData(memoId);
      
      // Generate PDF using existing service
      const { TemplateToPdfService } = await import('../reporting/templateToPdfService');
      const pdfBlob = await TemplateToPdfService.generateFromTemplate(template, memoData);
      
      // Save generated file
      const fileName = `report-${memoId}-${Date.now()}.pdf`;
      let filePath: string;
      
      if (this.isElectron) {
        // Save to local filesystem
        const arrayBuffer = await pdfBlob.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        const result = await window.electronAPI.saveFile(`/reports/${fileName}`, uint8Array);
        if (!result.success) throw new Error('Failed to save report file');
        filePath = `/reports/${fileName}`;
      } else {
        // Browser mode - would need file upload API
        console.warn('Browser environment: Report file save not available');
        filePath = `mock://reports/${fileName}`;
      }
      
      // Save report record
      const reportId = crypto.randomUUID();
      const now = new Date().toISOString();
      
      const report: GeneratedReport = {
        id: reportId,
        memo_id: memoId,
        template_id: templateId,
        generated_by: parameters.generatedBy || 'system',
        generated_at: now,
        file_path: filePath,
        parameters,
        status: 'completed'
      };
      
      if (this.isElectron) {
        await window.electronAPI.dbRun(
          `INSERT INTO generated_reports 
           (id, memo_id, template_id, generated_by, generated_at, file_path, parameters, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            reportId,
            memoId,
            templateId,
            report.generated_by,
            now,
            filePath,
            JSON.stringify(parameters),
            'completed'
          ]
        );
      } else {
        // Browser mode - would need API endpoint
        console.warn('Browser environment: Report save not available');
        // Return mock success
      }
      
      return report;
    } catch (error) {
      console.error('Failed to generate report:', error);
      return null;
    }
  }

  // Helper methods
  private static async getTemplateById(id: string): Promise<any> {
    if (this.isElectron) {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM report_templates WHERE id = ?',
        [id]
      );
      return result.success && result.data.length > 0 ? result.data[0] : null;
    } else {
      // Browser mode - would need API endpoint
      console.warn('Browser environment: Template fetch not available');
      return null;
    }
  }

  private static async getMemoData(memoId: string): Promise<any> {
    // Use existing DataBindingService
    const { DataBindingService } = await import('../reporting/dataBindingService');
    const dataService = new DataBindingService();
    return await dataService.bindMemoData(memoId);
  }

  // Insert default data
  private static async insertDefaultData(): Promise<void> {
    // Insert default categories
    const categories = [
      { id: 'aggregates', name: 'Aggregates', description: 'Stone and sand materials testing' },
      { id: 'concrete', name: 'Concrete', description: 'Concrete mix testing' },
      { id: 'blocks', name: 'Blocks', description: 'Concrete block testing' },
      { id: 'pavers', name: 'Pavers', description: 'Paving stone testing' }
    ];

    for (const category of categories) {
      await window.electronAPI.dbRun(
        `INSERT OR REPLACE INTO report_categories (id, name, description, created_by, created_at, is_active)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [category.id, category.name, category.description, 'system', new Date().toISOString(), true]
      );
    }

    // Insert default analytics charts
    const charts = [
      {
        id: 'sieve-analysis',
        chart_type: 'line',
        name: 'Sieve Analysis',
        description: 'Particle size distribution',
        data_source: 'test_results',
        config: { xAxis: 'sieve_size', yAxis: 'passing_percentage' }
      },
      {
        id: 'strength-trend',
        chart_type: 'line',
        name: 'Strength Trend',
        description: 'Compressive strength over time',
        data_source: 'test_results',
        config: { xAxis: 'age_days', yAxis: 'compressive_strength' }
      }
    ];

    for (const chart of charts) {
      await window.electronAPI.dbRun(
        `INSERT OR REPLACE INTO analytics_charts 
         (id, chart_type, name, description, data_source, config, created_by, created_at, is_public)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          chart.id,
          chart.chart_type,
          chart.name,
          chart.description,
          chart.data_source,
          JSON.stringify(chart.config),
          'system',
          new Date().toISOString(),
          true
        ]
      );
    }
  }

  private static async insertDefaultDataSupabase(): Promise<void> {
    // This would be handled by migrations in production
    // For now, we'll skip default data insertion
  }

  // Mock data methods for browser fallback
  private static getMockCategories(): ReportCategory[] {
    return [
      { id: 'aggregates', name: 'Aggregates', description: 'Stone and sand materials testing', created_by: 'system', is_active: true },
      { id: 'concrete', name: 'Concrete', description: 'Concrete mix testing', created_by: 'system', is_active: true },
      { id: 'blocks', name: 'Blocks', description: 'Concrete block testing', created_by: 'system', is_active: true },
      { id: 'pavers', name: 'Pavers', description: 'Paving stone testing', created_by: 'system', is_active: true }
    ];
  }

  private static getMockProductDefinitions(categoryId?: string): ProductDefinition[] {
    const allProducts = [
      {
        id: 'agg-10-14mm',
        name: '10-14mm Aggregate',
        category_id: 'aggregates',
        field_definitions: [
          { id: '1', name: 'Date of Test', token: '{{date_of_test}}', type: 'date' as const, required: true },
          { id: '2', name: 'Officer in Charge', token: '{{officer_in_charge}}', type: 'text' as const, required: true },
          { id: '3', name: 'Moisture Content (%)', token: '{{moisture_content}}', type: 'number' as const, required: true }
        ],
        created_by: 'system',
        is_active: true
      },
      {
        id: 'cube-test',
        name: 'Cube Test',
        category_id: 'concrete',
        field_definitions: [
          { id: '4', name: 'Mix Design', token: '{{mix_design}}', type: 'text' as const, required: true },
          { id: '5', name: 'Slump Value (mm)', token: '{{slump_value}}', type: 'number' as const, required: true }
        ],
        created_by: 'system',
        is_active: true
      }
    ];
    
    return categoryId ? allProducts.filter(p => p.category_id === categoryId) : allProducts;
  }

  private static getMockTemplates(productType?: string): ReportTemplate[] {
    const allTemplates = [
      {
        id: 'template-1',
        name: 'Standard Aggregate Report',
        description: 'Standard template for aggregate testing',
        product_type: 'aggregates',
        layout_json: '[]',
        uploaded_by: 'system',
        uploaded_at: new Date().toISOString(),
        template_type: 'canvas' as const,
        version: 1,
        is_active: true
      }
    ];
    
    return productType ? allTemplates.filter(t => t.product_type === productType) : allTemplates;
  }

  private static getMockAnalyticsCharts(): AnalyticsChart[] {
    return [
      {
        id: 'sieve-analysis',
        chart_type: 'line',
        name: 'Sieve Analysis',
        description: 'Particle size distribution',
        data_source: 'test_results',
        config: { xAxis: 'sieve_size', yAxis: 'passing_percentage' },
        created_by: 'system',
        is_public: true
      }
    ];
  }
}