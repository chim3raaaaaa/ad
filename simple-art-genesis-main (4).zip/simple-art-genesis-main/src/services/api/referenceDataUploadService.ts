// CSV Upload Service for Reference Datasets

export interface UploadResult {
  success: boolean;
  rowsImported: number;
  tableName: string;
  errors: string[];
  timestamp: string;
}

export interface ReferenceTableInfo {
  tableName: string;
  lastUpdated: string | null;
  rowCount: number;
}

// Map CSV filenames to database tables
const TABLE_MAPPING: Record<string, string> = {
  'lab tests.csv': 'lab_tests',
  'lab group code.csv': 'lab_group_code', 
  'lab mould.csv': 'lab_mould',
  'sampling places.csv': 'sampling_places',
  'colour.csv': 'colour',
  'climatic conditions.csv': 'climatic_conditions'
};

// Expected column schemas for each table
const TABLE_SCHEMAS: Record<string, string[]> = {
  'lab_tests': ['code', 'name', 'type', 'active'],
  'lab_group_code': ['lab_site', 'lab_product', 'lab_machine', 'active'],
  'lab_mould': ['code', 'name', 'machine_no', 'active'],
  'sampling_places': ['code', 'name', 'location', 'active'],
  'colour': ['code', 'name', 'hex_value', 'active'],
  'climatic_conditions': ['code', 'name', 'description', 'active']
};

class ReferenceDataUploadService {
  
  // Initialize upload log table if it doesn't exist
  async initializeUploadLog(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS reference_upload_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          table_name TEXT NOT NULL,
          filename TEXT NOT NULL,
          rows_imported INTEGER NOT NULL,
          uploaded_by TEXT NOT NULL,
          uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          file_size INTEGER,
          checksum TEXT
        )
      `);
    } catch (error) {
      console.error('Failed to initialize upload log table:', error);
    }
  }

  // Parse CSV content into rows
  private parseCSV(content: string): string[][] {
    const lines = content.split('\n').filter(line => line.trim());
    return lines.map(line => {
      // Handle CSV parsing with quoted values
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' && (i === 0 || line[i-1] === ',')) {
          inQuotes = true;
        } else if (char === '"' && inQuotes && (i === line.length-1 || line[i+1] === ',')) {
          inQuotes = false;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    });
  }

  // Validate CSV headers against expected schema
  private validateHeaders(headers: string[], tableName: string): string[] {
    const expected = TABLE_SCHEMAS[tableName];
    if (!expected) {
      return [`Unknown table schema for ${tableName}`];
    }

    const errors: string[] = [];
    const headerLower = headers.map(h => h.toLowerCase().replace(/\s+/g, '_'));
    const expectedLower = expected.map(e => e.toLowerCase());

    for (const expectedCol of expectedLower) {
      if (!headerLower.includes(expectedCol)) {
        errors.push(`Missing required column: ${expectedCol}`);
      }
    }

    return errors;
  }

  // Upload CSV file and update database
  async uploadCSV(file: File, currentUser: string): Promise<UploadResult> {
    try {
      if (!window.electronAPI) {
        throw new Error('Database access not available');
      }

      // Initialize upload log table
      await this.initializeUploadLog();

      // Determine target table from filename
      const filename = file.name.toLowerCase();
      const tableName = TABLE_MAPPING[filename];
      
      if (!tableName) {
        return {
          success: false,
          rowsImported: 0,
          tableName: filename,
          errors: [`Unknown CSV file: ${filename}. Expected one of: ${Object.keys(TABLE_MAPPING).join(', ')}`],
          timestamp: new Date().toISOString()
        };
      }

      // Read and parse CSV content
      const content = await file.text();
      const rows = this.parseCSV(content);
      
      if (rows.length === 0) {
        return {
          success: false,
          rowsImported: 0,
          tableName,
          errors: ['CSV file is empty'],
          timestamp: new Date().toISOString()
        };
      }

      // Validate headers
      const headers = rows[0];
      const headerErrors = this.validateHeaders(headers, tableName);
      
      if (headerErrors.length > 0) {
        return {
          success: false,
          rowsImported: 0,
          tableName,
          errors: headerErrors,
          timestamp: new Date().toISOString()
        };
      }

      // Create table if it doesn't exist
      await this.createTableIfNotExists(tableName, headers);

      // Begin transaction for atomic update
      await window.electronAPI.dbRun('BEGIN TRANSACTION');

      try {
        // Clear existing data
        await window.electronAPI.dbRun(`DELETE FROM ${tableName}`);

        // Insert new data
        const dataRows = rows.slice(1); // Skip header row
        let successCount = 0;
        const errors: string[] = [];

        for (let i = 0; i < dataRows.length; i++) {
          const row = dataRows[i];
          if (row.length !== headers.length) {
            errors.push(`Row ${i + 2}: Column count mismatch (expected ${headers.length}, got ${row.length})`);
            continue;
          }

          try {
            const placeholders = headers.map(() => '?').join(',');
            const columns = headers.join(',');
            
            await window.electronAPI.dbRun(
              `INSERT INTO ${tableName} (${columns}) VALUES (${placeholders})`,
              row
            );
            successCount++;
          } catch (error) {
            errors.push(`Row ${i + 2}: ${error}`);
          }
        }

        // Log the upload
        await window.electronAPI.dbRun(
          `INSERT INTO reference_upload_log (table_name, filename, rows_imported, uploaded_by, file_size)
           VALUES (?, ?, ?, ?, ?)`,
          [tableName, file.name, successCount, currentUser, file.size]
        );

        // Commit transaction
        await window.electronAPI.dbRun('COMMIT');

        return {
          success: true,
          rowsImported: successCount,
          tableName,
          errors,
          timestamp: new Date().toISOString()
        };

      } catch (error) {
        // Rollback on error
        await window.electronAPI.dbRun('ROLLBACK');
        throw error;
      }

    } catch (error) {
      console.error('CSV upload failed:', error);
      return {
        success: false,
        rowsImported: 0,
        tableName: file.name,
        errors: [`Upload failed: ${error}`],
        timestamp: new Date().toISOString()
      };
    }
  }

  // Create table with dynamic schema
  private async createTableIfNotExists(tableName: string, headers: string[]): Promise<void> {
    if (!window.electronAPI) return;

    const columns = headers.map(header => `${header} TEXT`).join(', ');
    const sql = `CREATE TABLE IF NOT EXISTS ${tableName} (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ${columns},
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`;

    await window.electronAPI.dbRun(sql);
  }

  // Get information about all reference tables
  async getReferenceTablesInfo(): Promise<ReferenceTableInfo[]> {
    if (!window.electronAPI) {
      return [];
    }

    try {
      const tables = Object.values(TABLE_MAPPING);
      const tableInfo: ReferenceTableInfo[] = [];

      for (const tableName of tables) {
        // Get row count
        const countResult = await window.electronAPI.dbQuery(
          `SELECT COUNT(*) as count FROM ${tableName}`,
          []
        );
        
        const rowCount = countResult.success ? (countResult.data[0]?.count || 0) : 0;

        // Get last updated timestamp
        const logResult = await window.electronAPI.dbQuery(
          `SELECT uploaded_at FROM reference_upload_log 
           WHERE table_name = ? 
           ORDER BY uploaded_at DESC 
           LIMIT 1`,
          [tableName]
        );

        const lastUpdated = logResult.success && logResult.data.length > 0 
          ? logResult.data[0].uploaded_at 
          : null;

        tableInfo.push({
          tableName,
          lastUpdated,
          rowCount
        });
      }

      return tableInfo;
    } catch (error) {
      console.error('Failed to get table info:', error);
      return [];
    }
  }

  // Get upload history
  async getUploadHistory(limit: number = 10): Promise<any[]> {
    if (!window.electronAPI) {
      return [];
    }

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM reference_upload_log 
         ORDER BY uploaded_at DESC 
         LIMIT ?`,
        [limit]
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get upload history:', error);
      return [];
    }
  }
}

export const referenceDataUploadService = new ReferenceDataUploadService();