// Server-side API implementation for Test Modules
// This would be the actual backend implementation when not using Electron

export interface ServerConfig {
  baseUrl: string;
  apiKey?: string;
  timeout: number;
}

export class TestModulesServerAPI {
  private config: ServerConfig;

  constructor(config: ServerConfig) {
    this.config = config;
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
    const url = `${this.config.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(this.config.apiKey && { 'Authorization': `Bearer ${this.config.apiKey}` }),
      ...options.headers
    };

    const response = await fetch(url, {
      ...options,
      headers,
      signal: AbortSignal.timeout(this.config.timeout)
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return response.json();
  }

  // Product Categories Endpoints
  async getProductCategories() {
    return this.makeRequest('/api/v1/test-modules/categories');
  }

  async createProductCategory(category: any) {
    return this.makeRequest('/api/v1/test-modules/categories', {
      method: 'POST',
      body: JSON.stringify(category)
    });
  }

  async updateProductCategory(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deleteProductCategory(id: string) {
    return this.makeRequest(`/api/v1/test-modules/categories/${id}`, {
      method: 'DELETE'
    });
  }

  // Product Types Endpoints
  async getProductTypes(categoryId?: string) {
    const query = categoryId ? `?category_id=${categoryId}` : '';
    return this.makeRequest(`/api/v1/test-modules/types${query}`);
  }

  async createProductType(productType: any) {
    return this.makeRequest('/api/v1/test-modules/types', {
      method: 'POST',
      body: JSON.stringify(productType)
    });
  }

  async updateProductType(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/types/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deleteProductType(id: string) {
    return this.makeRequest(`/api/v1/test-modules/types/${id}`, {
      method: 'DELETE'
    });
  }

  // Product Fields Endpoints
  async getProductFields(productTypeId: string) {
    return this.makeRequest(`/api/v1/test-modules/fields?product_type_id=${productTypeId}`);
  }

  async createProductField(field: any) {
    return this.makeRequest('/api/v1/test-modules/fields', {
      method: 'POST',
      body: JSON.stringify(field)
    });
  }

  async updateProductField(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/fields/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deleteProductField(id: string) {
    return this.makeRequest(`/api/v1/test-modules/fields/${id}`, {
      method: 'DELETE'
    });
  }

  // Test Entries Endpoints
  async getTestEntries(filters: any = {}) {
    const searchParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) searchParams.append(key, String(value));
    });
    
    const query = searchParams.toString() ? `?${searchParams}` : '';
    return this.makeRequest(`/api/v1/test-modules/entries${query}`);
  }

  async createTestEntry(entry: any) {
    return this.makeRequest('/api/v1/test-modules/entries', {
      method: 'POST',
      body: JSON.stringify(entry)
    });
  }

  async updateTestEntry(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/entries/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deleteTestEntry(id: string) {
    return this.makeRequest(`/api/v1/test-modules/entries/${id}`, {
      method: 'DELETE'
    });
  }

  // Plant Configuration Endpoints
  async getPlantConfigurations() {
    return this.makeRequest('/api/v1/test-modules/plants');
  }

  async createPlantConfiguration(plant: any) {
    return this.makeRequest('/api/v1/test-modules/plants', {
      method: 'POST',
      body: JSON.stringify(plant)
    });
  }

  async updatePlantConfiguration(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/plants/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  // Plant Machines Endpoints
  async getPlantMachines(plantId: string) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/machines`);
  }

  async createPlantMachine(plantId: string, machine: any) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/machines`, {
      method: 'POST',
      body: JSON.stringify(machine)
    });
  }

  async updatePlantMachine(plantId: string, machineId: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/machines/${machineId}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deletePlantMachine(plantId: string, machineId: string) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/machines/${machineId}`, {
      method: 'DELETE'
    });
  }

  // Plant Officers Endpoints
  async getPlantOfficers(plantId: string) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/officers`);
  }

  async createPlantOfficer(plantId: string, officer: any) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/officers`, {
      method: 'POST',
      body: JSON.stringify(officer)
    });
  }

  async updatePlantOfficer(plantId: string, officerId: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/officers/${officerId}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deletePlantOfficer(plantId: string, officerId: string) {
    return this.makeRequest(`/api/v1/test-modules/plants/${plantId}/officers/${officerId}`, {
      method: 'DELETE'
    });
  }

  // Memo Test Assignments Endpoints
  async getMemoTestAssignments(filters: any = {}) {
    const searchParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) searchParams.append(key, String(value));
    });
    
    const query = searchParams.toString() ? `?${searchParams}` : '';
    return this.makeRequest(`/api/v1/test-modules/memo-assignments${query}`);
  }

  async createMemoTestAssignment(assignment: any) {
    return this.makeRequest('/api/v1/test-modules/memo-assignments', {
      method: 'POST',
      body: JSON.stringify(assignment)
    });
  }

  async updateMemoTestAssignment(id: string, updates: any) {
    return this.makeRequest(`/api/v1/test-modules/memo-assignments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  // Validation Endpoints
  async validateField(productTypeId: string, fieldName: string, value: any) {
    return this.makeRequest('/api/v1/test-modules/validate-field', {
      method: 'POST',
      body: JSON.stringify({ productTypeId, fieldName, value })
    });
  }

  async validateTestEntry(entry: any) {
    return this.makeRequest('/api/v1/test-modules/validate-entry', {
      method: 'POST',
      body: JSON.stringify(entry)
    });
  }

  // Utility Endpoints
  async getSystemHealth() {
    return this.makeRequest('/api/v1/health');
  }

  async getDatabaseSchema() {
    return this.makeRequest('/api/v1/test-modules/schema');
  }

  async runMigration(version?: string) {
    const body = version ? JSON.stringify({ version }) : undefined;
    return this.makeRequest('/api/v1/test-modules/migrate', {
      method: 'POST',
      body
    });
  }

  async exportData(filters: any = {}) {
    const searchParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) searchParams.append(key, String(value));
    });
    
    const query = searchParams.toString() ? `?${searchParams}` : '';
    return this.makeRequest(`/api/v1/test-modules/export${query}`);
  }

  async importData(data: any) {
    return this.makeRequest('/api/v1/test-modules/import', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }
}

// Factory function to create configured API instance
export function createTestModulesServerAPI(config?: Partial<ServerConfig>): TestModulesServerAPI {
  const defaultConfig: ServerConfig = {
    baseUrl: process.env.NODE_ENV === 'production' 
      ? 'https://api.your-domain.com' 
      : 'http://localhost:3001',
    timeout: 30000,
    ...config
  };

  return new TestModulesServerAPI(defaultConfig);
}

// Export types for use in other files
export type { ServerConfig as TestModulesServerConfig };