// CSV Upload Service for Reference Datasets
export interface CsvUploadResult {
  success: boolean;
  rowsInserted: number;
  error?: string;
  tableName?: string;
}

export interface ReferenceTableConfig {
  fileName: string;
  tableName: string;
  requiredColumns: string[];
  description: string;
}

export const REFERENCE_TABLE_CONFIGS: Record<string, ReferenceTableConfig> = {
  'lab tests.csv': {
    fileName: 'lab tests.csv',
    tableName: 'lab_tests',
    requiredColumns: ['code', 'description'],
    description: 'Laboratory test types and procedures'
  },
  'lab group code.csv': {
    fileName: 'lab group code.csv',
    tableName: 'lab_group_code',
    requiredColumns: ['code'],
    description: 'Laboratory group codes for machines and products'
  },
  'lab mould.csv': {
    fileName: 'lab mould.csv',
    tableName: 'lab_mould',
    requiredColumns: ['code'],
    description: 'Laboratory mould references and positions'
  },
  'sampling places.csv': {
    fileName: 'sampling places.csv',
    tableName: 'sampling_places',
    requiredColumns: ['code', 'description'],
    description: 'Sampling locations and points'
  },
  'climatic conditions.csv': {
    fileName: 'climatic conditions.csv',
    tableName: 'climatic_conditions',
    requiredColumns: ['code', 'description'],
    description: 'Environmental and climate conditions'
  },
  'colour.csv': {
    fileName: 'colour.csv',
    tableName: 'colour',
    requiredColumns: ['code', 'description'],
    description: 'Color reference codes and descriptions'
  }
};

export class CsvUploadService {
  static parseCSV(csvContent: string): any[] {
    const lines = csvContent.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
    const rows = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      const row: any = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      rows.push(row);
    }

    return rows;
  }

  static validateCSVData(fileName: string, data: any[]): { isValid: boolean; error?: string } {
    const config = REFERENCE_TABLE_CONFIGS[fileName.toLowerCase()];
    if (!config) {
      return { isValid: false, error: `Unsupported file: ${fileName}. Supported files: ${Object.keys(REFERENCE_TABLE_CONFIGS).join(', ')}` };
    }

    if (data.length === 0) {
      return { isValid: false, error: 'CSV file is empty or has no data rows' };
    }

    // Check required columns
    const firstRow = data[0];
    const missingColumns = config.requiredColumns.filter(col => !(col in firstRow));
    if (missingColumns.length > 0) {
      return { isValid: false, error: `Missing required columns: ${missingColumns.join(', ')}` };
    }

    // Check for empty codes
    const emptyCodeRows = data.filter(row => !row.code || row.code.trim() === '');
    if (emptyCodeRows.length > 0) {
      return { isValid: false, error: `Found ${emptyCodeRows.length} rows with empty codes. All rows must have a valid code.` };
    }

    return { isValid: true };
  }

  static getTableNameFromFileName(fileName: string): string | null {
    const config = REFERENCE_TABLE_CONFIGS[fileName.toLowerCase()];
    return config ? config.tableName : null;
  }

  static getSupportedFiles(): ReferenceTableConfig[] {
    return Object.values(REFERENCE_TABLE_CONFIGS);
  }
}