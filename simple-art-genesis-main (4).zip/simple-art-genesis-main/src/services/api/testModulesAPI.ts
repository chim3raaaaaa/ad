// Cross-platform Test Modules API Service
import { ReportsAPI } from './reportsAPI';

export interface ProductCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  sort_order: number;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ProductType {
  id: string;
  category_id: string;
  name: string;
  description: string;
  table_suffix: string;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ProductField {
  id: string;
  product_type_id: string;
  field_name: string;
  field_label: string;
  field_type: 'text' | 'number' | 'date' | 'select' | 'textarea' | 'boolean' | 'file';
  field_unit?: string;
  is_required: boolean;
  validation_rules: ValidationRule[];
  field_options?: string[];
  sort_order: number;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ValidationRule {
  type: 'min' | 'max' | 'pattern' | 'custom';
  value: any;
  message: string;
}

export interface TestEntry {
  id: string;
  product_type_id: string;
  memo_id?: string;
  plant_id: string;
  officer_id: string;
  test_date: string;
  test_data: Record<string, any>;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  notes?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface PlantConfiguration {
  id: string;
  name: string;
  location: string;
  contact_info: Record<string, any>;
  machines: PlantMachine[];
  officers: PlantOfficer[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface PlantMachine {
  id: string;
  plant_id: string;
  name: string;
  type: string;
  specifications: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PlantOfficer {
  id: string;
  plant_id: string;
  name: string;
  role: string;
  contact_info: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MemoTestAssignment {
  id: string;
  memo_id: string;
  product_type_id: string;
  required_tests: string[];
  assigned_to?: string;
  due_date?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  test_entry_id?: string;
  created_at: string;
  updated_at: string;
}

export class TestModulesAPI {
  private static baseUrl = '/api/test-modules';
  private static isElectron = typeof window !== 'undefined' && window.electronAPI;

  // Product Categories Management
  static async getProductCategories(): Promise<ProductCategory[]> {
    try {
      if (this.isElectron) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM product_categories WHERE is_active = 1 ORDER BY sort_order, name`
        );
        return result.success ? result.data : [];
      } else {
        const response = await fetch(`${this.baseUrl}/categories`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get product categories:', error);
      return this.getDefaultCategories();
    }
  }

  static async createProductCategory(category: Omit<ProductCategory, 'id' | 'created_at' | 'updated_at'>): Promise<string | null> {
    try {
      if (this.isElectron) {
        const id = crypto.randomUUID();
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_categories (id, name, description, icon, sort_order, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [id, category.name, category.description, category.icon, category.sort_order, category.is_active, category.created_by]
        );
        return result.success ? id : null;
      } else {
        const response = await fetch(`${this.baseUrl}/categories`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(category)
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        return result.id;
      }
    } catch (error) {
      console.error('Failed to create product category:', error);
      return null;
    }
  }

  static async updateProductCategory(id: string, updates: Partial<ProductCategory>): Promise<boolean> {
    try {
      if (this.isElectron) {
        const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
        const values = [...Object.values(updates), new Date().toISOString(), id];
        const result = await window.electronAPI.dbQuery(
          `UPDATE product_categories SET ${setClause}, updated_at = ? WHERE id = ?`,
          values
        );
        return result.success;
      } else {
        const response = await fetch(`${this.baseUrl}/categories/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
        return response.ok;
      }
    } catch (error) {
      console.error('Failed to update product category:', error);
      return false;
    }
  }

  // Product Types Management
  static async getProductTypes(categoryId?: string): Promise<ProductType[]> {
    try {
      if (this.isElectron) {
        const query = categoryId 
          ? `SELECT * FROM product_types WHERE category_id = ? AND is_active = 1 ORDER BY name`
          : `SELECT * FROM product_types WHERE is_active = 1 ORDER BY name`;
        const params = categoryId ? [categoryId] : [];
        const result = await window.electronAPI.dbQuery(query, params);
        return result.success ? result.data : [];
      } else {
        const url = categoryId 
          ? `${this.baseUrl}/types?category_id=${categoryId}`
          : `${this.baseUrl}/types`;
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get product types:', error);
      return [];
    }
  }

  static async createProductType(productType: Omit<ProductType, 'id' | 'created_at' | 'updated_at'>): Promise<string | null> {
    try {
      if (this.isElectron) {
        const id = crypto.randomUUID();
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_types (id, category_id, name, description, table_suffix, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [id, productType.category_id, productType.name, productType.description, 
           productType.table_suffix, productType.is_active, productType.created_by]
        );
        
        if (result.success) {
          // Create the test data table for this product type
          await this.createTestDataTable(productType.table_suffix);
          return id;
        }
        return null;
      } else {
        const response = await fetch(`${this.baseUrl}/types`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(productType)
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        return result.id;
      }
    } catch (error) {
      console.error('Failed to create product type:', error);
      return null;
    }
  }

  // Product Fields Management
  static async getProductFields(productTypeId: string): Promise<ProductField[]> {
    try {
      if (this.isElectron) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM product_fields WHERE product_type_id = ? AND is_active = 1 ORDER BY sort_order, field_label`,
          [productTypeId]
        );
        return result.success ? result.data.map(field => ({
          ...field,
          validation_rules: JSON.parse(field.validation_rules || '[]'),
          field_options: JSON.parse(field.field_options || 'null')
        })) : [];
      } else {
        const response = await fetch(`${this.baseUrl}/fields?product_type_id=${productTypeId}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get product fields:', error);
      return [];
    }
  }

  static async createProductField(field: Omit<ProductField, 'id' | 'created_at' | 'updated_at'>): Promise<string | null> {
    try {
      if (this.isElectron) {
        const id = crypto.randomUUID();
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_fields 
           (id, product_type_id, field_name, field_label, field_type, field_unit, is_required, 
            validation_rules, field_options, sort_order, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [id, field.product_type_id, field.field_name, field.field_label, field.field_type,
           field.field_unit, field.is_required, JSON.stringify(field.validation_rules),
           JSON.stringify(field.field_options), field.sort_order, field.is_active, field.created_by]
        );
        return result.success ? id : null;
      } else {
        const response = await fetch(`${this.baseUrl}/fields`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(field)
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        return result.id;
      }
    } catch (error) {
      console.error('Failed to create product field:', error);
      return null;
    }
  }

  // Test Entries Management
  static async getTestEntries(filters: {
    productTypeId?: string;
    plantId?: string;
    memoId?: string;
    status?: string;
    dateFrom?: string;
    dateTo?: string;
  } = {}): Promise<TestEntry[]> {
    try {
      if (this.isElectron) {
        let query = `SELECT * FROM test_entries WHERE 1=1`;
        const params: any[] = [];

        if (filters.productTypeId) {
          query += ` AND product_type_id = ?`;
          params.push(filters.productTypeId);
        }
        if (filters.plantId) {
          query += ` AND plant_id = ?`;
          params.push(filters.plantId);
        }
        if (filters.memoId) {
          query += ` AND memo_id = ?`;
          params.push(filters.memoId);
        }
        if (filters.status) {
          query += ` AND status = ?`;
          params.push(filters.status);
        }
        if (filters.dateFrom) {
          query += ` AND test_date >= ?`;
          params.push(filters.dateFrom);
        }
        if (filters.dateTo) {
          query += ` AND test_date <= ?`;
          params.push(filters.dateTo);
        }

        query += ` ORDER BY test_date DESC, created_at DESC`;

        const result = await window.electronAPI.dbQuery(query, params);
        return result.success ? result.data.map(entry => ({
          ...entry,
          test_data: JSON.parse(entry.test_data || '{}')
        })) : [];
      } else {
        const searchParams = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value) searchParams.append(key, value);
        });
        
        const response = await fetch(`${this.baseUrl}/entries?${searchParams}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get test entries:', error);
      return [];
    }
  }

  static async createTestEntry(entry: Omit<TestEntry, 'id' | 'created_at' | 'updated_at'>): Promise<string | null> {
    try {
      if (this.isElectron) {
        const id = crypto.randomUUID();
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO test_entries 
           (id, product_type_id, memo_id, plant_id, officer_id, test_date, test_data, status, notes, created_by) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [id, entry.product_type_id, entry.memo_id, entry.plant_id, entry.officer_id,
           entry.test_date, JSON.stringify(entry.test_data), entry.status, entry.notes, entry.created_by]
        );
        
        if (result.success && entry.memo_id) {
          // Update memo status and test assignment
          await this.updateMemoTestAssignment(entry.memo_id, entry.product_type_id, id);
        }
        
        return result.success ? id : null;
      } else {
        const response = await fetch(`${this.baseUrl}/entries`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(entry)
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        return result.id;
      }
    } catch (error) {
      console.error('Failed to create test entry:', error);
      return null;
    }
  }

  // Plant Configuration Management
  static async getPlantConfigurations(): Promise<PlantConfiguration[]> {
    try {
      if (this.isElectron) {
        const plantsResult = await window.electronAPI.dbQuery(
          `SELECT * FROM plant_configurations WHERE is_active = 1 ORDER BY name`
        );
        
        if (!plantsResult.success) return [];
        
        const plants = await Promise.all(plantsResult.data.map(async (plant: any) => {
          const [machinesResult, officersResult] = await Promise.all([
            window.electronAPI.dbQuery(`SELECT * FROM plant_machines WHERE plant_id = ? AND is_active = 1`, [plant.id]),
            window.electronAPI.dbQuery(`SELECT * FROM plant_officers WHERE plant_id = ? AND is_active = 1`, [plant.id])
          ]);
          
          return {
            ...plant,
            contact_info: JSON.parse(plant.contact_info || '{}'),
            machines: machinesResult.success ? machinesResult.data.map((m: any) => ({
              ...m,
              specifications: JSON.parse(m.specifications || '{}')
            })) : [],
            officers: officersResult.success ? officersResult.data.map((o: any) => ({
              ...o,
              contact_info: JSON.parse(o.contact_info || '{}')
            })) : []
          };
        }));
        
        return plants;
      } else {
        const response = await fetch(`${this.baseUrl}/plants`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get plant configurations:', error);
      return [];
    }
  }

  // Memo Test Assignments
  static async getMemoTestAssignments(filters: {
    memoId?: string;
    assignedTo?: string;
    status?: string;
  } = {}): Promise<MemoTestAssignment[]> {
    try {
      if (this.isElectron) {
        let query = `SELECT * FROM memo_test_assignments WHERE 1=1`;
        const params: any[] = [];

        if (filters.memoId) {
          query += ` AND memo_id = ?`;
          params.push(filters.memoId);
        }
        if (filters.assignedTo) {
          query += ` AND assigned_to = ?`;
          params.push(filters.assignedTo);
        }
        if (filters.status) {
          query += ` AND status = ?`;
          params.push(filters.status);
        }

        query += ` ORDER BY due_date ASC, created_at DESC`;

        const result = await window.electronAPI.dbQuery(query, params);
        return result.success ? result.data.map((assignment: any) => ({
          ...assignment,
          required_tests: JSON.parse(assignment.required_tests || '[]')
        })) : [];
      } else {
        const searchParams = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value) searchParams.append(key, value);
        });
        
        const response = await fetch(`${this.baseUrl}/memo-assignments?${searchParams}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      }
    } catch (error) {
      console.error('Failed to get memo test assignments:', error);
      return [];
    }
  }

  // Utility Methods
  private static async createTestDataTable(tableSuffix: string): Promise<boolean> {
    try {
      if (this.isElectron) {
        const tableName = `test_data_${tableSuffix}`;
        const result = await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS ${tableName} (
            id TEXT PRIMARY KEY,
            test_entry_id TEXT NOT NULL,
            field_data JSON NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (test_entry_id) REFERENCES test_entries(id)
          )
        `);
        return result.success;
      }
      return true; // API will handle table creation
    } catch (error) {
      console.error('Failed to create test data table:', error);
      return false;
    }
  }

  private static async updateMemoTestAssignment(memoId: string, productTypeId: string, testEntryId: string): Promise<void> {
    try {
      if (this.isElectron) {
        await window.electronAPI.dbQuery(
          `UPDATE memo_test_assignments 
           SET status = 'completed', test_entry_id = ?, updated_at = CURRENT_TIMESTAMP
           WHERE memo_id = ? AND product_type_id = ?`,
          [testEntryId, memoId, productTypeId]
        );
      }
    } catch (error) {
      console.error('Failed to update memo test assignment:', error);
    }
  }

  private static getDefaultCategories(): ProductCategory[] {
    return [
      {
        id: 'aggregates',
        name: 'Aggregates',
        description: 'Sand, gravel, and crushed stone testing',
        icon: 'TestTube',
        sort_order: 1,
        is_active: true,
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'concrete',
        name: 'Concrete',
        description: 'Concrete mix and cube testing',
        icon: 'Building',
        sort_order: 2,
        is_active: true,
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'blocks',
        name: 'Blocks',
        description: 'Concrete block testing',
        icon: 'Package2',
        sort_order: 3,
        is_active: true,
        created_by: 'system',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ];
  }

  // Validation helpers
  static validateField(value: any, field: ProductField): { isValid: boolean; message?: string } {
    if (field.is_required && (value === null || value === undefined || value === '')) {
      return { isValid: false, message: `${field.field_label} is required` };
    }

    for (const rule of field.validation_rules) {
      switch (rule.type) {
        case 'min':
          if (field.field_type === 'number' && parseFloat(value) < rule.value) {
            return { isValid: false, message: rule.message };
          }
          break;
        case 'max':
          if (field.field_type === 'number' && parseFloat(value) > rule.value) {
            return { isValid: false, message: rule.message };
          }
          break;
        case 'pattern':
          if (field.field_type === 'text' && !new RegExp(rule.value).test(value)) {
            return { isValid: false, message: rule.message };
          }
          break;
      }
    }

    return { isValid: true };
  }
}