// Core data types for the laboratory management system
export interface Memo {
  id: string;
  ref: string;
  created_at: string;
  production_data?: ProductionData[];
  user_id?: string;
}

export interface ProductionData {
  productionNumber: string;
  productionDate?: string;
  testDate?: string;
  age?: string;
  product?: string;
  grade?: string;
  machineNo?: string;
  mouldRef?: string;
  blockPositions?: string[];
  numberOfSamples?: string;
  blockPositionNumbers?: string[];
  remarks?: string;
  officer?: string;
  site?: string;
  typeOfTest?: string;
  [key: string]: unknown;
}

export interface TestRequest {
  id: string;
  client_name: string;
  sample_description: string;
  test_type: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  assigned_to?: string;
  due_date?: string;
  created_at: string;
  updated_at: string;
  user_id?: string;
}

export interface UserProfile {
  id: string;
  user_id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  status: 'active' | 'inactive';
  last_login?: string;
  created_at: string;
  updated_at: string;
}

export interface UserRole {
  id: string;
  name: string;
  description: string;
  permissions: string[];
  created_at: string;
  updated_at: string;
}

export interface AnalyticsData {
  totalTests: number;
  completedTests: number;
  pendingTests: number;
  activeUsers: number;
  completionRate: number;
}

// Module and Plugin System Types
export interface ModuleConfig {
  name: string;
  version: string;
  description: string;
  author: string;
  license?: string;
  dependencies: string[];
  tags: string[];
  category: 'testing' | 'dashboard' | 'reports' | 'workflow' | 'utility';
  permissions: string[];
  minAppVersion: string;
}

export interface ModuleSchema {
  tables: Array<{
    name: string;
    columns: Array<{
      name: string;
      type: string;
      required: boolean;
      default?: unknown;
      validation?: string;
    }>;
    relationships?: Array<{
      type: '1:1' | '1:N' | 'N:N';
      table: string;
      foreignKey: string;
    }>;
  }>;
  views?: Array<{
    name: string;
    query: string;
  }>;
}

export interface ModuleComponent {
  name: string;
  type: 'form' | 'list' | 'detail' | 'dashboard' | 'widget' | 'modal';
  path: string;
  permissions: string[];
  props?: Record<string, unknown>;
}

export interface ModuleLogic {
  calculations?: Record<string, string>;
  validations?: Record<string, string>;
  workflows?: Array<{
    name: string;
    steps: Array<{
      id: string;
      type: string;
      config: Record<string, unknown>;
    }>;
  }>;
}

export interface Module {
  id: string;
  config: ModuleConfig;
  schema: ModuleSchema;
  components: ModuleComponent[];
  logic: ModuleLogic;
  enabled: boolean;
  installed_at: string;
  updated_at: string;
  data_version: string;
}

export interface ModuleInstance {
  id: string;
  module_id: string;
  name: string;
  configuration: Record<string, unknown>;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface ModuleMarketplace {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  downloads: number;
  rating: number;
  category: string;
  price: number;
  screenshots: string[];
  documentation_url: string;
  source_url?: string;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  totalPages: number;
}

// Filter and query types
export interface QueryOptions {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  filters?: Record<string, unknown>;
}

// Phase 6: Advanced Data Features Types

// Validation Rules Engine
export interface ValidationRule {
  id: string;
  name: string;
  description: string;
  table_name: string;
  field_name: string;
  rule_type: 'threshold' | 'cross_field' | 'formula' | 'pattern';
  configuration: {
    min_value?: number;
    max_value?: number;
    related_fields?: string[];
    formula?: string;
    pattern?: string;
    error_message?: string;
    warning_message?: string;
  };
  severity: 'error' | 'warning' | 'info';
  active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ValidationResult {
  id: string;
  rule_id: string;
  record_id: string;
  table_name: string;
  field_name: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
  actual_value: unknown;
  expected_value?: unknown;
  validated_at: string;
}

// Smart Date Calculator
export interface TestSchedule {
  id: string;
  test_type: string;
  sample_id: string;
  scheduled_date: string;
  due_date: string;
  age_days: number;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'scheduled' | 'pending' | 'completed' | 'overdue';
  auto_generated: boolean;
  parent_schedule_id?: string;
  notification_sent: boolean;
  assigned_to?: string;
  created_at: string;
  updated_at: string;
}

export interface ScheduleTemplate {
  id: string;
  name: string;
  test_type: string;
  schedule_pattern: {
    intervals: number[]; // e.g., [7, 28] for 7-day and 28-day tests
    unit: 'days' | 'weeks' | 'months';
    working_days_only: boolean;
    exclude_holidays: boolean;
  };
  auto_create: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

// Linked Table Views
export interface TableRelationship {
  id: string;
  parent_table: string;
  child_table: string;
  relationship_type: '1:1' | '1:N' | 'N:N';
  foreign_key: string;
  display_field: string;
  filter_conditions?: Record<string, unknown>;
  sort_order?: {
    field: string;
    direction: 'asc' | 'desc';
  };
  active: boolean;
}

export interface NavigationPath {
  table: string;
  record_id: string;
  display_name: string;
  filters?: Record<string, unknown>;
}

// Version Control System
export interface DataVersion {
  id: string;
  table_name: string;
  record_id: string;
  version_number: number;
  data_snapshot: Record<string, unknown>;
  change_type: 'create' | 'update' | 'delete';
  changed_fields: string[];
  change_summary: string;
  created_by: string;
  created_at: string;
  approved_by?: string;
  approved_at?: string;
  status: 'draft' | 'pending_approval' | 'approved' | 'rejected';
  parent_version_id?: string;
}

export interface ChangeRequest {
  id: string;
  table_name: string;
  record_id: string;
  requested_changes: Record<string, unknown>;
  current_data: Record<string, unknown>;
  change_reason: string;
  business_justification: string;
  impact_assessment: string;
  requested_by: string;
  requested_at: string;
  reviewed_by?: string;
  reviewed_at?: string;
  status: 'pending' | 'approved' | 'rejected' | 'implemented';
  reviewer_comments?: string;
}

export interface ApprovalWorkflow {
  id: string;
  name: string;
  table_name: string;
  approval_levels: {
    level: number;
    required_role: string;
    auto_approve_conditions?: Record<string, unknown>;
  }[];
  notification_settings: {
    notify_on_request: boolean;
    notify_on_approval: boolean;
    notify_on_rejection: boolean;
    escalation_hours?: number;
  };
  active: boolean;
  created_at: string;
  updated_at: string;
}