import type { IDataService } from './interface';
import type { 
  Memo, 
  TestRequest, 
  UserProfile, 
  UserRole, 
  AnalyticsData, 
  ApiResponse, 
  PaginatedResponse, 
  QueryOptions,
  Module,
  ModuleInstance,
  ModuleMarketplace,
  ValidationRule,
  ValidationResult,
  TestSchedule,
  ScheduleTemplate,
  TableRelationship,
  NavigationPath,
  DataVersion,
  ChangeRequest,
  ApprovalWorkflow
} from './types';

// Mock data removed - using empty arrays for clean state
const mockMemos: Memo[] = [];
const mockTestRequests: TestRequest[] = [];
const mockUserProfiles: UserProfile[] = [];
const mockUserRoles: UserRole[] = [];

export class MockDataService implements IDataService {
  // Memo operations
  async getMemos(options: QueryOptions = {}): Promise<PaginatedResponse<Memo>> {
    const { page = 1, limit = 10 } = options;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedData = mockMemos.slice(startIndex, endIndex);

    return {
      data: paginatedData,
      count: mockMemos.length,
      page,
      totalPages: Math.ceil(mockMemos.length / limit)
    };
  }

  async getMemoById(id: string): Promise<ApiResponse<Memo>> {
    const memo = mockMemos.find(m => m.id === id);
    return memo ? { data: memo } : { data: null, error: 'Memo not found' };
  }

  async createMemo(memo: Omit<Memo, 'id' | 'created_at'>): Promise<ApiResponse<Memo>> {
    const newMemo: Memo = {
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      ...memo
    };
    mockMemos.push(newMemo);
    return { data: newMemo };
  }

  async updateMemo(id: string, memo: Partial<Memo>): Promise<ApiResponse<Memo>> {
    const index = mockMemos.findIndex(m => m.id === id);
    if (index === -1) {
      return { data: null, error: 'Memo not found' };
    }
    mockMemos[index] = { ...mockMemos[index], ...memo };
    return { data: mockMemos[index] };
  }

  async deleteMemo(id: string): Promise<ApiResponse<boolean>> {
    const index = mockMemos.findIndex(m => m.id === id);
    if (index === -1) {
      return { data: false, error: 'Memo not found' };
    }
    mockMemos.splice(index, 1);
    return { data: true };
  }

  // Test Request operations
  async getTestRequests(options: QueryOptions = {}): Promise<PaginatedResponse<TestRequest>> {
    const { page = 1, limit = 10 } = options;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedData = mockTestRequests.slice(startIndex, endIndex);

    return {
      data: paginatedData,
      count: mockTestRequests.length,
      page,
      totalPages: Math.ceil(mockTestRequests.length / limit)
    };
  }

  async getTestRequestById(id: string): Promise<ApiResponse<TestRequest>> {
    const request = mockTestRequests.find(r => r.id === id);
    return request ? { data: request } : { data: null, error: 'Test request not found' };
  }

  async createTestRequest(testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestRequest>> {
    const newRequest: TestRequest = {
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...testRequest
    };
    mockTestRequests.push(newRequest);
    return { data: newRequest };
  }

  async updateTestRequest(id: string, testRequest: Partial<TestRequest>): Promise<ApiResponse<TestRequest>> {
    const index = mockTestRequests.findIndex(r => r.id === id);
    if (index === -1) {
      return { data: null, error: 'Test request not found' };
    }
    mockTestRequests[index] = { ...mockTestRequests[index], ...testRequest, updated_at: new Date().toISOString() };
    return { data: mockTestRequests[index] };
  }

  async deleteTestRequest(id: string): Promise<ApiResponse<boolean>> {
    const index = mockTestRequests.findIndex(r => r.id === id);
    if (index === -1) {
      return { data: false, error: 'Test request not found' };
    }
    mockTestRequests.splice(index, 1);
    return { data: true };
  }

  // User Profile operations
  async getUserProfiles(options: QueryOptions = {}): Promise<PaginatedResponse<UserProfile>> {
    const { page = 1, limit = 10 } = options;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedData = mockUserProfiles.slice(startIndex, endIndex);

    return {
      data: paginatedData,
      count: mockUserProfiles.length,
      page,
      totalPages: Math.ceil(mockUserProfiles.length / limit)
    };
  }

  async getUserProfileById(id: string): Promise<ApiResponse<UserProfile>> {
    const profile = mockUserProfiles.find(p => p.id === id);
    return profile ? { data: profile } : { data: null, error: 'Profile not found' };
  }

  async createUserProfile(profile: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserProfile>> {
    const newProfile: UserProfile = {
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...profile
    };
    mockUserProfiles.push(newProfile);
    return { data: newProfile };
  }

  async updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<ApiResponse<UserProfile>> {
    const index = mockUserProfiles.findIndex(p => p.id === id);
    if (index === -1) {
      return { data: null, error: 'Profile not found' };
    }
    mockUserProfiles[index] = { ...mockUserProfiles[index], ...profile, updated_at: new Date().toISOString() };
    return { data: mockUserProfiles[index] };
  }

  async deleteUserProfile(id: string): Promise<ApiResponse<boolean>> {
    const index = mockUserProfiles.findIndex(p => p.id === id);
    if (index === -1) {
      return { data: false, error: 'Profile not found' };
    }
    mockUserProfiles.splice(index, 1);
    return { data: true };
  }

  // User Role operations
  async getUserRoles(): Promise<ApiResponse<UserRole[]>> {
    return { data: mockUserRoles };
  }

  async getUserRoleById(id: string): Promise<ApiResponse<UserRole>> {
    const role = mockUserRoles.find(r => r.id === id);
    return role ? { data: role } : { data: null, error: 'Role not found' };
  }

  async createUserRole(role: Omit<UserRole, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserRole>> {
    const newRole: UserRole = {
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...role
    };
    mockUserRoles.push(newRole);
    return { data: newRole };
  }

  async updateUserRole(id: string, role: Partial<UserRole>): Promise<ApiResponse<UserRole>> {
    const index = mockUserRoles.findIndex(r => r.id === id);
    if (index === -1) {
      return { data: null, error: 'Role not found' };
    }
    mockUserRoles[index] = { ...mockUserRoles[index], ...role, updated_at: new Date().toISOString() };
    return { data: mockUserRoles[index] };
  }

  async deleteUserRole(id: string): Promise<ApiResponse<boolean>> {
    const index = mockUserRoles.findIndex(r => r.id === id);
    if (index === -1) {
      return { data: false, error: 'Role not found' };
    }
    mockUserRoles.splice(index, 1);
    return { data: true };
  }

  // Analytics operations
  async getAnalyticsData(): Promise<ApiResponse<AnalyticsData>> {
    return {
      data: {
        totalTests: mockTestRequests.length,
        completedTests: mockTestRequests.filter(r => r.status === 'completed').length,
        pendingTests: mockTestRequests.filter(r => r.status === 'pending').length,
        activeUsers: mockUserProfiles.filter(p => p.status === 'active').length,
        completionRate: 75.5
      }
    };
  }

  async getMonthlyTestData(): Promise<ApiResponse<any[]>> {
    return { data: [] };
  }

  async getTestTypeDistribution(): Promise<ApiResponse<any[]>> {
    return { data: [] };
  }

  async getCurrentUser(): Promise<ApiResponse<UserProfile | null>> {
    return { data: mockUserProfiles[0] || null };
  }

  // Module operations - mock implementations
  async getModules(): Promise<PaginatedResponse<Module>> {
    return { data: [], count: 0, page: 1, totalPages: 1 };
  }

  async getModuleById(id: string): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Module not found' };
  }

  async installModule(moduleData: any): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  async uninstallModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented in mock service' };
  }

  async enableModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented in mock service' };
  }

  async disableModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented in mock service' };
  }

  async updateModule(id: string, updates: Partial<Module>): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  async getModuleInstances(moduleId?: string): Promise<ApiResponse<ModuleInstance[]>> {
    return { data: [] };
  }

  async createModuleInstance(instance: Omit<ModuleInstance, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ModuleInstance>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  async updateModuleInstance(id: string, updates: Partial<ModuleInstance>): Promise<ApiResponse<ModuleInstance>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  async deleteModuleInstance(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented in mock service' };
  }

  async getMarketplaceModules(): Promise<PaginatedResponse<ModuleMarketplace>> {
    return { data: [], count: 0, page: 1, totalPages: 1 };
  }

  async downloadModule(marketplaceId: string): Promise<ApiResponse<any>> {
    return { data: null, error: 'Not implemented in mock service' };
  }

  async exportModule(id: string): Promise<ApiResponse<Blob>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  async importModule(file: File): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Not implemented in mock service' };
  }

  // Phase 6: Advanced Data Features
  async getValidationRules(options?: QueryOptions): Promise<PaginatedResponse<ValidationRule>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getValidationRuleById(id: string): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async createValidationRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async updateValidationRule(id: string, rule: Partial<ValidationRule>): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async deleteValidationRule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented' };
  }

  async validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ApiResponse<ValidationResult[]>> {
    return { data: [] };
  }

  async getValidationResults(options?: QueryOptions): Promise<PaginatedResponse<ValidationResult>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getTestSchedules(options?: QueryOptions): Promise<PaginatedResponse<TestSchedule>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createTestSchedule(schedule: Omit<TestSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestSchedule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async generateSchedulesFromTemplate(templateId: string, sampleIds: string[]): Promise<ApiResponse<TestSchedule[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getScheduleTemplates(): Promise<ApiResponse<ScheduleTemplate[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async createScheduleTemplate(template: Omit<ScheduleTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async updateScheduleTemplate(id: string, template: Partial<ScheduleTemplate>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async getTableRelationships(tableName?: string): Promise<ApiResponse<TableRelationship[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getRelatedRecords(tableName: string, recordId: string, relationship: string): Promise<ApiResponse<any[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getNavigationPath(tableName: string, recordId: string): Promise<ApiResponse<NavigationPath[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getDataVersions(tableName: string, recordId: string): Promise<ApiResponse<DataVersion[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async createDataVersion(version: Omit<DataVersion, 'id' | 'created_at'>): Promise<ApiResponse<DataVersion>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async compareVersions(versionId1: string, versionId2: string): Promise<ApiResponse<any>> {
    return { data: null, error: 'Not implemented' };
  }

  async rollbackToVersion(versionId: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented' };
  }

  async getChangeRequests(options?: QueryOptions): Promise<PaginatedResponse<ChangeRequest>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createChangeRequest(request: Omit<ChangeRequest, 'id' | 'requested_at'>): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async approveChangeRequest(requestId: string, comments?: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async rejectChangeRequest(requestId: string, comments: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async getApprovalWorkflows(): Promise<ApiResponse<ApprovalWorkflow[]>> {
    return { data: [], error: 'Not implemented' };
  }

  // Reference Dataset operations
  async uploadReferenceDataset(tableName: string, csvData: any[]): Promise<{ success: boolean; rowsInserted: number; error?: string }> {
    return { success: false, rowsInserted: 0, error: 'Not implemented in mock service' };
  }

  async getReferenceData(tableName: string, activeOnly?: boolean): Promise<any[]> {
    return [];
  }

  async getFilteredSamplingPlaces(productType: string): Promise<any[]> {
    return [];
  }

  // Required interface methods
  async createAuditLog(entry: any): Promise<ApiResponse<any>> { return { data: entry }; }
  async getAuditLogs(filters?: any): Promise<any[]> { return []; }
  async getTables(): Promise<string[]> { return ['memos', 'test_requests', 'user_profiles']; }
  async getTableSchema(tableName: string): Promise<any> { return null; }
  async executeSQL(sql: string): Promise<any> { return {}; }
  async createDataRelationship(relationship: any): Promise<ApiResponse<any>> { return { data: relationship }; }
  async deleteDataRelationship(id: string): Promise<ApiResponse<boolean>> { return { data: true }; }
  async getDataRelationships(): Promise<any[]> { return []; }
  async getUserProfile(id: string): Promise<ApiResponse<UserProfile>> { return { data: null as any, error: 'Not implemented' }; }
  async createValidationResult(result: any): Promise<ApiResponse<any>> { return { data: result }; }
}