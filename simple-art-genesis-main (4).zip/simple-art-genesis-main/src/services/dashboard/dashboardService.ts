export interface DashboardData {
  totalMemos: number;
  testsToday: number;
  failureRate: number;
  pendingRetests: number;
  mostTestedProduct: string;
  activeUsers: number;
  monthlyTrends: Array<{ name: string; value: number }>;
  testStatusDistribution: Array<{ name: string; value: number }>;
  upcomingCalendar: Array<{ date: string; tests: number }>;
}

export interface DashboardLayout {
  id: string;
  user_id: string;
  name: string;
  widgets: DashboardWidget[];
  locked: boolean;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

import type { DashboardWidget } from '@/types/dashboard';

class DashboardService {
  private isElectron = typeof window !== 'undefined' && window.electronAPI;

  async initializeTables(): Promise<void> {
    if (!this.isElectron) return;
    
    try {
      const createLayoutsTable = `
        CREATE TABLE IF NOT EXISTS dashboard_layouts (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          widgets TEXT NOT NULL,
          locked INTEGER DEFAULT 0,
          is_default INTEGER DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `;
      
      await window.electronAPI.dbRun(createLayoutsTable);
    } catch (error) {
      console.error('Error initializing dashboard tables:', error);
    }
  }

  async getUserLayouts(userId: string): Promise<DashboardLayout[]> {
    if (!this.isElectron) {
      return this.getLayoutsFromLocalStorage(userId);
    }

    try {
      await this.initializeTables();
      
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM dashboard_layouts WHERE user_id = ? ORDER BY created_at DESC',
        [userId]
      );
      
      if (result.success) {
        return result.data.map(this.mapRowToLayout);
      }
      
      return [];
    } catch (error) {
      console.error('Error loading dashboard layouts:', error);
      return this.getLayoutsFromLocalStorage(userId);
    }
  }

  async saveLayout(layout: DashboardLayout): Promise<void> {
    if (!this.isElectron) {
      this.saveLayoutToLocalStorage(layout);
      return;
    }

    try {
      await this.initializeTables();
      
      const sql = `
        INSERT OR REPLACE INTO dashboard_layouts 
        (id, user_id, name, widgets, locked, is_default, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      await window.electronAPI.dbRun(sql, [
        layout.id,
        layout.user_id,
        layout.name,
        JSON.stringify(layout.widgets),
        layout.locked ? 1 : 0,
        layout.is_default ? 1 : 0,
        layout.created_at,
        layout.updated_at
      ]);
    } catch (error) {
      console.error('Error saving dashboard layout:', error);
      this.saveLayoutToLocalStorage(layout);
    }
  }

  async getCurrentLayout(userId: string): Promise<DashboardLayout | null> {
    const layouts = await this.getUserLayouts(userId);
    
    // Return default layout or first layout if any exist
    const defaultLayout = layouts.find(l => l.is_default);
    if (defaultLayout) return defaultLayout;
    
    return layouts.length > 0 ? layouts[0] : null;
  }

  async addWidget(userId: string, layoutId: string, widget: DashboardWidget): Promise<void> {
    const layouts = await this.getUserLayouts(userId);
    const layout = layouts.find(l => l.id === layoutId);
    
    if (!layout) {
      throw new Error('Layout not found');
    }

    // Add or update widget
    const existingIndex = layout.widgets.findIndex(w => w.id === widget.id);
    if (existingIndex >= 0) {
      layout.widgets[existingIndex] = widget;
    } else {
      layout.widgets.push(widget);
    }
    
    layout.updated_at = new Date().toISOString();
    await this.saveLayout(layout);
  }

  async removeWidget(userId: string, layoutId: string, widgetId: string): Promise<void> {
    const layouts = await this.getUserLayouts(userId);
    const layout = layouts.find(l => l.id === layoutId);
    
    if (!layout) {
      throw new Error('Layout not found');
    }

    layout.widgets = layout.widgets.filter(w => w.id !== widgetId);
    layout.updated_at = new Date().toISOString();
    await this.saveLayout(layout);
  }

  async updateWidgetPositions(userId: string, layoutId: string, widgets: DashboardWidget[]): Promise<void> {
    const layouts = await this.getUserLayouts(userId);
    const layout = layouts.find(l => l.id === layoutId);
    
    if (!layout) {
      throw new Error('Layout not found');
    }

    layout.widgets = widgets;
    layout.updated_at = new Date().toISOString();
    await this.saveLayout(layout);
  }

  private getLayoutsFromLocalStorage(userId: string): DashboardLayout[] {
    try {
      const saved = localStorage.getItem(`dashboard_layouts_${userId}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  }

  private saveLayoutToLocalStorage(layout: DashboardLayout): void {
    try {
      const userId = layout.user_id;
      const existing = this.getLayoutsFromLocalStorage(userId);
      const updated = existing.filter(l => l.id !== layout.id);
      updated.push(layout);
      
      localStorage.setItem(`dashboard_layouts_${userId}`, JSON.stringify(updated));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  }

  private mapRowToLayout(row: any): DashboardLayout {
    return {
      id: row.id,
      user_id: row.user_id,
      name: row.name,
      widgets: JSON.parse(row.widgets || '[]'),
      locked: Boolean(row.locked),
      is_default: Boolean(row.is_default),
      created_at: row.created_at,
      updated_at: row.updated_at
    };
  }
}

export const dashboardService = new DashboardService();