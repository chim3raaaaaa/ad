// Local authentication service for offline app
import bcrypt from 'bcryptjs';

export interface LocalUser {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  role: string;
  status: 'active' | 'inactive';
  department: string;
  last_login?: string;
  created_at: string;
  updated_at: string;
}

export interface LocalRole {
  name: string;
  description: string;
  permissions: string[];
  color: string;
}

export interface AuthSession {
  user: LocalUser;
  token: string;
  expires_at: string;
}

class LocalAuthService {
  private currentSession: AuthSession | null = null;
  private sessionKey = 'lab-auth-session';

  constructor() {
    this.loadSession();
    this.initializeUsers();
    this.initializeRoles();
  }

  // Load existing session from localStorage
  private loadSession() {
    try {
      const saved = localStorage.getItem(this.sessionKey);
      if (saved) {
        const session = JSON.parse(saved);
        // Check if session is expired
        if (new Date(session.expires_at) > new Date()) {
          this.currentSession = session;
        } else {
          this.clearSession();
        }
      }
    } catch (error) {
      console.error('Failed to load session:', error);
      this.clearSession();
    }
  }

  // Save session to localStorage
  private saveSession(session: AuthSession) {
    localStorage.setItem(this.sessionKey, JSON.stringify(session));
    this.currentSession = session;
  }

  // Clear session
  private clearSession() {
    localStorage.removeItem(this.sessionKey);
    this.currentSession = null;
  }

  // Generate simple token
  private generateToken(): string {
    return btoa(Math.random().toString(36).substring(2) + Date.now().toString(36));
  }

  // Hash password
  async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 10);
  }

  // Verify password
  async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  // Login
  async login(email: string, password: string): Promise<{ success: boolean; user?: LocalUser; error?: string }> {
    try {
      const users = this.getUsers();
      const user = users.find(u => u.email === email && u.status === 'active');
      
      if (!user) {
        return { success: false, error: 'Invalid email or password' };
      }

      const isValid = await this.verifyPassword(password, user.password_hash);
      if (!isValid) {
        return { success: false, error: 'Invalid email or password' };
      }

      // Update last login
      user.last_login = new Date().toISOString();
      this.updateUser(user.id, { last_login: user.last_login });

      // Create session
      const session: AuthSession = {
        user,
        token: this.generateToken(),
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
      };

      this.saveSession(session);
      return { success: true, user };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Login failed' };
    }
  }

  // Logout
  logout() {
    this.clearSession();
  }

  // Get current user
  getCurrentUser(): LocalUser | null {
    return this.currentSession?.user || null;
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return this.currentSession !== null;
  }

  // Get users from localStorage
  private getUsers(): LocalUser[] {
    try {
      const saved = localStorage.getItem('lab-users-db');
      return saved ? JSON.parse(saved) : this.getDefaultUsers();
    } catch {
      return this.getDefaultUsers();
    }
  }

  // Save users to localStorage
  private saveUsers(users: LocalUser[]) {
    localStorage.setItem('lab-users-db', JSON.stringify(users));
  }

  // Update user
  private updateUser(id: string, updates: Partial<LocalUser>) {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
      users[index] = { ...users[index], ...updates, updated_at: new Date().toISOString() };
      this.saveUsers(users);
    }
  }

  // Get default users with hashed passwords
  private getDefaultUsers(): LocalUser[] {
    const now = new Date().toISOString();
    return [
      {
        id: 'user-admin',
        name: 'System Administrator',
        email: 'admin@lab.local',
        password_hash: bcrypt.hashSync('admin123', 10), // Default password
        role: 'admin',
        status: 'active',
        department: 'Administration',
        created_at: now,
        updated_at: now
      },
      {
        id: 'user-manager',
        name: 'Dr. Sarah Johnson',
        email: 'sarah@lab.local',
        password_hash: bcrypt.hashSync('manager123', 10),
        role: 'lab_manager',
        status: 'active',
        department: 'Quality Control',
        created_at: now,
        updated_at: now
      },
      {
        id: 'user-tech1',
        name: 'John Smith',
        email: 'john@lab.local',
        password_hash: bcrypt.hashSync('tech123', 10),
        role: 'senior_technician',
        status: 'active',
        department: 'Testing',
        created_at: now,
        updated_at: now
      }
    ];
  }

  // Initialize default users
  initializeUsers() {
    const existing = localStorage.getItem('lab-users-db');
    if (!existing) {
      this.saveUsers(this.getDefaultUsers());
    }
  }

  // User management methods
  async createUser(userData: Omit<LocalUser, 'id' | 'password_hash' | 'created_at' | 'updated_at'>, password: string): Promise<LocalUser> {
    const users = this.getUsers();
    const now = new Date().toISOString();
    
    const newUser: LocalUser = {
      ...userData,
      id: `user-${Date.now()}`,
      password_hash: await this.hashPassword(password),
      created_at: now,
      updated_at: now
    };

    users.push(newUser);
    this.saveUsers(users);
    return newUser;
  }

  getAllUsers(): LocalUser[] {
    return this.getUsers();
  }

  getUserById(id: string): LocalUser | undefined {
    return this.getUsers().find(u => u.id === id);
  }

  async updateUserById(id: string, updates: Partial<LocalUser>, newPassword?: string): Promise<boolean> {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === id);
    
    if (index === -1) return false;

    const updateData = { ...updates, updated_at: new Date().toISOString() };
    
    if (newPassword) {
      updateData.password_hash = await this.hashPassword(newPassword);
    }

    users[index] = { ...users[index], ...updateData };
    this.saveUsers(users);
    return true;
  }

  deleteUserById(id: string): boolean {
    const users = this.getUsers();
    const filtered = users.filter(u => u.id !== id);
    if (filtered.length < users.length) {
      this.saveUsers(filtered);
      return true;
    }
    return false;
  }

  // Role management
  getRoles(): LocalRole[] {
    try {
      const saved = localStorage.getItem('lab-roles-db');
      return saved ? JSON.parse(saved) : this.getDefaultRoles();
    } catch {
      return this.getDefaultRoles();
    }
  }

  private getDefaultRoles(): LocalRole[] {
    return [
      {
        name: 'admin',
        description: 'Full system access with all permissions',
        permissions: [
          'system.full_access',
          'system.developer_mode',
          'system.advanced_features',
          'users.view', 'users.create', 'users.edit', 'users.delete',
          'roles.view', 'roles.create', 'roles.edit', 'roles.delete',
          'tests.view', 'tests.create', 'tests.edit', 'tests.approve',
          'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
          'reports.view', 'reports.generate', 'reports.export',
          'modules.view', 'modules.install', 'modules.configure',
          'settings.view', 'settings.edit', 'settings.password_policy'
        ],
        color: 'bg-blue-500/20 text-blue-700 border-blue-500/30'
      },
      {
        name: 'lab_manager',
        description: 'Laboratory management with approval rights',
        permissions: [
          'users.view', 'users.edit',
          'tests.view', 'tests.create', 'tests.edit', 'tests.approve',
          'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
          'reports.view', 'reports.generate', 'reports.export',
          'settings.view', 'settings.password_policy'
        ],
        color: 'bg-purple-500/20 text-purple-700 border-purple-500/30'
      },
      {
        name: 'senior_technician',
        description: 'Advanced testing operations and reporting',
        permissions: [
          'tests.view', 'tests.create', 'tests.edit',
          'memos.view', 'memos.create', 'memos.edit',
          'reports.view', 'reports.generate'
        ],
        color: 'bg-orange-500/20 text-orange-700 border-orange-500/30'
      },
      {
        name: 'technician',
        description: 'Basic testing operations',
        permissions: [
          'tests.view', 'tests.create',
          'memos.view', 'memos.create',
          'reports.view'
        ],
        color: 'bg-gray-500/20 text-gray-700 border-gray-500/30'
      }
    ];
  }

  initializeRoles() {
    // Always refresh roles to ensure latest permissions are loaded
    localStorage.setItem('lab-roles-db', JSON.stringify(this.getDefaultRoles()));
  }

  // Permission checking
  userHasPermission(userId: string, permission: string): boolean {
    const user = this.getUserById(userId);
    if (!user) return false;

    const roles = this.getRoles();
    const userRole = roles.find(r => r.name === user.role);
    
    return userRole?.permissions.includes(permission) || userRole?.permissions.includes('system.full_access') || false;
  }

  getCurrentUserPermissions(): string[] {
    const user = this.getCurrentUser();
    if (!user) return [];

    const roles = this.getRoles();
    const userRole = roles.find(r => r.name === user.role);
    return userRole?.permissions || [];
  }

  // Check if current user has permission
  hasPermission(permission: string): boolean {
    const user = this.getCurrentUser();
    return user ? this.userHasPermission(user.id, permission) : false;
  }
}

export const localAuthService = new LocalAuthService();