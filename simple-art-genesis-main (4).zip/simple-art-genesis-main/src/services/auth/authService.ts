// Local authentication service using browser storage
import type { UserProfile } from '../api/types';

export interface AuthUser {
  id: string;
  email: string;
  full_name?: string;
  username?: string;
}

export interface AuthSession {
  user: AuthUser;
  access_token: string;
  expires_at: number;
}

class BrowserAuthService {
  private currentSession: AuthSession | null = null;
  private listeners: ((session: AuthSession | null) => void)[] = [];
  private storage: IDBDatabase | null = null;

  constructor() {
    this.initDB();
    this.loadSession();
  }

  private async initDB(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('LabManagementDB', 1);
      request.onsuccess = () => {
        this.storage = request.result;
        resolve();
      };
      request.onerror = () => reject(request.error);
    });
  }

  private loadSession(): void {
    try {
      const stored = localStorage.getItem('auth_session');
      if (stored) {
        const session = JSON.parse(stored);
        if (session.expires_at > Date.now()) {
          this.currentSession = session;
        } else {
          localStorage.removeItem('auth_session');
        }
      }
    } catch (error) {
      console.error('Error loading session:', error);
      localStorage.removeItem('auth_session');
    }
  }

  private saveSession(session: AuthSession | null): void {
    if (session) {
      localStorage.setItem('auth_session', JSON.stringify(session));
    } else {
      localStorage.removeItem('auth_session');
    }
    this.currentSession = session;
    this.notifyListeners();
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener(this.currentSession));
  }

  private generateToken(): string {
    return 'local_token_' + Math.random().toString(36).substr(2) + Date.now().toString(36);
  }

  private async getUserFromDB(email: string): Promise<any> {
    if (!this.storage) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const tx = this.storage!.transaction('users', 'readonly');
      const store = tx.objectStore('users');
      const request = store.getAll();
      
      request.onsuccess = () => {
        const users = request.result;
        const user = users.find(u => u.email === email);
        resolve(user);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async signIn(email: string, password: string): Promise<{ session: AuthSession | null; error: string | null }> {
    try {
      // Simple demo authentication - in production use proper password hashing
      if (email === 'admin@lab.local' && password === 'admin123') {
        const session: AuthSession = {
          user: {
            id: 'admin_user',
            email: 'admin@lab.local',
            full_name: 'System Administrator',
            username: 'admin'
          },
          access_token: this.generateToken(),
          expires_at: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
        };

        this.saveSession(session);
        return { session, error: null };
      }

      return { session: null, error: 'Invalid email or password' };
    } catch (error) {
      console.error('Sign in error:', error);
      return { session: null, error: 'An error occurred during sign in' };
    }
  }

  async signUp(email: string, password: string, fullName?: string): Promise<{ session: AuthSession | null; error: string | null }> {
    try {
      // For demo, create a simple user and auto sign in
      const userId = 'user_' + Math.random().toString(36).substr(2);
      const session: AuthSession = {
        user: {
          id: userId,
          email,
          full_name: fullName || 'New User',
          username: email.split('@')[0]
        },
        access_token: this.generateToken(),
        expires_at: Date.now() + (24 * 60 * 60 * 1000)
      };

      this.saveSession(session);
      return { session, error: null };
    } catch (error) {
      console.error('Sign up error:', error);
      return { session: null, error: 'An error occurred during registration' };
    }
  }

  async signOut(): Promise<void> {
    this.saveSession(null);
  }

  getSession(): AuthSession | null {
    return this.currentSession;
  }

  getUser(): AuthUser | null {
    return this.currentSession?.user || null;
  }

  onAuthStateChange(callback: (session: AuthSession | null) => void): () => void {
    this.listeners.push(callback);
    setTimeout(() => callback(this.currentSession), 0);
    
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  async getUserProfile(): Promise<UserProfile | null> {
    if (!this.currentSession) return null;

    // Return admin profile for demo
    return {
      id: 'profile_admin',
      user_id: 'admin_user',
      name: 'System Administrator',
      email: 'admin@lab.local',
      role: 'admin',
      department: 'Administration',
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  }
}

export const authService = new BrowserAuthService();