import { enhancedNotificationService } from './enhancedNotificationService';
import { notificationIntegrationService } from './notificationIntegrationService';
import { notificationEventService } from './notificationEventService';
import { notificationDataService } from './notificationDataService';
import { dashboardSchemaService } from '../database/dashboardSchemaService';

class NotificationStartupService {
  private isInitialized = false;
  private startupError: string | null = null;

  async initialize(): Promise<void> {
    if (this.isInitialized) {
      console.log('Notification services already initialized');
      return;
    }

    try {
      console.log('Initializing notification services...');

      // Step 1: Initialize database schema first
      await this.initializeDatabaseSchema();

      // Step 2: Initialize notification data service
      await notificationDataService.initializeSchema();
      console.log('✓ Notification data service initialized');

      // Step 3: Load initial notifications
      await enhancedNotificationService.loadNotifications();
      console.log('✓ Enhanced notification service initialized');

      // Step 4: Initialize event service
      await notificationEventService.initialize();
      console.log('✓ Notification event service initialized');

      // Step 5: Start integration service
      notificationIntegrationService.startBackgroundSync();
      console.log('✓ Notification integration service started');

      // Step 6: Start periodic checks
      enhancedNotificationService.startPeriodicChecks();
      console.log('✓ Notification periodic checks started');

      this.isInitialized = true;
      this.startupError = null;
      console.log('🔔 Notification system fully initialized');

      // Only create startup notification on first initialization
      const isFirstRun = !localStorage.getItem('notification_system_initialized');
      if (isFirstRun) {
        await enhancedNotificationService.createNotification({
          type: 'info',
          category: 'system',
          title: 'LIMS System Ready',
          message: 'Laboratory Information Management System has been initialized successfully.',
          priority: 'normal'
        });
        localStorage.setItem('notification_system_initialized', 'true');
      }

    } catch (error) {
      console.error('Failed to initialize notification services:', error);
      this.startupError = error instanceof Error ? error.message : 'Unknown error';
      throw error;
    }
  }

  private async initializeDatabaseSchema(): Promise<void> {
    try {
      // Initialize dashboard schema (includes test_schedule table)
      await dashboardSchemaService.initializeDashboardTables();
      console.log('✓ Database schema initialized');
    } catch (error) {
      console.error('Database schema initialization failed:', error);
      // Don't throw here - let the system work without some features
      console.warn('Continuing without full database schema...');
    }
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      error: this.startupError,
      services: {
        enhancedNotificationService: this.isInitialized,
        notificationIntegrationService: this.isInitialized,
        periodicChecks: this.isInitialized
      }
    };
  }

  async createTestNotifications(): Promise<void> {
    if (!this.isInitialized) {
      throw new Error('Notification services not initialized');
    }

    console.log('Creating test notifications...');

    // Test memo notification
    notificationIntegrationService.triggerMemoCreated({
      id: 'test-memo-1',
      reference: 'TEST-001',
      status: 'pending',
      plant: 'Main Plant',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Test overdue notification
    notificationIntegrationService.triggerTestOverdue({
      id: 'test-overdue-1',
      testType: 'Aggregate Gradation',
      dueDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
      status: 'overdue',
      priority: 'high'
    });

    // Create critical system test notification only
    await enhancedNotificationService.createNotification({
      type: 'warning',
      category: 'system',
      title: 'System Test: Critical Alert',
      message: 'This is a test of critical system notifications. Only important alerts will be shown.',
      priority: 'high'
    });

    console.log('✓ Test notifications created');
  }

  async shutdown(): Promise<void> {
    console.log('Shutting down notification services...');
    
    try {
      enhancedNotificationService.stopPeriodicChecks();
      this.isInitialized = false;
      console.log('✓ Notification services shut down');
    } catch (error) {
      console.error('Error during notification services shutdown:', error);
    }
  }
}

export const notificationStartupService = new NotificationStartupService();