import { toast } from '@/hooks/use-toast';

export interface EnhancedNotification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  category: 'system' | 'tests' | 'memos' | 'reports' | 'users';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  priority: 'low' | 'normal' | 'high' | 'critical';
  actionUrl?: string;
  data?: Record<string, any>;
  expiresAt?: string;
}

export interface NotificationRule {
  id: string;
  name: string;
  trigger: 'test_due' | 'test_overdue' | 'memo_created' | 'memo_updated' | 'report_approved' | 'report_rejected' | 'user_inactive' | 'system_alert';
  conditions: Record<string, any>;
  template: {
    title: string;
    message: string;
    type: 'info' | 'success' | 'warning' | 'error';
    category: 'system' | 'tests' | 'memos' | 'reports' | 'users';
    priority: 'low' | 'normal' | 'high' | 'critical';
  };
  enabled: boolean;
  created_at: string;
}

class EnhancedNotificationService {
  private notifications: EnhancedNotification[] = [];
  private rules: NotificationRule[] = [];
  private listeners: ((notifications: EnhancedNotification[]) => void)[] = [];
  private periodicCheckInterval?: NodeJS.Timeout;
  private notificationCooldowns: Map<string, number> = new Map();

  constructor() {
    this.initializeDefaultRules();
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      // Create enhanced notifications table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS enhanced_notifications (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL,
          category TEXT NOT NULL,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          read INTEGER DEFAULT 0,
          priority TEXT DEFAULT 'normal',
          action_url TEXT,
          data TEXT,
          expires_at TEXT,
          user_id TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create notification rules table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS notification_rules (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          trigger_type TEXT NOT NULL,
          conditions TEXT NOT NULL,
          template TEXT NOT NULL,
          enabled INTEGER DEFAULT 1,
          created_at TEXT NOT NULL
        )
      `);

      await this.loadNotifications();
      await this.loadRules();
    } catch (error) {
      console.error('Failed to initialize enhanced notification database:', error);
    }
  }

  private initializeDefaultRules() {
    this.rules = [
      {
        id: 'test-due-today',
        name: 'Tests Due Today',
        trigger: 'test_due',
        conditions: { daysRemaining: 0 },
        template: {
          title: 'Tests Due Today',
          message: 'You have {count} test(s) due today',
          type: 'warning',
          category: 'tests',
          priority: 'high'
        },
        enabled: true,
        created_at: new Date().toISOString()
      },
      {
        id: 'test-overdue',
        name: 'Overdue Tests',
        trigger: 'test_overdue',
        conditions: { daysOverdue: 1 },
        template: {
          title: 'Overdue Tests',
          message: 'You have {count} overdue test(s) requiring immediate attention',
          type: 'error',
          category: 'tests',
          priority: 'high'
        },
        enabled: true,
        created_at: new Date().toISOString()
      },
      {
        id: 'memo-created',
        name: 'New Memo Created',
        trigger: 'memo_created',
        conditions: {},
        template: {
          title: 'New Memo Created',
          message: 'Memo {memoRef} has been created for {plant}',
          type: 'info',
          category: 'memos',
          priority: 'normal'
        },
        enabled: true,
        created_at: new Date().toISOString()
      },
      {
        id: 'memo-updated',
        name: 'Memo Status Updated',
        trigger: 'memo_updated',
        conditions: {},
        template: {
          title: 'Memo Status Updated',
          message: 'Memo {memoRef} status changed to {status}',
          type: 'info',
          category: 'memos',
          priority: 'normal'
        },
        enabled: true,
        created_at: new Date().toISOString()
      },
      {
        id: 'report-approved',
        name: 'Report Approved',
        trigger: 'report_approved',
        conditions: {},
        template: {
          title: 'Report Approved',
          message: 'Report for memo {memoRef} has been approved',
          type: 'success',
          category: 'reports',
          priority: 'normal'
        },
        enabled: true,
        created_at: new Date().toISOString()
      },
      {
        id: 'report-rejected',
        name: 'Report Rejected',
        trigger: 'report_rejected',
        conditions: {},
        template: {
          title: 'Report Rejected',
          message: 'Report for memo {memoRef} requires revision',
          type: 'warning',
          category: 'reports',
          priority: 'high'
        },
        enabled: true,
        created_at: new Date().toISOString()
      }
    ];
  }

  async loadNotifications(): Promise<EnhancedNotification[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) {
      return this.notifications;
    }

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM enhanced_notifications WHERE expires_at IS NULL OR expires_at > ? ORDER BY timestamp DESC LIMIT 100',
        [new Date().toISOString()]
      );

      if (result.success) {
        this.notifications = result.data.map((row: any) => ({
          id: row.id,
          type: row.type,
          category: row.category,
          title: row.title,
          message: row.message,
          timestamp: row.timestamp,
          read: Boolean(row.read),
          priority: row.priority || 'normal',
          actionUrl: row.action_url,
          data: row.data ? JSON.parse(row.data) : undefined,
          expiresAt: row.expires_at
        }));
      }
    } catch (error) {
      console.error('Error loading enhanced notifications:', error);
    }

    return this.notifications;
  }

  private isCriticalSystemEvent(notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>): boolean {
    if (notification.category !== 'system') return true; // Non-system notifications are always allowed
    
    const criticalKeywords = [
      'error', 'failed', 'offline', 'disconnected', 'crash', 'security', 
      'breach', 'unauthorized', 'critical', 'emergency', 'down', 'timeout',
      'connection lost', 'database error', 'sync failed', 'backup failed'
    ];
    
    const title = notification.title.toLowerCase();
    const message = notification.message.toLowerCase();
    
    return criticalKeywords.some(keyword => 
      title.includes(keyword) || message.includes(keyword)
    ) || notification.priority === 'high' || notification.priority === 'critical';
  }

  private createNotificationKey(notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>): string {
    return `${notification.category}:${notification.title}:${notification.type}`;
  }

  private isInCooldown(key: string): boolean {
    const cooldownUntil = this.notificationCooldowns.get(key);
    if (!cooldownUntil) return false;
    
    if (Date.now() > cooldownUntil) {
      this.notificationCooldowns.delete(key);
      return false;
    }
    
    return true;
  }

  private setCooldown(key: string, durationMs: number = 300000): void { // 5 minutes default
    this.notificationCooldowns.set(key, Date.now() + durationMs);
  }

  async createNotification(notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>): Promise<EnhancedNotification> {
    // Check if it's a critical system event for system notifications
    if (!this.isCriticalSystemEvent(notification)) {
      console.log(`Skipping non-critical system notification: ${notification.title}`);
      return {
        id: 'skipped',
        timestamp: new Date().toISOString(),
        read: true,
        ...notification
      };
    }

    // Check for duplicates and cooldowns
    const notificationKey = this.createNotificationKey(notification);
    if (this.isInCooldown(notificationKey)) {
      console.log(`Notification in cooldown: ${notification.title}`);
      return {
        id: 'cooldown',
        timestamp: new Date().toISOString(),
        read: true,
        ...notification
      };
    }

    const newNotification: EnhancedNotification = {
      ...notification,
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      read: false,
      priority: notification.priority || 'normal'
    };

    // Set cooldown for this notification type
    this.setCooldown(notificationKey);

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbRun(
          `INSERT INTO enhanced_notifications (id, type, category, title, message, timestamp, read, priority, action_url, data, expires_at) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newNotification.id,
            newNotification.type,
            newNotification.category,
            newNotification.title,
            newNotification.message,
            newNotification.timestamp,
            newNotification.read ? 1 : 0,
            newNotification.priority,
            newNotification.actionUrl || null,
            newNotification.data ? JSON.stringify(newNotification.data) : null,
            newNotification.expiresAt || null
          ]
        );
      } catch (error) {
        console.error('Error saving enhanced notification:', error);
      }
    }

    this.notifications.unshift(newNotification);
    this.notifyListeners();

    // Show toast notification for high priority items
    if (newNotification.priority === 'high') {
      toast({
        title: newNotification.title,
        description: newNotification.message,
        variant: newNotification.type === 'error' ? 'destructive' : 'default'
      });
    }

    return newNotification;
  }

  async markAsRead(id: string): Promise<void> {
    const notification = this.notifications.find(n => n.id === id);
    if (!notification) return;

    notification.read = true;

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbRun(
          'UPDATE enhanced_notifications SET read = 1 WHERE id = ?',
          [id]
        );
      } catch (error) {
        console.error('Error marking notification as read:', error);
      }
    }

    this.notifyListeners();
  }

  async markAllAsRead(): Promise<void> {
    this.notifications.forEach(n => n.read = true);

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbRun('UPDATE enhanced_notifications SET read = 1');
      } catch (error) {
        console.error('Error marking all notifications as read:', error);
      }
    }

    this.notifyListeners();
  }

  async deleteNotification(id: string): Promise<void> {
    this.notifications = this.notifications.filter(n => n.id !== id);

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbRun('DELETE FROM enhanced_notifications WHERE id = ?', [id]);
      } catch (error) {
        console.error('Error deleting notification:', error);
      }
    }

    this.notifyListeners();
  }

  async clearOldNotifications(): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 30); // 30 days old

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbRun(
          'DELETE FROM enhanced_notifications WHERE timestamp < ? AND read = 1',
          [cutoffDate.toISOString()]
        );
      } catch (error) {
        console.error('Error clearing old notifications:', error);
      }
    }

    this.notifications = this.notifications.filter(n => 
      !n.read || new Date(n.timestamp) > cutoffDate
    );

    this.notifyListeners();
  }

  async checkTestDueDates(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      // Import test calendar service if available
      const { realTimeTestCalendarService } = await import('@/services/database/realTimeTestCalendarService');
      
      const alerts = await realTimeTestCalendarService.checkForAlerts();
      
      // Create notifications for overdue tests
      if (alerts.overdue > 0) {
        await this.createNotification({
          type: 'error',
          category: 'tests',
          title: 'Overdue Tests',
          message: `You have ${alerts.overdue} overdue test(s) requiring immediate attention`,
          priority: 'high',
          actionUrl: '/test-calendar?filter=overdue'
        });
      }

      // Create notifications for tests due today
      if (alerts.dueToday > 0) {
        await this.createNotification({
          type: 'warning',
          category: 'tests',
          title: 'Tests Due Today',
          message: `You have ${alerts.dueToday} test(s) due today`,
          priority: 'high',
          actionUrl: '/test-calendar?filter=due-today'
        });
      }

      // Create notifications for tests due tomorrow
      if (alerts.dueTomorrow > 0) {
        await this.createNotification({
          type: 'info',
          category: 'tests',
          title: 'Tests Due Tomorrow',
          message: `You have ${alerts.dueTomorrow} test(s) due tomorrow`,
          priority: 'normal',
          actionUrl: '/test-calendar?filter=due-tomorrow'
        });
      }
    } catch (error) {
      console.error('Error checking test due dates:', error);
    }
  }

  async checkMemoUpdates(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      // Check for new memos in the last hour
      const oneHourAgo = new Date();
      oneHourAgo.setHours(oneHourAgo.getHours() - 1);

      const result = await window.electronAPI.dbQuery(
        `SELECT id, reference, status, created_at, updated_at FROM memos 
         WHERE created_at > ? OR updated_at > ?
         ORDER BY created_at DESC`,
        [oneHourAgo.toISOString(), oneHourAgo.toISOString()]
      );

      if (result.success && result.data.length > 0) {
        for (const memo of result.data) {
          // Check if we already have a notification for this memo
          const existingNotification = this.notifications.find(n => 
            n.data?.memoId === memo.id && 
            n.category === 'memos'
          );

          if (!existingNotification) {
            await this.createNotification({
              type: 'info',
              category: 'memos',
              title: 'Memo Updated',
              message: `Memo ${memo.reference} status: ${memo.status}`,
              priority: 'normal',
              actionUrl: `/test-requests?memo=${memo.id}`,
              data: { memoId: memo.id, memoReference: memo.reference }
            });
          }
        }
      }
    } catch (error) {
      console.error('Error checking memo updates:', error);
    }
  }

  async loadRules(): Promise<NotificationRule[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return this.rules;

    try {
      const result = await window.electronAPI.dbQuery('SELECT * FROM notification_rules');
      if (result.success) {
        this.rules = result.data.map((row: any) => ({
          id: row.id,
          name: row.name,
          trigger: row.trigger_type,
          conditions: JSON.parse(row.conditions),
          template: JSON.parse(row.template),
          enabled: Boolean(row.enabled),
          created_at: row.created_at
        }));
      }
    } catch (error) {
      console.error('Error loading notification rules:', error);
    }

    return this.rules;
  }

  getUnreadCount(): number {
    return this.notifications.filter(n => !n.read).length;
  }

  getNotifications(): EnhancedNotification[] {
    return this.notifications;
  }

  getNotificationsByCategory(category: string): EnhancedNotification[] {
    return this.notifications.filter(n => n.category === category);
  }

  subscribe(listener: (notifications: EnhancedNotification[]) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener(this.notifications));
  }

  // Start periodic checking
  startPeriodicChecks(): void {
    // Clear existing interval
    if (this.periodicCheckInterval) {
      clearInterval(this.periodicCheckInterval);
    }

    // Check every 5 minutes
    this.periodicCheckInterval = setInterval(() => {
      this.checkTestDueDates();
      this.checkMemoUpdates();
    }, 5 * 60 * 1000);

    // Initial check
    this.checkTestDueDates();
    this.checkMemoUpdates();
  }

  stopPeriodicChecks(): void {
    if (this.periodicCheckInterval) {
      clearInterval(this.periodicCheckInterval);
      this.periodicCheckInterval = undefined;
    }
  }
}

export const enhancedNotificationService = new EnhancedNotificationService();