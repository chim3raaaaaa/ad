import { enhancedNotificationService } from './enhancedNotificationService';
import { localNotificationService } from './localNotificationService';

/**
 * Service for handling real-time notification events and triggers
 */
class NotificationEventService {
  private isInitialized = false;
  private checkInterval: NodeJS.Timeout | null = null;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Set up event listeners for various system events
      this.setupEventListeners();
      
      // Start periodic checks for due dates and overdue items
      this.startPeriodicChecks();
      
      this.isInitialized = true;
      console.log('Notification event service initialized');
    } catch (error) {
      console.error('Failed to initialize notification event service:', error);
      throw error;
    }
  }

  private setupEventListeners(): void {
    // Listen for memo events
    window.addEventListener('memo-created', this.handleMemoCreated.bind(this));
    window.addEventListener('memo-updated', this.handleMemoUpdated.bind(this));
    window.addEventListener('memo-approved', this.handleMemoApproved.bind(this));
    window.addEventListener('memo-rejected', this.handleMemoRejected.bind(this));

    // Listen for test events
    window.addEventListener('test-completed', this.handleTestCompleted.bind(this));
    window.addEventListener('test-overdue', this.handleTestOverdue.bind(this));
    window.addEventListener('test-scheduled', this.handleTestScheduled.bind(this));

    // Listen for report events
    window.addEventListener('report-generated', this.handleReportGenerated.bind(this));
    window.addEventListener('report-approved', this.handleReportApproved.bind(this));

    // Listen for user events
    window.addEventListener('user-created', this.handleUserCreated.bind(this));
    window.addEventListener('user-inactivity', this.handleUserInactivity.bind(this));

    console.log('Event listeners set up for notifications');
  }

  private async handleMemoCreated(event: CustomEvent): Promise<void> {
    const memo = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'info',
        category: 'memos',
        title: 'New Memo Created',
        message: `Memo ${memo.reference} has been created for ${memo.plant}`,
        priority: 'normal',
        actionUrl: `/test-modules?memoId=${memo.id}`,
        data: { memoId: memo.id, reference: memo.reference }
      });

      await localNotificationService.addNotification({
        title: 'New Memo',
        message: `${memo.reference} - ${memo.plant}`,
        category: 'memos',
        type: 'info',
        action_url: `/test-modules?memoId=${memo.id}`
      });
    } catch (error) {
      console.error('Failed to create memo notification:', error);
    }
  }

  private async handleMemoUpdated(event: CustomEvent): Promise<void> {
    const memo = event.detail;
    
    try {
      const priority = memo.status === 'urgent' ? 'high' : 'normal';
      const type = memo.status === 'approved' ? 'success' : 'info';

      await enhancedNotificationService.createNotification({
        type,
        category: 'memos',
        title: 'Memo Updated',
        message: `Memo ${memo.reference} status changed to ${memo.status}`,
        priority,
        actionUrl: `/test-modules?memoId=${memo.id}`,
        data: { memoId: memo.id, status: memo.status }
      });
    } catch (error) {
      console.error('Failed to create memo update notification:', error);
    }
  }

  private async handleMemoApproved(event: CustomEvent): Promise<void> {
    const memo = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'success',
        category: 'memos',
        title: 'Memo Approved',
        message: `Memo ${memo.reference} has been approved and is ready for testing`,
        priority: 'normal',
        actionUrl: `/test-calendar?memoId=${memo.id}`,
        data: { memoId: memo.id }
      });
    } catch (error) {
      console.error('Failed to create memo approval notification:', error);
    }
  }

  private async handleMemoRejected(event: CustomEvent): Promise<void> {
    const memo = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'error',
        category: 'memos',
        title: 'Memo Rejected',
        message: `Memo ${memo.reference} has been rejected. Reason: ${memo.reason || 'No reason provided'}`,
        priority: 'high',
        actionUrl: `/test-modules?memoId=${memo.id}`,
        data: { memoId: memo.id, reason: memo.reason }
      });
    } catch (error) {
      console.error('Failed to create memo rejection notification:', error);
    }
  }

  private async handleTestCompleted(event: CustomEvent): Promise<void> {
    const test = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'success',
        category: 'tests',
        title: 'Test Completed',
        message: `${test.testType} test has been completed successfully`,
        priority: 'normal',
        actionUrl: `/test-calendar?testId=${test.id}`,
        data: { testId: test.id, testType: test.testType }
      });
    } catch (error) {
      console.error('Failed to create test completion notification:', error);
    }
  }

  private async handleTestOverdue(event: CustomEvent): Promise<void> {
    const test = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'warning',
        category: 'tests',
        title: 'Test Overdue',
        message: `${test.testType} test is overdue (due: ${test.dueDate})`,
        priority: 'high',
        actionUrl: `/test-calendar?testId=${test.id}`,
        data: { testId: test.id, testType: test.testType, dueDate: test.dueDate }
      });

      await localNotificationService.addNotification({
        title: 'Overdue Test',
        message: `${test.testType} - Due: ${test.dueDate}`,
        category: 'tests',
        type: 'warning',
        action_url: `/test-calendar?testId=${test.id}`
      });
    } catch (error) {
      console.error('Failed to create test overdue notification:', error);
    }
  }

  private async handleTestScheduled(event: CustomEvent): Promise<void> {
    const test = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'info',
        category: 'tests',
        title: 'Test Scheduled',
        message: `${test.testType} test scheduled for ${test.scheduledDate}`,
        priority: 'normal',
        actionUrl: `/test-calendar?testId=${test.id}`,
        data: { testId: test.id, testType: test.testType, scheduledDate: test.scheduledDate }
      });
    } catch (error) {
      console.error('Failed to create test schedule notification:', error);
    }
  }

  private async handleReportGenerated(event: CustomEvent): Promise<void> {
    const report = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'success',
        category: 'reports',
        title: 'Report Generated',
        message: `${report.type} report has been generated successfully`,
        priority: 'normal',
        actionUrl: `/reports?reportId=${report.id}`,
        data: { reportId: report.id, type: report.type }
      });
    } catch (error) {
      console.error('Failed to create report generation notification:', error);
    }
  }

  private async handleReportApproved(event: CustomEvent): Promise<void> {
    const report = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'success',
        category: 'reports',
        title: 'Report Approved',
        message: `${report.type} report has been approved`,
        priority: 'normal',
        actionUrl: `/reports?reportId=${report.id}`,
        data: { reportId: report.id, type: report.type }
      });
    } catch (error) {
      console.error('Failed to create report approval notification:', error);
    }
  }

  private async handleUserCreated(event: CustomEvent): Promise<void> {
    const user = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'info',
        category: 'users',
        title: 'New User Created',
        message: `${user.name} has been added to the system`,
        priority: 'low',
        actionUrl: `/users?userId=${user.id}`,
        data: { userId: user.id, name: user.name }
      });
    } catch (error) {
      console.error('Failed to create user creation notification:', error);
    }
  }

  private async handleUserInactivity(event: CustomEvent): Promise<void> {
    const user = event.detail;
    
    try {
      await enhancedNotificationService.createNotification({
        type: 'warning',
        category: 'users',
        title: 'User Inactivity Alert',
        message: `${user.name} has been inactive for ${user.inactiveDays} days`,
        priority: 'normal',
        actionUrl: `/users?userId=${user.id}`,
        data: { userId: user.id, inactiveDays: user.inactiveDays }
      });
    } catch (error) {
      console.error('Failed to create user inactivity notification:', error);
    }
  }

  private startPeriodicChecks(): void {
    // Check every 5 minutes for due dates and other time-based events
    this.checkInterval = setInterval(() => {
      this.checkTestDueDates();
      this.checkMemoDeadlines();
      this.checkUserInactivity();
    }, 5 * 60 * 1000);

    console.log('Periodic checks started for notifications');
  }

  private async checkTestDueDates(): Promise<void> {
    try {
      // Check for tests due in the next 24 hours or overdue
      if (typeof window !== 'undefined' && window.electronAPI) {
        const tests = await window.electronAPI.dbQuery(`
          SELECT * FROM test_schedule 
          WHERE (due_date <= datetime('now', '+1 day') AND status != 'completed')
             OR (due_date < datetime('now') AND status != 'completed' AND status != 'overdue')
        `);

        for (const test of tests || []) {
          const dueDate = new Date(test.due_date);
          const now = new Date();
          
          if (dueDate < now && test.status !== 'overdue') {
            // Mark as overdue and create notification
            await window.electronAPI.dbQuery(
              'UPDATE test_schedule SET status = ? WHERE id = ?',
              ['overdue', test.id]
            );

            window.dispatchEvent(new CustomEvent('test-overdue', { 
              detail: { 
                id: test.id, 
                testType: test.test_type, 
                dueDate: test.due_date 
              } 
            }));
          } else if (dueDate > now && dueDate <= new Date(now.getTime() + 24 * 60 * 60 * 1000)) {
            // Test due within 24 hours
            await enhancedNotificationService.createNotification({
              type: 'info',
              category: 'tests',
              title: 'Test Due Soon',
              message: `${test.test_type} test is due within 24 hours`,
              priority: 'normal',
              actionUrl: `/test-calendar?testId=${test.id}`,
              data: { testId: test.id, testType: test.test_type, dueDate: test.due_date }
            });
          }
        }
      }
    } catch (error) {
      console.error('Failed to check test due dates:', error);
    }
  }

  private async checkMemoDeadlines(): Promise<void> {
    try {
      // Implementation for memo deadline checking
      // This would query the memos table for approaching deadlines
    } catch (error) {
      console.error('Failed to check memo deadlines:', error);
    }
  }

  private async checkUserInactivity(): Promise<void> {
    try {
      // Implementation for user inactivity checking
      // This would check user login logs and identify inactive users
    } catch (error) {
      console.error('Failed to check user inactivity:', error);
    }
  }

  shutdown(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }

    // Remove event listeners
    window.removeEventListener('memo-created', this.handleMemoCreated.bind(this));
    window.removeEventListener('memo-updated', this.handleMemoUpdated.bind(this));
    window.removeEventListener('test-completed', this.handleTestCompleted.bind(this));
    window.removeEventListener('test-overdue', this.handleTestOverdue.bind(this));
    // ... remove other listeners

    this.isInitialized = false;
    console.log('Notification event service shut down');
  }

  // Public methods to trigger events programmatically
  triggerMemoCreated(memo: any): void {
    window.dispatchEvent(new CustomEvent('memo-created', { detail: memo }));
  }

  triggerMemoUpdated(memo: any): void {
    window.dispatchEvent(new CustomEvent('memo-updated', { detail: memo }));
  }

  triggerTestCompleted(test: any): void {
    window.dispatchEvent(new CustomEvent('test-completed', { detail: test }));
  }

  triggerTestOverdue(test: any): void {
    window.dispatchEvent(new CustomEvent('test-overdue', { detail: test }));
  }

  triggerReportGenerated(report: any): void {
    window.dispatchEvent(new CustomEvent('report-generated', { detail: report }));
  }
}

export const notificationEventService = new NotificationEventService();