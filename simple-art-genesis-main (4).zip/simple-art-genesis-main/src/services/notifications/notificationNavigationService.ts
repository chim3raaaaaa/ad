import { type EnhancedNotification } from './enhancedNotificationService';

export interface NavigationTarget {
  route: string;
  params?: Record<string, string>;
}

export class NotificationNavigationService {
  /**
   * Determines the most appropriate navigation target for a notification
   */
  static getNavigationTarget(notification: EnhancedNotification): NavigationTarget {
    // If there's an explicit action URL, use it
    if (notification.actionUrl) {
      return { route: notification.actionUrl };
    }

    // Handle notification data for specific routing
    const data = notification.data || {};
    
    switch (notification.category) {
      case 'tests':
        return this.getTestNavigationTarget(notification, data);
      
      case 'memos':
        return this.getMemoNavigationTarget(notification, data);
      
      case 'reports':
        return this.getReportNavigationTarget(notification, data);
      
      case 'users':
        return this.getUserNavigationTarget(notification, data);
      
      case 'system':
        return this.getSystemNavigationTarget(notification, data);
      
      default:
        return { route: '/dashboard' };
    }
  }

  private static getTestNavigationTarget(notification: EnhancedNotification, data: any): NavigationTarget {
    // If it's a specific test type, go to test modules
    if (data.testType || data.moduleType) {
      return {
        route: '/test-modules',
        params: {
          module: data.testType || data.moduleType,
          ...(data.testId && { testId: data.testId })
        }
      };
    }

    // If it's about test scheduling or due dates, go to calendar
    if (notification.title.toLowerCase().includes('due') || 
        notification.title.toLowerCase().includes('scheduled') ||
        notification.title.toLowerCase().includes('overdue')) {
      return {
        route: '/test-calendar',
        params: {
          ...(data.testId && { highlight: data.testId }),
          ...(data.dueDate && { date: data.dueDate }),
          filter: 'overdue'
        }
      };
    }

    // Default to test calendar
    return { route: '/test-calendar' };
  }

  private static getMemoNavigationTarget(notification: EnhancedNotification, data: any): NavigationTarget {
    return {
      route: '/test-requests',
      params: {
        ...(data.memoId && { memo: data.memoId }),
        ...(data.status && { status: data.status }),
        ...(data.plant && { plant: data.plant })
      }
    };
  }

  private static getReportNavigationTarget(notification: EnhancedNotification, data: any): NavigationTarget {
    return {
      route: '/reports',
      params: {
        ...(data.reportId && { reportId: data.reportId }),
        ...(data.type && { type: data.type }),
        ...(data.status && { status: data.status })
      }
    };
  }

  private static getUserNavigationTarget(notification: EnhancedNotification, data: any): NavigationTarget {
    return {
      route: '/users',
      params: {
        ...(data.userId && { userId: data.userId }),
        ...(data.role && { role: data.role })
      }
    };
  }

  private static getSystemNavigationTarget(notification: EnhancedNotification, data: any): NavigationTarget {
    // Route system notifications to specific areas based on content
    const message = notification.message.toLowerCase();
    const title = notification.title.toLowerCase();
    
    if (title.includes('backup') || message.includes('backup')) {
      return { route: '/settings' };
    }
    
    if (title.includes('user') || message.includes('user')) {
      return { route: '/users' };
    }
    
    if (title.includes('integration') || message.includes('integration')) {
      return { route: '/integrations' };
    }
    
    if (title.includes('reference') || message.includes('reference data')) {
      return { route: '/reference-data' };
    }
    
    if (title.includes('dashboard') || message.includes('dashboard')) {
      return { route: '/dashboard' };
    }

    // Default to settings for system notifications
    return { route: '/settings' };
  }

  /**
   * Builds the final navigation URL with query parameters
   */
  static buildNavigationUrl(target: NavigationTarget): string {
    let url = target.route;
    
    if (target.params && Object.keys(target.params).length > 0) {
      const searchParams = new URLSearchParams();
      Object.entries(target.params).forEach(([key, value]) => {
        if (value) {
          searchParams.append(key, value);
        }
      });
      
      const queryString = searchParams.toString();
      if (queryString) {
        url += '?' + queryString;
      }
    }
    
    return url;
  }

  /**
   * Main method to get the complete navigation URL for a notification
   */
  static getNavigationUrl(notification: EnhancedNotification): string {
    const target = this.getNavigationTarget(notification);
    return this.buildNavigationUrl(target);
  }
}