import type { EnhancedNotification } from './enhancedNotificationService';
import type { LocalNotification, NotificationSettings } from './localNotificationService';
import { notificationApiService } from './notificationApiService';
import { generateId } from '@/lib/utils';

/**
 * Abstract data service that handles both Electron and web environments
 */
class NotificationDataService {
  private isElectronAvailable(): boolean {
    return typeof window !== 'undefined' && window.electronAPI;
  }

  private getCurrentUserId(): string {
    // Get user ID from UserContext or fallback to localStorage
    const userStr = localStorage.getItem('current_user');
    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        return user.id || 'anonymous';
      } catch {
        // Fall through to anonymous
      }
    }
    return 'anonymous';
  }

  // Enhanced Notifications Methods
  async getEnhancedNotifications(): Promise<EnhancedNotification[]> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM enhanced_notifications WHERE user_id = ? ORDER BY timestamp DESC',
          [userId]
        );
        return result || [];
      } catch (error) {
        console.error('Failed to fetch notifications from Electron DB:', error);
        return [];
      }
    } else {
      const response = await notificationApiService.getNotifications(userId);
      if (response.success && response.data) {
        return response.data;
      } else {
        console.error('Failed to fetch notifications from API:', response.error);
        return [];
      }
    }
  }

  async createEnhancedNotification(
    notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>
  ): Promise<EnhancedNotification> {
    const userId = this.getCurrentUserId();
    const newNotification: EnhancedNotification = {
      ...notification,
      id: generateId(),
      timestamp: new Date().toISOString(),
      read: false,
    };

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          `INSERT INTO enhanced_notifications 
           (id, user_id, type, category, title, message, priority, action_url, data, expires_at, timestamp, read) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newNotification.id,
            userId,
            newNotification.type,
            newNotification.category,
            newNotification.title,
            newNotification.message,
            newNotification.priority,
            newNotification.actionUrl || null,
            JSON.stringify(newNotification.data || {}),
            newNotification.expiresAt || null,
            newNotification.timestamp,
            newNotification.read ? 1 : 0,
          ]
        );
        return newNotification;
      } catch (error) {
        console.error('Failed to create notification in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.createNotification(notification, userId);
      if (response.success && response.data) {
        return response.data;
      } else {
        throw new Error(response.error || 'Failed to create notification');
      }
    }
  }

  async markEnhancedAsRead(id: string): Promise<void> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          'UPDATE enhanced_notifications SET read = 1 WHERE id = ? AND user_id = ?',
          [id, userId]
        );
      } catch (error) {
        console.error('Failed to mark notification as read in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.markAsRead(id, userId);
      if (!response.success) {
        throw new Error(response.error || 'Failed to mark notification as read');
      }
    }
  }

  async markAllEnhancedAsRead(): Promise<void> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          'UPDATE enhanced_notifications SET read = 1 WHERE user_id = ?',
          [userId]
        );
      } catch (error) {
        console.error('Failed to mark all notifications as read in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.markAllAsRead(userId);
      if (!response.success) {
        throw new Error(response.error || 'Failed to mark all notifications as read');
      }
    }
  }

  async deleteEnhancedNotification(id: string): Promise<void> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          'DELETE FROM enhanced_notifications WHERE id = ? AND user_id = ?',
          [id, userId]
        );
      } catch (error) {
        console.error('Failed to delete notification in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.deleteNotification(id, userId);
      if (!response.success) {
        throw new Error(response.error || 'Failed to delete notification');
      }
    }
  }

  async clearOldEnhancedNotifications(): Promise<void> {
    const userId = this.getCurrentUserId();
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          'DELETE FROM enhanced_notifications WHERE user_id = ? AND timestamp < ?',
          [userId, thirtyDaysAgo]
        );
      } catch (error) {
        console.error('Failed to clear old notifications in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.clearOldNotifications(userId);
      if (!response.success) {
        throw new Error(response.error || 'Failed to clear old notifications');
      }
    }
  }

  // Local Notifications Methods
  async getLocalNotifications(): Promise<LocalNotification[]> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM local_notifications WHERE user_id = ? ORDER BY timestamp DESC',
          [userId]
        );
        return result || [];
      } catch (error) {
        console.error('Failed to fetch local notifications from Electron DB:', error);
        return [];
      }
    } else {
      const response = await notificationApiService.getLocalNotifications(userId);
      if (response.success && response.data) {
        return response.data;
      } else {
        console.error('Failed to fetch local notifications from API:', response.error);
        return [];
      }
    }
  }

  async addLocalNotification(
    notification: Omit<LocalNotification, 'id' | 'timestamp' | 'read'>
  ): Promise<LocalNotification> {
    const userId = this.getCurrentUserId();
    const newNotification: LocalNotification = {
      ...notification,
      id: generateId(),
      timestamp: new Date().toISOString(),
      read: 0, // SQLite uses 0/1 for boolean
    };

    if (this.isElectronAvailable()) {
      try {
        await window.electronAPI.dbQuery(
          `INSERT INTO local_notifications 
           (id, user_id, title, message, category, type, timestamp, read, snoozed_until, action_url) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newNotification.id,
            userId,
            newNotification.title,
            newNotification.message,
            newNotification.category,
            newNotification.type,
            newNotification.timestamp,
            0, // read = false
            newNotification.snoozed_until || null,
            newNotification.action_url || null,
          ]
        );
        return newNotification;
      } catch (error) {
        console.error('Failed to add local notification in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.addLocalNotification(notification, userId);
      if (response.success && response.data) {
        return response.data;
      } else {
        throw new Error(response.error || 'Failed to add local notification');
      }
    }
  }

  // Notification Settings Methods
  async getNotificationSettings(): Promise<NotificationSettings[]> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM notification_settings WHERE user_id = ?',
          [userId]
        );
        return result || [];
      } catch (error) {
        console.error('Failed to fetch notification settings from Electron DB:', error);
        return [];
      }
    } else {
      const response = await notificationApiService.getNotificationSettings(userId);
      if (response.success && response.data) {
        return response.data;
      } else {
        console.error('Failed to fetch notification settings from API:', response.error);
        return [];
      }
    }
  }

  async updateNotificationSettings(settings: NotificationSettings[]): Promise<void> {
    const userId = this.getCurrentUserId();

    if (this.isElectronAvailable()) {
      try {
        // Delete existing settings for user
        await window.electronAPI.dbQuery(
          'DELETE FROM notification_settings WHERE user_id = ?',
          [userId]
        );

        // Insert new settings
        for (const setting of settings) {
          await window.electronAPI.dbQuery(
            `INSERT INTO notification_settings 
             (user_id, category, receive, play_sound, toast_enabled) 
             VALUES (?, ?, ?, ?, ?)`,
            [
              userId,
              setting.category,
              setting.receive ? 1 : 0,
              setting.play_sound ? 1 : 0,
              setting.toast_enabled ? 1 : 0,
            ]
          );
        }
      } catch (error) {
        console.error('Failed to update notification settings in Electron DB:', error);
        throw error;
      }
    } else {
      const response = await notificationApiService.updateNotificationSettings(settings, userId);
      if (!response.success) {
        throw new Error(response.error || 'Failed to update notification settings');
      }
    }
  }

  // Schema initialization for Electron
  async initializeSchema(): Promise<void> {
    if (!this.isElectronAvailable()) {
      return; // API handles schema
    }

    try {
      // Create enhanced_notifications table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS enhanced_notifications (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          type TEXT NOT NULL,
          category TEXT NOT NULL,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          priority TEXT DEFAULT 'normal',
          action_url TEXT,
          data TEXT,
          expires_at TEXT,
          timestamp TEXT NOT NULL,
          read INTEGER DEFAULT 0
        )
      `);

      // Create local_notifications table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS local_notifications (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          category TEXT NOT NULL,
          type TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          read INTEGER DEFAULT 0,
          snoozed_until TEXT,
          action_url TEXT
        )
      `);

      // Create notification_settings table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS notification_settings (
          user_id TEXT NOT NULL,
          category TEXT NOT NULL,
          receive INTEGER DEFAULT 1,
          play_sound INTEGER DEFAULT 1,
          toast_enabled INTEGER DEFAULT 1,
          PRIMARY KEY (user_id, category)
        )
      `);

      // Create indexes for performance
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_enhanced_notifications_user_timestamp 
        ON enhanced_notifications(user_id, timestamp)
      `);

      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_local_notifications_user_timestamp 
        ON local_notifications(user_id, timestamp)
      `);

    } catch (error) {
      console.error('Failed to initialize notification schema:', error);
      throw error;
    }
  }
}

export const notificationDataService = new NotificationDataService();