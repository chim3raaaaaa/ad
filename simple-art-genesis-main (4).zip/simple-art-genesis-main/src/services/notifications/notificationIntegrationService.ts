import { enhancedNotificationService } from './enhancedNotificationService';

interface MemoEventData {
  id: string;
  reference: string;
  status: string;
  plant?: string;
  createdAt: string;
  updatedAt: string;
}

interface TestEventData {
  id: string;
  testType: string;
  dueDate: string;
  status: string;
  priority: 'low' | 'normal' | 'high';
}

class NotificationIntegrationService {
  constructor() {
    this.initializeEventListeners();
  }

  private initializeEventListeners() {
    // Listen for memo status changes
    if (typeof window !== 'undefined') {
      window.addEventListener('memo-created', this.handleMemoCreated.bind(this));
      window.addEventListener('memo-updated', this.handleMemoUpdated.bind(this));
      window.addEventListener('test-completed', this.handleTestCompleted.bind(this));
      window.addEventListener('test-overdue', this.handleTestOverdue.bind(this));
      
      // NEW: Memo Inbox Events
      window.addEventListener('memo-submitted-to-inbox', this.handleMemoSubmittedToInbox.bind(this));
      window.addEventListener('memo-flagged', this.handleMemoFlagged.bind(this));
      window.addEventListener('revision-required', this.handleRevisionRequired.bind(this));
      window.addEventListener('memo-acknowledged', this.handleMemoAcknowledged.bind(this));
    }
    
    console.log('Notification integration service initialized with inbox events');
  }

  async handleMemoCreated(event: CustomEvent<MemoEventData>) {
    const memo = event.detail;
    
    await enhancedNotificationService.createNotification({
      type: 'info',
      category: 'memos',
      title: 'New Memo Created',
      message: `Memo ${memo.reference} has been created for ${memo.plant || 'Unknown Plant'}`,
      priority: 'normal',
      actionUrl: `/test-requests?memo=${memo.id}`,
      data: {
        memoId: memo.id,
        memoReference: memo.reference,
        plant: memo.plant
      }
    });
  }

  async handleMemoUpdated(event: CustomEvent<MemoEventData>) {
    const memo = event.detail;
    
    let type: 'info' | 'success' | 'warning' | 'error' = 'info';
    let priority: 'low' | 'normal' | 'high' = 'normal';
    
    if (memo.status === 'completed') {
      type = 'success';
      priority = 'normal';
    } else if (memo.status === 'failed' || memo.status === 'rejected') {
      type = 'error';
      priority = 'high';
    } else if (memo.status === 'pending' || memo.status === 'review') {
      type = 'warning';
      priority = 'normal';
    }

    await enhancedNotificationService.createNotification({
      type,
      category: 'memos',
      title: 'Memo Status Updated',
      message: `Memo ${memo.reference} status changed to ${memo.status}`,
      priority,
      actionUrl: `/test-requests?memo=${memo.id}`,
      data: {
        memoId: memo.id,
        memoReference: memo.reference,
        oldStatus: memo.status,
        newStatus: memo.status
      }
    });
  }

  async handleTestCompleted(event: CustomEvent<TestEventData>) {
    const test = event.detail;
    
    await enhancedNotificationService.createNotification({
      type: 'success',
      category: 'tests',
      title: 'Test Completed',
      message: `${test.testType} test has been completed successfully`,
      priority: 'normal',
      actionUrl: '/test-calendar',
      data: {
        testId: test.id,
        testType: test.testType
      }
    });
  }

  async handleTestOverdue(event: CustomEvent<TestEventData>) {
    const test = event.detail;
    
    await enhancedNotificationService.createNotification({
      type: 'error',
      category: 'tests',
      title: 'Test Overdue',
      message: `${test.testType} test is overdue and requires immediate attention`,
      priority: 'high',
      actionUrl: '/test-calendar?filter=overdue',
      data: {
        testId: test.id,
        testType: test.testType,
        dueDate: test.dueDate
      }
    });
  }

  // Trigger events programmatically for integration
  triggerMemoCreated(memo: MemoEventData) {
    const event = new CustomEvent('memo-created', { detail: memo });
    window.dispatchEvent(event);
  }

  triggerMemoUpdated(memo: MemoEventData) {
    const event = new CustomEvent('memo-updated', { detail: memo });
    window.dispatchEvent(event);
  }

  triggerTestCompleted(test: TestEventData) {
    const event = new CustomEvent('test-completed', { detail: test });
    window.dispatchEvent(event);
  }

  triggerTestOverdue(test: TestEventData) {
    const event = new CustomEvent('test-overdue', { detail: test });
    window.dispatchEvent(event);
  }

  async createSystemNotification(
    title: string, 
    message: string, 
    type: 'info' | 'success' | 'warning' | 'error' = 'info',
    priority: 'low' | 'normal' | 'high' = 'normal'
  ) {
    await enhancedNotificationService.createNotification({
      type,
      category: 'system',
      title,
      message,
      priority
    });
  }

  async createUserNotification(
    title: string, 
    message: string, 
    userId: string,
    actionUrl?: string
  ) {
    await enhancedNotificationService.createNotification({
      type: 'info',
      category: 'users',
      title,
      message,
      priority: 'normal',
      actionUrl,
      data: { userId }
    });
  }

  async createReportNotification(
    title: string, 
    message: string, 
    type: 'success' | 'error' = 'success',
    reportId?: string
  ) {
    await enhancedNotificationService.createNotification({
      type,
      category: 'reports',
      title,
      message,
      priority: type === 'error' ? 'high' : 'normal',
      actionUrl: '/reports',
      data: { reportId }
    });
  }

  // Integration with memo context
  async syncWithMemoContext(memos: any[]) {
    // Check for new memos in the last hour
    const oneHourAgo = new Date();
    oneHourAgo.setHours(oneHourAgo.getHours() - 1);

    for (const memo of memos) {
      const memoTime = new Date(memo.createdAt || memo.created_at);
      
      // New memo notification
      if (memoTime > oneHourAgo) {
        this.triggerMemoCreated({
          id: memo.id,
          reference: memo.reference,
          status: memo.status,
          plant: memo.plant,
          createdAt: memo.createdAt || memo.created_at,
          updatedAt: memo.updatedAt || memo.updated_at
        });
      }

      // Status change notifications
      if (memo.updatedAt && new Date(memo.updatedAt) > oneHourAgo) {
        this.triggerMemoUpdated({
          id: memo.id,
          reference: memo.reference,
          status: memo.status,
          plant: memo.plant,
          createdAt: memo.createdAt || memo.created_at,
          updatedAt: memo.updatedAt || memo.updated_at
        });
      }
    }
  }

  // Integration with test calendar
  async syncWithTestCalendar() {
    try {
      const { realTimeTestCalendarService } = await import('@/services/database/realTimeTestCalendarService');
      
      // Check for overdue tests
      const overdueTests = await realTimeTestCalendarService.getOverdueTests();
      if (overdueTests && overdueTests.length > 0) {
        for (const test of overdueTests) {
          this.triggerTestOverdue({
            id: test.id,
            testType: test.test_type,
            dueDate: test.due_date,
            status: test.status,
            priority: (test.priority === 'critical' ? 'high' : test.priority) || 'high'
          });
        }
      }

      // Check for completed tests
      const completedToday = await realTimeTestCalendarService.getTestEvents({
        status: 'completed',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date().toISOString().split('T')[0]
      });

      if (completedToday && completedToday.length > 0) {
        for (const test of completedToday) {
          this.triggerTestCompleted({
            id: test.id,
            testType: test.test_type,
            dueDate: test.due_date,
            status: test.status,
            priority: (test.priority === 'critical' ? 'high' : test.priority) || 'normal'
          });
        }
      }
    } catch (error) {
      console.error('Error syncing with test calendar:', error);
      // Don't throw - let the system continue without calendar integration
    }
  }

  // Start background sync processes
  startBackgroundSync() {
    // Sync every 5 minutes
    setInterval(() => {
      this.syncWithTestCalendar();
    }, 5 * 60 * 1000);

    // Initial sync
    this.syncWithTestCalendar();
  }

  // NEW: Memo Inbox Event Handlers
  private async handleMemoSubmittedToInbox(event: CustomEvent<MemoEventData>) {
    await this.createSystemNotification(
      'Memo Submitted to Inbox',
      `Memo ${event.detail.reference} has been submitted for review`,
      'info',
      'normal'
    );
  }

  private async handleMemoFlagged(event: CustomEvent<MemoEventData & { flaggedBy: string; reason: string; priority: string }>) {
    const priority = event.detail.priority === 'critical' ? 'high' : 'normal';
    await this.createSystemNotification(
      'Memo Flagged for Discrepancies',
      `Memo ${event.detail.reference} has been flagged by ${event.detail.flaggedBy}. Reason: ${event.detail.reason}`,
      'error',
      priority as 'normal' | 'high'
    );
  }

  private async handleRevisionRequired(event: CustomEvent<MemoEventData & { requestedBy: string; changes: string }>) {
    await this.createUserNotification(
      'Revision Required',
      `Your memo ${event.detail.reference} requires revision. Changes: ${event.detail.changes}`,
      event.detail.id // User ID who created the memo
    );
  }

  private async handleMemoAcknowledged(event: CustomEvent<MemoEventData & { acknowledgedBy: string }>) {
    await this.createSystemNotification(
      'Memo Acknowledged',
      `Memo ${event.detail.reference} has been acknowledged by ${event.detail.acknowledgedBy}`,
      'success',
      'normal'
    );
  }

  // NEW: Memo Inbox Event Triggers
  public triggerMemoSubmittedToInbox(memo: MemoEventData) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('memo-submitted-to-inbox', { detail: memo }));
    }
  }

  public triggerMemoFlagged(memo: MemoEventData & { flaggedBy: string; reason: string; priority: string }) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('memo-flagged', { detail: memo }));
    }
  }

  public triggerRevisionRequired(memo: MemoEventData & { requestedBy: string; changes: string }) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('revision-required', { detail: memo }));
    }
  }

  public triggerMemoAcknowledged(memo: MemoEventData & { acknowledgedBy: string }) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('memo-acknowledged', { detail: memo }));
    }
  }
}

export const notificationIntegrationService = new NotificationIntegrationService();