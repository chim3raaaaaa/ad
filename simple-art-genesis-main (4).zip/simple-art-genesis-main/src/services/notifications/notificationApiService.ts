import type { EnhancedNotification } from './enhancedNotificationService';
import type { LocalNotification, NotificationSettings } from './localNotificationService';

export interface NotificationApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * API service for notification operations when running in web mode
 */
class NotificationApiService {
  private baseUrl: string;

  constructor() {
    // Use the project's API base URL - replace with actual backend URL
    this.baseUrl = '/api/notifications';
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<NotificationApiResponse<T>> {
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      console.error('Notification API request failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown API error',
      };
    }
  }

  // Enhanced Notifications API
  async getNotifications(userId: string): Promise<NotificationApiResponse<EnhancedNotification[]>> {
    return this.request<EnhancedNotification[]>(`/enhanced?userId=${userId}`);
  }

  async createNotification(
    notification: Omit<EnhancedNotification, 'id' | 'timestamp' | 'read'>,
    userId: string
  ): Promise<NotificationApiResponse<EnhancedNotification>> {
    return this.request<EnhancedNotification>('/enhanced', {
      method: 'POST',
      body: JSON.stringify({ ...notification, userId }),
    });
  }

  async markAsRead(id: string, userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>(`/enhanced/${id}/read`, {
      method: 'PUT',
      body: JSON.stringify({ userId }),
    });
  }

  async markAllAsRead(userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>('/enhanced/read-all', {
      method: 'PUT',
      body: JSON.stringify({ userId }),
    });
  }

  async deleteNotification(id: string, userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>(`/enhanced/${id}`, {
      method: 'DELETE',
      body: JSON.stringify({ userId }),
    });
  }

  async clearOldNotifications(userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>('/enhanced/clear-old', {
      method: 'DELETE',
      body: JSON.stringify({ userId }),
    });
  }

  // Local Notifications API
  async getLocalNotifications(userId: string): Promise<NotificationApiResponse<LocalNotification[]>> {
    return this.request<LocalNotification[]>(`/local?userId=${userId}`);
  }

  async addLocalNotification(
    notification: Omit<LocalNotification, 'id' | 'timestamp' | 'read'>,
    userId: string
  ): Promise<NotificationApiResponse<LocalNotification>> {
    return this.request<LocalNotification>('/local', {
      method: 'POST',
      body: JSON.stringify({ ...notification, userId }),
    });
  }

  async markLocalAsRead(id: string, userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>(`/local/${id}/read`, {
      method: 'PUT',
      body: JSON.stringify({ userId }),
    });
  }

  async deleteLocalNotification(id: string, userId: string): Promise<NotificationApiResponse<void>> {
    return this.request<void>(`/local/${id}`, {
      method: 'DELETE',
      body: JSON.stringify({ userId }),
    });
  }

  async snoozeLocalNotification(
    id: string,
    snoozeUntil: string,
    userId: string
  ): Promise<NotificationApiResponse<void>> {
    return this.request<void>(`/local/${id}/snooze`, {
      method: 'PUT',
      body: JSON.stringify({ snoozeUntil, userId }),
    });
  }

  // Notification Settings API
  async getNotificationSettings(userId: string): Promise<NotificationApiResponse<NotificationSettings[]>> {
    return this.request<NotificationSettings[]>(`/settings?userId=${userId}`);
  }

  async updateNotificationSettings(
    settings: NotificationSettings[],
    userId: string
  ): Promise<NotificationApiResponse<void>> {
    return this.request<void>('/settings', {
      method: 'PUT',
      body: JSON.stringify({ settings, userId }),
    });
  }

  // Health check endpoint
  async checkHealth(): Promise<NotificationApiResponse<{ status: string }>> {
    return this.request<{ status: string }>('/health');
  }
}

export const notificationApiService = new NotificationApiService();