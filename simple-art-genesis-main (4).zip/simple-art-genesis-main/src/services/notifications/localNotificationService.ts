// Local notification service for SQLite integration

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface LocalNotification {
  id: string;
  title: string;
  message: string;
  category: 'system' | 'tests' | 'memos' | 'reports' | 'users';
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: number; // 0 or 1 for SQLite
  snoozed_until?: string;
  action_url?: string;
  linked_id?: string; // memo_id, test_id, etc.
  priority: 'low' | 'normal' | 'high' | 'critical';
  created_at: string;
  updated_at: string;
}

export interface NotificationSettings {
  id: string;
  user_id: string;
  category: string;
  receive: number; // 0 or 1
  play_sound: number; // 0 or 1
  toast_enabled: number; // 0 or 1
  created_at: string;
  updated_at: string;
}

class LocalNotificationService {
  private isElectron = false;
  private isInitialized = false;
  private listeners: ((notifications: LocalNotification[]) => void)[] = [];
  private soundEnabled = true;
  private lastSeenTimestamp: string | null = null;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
    console.log('Local Notification Service - Electron detected:', this.isElectron);
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        await this.createRequiredTables();
        await this.createDefaultSettings();
        console.log('Local Notification Service initialized with database');
      } else {
        console.warn('Local Notification Service running in browser mode');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Local Notification Service:', error);
      throw error;
    }
  }

  private async createRequiredTables(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Create notifications table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS Notifications (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          category TEXT NOT NULL,
          type TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          read INTEGER DEFAULT 0,
          snoozed_until TEXT,
          action_url TEXT,
          linked_id TEXT,
          priority TEXT DEFAULT 'normal',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create notification settings table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS NotificationSettings (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          category TEXT NOT NULL,
          receive INTEGER DEFAULT 1,
          play_sound INTEGER DEFAULT 1,
          toast_enabled INTEGER DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(user_id, category)
        )
      `);

      // Create user preferences table for last seen
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS UserPreferences (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          key TEXT NOT NULL,
          value TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(user_id, key)
        )
      `);

      // Create indexes for better performance
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_notifications_category ON Notifications(category)
      `);
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_notifications_read ON Notifications(read)
      `);
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_notifications_timestamp ON Notifications(timestamp)
      `);

      console.log('Notification tables and indexes created successfully');
    } catch (error) {
      console.error('Error creating notification tables:', error);
      throw error;
    }
  }

  private async createDefaultSettings(): Promise<void> {
    if (!this.isElectron) return;

    const defaultCategories = ['system', 'tests', 'memos', 'reports', 'users'];
    const defaultUserId = 'default_user';

    try {
      for (const category of defaultCategories) {
        await window.electronAPI.dbQuery(`
          INSERT OR IGNORE INTO NotificationSettings (id, user_id, category, receive, play_sound, toast_enabled)
          VALUES (?, ?, ?, 1, 1, 1)
        `, [`${defaultUserId}_${category}`, defaultUserId, category]);
      }
      console.log('Default notification settings created');
    } catch (error) {
      console.error('Error creating default settings:', error);
    }
  }

  async addNotification(data: {
    title: string;
    message: string;
    category: 'system' | 'tests' | 'memos' | 'reports' | 'users';
    type?: 'info' | 'success' | 'warning' | 'error';
    action_url?: string;
    linked_id?: string;
    priority?: 'low' | 'normal' | 'high' | 'critical';
  }): Promise<string | null> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Notification added (browser mode)');
      return `mock_${Date.now()}`;
    }

    try {
      const id = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const timestamp = new Date().toISOString();
      
      const result = await window.electronAPI.dbQuery(`
        INSERT INTO Notifications (
          id, title, message, category, type, timestamp, read, 
          action_url, linked_id, priority
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        data.title,
        data.message,
        data.category,
        data.type || 'info',
        timestamp,
        0,
        data.action_url || null,
        data.linked_id || null,
        data.priority || 'normal'
      ]);

      if (result.success) {
        console.log(`Added notification: ${id}`);
        this.notifyListeners();
        
        // Check if should play sound and show toast
        await this.handleNewNotificationEffects(data.category, data.type || 'info', data.title, data.message);
        
        return id;
      } else {
        console.error('Failed to add notification:', result.error);
        return null;
      }
    } catch (error) {
      console.error('Error adding notification:', error);
      return null;
    }
  }

  private async handleNewNotificationEffects(category: string, type: string, title: string, message: string): Promise<void> {
    try {
      const settings = await this.getNotificationSettings('default_user', category);
      
      // Play sound if enabled (check if settings is single object, not array)
      if (settings && !Array.isArray(settings) && settings.play_sound && this.soundEnabled) {
        this.playNotificationSound();
      }
      
      // Show toast if enabled
      if (settings && !Array.isArray(settings) && settings.toast_enabled) {
        // Trigger toast notification
        const event = new CustomEvent('show-toast', {
          detail: { title, message, type }
        });
        window.dispatchEvent(event);
      }
    } catch (error) {
      console.error('Error handling notification effects:', error);
    }
  }

  private playNotificationSound(): void {
    try {
      // Create a subtle notification sound
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.2);
    } catch (error) {
      console.error('Error playing notification sound:', error);
    }
  }

  async markAsRead(notificationId: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Notification marked as read (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE Notifications 
        SET read = 1, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [notificationId]);

      if (result.success) {
        console.log(`Marked notification ${notificationId} as read`);
        this.notifyListeners();
        return true;
      } else {
        console.error('Failed to mark notification as read:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
      return false;
    }
  }

  async markAllRead(): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: All notifications marked as read (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE Notifications 
        SET read = 1, updated_at = CURRENT_TIMESTAMP
      `);

      if (result.success) {
        console.log('Marked all notifications as read');
        this.notifyListeners();
        return true;
      } else {
        console.error('Failed to mark all notifications as read:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      return false;
    }
  }

  async deleteOldNotifications(days: number = 30): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Old notifications deleted (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        DELETE FROM Notifications 
        WHERE timestamp <= datetime('now', '-' || ? || ' days')
        AND read = 1
      `, [days]);

      if (result.success) {
        console.log(`Deleted notifications older than ${days} days`);
        this.notifyListeners();
        return true;
      } else {
        console.error('Failed to delete old notifications:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error deleting old notifications:', error);
      return false;
    }
  }

  async snoozeNotification(notificationId: string, until: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Notification snoozed (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE Notifications 
        SET snoozed_until = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [until, notificationId]);

      if (result.success) {
        console.log(`Snoozed notification ${notificationId} until ${until}`);
        this.notifyListeners();
        return true;
      } else {
        console.error('Failed to snooze notification:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error snoozing notification:', error);
      return false;
    }
  }

  async getNotifications(filters?: {
    category?: string;
    read?: boolean;
    limit?: number;
  }): Promise<LocalNotification[]> {
    await this.initialize();

    if (!this.isElectron) {
      return this.getMockNotifications();
    }

    try {
      let query = `
        SELECT * FROM Notifications 
        WHERE (snoozed_until IS NULL OR snoozed_until <= datetime('now'))
      `;
      const params: any[] = [];

      if (filters?.category) {
        query += ' AND category = ?';
        params.push(filters.category);
      }

      if (filters?.read !== undefined) {
        query += ' AND read = ?';
        params.push(filters.read ? 1 : 0);
      }

      query += ' ORDER BY timestamp DESC';

      if (filters?.limit) {
        query += ' LIMIT ?';
        params.push(filters.limit);
      }

      const result = await window.electronAPI.dbQuery(query, params);

      if (!result.success) {
        console.error('Failed to fetch notifications:', result.error);
        return [];
      }

      return result.data as LocalNotification[];
    } catch (error) {
      console.error('Error fetching notifications:', error);
      return [];
    }
  }

  async getNotificationSettings(userId: string, category?: string): Promise<NotificationSettings | NotificationSettings[] | null> {
    await this.initialize();

    if (!this.isElectron) {
      return {
        id: 'mock',
        user_id: userId,
        category: category || 'all',
        receive: 1,
        play_sound: 1,
        toast_enabled: 1,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }

    try {
      let query = 'SELECT * FROM NotificationSettings WHERE user_id = ?';
      const params = [userId];

      if (category) {
        query += ' AND category = ?';
        params.push(category);
      }

      const result = await window.electronAPI.dbQuery(query, params);

      if (!result.success) {
        console.error('Failed to fetch notification settings:', result.error);
        return null;
      }

      return category ? result.data[0] || null : result.data;
    } catch (error) {
      console.error('Error fetching notification settings:', error);
      return null;
    }
  }

  async updateNotificationSettings(userId: string, category: string, settings: {
    receive?: boolean;
    play_sound?: boolean;
    toast_enabled?: boolean;
  }): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Notification settings updated (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE NotificationSettings 
        SET receive = COALESCE(?, receive),
            play_sound = COALESCE(?, play_sound),
            toast_enabled = COALESCE(?, toast_enabled),
            updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ? AND category = ?
      `, [
        settings.receive !== undefined ? (settings.receive ? 1 : 0) : null,
        settings.play_sound !== undefined ? (settings.play_sound ? 1 : 0) : null,
        settings.toast_enabled !== undefined ? (settings.toast_enabled ? 1 : 0) : null,
        userId,
        category
      ]);

      if (result.success) {
        console.log(`Updated notification settings for ${userId}:${category}`);
        return true;
      } else {
        console.error('Failed to update notification settings:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error updating notification settings:', error);
      return false;
    }
  }

  async deleteNotification(notificationId: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Notification deleted (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(
        'DELETE FROM Notifications WHERE id = ?',
        [notificationId]
      );

      if (result.success) {
        console.log(`Deleted notification: ${notificationId}`);
        this.notifyListeners();
        return true;
      } else {
        console.error('Failed to delete notification:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
      return false;
    }
  }

  // Integration methods for other services
  async createMemoNotification(memoId: string, action: 'created' | 'updated' | 'approved', details?: any): Promise<void> {
    const actionMap = {
      created: { type: 'info' as const, title: 'New Memo Created' },
      updated: { type: 'info' as const, title: 'Memo Updated' },
      approved: { type: 'success' as const, title: 'Memo Approved' }
    };

    const { type, title } = actionMap[action];
    
    await this.addNotification({
      title,
      message: `Memo ${details?.reference || memoId} has been ${action}`,
      category: 'memos',
      type,
      action_url: `/test-requests?memo=${memoId}`,
      linked_id: memoId,
      priority: action === 'approved' ? 'high' : 'normal'
    });
  }

  async createTestNotification(testId: string, action: 'due' | 'overdue' | 'completed', details?: any): Promise<void> {
    const actionMap = {
      due: { type: 'warning' as const, title: 'Test Due', priority: 'high' as const },
      overdue: { type: 'error' as const, title: 'Test Overdue', priority: 'critical' as const },
      completed: { type: 'success' as const, title: 'Test Completed', priority: 'normal' as const }
    };

    const { type, title, priority } = actionMap[action];
    
    await this.addNotification({
      title,
      message: `Test ${details?.test_type || 'Unknown'} is ${action}${details?.days ? ` (${details.days} days)` : ''}`,
      category: 'tests',
      type,
      action_url: `/test-calendar?test=${testId}`,
      linked_id: testId,
      priority
    });
  }

  // Subscription and listener management
  subscribe(listener: (notifications: LocalNotification[]) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private async notifyListeners(): Promise<void> {
    try {
      const notifications = await this.getNotifications({ limit: 100 });
      this.listeners.forEach(listener => listener(notifications));
    } catch (error) {
      console.error('Error notifying listeners:', error);
    }
  }

  private getMockNotifications(): LocalNotification[] {
    console.warn('Using mock notification data - database not available');
    return [];
  }

  // Sound control
  setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
  }

  getSoundEnabled(): boolean {
    return this.soundEnabled;
  }
}

export const localNotificationService = new LocalNotificationService();