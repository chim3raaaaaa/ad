// Local reference data service for managing reference datasets
import { CustomReferenceType, FieldDefinition } from '@/components/reference-data/CustomReferenceTypeManager';

export interface ReferenceDataService {
  // Custom Reference Types
  getCustomReferenceTypes(): Promise<CustomReferenceType[]>;
  saveCustomReferenceType(type: CustomReferenceType): Promise<void>;
  deleteCustomReferenceType(id: string): Promise<void>;
  createDynamicTable(tableName: string, fields: FieldDefinition[]): Promise<void>;
  
  // Reference Data CRUD
  getReferenceData(tableName: string): Promise<any[]>;
  createReferenceDataItem(tableName: string, data: any): Promise<any>;
  updateReferenceDataItem(tableName: string, id: string, data: any): Promise<any>;
  deleteReferenceDataItem(tableName: string, id: string): Promise<boolean>;
  
  // CSV Upload
  uploadCSV(tableName: string, csvData: any[]): Promise<{ success: boolean; rowsImported: number; errors?: string[] }>;
  getUploadHistory(): Promise<any[]>;
}

class LocalReferenceDataService implements ReferenceDataService {
  private isElectron(): boolean {
    return typeof window !== 'undefined' && (window as any).electronAPI;
  }

  // Initialize reference tables for sieve grading
  async initializeSieveGradingTables(): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        // Material Types table
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS material_types (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `, []);

        // Standards table
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS standards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `, []);

        // Sieve Sizes table
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS sieve_sizes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            size_mm REAL,
            display_order INTEGER,
            field_key TEXT NOT NULL UNIQUE,
            is_active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `, []);

        // Insert default data if tables are empty
        await this.insertDefaultSieveGradingData();
      }
    } catch (error) {
      console.error('Error initializing sieve grading tables:', error);
    }
  }

  async insertDefaultSieveGradingData(): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        // Check if data already exists
        const materialTypesCount = await window.electronAPI.dbQuery('SELECT COUNT(*) as count FROM material_types', []);
        const standardsCount = await window.electronAPI.dbQuery('SELECT COUNT(*) as count FROM standards', []);
        const sieveSizesCount = await window.electronAPI.dbQuery('SELECT COUNT(*) as count FROM sieve_sizes', []);

        // Insert default material types
        if (materialTypesCount[0]?.count === 0) {
          const defaultMaterialTypes = [
            '4-6mm', '6-10mm', '10-14mm', '14-20mm', '20-31.5mm',
            'All-in 0-31.5mm', 'All-in 0-37.5mm', 'Sand 0-5mm', 'Dust 0-0.075mm'
          ];
          
          for (const type of defaultMaterialTypes) {
            await window.electronAPI.dbQuery(
              'INSERT INTO material_types (name) VALUES (?)',
              [type]
            );
          }
        }

        // Insert default standards
        if (standardsCount[0]?.count === 0) {
          const defaultStandards = ['BS Min', 'BS Max', 'RDA Min', 'RDA Max'];
          
          for (const standard of defaultStandards) {
            await window.electronAPI.dbQuery(
              'INSERT INTO standards (name) VALUES (?)',
              [standard]
            );
          }
        }

        // Insert default sieve sizes
        if (sieveSizesCount[0]?.count === 0) {
          const defaultSieveSizes = [
            { name: '0.075mm', size_mm: 0.075, field_key: 'sieve_0_075', display_order: 1 },
            { name: '0.15mm', size_mm: 0.15, field_key: 'sieve_0_15', display_order: 2 },
            { name: '0.3mm', size_mm: 0.3, field_key: 'sieve_0_3', display_order: 3 },
            { name: '0.6mm', size_mm: 0.6, field_key: 'sieve_0_6', display_order: 4 },
            { name: '1.18mm', size_mm: 1.18, field_key: 'sieve_1_18', display_order: 5 },
            { name: '2.36mm', size_mm: 2.36, field_key: 'sieve_2_36', display_order: 6 },
            { name: '5mm', size_mm: 5, field_key: 'sieve_5', display_order: 7 },
            { name: '10mm', size_mm: 10, field_key: 'sieve_10', display_order: 8 },
            { name: '14mm', size_mm: 14, field_key: 'sieve_14', display_order: 9 },
            { name: '16mm', size_mm: 16, field_key: 'sieve_16', display_order: 10 },
            { name: '20mm', size_mm: 20, field_key: 'sieve_20', display_order: 11 },
            { name: '31.5mm', size_mm: 31.5, field_key: 'sieve_31_5', display_order: 12 },
            { name: '37.5mm', size_mm: 37.5, field_key: 'sieve_37_5', display_order: 13 },
            { name: '45mm', size_mm: 45, field_key: 'sieve_45', display_order: 14 },
            { name: '50mm', size_mm: 50, field_key: 'sieve_50', display_order: 15 },
            { name: '63mm', size_mm: 63, field_key: 'sieve_63', display_order: 16 }
          ];
          
          for (const sieve of defaultSieveSizes) {
            await window.electronAPI.dbQuery(
              'INSERT INTO sieve_sizes (name, size_mm, field_key, display_order) VALUES (?, ?, ?, ?)',
              [sieve.name, sieve.size_mm, sieve.field_key, sieve.display_order]
            );
          }
        }
      }
    } catch (error) {
      console.error('Error inserting default sieve grading data:', error);
    }
  }

  // Material Types CRUD
  async getMaterialTypes(): Promise<any[]> {
    try {
      if (window.electronAPI?.dbQuery) {
        return await window.electronAPI.dbQuery(
          'SELECT * FROM material_types WHERE is_active = 1 ORDER BY name',
          []
        );
      } else {
        const stored = localStorage.getItem('material_types');
        return stored ? JSON.parse(stored) : [];
      }
    } catch (error) {
      console.error('Error getting material types:', error);
      return [];
    }
  }

  async saveMaterialType(data: { name: string; description?: string }): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'INSERT INTO material_types (name, description) VALUES (?, ?)',
          [data.name, data.description || null]
        );
      } else {
        const stored = localStorage.getItem('material_types') || '[]';
        const types = JSON.parse(stored);
        types.push({ id: Date.now(), ...data, is_active: 1, created_at: new Date().toISOString() });
        localStorage.setItem('material_types', JSON.stringify(types));
      }
    } catch (error) {
      console.error('Error saving material type:', error);
      throw error;
    }
  }

  async deleteMaterialType(id: string): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'UPDATE material_types SET is_active = 0 WHERE id = ?',
          [id]
        );
      } else {
        const stored = localStorage.getItem('material_types') || '[]';
        const types = JSON.parse(stored);
        const updated = types.filter((type: any) => type.id.toString() !== id);
        localStorage.setItem('material_types', JSON.stringify(updated));
      }
    } catch (error) {
      console.error('Error deleting material type:', error);
      throw error;
    }
  }

  // Standards CRUD
  async getStandards(): Promise<any[]> {
    try {
      if (window.electronAPI?.dbQuery) {
        return await window.electronAPI.dbQuery(
          'SELECT * FROM standards WHERE is_active = 1 ORDER BY name',
          []
        );
      } else {
        const stored = localStorage.getItem('standards');
        return stored ? JSON.parse(stored) : [];
      }
    } catch (error) {
      console.error('Error getting standards:', error);
      return [];
    }
  }

  async saveStandard(data: { name: string; description?: string }): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'INSERT INTO standards (name, description) VALUES (?, ?)',
          [data.name, data.description || null]
        );
      } else {
        const stored = localStorage.getItem('standards') || '[]';
        const standards = JSON.parse(stored);
        standards.push({ id: Date.now(), ...data, is_active: 1, created_at: new Date().toISOString() });
        localStorage.setItem('standards', JSON.stringify(standards));
      }
    } catch (error) {
      console.error('Error saving standard:', error);
      throw error;
    }
  }

  async deleteStandard(id: string): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'UPDATE standards SET is_active = 0 WHERE id = ?',
          [id]
        );
      } else {
        const stored = localStorage.getItem('standards') || '[]';
        const standards = JSON.parse(stored);
        const updated = standards.filter((standard: any) => standard.id.toString() !== id);
        localStorage.setItem('standards', JSON.stringify(updated));
      }
    } catch (error) {
      console.error('Error deleting standard:', error);
      throw error;
    }
  }

  // Sieve Sizes CRUD
  async getSieveSizes(): Promise<any[]> {
    try {
      if (window.electronAPI?.dbQuery) {
        return await window.electronAPI.dbQuery(
          'SELECT * FROM sieve_sizes WHERE is_active = 1 ORDER BY display_order',
          []
        );
      } else {
        const stored = localStorage.getItem('sieve_sizes');
        return stored ? JSON.parse(stored) : [];
      }
    } catch (error) {
      console.error('Error getting sieve sizes:', error);
      return [];
    }
  }

  async saveSieveSize(data: { name: string; size_mm: number; field_key: string; display_order: number }): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'INSERT INTO sieve_sizes (name, size_mm, field_key, display_order) VALUES (?, ?, ?, ?)',
          [data.name, data.size_mm, data.field_key, data.display_order]
        );
      } else {
        const stored = localStorage.getItem('sieve_sizes') || '[]';
        const sizes = JSON.parse(stored);
        sizes.push({ id: Date.now(), ...data, is_active: 1, created_at: new Date().toISOString() });
        localStorage.setItem('sieve_sizes', JSON.stringify(sizes));
      }
    } catch (error) {
      console.error('Error saving sieve size:', error);
      throw error;
    }
  }

  async deleteSieveSize(id: string): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          'UPDATE sieve_sizes SET is_active = 0 WHERE id = ?',
          [id]
        );
      } else {
        const stored = localStorage.getItem('sieve_sizes') || '[]';
        const sizes = JSON.parse(stored);
        const updated = sizes.filter((size: any) => size.id.toString() !== id);
        localStorage.setItem('sieve_sizes', JSON.stringify(updated));
      }
    } catch (error) {
      console.error('Error deleting sieve size:', error);
      throw error;
    }
  }

  async getCustomReferenceTypes(): Promise<CustomReferenceType[]> {
    if (this.isElectron()) {
      try {
        const result = await (window as any).electronAPI.dbQuery(
          'SELECT * FROM custom_reference_types WHERE is_active = 1 ORDER BY created_at DESC'
        );
        
        return (result.data || []).map((row: any) => ({
          id: row.id,
          name: row.name,
          description: row.description,
          icon: row.icon,
          fields: JSON.parse(row.fields_schema),
          tableName: row.table_name,
          createdAt: new Date(row.created_at),
          isActive: Boolean(row.is_active)
        }));
      } catch (error) {
        console.error('Failed to load custom reference types:', error);
        return [];
      }
    } else {
      // Browser fallback
      const stored = localStorage.getItem('custom_reference_types');
      return stored ? JSON.parse(stored) : [];
    }
  }

  async saveCustomReferenceType(type: CustomReferenceType): Promise<void> {
    if (this.isElectron()) {
      try {
        await (window as any).electronAPI.dbRun(
          `INSERT OR REPLACE INTO custom_reference_types 
           (id, name, description, icon, fields_schema, table_name, created_at, is_active, updated_at) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            type.id,
            type.name,
            type.description,
            type.icon,
            JSON.stringify(type.fields),
            type.tableName,
            type.createdAt.toISOString(),
            type.isActive ? 1 : 0,
            new Date().toISOString()
          ]
        );
      } catch (error) {
        console.error('Failed to save custom reference type:', error);
        throw error;
      }
    } else {
      // Browser fallback
      const existingTypes = await this.getCustomReferenceTypes();
      const updatedTypes = existingTypes.filter(t => t.id !== type.id);
      updatedTypes.push(type);
      localStorage.setItem('custom_reference_types', JSON.stringify(updatedTypes));
    }
  }

  async deleteCustomReferenceType(id: string): Promise<void> {
    if (this.isElectron()) {
      try {
        await (window as any).electronAPI.dbRun(
          'UPDATE custom_reference_types SET is_active = 0, updated_at = ? WHERE id = ?',
          [new Date().toISOString(), id]
        );
      } catch (error) {
        console.error('Failed to delete custom reference type:', error);
        throw error;
      }
    } else {
      // Browser fallback
      const existingTypes = await this.getCustomReferenceTypes();
      const updatedTypes = existingTypes.map(type =>
        type.id === id ? { ...type, isActive: false } : type
      );
      localStorage.setItem('custom_reference_types', JSON.stringify(updatedTypes));
    }
  }

  async createDynamicTable(tableName: string, fields: FieldDefinition[]): Promise<void> {
    if (!this.isElectron()) return; // Only supported in Electron

    const columnDefinitions = fields.map(field => {
      let columnDef = `${field.name} `;
      switch (field.type) {
        case 'number':
          columnDef += 'REAL';
          break;
        case 'date':
          columnDef += 'DATETIME';
          break;
        case 'boolean':
          columnDef += 'INTEGER';
          break;
        default:
          columnDef += 'TEXT';
      }
      if (field.required) {
        columnDef += ' NOT NULL';
      }
      return columnDef;
    }).join(', ');

    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id TEXT PRIMARY KEY,
        ${columnDefinitions},
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    try {
      await (window as any).electronAPI.dbRun(createTableSQL);
    } catch (error) {
      console.error('Failed to create dynamic table:', error);
      throw error;
    }
  }

  // Reference Data CRUD Operations
  async getReferenceData(tableName: string): Promise<any[]> {
    if (this.isElectron()) {
      try {
        const result = await (window as any).electronAPI.dbQuery(
          `SELECT * FROM ${tableName} ORDER BY created_at DESC`
        );
        return result.data || [];
      } catch (error) {
        console.error(`Failed to load data from ${tableName}:`, error);
        return [];
      }
    } else {
      // Browser fallback
      const stored = localStorage.getItem(`reference_data_${tableName}`);
      return stored ? JSON.parse(stored) : [];
    }
  }

  async createReferenceDataItem(tableName: string, data: any): Promise<any> {
    const id = `${tableName}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    
    const itemWithMetadata = {
      id,
      ...data,
      created_at: now,
      updated_at: now
    };

    if (this.isElectron()) {
      try {
        const columns = Object.keys(itemWithMetadata);
        const placeholders = columns.map(() => '?').join(', ');
        const values = Object.values(itemWithMetadata);

        await (window as any).electronAPI.dbRun(
          `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders})`,
          values
        );
      } catch (error) {
        console.error(`Failed to create item in ${tableName}:`, error);
        throw error;
      }
    } else {
      // Browser fallback
      const existingData = await this.getReferenceData(tableName);
      existingData.push(itemWithMetadata);
      localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(existingData));
    }

    return itemWithMetadata;
  }

  async updateReferenceDataItem(tableName: string, id: string, data: any): Promise<any> {
    const now = new Date().toISOString();
    const updateData = { ...data, updated_at: now };

    if (this.isElectron()) {
      try {
        const updateFields = Object.keys(updateData);
        const setClause = updateFields.map(field => `${field} = ?`).join(', ');
        const values = [...Object.values(updateData), id];

        await (window as any).electronAPI.dbRun(
          `UPDATE ${tableName} SET ${setClause} WHERE id = ?`,
          values
        );

        const result = await (window as any).electronAPI.dbQuery(
          `SELECT * FROM ${tableName} WHERE id = ?`,
          [id]
        );
        return result.data?.[0];
      } catch (error) {
        console.error(`Failed to update item in ${tableName}:`, error);
        throw error;
      }
    } else {
      // Browser fallback
      const existingData = await this.getReferenceData(tableName);
      const updatedData = existingData.map(item =>
        item.id === id ? { ...item, ...updateData } : item
      );
      localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(updatedData));
      return updatedData.find(item => item.id === id);
    }
  }

  async deleteReferenceDataItem(tableName: string, id: string): Promise<boolean> {
    if (this.isElectron()) {
      try {
        const result = await (window as any).electronAPI.dbRun(
          `DELETE FROM ${tableName} WHERE id = ?`,
          [id]
        );
        return result.changes > 0;
      } catch (error) {
        console.error(`Failed to delete item from ${tableName}:`, error);
        return false;
      }
    } else {
      // Browser fallback
      const existingData = await this.getReferenceData(tableName);
      const filteredData = existingData.filter(item => item.id !== id);
      localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(filteredData));
      return filteredData.length < existingData.length;
    }
  }

  // CSV Upload functionality
  async uploadCSV(tableName: string, csvData: any[]): Promise<{ success: boolean; rowsImported: number; errors?: string[] }> {
    const errors: string[] = [];
    let rowsImported = 0;

    try {
      for (const row of csvData) {
        try {
          await this.createReferenceDataItem(tableName, row);
          rowsImported++;
        } catch (error) {
          errors.push(`Row ${rowsImported + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

      // Log the upload
      await this.logUpload(tableName, rowsImported, errors.length === 0 ? 'success' : 'partial', errors.join('; '));

      return {
        success: errors.length === 0,
        rowsImported,
        errors: errors.length > 0 ? errors : undefined
      };
    } catch (error) {
      await this.logUpload(tableName, rowsImported, 'error', error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  }

  private async logUpload(tableName: string, rowsImported: number, status: string, errorMessage?: string): Promise<void> {
    if (!this.isElectron()) return;

    try {
      await (window as any).electronAPI.dbRun(
        `INSERT INTO reference_data_upload_log 
         (id, filename, table_name, rows_imported, status, error_message, uploaded_by, upload_timestamp) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          `upload_${Date.now()}`,
          `${tableName}_import.csv`,
          tableName,
          rowsImported,
          status,
          errorMessage || null,
          'current_user',
          new Date().toISOString()
        ]
      );
    } catch (error) {
      console.error('Failed to log upload:', error);
    }
  }

  async getUploadHistory(): Promise<any[]> {
    if (this.isElectron()) {
      try {
        const result = await (window as any).electronAPI.dbQuery(
          'SELECT * FROM reference_data_upload_log ORDER BY upload_timestamp DESC LIMIT 50'
        );
        return result.data || [];
      } catch (error) {
        console.error('Failed to load upload history:', error);
        return [];
      }
    } else {
      // Browser fallback
      const stored = localStorage.getItem('upload_history');
      return stored ? JSON.parse(stored) : [];
    }
  }
}

// Export singleton instance
export const localReferenceDataService = new LocalReferenceDataService();
