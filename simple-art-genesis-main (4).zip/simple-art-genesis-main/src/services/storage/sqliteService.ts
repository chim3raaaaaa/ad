// Local SQLite database service for Electron app
import type { IDataService } from '../api/interface';
import type {
  Memo,
  TestRequest,
  UserProfile,
  UserRole,
  AnalyticsData,
  ApiResponse,
  PaginatedResponse,
  QueryOptions,
  Module,
  ModuleInstance,
  ModuleMarketplace,
  ValidationRule,
  ValidationResult,
  TestSchedule,
  ScheduleTemplate,
  TableRelationship,
  NavigationPath,
  DataVersion,
  ChangeRequest,
  ApprovalWorkflow
} from '../api/types';

interface SQLiteDatabase {
  exec(sql: string): any;
  prepare(sql: string): SQLiteStatement;
  transaction(fn: () => void): void;
}

interface SQLiteStatement {
  all(...params: any[]): any[];
  run(...params: any[]): { lastInsertRowid: number; changes: number };
  get(...params: any[]): any;
  finalize(): void;
}

// Schema definitions for local database
const SCHEMA_SQL = `
-- Memos table
CREATE TABLE IF NOT EXISTS memos (
  id TEXT PRIMARY KEY,
  ref TEXT NOT NULL,
  created_at TEXT NOT NULL,
  production_data TEXT, -- JSON string
  user_id TEXT
);

-- Reference Tables for Lookups
CREATE TABLE IF NOT EXISTS climatic_conditions (
  code TEXT PRIMARY KEY,
  description TEXT,
  active TEXT
);

CREATE TABLE IF NOT EXISTS colour (
  code TEXT PRIMARY KEY,
  description TEXT,
  active TEXT
);

CREATE TABLE IF NOT EXISTS lab_group_code (
  lab_site TEXT,
  lab_product TEXT,
  lab_machine TEXT,
  code TEXT PRIMARY KEY,
  active TEXT
);

CREATE TABLE IF NOT EXISTS lab_mould (
  lab_site TEXT,
  code TEXT,
  description TEXT,
  position TEXT,
  active TEXT
);

CREATE TABLE IF NOT EXISTS lab_tests (
  product_type TEXT,
  code TEXT PRIMARY KEY,
  description TEXT,
  sort_order INTEGER,
  active TEXT
);

CREATE TABLE IF NOT EXISTS sampling_places (
  code TEXT PRIMARY KEY,
  description TEXT,
  product_type TEXT
);

-- Test Requests table  
CREATE TABLE IF NOT EXISTS test_requests (
  id TEXT PRIMARY KEY,
  client_name TEXT NOT NULL,
  sample_description TEXT NOT NULL,
  test_type TEXT NOT NULL,
  priority TEXT CHECK(priority IN ('low', 'medium', 'high', 'urgent')) NOT NULL,
  status TEXT CHECK(status IN ('pending', 'in_progress', 'completed', 'cancelled')) NOT NULL,
  assigned_to TEXT,
  due_date TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT
);

-- User Profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL,
  department TEXT NOT NULL,
  status TEXT CHECK(status IN ('active', 'inactive')) NOT NULL,
  last_login TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- User Roles table  
CREATE TABLE IF NOT EXISTS user_roles (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  permissions TEXT NOT NULL, -- JSON string
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Custom Forms table (for Form Builder)
CREATE TABLE IF NOT EXISTS custom_forms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  fields TEXT NOT NULL, -- JSON string
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Custom Tables table (for Table Builder)
CREATE TABLE IF NOT EXISTS custom_tables (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  columns TEXT NOT NULL, -- JSON string
  data_source TEXT NOT NULL,
  api_endpoint TEXT,
  features TEXT NOT NULL, -- JSON string
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Data Links table (for data relationships)
CREATE TABLE IF NOT EXISTS data_links (
  id TEXT PRIMARY KEY,
  source_table TEXT NOT NULL,
  source_field TEXT NOT NULL,
  target_table TEXT NOT NULL,
  target_field TEXT NOT NULL,
  link_type TEXT CHECK(link_type IN ('1:1', '1:N', 'N:1', 'N:N', 'lookup')) NOT NULL,
  cascade_delete BOOLEAN DEFAULT FALSE,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

-- Audit Log table
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  old_data TEXT, -- JSON string
  new_data TEXT, -- JSON string
  ip_address TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL
);

-- Modules table (for plugin system)
CREATE TABLE IF NOT EXISTS modules (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  version TEXT NOT NULL,
  description TEXT,
  schema_definition TEXT NOT NULL, -- JSON string
  components TEXT, -- JSON string paths
  enabled BOOLEAN DEFAULT TRUE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Test Data Entries table (for Test Data Explorer)
CREATE TABLE IF NOT EXISTS test_data_entries (
  id TEXT PRIMARY KEY,
  module_id TEXT NOT NULL,
  test_type TEXT NOT NULL,
  batch_id TEXT,
  product_type TEXT,
  test_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  site TEXT,
  memo_reference TEXT,
  operator TEXT,
  test_results TEXT NOT NULL, -- JSON string with test values
  calculated_fields TEXT, -- JSON string with derived values
  pass_fail_status TEXT, -- 'pass', 'fail', 'pending'
  source TEXT DEFAULT 'manual', -- 'manual', 'imported', 'liveshare'
  raw_data TEXT, -- JSON string for original imported data
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT
);

-- Test Data Templates table (for Excel import templates)
CREATE TABLE IF NOT EXISTS test_data_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  module_id TEXT NOT NULL,
  column_mapping TEXT NOT NULL, -- JSON string mapping Excel columns to fields
  validation_rules TEXT, -- JSON string with validation rules
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT
);

-- Test Thresholds table (for pass/fail criteria)
CREATE TABLE IF NOT EXISTS test_thresholds (
  id TEXT PRIMARY KEY,
  module_id TEXT NOT NULL,
  test_type TEXT NOT NULL,
  parameter_name TEXT NOT NULL,
  min_value REAL,
  max_value REAL,
  unit TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Custom Components table (for Component Builder)
CREATE TABLE IF NOT EXISTS custom_components (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  component_type TEXT NOT NULL, -- 'ui', 'functional', 'layout'
  template_code TEXT NOT NULL, -- React component code
  props_schema TEXT, -- JSON string defining props
  style_config TEXT, -- JSON string for styling
  dependencies TEXT, -- JSON array of required imports
  category TEXT DEFAULT 'custom',
  is_reusable BOOLEAN DEFAULT TRUE,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Workflows table (for Workflow Builder)
CREATE TABLE IF NOT EXISTS workflows (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  trigger_config TEXT NOT NULL, -- JSON string with trigger setup
  steps TEXT NOT NULL, -- JSON array of workflow steps
  status TEXT CHECK(status IN ('active', 'inactive', 'draft')) DEFAULT 'draft',
  execution_count INTEGER DEFAULT 0,
  last_execution TEXT, -- ISO datetime
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Workflow Executions table (for tracking workflow runs)
CREATE TABLE IF NOT EXISTS workflow_executions (
  id TEXT PRIMARY KEY,
  workflow_id TEXT NOT NULL,
  status TEXT CHECK(status IN ('running', 'completed', 'failed', 'cancelled')) DEFAULT 'running',
  start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  end_time DATETIME,
  current_step TEXT,
  execution_logs TEXT, -- JSON array of log entries
  error_message TEXT,
  input_data TEXT, -- JSON string of input data
  output_data TEXT, -- JSON string of output data
  FOREIGN KEY (workflow_id) REFERENCES workflows(id) ON DELETE CASCADE
);

-- API Endpoints table (for API Manager)
CREATE TABLE IF NOT EXISTS api_endpoints (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  method TEXT CHECK(method IN ('GET', 'POST', 'PUT', 'DELETE', 'PATCH')) NOT NULL,
  path TEXT NOT NULL,
  headers TEXT, -- JSON object with header key-value pairs
  query_params TEXT, -- JSON object with query parameter definitions
  request_body_schema TEXT, -- JSON schema for request body
  response_schema TEXT, -- JSON schema for response
  auth_required BOOLEAN DEFAULT FALSE,
  rate_limit INTEGER, -- requests per minute
  is_active BOOLEAN DEFAULT TRUE,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- API Endpoint Logs table (for tracking API usage)
CREATE TABLE IF NOT EXISTS api_endpoint_logs (
  id TEXT PRIMARY KEY,
  endpoint_id TEXT NOT NULL,
  request_method TEXT NOT NULL,
  request_path TEXT NOT NULL,
  request_headers TEXT, -- JSON object
  request_body TEXT, -- JSON string
  response_status INTEGER,
  response_body TEXT, -- JSON string
  response_time_ms INTEGER,
  user_id TEXT,
  ip_address TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (endpoint_id) REFERENCES api_endpoints(id) ON DELETE CASCADE
);

-- Custom Reference Types table (for Reference Data Manager)
CREATE TABLE IF NOT EXISTS custom_reference_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT DEFAULT 'Database',
  fields_schema TEXT NOT NULL, -- JSON string with field definitions
  table_name TEXT NOT NULL UNIQUE,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT
);

-- Reference Data Tables (for built-in reference data)
CREATE TABLE IF NOT EXISTS product_categories (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  is_active INTEGER DEFAULT 1,
  sort_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category_id TEXT,
  description TEXT,
  unit_of_measure TEXT,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES product_categories(id)
);

CREATE TABLE IF NOT EXISTS grades (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  product_type TEXT,
  specifications TEXT, -- JSON string
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plants (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  location TEXT,
  contact_info TEXT, -- JSON string
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  contact_person TEXT,
  email TEXT,
  phone TEXT,
  address TEXT,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reference_data_upload_log (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  table_name TEXT NOT NULL,
  rows_imported INTEGER DEFAULT 0,
  status TEXT CHECK(status IN ('success', 'error', 'partial')) NOT NULL,
  error_message TEXT,
  uploaded_by TEXT,
  upload_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
`;

export class SQLiteDataService implements IDataService {
  private db: SQLiteDatabase | null = null;
  private isElectron = false;

  constructor() {
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      // Check if running in Electron environment
      this.isElectron = typeof window !== 'undefined' && 
                        window.require !== undefined;

      if (this.isElectron) {
        // Initialize SQLite in Electron
        const path = window.require('path');
        const { app } = window.require('@electron/remote');
        const Database = window.require('better-sqlite3');
        
        const dbPath = path.join(app.getPath('userData'), 'lab_data.db');
        this.db = new Database(dbPath);
        
        // Initialize schema
        this.db.exec(SCHEMA_SQL);
        
        // Add sample test data if none exists
        await this.addSampleTestData();
        
        console.log('SQLite database initialized at:', dbPath);
      } else {
        console.warn('SQLite service requires Electron environment. Falling back to mock data.');
      }
    } catch (error) {
      console.error('Failed to initialize SQLite database:', error);
    }
  }

  private executeQuery<T>(sql: string, params: any[] = []): T[] {
    if (!this.db || !this.isElectron) {
      console.warn('Database not available, returning empty results');
      return [];
    }

    try {
      const stmt = this.db.prepare(sql);
      const result = stmt.all(...params);
      stmt.finalize();
      return result as T[];
    } catch (error) {
      console.error('Database query error:', error);
      return [];
    }
  }

  private executeInsert(sql: string, params: any[] = []): { id: number; changes: number } {
    if (!this.db || !this.isElectron) {
      return { id: 0, changes: 0 };
    }

    try {
      const stmt = this.db.prepare(sql);
      const result = stmt.run(...params);
      stmt.finalize();
      return { id: result.lastInsertRowid as number, changes: result.changes };
    } catch (error) {
      console.error('Database insert error:', error);
      return { id: 0, changes: 0 };
    }
  }

  private executeRun(sql: string, params: any[] = []): { id: number; changes: number } {
    return this.executeInsert(sql, params);
  }

  // Audit logging
  private logAction(action: string, resourceType: string, resourceId?: string, oldData?: any, newData?: any) {
    if (!this.db || !this.isElectron) return;

    const logEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      user_id: 'current_user', // Should get from auth context
      action,
      resource_type: resourceType,
      resource_id: resourceId || null,
      old_data: oldData ? JSON.stringify(oldData) : null,
      new_data: newData ? JSON.stringify(newData) : null,
      ip_address: '127.0.0.1',
      user_agent: navigator.userAgent,
      created_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, old_data, new_data, ip_address, user_agent, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(logEntry)
    );
  }

  // Memo operations
  async getMemos(options?: QueryOptions): Promise<PaginatedResponse<Memo>> {
    const memos = this.executeQuery<any>('SELECT * FROM memos ORDER BY created_at DESC');
    
    return {
      data: memos.map(m => ({
        ...m,
        production_data: m.production_data ? JSON.parse(m.production_data) : []
      })),
      count: memos.length,
      page: options?.page || 1,
      totalPages: Math.ceil(memos.length / (options?.limit || 10))
    };
  }

  async getMemoById(id: string): Promise<ApiResponse<Memo>> {
    const results = this.executeQuery<any>('SELECT * FROM memos WHERE id = ?', [id]);
    
    if (results.length === 0) {
      return { data: null as any, error: 'Memo not found' };
    }

    const memo = results[0];
    return {
      data: {
        ...memo,
        production_data: memo.production_data ? JSON.parse(memo.production_data) : []
      }
    };
  }

  async createMemo(memo: Omit<Memo, 'id' | 'created_at'>): Promise<ApiResponse<Memo>> {
    const newMemo = {
      id: `memo_${Date.now()}`,
      ...memo,
      created_at: new Date().toISOString(),
      production_data: JSON.stringify(memo.production_data || [])
    };

    this.executeInsert(
      'INSERT INTO memos (id, ref, created_at, production_data, user_id) VALUES (?, ?, ?, ?, ?)',
      [newMemo.id, newMemo.ref, newMemo.created_at, newMemo.production_data, newMemo.user_id]
    );

    this.logAction('create', 'memo', newMemo.id, null, newMemo);

    return {
      data: {
        ...newMemo,
        production_data: memo.production_data || []
      }
    };
  }

  async updateMemo(id: string, memo: Partial<Memo>): Promise<ApiResponse<Memo>> {
    const existing = await this.getMemoById(id);
    if (existing.error) {
      return existing;
    }

    const updateData = {
      ...memo,
      production_data: memo.production_data ? JSON.stringify(memo.production_data) : undefined
    };

    const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
    const updateValues = updateFields.map(key => updateData[key]);
    
    if (updateFields.length > 0) {
      const sql = `UPDATE memos SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
      this.executeInsert(sql, [...updateValues, id]);
      
      this.logAction('update', 'memo', id, existing.data, updateData);
    }

    return this.getMemoById(id);
  }

  async deleteMemo(id: string): Promise<ApiResponse<boolean>> {
    const existing = await this.getMemoById(id);
    if (existing.error) {
      return { data: false, error: existing.error };
    }

    this.executeInsert('DELETE FROM memos WHERE id = ?', [id]);
    this.logAction('delete', 'memo', id, existing.data, null);

    return { data: true };
  }

  // Test Request operations (similar pattern)
  async getTestRequests(options?: QueryOptions): Promise<PaginatedResponse<TestRequest>> {
    const requests = this.executeQuery<TestRequest>('SELECT * FROM test_requests ORDER BY created_at DESC');
    
    return {
      data: requests,
      count: requests.length,
      page: options?.page || 1,
      totalPages: Math.ceil(requests.length / (options?.limit || 10))
    };
  }

  async getTestRequestById(id: string): Promise<ApiResponse<TestRequest>> {
    const results = this.executeQuery<TestRequest>('SELECT * FROM test_requests WHERE id = ?', [id]);
    
    if (results.length === 0) {
      return { data: null as any, error: 'Test request not found' };
    }

    return { data: results[0] };
  }

  async createTestRequest(testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestRequest>> {
    const newRequest = {
      id: `request_${Date.now()}`,
      ...testRequest,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO test_requests (id, client_name, sample_description, test_type, priority, status, assigned_to, due_date, created_at, updated_at, user_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(newRequest)
    );

    this.logAction('create', 'test_request', newRequest.id, null, newRequest);

    return { data: newRequest };
  }

  async updateTestRequest(id: string, testRequest: Partial<TestRequest>): Promise<ApiResponse<TestRequest>> {
    const existing = await this.getTestRequestById(id);
    if (existing.error) {
      return existing;
    }

    const updateData = { ...testRequest, updated_at: new Date().toISOString() };
    const updateFields = Object.keys(updateData);
    const updateValues = updateFields.map(key => updateData[key]);
    
    const sql = `UPDATE test_requests SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
    this.executeInsert(sql, [...updateValues, id]);
    
    this.logAction('update', 'test_request', id, existing.data, updateData);

    return this.getTestRequestById(id);
  }

  async deleteTestRequest(id: string): Promise<ApiResponse<boolean>> {
    const existing = await this.getTestRequestById(id);
    if (existing.error) {
      return { data: false, error: existing.error };
    }

    this.executeInsert('DELETE FROM test_requests WHERE id = ?', [id]);
    this.logAction('delete', 'test_request', id, existing.data, null);

    return { data: true };
  }

  // User Profile operations (simplified for brevity)
  async getUserProfiles(options?: QueryOptions): Promise<PaginatedResponse<UserProfile>> {
    const profiles = this.executeQuery<UserProfile>('SELECT * FROM user_profiles ORDER BY created_at DESC');
    
    return {
      data: profiles,
      count: profiles.length,
      page: options?.page || 1,
      totalPages: Math.ceil(profiles.length / (options?.limit || 10))
    };
  }

  async getUserProfileById(id: string): Promise<ApiResponse<UserProfile>> {
    const results = this.executeQuery<UserProfile>('SELECT * FROM user_profiles WHERE id = ?', [id]);
    return results.length > 0 ? { data: results[0] } : { data: null as any, error: 'Profile not found' };
  }

  async createUserProfile(profile: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserProfile>> {
    const newProfile = {
      id: `profile_${Date.now()}`,
      ...profile,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO user_profiles (id, user_id, name, email, role, department, status, last_login, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(newProfile)
    );

    this.logAction('create', 'user_profile', newProfile.id, null, newProfile);
    return { data: newProfile };
  }

  async updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<ApiResponse<UserProfile>> {
    const existing = await this.getUserProfileById(id);
    if (existing.error) return existing;

    const updateData = { ...profile, updated_at: new Date().toISOString() };
    const updateFields = Object.keys(updateData);
    const updateValues = updateFields.map(key => updateData[key]);
    
    const sql = `UPDATE user_profiles SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
    this.executeInsert(sql, [...updateValues, id]);
    
    this.logAction('update', 'user_profile', id, existing.data, updateData);
    return this.getUserProfileById(id);
  }

  async deleteUserProfile(id: string): Promise<ApiResponse<boolean>> {
    const existing = await this.getUserProfileById(id);
    if (existing.error) return { data: false, error: existing.error };

    this.executeInsert('DELETE FROM user_profiles WHERE id = ?', [id]);
    this.logAction('delete', 'user_profile', id, existing.data, null);
    return { data: true };
  }

  // User Role operations
  async getUserRoles(): Promise<ApiResponse<UserRole[]>> {
    const roles = this.executeQuery<any>('SELECT * FROM user_roles ORDER BY created_at DESC');
    
    return {
      data: roles.map(r => ({
        ...r,
        permissions: r.permissions ? JSON.parse(r.permissions) : []
      }))
    };
  }

  async getUserRoleById(id: string): Promise<ApiResponse<UserRole>> {
    const results = this.executeQuery<any>('SELECT * FROM user_roles WHERE id = ?', [id]);
    
    if (results.length === 0) {
      return { data: null as any, error: 'Role not found' };
    }

    const role = results[0];
    return {
      data: {
        ...role,
        permissions: role.permissions ? JSON.parse(role.permissions) : []
      }
    };
  }

  async createUserRole(role: Omit<UserRole, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserRole>> {
    const newRole = {
      id: `role_${Date.now()}`,
      ...role,
      permissions: JSON.stringify(role.permissions),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      'INSERT INTO user_roles (id, name, description, permissions, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      Object.values(newRole)
    );

    this.logAction('create', 'user_role', newRole.id, null, newRole);

    return {
      data: {
        ...newRole,
        permissions: role.permissions
      }
    };
  }

  async updateUserRole(id: string, role: Partial<UserRole>): Promise<ApiResponse<UserRole>> {
    const existing = await this.getUserRoleById(id);
    if (existing.error) return existing;

    const updateData = {
      ...role,
      permissions: role.permissions ? JSON.stringify(role.permissions) : undefined,
      updated_at: new Date().toISOString()
    };

    const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
    const updateValues = updateFields.map(key => updateData[key]);
    
    if (updateFields.length > 0) {
      const sql = `UPDATE user_roles SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
      this.executeInsert(sql, [...updateValues, id]);
      
      this.logAction('update', 'user_role', id, existing.data, updateData);
    }

    return this.getUserRoleById(id);
  }

  async deleteUserRole(id: string): Promise<ApiResponse<boolean>> {
    const existing = await this.getUserRoleById(id);
    if (existing.error) return { data: false, error: existing.error };

    this.executeInsert('DELETE FROM user_roles WHERE id = ?', [id]);
    this.logAction('delete', 'user_role', id, existing.data, null);
    return { data: true };
  }

  // Analytics operations
  async getAnalyticsData(): Promise<ApiResponse<AnalyticsData>> {
    const totalTests = this.executeQuery<any>('SELECT COUNT(*) as count FROM test_requests')[0]?.count || 0;
    const completedTests = this.executeQuery<any>("SELECT COUNT(*) as count FROM test_requests WHERE status = 'completed'")[0]?.count || 0;
    const pendingTests = this.executeQuery<any>("SELECT COUNT(*) as count FROM test_requests WHERE status = 'pending'")[0]?.count || 0;
    const activeUsers = this.executeQuery<any>("SELECT COUNT(*) as count FROM user_profiles WHERE status = 'active'")[0]?.count || 0;

    return {
      data: {
        totalTests,
        completedTests,
        pendingTests,
        activeUsers,
        completionRate: totalTests > 0 ? (completedTests / totalTests) * 100 : 0
      }
    };
  }

  async getMonthlyTestData(): Promise<ApiResponse<any[]>> {
    // Return mock data - implement based on actual needs
    return { data: [] };
  }

  async getTestTypeDistribution(): Promise<ApiResponse<any[]>> {
    const distribution = this.executeQuery<any>(
      `SELECT test_type, COUNT(*) as count 
       FROM test_requests 
       GROUP BY test_type 
       ORDER BY count DESC`
    );

    return { data: distribution };
  }

  async getCurrentUser(): Promise<ApiResponse<UserProfile | null>> {
    // Should integrate with authentication system
    return { data: null };
  }

  // Data linking operations
  async createDataLink(link: {
    sourceTable: string;
    sourceField: string; 
    targetTable: string;
    targetField: string;
    linkType: '1:1' | '1:N' | 'N:1' | 'N:N' | 'lookup';
    cascadeDelete?: boolean;
  }): Promise<ApiResponse<any>> {
    const newLink = {
      id: `link_${Date.now()}`,
      ...link,
      cascade_delete: link.cascadeDelete || false,
      created_by: 'current_user',
      created_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO data_links (id, source_table, source_field, target_table, target_field, link_type, cascade_delete, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(newLink)
    );

    this.logAction('create', 'data_link', newLink.id, null, newLink);
    return { data: newLink };
  }

  async getDataLinks(): Promise<ApiResponse<any[]>> {
    const links = this.executeQuery<any>('SELECT * FROM data_links ORDER BY created_at DESC');
    return { data: links };
  }

  // Module operations for plugin system
  async getModules(options: QueryOptions = {}): Promise<PaginatedResponse<Module>> {
    const modules = this.executeQuery<any>('SELECT * FROM modules ORDER BY name');
    return {
      data: modules.map(m => ({
        ...m,
        config: JSON.parse(m.config || '{}'),
        schema: JSON.parse(m.schema_definition || '{}'),
        components: JSON.parse(m.components || '[]'),
        logic: JSON.parse(m.logic || '{}'),
        enabled: Boolean(m.enabled)
      })),
      count: modules.length,
      page: 1,
      totalPages: 1
    };
  }

  async installModule(module: {
    name: string;
    version: string;
    description?: string;
    schemaDefinition: any;
    components?: string[];
  }): Promise<ApiResponse<any>> {
    const newModule = {
      id: `module_${Date.now()}`,
      ...module,
      schema_definition: JSON.stringify(module.schemaDefinition),
      components: JSON.stringify(module.components || []),
      enabled: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO modules (id, name, version, description, schema_definition, components, enabled, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(newModule)
    );

    this.logAction('install', 'module', newModule.id, null, newModule);
    return { data: newModule };
  }

  async getModuleById(id: string): Promise<ApiResponse<Module>> {
    const modules = this.executeQuery<any>('SELECT * FROM modules WHERE id = ?', [id]);
    if (modules.length === 0) {
      return { data: null as any, error: 'Module not found' };
    }

    const module = modules[0];
    return {
      data: {
        ...module,
        config: JSON.parse(module.config || '{}'),
        schema: JSON.parse(module.schema_definition || '{}'),
        components: JSON.parse(module.components || '[]'),
        logic: JSON.parse(module.logic || '{}'),
        enabled: Boolean(module.enabled)
      }
    };
  }

  async uninstallModule(id: string): Promise<ApiResponse<boolean>> {
    this.executeQuery('DELETE FROM modules WHERE id = ?', [id]);
    this.logAction('uninstall', 'module', id, null, null);
    return { data: true };
  }

  async enableModule(id: string): Promise<ApiResponse<boolean>> {
    this.executeQuery('UPDATE modules SET enabled = 1, updated_at = ? WHERE id = ?', [new Date().toISOString(), id]);
    this.logAction('enable', 'module', id, null, null);
    return { data: true };
  }

  async disableModule(id: string): Promise<ApiResponse<boolean>> {
    this.executeQuery('UPDATE modules SET enabled = 0, updated_at = ? WHERE id = ?', [new Date().toISOString(), id]);
    this.logAction('disable', 'module', id, null, null);
    return { data: true };
  }

  async updateModule(id: string, updates: Partial<Module>): Promise<ApiResponse<Module>> {
    const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
    const values = [...Object.values(updates), new Date().toISOString(), id];
    
    this.executeQuery(
      `UPDATE modules SET ${setClause}, updated_at = ? WHERE id = ?`,
      values
    );

    const updated = await this.getModuleById(id);
    this.logAction('update', 'module', id, null, updates);
    return updated;
  }

  async getModuleInstances(moduleId?: string): Promise<ApiResponse<ModuleInstance[]>> {
    const query = moduleId 
      ? 'SELECT * FROM module_instances WHERE module_id = ? ORDER BY name'
      : 'SELECT * FROM module_instances ORDER BY name';
    const params = moduleId ? [moduleId] : [];
    
    const instances = this.executeQuery<any>(query, params);
    return {
      data: instances.map(i => ({
        ...i,
        configuration: JSON.parse(i.configuration || '{}'),
        enabled: Boolean(i.enabled)
      }))
    };
  }

  async createModuleInstance(instance: Omit<ModuleInstance, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ModuleInstance>> {
    const newInstance = {
      id: `instance_${Date.now()}`,
      ...instance,
      configuration: JSON.stringify(instance.configuration || {}),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeQuery(
      `INSERT INTO module_instances (id, module_id, name, configuration, enabled, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      Object.values(newInstance)
    );

    return { 
      data: {
        ...newInstance,
        configuration: instance.configuration || {},
        enabled: Boolean(newInstance.enabled)
      }
    };
  }

  async updateModuleInstance(id: string, updates: Partial<ModuleInstance>): Promise<ApiResponse<ModuleInstance>> {
    const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
    const values = [...Object.values(updates), new Date().toISOString(), id];
    
    this.executeQuery(
      `UPDATE module_instances SET ${setClause}, updated_at = ? WHERE id = ?`,
      values
    );

    const instance = this.executeQuery<any>('SELECT * FROM module_instances WHERE id = ?', [id])[0];
    return { 
      data: {
        ...instance,
        configuration: JSON.parse(instance.configuration || '{}'),
        enabled: Boolean(instance.enabled)
      }
    };
  }

  async deleteModuleInstance(id: string): Promise<ApiResponse<boolean>> {
    this.executeQuery('DELETE FROM module_instances WHERE id = ?', [id]);
    return { data: true };
  }

  async getMarketplaceModules(): Promise<PaginatedResponse<ModuleMarketplace>> {
    const modules = this.executeQuery<any>('SELECT * FROM module_marketplace ORDER BY downloads DESC');
    return {
      data: modules.map(m => ({
        ...m,
        screenshots: JSON.parse(m.screenshots || '[]')
      })),
      count: modules.length,
      page: 1,
      totalPages: 1
    };
  }

  async downloadModule(marketplaceId: string): Promise<ApiResponse<any>> {
    return {
      data: {
        config: { name: 'Downloaded Module', version: '1.0.0' },
        schema: { tables: [] },
        components: [],
        logic: {}
      }
    };
  }

  async exportModule(id: string): Promise<ApiResponse<Blob>> {
    const moduleResponse = await this.getModuleById(id);
    if (!moduleResponse.data) {
      return { data: null as any, error: 'Module not found' };
    }

    const exportData = {
      module: moduleResponse.data,
      exportedAt: new Date().toISOString(),
      version: '1.0.0'
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    return { data: blob };
  }

  async importModule(file: File): Promise<ApiResponse<Module>> {
    try {
      const text = await file.text();
      const importData = JSON.parse(text);
      
      if (!importData.module) {
        return { data: null as any, error: 'Invalid module file' };
      }

      return await this.installModule(importData.module);
    } catch (error) {
      return { data: null as any, error: 'Failed to parse module file' };
    }
  }

  // Custom Tables (TableBuilder) methods
  async getCustomTables(options?: QueryOptions): Promise<PaginatedResponse<any>> {
    try {
      const tables = this.executeQuery<any>(`
        SELECT * FROM custom_tables 
        ORDER BY created_at DESC
        LIMIT ${options?.limit || 50} OFFSET ${((options?.page || 1) - 1) * (options?.limit || 50)}
      `);
      
      const count = this.executeQuery<{count: number}>('SELECT COUNT(*) as count FROM custom_tables')[0]?.count || 0;
      
      return {
        data: tables.map(table => ({
          ...table,
          columns: JSON.parse(table.columns || '[]'),
          features: JSON.parse(table.features || '{}')
        })),
        count,
        page: options?.page || 1,
        totalPages: Math.ceil(count / (options?.limit || 50))
      };
    } catch (error) {
      console.error('Error getting custom tables:', error);
      return { data: [], count: 0, page: 1, totalPages: 0 };
    }
  }

  async createCustomTable(table: any): Promise<ApiResponse<any>> {
    try {
      const id = `table_${Date.now()}`;
      const now = new Date().toISOString();
      
      this.executeRun(`
        INSERT INTO custom_tables (id, name, description, columns, data_source, api_endpoint, features, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        table.name,
        table.description,
        JSON.stringify(table.columns),
        table.dataSource,
        table.apiEndpoint,
        JSON.stringify(table.features),
        'current_user',
        now,
        now
      ]);

      return { 
        data: { 
          id, 
          ...table, 
          created_at: now, 
          updated_at: now 
        } 
      };
    } catch (error) {
      return { data: null as any, error: 'Failed to create custom table' };
    }
  }

  async updateCustomTable(id: string, table: any): Promise<ApiResponse<any>> {
    try {
      const now = new Date().toISOString();
      
      this.executeRun(`
        UPDATE custom_tables 
        SET name = ?, description = ?, columns = ?, data_source = ?, api_endpoint = ?, features = ?, updated_at = ?
        WHERE id = ?
      `, [
        table.name,
        table.description,
        JSON.stringify(table.columns),
        table.dataSource,
        table.apiEndpoint,
        JSON.stringify(table.features),
        now,
        id
      ]);

      return { data: { id, ...table, updated_at: now } };
    } catch (error) {
      return { data: null as any, error: 'Failed to update custom table' };
    }
  }

  async deleteCustomTable(id: string): Promise<ApiResponse<boolean>> {
    try {
      this.executeRun('DELETE FROM custom_tables WHERE id = ?', [id]);
      return { data: true };
    } catch (error) {
      return { data: false, error: 'Failed to delete custom table' };
    }
  }

  // Phase 6: Advanced Data Features
  async getValidationRules(options?: QueryOptions): Promise<PaginatedResponse<ValidationRule>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getValidationRuleById(id: string): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async createValidationRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async updateValidationRule(id: string, rule: Partial<ValidationRule>): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async deleteValidationRule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented' };
  }

  async validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ApiResponse<ValidationResult[]>> {
    return { data: [] };
  }

  async getValidationResults(options?: QueryOptions): Promise<PaginatedResponse<ValidationResult>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getTestSchedules(options?: QueryOptions): Promise<PaginatedResponse<TestSchedule>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createTestSchedule(schedule: Omit<TestSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestSchedule>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async generateSchedulesFromTemplate(templateId: string, sampleIds: string[]): Promise<ApiResponse<TestSchedule[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getScheduleTemplates(): Promise<ApiResponse<ScheduleTemplate[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async createScheduleTemplate(template: Omit<ScheduleTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async updateScheduleTemplate(id: string, template: Partial<ScheduleTemplate>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async getTableRelationships(tableName?: string): Promise<ApiResponse<TableRelationship[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getRelatedRecords(tableName: string, recordId: string, relationship: string): Promise<ApiResponse<any[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getNavigationPath(tableName: string, recordId: string): Promise<ApiResponse<NavigationPath[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async getDataVersions(tableName: string, recordId: string): Promise<ApiResponse<DataVersion[]>> {
    return { data: [], error: 'Not implemented' };
  }

  async createDataVersion(version: Omit<DataVersion, 'id' | 'created_at'>): Promise<ApiResponse<DataVersion>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async compareVersions(versionId1: string, versionId2: string): Promise<ApiResponse<any>> {
    return { data: null, error: 'Not implemented' };
  }

  async rollbackToVersion(versionId: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented' };
  }

  async getChangeRequests(options?: QueryOptions): Promise<PaginatedResponse<ChangeRequest>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createChangeRequest(request: Omit<ChangeRequest, 'id' | 'requested_at'>): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async approveChangeRequest(requestId: string, comments?: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async rejectChangeRequest(requestId: string, comments: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async getApprovalWorkflows(): Promise<ApiResponse<ApprovalWorkflow[]>> {
    return { data: [], error: 'Not implemented' };
  }

  // Test Data Explorer methods
  async getTestDataEntries(options?: QueryOptions & { 
    moduleId?: string; 
    testType?: string; 
    productType?: string;
    site?: string;
    operator?: string;
    passFail?: string;
    source?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<PaginatedResponse<any>> {
    try {
      let query = 'SELECT * FROM test_data_entries WHERE 1=1';
      const params: any[] = [];

      if (options?.moduleId) {
        query += ' AND module_id = ?';
        params.push(options.moduleId);
      }

      if (options?.testType) {
        query += ' AND test_type = ?';
        params.push(options.testType);
      }

      if (options?.productType) {
        query += ' AND product_type = ?';
        params.push(options.productType);
      }

      if (options?.site) {
        query += ' AND site LIKE ?';
        params.push(`%${options.site}%`);
      }

      if (options?.operator) {
        query += ' AND operator LIKE ?';
        params.push(`%${options.operator}%`);
      }

      if (options?.passFail) {
        query += ' AND pass_fail_status = ?';
        params.push(options.passFail);
      }

      if (options?.source) {
        query += ' AND source = ?';
        params.push(options.source);
      }

      if (options?.startDate) {
        query += ' AND test_date >= ?';
        params.push(options.startDate);
      }

      if (options?.endDate) {
        query += ' AND test_date <= ?';
        params.push(options.endDate);
      }

      query += ' ORDER BY test_date DESC';

      const limit = options?.limit || 50;
      const offset = ((options?.page || 1) - 1) * limit;
      query += ` LIMIT ${limit} OFFSET ${offset}`;

      const entries = this.executeQuery<any>(query, params);
      
      // Get total count for pagination
      let countQuery = 'SELECT COUNT(*) as count FROM test_data_entries WHERE 1=1';
      if (options?.moduleId) countQuery += ' AND module_id = ?';
      if (options?.testType) countQuery += ' AND test_type = ?';
      if (options?.productType) countQuery += ' AND product_type = ?';
      if (options?.site) countQuery += ' AND site LIKE ?';
      if (options?.operator) countQuery += ' AND operator LIKE ?';
      if (options?.passFail) countQuery += ' AND pass_fail_status = ?';
      if (options?.source) countQuery += ' AND source = ?';
      if (options?.startDate) countQuery += ' AND test_date >= ?';
      if (options?.endDate) countQuery += ' AND test_date <= ?';

      const count = this.executeQuery<{count: number}>(countQuery, params)[0]?.count || 0;

      return {
        data: entries.map(entry => ({
          ...entry,
          test_results: entry.test_results ? JSON.parse(entry.test_results) : {},
          calculated_fields: entry.calculated_fields ? JSON.parse(entry.calculated_fields) : {},
          raw_data: entry.raw_data ? JSON.parse(entry.raw_data) : null
        })),
        count,
        page: options?.page || 1,
        totalPages: Math.ceil(count / limit)
      };
    } catch (error) {
      console.error('Error getting test data entries:', error);
      return { data: [], count: 0, page: 1, totalPages: 0 };
    }
  }

  async createTestDataEntry(entry: {
    moduleId: string;
    testType: string;
    batchId?: string;
    productType?: string;
    testDate?: string;
    site?: string;
    memoReference?: string;
    operator?: string;
    testResults: Record<string, any>;
    calculatedFields?: Record<string, any>;
    passFail?: string;
    source?: string;
    rawData?: any;
    notes?: string;
  }): Promise<ApiResponse<any>> {
    try {
      const id = `test_entry_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const now = new Date().toISOString();

      const newEntry = {
        id,
        module_id: entry.moduleId,
        test_type: entry.testType,
        batch_id: entry.batchId || null,
        product_type: entry.productType || null,
        test_date: entry.testDate || now,
        site: entry.site || null,
        memo_reference: entry.memoReference || null,
        operator: entry.operator || null,
        test_results: JSON.stringify(entry.testResults),
        calculated_fields: JSON.stringify(entry.calculatedFields || {}),
        pass_fail_status: entry.passFail || 'pending',
        source: entry.source || 'manual',
        raw_data: entry.rawData ? JSON.stringify(entry.rawData) : null,
        notes: entry.notes || null,
        created_at: now,
        updated_at: now,
        created_by: 'current_user'
      };

      this.executeInsert(`
        INSERT INTO test_data_entries (
          id, module_id, test_type, batch_id, product_type, test_date, site, memo_reference, 
          operator, test_results, calculated_fields, pass_fail_status, source, raw_data, 
          notes, created_at, updated_at, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, Object.values(newEntry));

      this.logAction('create', 'test_data_entry', id, null, newEntry);

      return { 
        data: {
          ...newEntry,
          test_results: entry.testResults,
          calculated_fields: entry.calculatedFields || {},
          raw_data: entry.rawData || null
        }
      };
    } catch (error) {
      console.error('Error creating test data entry:', error);
      return { data: null as any, error: 'Failed to create test data entry' };
    }
  }

  async updateTestDataEntry(id: string, entry: Partial<any>): Promise<ApiResponse<any>> {
    try {
      const updates: any = { ...entry };
      if (entry.testResults) {
        updates.test_results = JSON.stringify(entry.testResults);
        delete updates.testResults;
      }
      if (entry.calculatedFields) {
        updates.calculated_fields = JSON.stringify(entry.calculatedFields);
        delete updates.calculatedFields;
      }
      if (entry.rawData) {
        updates.raw_data = JSON.stringify(entry.rawData);
        delete updates.rawData;
      }
      updates.updated_at = new Date().toISOString();

      const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = [...Object.values(updates), id];

      this.executeRun(`UPDATE test_data_entries SET ${setClause} WHERE id = ?`, values);
      this.logAction('update', 'test_data_entry', id, null, updates);

      const updated = this.executeQuery<any>('SELECT * FROM test_data_entries WHERE id = ?', [id])[0];
      return {
        data: {
          ...updated,
          test_results: updated.test_results ? JSON.parse(updated.test_results) : {},
          calculated_fields: updated.calculated_fields ? JSON.parse(updated.calculated_fields) : {},
          raw_data: updated.raw_data ? JSON.parse(updated.raw_data) : null
        }
      };
    } catch (error) {
      console.error('Error updating test data entry:', error);
      return { data: null as any, error: 'Failed to update test data entry' };
    }
  }

  async deleteTestDataEntry(id: string): Promise<ApiResponse<boolean>> {
    try {
      this.executeRun('DELETE FROM test_data_entries WHERE id = ?', [id]);
      this.logAction('delete', 'test_data_entry', id, null, null);
      return { data: true };
    } catch (error) {
      console.error('Error deleting test data entry:', error);
      return { data: false, error: 'Failed to delete test data entry' };
    }
  }

  async getTestThresholds(moduleId?: string): Promise<ApiResponse<any[]>> {
    try {
      const query = moduleId ? 'SELECT * FROM test_thresholds WHERE module_id = ?' : 'SELECT * FROM test_thresholds';
      const params = moduleId ? [moduleId] : [];
      const thresholds = this.executeQuery<any>(query, params);
      return { data: thresholds };
    } catch (error) {
      console.error('Error getting test thresholds:', error);
      return { data: [], error: 'Failed to get test thresholds' };
    }
  }

  async createTestThreshold(threshold: {
    moduleId: string;
    testType: string;
    parameterName: string;
    minValue?: number;
    maxValue?: number;
    unit?: string;
  }): Promise<ApiResponse<any>> {
    try {
      const id = `threshold_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const now = new Date().toISOString();

      const newThreshold = {
        id,
        module_id: threshold.moduleId,
        test_type: threshold.testType,
        parameter_name: threshold.parameterName,
        min_value: threshold.minValue || null,
        max_value: threshold.maxValue || null,
        unit: threshold.unit || null,
        created_at: now,
        updated_at: now
      };

      this.executeInsert(`
        INSERT INTO test_thresholds (id, module_id, test_type, parameter_name, min_value, max_value, unit, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, Object.values(newThreshold));

      return { data: newThreshold };
    } catch (error) {
      console.error('Error creating test threshold:', error);
      return { data: null as any, error: 'Failed to create test threshold' };
    }
  }

  async getTestDataTemplates(moduleId?: string): Promise<ApiResponse<any[]>> {
    try {
      const query = moduleId ? 'SELECT * FROM test_data_templates WHERE module_id = ?' : 'SELECT * FROM test_data_templates';
      const params = moduleId ? [moduleId] : [];
      const templates = this.executeQuery<any>(query, params);
      
      return {
        data: templates.map(t => ({
          ...t,
          column_mapping: t.column_mapping ? JSON.parse(t.column_mapping) : {},
          validation_rules: t.validation_rules ? JSON.parse(t.validation_rules) : {}
        }))
      };
    } catch (error) {
      console.error('Error getting test data templates:', error);
      return { data: [], error: 'Failed to get test data templates' };
    }
  }

  async createTestDataTemplate(template: {
    name: string;
    moduleId: string;
    columnMapping: Record<string, string>;
    validationRules?: Record<string, any>;
  }): Promise<ApiResponse<any>> {
    try {
      const id = `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const now = new Date().toISOString();

      const newTemplate = {
        id,
        name: template.name,
        module_id: template.moduleId,
        column_mapping: JSON.stringify(template.columnMapping),
        validation_rules: JSON.stringify(template.validationRules || {}),
        created_at: now,
        updated_at: now,
        created_by: 'current_user'
      };

      this.executeInsert(`
        INSERT INTO test_data_templates (id, name, module_id, column_mapping, validation_rules, created_at, updated_at, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, Object.values(newTemplate));

      return {
        data: {
          ...newTemplate,
          column_mapping: template.columnMapping,
          validation_rules: template.validationRules || {}
        }
      };
    } catch (error) {
      console.error('Error creating test data template:', error);
      return { data: null as any, error: 'Failed to create test data template' };
    }
  }

  async importTestDataFromExcel(templateId: string, data: any[]): Promise<ApiResponse<{ success: number; failed: number; errors: string[] }>> {
    try {
      const templateResponse = await this.getTestDataTemplates();
      const template = templateResponse.data?.find(t => t.id === templateId);
      
      if (!template) {
        return { data: null as any, error: 'Template not found' };
      }

      let success = 0;
      let failed = 0;
      const errors: string[] = [];

      for (const row of data) {
        try {
          // Map Excel columns to database fields using template
          const mappedData: any = {};
          for (const [dbField, excelColumn] of Object.entries(template.column_mapping as Record<string, string>)) {
            if (row[excelColumn as string] !== undefined) {
              mappedData[dbField] = row[excelColumn as string];
            }
          }

          // Create test data entry
          await this.createTestDataEntry({
            moduleId: template.module_id,
            testType: mappedData.test_type || 'imported',
            batchId: mappedData.batch_id,
            productType: mappedData.product_type,
            testDate: mappedData.test_date,
            site: mappedData.site,
            memoReference: mappedData.memo_reference,
            operator: mappedData.operator,
            testResults: mappedData.test_results || {},
            source: 'imported',
            rawData: row,
            notes: mappedData.notes
          });

          success++;
        } catch (error) {
          failed++;
          errors.push(`Row ${data.indexOf(row) + 1}: ${error}`);
        }
      }

      return { data: { success, failed, errors } };
    } catch (error) {
      console.error('Error importing test data:', error);
      return { data: null as any, error: 'Failed to import test data' };
    }
  }

  async exportTestData(filters?: any, format: 'csv' | 'excel' | 'pdf' = 'csv'): Promise<ApiResponse<Blob>> {
    try {
      const response = await this.getTestDataEntries(filters);
      const data = response.data;

      if (format === 'csv') {
        const headers = ['ID', 'Module', 'Test Type', 'Batch ID', 'Product Type', 'Test Date', 'Site', 'Operator', 'Pass/Fail', 'Source', 'Test Results'];
        const csvContent = [
          headers.join(','),
          ...data.map(entry => [
            entry.id,
            entry.module_id,
            entry.test_type,
            entry.batch_id || '',
            entry.product_type || '',
            entry.test_date,
            entry.site || '',
            entry.operator || '',
            entry.pass_fail_status,
            entry.source,
            JSON.stringify(entry.test_results || {}).replace(/,/g, ';')
          ].map(field => `"${field}"`).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        return { data: blob };
      }

      if (format === 'excel') {
        // Create Excel-like CSV with enhanced formatting
        const headers = ['ID', 'Module', 'Test Type', 'Batch ID', 'Product Type', 'Test Date', 'Site', 'Operator', 'Pass/Fail', 'Source', 'Test Results', 'W/C Ratio', 'Mean Strength', 'Notes'];
        const csvContent = [
          headers.join(','),
          ...data.map(entry => {
            const results = entry.test_results || {};
            const wcRatio = (results.water && results.cement) ? (results.water / results.cement).toFixed(2) : '';
            const meanStrength = results.specimens?.length ? 
              (results.specimens.reduce((sum: number, spec: any) => sum + (spec.strength || 0), 0) / results.specimens.length).toFixed(2) : '';
            
            return [
              entry.id,
              entry.module_id,
              entry.test_type,
              entry.batch_id || '',
              entry.product_type || '',
              entry.test_date,
              entry.site || '',
              entry.operator || '',
              entry.pass_fail_status,
              entry.source,
              JSON.stringify(entry.test_results || {}).replace(/,/g, ';'),
              wcRatio,
              meanStrength,
              entry.notes || ''
            ].map(field => `"${field}"`).join(',');
          })
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'application/vnd.ms-excel' });
        return { data: blob };
      }

      if (format === 'pdf') {
        // Create a simple PDF-like text format
        const pdfContent = [
          'TEST DATA EXPORT REPORT',
          '========================',
          `Generated: ${new Date().toLocaleString()}`,
          `Total Records: ${data.length}`,
          '',
          ...data.map((entry, index) => [
            `Record ${index + 1}:`,
            `  ID: ${entry.id}`,
            `  Module: ${entry.module_id}`,
            `  Test Type: ${entry.test_type}`,
            `  Date: ${entry.test_date}`,
            `  Operator: ${entry.operator || 'N/A'}`,
            `  Site: ${entry.site || 'N/A'}`,
            `  Status: ${entry.pass_fail_status}`,
            `  Results: ${JSON.stringify(entry.test_results || {})}`,
            ''
          ]).flat()
        ].join('\n');

        const blob = new Blob([pdfContent], { type: 'application/pdf' });
        return { data: blob };
      }

      // Fallback
      const csvContent = 'Export format not implemented yet';
      const blob = new Blob([csvContent], { type: 'text/plain' });
      return { data: blob };
    } catch (error) {
      console.error('Error exporting test data:', error);
      return { data: null as any, error: 'Failed to export test data' };
    }
  }

  // Enhanced calculation engine
  async calculateDerivedFields(entryId: string): Promise<ApiResponse<any>> {
    try {
      const entryResponse = await this.getTestDataEntries({ moduleId: entryId } as any);
      if (!entryResponse.data || entryResponse.data.length === 0) {
        return { data: null, error: 'Entry not found' };
      }

      const entry = entryResponse.data[0];
      const results = entry.test_results || {};
      const calculated: Record<string, any> = {};

      // W/C Ratio calculation
      if (results.water && results.cement) {
        calculated.wcRatio = (results.water / results.cement).toFixed(2);
        calculated.wcRatioDescription = 'Water to Cement ratio';
      }

      // Strength efficiency
      if (results.compressive_strength && results.cement_content) {
        calculated.strengthEfficiency = (results.compressive_strength / results.cement_content).toFixed(2);
        calculated.strengthEfficiencyDescription = 'Strength per unit cement';
      }

      // Aggregate ratio
      if (results.fine_aggregate && results.coarse_aggregate) {
        calculated.aggregateRatio = (results.fine_aggregate / results.coarse_aggregate).toFixed(2);
        calculated.aggregateRatioDescription = 'Fine to coarse aggregate ratio';
      }

      // Mean strength for multiple specimens
      if (results.specimens && Array.isArray(results.specimens)) {
        const strengths = results.specimens.map((spec: any) => spec.strength || 0);
        const mean = strengths.reduce((sum: number, val: number) => sum + val, 0) / strengths.length;
        const stdDev = Math.sqrt(strengths.reduce((sum: number, val: number) => sum + Math.pow(val - mean, 2), 0) / strengths.length);
        
        calculated.meanStrength = mean.toFixed(2);
        calculated.standardDeviation = stdDev.toFixed(2);
        calculated.coefficientOfVariation = ((stdDev / mean) * 100).toFixed(2);
        calculated.statisticsDescription = 'Statistical analysis of test specimens';
      }

      // Slump vs Strength correlation
      if (results.slump && results.compressive_strength) {
        calculated.slumpStrengthRatio = (results.compressive_strength / results.slump).toFixed(2);
        calculated.slumpStrengthDescription = 'Strength to slump correlation';
      }

      // Update the entry with calculated fields
      const updateSql = 'UPDATE test_data_entries SET calculated_fields = ? WHERE id = ?';
      await this.executeRun(updateSql, [JSON.stringify(calculated), entryId]);

      return { data: calculated };
    } catch (error) {
      console.error('Error calculating derived fields:', error);
      return { data: null, error: 'Failed to calculate derived fields' };
    }
  }

  // Batch processing for performance optimization
  async batchUpdateTestData(updates: Array<{id: string, data: Partial<any>}>): Promise<ApiResponse<any>> {
    try {
      const results = [];
      
      // Process in batches of 50 for better performance
      for (let i = 0; i < updates.length; i += 50) {
        const batch = updates.slice(i, i + 50);
        
        for (const update of batch) {
          const fields = Object.keys(update.data);
          const values = Object.values(update.data);
          const setClause = fields.map(field => `${field} = ?`).join(', ');
          
          const sql = `UPDATE test_data_entries SET ${setClause} WHERE id = ?`;
          await this.executeRun(sql, [...values, update.id]);
          results.push({ id: update.id, status: 'updated' });
        }
      }

      return { data: { updated: results.length, results } };
    } catch (error) {
      console.error('Error in batch update:', error);
      return { data: null, error: 'Batch update failed' };
    }
  }

  // Advanced search functionality
  async searchTestData(query: string, options: any = {}): Promise<ApiResponse<any[]>> {
    try {
      const searchFields = ['test_type', 'batch_id', 'operator', 'site', 'notes'];
      const conditions = searchFields.map(field => `${field} LIKE ?`).join(' OR ');
      const searchPattern = `%${query}%`;
      const params = new Array(searchFields.length).fill(searchPattern);

      let sql = `
        SELECT * FROM test_data_entries 
        WHERE ${conditions}
      `;

      // Add filters
      if (options.moduleId) {
        sql += ' AND module_id = ?';
        params.push(options.moduleId);
      }

      if (options.startDate && options.endDate) {
        sql += ' AND test_date BETWEEN ? AND ?';
        params.push(options.startDate, options.endDate);
      }

      sql += ' ORDER BY test_date DESC LIMIT 100';

      const result = await this.executeQuery(sql, params);
      return { data: result };
    } catch (error) {
      console.error('Error searching test data:', error);
      return { data: [], error: 'Search failed' };
    }
  }

  // Get threshold-based pass/fail analysis
  async analyzePassFailThresholds(moduleId: string): Promise<ApiResponse<any>> {
    try {
      const thresholdsSql = 'SELECT * FROM test_thresholds WHERE module_id = ?';
      const thresholds = await this.executeQuery(thresholdsSql, [moduleId]);

      const entriesSql = 'SELECT * FROM test_data_entries WHERE module_id = ?';
      const entries = await this.executeQuery(entriesSql, [moduleId]);

      const analysis = entries.map((entry: any) => {
        const results = typeof entry.test_results === 'string' 
          ? JSON.parse(entry.test_results) 
          : entry.test_results || {};
        
        const applicableThresholds = thresholds.filter((t: any) => t.test_type === entry.test_type);
        let computedStatus = 'pass';
        const failureReasons = [];

        for (const threshold of applicableThresholds) {
          const thresholdData = threshold as any;
          const value = results[thresholdData.parameter_name];
          if (value !== undefined) {
            if (thresholdData.min_value && value < thresholdData.min_value) {
              computedStatus = 'fail';
              failureReasons.push(`${thresholdData.parameter_name} below minimum (${value} < ${thresholdData.min_value})`);
            }
            if (thresholdData.max_value && value > thresholdData.max_value) {
              computedStatus = 'fail';
              failureReasons.push(`${thresholdData.parameter_name} above maximum (${value} > ${thresholdData.max_value})`);
            }
          }
        }

        return {
          ...entry,
          computedPassFail: computedStatus,
          failureReasons,
          thresholdsApplied: applicableThresholds.length
        };
      });

      const summary = {
        total: entries.length,
        passed: analysis.filter(a => a.computedPassFail === 'pass').length,
        failed: analysis.filter(a => a.computedPassFail === 'fail').length,
        passRate: entries.length > 0 ? ((analysis.filter(a => a.computedPassFail === 'pass').length / entries.length) * 100).toFixed(2) : 0
      };

      return { data: { analysis, summary } };
    } catch (error) {
      console.error('Error analyzing thresholds:', error);
      return { data: null, error: 'Threshold analysis failed' };
    }
  }

  // Add sample test data for demonstration
  private async addSampleTestData(): Promise<void> {
    try {
      // Check if data already exists
      const existingData = await this.executeQuery('SELECT COUNT(*) as count FROM test_data_entries');
      if ((existingData[0] as any)?.count > 0) {
        return; // Data already exists
      }

      const sampleData = [
        {
          id: 'test_001',
          module_id: 'aggregates-silt-clay-content-%-by-mass-passing-75μm-sieve',
          test_type: 'Silt & Clay content - % by mass passing 75μm sieve',
          batch_id: 'BATCH_001',
          product_type: 'Aggregates',
          test_date: '2024-01-15',
          site: 'Main Laboratory',
          operator: 'John Smith',
          test_results: JSON.stringify({
            silt_clay_percentage: 8.5,
            passing_75micron: 12.3,
            sample_weight: 500,
            wash_weight: 456.2
          }),
          calculated_fields: JSON.stringify({
            efficiency: 92.4,
            variance: 1.2
          }),
          pass_fail_status: 'pass',
          source: 'manual',
          notes: 'Standard test procedure followed',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 'test_002',
          module_id: 'aggregates-silt-clay-content-%-by-mass-passing-75μm-sieve',
          test_type: 'Silt & Clay content - % by mass passing 75μm sieve',
          batch_id: 'BATCH_002',
          product_type: 'Aggregates',
          test_date: '2024-01-16',
          site: 'Main Laboratory',
          operator: 'Jane Doe',
          test_results: JSON.stringify({
            silt_clay_percentage: 15.2,
            passing_75micron: 18.7,
            sample_weight: 500,
            wash_weight: 407.3
          }),
          calculated_fields: JSON.stringify({
            efficiency: 81.5,
            variance: 2.8
          }),
          pass_fail_status: 'fail',
          source: 'imported',
          notes: 'Exceeds allowable limits',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 'test_003',
          module_id: 'aggregates-moisture-content',
          test_type: 'Moisture Content',
          batch_id: 'BATCH_003',
          product_type: 'Aggregates',
          test_date: '2024-01-17',
          site: 'Field Laboratory',
          operator: 'Mike Johnson',
          test_results: JSON.stringify({
            moisture_percentage: 3.2,
            wet_weight: 1000,
            dry_weight: 968,
            container_weight: 45
          }),
          calculated_fields: JSON.stringify({
            moisture_ratio: 0.032,
            efficiency: 96.8
          }),
          pass_fail_status: 'pass',
          source: 'manual',
          notes: 'Within acceptable range',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 'test_004',
          module_id: 'blocks-compressive-strength',
          test_type: 'Compressive Strength',
          batch_id: 'BATCH_004',
          product_type: 'Blocks',
          test_date: '2024-01-18',
          site: 'Main Laboratory',
          operator: 'Sarah Wilson',
          test_results: JSON.stringify({
            compressive_strength: 25.6,
            specimens: [
              { strength: 25.2 },
              { strength: 25.8 },
              { strength: 25.9 }
            ],
            test_area: 140
          }),
          calculated_fields: JSON.stringify({
            meanStrength: '25.63',
            standardDeviation: '0.38',
            coefficientOfVariation: '1.48'
          }),
          pass_fail_status: 'pass',
          source: 'manual',
          notes: 'Good quality blocks',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 'test_005',
          module_id: 'aggregates-silt-clay-content-%-by-mass-passing-75μm-sieve',
          test_type: 'Silt & Clay content - % by mass passing 75μm sieve',
          batch_id: 'BATCH_005',
          product_type: 'Aggregates',
          test_date: '2024-01-19',
          site: 'Quality Control Lab',
          operator: 'David Brown',
          test_results: JSON.stringify({
            silt_clay_percentage: 6.8,
            passing_75micron: 9.2,
            sample_weight: 500,
            wash_weight: 477.4
          }),
          calculated_fields: JSON.stringify({
            efficiency: 95.5,
            variance: 0.8
          }),
          pass_fail_status: 'pass',
          source: 'liveshare',
          notes: 'Excellent quality aggregate',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ];

      for (const entry of sampleData) {
        const sql = `
          INSERT INTO test_data_entries (
            id, module_id, test_type, batch_id, product_type, test_date,
            site, operator, test_results, calculated_fields, pass_fail_status,
            source, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        await this.executeRun(sql, [
          entry.id, entry.module_id, entry.test_type, entry.batch_id, 
          entry.product_type, entry.test_date, entry.site, entry.operator,
          entry.test_results, entry.calculated_fields, entry.pass_fail_status,
          entry.source, entry.notes, entry.created_at, entry.updated_at
        ]);
      }

      console.log('Sample test data added successfully');
    } catch (error) {
      console.error('Error adding sample test data:', error);
    }
  }

  // ===== CUSTOM COMPONENTS METHODS =====
  async getCustomComponents(): Promise<any[]> {
    return this.executeQuery('SELECT * FROM custom_components ORDER BY created_at DESC');
  }

  async createCustomComponent(component: any): Promise<any> {
    const newComponent = {
      id: `comp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...component,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO custom_components (id, name, description, component_type, template_code, props_schema, style_config, dependencies, category, is_reusable, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newComponent.id, newComponent.name, newComponent.description, newComponent.component_type,
        newComponent.template_code, JSON.stringify(newComponent.props_schema || {}),
        JSON.stringify(newComponent.style_config || {}), JSON.stringify(newComponent.dependencies || []),
        newComponent.category, newComponent.is_reusable, newComponent.created_by,
        newComponent.created_at, newComponent.updated_at
      ]
    );

    this.logAction('create', 'custom_component', newComponent.id, null, newComponent);
    return newComponent;
  }

  async updateCustomComponent(id: string, updates: any): Promise<any> {
    const updateData = {
      ...updates,
      updated_at: new Date().toISOString(),
      props_schema: updates.props_schema ? JSON.stringify(updates.props_schema) : undefined,
      style_config: updates.style_config ? JSON.stringify(updates.style_config) : undefined,
      dependencies: updates.dependencies ? JSON.stringify(updates.dependencies) : undefined
    };

    const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
    const updateValues = updateFields.map(key => updateData[key]);
    
    if (updateFields.length > 0) {
      const sql = `UPDATE custom_components SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
      this.executeInsert(sql, [...updateValues, id]);
      this.logAction('update', 'custom_component', id, null, updateData);
    }

    return this.executeQuery('SELECT * FROM custom_components WHERE id = ?', [id])[0];
  }

  async deleteCustomComponent(id: string): Promise<boolean> {
    const existing = this.executeQuery('SELECT * FROM custom_components WHERE id = ?', [id])[0];
    if (!existing) return false;

    this.executeInsert('DELETE FROM custom_components WHERE id = ?', [id]);
    this.logAction('delete', 'custom_component', id, existing, null);
    return true;
  }

  // ===== WORKFLOWS METHODS =====
  async getWorkflows(): Promise<any[]> {
    const workflows = this.executeQuery<any>('SELECT * FROM workflows ORDER BY created_at DESC');
    return workflows.map((w: any) => ({
      ...w,
      trigger_config: JSON.parse(w.trigger_config || '{}'),
      steps: JSON.parse(w.steps || '[]')
    }));
  }

  async createWorkflow(workflow: any): Promise<any> {
    const newWorkflow = {
      id: `workflow_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...workflow,
      trigger_config: JSON.stringify(workflow.trigger_config || {}),
      steps: JSON.stringify(workflow.steps || []),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO workflows (id, name, description, trigger_config, steps, status, execution_count, last_execution, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newWorkflow.id, newWorkflow.name, newWorkflow.description, newWorkflow.trigger_config,
        newWorkflow.steps, newWorkflow.status || 'draft', 0, null, newWorkflow.created_by,
        newWorkflow.created_at, newWorkflow.updated_at
      ]
    );

    this.logAction('create', 'workflow', newWorkflow.id, null, newWorkflow);
    return {
      ...newWorkflow,
      trigger_config: JSON.parse(newWorkflow.trigger_config),
      steps: JSON.parse(newWorkflow.steps)
    };
  }

  async updateWorkflow(id: string, updates: any): Promise<any> {
    const updateData = {
      ...updates,
      updated_at: new Date().toISOString(),
      trigger_config: updates.trigger_config ? JSON.stringify(updates.trigger_config) : undefined,
      steps: updates.steps ? JSON.stringify(updates.steps) : undefined
    };

    const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
    const updateValues = updateFields.map(key => updateData[key]);
    
    if (updateFields.length > 0) {
      const sql = `UPDATE workflows SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
      this.executeInsert(sql, [...updateValues, id]);
      this.logAction('update', 'workflow', id, null, updateData);
    }

    const result = this.executeQuery<any>('SELECT * FROM workflows WHERE id = ?', [id])[0];
    return {
      ...result,
      trigger_config: JSON.parse(result.trigger_config || '{}'),
      steps: JSON.parse(result.steps || '[]')
    };
  }

  async deleteWorkflow(id: string): Promise<boolean> {
    const existing = this.executeQuery('SELECT * FROM workflows WHERE id = ?', [id])[0];
    if (!existing) return false;

    this.executeInsert('DELETE FROM workflows WHERE id = ?', [id]);
    this.logAction('delete', 'workflow', id, existing, null);
    return true;
  }

  async executeWorkflow(workflowId: string, inputData: any = {}): Promise<any> {
    const workflow = this.executeQuery('SELECT * FROM workflows WHERE id = ?', [workflowId])[0];
    if (!workflow) throw new Error('Workflow not found');

    const executionId = `exec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const execution = {
      id: executionId,
      workflow_id: workflowId,
      status: 'running',
      start_time: new Date().toISOString(),
      input_data: JSON.stringify(inputData),
      execution_logs: JSON.stringify([])
    };

    this.executeInsert(
      `INSERT INTO workflow_executions (id, workflow_id, status, start_time, input_data, execution_logs)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [execution.id, execution.workflow_id, execution.status, execution.start_time, execution.input_data, execution.execution_logs]
    );

    // Update execution count
    this.executeInsert(
      'UPDATE workflows SET execution_count = execution_count + 1, last_execution = ? WHERE id = ?',
      [execution.start_time, workflowId]
    );

    this.logAction('execute', 'workflow', workflowId, null, { execution_id: executionId, inputData });
    return execution;
  }

  async getWorkflowExecutions(workflowId?: string): Promise<any[]> {
    const sql = workflowId 
      ? 'SELECT * FROM workflow_executions WHERE workflow_id = ? ORDER BY start_time DESC'
      : 'SELECT * FROM workflow_executions ORDER BY start_time DESC';
    const params = workflowId ? [workflowId] : [];
    
    const executions = this.executeQuery<any>(sql, params);
    return executions.map((e: any) => ({
      ...e,
      execution_logs: JSON.parse(e.execution_logs || '[]'),
      input_data: JSON.parse(e.input_data || '{}'),
      output_data: e.output_data ? JSON.parse(e.output_data) : null
    }));
  }

  // ===== API ENDPOINTS METHODS =====
  async getApiEndpoints(): Promise<any[]> {
    const endpoints = this.executeQuery<any>('SELECT * FROM api_endpoints ORDER BY created_at DESC');
    return endpoints.map((e: any) => ({
      ...e,
      headers: JSON.parse(e.headers || '{}'),
      query_params: JSON.parse(e.query_params || '{}'),
      request_body_schema: e.request_body_schema ? JSON.parse(e.request_body_schema) : null,
      response_schema: e.response_schema ? JSON.parse(e.response_schema) : null
    }));
  }

  async createApiEndpoint(endpoint: any): Promise<any> {
    const newEndpoint = {
      id: `api_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...endpoint,
      headers: JSON.stringify(endpoint.headers || {}),
      query_params: JSON.stringify(endpoint.query_params || {}),
      request_body_schema: endpoint.request_body_schema ? JSON.stringify(endpoint.request_body_schema) : null,
      response_schema: endpoint.response_schema ? JSON.stringify(endpoint.response_schema) : null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO api_endpoints (id, name, description, method, path, headers, query_params, request_body_schema, response_schema, auth_required, rate_limit, is_active, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newEndpoint.id, newEndpoint.name, newEndpoint.description, newEndpoint.method, newEndpoint.path,
        newEndpoint.headers, newEndpoint.query_params, newEndpoint.request_body_schema, newEndpoint.response_schema,
        newEndpoint.auth_required || false, newEndpoint.rate_limit, newEndpoint.is_active !== false,
        newEndpoint.created_by, newEndpoint.created_at, newEndpoint.updated_at
      ]
    );

    this.logAction('create', 'api_endpoint', newEndpoint.id, null, newEndpoint);
    return {
      ...newEndpoint,
      headers: JSON.parse(newEndpoint.headers),
      query_params: JSON.parse(newEndpoint.query_params),
      request_body_schema: newEndpoint.request_body_schema ? JSON.parse(newEndpoint.request_body_schema) : null,
      response_schema: newEndpoint.response_schema ? JSON.parse(newEndpoint.response_schema) : null
    };
  }

  async updateApiEndpoint(id: string, updates: any): Promise<any> {
    const updateData = {
      ...updates,
      updated_at: new Date().toISOString(),
      headers: updates.headers ? JSON.stringify(updates.headers) : undefined,
      query_params: updates.query_params ? JSON.stringify(updates.query_params) : undefined,
      request_body_schema: updates.request_body_schema ? JSON.stringify(updates.request_body_schema) : undefined,
      response_schema: updates.response_schema ? JSON.stringify(updates.response_schema) : undefined
    };

    const updateFields = Object.keys(updateData).filter(key => updateData[key] !== undefined);
    const updateValues = updateFields.map(key => updateData[key]);
    
    if (updateFields.length > 0) {
      const sql = `UPDATE api_endpoints SET ${updateFields.map(field => `${field} = ?`).join(', ')} WHERE id = ?`;
      this.executeInsert(sql, [...updateValues, id]);
      this.logAction('update', 'api_endpoint', id, null, updateData);
    }

    const result = this.executeQuery<any>('SELECT * FROM api_endpoints WHERE id = ?', [id])[0];
    return {
      ...result,
      headers: JSON.parse(result.headers || '{}'),
      query_params: JSON.parse(result.query_params || '{}'),
      request_body_schema: result.request_body_schema ? JSON.parse(result.request_body_schema) : null,
      response_schema: result.response_schema ? JSON.parse(result.response_schema) : null
    };
  }

  async deleteApiEndpoint(id: string): Promise<boolean> {
    const existing = this.executeQuery('SELECT * FROM api_endpoints WHERE id = ?', [id])[0];
    if (!existing) return false;

    this.executeInsert('DELETE FROM api_endpoints WHERE id = ?', [id]);
    this.logAction('delete', 'api_endpoint', id, existing, null);
    return true;
  }

  async logApiRequest(endpointId: string, requestData: any): Promise<void> {
    const logEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      endpoint_id: endpointId,
      request_method: requestData.method,
      request_path: requestData.path,
      request_headers: JSON.stringify(requestData.headers || {}),
      request_body: requestData.body ? JSON.stringify(requestData.body) : null,
      response_status: requestData.response_status,
      response_body: requestData.response_body ? JSON.stringify(requestData.response_body) : null,
      response_time_ms: requestData.response_time_ms,
      user_id: requestData.user_id,
      ip_address: requestData.ip_address || '127.0.0.1',
      timestamp: new Date().toISOString()
    };

    this.executeInsert(
      `INSERT INTO api_endpoint_logs (id, endpoint_id, request_method, request_path, request_headers, request_body, response_status, response_body, response_time_ms, user_id, ip_address, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      Object.values(logEntry)
    );
  }

  async getApiLogs(endpointId?: string): Promise<any[]> {
    const sql = endpointId 
      ? 'SELECT * FROM api_endpoint_logs WHERE endpoint_id = ? ORDER BY timestamp DESC'
      : 'SELECT * FROM api_endpoint_logs ORDER BY timestamp DESC';
    const params = endpointId ? [endpointId] : [];
    
    const logs = this.executeQuery<any>(sql, params);
    return logs.map((log: any) => ({
      ...log,
      request_headers: JSON.parse(log.request_headers || '{}'),
      request_body: log.request_body ? JSON.parse(log.request_body) : null,
      response_body: log.response_body ? JSON.parse(log.response_body) : null
    }));
  }

  // Reference Dataset Management
  async uploadReferenceDataset(tableName: string, csvData: any[]): Promise<{ success: boolean; rowsInserted: number; error?: string }> {
    try {
      // Validate table name
      const validTables = ['lab_tests', 'lab_group_code', 'lab_mould', 'sampling_places', 'climatic_conditions', 'colour'];
      if (!validTables.includes(tableName)) {
        return { success: false, rowsInserted: 0, error: `Unsupported table: ${tableName}` };
      }

      // Clear existing data
      this.executeInsert(`DELETE FROM ${tableName}`, []);

      // Insert new data
      let rowsInserted = 0;
      for (const row of csvData) {
        try {
          switch (tableName) {
            case 'lab_tests':
              this.executeInsert(
                'INSERT INTO lab_tests (product_type, code, description, sort_order, active) VALUES (?, ?, ?, ?, ?)',
                [row.product_type || '', row.code, row.description || '', parseInt(row.sort_order) || 0, row.active || 'Yes']
              );
              break;
            case 'lab_group_code':
              this.executeInsert(
                'INSERT INTO lab_group_code (lab_site, lab_product, lab_machine, code, active) VALUES (?, ?, ?, ?, ?)',
                [row.lab_site || '', row.lab_product || '', row.lab_machine || '', row.code, row.active || 'Yes']
              );
              break;
            case 'lab_mould':
              this.executeInsert(
                'INSERT INTO lab_mould (lab_site, code, description, position, active) VALUES (?, ?, ?, ?, ?)',
                [row.lab_site || '', row.code, row.description || '', row.position || '', row.active || 'Yes']
              );
              break;
            case 'sampling_places':
              this.executeInsert(
                'INSERT INTO sampling_places (code, description, product_type) VALUES (?, ?, ?)',
                [row.code, row.description || '', row.product_type || '']
              );
              break;
            case 'climatic_conditions':
              this.executeInsert(
                'INSERT INTO climatic_conditions (code, description, active) VALUES (?, ?, ?)',
                [row.code, row.description || '', row.active || 'Yes']
              );
              break;
            case 'colour':
              this.executeInsert(
                'INSERT INTO colour (code, description, active) VALUES (?, ?, ?)',
                [row.code, row.description || '', row.active || 'Yes']
              );
              break;
          }
          rowsInserted++;
        } catch (error) {
          console.warn(`Failed to insert row in ${tableName}:`, row, error);
        }
      }

      this.logAction('upload', 'reference_dataset', tableName, null, { rowsInserted });
      return { success: true, rowsInserted };
    } catch (error) {
      console.error('Failed to upload reference dataset:', error);
      return { success: false, rowsInserted: 0, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getReferenceData(tableName: string, activeOnly: boolean = true): Promise<any[]> {
    try {
      const validTables = ['lab_tests', 'lab_group_code', 'lab_mould', 'sampling_places', 'climatic_conditions', 'colour'];
      if (!validTables.includes(tableName)) {
        return [];
      }

      let sql = `SELECT * FROM ${tableName}`;
      if (activeOnly && ['lab_tests', 'lab_group_code', 'lab_mould', 'climatic_conditions', 'colour'].includes(tableName)) {
        sql += ` WHERE active = 'Yes'`;
      }
      sql += ' ORDER BY ';
      
      // Add appropriate sorting
      switch (tableName) {
        case 'lab_tests':
          sql += 'sort_order ASC, description ASC';
          break;
        default:
          sql += 'description ASC';
      }

      return this.executeQuery(sql, []);
    } catch (error) {
      console.error(`Failed to get reference data for ${tableName}:`, error);
      return [];
    }
  }

  async getFilteredSamplingPlaces(productType: string): Promise<any[]> {
    try {
      const sql = `SELECT * FROM sampling_places WHERE product_type = ? OR product_type = '' ORDER BY description ASC`;
      return this.executeQuery(sql, [productType]);
    } catch (error) {
      console.error('Failed to get filtered sampling places:', error);
      return [];
    }
  }

  // Audit Trail operations
  async createAuditLog(entry: any): Promise<ApiResponse<any>> {
    try {
      this.logAction(entry.action, entry.resource_type, entry.resource_id, entry.old_data, entry.new_data);
      return { data: entry };
    } catch (error) {
      return { data: null as any, error: 'Failed to create audit log' };
    }
  }

  async getAuditLogs(filters?: any): Promise<any[]> {
    try {
      let sql = 'SELECT * FROM audit_logs ORDER BY created_at DESC';
      const params: any[] = [];
      
      if (filters?.search) {
        sql += ' WHERE action LIKE ? OR resource_type LIKE ?';
        params.push(`%${filters.search}%`, `%${filters.search}%`);
      }
      
      return this.executeQuery(sql, params);
    } catch (error) {
      console.error('Failed to get audit logs:', error);
      return [];
    }
  }

  // Schema operations
  async getTables(): Promise<string[]> {
    try {
      const results = this.executeQuery<{name: string}>(`
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name NOT LIKE 'sqlite_%'
        ORDER BY name
      `);
      return results.map(r => r.name);
    } catch (error) {
      console.error('Failed to get tables:', error);
      return [];
    }
  }

  async getTableSchema(tableName: string): Promise<any> {
    try {
      const columns = this.executeQuery(`PRAGMA table_info(${tableName})`);
      const indexes = this.executeQuery(`PRAGMA index_list(${tableName})`);
      const foreignKeys = this.executeQuery(`PRAGMA foreign_key_list(${tableName})`);
      
      return {
        name: tableName,
        columns: columns.map((col: any) => ({
          name: col.name,
          type: col.type,
          nullable: !col.notnull,
          defaultValue: col.dflt_value,
          primaryKey: !!col.pk,
          unique: false,
          autoIncrement: col.type === 'INTEGER' && !!col.pk
        })),
        indexes: indexes,
        foreignKeys: foreignKeys,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to get table schema:', error);
      return null;
    }
  }

  async executeSQL(sql: string): Promise<any> {
    try {
      if (sql.trim().toUpperCase().startsWith('SELECT')) {
        return this.executeQuery(sql);
      } else {
        return this.executeRun(sql);
      }
    } catch (error) {
      console.error('Failed to execute SQL:', error);
      throw error;
    }
  }

  async createDataRelationship(relationship: any): Promise<ApiResponse<any>> {
    try {
      const sql = `
        INSERT INTO data_links (id, source_table, source_field, target_table, target_field, link_type, cascade_delete, created_by, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      this.executeInsert(sql, [
        relationship.id,
        relationship.sourceTable,
        relationship.sourceColumn,
        relationship.targetTable,
        relationship.targetColumn,
        relationship.relationshipType,
        relationship.cascadeDelete,
        'current_user',
        relationship.created_at
      ]);
      
      return { data: relationship };
    } catch (error) {
      return { data: null as any, error: 'Failed to create relationship' };
    }
  }

  async deleteDataRelationship(id: string): Promise<ApiResponse<boolean>> {
    try {
      this.executeRun('DELETE FROM data_links WHERE id = ?', [id]);
      return { data: true };
    } catch (error) {
      return { data: false, error: 'Failed to delete relationship' };
    }
  }

  async getDataRelationships(): Promise<any[]> {
    try {
      return this.executeQuery('SELECT * FROM data_links ORDER BY created_at DESC');
    } catch (error) {
      console.error('Failed to get relationships:', error);
      return [];
    }
  }

  // Extended user operations
  async getUserProfile(id: string): Promise<ApiResponse<UserProfile>> {
    try {
      const results = this.executeQuery<any>('SELECT * FROM user_profiles WHERE user_id = ?', [id]);
      if (results.length === 0) {
        return { data: null as any, error: 'User profile not found' };
      }
      return { data: results[0] };
    } catch (error) {
      return { data: null as any, error: 'Failed to get user profile' };
    }
  }

  // Validation result operations
  async createValidationResult(result: any): Promise<ApiResponse<any>> {
    try {
      // For now, just log validation results - in production, save to a validation_results table
      console.log('Validation result:', result);
      return { data: result };
    } catch (error) {
      return { data: null as any, error: 'Failed to create validation result' };
    }
  }
}