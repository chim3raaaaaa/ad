// Enhanced local CSV service for reference data export/import
import { localReferenceDataService } from './localReferenceDataService';

export interface CSVExportResult {
  success: boolean;
  filename: string;
  rowCount: number;
  error?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  tablesChecked: number;
  timestamp: string;
}

export interface ReferenceTable {
  name: string;
  displayName: string;
  description?: string;
}

class LocalCSVService {
  private isElectron(): boolean {
    return typeof window !== 'undefined' && (window as any).electronAPI;
  }

  private readonly REFERENCE_TABLES: ReferenceTable[] = [
    { name: 'product_categories', displayName: 'Product Categories', description: 'Product category definitions' },
    { name: 'products', displayName: 'Products', description: 'Product master data' },
    { name: 'grades', displayName: 'Grades', description: 'Grade specifications' },
    { name: 'plants', displayName: 'Plants', description: 'Plant locations' },
    { name: 'suppliers', displayName: 'Suppliers', description: 'Supplier information' },
    { name: 'climatic_conditions', displayName: 'Climatic Conditions', description: 'Weather condition codes' },
    { name: 'colour', displayName: 'Colors', description: 'Color specifications' },
    { name: 'lab_group_code', displayName: 'Lab Group Codes', description: 'Laboratory group codes' },
    { name: 'lab_mould', displayName: 'Lab Moulds', description: 'Laboratory mould definitions' },
    { name: 'lab_tests', displayName: 'Lab Tests', description: 'Available laboratory tests' },
    { name: 'sampling_places', displayName: 'Sampling Places', description: 'Sample collection locations' },
  ];

  // Export all reference data to CSV files
  async exportAllData(): Promise<CSVExportResult[]> {
    const results: CSVExportResult[] = [];

    // Get custom reference types
    const customTypes = await localReferenceDataService.getCustomReferenceTypes();
    const allTables = [
      ...this.REFERENCE_TABLES,
      ...customTypes.filter(t => t.isActive).map(t => ({
        name: t.tableName,
        displayName: t.name,
        description: t.description
      }))
    ];

    for (const table of allTables) {
      try {
        const data = await localReferenceDataService.getReferenceData(table.name);
        
        if (data.length === 0) {
          results.push({
            success: false,
            filename: `${table.name}.csv`,
            rowCount: 0,
            error: 'No data available'
          });
          continue;
        }

        const csvContent = this.convertToCSV(data);
        const filename = `${table.name}.csv`;

        if (this.isElectron()) {
          // Use Electron's file save dialog
          try {
            const result = await (window as any).electronAPI.saveFile(filename, csvContent);
            if (result.success) {
              results.push({
                success: true,
                filename,
                rowCount: data.length
              });
            } else {
              results.push({
                success: false,
                filename,
                rowCount: 0,
                error: result.error || 'Failed to save file'
              });
            }
          } catch (error) {
            results.push({
              success: false,
              filename,
              rowCount: 0,
              error: error instanceof Error ? error.message : 'Unknown error'
            });
          }
        } else {
          // Browser download
          this.downloadCSV(csvContent, filename);
          results.push({
            success: true,
            filename,
            rowCount: data.length
          });
        }
      } catch (error) {
        results.push({
          success: false,
          filename: `${table.name}.csv`,
          rowCount: 0,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return results;
  }

  // Validate all reference data
  async validateAllData(): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];
    let tablesChecked = 0;

    // Get custom reference types
    const customTypes = await localReferenceDataService.getCustomReferenceTypes();
    const allTables = [
      ...this.REFERENCE_TABLES,
      ...customTypes.filter(t => t.isActive).map(t => ({
        name: t.tableName,
        displayName: t.name,
        description: t.description
      }))
    ];

    for (const table of allTables) {
      try {
        tablesChecked++;
        const data = await localReferenceDataService.getReferenceData(table.name);
        
        // Check if table is empty
        if (data.length === 0) {
          warnings.push(`${table.displayName}: No data found - consider adding sample data`);
          continue;
        }

        // Check for required fields based on table type
        const validationResults = this.validateTableData(table.name, data);
        errors.push(...validationResults.errors);
        warnings.push(...validationResults.warnings);

        // Check for low data count
        if (data.length < 3 && table.name !== 'climatic_conditions') {
          warnings.push(`${table.displayName}: Only ${data.length} entries found`);
        }

      } catch (error) {
        errors.push(`${table.displayName}: Failed to validate - ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      tablesChecked,
      timestamp: new Date().toISOString()
    };
  }

  // Initialize sample data for all tables
  async populateAllSampleData(): Promise<void> {
    // For clean prototype - skip sample data population
    console.log('Sample data population disabled for clean prototype');
    return;
  }

  // Get table statistics
  async getTableStats(): Promise<{ [tableName: string]: { rowCount: number; lastUpdated?: string } }> {
    const stats: { [tableName: string]: { rowCount: number; lastUpdated?: string } } = {};
    
    const customTypes = await localReferenceDataService.getCustomReferenceTypes();
    const allTables = [
      ...this.REFERENCE_TABLES,
      ...customTypes.filter(t => t.isActive).map(t => ({
        name: t.tableName,
        displayName: t.name
      }))
    ];

    for (const table of allTables) {
      try {
        const data = await localReferenceDataService.getReferenceData(table.name);
        const lastUpdated = data.length > 0 ? 
          Math.max(...data.map(item => new Date(item.updated_at || item.created_at).getTime())) : 
          undefined;

        stats[table.name] = {
          rowCount: data.length,
          lastUpdated: lastUpdated ? new Date(lastUpdated).toISOString() : undefined
        };
      } catch (error) {
        stats[table.name] = { rowCount: 0 };
      }
    }

    return stats;
  }

  // Convert data to CSV format
  private convertToCSV(data: any[]): string {
    if (data.length === 0) return '';

    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','), // Header row
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          // Escape commas and quotes in values
          if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value ?? '';
        }).join(',')
      )
    ];

    return csvRows.join('\n');
  }

  // Download CSV in browser
  private downloadCSV(content: string, filename: string): void {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }

  // Validate specific table data
  private validateTableData(tableName: string, data: any[]): { errors: string[]; warnings: string[] } {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Common validations for all tables
    const requiredFields = ['id'];
    
    // Table-specific validations
    const tableValidations: { [key: string]: string[] } = {
      'product_categories': ['code', 'name'],
      'products': ['code', 'name'],
      'grades': ['code', 'name'],
      'plants': ['code', 'name'],
      'suppliers': ['code', 'name'],
      'climatic_conditions': ['code', 'description'],
      'colour': ['code', 'description'],
      'lab_group_code': ['code'],
      'lab_tests': ['code', 'description'],
      'sampling_places': ['code', 'description']
    };

    const required = [...requiredFields, ...(tableValidations[tableName] || [])];

    // Check for required fields
    for (const item of data) {
      for (const field of required) {
        if (!item[field] || item[field].toString().trim() === '') {
          errors.push(`${tableName}: Missing required field "${field}" in record ${item.id || 'unknown'}`);
        }
      }

      // Check for duplicate codes
      if (item.code) {
        const duplicates = data.filter(d => d.code === item.code && d.id !== item.id);
        if (duplicates.length > 0) {
          errors.push(`${tableName}: Duplicate code "${item.code}" found`);
        }
      }
    }

    return { errors, warnings };
  }

  // Get sample data for initialization
  private getSampleData(): { [tableName: string]: any[] } {
    return {
      product_categories: [
        { code: 'CONC', name: 'Concrete Products', description: 'Standard concrete products', is_active: 1, sort_order: 1 },
        { code: 'PAVE', name: 'Pavers', description: 'Concrete pavers and blocks', is_active: 1, sort_order: 2 },
        { code: 'KERB', name: 'Kerbs', description: 'Kerb stones and accessories', is_active: 1, sort_order: 3 },
        { code: 'FLAG', name: 'Flagstones', description: 'Flagstone products', is_active: 1, sort_order: 4 },
        { code: 'AGGR', name: 'Aggregates', description: 'Raw aggregates and materials', is_active: 1, sort_order: 5 },
        { code: 'BLOC', name: 'Blocks', description: 'Concrete building blocks', is_active: 1, sort_order: 6 }
      ],
      products: [
        { code: 'STD_CONC_25', name: 'Standard Concrete 25MPa', category_id: 'prod_cat_1', description: '25MPa standard concrete mix', unit_of_measure: 'kg', is_active: 1 },
        { code: 'STD_CONC_32', name: 'Standard Concrete 32MPa', category_id: 'prod_cat_1', description: '32MPa standard concrete mix', unit_of_measure: 'kg', is_active: 1 },
        { code: 'PAVE_80MM', name: 'Paver 80mm', category_id: 'prod_cat_2', description: '80mm concrete paver', unit_of_measure: 'each', is_active: 1 },
        { code: 'KERB_150', name: 'Kerb 150mm', category_id: 'prod_cat_3', description: '150mm concrete kerb', unit_of_measure: 'lm', is_active: 1 }
      ],
      grades: [
        { code: 'C25', name: 'Grade C25', product_type: 'concrete', specifications: '{"strength": "25MPa", "slump": "75mm"}', is_active: 1 },
        { code: 'C32', name: 'Grade C32', product_type: 'concrete', specifications: '{"strength": "32MPa", "slump": "75mm"}', is_active: 1 },
        { code: 'P80', name: 'Paver Grade', product_type: 'paver', specifications: '{"strength": "50MPa", "thickness": "80mm"}', is_active: 1 },
        { code: 'K40', name: 'Kerb Grade', product_type: 'kerb', specifications: '{"strength": "40MPa", "dimensions": "150x300mm"}', is_active: 1 }
      ],
      plants: [
        { code: 'PLT001', name: 'Main Plant', location: 'Industrial Estate North', contact_info: '{"manager": "John Smith", "phone": "123-456-7890"}', is_active: 1 },
        { code: 'PLT002', name: 'South Plant', location: 'Industrial Estate South', contact_info: '{"manager": "Jane Doe", "phone": "123-456-7891"}', is_active: 1 }
      ],
      suppliers: [
        { code: 'SUP001', name: 'ABC Aggregates', contact_person: 'Mike Johnson', email: 'mike@abcagg.com', phone: '123-555-0001', address: '123 Supply St', is_active: 1 },
        { code: 'SUP002', name: 'XYZ Cement', contact_person: 'Sarah Wilson', email: 'sarah@xyzcement.com', phone: '123-555-0002', address: '456 Material Ave', is_active: 1 }
      ],
      climatic_conditions: [
        { code: 'NORM', description: 'Normal conditions', active: 'Y' },
        { code: 'HOT', description: 'Hot weather (>30°C)', active: 'Y' },
        { code: 'COLD', description: 'Cold weather (<5°C)', active: 'Y' },
        { code: 'WET', description: 'Wet conditions', active: 'Y' }
      ],
      colour: [
        { code: 'GREY', description: 'Standard Grey', active: 'Y' },
        { code: 'CHARCOAL', description: 'Charcoal', active: 'Y' },
        { code: 'RED', description: 'Red Oxide', active: 'Y' },
        { code: 'BUFF', description: 'Buff', active: 'Y' }
      ]
    };
  }
}

// Export singleton instance
export const localCSVService = new LocalCSVService();