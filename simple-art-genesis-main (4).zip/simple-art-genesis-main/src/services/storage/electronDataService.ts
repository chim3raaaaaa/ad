import type { IDataService } from '../api/interface';
import type {
  Memo,
  TestRequest,
  UserProfile,
  UserRole,
  AnalyticsData,
  ApiResponse,
  PaginatedResponse,
  QueryOptions,
  Module,
  ModuleInstance,
  ModuleMarketplace,
  ValidationRule,
  ValidationResult,
  TestSchedule,
  ScheduleTemplate,
  TableRelationship,
  NavigationPath,
  DataVersion,
  ChangeRequest,
  ApprovalWorkflow
} from '../api/types';
import { SQLiteDataService } from './sqliteService';

// ElectronAPI types now defined globally in vite-env.d.ts

class ElectronDataService implements IDataService {
  private isElectron(): boolean {
    return window.electronAPI !== undefined;
  }

  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  }

  private async executeRun(sql: string, params: any[] = []): Promise<any> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  }

  private createPaginatedResponse<T>(
    data: T[],
    page: number = 1,
    limit: number = 50
  ): PaginatedResponse<T> {
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedData = data.slice(startIndex, endIndex);

    return {
      data: paginatedData,
      count: data.length,
      page: page,
      totalPages: Math.ceil(data.length / limit)
    };
  }

  // Memo operations
  async getMemos(options: QueryOptions = {}): Promise<PaginatedResponse<Memo>> {
    try {
      let sql = 'SELECT * FROM memos WHERE 1=1';
      const params: any[] = [];

      if (options.filters?.search) {
        sql += ' AND (ref LIKE ?)';
        params.push(`%${options.filters.search}%`);
      }

      if (options.filters?.type) {
        sql += ' AND type = ?';
        params.push(options.filters.type);
      }

      if (options.filters?.status) {
        sql += ' AND status = ?';
        params.push(options.filters.status);
      }

      sql += ' ORDER BY created_at DESC';

      const memos = await this.executeQuery<Memo>(sql, params);
      return this.createPaginatedResponse(memos, options.page, options.limit);
    } catch (error) {
      console.error('Error fetching memos:', error);
      throw error;
    }
  }

  async getMemoById(id: string): Promise<ApiResponse<Memo>> {
    try {
      const memos = await this.executeQuery<Memo>('SELECT * FROM memos WHERE id = ?', [id]);
      if (memos.length === 0) {
        return { data: null, error: 'Memo not found' };
      }
      return { data: memos[0] };
    } catch (error) {
      console.error('Error fetching memo:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async createMemo(memo: Omit<Memo, 'id' | 'created_at'>): Promise<ApiResponse<Memo>> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();
      
      await this.executeRun(
        `INSERT INTO memos (id, ref, created_at, user_id)
         VALUES (?, ?, ?, ?)`,
        [id, memo.ref, now, memo.user_id]
      );

      const createdMemo = await this.getMemoById(id);
      return createdMemo;
    } catch (error) {
      console.error('Error creating memo:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async updateMemo(id: string, memo: Partial<Memo>): Promise<ApiResponse<Memo>> {
    try {
      const updates: string[] = [];
      const params: any[] = [];

      Object.entries(memo).forEach(([key, value]) => {
        if (key !== 'id' && key !== 'created_at' && value !== undefined) {
          updates.push(`${key} = ?`);
          params.push(value);
        }
      });

      if (updates.length === 0) {
        return { data: null, error: 'No fields to update' };
      }

      updates.push('updated_at = ?');
      params.push(new Date().toISOString());
      params.push(id);

      await this.executeRun(
        `UPDATE memos SET ${updates.join(', ')} WHERE id = ?`,
        params
      );

      const updatedMemo = await this.getMemoById(id);
      return updatedMemo;
    } catch (error) {
      console.error('Error updating memo:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async deleteMemo(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.executeRun('DELETE FROM memos WHERE id = ?', [id]);
      return { data: result.changes > 0 };
    } catch (error) {
      console.error('Error deleting memo:', error);
      return { data: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Test Request operations
  async getTestRequests(options: QueryOptions = {}): Promise<PaginatedResponse<TestRequest>> {
    try {
      let sql = 'SELECT * FROM test_requests WHERE 1=1';
      const params: any[] = [];

      if (options.filters?.search) {
        sql += ' AND (client_name LIKE ? OR sample_description LIKE ?)';
        params.push(`%${options.filters.search}%`, `%${options.filters.search}%`);
      }

      if (options.filters?.test_type) {
        sql += ' AND test_type = ?';
        params.push(options.filters.test_type);
      }

      if (options.filters?.status) {
        sql += ' AND status = ?';
        params.push(options.filters.status);
      }

      sql += ' ORDER BY created_at DESC';

      const requests = await this.executeQuery<TestRequest>(sql, params);
      return this.createPaginatedResponse(requests, options.page, options.limit);
    } catch (error) {
      console.error('Error fetching test requests:', error);
      throw error;
    }
  }

  async getTestRequestById(id: string): Promise<ApiResponse<TestRequest>> {
    try {
      const requests = await this.executeQuery<TestRequest>('SELECT * FROM test_requests WHERE id = ?', [id]);
      if (requests.length === 0) {
        return { data: null, error: 'Test request not found' };
      }
      return { data: requests[0] };
    } catch (error) {
      console.error('Error fetching test request:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async createTestRequest(testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestRequest>> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();
      
      await this.executeRun(
        `INSERT INTO test_requests (id, client_name, sample_description, test_type, priority, status, assigned_to, due_date, created_at, updated_at, user_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id, testRequest.client_name, testRequest.sample_description, testRequest.test_type,
          testRequest.priority, testRequest.status, testRequest.assigned_to,
          testRequest.due_date, now, now, testRequest.user_id
        ]
      );

      const createdRequest = await this.getTestRequestById(id);
      return createdRequest;
    } catch (error) {
      console.error('Error creating test request:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async updateTestRequest(id: string, testRequest: Partial<TestRequest>): Promise<ApiResponse<TestRequest>> {
    try {
      const updates: string[] = [];
      const params: any[] = [];

      Object.entries(testRequest).forEach(([key, value]) => {
        if (key !== 'id' && key !== 'created_at' && value !== undefined) {
          updates.push(`${key} = ?`);
          params.push(value);
        }
      });

      if (updates.length === 0) {
        return { data: null, error: 'No fields to update' };
      }

      updates.push('updated_at = ?');
      params.push(new Date().toISOString());
      params.push(id);

      await this.executeRun(
        `UPDATE test_requests SET ${updates.join(', ')} WHERE id = ?`,
        params
      );

      const updatedRequest = await this.getTestRequestById(id);
      return updatedRequest;
    } catch (error) {
      console.error('Error updating test request:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async deleteTestRequest(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.executeRun('DELETE FROM test_requests WHERE id = ?', [id]);
      return { data: result.changes > 0 };
    } catch (error) {
      console.error('Error deleting test request:', error);
      return { data: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // User Profile operations
  async getUserProfiles(options: QueryOptions = {}): Promise<PaginatedResponse<UserProfile>> {
    try {
      let sql = 'SELECT * FROM user_profiles WHERE 1=1';
      const params: any[] = [];

      if (options.filters?.search) {
        sql += ' AND (name LIKE ? OR email LIKE ?)';
        params.push(`%${options.filters.search}%`, `%${options.filters.search}%`);
      }

      sql += ' ORDER BY created_at DESC';

      const profiles = await this.executeQuery<UserProfile>(sql, params);
      return this.createPaginatedResponse(profiles, options.page, options.limit);
    } catch (error) {
      console.error('Error fetching user profiles:', error);
      throw error;
    }
  }

  async getUserProfileById(id: string): Promise<ApiResponse<UserProfile>> {
    try {
      const profiles = await this.executeQuery<UserProfile>('SELECT * FROM user_profiles WHERE id = ?', [id]);
      if (profiles.length === 0) {
        return { data: null, error: 'User profile not found' };
      }
      return { data: profiles[0] };
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async createUserProfile(profile: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserProfile>> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();
      
      await this.executeRun(
        `INSERT INTO user_profiles (id, user_id, name, email, role, department, created_at, updated_at, last_login, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, profile.user_id, profile.name, profile.email, profile.role, profile.department, now, now, profile.last_login, profile.status]
      );

      const createdProfile = await this.getUserProfileById(id);
      return createdProfile;
    } catch (error) {
      console.error('Error creating user profile:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<ApiResponse<UserProfile>> {
    try {
      const updates: string[] = [];
      const params: any[] = [];

      Object.entries(profile).forEach(([key, value]) => {
        if (key !== 'id' && key !== 'created_at' && value !== undefined) {
          updates.push(`${key} = ?`);
          params.push(value);
        }
      });

      if (updates.length === 0) {
        return { data: null, error: 'No fields to update' };
      }

      updates.push('updated_at = ?');
      params.push(new Date().toISOString());
      params.push(id);

      await this.executeRun(
        `UPDATE user_profiles SET ${updates.join(', ')} WHERE id = ?`,
        params
      );

      const updatedProfile = await this.getUserProfileById(id);
      return updatedProfile;
    } catch (error) {
      console.error('Error updating user profile:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async deleteUserProfile(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.executeRun('DELETE FROM user_profiles WHERE id = ?', [id]);
      return { data: result.changes > 0 };
    } catch (error) {
      console.error('Error deleting user profile:', error);
      return { data: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // User Role operations
  async getUserRoles(): Promise<ApiResponse<UserRole[]>> {
    try {
      const roles = await this.executeQuery<UserRole>('SELECT * FROM user_roles ORDER BY name');
      return { data: roles };
    } catch (error) {
      console.error('Error fetching user roles:', error);
      return { data: [], error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getUserRoleById(id: string): Promise<ApiResponse<UserRole>> {
    try {
      const roles = await this.executeQuery<UserRole>('SELECT * FROM user_roles WHERE id = ?', [id]);
      if (roles.length === 0) {
        return { data: null, error: 'User role not found' };
      }
      return { data: roles[0] };
    } catch (error) {
      console.error('Error fetching user role:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async createUserRole(role: Omit<UserRole, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserRole>> {
    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();
      
      await this.executeRun(
        `INSERT INTO user_roles (id, name, description, permissions, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [id, role.name, role.description, role.permissions, now, now]
      );

      const createdRole = await this.getUserRoleById(id);
      return createdRole;
    } catch (error) {
      console.error('Error creating user role:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async updateUserRole(id: string, role: Partial<UserRole>): Promise<ApiResponse<UserRole>> {
    try {
      const updates: string[] = [];
      const params: any[] = [];

      Object.entries(role).forEach(([key, value]) => {
        if (key !== 'id' && key !== 'created_at' && value !== undefined) {
          updates.push(`${key} = ?`);
          params.push(value);
        }
      });

      if (updates.length === 0) {
        return { data: null, error: 'No fields to update' };
      }

      updates.push('updated_at = ?');
      params.push(new Date().toISOString());
      params.push(id);

      await this.executeRun(
        `UPDATE user_roles SET ${updates.join(', ')} WHERE id = ?`,
        params
      );

      const updatedRole = await this.getUserRoleById(id);
      return updatedRole;
    } catch (error) {
      console.error('Error updating user role:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async deleteUserRole(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.executeRun('DELETE FROM user_roles WHERE id = ?', [id]);
      return { data: result.changes > 0 };
    } catch (error) {
      console.error('Error deleting user role:', error);
      return { data: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Analytics operations
  async getAnalyticsData(): Promise<ApiResponse<AnalyticsData>> {
    try {
      const [totalTests] = await this.executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM test_requests');
      const [completedTests] = await this.executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM test_requests WHERE status = "completed"');
      const [pendingTests] = await this.executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM test_requests WHERE status = "pending"');
      const [totalMemos] = await this.executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM memos');

      const completionRate = totalTests.count > 0 ? (completedTests.count / totalTests.count) * 100 : 0;

      return {
        data: {
          totalTests: totalTests.count,
          completedTests: completedTests.count,
          pendingTests: pendingTests.count,
          completionRate,
          activeUsers: 0
        }
      };
    } catch (error) {
      console.error('Error fetching analytics data:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getMonthlyTestData(): Promise<ApiResponse<any[]>> {
    try {
      const data = await this.executeQuery(`
        SELECT 
          strftime('%Y-%m', created_at) as month,
          COUNT(*) as total,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
        FROM test_requests 
        WHERE created_at >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', created_at)
        ORDER BY month
      `);
      
      return { data };
    } catch (error) {
      console.error('Error fetching monthly test data:', error);
      return { data: [], error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getTestTypeDistribution(): Promise<ApiResponse<any[]>> {
    try {
      const data = await this.executeQuery(`
        SELECT type, COUNT(*) as count
        FROM test_requests
        GROUP BY type
        ORDER BY count DESC
      `);
      
      return { data };
    } catch (error) {
      console.error('Error fetching test type distribution:', error);
      return { data: [], error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async getCurrentUser(): Promise<ApiResponse<UserProfile | null>> {
    try {
      // For now, return first admin user as current user
      const users = await this.executeQuery<UserProfile>('SELECT * FROM user_profiles WHERE role = "admin" LIMIT 1');
      return { data: users[0] || null };
    } catch (error) {
      console.error('Error fetching current user:', error);
      return { data: null, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Electron-specific methods
  async createBackup(): Promise<{ success: boolean; path?: string; error?: string }> {
    if (!this.isElectron()) {
      return { success: false, error: 'Electron API not available' };
    }
    return await window.electronAPI.createBackup();
  }

  async restoreBackup(backupPath: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isElectron()) {
      return { success: false, error: 'Electron API not available' };
    }
    return await window.electronAPI.restoreBackup(backupPath);
  }

  async exportData(format: 'json' | 'sqlite'): Promise<{ success: boolean; path?: string; canceled?: boolean; error?: string }> {
    if (!this.isElectron()) {
      return { success: false, error: 'Electron API not available' };
    }
    return await window.electronAPI.exportData(format);
  }

  async importData(): Promise<{ success: boolean; canceled?: boolean; error?: string }> {
    if (!this.isElectron()) {
      return { success: false, error: 'Electron API not available' };
    }
    return await window.electronAPI.importData();
  }

  async getAppPaths() {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }
    return await window.electronAPI.getAppPaths();
  }

  // Module operations - delegate to SQLite service
  private sqliteService = new SQLiteDataService();

  async getModules(options?: QueryOptions): Promise<PaginatedResponse<Module>> {
    return this.sqliteService.getModules(options);
  }

  async getModuleById(id: string): Promise<ApiResponse<Module>> {
    return this.sqliteService.getModuleById(id);
  }

  async installModule(moduleData: any): Promise<ApiResponse<Module>> {
    return this.sqliteService.installModule(moduleData);
  }

  async uninstallModule(id: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.uninstallModule(id);
  }

  async enableModule(id: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.enableModule(id);
  }

  async disableModule(id: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.disableModule(id);
  }

  async updateModule(id: string, updates: Partial<Module>): Promise<ApiResponse<Module>> {
    return this.sqliteService.updateModule(id, updates);
  }

  async getModuleInstances(moduleId?: string): Promise<ApiResponse<ModuleInstance[]>> {
    return this.sqliteService.getModuleInstances(moduleId);
  }

  async createModuleInstance(instance: Omit<ModuleInstance, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ModuleInstance>> {
    return this.sqliteService.createModuleInstance(instance);
  }

  async updateModuleInstance(id: string, updates: Partial<ModuleInstance>): Promise<ApiResponse<ModuleInstance>> {
    return this.sqliteService.updateModuleInstance(id, updates);
  }

  async deleteModuleInstance(id: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.deleteModuleInstance(id);
  }

  async getMarketplaceModules(): Promise<PaginatedResponse<ModuleMarketplace>> {
    return this.sqliteService.getMarketplaceModules();
  }

  async downloadModule(marketplaceId: string): Promise<ApiResponse<any>> {
    return this.sqliteService.downloadModule(marketplaceId);
  }

  async exportModule(id: string): Promise<ApiResponse<Blob>> {
    return this.sqliteService.exportModule(id);
  }

  async importModule(file: File): Promise<ApiResponse<Module>> {
    return this.sqliteService.importModule(file);
  }

  // Phase 6: Advanced Data Features - delegate to SQLite service
  async getValidationRules(options?: QueryOptions): Promise<PaginatedResponse<ValidationRule>> {
    return this.sqliteService.getValidationRules(options);
  }

  async getValidationRuleById(id: string): Promise<ApiResponse<ValidationRule>> {
    return this.sqliteService.getValidationRuleById(id);
  }

  async createValidationRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ValidationRule>> {
    return this.sqliteService.createValidationRule(rule);
  }

  async updateValidationRule(id: string, rule: Partial<ValidationRule>): Promise<ApiResponse<ValidationRule>> {
    return this.sqliteService.updateValidationRule(id, rule);
  }

  async deleteValidationRule(id: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.deleteValidationRule(id);
  }

  async validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ApiResponse<ValidationResult[]>> {
    return this.sqliteService.validateRecord(tableName, recordId, data);
  }

  async getValidationResults(options?: QueryOptions): Promise<PaginatedResponse<ValidationResult>> {
    return this.sqliteService.getValidationResults(options);
  }

  async getTestSchedules(options?: QueryOptions): Promise<PaginatedResponse<TestSchedule>> {
    return this.sqliteService.getTestSchedules(options);
  }

  async createTestSchedule(schedule: Omit<TestSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestSchedule>> {
    return this.sqliteService.createTestSchedule(schedule);
  }

  async generateSchedulesFromTemplate(templateId: string, sampleIds: string[]): Promise<ApiResponse<TestSchedule[]>> {
    return this.sqliteService.generateSchedulesFromTemplate(templateId, sampleIds);
  }

  async getScheduleTemplates(): Promise<ApiResponse<ScheduleTemplate[]>> {
    return this.sqliteService.getScheduleTemplates();
  }

  async createScheduleTemplate(template: Omit<ScheduleTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ScheduleTemplate>> {
    return this.sqliteService.createScheduleTemplate(template);
  }

  async updateScheduleTemplate(id: string, template: Partial<ScheduleTemplate>): Promise<ApiResponse<ScheduleTemplate>> {
    return this.sqliteService.updateScheduleTemplate(id, template);
  }

  async getTableRelationships(tableName?: string): Promise<ApiResponse<TableRelationship[]>> {
    return this.sqliteService.getTableRelationships(tableName);
  }

  async getRelatedRecords(tableName: string, recordId: string, relationship: string): Promise<ApiResponse<any[]>> {
    return this.sqliteService.getRelatedRecords(tableName, recordId, relationship);
  }

  async getNavigationPath(tableName: string, recordId: string): Promise<ApiResponse<NavigationPath[]>> {
    return this.sqliteService.getNavigationPath(tableName, recordId);
  }

  async getDataVersions(tableName: string, recordId: string): Promise<ApiResponse<DataVersion[]>> {
    return this.sqliteService.getDataVersions(tableName, recordId);
  }

  async createDataVersion(version: Omit<DataVersion, 'id' | 'created_at'>): Promise<ApiResponse<DataVersion>> {
    return this.sqliteService.createDataVersion(version);
  }

  async compareVersions(versionId1: string, versionId2: string): Promise<ApiResponse<any>> {
    return this.sqliteService.compareVersions(versionId1, versionId2);
  }

  async rollbackToVersion(versionId: string): Promise<ApiResponse<boolean>> {
    return this.sqliteService.rollbackToVersion(versionId);
  }

  async getChangeRequests(options?: QueryOptions): Promise<PaginatedResponse<ChangeRequest>> {
    return this.sqliteService.getChangeRequests(options);
  }

  async createChangeRequest(request: Omit<ChangeRequest, 'id' | 'requested_at'>): Promise<ApiResponse<ChangeRequest>> {
    return this.sqliteService.createChangeRequest(request);
  }

  async approveChangeRequest(requestId: string, comments?: string): Promise<ApiResponse<ChangeRequest>> {
    return this.sqliteService.approveChangeRequest(requestId, comments);
  }

  async rejectChangeRequest(requestId: string, comments: string): Promise<ApiResponse<ChangeRequest>> {
    return this.sqliteService.rejectChangeRequest(requestId, comments);
  }

  async getApprovalWorkflows(): Promise<ApiResponse<ApprovalWorkflow[]>> {
    return this.sqliteService.getApprovalWorkflows();
  }

  // Reference Dataset operations
  async uploadReferenceDataset(tableName: string, csvData: any[], replaceExisting: boolean = false): Promise<{ success: boolean; rowsInserted: number; error?: string }> {
    // For now, we'll ignore replaceExisting since sqliteService doesn't support it yet
    return this.sqliteService.uploadReferenceDataset(tableName, csvData);
  }

  async getReferenceData(tableName: string, activeOnly?: boolean): Promise<any[]> {
    return this.sqliteService.getReferenceData(tableName, activeOnly);
  }

  async getFilteredSamplingPlaces(productType: string): Promise<any[]> {
    return this.sqliteService.getFilteredSamplingPlaces(productType);
  }

  // Required interface methods
  async createAuditLog(entry: any): Promise<ApiResponse<any>> { return this.sqliteService.createAuditLog(entry); }
  async getAuditLogs(filters?: any): Promise<any[]> { return this.sqliteService.getAuditLogs(filters); }
  async getTables(): Promise<string[]> { return this.sqliteService.getTables(); }
  async getTableSchema(tableName: string): Promise<any> { return this.sqliteService.getTableSchema(tableName); }
  async executeSQL(sql: string): Promise<any> { return this.sqliteService.executeSQL(sql); }
  async createDataRelationship(relationship: any): Promise<ApiResponse<any>> { return this.sqliteService.createDataRelationship(relationship); }
  async deleteDataRelationship(id: string): Promise<ApiResponse<boolean>> { return this.sqliteService.deleteDataRelationship(id); }
  async getDataRelationships(): Promise<any[]> { return this.sqliteService.getDataRelationships(); }
  async getUserProfile(id: string): Promise<ApiResponse<UserProfile>> { return this.sqliteService.getUserProfile(id); }
  async createValidationResult(result: any): Promise<ApiResponse<any>> { return this.sqliteService.createValidationResult(result); }
}

export { ElectronDataService };

// Export singleton instance for easy import
export const electronDataService = new ElectronDataService();