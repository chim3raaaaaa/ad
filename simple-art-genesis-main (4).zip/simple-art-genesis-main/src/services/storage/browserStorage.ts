// Browser-compatible IndexedDB storage service
import type { IDataService } from '../api/interface';
import type {
  Memo,
  TestRequest,
  UserProfile,
  UserRole,
  AnalyticsData,
  ApiResponse,
  PaginatedResponse,
  QueryOptions,
  Module,
  ModuleInstance,
  ModuleMarketplace,
  ValidationRule,
  ValidationResult,
  TestSchedule,
  ScheduleTemplate,
  TableRelationship,
  NavigationPath,
  DataVersion,
  ChangeRequest,
  ApprovalWorkflow
} from '../api/types';

// IndexedDB wrapper for browser storage
class LocalStorage {
  private dbName = 'LabManagementDB';
  private version = 1;
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Create object stores
        if (!db.objectStoreNames.contains('users')) {
          db.createObjectStore('users', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('profiles')) {
          db.createObjectStore('profiles', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('memos')) {
          db.createObjectStore('memos', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('test_requests')) {
          db.createObjectStore('test_requests', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('user_roles')) {
          db.createObjectStore('user_roles', { keyPath: 'id' });
        }
        
        // Reference data stores
        const referenceTables = ['products', 'product_categories', 'plants', 'sampling_places', 'test_standards', 'clients'];
        referenceTables.forEach(table => {
          if (!db.objectStoreNames.contains(`reference_${table}`)) {
            db.createObjectStore(`reference_${table}`, { keyPath: 'id' });
          }
        });
        
        // System stores
        if (!db.objectStoreNames.contains('audit_logs')) {
          db.createObjectStore('audit_logs', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('data_relationships')) {
          db.createObjectStore('data_relationships', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('validation_results')) {
          db.createObjectStore('validation_results', { keyPath: 'id' });
        }

        // Initialize default data
        this.initializeDefaultData(db);
      };
    });
  }

  private initializeDefaultData(db: IDBDatabase): void {
    const tx = db.transaction(['users', 'profiles', 'user_roles'], 'readwrite');
    
    // Default roles
    const rolesStore = tx.objectStore('user_roles');
    rolesStore.add({
      id: 'role_admin',
      name: 'admin',
      description: 'Full system administrator access',
      permissions: ['full_access', 'user_management', 'system_settings', 'developer_mode'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    rolesStore.add({
      id: 'role_lab',
      name: 'lab_technician',
      description: 'Laboratory technician access',
      permissions: ['test_management', 'memo_access', 'basic_reports'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });
  }

  async getAll(storeName: string): Promise<any[]> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async get(storeName: string, id: string): Promise<any> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.get(id);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async add(storeName: string, data: any): Promise<any> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.add(data);
      
      request.onsuccess = () => resolve(data);
      request.onerror = () => reject(request.error);
    });
  }

  async put(storeName: string, data: any): Promise<any> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.put(data);
      
      request.onsuccess = () => resolve(data);
      request.onerror = () => reject(request.error);
    });
  }

  async delete(storeName: string, id: string): Promise<boolean> {
    if (!this.db) await this.init();
    
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.delete(id);
      
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  }
}

class BrowserDataService implements IDataService {
  private storage = new LocalStorage();

  private generateId(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  // Memo operations
  async getMemos(options: QueryOptions = {}): Promise<PaginatedResponse<Memo>> {
    const { page = 1, limit = 10 } = options;
    const offset = (page - 1) * limit;

    try {
      const memos = await this.storage.getAll('memos');
      const total = memos.length;
      const paginatedData = memos.slice(offset, offset + limit);

      return {
        data: paginatedData,
        count: total,
        page,
        totalPages: Math.ceil(total / limit)
      };
    } catch (error) {
      console.error('Error fetching memos:', error);
      return { data: [], count: 0, page, totalPages: 0 };
    }
  }

  async getMemoById(id: string): Promise<ApiResponse<Memo>> {
    try {
      const memo = await this.storage.get('memos', id);
      if (!memo) {
        return { data: null as any, error: 'Memo not found' };
      }
      return { data: memo };
    } catch (error) {
      console.error('Error fetching memo by ID:', error);
      return { data: null as any, error: 'Failed to fetch memo' };
    }
  }

  async createMemo(memo: Omit<Memo, 'id' | 'created_at'>): Promise<ApiResponse<Memo>> {
    try {
      const newMemo: Memo = {
        ...memo,
        id: this.generateId(),
        created_at: new Date().toISOString()
      };
      
      await this.storage.add('memos', newMemo);
      return { data: newMemo };
    } catch (error) {
      console.error('Error creating memo:', error);
      return { data: null as any, error: 'Failed to create memo' };
    }
  }

  async updateMemo(id: string, memo: Partial<Memo>): Promise<ApiResponse<Memo>> {
    try {
      const existing = await this.storage.get('memos', id);
      if (!existing) {
        return { data: null as any, error: 'Memo not found' };
      }

      const updated = { ...existing, ...memo, updated_at: new Date().toISOString() };
      await this.storage.put('memos', updated);
      return { data: updated };
    } catch (error) {
      console.error('Error updating memo:', error);
      return { data: null as any, error: 'Failed to update memo' };
    }
  }

  async deleteMemo(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.storage.delete('memos', id);
      return { data: result };
    } catch (error) {
      console.error('Error deleting memo:', error);
      return { data: false, error: 'Failed to delete memo' };
    }
  }

  // Test Request operations
  async getTestRequests(options: QueryOptions = {}): Promise<PaginatedResponse<TestRequest>> {
    const { page = 1, limit = 10 } = options;
    const offset = (page - 1) * limit;

    try {
      const testRequests = await this.storage.getAll('test_requests');
      const total = testRequests.length;
      const paginatedData = testRequests.slice(offset, offset + limit);

      return {
        data: paginatedData,
        count: total,
        page,
        totalPages: Math.ceil(total / limit)
      };
    } catch (error) {
      console.error('Error fetching test requests:', error);
      return { data: [], count: 0, page, totalPages: 0 };
    }
  }

  async getTestRequestById(id: string): Promise<ApiResponse<TestRequest>> {
    try {
      const testRequest = await this.storage.get('test_requests', id);
      if (!testRequest) {
        return { data: null as any, error: 'Test request not found' };
      }
      return { data: testRequest };
    } catch (error) {
      console.error('Error fetching test request by ID:', error);
      return { data: null as any, error: 'Failed to fetch test request' };
    }
  }

  async createTestRequest(testRequest: Omit<TestRequest, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestRequest>> {
    try {
      const newTestRequest: TestRequest = {
        ...testRequest,
        id: this.generateId(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      await this.storage.add('test_requests', newTestRequest);
      return { data: newTestRequest };
    } catch (error) {
      console.error('Error creating test request:', error);
      return { data: null as any, error: 'Failed to create test request' };
    }
  }

  async updateTestRequest(id: string, testRequest: Partial<TestRequest>): Promise<ApiResponse<TestRequest>> {
    try {
      const existing = await this.storage.get('test_requests', id);
      if (!existing) {
        return { data: null as any, error: 'Test request not found' };
      }

      const updated = { ...existing, ...testRequest, updated_at: new Date().toISOString() };
      await this.storage.put('test_requests', updated);
      return { data: updated };
    } catch (error) {
      console.error('Error updating test request:', error);
      return { data: null as any, error: 'Failed to update test request' };
    }
  }

  async deleteTestRequest(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.storage.delete('test_requests', id);
      return { data: result };
    } catch (error) {
      console.error('Error deleting test request:', error);
      return { data: false, error: 'Failed to delete test request' };
    }
  }

  // User Profile operations  
  async getUserProfiles(options: QueryOptions = {}): Promise<PaginatedResponse<UserProfile>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getUserProfileById(id: string): Promise<ApiResponse<UserProfile>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async createUserProfile(profile: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserProfile>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async updateUserProfile(id: string, profile: Partial<UserProfile>): Promise<ApiResponse<UserProfile>> {
    return { data: null as any, error: 'Not implemented' };
  }

  async deleteUserProfile(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not implemented' };
  }

  // User Role operations
  async getUserRoles(): Promise<ApiResponse<UserRole[]>> {
    try {
      const roles = await this.storage.getAll('user_roles');
      return { data: roles };
    } catch (error) {
      console.error('Error fetching user roles:', error);
      return { data: [], error: 'Failed to fetch user roles' };
    }
  }

  async getUserRoleById(id: string): Promise<ApiResponse<UserRole>> {
    try {
      const role = await this.storage.get('user_roles', id);
      if (!role) {
        return { data: null as any, error: 'User role not found' };
      }
      return { data: role };
    } catch (error) {
      console.error('Error fetching user role by ID:', error);
      return { data: null as any, error: 'Failed to fetch user role' };
    }
  }

  async createUserRole(role: Omit<UserRole, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<UserRole>> {
    try {
      const newRole: UserRole = {
        ...role,
        id: this.generateId(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      await this.storage.add('user_roles', newRole);
      return { data: newRole };
    } catch (error) {
      console.error('Error creating user role:', error);
      return { data: null as any, error: 'Failed to create user role' };
    }
  }

  async updateUserRole(id: string, role: Partial<UserRole>): Promise<ApiResponse<UserRole>> {
    try {
      const existing = await this.storage.get('user_roles', id);
      if (!existing) {
        return { data: null as any, error: 'User role not found' };
      }

      const updated = { ...existing, ...role, updated_at: new Date().toISOString() };
      await this.storage.put('user_roles', updated);
      return { data: updated };
    } catch (error) {
      console.error('Error updating user role:', error);
      return { data: null as any, error: 'Failed to update user role' };
    }
  }

  async deleteUserRole(id: string): Promise<ApiResponse<boolean>> {
    try {
      const result = await this.storage.delete('user_roles', id);
      return { data: result };
    } catch (error) {
      console.error('Error deleting user role:', error);
      return { data: false, error: 'Failed to delete user role' };
    }
  }

  // Analytics operations
  async getAnalyticsData(): Promise<ApiResponse<AnalyticsData>> {
    try {
      const testRequests = await this.storage.getAll('test_requests');

      const totalTests = testRequests.length;
      const completedTests = testRequests.filter(t => t.status === 'completed').length;
      const pendingTests = testRequests.filter(t => t.status === 'pending').length;

      return {
        data: {
          totalTests,
          completedTests,
          pendingTests,
          activeUsers: 1,
          completionRate: totalTests > 0 ? (completedTests / totalTests) * 100 : 0
        }
      };
    } catch (error) {
      console.error('Error fetching analytics data:', error);
      return {
        data: {
          totalTests: 0,
          completedTests: 0,
          pendingTests: 0,
          activeUsers: 0,
          completionRate: 0
        }
      };
    }
  }

  async getMonthlyTestData(): Promise<ApiResponse<any[]>> {
    const monthlyData = [
      { month: "Jan", tests: 45, completed: 42, pending: 3 },
      { month: "Feb", tests: 52, completed: 48, pending: 4 },
      { month: "Mar", tests: 38, completed: 36, pending: 2 },
      { month: "Apr", tests: 67, completed: 63, pending: 4 },
      { month: "May", tests: 71, completed: 68, pending: 3 },
      { month: "Jun", tests: 58, completed: 55, pending: 3 }
    ];
    return { data: monthlyData };
  }

  async getTestTypeDistribution(): Promise<ApiResponse<any[]>> {
    const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe'];
    const distribution = [
      { name: "Aggregates", value: 40, color: colors[0] },
      { name: "Blocks", value: 25, color: colors[1] },
      { name: "Pavings", value: 20, color: colors[2] },
      { name: "Concrete", value: 10, color: colors[3] },
      { name: "Railway Ballast", value: 5, color: colors[4] }
    ];
    return { data: distribution };
  }

  async getCurrentUser(): Promise<ApiResponse<UserProfile | null>> {
    return {
      data: {
        id: 'profile_admin',
        user_id: 'admin_user',
        name: 'System Administrator',
        email: 'admin@lab.local',
        role: 'admin',
        department: 'Administration',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    };
  }

  // Module operations - fallback to mock data for browser
  async getModules(): Promise<PaginatedResponse<Module>> {
    return {
      data: [],
      count: 0,
      page: 1,
      totalPages: 1
    };
  }

  async getModuleById(id: string): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Module not found' };
  }

  async installModule(moduleData: any): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Module installation not supported in browser mode' };
  }

  async uninstallModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Module uninstallation not supported in browser mode' };
  }

  async enableModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Module management not supported in browser mode' };
  }

  async disableModule(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Module management not supported in browser mode' };
  }

  async updateModule(id: string, updates: Partial<Module>): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Module updates not supported in browser mode' };
  }

  async getModuleInstances(moduleId?: string): Promise<ApiResponse<ModuleInstance[]>> {
    return { data: [] };
  }

  async createModuleInstance(instance: Omit<ModuleInstance, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ModuleInstance>> {
    return { data: null as any, error: 'Module instances not supported in browser mode' };
  }

  async updateModuleInstance(id: string, updates: Partial<ModuleInstance>): Promise<ApiResponse<ModuleInstance>> {
    return { data: null as any, error: 'Module instances not supported in browser mode' };
  }

  async deleteModuleInstance(id: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Module instances not supported in browser mode' };
  }

  async getMarketplaceModules(): Promise<PaginatedResponse<ModuleMarketplace>> {
    // Return some mock marketplace modules for demo
    const mockModules: ModuleMarketplace[] = [
      {
        id: 'mock-cube-test',
        name: 'Advanced Cube Test Module',
        description: 'Enhanced cube testing with AI-powered analysis',
        version: '2.0.0',
        author: 'Laboratory Systems Inc.',
        downloads: 1250,
        rating: 4.8,
        category: 'testing',
        price: 0,
        screenshots: [],
        documentation_url: 'https://docs.example.com/cube-test',
        source_url: 'https://github.com/example/cube-test'
      },
      {
        id: 'mock-analytics',
        name: 'Advanced Analytics Dashboard',
        description: 'Real-time analytics and reporting dashboard',
        version: '1.5.0',
        author: 'Analytics Pro',
        downloads: 890,
        rating: 4.6,
        category: 'dashboard',
        price: 99,
        screenshots: [],
        documentation_url: 'https://docs.example.com/analytics'
      }
    ];

    return {
      data: mockModules,
      count: mockModules.length,
      page: 1,
      totalPages: 1
    };
  }

  async downloadModule(marketplaceId: string): Promise<ApiResponse<any>> {
    return { data: null, error: 'Module download not supported in browser mode' };
  }

  async exportModule(id: string): Promise<ApiResponse<Blob>> {
    return { data: null as any, error: 'Module export not supported in browser mode' };
  }

  async importModule(file: File): Promise<ApiResponse<Module>> {
    return { data: null as any, error: 'Module import not supported in browser mode' };
  }

  // Phase 6: Advanced Data Features
  async getValidationRules(options?: QueryOptions): Promise<PaginatedResponse<ValidationRule>> {
    try {
      const rules = JSON.parse(localStorage.getItem('validation_rules') || '[]');
      return { 
        data: rules, 
        count: rules.length, 
        page: options?.page || 1, 
        totalPages: Math.ceil(rules.length / (options?.limit || 10))
      };
    } catch (error) {
      return { data: [], count: 0, page: 1, totalPages: 0 };
    }
  }

  async getValidationRuleById(id: string): Promise<ApiResponse<ValidationRule>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async createValidationRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ValidationRule>> {
    try {
      const newRule: ValidationRule = {
        ...rule,
        id: `rule_${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      const rules = JSON.parse(localStorage.getItem('validation_rules') || '[]');
      rules.push(newRule);
      localStorage.setItem('validation_rules', JSON.stringify(rules));
      
      return { data: newRule };
    } catch (error) {
      return { data: null as any, error: 'Failed to create validation rule' };
    }
  }

  async updateValidationRule(id: string, rule: Partial<ValidationRule>): Promise<ApiResponse<ValidationRule>> {
    try {
      const rules = JSON.parse(localStorage.getItem('validation_rules') || '[]');
      const index = rules.findIndex((r: any) => r.id === id);
      
      if (index === -1) {
        return { data: null as any, error: 'Validation rule not found' };
      }
      
      rules[index] = { ...rules[index], ...rule, updated_at: new Date().toISOString() };
      localStorage.setItem('validation_rules', JSON.stringify(rules));
      
      return { data: rules[index] };
    } catch (error) {
      return { data: null as any, error: 'Failed to update validation rule' };
    }
  }

  async deleteValidationRule(id: string): Promise<ApiResponse<boolean>> {
    try {
      const rules = JSON.parse(localStorage.getItem('validation_rules') || '[]');
      const filtered = rules.filter((r: any) => r.id !== id);
      localStorage.setItem('validation_rules', JSON.stringify(filtered));
      
      return { data: filtered.length !== rules.length };
    } catch (error) {
      return { data: false, error: 'Failed to delete validation rule' };
    }
  }

  async validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ApiResponse<ValidationResult[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async getValidationResults(options?: QueryOptions): Promise<PaginatedResponse<ValidationResult>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async getTestSchedules(options?: QueryOptions): Promise<PaginatedResponse<TestSchedule>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createTestSchedule(schedule: Omit<TestSchedule, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<TestSchedule>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async generateSchedulesFromTemplate(templateId: string, sampleIds: string[]): Promise<ApiResponse<TestSchedule[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async getScheduleTemplates(): Promise<ApiResponse<ScheduleTemplate[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async createScheduleTemplate(template: Omit<ScheduleTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async updateScheduleTemplate(id: string, template: Partial<ScheduleTemplate>): Promise<ApiResponse<ScheduleTemplate>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async getTableRelationships(tableName?: string): Promise<ApiResponse<TableRelationship[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async getRelatedRecords(tableName: string, recordId: string, relationship: string): Promise<ApiResponse<any[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async getNavigationPath(tableName: string, recordId: string): Promise<ApiResponse<NavigationPath[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async getDataVersions(tableName: string, recordId: string): Promise<ApiResponse<DataVersion[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  async createDataVersion(version: Omit<DataVersion, 'id' | 'created_at'>): Promise<ApiResponse<DataVersion>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async compareVersions(versionId1: string, versionId2: string): Promise<ApiResponse<any>> {
    return { data: null, error: 'Not supported in browser' };
  }

  async rollbackToVersion(versionId: string): Promise<ApiResponse<boolean>> {
    return { data: false, error: 'Not supported in browser' };
  }

  async getChangeRequests(options?: QueryOptions): Promise<PaginatedResponse<ChangeRequest>> {
    return { data: [], count: 0, page: 1, totalPages: 0 };
  }

  async createChangeRequest(request: Omit<ChangeRequest, 'id' | 'requested_at'>): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async approveChangeRequest(requestId: string, comments?: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async rejectChangeRequest(requestId: string, comments: string): Promise<ApiResponse<ChangeRequest>> {
    return { data: null as any, error: 'Not supported in browser' };
  }

  async getApprovalWorkflows(): Promise<ApiResponse<ApprovalWorkflow[]>> {
    return { data: [], error: 'Not supported in browser' };
  }

  // Reference Dataset operations
  async uploadReferenceDataset(tableName: string, csvData: any[], replaceExisting: boolean = false): Promise<{ success: boolean; rowsInserted: number; error?: string }> {
    try {
      // Get existing data
      const existing = await this.storage.getAll(`reference_${tableName}`) || [];
      
      if (replaceExisting) {
        // Clear existing data
        for (const record of existing) {
          await this.storage.delete(`reference_${tableName}`, record.id);
        }
      }

      // Insert new data
      let insertedCount = 0;
      for (const record of csvData) {
        try {
          await this.storage.add(`reference_${tableName}`, record);
          insertedCount++;
        } catch (error) {
          if (!replaceExisting) {
            // Try update if add fails
            await this.storage.put(`reference_${tableName}`, record);
            insertedCount++;
          }
        }
      }

      return { success: true, rowsInserted: insertedCount };
    } catch (error) {
      console.error('Error uploading reference dataset:', error);
      return { success: false, rowsInserted: 0, error: error instanceof Error ? error.message : 'Upload failed' };
    }
  }

  async getReferenceData(tableName: string, activeOnly?: boolean): Promise<any[]> {
    return [];
  }

  async getFilteredSamplingPlaces(productType: string): Promise<any[]> {
    return [];
  }

  // Required interface methods
  async createAuditLog(entry: any): Promise<ApiResponse<any>> { return { data: entry }; }
  async getAuditLogs(filters?: any): Promise<any[]> { return []; }
  async getTables(): Promise<string[]> { return ['memos', 'test_requests', 'user_profiles']; }
  async getTableSchema(tableName: string): Promise<any> { return null; }
  async executeSQL(sql: string): Promise<any> { return {}; }
  async createDataRelationship(relationship: any): Promise<ApiResponse<any>> { return { data: relationship }; }
  async deleteDataRelationship(id: string): Promise<ApiResponse<boolean>> { return { data: true }; }
  async getDataRelationships(): Promise<any[]> { return []; }
  async getUserProfile(id: string): Promise<ApiResponse<UserProfile>> { return { data: null as any, error: 'Not implemented' }; }
  async createValidationResult(result: any): Promise<ApiResponse<any>> { return { data: result }; }
}

export { BrowserDataService };