// Enhanced File Upload Service for Reports
export interface UploadedFile {
  id: string;
  originalName: string;
  storedPath: string;
  fileType: string;
  fileSize: number;
  uploadedBy: string;
  uploadedAt: string;
  category: 'template' | 'attachment' | 'report';
  metadata?: any;
}

export interface FileUploadProgress {
  fileName: string;
  progress: number;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  error?: string;
}

export class FileUploadService {
  private static readonly UPLOAD_DIR = '/uploads';
  private static readonly MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
  private static readonly ALLOWED_TYPES = {
    template: ['.docx', '.xlsx', '.pdf', '.json'],
    attachment: ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.jpg', '.jpeg', '.png', '.gif'],
    report: ['.pdf', '.docx', '.xlsx']
  };

  // Initialize upload directories
  static async initializeDirectories(): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const directories = [
        `${this.UPLOAD_DIR}/templates`,
        `${this.UPLOAD_DIR}/attachments`,
        `${this.UPLOAD_DIR}/reports`,
        `${this.UPLOAD_DIR}/temp`
      ];

      for (const dir of directories) {
        // Create directory if it doesn't exist
        await this.ensureDirectoryExists(dir);
      }

      return true;
    } catch (error) {
      console.error('Failed to initialize upload directories:', error);
      return false;
    }
  }

  // Upload file with progress tracking
  static async uploadFile(
    file: File,
    category: 'template' | 'attachment' | 'report',
    uploadedBy: string,
    onProgress?: (progress: FileUploadProgress) => void
  ): Promise<UploadedFile | null> {
    try {
      // Validate file
      const validation = this.validateFile(file, category);
      if (!validation.isValid) {
        throw new Error(validation.error);
      }

      onProgress?.({
        fileName: file.name,
        progress: 0,
        status: 'uploading'
      });

      // Generate unique file path
      const fileExtension = this.getFileExtension(file.name);
      const fileName = `${crypto.randomUUID()}${fileExtension}`;
      const storedPath = `${this.UPLOAD_DIR}/${category}s/${fileName}`;

      onProgress?.({
        fileName: file.name,
        progress: 25,
        status: 'uploading'
      });

      // Read file as array buffer
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);

      onProgress?.({
        fileName: file.name,
        progress: 50,
        status: 'processing'
      });

      // Save file using Electron API
      if (window.electronAPI?.saveFile) {
        const saveResult = await window.electronAPI.saveFile(storedPath, uint8Array);
        if (!saveResult.success) {
          throw new Error(saveResult.error || 'Failed to save file');
        }
      } else {
        // Fallback for browser environment - use IndexedDB
        await this.saveFileToIndexedDB(storedPath, uint8Array);
      }

      onProgress?.({
        fileName: file.name,
        progress: 75,
        status: 'processing'
      });

      // Extract metadata based on file type
      const metadata = await this.extractFileMetadata(file, uint8Array);

      // Save file record to database
      const fileRecord: UploadedFile = {
        id: crypto.randomUUID(),
        originalName: file.name,
        storedPath,
        fileType: file.type || this.getMimeTypeFromExtension(fileExtension),
        fileSize: file.size,
        uploadedBy,
        uploadedAt: new Date().toISOString(),
        category,
        metadata
      };

      // Save to enhanced reports service
      const { EnhancedReportsService } = await import('../database/enhancedReportsService');
      const savedId = await EnhancedReportsService.saveUploadedFile(
        fileRecord.originalName,
        fileRecord.storedPath,
        fileRecord.fileType,
        fileRecord.fileSize,
        fileRecord.uploadedBy,
        fileRecord.category
      );

      if (!savedId) {
        throw new Error('Failed to save file record to database');
      }

      fileRecord.id = savedId;

      onProgress?.({
        fileName: file.name,
        progress: 100,
        status: 'completed'
      });

      return fileRecord;
    } catch (error) {
      onProgress?.({
        fileName: file.name,
        progress: 0,
        status: 'error',
        error: error instanceof Error ? error.message : 'Upload failed'
      });
      
      console.error('File upload failed:', error);
      return null;
    }
  }

  // Upload multiple files
  static async uploadMultipleFiles(
    files: File[],
    category: 'template' | 'attachment' | 'report',
    uploadedBy: string,
    onProgress?: (progress: FileUploadProgress[]) => void
  ): Promise<UploadedFile[]> {
    const results: UploadedFile[] = [];
    const progressArray: FileUploadProgress[] = files.map(file => ({
      fileName: file.name,
      progress: 0,
      status: 'uploading' as const
    }));

    const updateProgress = (index: number, progress: FileUploadProgress) => {
      progressArray[index] = progress;
      onProgress?.(progressArray);
    };

    // Upload files in parallel with limited concurrency
    const BATCH_SIZE = 3;
    
    for (let i = 0; i < files.length; i += BATCH_SIZE) {
      const batch = files.slice(i, i + BATCH_SIZE);
      
      const batchPromises = batch.map((file, batchIndex) => {
        const fileIndex = i + batchIndex;
        return this.uploadFile(
          file,
          category,
          uploadedBy,
          (progress) => updateProgress(fileIndex, progress)
        );
      });

      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults.filter(Boolean) as UploadedFile[]);
    }

    return results;
  }

  // Get uploaded file
  static async getUploadedFile(fileId: string): Promise<UploadedFile | null> {
    if (!window.electronAPI) return null;

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM uploaded_files WHERE id = ?`,
        [fileId]
      );

      return result.success && result.data.length > 0 ? result.data[0] : null;
    } catch (error) {
      console.error('Failed to get uploaded file:', error);
      return null;
    }
  }

  // Get file content
  static async getFileContent(filePath: string): Promise<Uint8Array | null> {
    try {
      if (window.electronAPI?.readFile) {
        const result = await window.electronAPI.readFile(filePath);
        return result.success ? result.data : null;
      } else {
        // Fallback for browser environment
        return await this.getFileFromIndexedDB(filePath);
      }
    } catch (error) {
      console.error('Failed to get file content:', error);
      return null;
    }
  }

  // Delete uploaded file
  static async deleteFile(fileId: string): Promise<boolean> {
    try {
      // Get file record first
      const fileRecord = await this.getUploadedFile(fileId);
      if (!fileRecord) return false;

      // Delete physical file
      if (window.electronAPI?.deleteFile) {
        await window.electronAPI.deleteFile(fileRecord.storedPath);
      } else {
        await this.deleteFileFromIndexedDB(fileRecord.storedPath);
      }

      // Delete database record
      const result = await window.electronAPI.dbRun(
        `DELETE FROM uploaded_files WHERE id = ?`,
        [fileId]
      );

      return result.success;
    } catch (error) {
      console.error('Failed to delete file:', error);
      return false;
    }
  }

  // Validate file
  private static validateFile(file: File, category: 'template' | 'attachment' | 'report'): { isValid: boolean; error?: string } {
    // Check file size
    if (file.size > this.MAX_FILE_SIZE) {
      return {
        isValid: false,
        error: `File size exceeds maximum limit of ${this.MAX_FILE_SIZE / (1024 * 1024)}MB`
      };
    }

    // Check file type
    const extension = this.getFileExtension(file.name).toLowerCase();
    const allowedExtensions = this.ALLOWED_TYPES[category];
    
    if (!allowedExtensions.includes(extension)) {
      return {
        isValid: false,
        error: `File type ${extension} is not allowed for ${category}. Allowed types: ${allowedExtensions.join(', ')}`
      };
    }

    return { isValid: true };
  }

  // Extract file metadata
  private static async extractFileMetadata(file: File, content: Uint8Array): Promise<any> {
    const metadata: any = {
      originalSize: file.size,
      mimeType: file.type,
      lastModified: file.lastModified
    };

    const extension = this.getFileExtension(file.name).toLowerCase();

    try {
      switch (extension) {
        case '.pdf':
          metadata.pages = await this.extractPDFPageCount(content);
          break;
        case '.docx':
          metadata.wordCount = await this.extractWordCount(content);
          break;
        case '.xlsx':
          metadata.worksheets = await this.extractWorksheetCount(content);
          break;
        case '.jpg':
        case '.jpeg':
        case '.png':
        case '.gif':
          metadata.dimensions = await this.extractImageDimensions(file);
          break;
      }
    } catch (error) {
      console.warn('Failed to extract metadata:', error);
    }

    return metadata;
  }

  // Helper methods
  private static getFileExtension(fileName: string): string {
    const lastDot = fileName.lastIndexOf('.');
    return lastDot !== -1 ? fileName.substring(lastDot) : '';
  }

  private static getMimeTypeFromExtension(extension: string): string {
    const mimeMap: Record<string, string> = {
      '.pdf': 'application/pdf',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.doc': 'application/msword',
      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      '.xls': 'application/vnd.ms-excel',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
      '.json': 'application/json'
    };

    return mimeMap[extension.toLowerCase()] || 'application/octet-stream';
  }

  private static async ensureDirectoryExists(path: string): Promise<void> {
    if (window.electronAPI?.ensureDirectory) {
      await window.electronAPI.ensureDirectory(path);
    }
  }

  // IndexedDB fallback methods for browser environment
  private static async saveFileToIndexedDB(path: string, data: Uint8Array): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('ReportFiles', 1);
      
      request.onerror = () => reject(request.error);
      
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files');
        }
      };
      
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['files'], 'readwrite');
        const store = transaction.objectStore('files');
        
        store.put(data, path);
        
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      };
    });
  }

  private static async getFileFromIndexedDB(path: string): Promise<Uint8Array | null> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('ReportFiles', 1);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['files'], 'readonly');
        const store = transaction.objectStore('files');
        
        const getRequest = store.get(path);
        
        getRequest.onsuccess = () => {
          resolve(getRequest.result || null);
        };
        
        getRequest.onerror = () => reject(getRequest.error);
      };
    });
  }

  private static async deleteFileFromIndexedDB(path: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('ReportFiles', 1);
      
      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['files'], 'readwrite');
        const store = transaction.objectStore('files');
        
        store.delete(path);
        
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
      };
    });
  }

  // File analysis methods
  private static async extractPDFPageCount(content: Uint8Array): Promise<number> {
    // Basic PDF page count extraction - simplified
    const text = new TextDecoder().decode(content);
    const matches = text.match(/\/Count\s+(\d+)/g);
    if (matches) {
      const counts = matches.map(match => parseInt(match.replace('/Count', '').trim()));
      return Math.max(...counts);
    }
    return 1;
  }

  private static async extractWordCount(content: Uint8Array): Promise<number> {
    // Simplified word count for DOCX - would need proper XML parsing in production
    return Math.floor(content.length / 6); // Rough estimate
  }

  private static async extractWorksheetCount(content: Uint8Array): Promise<number> {
    // Simplified worksheet count for XLSX
    const text = new TextDecoder().decode(content);
    const matches = text.match(/sheet\d+/gi);
    return matches ? matches.length : 1;
  }

  private static async extractImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      
      img.onload = () => {
        resolve({ width: img.naturalWidth, height: img.naturalHeight });
        URL.revokeObjectURL(url);
      };
      
      img.onerror = () => {
        resolve({ width: 0, height: 0 });
        URL.revokeObjectURL(url);
      };
      
      img.src = url;
    });
  }
}