export interface ThemeColors {
  primary: string;
  'primary-foreground': string;
  secondary: string;
  'secondary-foreground': string;
  accent: string;
  'accent-foreground': string;
  destructive: string;
  'destructive-foreground': string;
  muted: string;
  'muted-foreground': string;
  card: string;
  'card-foreground': string;
  popover: string;
  'popover-foreground': string;
  border: string;
  input: string;
  background: string;
  foreground: string;
  radius: string;
}

export interface CustomTheme {
  id: string;
  name: string;
  description?: string;
  colors: ThemeColors;
  isDark: boolean;
  created_at: string;
  created_by: string;
}

export class ThemePersistenceService {
  private isElectron(): boolean {
    return window.electronAPI !== undefined;
  }

  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  }

  private async executeRun(sql: string, params: any[] = []): Promise<any> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  }

  // Initialize themes table if needed
  async initializeThemesTable(): Promise<void> {
    try {
      const createTableSQL = `
        CREATE TABLE IF NOT EXISTS custom_themes (
          id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
          name TEXT NOT NULL,
          description TEXT,
          colors TEXT NOT NULL,
          is_dark BOOLEAN DEFAULT FALSE,
          is_active BOOLEAN DEFAULT FALSE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          created_by TEXT DEFAULT 'current_user'
        )
      `;
      
      await this.executeRun(createTableSQL);

      // Create default themes if none exist
      const themes = await this.executeQuery('SELECT COUNT(*) as count FROM custom_themes');
      if ((themes[0] as any).count === 0) {
        await this.createDefaultThemes();
      }
    } catch (error) {
      console.error('Error initializing themes table:', error);
    }
  }

  // Create default themes
  private async createDefaultThemes(): Promise<void> {
    const defaultLight: Omit<CustomTheme, 'id' | 'created_at' | 'created_by'> = {
      name: 'Default Light',
      description: 'Default light theme',
      isDark: false,
      colors: {
        primary: '222.2 84% 4.9%',
        'primary-foreground': '210 40% 98%',
        secondary: '210 40% 96%',
        'secondary-foreground': '222.2 84% 4.9%',
        accent: '210 40% 96%',
        'accent-foreground': '222.2 84% 4.9%',
        destructive: '0 84.2% 60.2%',
        'destructive-foreground': '210 40% 98%',
        muted: '210 40% 96%',
        'muted-foreground': '215.4 16.3% 46.9%',
        card: '0 0% 100%',
        'card-foreground': '222.2 84% 4.9%',
        popover: '0 0% 100%',
        'popover-foreground': '222.2 84% 4.9%',
        border: '214.3 31.8% 91.4%',
        input: '214.3 31.8% 91.4%',
        background: '0 0% 100%',
        foreground: '222.2 84% 4.9%',
        radius: '0.5rem'
      }
    };

    const defaultDark: Omit<CustomTheme, 'id' | 'created_at' | 'created_by'> = {
      name: 'Default Dark',
      description: 'Default dark theme',
      isDark: true,
      colors: {
        primary: '210 40% 98%',
        'primary-foreground': '222.2 84% 4.9%',
        secondary: '222.2 47% 11%',
        'secondary-foreground': '210 40% 98%',
        accent: '222.2 47% 11%',
        'accent-foreground': '210 40% 98%',
        destructive: '0 62.8% 30.6%',
        'destructive-foreground': '210 40% 98%',
        muted: '222.2 47% 11%',
        'muted-foreground': '215 20.2% 65.1%',
        card: '222.2 84% 4.9%',
        'card-foreground': '210 40% 98%',
        popover: '222.2 84% 4.9%',
        'popover-foreground': '210 40% 98%',
        border: '222.2 47% 11%',
        input: '222.2 47% 11%',
        background: '222.2 84% 4.9%',
        foreground: '210 40% 98%',
        radius: '0.5rem'
      }
    };

    await this.saveTheme(defaultLight);
    await this.saveTheme(defaultDark);
    
    // Set light theme as active by default
    await this.activateTheme((await this.getThemeByName('Default Light'))?.id || '');
  }

  // Save theme to database
  async saveTheme(theme: Omit<CustomTheme, 'id' | 'created_at' | 'created_by'>): Promise<string> {
    try {
      const themeId = crypto.randomUUID();
      
      await this.executeRun(
        `INSERT INTO custom_themes (id, name, description, colors, is_dark, created_at, updated_at, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          themeId,
          theme.name,
          theme.description || '',
          JSON.stringify(theme.colors),
          theme.isDark,
          new Date().toISOString(),
          new Date().toISOString(),
          'current_user'
        ]
      );

      return themeId;
    } catch (error) {
      console.error('Error saving theme:', error);
      throw error;
    }
  }

  // Get all themes
  async getAllThemes(): Promise<CustomTheme[]> {
    try {
      const themes = await this.executeQuery('SELECT * FROM custom_themes ORDER BY created_at DESC');
      
      return themes.map((theme: any) => ({
        id: theme.id,
        name: theme.name,
        description: theme.description,
        colors: JSON.parse(theme.colors),
        isDark: theme.is_dark,
        created_at: theme.created_at,
        created_by: theme.created_by
      }));
    } catch (error) {
      console.error('Error loading themes:', error);
      return [];
    }
  }

  // Get active theme
  async getActiveTheme(): Promise<CustomTheme | null> {
    try {
      const themes = await this.executeQuery('SELECT * FROM custom_themes WHERE is_active = 1 LIMIT 1');
      
      if (themes.length === 0) return null;
      
      const theme = themes[0] as any;
      return {
        id: theme.id,
        name: theme.name,
        description: theme.description,
        colors: JSON.parse(theme.colors),
        isDark: theme.is_dark,
        created_at: theme.created_at,
        created_by: theme.created_by
      };
    } catch (error) {
      console.error('Error getting active theme:', error);
      return null;
    }
  }

  // Get theme by name
  async getThemeByName(name: string): Promise<CustomTheme | null> {
    try {
      const themes = await this.executeQuery('SELECT * FROM custom_themes WHERE name = ? LIMIT 1', [name]);
      
      if (themes.length === 0) return null;
      
      const theme = themes[0] as any;
      return {
        id: theme.id,
        name: theme.name,
        description: theme.description,
        colors: JSON.parse(theme.colors),
        isDark: theme.is_dark,
        created_at: theme.created_at,
        created_by: theme.created_by
      };
    } catch (error) {
      console.error('Error getting theme by name:', error);
      return null;
    }
  }

  // Activate theme
  async activateTheme(themeId: string): Promise<void> {
    try {
      // Deactivate all themes
      await this.executeRun('UPDATE custom_themes SET is_active = 0');
      
      // Activate the selected theme
      await this.executeRun('UPDATE custom_themes SET is_active = 1 WHERE id = ?', [themeId]);
      
      // Apply theme to DOM
      await this.applyTheme(themeId);
    } catch (error) {
      console.error('Error activating theme:', error);
      throw error;
    }
  }

  // Apply theme to DOM
  async applyTheme(themeId: string): Promise<void> {
    try {
      const themes = await this.executeQuery('SELECT * FROM custom_themes WHERE id = ?', [themeId]);
      
      if (themes.length === 0) return;
      
      const theme = themes[0] as any;
      const colors = JSON.parse(theme.colors);
      
      // Apply CSS variables to root
      const root = document.documentElement;
      
      Object.entries(colors).forEach(([key, value]) => {
        root.style.setProperty(`--${key}`, value as string);
      });
      
      // Toggle dark mode class
      if (theme.is_dark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
      
      // Store active theme in localStorage for persistence
      localStorage.setItem('activeThemeId', themeId);
      localStorage.setItem('activeTheme', JSON.stringify({
        id: theme.id,
        name: theme.name,
        isDark: theme.is_dark,
        colors
      }));
    } catch (error) {
      console.error('Error applying theme:', error);
    }
  }

  // Load theme from localStorage on app start
  async loadStoredTheme(): Promise<void> {
    try {
      const storedThemeId = localStorage.getItem('activeThemeId');
      
      if (storedThemeId) {
        await this.applyTheme(storedThemeId);
      } else {
        // Apply default theme
        const defaultTheme = await this.getThemeByName('Default Light');
        if (defaultTheme) {
          await this.activateTheme(defaultTheme.id);
        }
      }
    } catch (error) {
      console.error('Error loading stored theme:', error);
    }
  }

  // Update theme
  async updateTheme(themeId: string, updates: Partial<Omit<CustomTheme, 'id' | 'created_at' | 'created_by'>>): Promise<void> {
    try {
      const updateFields: string[] = [];
      const values: any[] = [];
      
      if (updates.name !== undefined) {
        updateFields.push('name = ?');
        values.push(updates.name);
      }
      
      if (updates.description !== undefined) {
        updateFields.push('description = ?');
        values.push(updates.description);
      }
      
      if (updates.colors !== undefined) {
        updateFields.push('colors = ?');
        values.push(JSON.stringify(updates.colors));
      }
      
      if (updates.isDark !== undefined) {
        updateFields.push('is_dark = ?');
        values.push(updates.isDark);
      }
      
      if (updateFields.length === 0) return;
      
      updateFields.push('updated_at = ?');
      values.push(new Date().toISOString());
      values.push(themeId);
      
      await this.executeRun(
        `UPDATE custom_themes SET ${updateFields.join(', ')} WHERE id = ?`,
        values
      );
      
      // If this is the active theme, reapply it
      const activeTheme = await this.getActiveTheme();
      if (activeTheme && activeTheme.id === themeId) {
        await this.applyTheme(themeId);
      }
    } catch (error) {
      console.error('Error updating theme:', error);
      throw error;
    }
  }

  // Delete theme
  async deleteTheme(themeId: string): Promise<void> {
    try {
      // Check if this is the active theme
      const activeTheme = await this.getActiveTheme();
      if (activeTheme && activeTheme.id === themeId) {
        // Switch to default theme before deleting
        const defaultTheme = await this.getThemeByName('Default Light');
        if (defaultTheme) {
          await this.activateTheme(defaultTheme.id);
        }
      }
      
      await this.executeRun('DELETE FROM custom_themes WHERE id = ?', [themeId]);
    } catch (error) {
      console.error('Error deleting theme:', error);
      throw error;
    }
  }

  // Export theme as JSON
  async exportTheme(themeId: string): Promise<string> {
    try {
      const themes = await this.executeQuery('SELECT * FROM custom_themes WHERE id = ?', [themeId]);
      
      if (themes.length === 0) {
        throw new Error('Theme not found');
      }
      
      const theme = themes[0] as any;
      const exportData = {
        name: theme.name,
        description: theme.description,
        colors: JSON.parse(theme.colors),
        isDark: theme.is_dark,
        exportedAt: new Date().toISOString(),
        version: '1.0'
      };
      
      return JSON.stringify(exportData, null, 2);
    } catch (error) {
      console.error('Error exporting theme:', error);
      throw error;
    }
  }

  // Import theme from JSON
  async importTheme(themeJson: string): Promise<string> {
    try {
      const themeData = JSON.parse(themeJson);
      
      if (!themeData.name || !themeData.colors) {
        throw new Error('Invalid theme format');
      }
      
      const newTheme: Omit<CustomTheme, 'id' | 'created_at' | 'created_by'> = {
        name: themeData.name,
        description: themeData.description || '',
        colors: themeData.colors,
        isDark: themeData.isDark || false
      };
      
      return await this.saveTheme(newTheme);
    } catch (error) {
      console.error('Error importing theme:', error);
      throw error;
    }
  }
}

export const themePersistenceService = new ThemePersistenceService();