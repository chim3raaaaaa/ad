import React from 'react';
import type { Module, ModuleConfig, ModuleSchema, ModuleComponent, ModuleLogic } from '../api/types';
import { ModuleValidator } from '../validation/moduleValidator';
import type { ModuleMeta } from '@/types';

// Enhanced module registry for managing loaded modules with validation
class ModuleRegistry {
  private modules: Map<string, Module> = new Map();
  private componentCache: Map<string, React.ComponentType<unknown>> = new Map();
  private logicCache: Map<string, unknown> = new Map();
  private appVersion = '1.0.0'; // Should be dynamic from package.json

  // Register a module with validation
  registerModule(module: Module): { success: boolean; errors?: string[] } {
    console.log(`Attempting to register module: ${module.config.name} v${module.config.version}`);
    
    // Validate the complete module
    const moduleValidation = ModuleValidator.validateModule(module);
    if (!moduleValidation.isValid) {
      console.error(`Module validation failed for ${module.id}:`, moduleValidation.errors);
      return { success: false, errors: moduleValidation.errors };
    }

    // Check app version compatibility
    if (!ModuleValidator.validateAppVersion(module.config.minAppVersion, this.appVersion)) {
      const error = `Module requires app version ${module.config.minAppVersion} but current version is ${this.appVersion}`;
      console.error(error);
      return { success: false, errors: [error] };
    }

    // Check dependencies - skip complex validation for now
    const installedModuleIds = Array.from(this.modules.keys());
    const missingDeps = module.config.dependencies.filter(dep => {
      const [depName] = dep.split('@');
      return !installedModuleIds.includes(depName);
    });
    
    if (missingDeps.length > 0) {
      const error = `Missing dependencies: ${missingDeps.join(', ')}`;
      console.error(error);
      return { success: false, errors: [error] };
    }

    this.modules.set(module.id, module);
    console.log(`Module registered successfully: ${module.config.name} v${module.config.version}`);
    return { success: true };
  }

  // Unregister a module
  unregisterModule(moduleId: string): void {
    const module = this.modules.get(moduleId);
    if (module) {
      // Clear component cache for this module
      module.components.forEach(comp => {
        this.componentCache.delete(`${moduleId}:${comp.name}`);
      });
      
      // Clear logic cache
      this.logicCache.delete(moduleId);
      
      this.modules.delete(moduleId);
      console.log(`Module unregistered: ${module.config.name}`);
    }
  }

  // Get all registered modules
  getModules(): Module[] {
    return Array.from(this.modules.values());
  }

  // Get enabled modules only
  getEnabledModules(): Module[] {
    return this.getModules().filter(module => module.enabled);
  }

  // Get module by ID
  getModule(moduleId: string): Module | undefined {
    return this.modules.get(moduleId);
  }

  // Get modules by category
  getModulesByCategory(category: string): Module[] {
    return this.getModules().filter(module => module.config.category === category);
  }

  // Get component from module with type safety
  getComponent(moduleId: string, componentName: string): React.ComponentType<unknown> | undefined {
    const cacheKey = `${moduleId}:${componentName}`;
    
    if (this.componentCache.has(cacheKey)) {
      return this.componentCache.get(cacheKey);
    }

    const module = this.modules.get(moduleId);
    if (!module || !module.enabled) {
      return undefined;
    }

    const component = module.components.find(comp => comp.name === componentName);
    if (!component) {
      return undefined;
    }

    // Safe component creation with proper typing
    const PlaceholderComponent: React.ComponentType<unknown> = (props: Record<string, unknown>) => {
      return React.createElement('div', {
        className: 'p-4 border rounded-lg bg-muted'
      }, [
        React.createElement('h3', { 
          key: 'title',
          className: 'font-semibold' 
        }, component.name),
        React.createElement('p', {
          key: 'module-info',
          className: 'text-sm text-muted-foreground'
        }, `Module: ${module.config.name} v${module.config.version}`),
        React.createElement('p', {
          key: 'type',
          className: 'text-xs mt-2'
        }, `Type: ${component.type}`),
        Object.keys(props).length > 0 && React.createElement('pre', {
          key: 'props',
          className: 'text-xs mt-2 bg-background p-2 rounded'
        }, JSON.stringify(props, null, 2))
      ].filter(Boolean));
    };

    this.componentCache.set(cacheKey, PlaceholderComponent);
    return PlaceholderComponent;
  }

  // Get module logic functions with type safety
  getLogic(moduleId: string): unknown {
    if (this.logicCache.has(moduleId)) {
      return this.logicCache.get(moduleId);
    }

    const module = this.modules.get(moduleId);
    if (!module || !module.enabled) {
      return null;
    }

    // Create logic wrapper
    const logic = {
      calculations: module.logic.calculations || {},
      validations: module.logic.validations || {},
      workflows: module.logic.workflows || [],
      
      // Helper methods with proper typing
      calculate: (formula: string, data: Record<string, unknown>) => {
        try {
          // In a real implementation, you would use a safe expression evaluator
          // For now, return placeholder
          return `Calculated: ${formula} with ${JSON.stringify(data)}`;
        } catch (error) {
          console.error('Calculation error:', error);
          return null;
        }
      },
      
      validate: (rule: string, value: unknown) => {
        try {
          // In a real implementation, you would use a validation library
          // For now, return true
          return { valid: true, message: '' };
        } catch (error) {
          console.error('Validation error:', error);
          return { valid: false, message: 'Validation error' };
        }
      }
    };

    this.logicCache.set(moduleId, logic);
    return logic;
  }

  // Safe module loading with fallback
  registerModuleWithFallback(module: Module): Module {
    const result = this.registerModule(module);
    if (!result.success) {
      const fallbackMeta = ModuleValidator.createSafeFallback(module.id, result.errors?.join('; ') || 'Unknown error');
      const fallbackModule: Module = {
        id: module.id + '-fallback',
        config: {
          name: fallbackMeta.name,
          version: fallbackMeta.version,
          description: fallbackMeta.description,
          author: fallbackMeta.author,
          dependencies: [],
          tags: ['error', 'fallback'],
          category: 'utility',
          permissions: [],
          minAppVersion: '0.0.0'
        },
        schema: fallbackMeta.schema,
        components: [],
        logic: {},
        enabled: false,
        installed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        data_version: '0.0.0'
      };
      
      this.modules.set(fallbackModule.id, fallbackModule);
      console.warn(`Registered fallback module for ${module.id}:`, result.errors);
      return fallbackModule;
    }
    return module;
  }

  // Check if module can be loaded (dependencies, permissions, etc.)
  canLoadModule(module: Module, userPermissions: string[] = []): { canLoad: boolean; reason?: string } {
    // Check if enabled
    if (!module.enabled) {
      return { canLoad: false, reason: 'Module is disabled' };
    }

    // Check permissions
    const hasPermissions = module.config.permissions.every(perm => 
      userPermissions.includes(perm) || userPermissions.includes('*')
    );

    if (!hasPermissions) {
      return { canLoad: false, reason: 'Insufficient permissions' };
    }

    // Check dependencies (simplified)
    const missingDeps = module.config.dependencies.filter(dep => {
      const [depName] = dep.split('@');
      return !this.modules.has(depName);
    });

    if (missingDeps.length > 0) {
      return { canLoad: false, reason: `Missing dependencies: ${missingDeps.join(', ')}` };
    }

    return { canLoad: true };
  }

  // Initialize all modules
  async initializeModules(): Promise<void> {
    const modules = this.getEnabledModules();
    
    for (const module of modules) {
      try {
        // Initialize module schema, components, etc.
        console.log(`Initializing module: ${module.config.name}`);
        
        // In a real implementation, you would:
        // 1. Create database tables from schema
        // 2. Load and register components
        // 3. Initialize module logic
        // 4. Set up routes and permissions
        
      } catch (error) {
        console.error(`Failed to initialize module ${module.config.name}:`, error);
      }
    }
  }

  // Cleanup modules
  cleanup(): void {
    this.componentCache.clear();
    this.logicCache.clear();
    this.modules.clear();
  }
}

// Global module registry instance
export const moduleRegistry = new ModuleRegistry();

// Helper function to create a new module
export function createModule(
  config: ModuleConfig,
  schema: ModuleSchema,
  components: ModuleComponent[] = [],
  logic: ModuleLogic = {}
): Omit<Module, 'id' | 'installed_at' | 'updated_at' | 'data_version'> {
  return {
    config,
    schema,
    components,
    logic,
    enabled: true
  };
}