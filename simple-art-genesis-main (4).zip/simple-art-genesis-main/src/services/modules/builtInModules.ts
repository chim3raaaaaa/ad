// Built-in module definitions
import cubeTestModule from '@/modules/cube-test';
import dashboardModule from '@/modules/dashboard';
import reportsModule from '@/modules/reports';
import { testDataExplorerModule } from '@/modules/test-data-explorer';
import { moduleRegistry } from './moduleRegistry';
import { dashboardSchemaService } from '@/services/database/dashboardSchemaService';
import { realTimeTestCalendarService } from '@/services/database/realTimeTestCalendarService';

// Core module definition
const coreModule = {
  config: {
    name: 'Core System',
    version: '1.0.0',
    description: 'Core laboratory management functionality',
    author: 'System',
    dependencies: [],
    tags: ['core', 'essential'],
    category: 'utility' as const,
    permissions: ['*'],
    minAppVersion: '1.0.0'
  },
  schema: {
    tables: [],
    entities: [],
    relationships: []
  },
  components: [],
  logic: {},
  enabled: true
};

// Initialize built-in modules
export const initializeBuiltInModules = async () => {
  console.log('Initializing built-in modules...');
  
  try {
    // Register core module first
    const core = {
      id: 'core@1.0.0',
      ...coreModule,
      installed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      data_version: '1.0.0'
    };
    moduleRegistry.registerModule(core);

    // Register cube test module
    const cubeModule = {
      id: 'cube-test-1.0.0',
      ...cubeTestModule,
      config: {
        ...cubeTestModule.config,
        dependencies: ['core@1.0.0']
      },
      installed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      data_version: '1.0.0'
    };
    moduleRegistry.registerModule(cubeModule);
    
    // Register dashboard module
    const dashModule = {
      id: 'dashboard-1.0.0',
      ...dashboardModule,
      config: {
        ...dashboardModule.config,
        dependencies: ['core@1.0.0']
      },
      installed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      data_version: '1.0.0'
    };
    moduleRegistry.registerModule(dashModule);
    
    // Register reports module
    const reportModule = {
      id: 'reports-1.0.0',
      ...reportsModule,
      config: {
        ...reportsModule.config,
        dependencies: ['core@1.0.0']
      },
      installed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      data_version: '1.0.0'
    };
    moduleRegistry.registerModule(reportModule);
    
    // Register test data explorer module
    const testExplorerModule = {
      id: 'test-data-explorer-1.0.0',
      ...testDataExplorerModule,
      config: {
        ...testDataExplorerModule.config,
        dependencies: ['core@1.0.0']
      },
      installed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      data_version: '1.0.0'
    };
    moduleRegistry.registerModule(testExplorerModule);
    
    console.log('Built-in modules initialized successfully');
    
    // Initialize database services
    try {
      await dashboardSchemaService.initializeDashboardTables();
      await realTimeTestCalendarService.initialize();
      console.log('Database services initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database services:', error);
    }
    
    // Initialize all modules
    await moduleRegistry.initializeModules();
    
  } catch (error) {
    console.error('Failed to initialize built-in modules:', error);
  }
};

// Export modules for individual access
export {
  coreModule,
  cubeTestModule,
  dashboardModule,
  reportsModule,
  testDataExplorerModule
};