import { z } from 'zod';
import type { ModuleMeta, ModuleConfig, ModuleSchema, ModuleComponent } from '@/types';

// Zod schema for module validation
const ModuleConfigSchema = z.object({
  name: z.string().min(1, 'Module name is required'),
  version: z.string().regex(/^\d+\.\d+\.\d+$/, 'Version must be in semver format (x.y.z)'),
  description: z.string().min(1, 'Description is required'),
  author: z.string().min(1, 'Author is required'),
  license: z.string().optional(),
  dependencies: z.array(z.string()),
  tags: z.array(z.string()),
  category: z.enum(['testing', 'dashboard', 'reports', 'workflow', 'utility']),
  permissions: z.array(z.string()),
  minAppVersion: z.string().regex(/^\d+\.\d+\.\d+$/, 'minAppVersion must be in semver format')
});

const ColumnSchema = z.object({
  name: z.string().min(1, 'Column name is required'),
  type: z.string().min(1, 'Column type is required'),
  required: z.boolean(),
  default: z.unknown().optional(),
  validation: z.string().optional()
});

const RelationshipSchema = z.object({
  type: z.enum(['1:1', '1:N', 'N:N']),
  table: z.string().min(1, 'Related table name is required'),
  foreignKey: z.string().min(1, 'Foreign key is required')
});

const TableSchema = z.object({
  name: z.string().min(1, 'Table name is required'),
  columns: z.array(ColumnSchema).min(1, 'At least one column is required'),
  relationships: z.array(RelationshipSchema).optional()
});

const ViewSchema = z.object({
  name: z.string().min(1, 'View name is required'),
  query: z.string().min(1, 'View query is required')
});

const ModuleSchemaSchema = z.object({
  tables: z.array(TableSchema).min(1, 'At least one table is required'),
  views: z.array(ViewSchema).optional()
});

const ModuleComponentSchema = z.object({
  name: z.string().min(1, 'Component name is required'),
  type: z.enum(['form', 'list', 'detail', 'dashboard', 'widget', 'modal']),
  path: z.string().min(1, 'Component path is required'),
  permissions: z.array(z.string()),
  props: z.record(z.unknown()).optional()
});

const ModuleLogicSchema = z.object({
  calculations: z.record(z.string()).optional(),
  validations: z.record(z.string()).optional(),
  workflows: z.array(z.object({
    name: z.string(),
    steps: z.array(z.object({
      id: z.string(),
      type: z.string(),
      config: z.record(z.unknown())
    }))
  })).optional()
});

// Menu configuration schema for standardized module.json
const MenuConfigSchema = z.object({
  section: z.string().min(1, 'Menu section is required'),
  position: z.number().min(0, 'Position must be non-negative'),
  label: z.string().min(1, 'Menu label is required'),
  route: z.string().min(1, 'Route is required'),
  icon: z.string().optional()
});

const ModuleMetaSchema = z.object({
  name: z.string().min(1, 'Module name is required'),
  slug: z.string().min(1, 'Module slug is required'),
  version: z.string().regex(/^\d+\.\d+\.\d+$/, 'Version must be in semver format'),
  description: z.string().min(1, 'Description is required'),
  author: z.string().min(1, 'Author is required'),
  license: z.string().optional(),
  menu: MenuConfigSchema,
  dependencies: z.array(z.string()),
  permissions: z.array(z.string()),
  schema: ModuleSchemaSchema,
  components: z.array(ModuleComponentSchema),
  configuration: z.record(z.unknown()).optional()
});

const FullModuleSchema = z.object({
  id: z.string(),
  config: ModuleConfigSchema,
  schema: ModuleSchemaSchema,
  components: z.array(ModuleComponentSchema),
  logic: ModuleLogicSchema,
  enabled: z.boolean(),
  installed_at: z.string(),
  updated_at: z.string(),
  data_version: z.string()
});

export class ModuleValidator {
  /**
   * Validate a module configuration
   */
  static validateConfig(config: unknown): { isValid: boolean; errors?: string[]; data?: ModuleConfig } {
    try {
      const validatedConfig = ModuleConfigSchema.parse(config) as ModuleConfig;
      return { isValid: true, data: validatedConfig };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          isValid: false,
          errors: error.errors.map(err => `${err.path.join('.')}: ${err.message}`)
        };
      }
      return { isValid: false, errors: ['Unknown validation error'] };
    }
  }

  /**
   * Validate a module schema
   */
  static validateSchema(schema: unknown): { isValid: boolean; errors?: string[]; data?: ModuleSchema } {
    try {
      const validatedSchema = ModuleSchemaSchema.parse(schema) as ModuleSchema;
      return { isValid: true, data: validatedSchema };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          isValid: false,
          errors: error.errors.map(err => `${err.path.join('.')}: ${err.message}`)
        };
      }
      return { isValid: false, errors: ['Unknown validation error'] };
    }
  }

  /**
   * Validate module components
   */
  static validateComponents(components: unknown): { isValid: boolean; errors?: string[]; data?: ModuleComponent[] } {
    try {
      const validatedComponents = z.array(ModuleComponentSchema).parse(components) as ModuleComponent[];
      return { isValid: true, data: validatedComponents };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          isValid: false,
          errors: error.errors.map(err => `${err.path.join('.')}: ${err.message}`)
        };
      }
      return { isValid: false, errors: ['Unknown validation error'] };
    }
  }

  /**
   * Validate a complete module
   */
  static validateModule(module: unknown): { isValid: boolean; errors?: string[]; data?: any } {
    try {
      const validatedModule = FullModuleSchema.parse(module);
      return { isValid: true, data: validatedModule };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          isValid: false,
          errors: error.errors.map(err => `${err.path.join('.')}: ${err.message}`)
        };
      }
      return { isValid: false, errors: ['Unknown validation error'] };
    }
  }

  /**
   * Validate standardized module.json format
   */
  static validateModuleMeta(meta: unknown): { isValid: boolean; errors?: string[]; data?: ModuleMeta } {
    try {
      const validatedMeta = ModuleMetaSchema.parse(meta) as ModuleMeta;
      return { isValid: true, data: validatedMeta };
    } catch (error) {
      if (error instanceof z.ZodError) {
        return {
          isValid: false,
          errors: error.errors.map(err => `${err.path.join('.')}: ${err.message}`)
        };
      }
      return { isValid: false, errors: ['Unknown validation error'] };
    }
  }

  /**
   * Check if a module has all required dependencies installed
   */
  static validateDependencies(module: ModuleMeta, installedModules: string[]): { isValid: boolean; missing?: string[] } {
    const missing = module.dependencies.filter(dep => {
      const [depName] = dep.split('@');
      return !installedModules.includes(depName);
    });

    return {
      isValid: missing.length === 0,
      missing: missing.length > 0 ? missing : undefined
    };
  }

  /**
   * Check if the app version meets the module's minimum requirements
   */
  static validateAppVersion(moduleMinVersion: string, currentVersion: string): boolean {
    const parseVersion = (version: string) => version.split('.').map(Number);
    const [minMajor, minMinor, minPatch] = parseVersion(moduleMinVersion);
    const [curMajor, curMinor, curPatch] = parseVersion(currentVersion);

    if (curMajor > minMajor) return true;
    if (curMajor < minMajor) return false;
    
    if (curMinor > minMinor) return true;
    if (curMinor < minMinor) return false;
    
    return curPatch >= minPatch;
  }

  /**
   * Create a safe fallback for incomplete or invalid modules
   */
  static createSafeFallback(moduleId: string, error: string): ModuleMeta {
    return {
      name: `Invalid Module (${moduleId})`,
      slug: moduleId,
      version: '0.0.0',
      description: `This module failed to load due to validation errors: ${error}`,
      author: 'System',
      menu: {
        section: 'System',
        position: 999,
        label: `Invalid: ${moduleId}`,
        route: `/error/${moduleId}`
      },
      dependencies: [],
      permissions: [],
      schema: {
        tables: [{
          name: 'placeholder',
          columns: [{
            name: 'id',
            type: 'text',
            required: true
          }]
        }]
      },
      components: [],
      configuration: { error }
    };
  }
}

export { ModuleConfigSchema, ModuleSchemaSchema, ModuleComponentSchema, ModuleMetaSchema };