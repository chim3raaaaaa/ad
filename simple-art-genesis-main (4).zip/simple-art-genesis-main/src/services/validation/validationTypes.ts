export interface ValidationRule {
  id: string;
  category: string;
  field: string;
  formula: string;
  failure_reason: string;
  severity: 'warning' | 'critical';
  active: boolean;
  created_at: string;
  created_by: string;
}

export interface ValidationResult {
  rule_id: string;
  field: string;
  message: string;
  severity: 'warning' | 'critical';
  passed: boolean;
  actual_value?: any;
  expected_value?: any;
}

export interface TestResultValidation {
  id: string;
  test_id: string;
  rule_id: string;
  passed: boolean;
  failure_reason?: string;
  evaluated_at: string;
  field?: string;
  rule_reason?: string;
}

export interface FormulaTestResult {
  success: boolean;
  result?: boolean;
  error?: string;
}