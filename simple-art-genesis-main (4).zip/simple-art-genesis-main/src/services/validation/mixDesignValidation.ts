// Enhanced Validation Engine for Mix Design Manager
// Phase 3: RBAC & Validation Implementation
// Created: 2025-01-31

import { z } from 'zod';
import { MixDesignField } from '@/services/database/mixDesignService';

export interface ValidationRule {
  type: 'min' | 'max' | 'step' | 'range' | 'regex' | 'enum' | 'custom' | 'dependent' | 'unit_conversion';
  value?: any;
  message?: string;
  severity?: 'error' | 'warning'; // Removed 'info' to match ValidationError
  condition?: (context: any) => boolean;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  suggestions: ValidationSuggestion[];
}

export interface ValidationError {
  field: string;
  message: string;
  severity: 'error' | 'warning';
  rule: string;
  value?: any;
}

export interface ValidationWarning {
  field: string;
  message: string;
  suggestion?: string;
}

export interface ValidationSuggestion {
  field: string;
  message: string;
  suggestedValue?: any;
  reasoning: string;
}

export interface ValidationContext {
  productType: string;
  designData: Record<string, any>;
  existingDesigns?: any[];
  industryStandards?: Record<string, any>;
  environmentalFactors?: Record<string, any>;
}

// Enhanced Validation Engine
export class MixDesignValidationEngine {
  private industryStandards: Map<string, any> = new Map();
  private customValidators: Map<string, (value: any, context: ValidationContext) => ValidationResult> = new Map();

  constructor() {
    this.initializeIndustryStandards();
    this.initializeCustomValidators();
  }

  // Initialize industry standards for validation
  private initializeIndustryStandards(): void {
    // Concrete standards
    this.industryStandards.set('concrete_standards', {
      water_cement_ratio: { min: 0.25, max: 0.7, optimal_range: [0.4, 0.6] },
      cement_content: { min: 200, max: 600, unit: 'kg/m³' },
      slump: { min: 25, max: 200, unit: 'mm' },
      compressive_strength: { min: 15, max: 100, unit: 'MPa' },
      aggregate_ratios: {
        fine_to_total: { min: 0.3, max: 0.45 },
        coarse_to_total: { min: 0.55, max: 0.7 }
      }
    });

    // Asphalt standards
    this.industryStandards.set('asphalt_standards', {
      binder_content: { min: 4.0, max: 8.0, unit: '%', optimal_range: [5.0, 6.5] },
      air_voids: { min: 3.0, max: 8.0, unit: '%', optimal_range: [4.0, 6.0] },
      mixing_temperature: { min: 140, max: 180, unit: '°C' },
      aggregate_gradation: {
        '0.075mm': { min: 2, max: 10, unit: '% passing' },
        '19mm': { min: 90, max: 100, unit: '% passing' }
      }
    });

    // Mortar standards
    this.industryStandards.set('mortar_standards', {
      cement_content: { min: 200, max: 500, unit: 'kg/m³' },
      sand_content: { min: 1200, max: 1800, unit: 'kg/m³' },
      water_content: { min: 200, max: 350, unit: 'kg/m³' },
      compressive_strength: { min: 5, max: 25, unit: 'MPa' }
    });
  }

  // Initialize custom validation functions
  private initializeCustomValidators(): void {
    // Concrete mix design validation
    this.customValidators.set('concrete_mix_validation', (value, context) => {
      const results: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };
      const data = context.designData;

      // Water-cement ratio validation
      if (data.water_content && data.cement_content) {
        const wcRatio = data.water_content / data.cement_content;
        if (wcRatio > 0.65) {
          results.errors.push({
            field: 'water_cement_ratio',
            message: 'High water-cement ratio may reduce strength and durability',
            severity: 'warning',
            rule: 'w_c_ratio_check',
            value: wcRatio
          });
        }
      }

      // Total aggregate validation
      if (data.fine_aggregate && data.coarse_aggregate) {
        const totalAggregate = data.fine_aggregate + data.coarse_aggregate;
        const fineRatio = data.fine_aggregate / totalAggregate;
        
        if (fineRatio < 0.3 || fineRatio > 0.45) {
          results.warnings.push({
            field: 'fine_aggregate',
            message: 'Fine aggregate ratio should be between 30-45% of total aggregate',
            suggestion: `Adjust to ${Math.round(totalAggregate * 0.375)} kg/m³`
          });
        }
      }

      // Workability vs strength balance
      if (data.slump && data.target_strength) {
        if (data.slump > 150 && data.target_strength > 40) {
          results.suggestions.push({
            field: 'admixture_type',
            message: 'Consider using superplasticizer for high strength with good workability',
            reasoning: 'High slump with high strength requirement detected'
          });
        }
      }

      results.isValid = results.errors.filter(e => e.severity === 'error').length === 0;
      return results;
    });

    // Asphalt mix design validation
    this.customValidators.set('asphalt_mix_validation', (value, context) => {
      const results: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };
      const data = context.designData;

      // Binder content vs air voids relationship
      if (data.binder_content && data.air_voids) {
        const optimalBinderForAirVoids = 6.5 - (data.air_voids - 4) * 0.3;
        const difference = Math.abs(data.binder_content - optimalBinderForAirVoids);
        
        if (difference > 0.5) {
          results.warnings.push({
            field: 'binder_content',
            message: 'Binder content may not be optimal for target air voids',
            suggestion: `Consider ${optimalBinderForAirVoids.toFixed(1)}% binder content`
          });
        }
      }

      // Temperature validation
      if (data.mixing_temp && data.asphalt_binder_grade) {
        const gradeTemp = parseInt(data.asphalt_binder_grade.split('-')[0].replace('PG ', ''));
        if (data.mixing_temp > gradeTemp + 20) {
          results.errors.push({
            field: 'mixing_temp',
            message: 'Mixing temperature too high for binder grade',
            severity: 'error',
            rule: 'binder_temp_compatibility',
            value: data.mixing_temp
          });
        }
      }

      results.isValid = results.errors.filter(e => e.severity === 'error').length === 0;
      return results;
    });
  }

  // Validate entire mix design
  validateMixDesign(
    fields: MixDesignField[], 
    data: Record<string, any>, 
    context: ValidationContext
  ): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };

    // Field-level validation
    for (const field of fields) {
      const fieldResult = this.validateField(field, data[field.field_name], context);
      result.errors.push(...fieldResult.errors);
      result.warnings.push(...fieldResult.warnings);
      result.suggestions.push(...fieldResult.suggestions);
    }

    // Cross-field validation based on product type
    const productTypeValidator = this.getProductTypeValidator(context.productType);
    if (productTypeValidator) {
      const crossFieldResult = productTypeValidator(data, context);
      result.errors.push(...crossFieldResult.errors);
      result.warnings.push(...crossFieldResult.warnings);
      result.suggestions.push(...crossFieldResult.suggestions);
    }

    // Industry standards validation
    const standardsResult = this.validateAgainstIndustryStandards(data, context);
    result.errors.push(...standardsResult.errors);
    result.warnings.push(...standardsResult.warnings);
    result.suggestions.push(...standardsResult.suggestions);

    // Environmental factors validation
    if (context.environmentalFactors) {
      const envResult = this.validateEnvironmentalFactors(data, context);
      result.warnings.push(...envResult.warnings);
      result.suggestions.push(...envResult.suggestions);
    }

    result.isValid = result.errors.filter(e => e.severity === 'error').length === 0;
    return result;
  }

  // Validate individual field
  validateField(field: MixDesignField, value: any, context: ValidationContext): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };

    if (!field.validation_rules) return result;

    try {
      const rules: ValidationRule[] = JSON.parse(field.validation_rules);
      
      for (const rule of rules) {
        // Check if rule applies based on condition
        if (rule.condition && !rule.condition(context)) continue;

        const ruleResult = this.applyValidationRule(field, value, rule, context);
        if (!ruleResult.isValid) {
          result.errors.push({
            field: field.field_name,
            message: rule.message || `Validation failed for ${field.field_label}`,
            severity: rule.severity || 'error',
            rule: rule.type,
            value
          });
        }
      }
    } catch (error) {
      console.warn(`Invalid validation rules for field ${field.field_name}:`, error);
    }

    result.isValid = result.errors.length === 0;
    return result;
  }

  // Apply individual validation rule
  private applyValidationRule(
    field: MixDesignField, 
    value: any, 
    rule: ValidationRule, 
    context: ValidationContext
  ): { isValid: boolean } {
    if (value === null || value === undefined || value === '') {
      return { isValid: !field.is_required };
    }

    switch (rule.type) {
      case 'min':
        return { isValid: Number(value) >= rule.value };
      
      case 'max':
        return { isValid: Number(value) <= rule.value };
      
      case 'range':
        const [min, max] = rule.value;
        return { isValid: Number(value) >= min && Number(value) <= max };
      
      case 'step':
        return { isValid: (Number(value) % rule.value) === 0 };
      
      case 'regex':
        return { isValid: new RegExp(rule.value).test(String(value)) };
      
      case 'enum':
        return { isValid: rule.value.includes(value) };
      
      case 'custom':
        const validator = this.customValidators.get(rule.value);
        if (validator) {
          const customResult = validator(value, context);
          return { isValid: customResult.isValid };
        }
        return { isValid: true };
      
      case 'dependent':
        // Validate based on other field values
        const dependentField = rule.value.field;
        const dependentValue = context.designData[dependentField];
        const condition = rule.value.condition;
        return { isValid: this.evaluateCondition(value, dependentValue, condition) };
      
      case 'unit_conversion':
        // Validate with unit conversion
        const convertedValue = this.convertUnits(value, rule.value.from, rule.value.to);
        return { isValid: this.applyValidationRule(field, convertedValue, rule.value.rule, context).isValid };
      
      default:
        return { isValid: true };
    }
  }

  // Get product type specific validator
  private getProductTypeValidator(productType: string): ((data: any, context: ValidationContext) => ValidationResult) | null {
    if (productType.includes('concrete')) {
      return this.customValidators.get('concrete_mix_validation') || null;
    } else if (productType.includes('asphalt')) {
      return this.customValidators.get('asphalt_mix_validation') || null;
    }
    return null;
  }

  // Validate against industry standards
  private validateAgainstIndustryStandards(data: Record<string, any>, context: ValidationContext): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };

    let standardsKey = '';
    if (context.productType.includes('concrete')) standardsKey = 'concrete_standards';
    else if (context.productType.includes('asphalt')) standardsKey = 'asphalt_standards';
    else if (context.productType.includes('mortar')) standardsKey = 'mortar_standards';

    const standards = this.industryStandards.get(standardsKey);
    if (!standards) return result;

    for (const [fieldName, value] of Object.entries(data)) {
      const standard = standards[fieldName];
      if (!standard || value === null || value === undefined) continue;

      // Check against min/max
      if (standard.min !== undefined && Number(value) < standard.min) {
        result.errors.push({
          field: fieldName,
          message: `Value below industry minimum of ${standard.min}${standard.unit ? ' ' + standard.unit : ''}`,
          severity: 'warning',
          rule: 'industry_standard_min',
          value
        });
      }

      if (standard.max !== undefined && Number(value) > standard.max) {
        result.errors.push({
          field: fieldName,
          message: `Value exceeds industry maximum of ${standard.max}${standard.unit ? ' ' + standard.unit : ''}`,
          severity: 'warning',
          rule: 'industry_standard_max',
          value
        });
      }

      // Check against optimal range
      if (standard.optimal_range) {
        const [optMin, optMax] = standard.optimal_range;
        const numValue = Number(value);
        if (numValue < optMin || numValue > optMax) {
          result.suggestions.push({
            field: fieldName,
            message: `Consider value within optimal range: ${optMin}-${optMax}${standard.unit ? ' ' + standard.unit : ''}`,
            suggestedValue: Math.round((optMin + optMax) / 2),
            reasoning: 'Industry best practices'
          });
        }
      }
    }

    return result;
  }

  // Validate environmental factors
  private validateEnvironmentalFactors(data: Record<string, any>, context: ValidationContext): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [], suggestions: [] };
    const env = context.environmentalFactors;

    if (!env) return result;

    // Temperature adjustments
    if (env.temperature && data.water_content) {
      if (env.temperature > 30 && context.productType.includes('concrete')) {
        result.suggestions.push({
          field: 'water_content',
          message: 'Consider reducing water content in hot weather',
          reasoning: 'High temperature increases evaporation rate',
          suggestedValue: Math.round(data.water_content * 0.95)
        });
      }
    }

    // Humidity adjustments
    if (env.humidity && data.curing_time) {
      if (env.humidity < 50 && context.productType.includes('concrete')) {
        result.warnings.push({
          field: 'curing_time',
          message: 'Extended curing may be required in low humidity conditions',
          suggestion: 'Consider increasing curing time by 20%'
        });
      }
    }

    return result;
  }

  // Utility methods
  private evaluateCondition(value1: any, value2: any, condition: string): boolean {
    switch (condition) {
      case 'greater_than': return Number(value1) > Number(value2);
      case 'less_than': return Number(value1) < Number(value2);
      case 'equal': return value1 === value2;
      case 'not_equal': return value1 !== value2;
      default: return true;
    }
  }

  private convertUnits(value: number, fromUnit: string, toUnit: string): number {
    // Simple unit conversion - extend as needed
    const conversions: Record<string, Record<string, number | ((val: number) => number)>> = {
      'kg/m³': { 'lb/ft³': 0.062428 },
      'MPa': { 'psi': 145.038 },
      '°C': { '°F': (val: number) => (val * 9/5) + 32 }
    };

    const conversion = conversions[fromUnit]?.[toUnit];
    if (typeof conversion === 'number') {
      return value * conversion;
    } else if (typeof conversion === 'function') {
      return conversion(value);
    }
    return value;
  }

  // Add custom validator
  addCustomValidator(name: string, validator: (value: any, context: ValidationContext) => ValidationResult): void {
    this.customValidators.set(name, validator);
  }

  // Get validation summary for UI
  getValidationSummary(result: ValidationResult): {
    hasErrors: boolean;
    hasWarnings: boolean;
    errorCount: number;
    warningCount: number;
    suggestionCount: number;
  } {
    const errors = result.errors.filter(e => e.severity === 'error');
    const warnings = result.errors.filter(e => e.severity === 'warning');
    const allWarnings = warnings.length + result.warnings.length;
    
    return {
      hasErrors: errors.length > 0,
      hasWarnings: allWarnings > 0,
      errorCount: errors.length,
      warningCount: allWarnings,
      suggestionCount: result.suggestions.length
    };
  }
}

// Global instance
export const mixDesignValidationEngine = new MixDesignValidationEngine();