import { referenceDataService } from '../database/referenceDataService';

export interface ValidationRule {
  id: string;
  name: string;
  category: string;
  parameter: string;
  rule_type: 'min' | 'max' | 'range' | 'enum' | 'formula';
  min_value?: number;
  max_value?: number;
  allowed_values?: string[];
  formula?: string;
  severity: 'error' | 'warning' | 'info';
  standard: string; // BS, RDA, UBP, etc.
  description: string;
}

export interface ValidationResult {
  parameter: string;
  value: any;
  rule: ValidationRule;
  status: 'pass' | 'fail' | 'warning';
  message: string;
}

export interface ConformityReport {
  test_id: string;
  category: string;
  product_type: string;
  overall_status: 'pass' | 'fail' | 'warning';
  validation_results: ValidationResult[];
  conformity_percentage: number;
  generated_at: string;
}

class ConformityEngine {
  private validationRules: Map<string, ValidationRule[]> = new Map();

  constructor() {
    this.initializeDefaultRules();
  }

  private initializeDefaultRules() {
    // Aggregate validation rules
    const aggregateRules: ValidationRule[] = [
      {
        id: 'agg_grading_bs',
        name: 'BS Grading Limits',
        category: 'aggregates',
        parameter: 'grading_results',
        rule_type: 'formula',
        formula: 'checkGradingLimits(value, "BS")',
        severity: 'error',
        standard: 'BS',
        description: 'Grading must comply with BS 882 limits'
      },
      {
        id: 'agg_moisture_content',
        name: 'Moisture Content Limit',
        category: 'aggregates',
        parameter: 'moisture_content',
        rule_type: 'max',
        max_value: 5.0,
        severity: 'warning',
        standard: 'RDA',
        description: 'Moisture content should not exceed 5%'
      },
      {
        id: 'agg_specific_gravity',
        name: 'Specific Gravity Range',
        category: 'aggregates',
        parameter: 'specific_gravity',
        rule_type: 'range',
        min_value: 2.4,
        max_value: 2.8,
        severity: 'warning',
        standard: 'BS',
        description: 'Specific gravity should be between 2.4 and 2.8'
      }
    ];

    // Block validation rules
    const blockRules: ValidationRule[] = [
      {
        id: 'block_compressive_strength',
        name: 'Minimum Compressive Strength',
        category: 'blocks',
        parameter: 'compressive_strength',
        rule_type: 'min',
        min_value: 3.5,
        severity: 'error',
        standard: 'BS',
        description: 'Compressive strength must be at least 3.5 MPa'
      },
      {
        id: 'block_water_absorption',
        name: 'Maximum Water Absorption',
        category: 'blocks',
        parameter: 'water_absorption',
        rule_type: 'max',
        max_value: 10.0,
        severity: 'error',
        standard: 'BS',
        description: 'Water absorption must not exceed 10%'
      },
      {
        id: 'block_density',
        name: 'Density Range',
        category: 'blocks',
        parameter: 'density',
        rule_type: 'range',
        min_value: 1000,
        max_value: 2500,
        severity: 'warning',
        standard: 'BS',
        description: 'Density should be between 1000-2500 kg/m³'
      }
    ];

    // Cube validation rules
    const cubeRules: ValidationRule[] = [
      {
        id: 'cube_compressive_strength',
        name: 'Compressive Strength Standard',
        category: 'cubes',
        parameter: 'compressive_strength',
        rule_type: 'min',
        min_value: 20.0,
        severity: 'error',
        standard: 'BS',
        description: 'Compressive strength must meet design requirements'
      },
      {
        id: 'cube_age_compliance',
        name: 'Test Age Compliance',
        category: 'cubes',
        parameter: 'test_age',
        rule_type: 'enum',
        allowed_values: ['7', '28'],
        severity: 'warning',
        standard: 'BS',
        description: 'Standard test ages are 7 and 28 days'
      }
    ];

    this.validationRules.set('aggregates', aggregateRules);
    this.validationRules.set('blocks', blockRules);
    this.validationRules.set('cubes', cubeRules);
  }

  async validateTestData(
    testData: Record<string, any>,
    category: string,
    productType: string,
    standard: string = 'BS'
  ): Promise<ConformityReport> {
    const rules = this.validationRules.get(category) || [];
    const applicableRules = rules.filter(rule => rule.standard === standard);
    
    const validationResults: ValidationResult[] = [];
    
    for (const rule of applicableRules) {
      const result = await this.validateParameter(testData, rule);
      if (result) {
        validationResults.push(result);
      }
    }

    // Calculate overall status and conformity percentage
    const errorCount = validationResults.filter(r => r.status === 'fail').length;
    const warningCount = validationResults.filter(r => r.status === 'warning').length;
    const passCount = validationResults.filter(r => r.status === 'pass').length;
    
    const overallStatus = errorCount > 0 ? 'fail' : warningCount > 0 ? 'warning' : 'pass';
    const conformityPercentage = (passCount / validationResults.length) * 100;

    return {
      test_id: testData.id || 'unknown',
      category,
      product_type: productType,
      overall_status: overallStatus,
      validation_results: validationResults,
      conformity_percentage: Math.round(conformityPercentage),
      generated_at: new Date().toISOString()
    };
  }

  private async validateParameter(
    testData: Record<string, any>,
    rule: ValidationRule
  ): Promise<ValidationResult | null> {
    const value = testData[rule.parameter];
    
    if (value === undefined || value === null) {
      return null; // Skip validation if parameter is not present
    }

    let status: 'pass' | 'fail' | 'warning' = 'pass';
    let message = `${rule.parameter} value ${value} is compliant`;

    switch (rule.rule_type) {
      case 'min':
        if (value < rule.min_value!) {
          status = rule.severity === 'error' ? 'fail' : 'warning';
          message = `${rule.parameter} value ${value} is below minimum ${rule.min_value}`;
        }
        break;

      case 'max':
        if (value > rule.max_value!) {
          status = rule.severity === 'error' ? 'fail' : 'warning';
          message = `${rule.parameter} value ${value} exceeds maximum ${rule.max_value}`;
        }
        break;

      case 'range':
        if (value < rule.min_value! || value > rule.max_value!) {
          status = rule.severity === 'error' ? 'fail' : 'warning';
          message = `${rule.parameter} value ${value} is outside range ${rule.min_value}-${rule.max_value}`;
        }
        break;

      case 'enum':
        if (!rule.allowed_values!.includes(String(value))) {
          status = rule.severity === 'error' ? 'fail' : 'warning';
          message = `${rule.parameter} value ${value} is not in allowed values: ${rule.allowed_values!.join(', ')}`;
        }
        break;

      case 'formula':
        const formulaResult = await this.evaluateFormula(rule.formula!, value, testData);
        if (!formulaResult.valid) {
          status = rule.severity === 'error' ? 'fail' : 'warning';
          message = formulaResult.message;
        }
        break;
    }

    return {
      parameter: rule.parameter,
      value,
      rule,
      status,
      message
    };
  }

  private async evaluateFormula(
    formula: string,
    value: any,
    testData: Record<string, any>
  ): Promise<{ valid: boolean; message: string }> {
    // Handle specific formula types
    if (formula.includes('checkGradingLimits')) {
      return await this.checkGradingLimits(value, testData);
    }

    // Default: assume formula passes
    return { valid: true, message: 'Formula validation passed' };
  }

  private async checkGradingLimits(
    gradingResults: any,
    testData: Record<string, any>
  ): Promise<{ valid: boolean; message: string }> {
    try {
      // Get grading limits from the database
      const gradingLimits = await this.getGradingLimitsFromDB(testData.material_type, testData.standard);
      
      if (!gradingResults || !gradingLimits) {
        return { valid: false, message: 'Grading data or limits not available' };
      }

      // Check each sieve size against the limits
      const failedSieves: string[] = [];
      const sieveSizes = [
        '0_075', '0_15', '0_3', '0_6', '1_18', '2_36', '5', '10', 
        '14', '16', '20', '31_5', '37_5', '45', '50', '63'
      ];

      for (const sieve of sieveSizes) {
        const actualValue = gradingResults[`sieve_${sieve}`];
        const limitValue = gradingLimits[`sieve_${sieve}`];
        
        if (actualValue !== undefined && limitValue !== undefined) {
          // For BS Min standards, actual must be >= limit
          // For BS Max standards, actual must be <= limit
          const isMinStandard = testData.standard?.includes('Min');
          const isMaxStandard = testData.standard?.includes('Max');
          
          if (isMinStandard && actualValue < limitValue) {
            failedSieves.push(`${sieve}mm (${actualValue}% < ${limitValue}%)`);
          } else if (isMaxStandard && actualValue > limitValue) {
            failedSieves.push(`${sieve}mm (${actualValue}% > ${limitValue}%)`);
          }
        }
      }

      if (failedSieves.length > 0) {
        return { 
          valid: false, 
          message: `Grading non-conformity in sieves: ${failedSieves.join(', ')}` 
        };
      }

      return { valid: true, message: 'Grading within acceptable limits' };
    } catch (error) {
      console.error('Error validating grading limits:', error);
      return { valid: false, message: 'Error validating grading limits' };
    }
  }

  private async getGradingLimitsFromDB(materialType: string, standard: string): Promise<any> {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          'SELECT * FROM grading_limits WHERE material_type = ? AND standard = ?',
          [materialType, standard]
        );
        return result[0] || null;
      }
      return null;
    } catch (error) {
      console.error('Error fetching grading limits from database:', error);
      return null;
    }
  }

  async getValidationRules(category: string): Promise<ValidationRule[]> {
    return this.validationRules.get(category) || [];
  }

  async addCustomRule(rule: ValidationRule): Promise<void> {
    const categoryRules = this.validationRules.get(rule.category) || [];
    categoryRules.push(rule);
    this.validationRules.set(rule.category, categoryRules);
  }

  async generateNonConformityReport(
    conformityReport: ConformityReport
  ): Promise<string> {
    const failedValidations = conformityReport.validation_results.filter(
      r => r.status === 'fail'
    );

    if (failedValidations.length === 0) {
      return 'No non-conformities found';
    }

    let report = `NON-CONFORMITY REPORT\n`;
    report += `Test ID: ${conformityReport.test_id}\n`;
    report += `Category: ${conformityReport.category}\n`;
    report += `Product Type: ${conformityReport.product_type}\n`;
    report += `Generated: ${new Date(conformityReport.generated_at).toLocaleString()}\n\n`;
    
    report += `NON-CONFORMITIES:\n`;
    failedValidations.forEach((validation, index) => {
      report += `${index + 1}. ${validation.rule.name}\n`;
      report += `   Parameter: ${validation.parameter}\n`;
      report += `   Value: ${validation.value}\n`;
      report += `   Issue: ${validation.message}\n`;
      report += `   Standard: ${validation.rule.standard}\n\n`;
    });

    return report;
  }
}

export const conformityEngine = new ConformityEngine();