import { evaluate } from 'mathjs';
import type { ValidationRule, ValidationResult } from './validationTypes';

export interface ValidationRuleData {
  id?: string;
  category: string;
  field: string;
  formula: string;
  failure_reason: string;
  severity: 'warning' | 'critical';
  active: boolean;
  created_at?: string;
  created_by?: string;
}

export interface TestResultValidation {
  id?: string;
  test_id: string;
  rule_id: string;
  passed: boolean;
  failure_reason?: string;
  evaluated_at?: string;
}

export class EnhancedValidationService {
  private static async executeQuery(query: string, params: any[] = []): Promise<any> {
    if (typeof window !== 'undefined' && window.electronAPI?.dbQuery) {
      return await window.electronAPI.dbQuery(query, params);
    }
    throw new Error('Database not available');
  }

  // Initialize validation tables
  static async initializeTables(): Promise<void> {
    const createValidationRulesTable = `
      CREATE TABLE IF NOT EXISTS validation_rules (
        id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        field TEXT NOT NULL,
        formula TEXT NOT NULL,
        failure_reason TEXT,
        severity TEXT DEFAULT 'critical',
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT
      )
    `;

    const createTestResultValidationsTable = `
      CREATE TABLE IF NOT EXISTS test_result_validations (
        id TEXT PRIMARY KEY,
        test_id TEXT NOT NULL,
        rule_id TEXT NOT NULL,
        passed INTEGER NOT NULL,
        failure_reason TEXT,
        evaluated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await this.executeQuery(createValidationRulesTable);
    await this.executeQuery(createTestResultValidationsTable);
    
    // Create indexes for better performance
    await this.executeQuery(`CREATE INDEX IF NOT EXISTS idx_validation_rules_category ON validation_rules(category)`);
    await this.executeQuery(`CREATE INDEX IF NOT EXISTS idx_validation_rules_active ON validation_rules(active)`);
    await this.executeQuery(`CREATE INDEX IF NOT EXISTS idx_test_validations_test_id ON test_result_validations(test_id)`);
  }

  // Rule Management
  static async getRulesByCategory(category: string): Promise<ValidationRule[]> {
    const query = `
      SELECT * FROM validation_rules 
      WHERE category = ? AND active = 1 
      ORDER BY created_at DESC
    `;
    const result = await this.executeQuery(query, [category]);
    return result.map(this.mapRowToValidationRule);
  }

  static async getAllRules(): Promise<ValidationRule[]> {
    const query = `SELECT * FROM validation_rules ORDER BY category, created_at DESC`;
    const result = await this.executeQuery(query);
    return result.map(this.mapRowToValidationRule);
  }

  static async addRule(rule: ValidationRuleData): Promise<string> {
    const id = `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const query = `
      INSERT INTO validation_rules (id, category, field, formula, failure_reason, severity, active, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await this.executeQuery(query, [
      id,
      rule.category,
      rule.field,
      rule.formula,
      rule.failure_reason,
      rule.severity,
      rule.active ? 1 : 0,
      rule.created_by || 'system'
    ]);
    return id;
  }

  static async updateRule(id: string, updated: Partial<ValidationRuleData>): Promise<void> {
    const fields = [];
    const values = [];
    
    if (updated.category !== undefined) {
      fields.push('category = ?');
      values.push(updated.category);
    }
    if (updated.field !== undefined) {
      fields.push('field = ?');
      values.push(updated.field);
    }
    if (updated.formula !== undefined) {
      fields.push('formula = ?');
      values.push(updated.formula);
    }
    if (updated.failure_reason !== undefined) {
      fields.push('failure_reason = ?');
      values.push(updated.failure_reason);
    }
    if (updated.severity !== undefined) {
      fields.push('severity = ?');
      values.push(updated.severity);
    }
    if (updated.active !== undefined) {
      fields.push('active = ?');
      values.push(updated.active ? 1 : 0);
    }

    if (fields.length === 0) return;

    values.push(id);
    const query = `UPDATE validation_rules SET ${fields.join(', ')} WHERE id = ?`;
    await this.executeQuery(query, values);
  }

  static async deleteRule(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM validation_rules WHERE id = ?', [id]);
  }

  // Validation Engine
  static async validateTestResult(testResult: Record<string, any>, category: string): Promise<ValidationResult[]> {
    const rules = await this.getRulesByCategory(category);
    const failures: ValidationResult[] = [];

    for (const rule of rules) {
      try {
        const isValid = this.evaluateFormula(rule.formula, testResult);
        
        if (!isValid) {
          failures.push({
            rule_id: rule.id,
            field: rule.field,
            message: rule.failure_reason,
            severity: rule.severity,
            passed: false,
            actual_value: testResult[rule.field]
          });
        }
      } catch (error) {
        console.error(`Error evaluating rule ${rule.id}:`, error);
        failures.push({
          rule_id: rule.id,
          field: rule.field,
          message: `Formula error: ${error.message}`,
          severity: 'critical',
          passed: false,
          actual_value: testResult[rule.field]
        });
      }
    }

    return failures;
  }

  // Excel-style formula evaluation using mathjs
  static evaluateFormula(formula: string, data: Record<string, any>): boolean {
    try {
      // Create a scope with the test data
      const scope = { ...data };
      
      // Handle Excel-style formulas
      let processedFormula = formula;
      
      // Convert Excel IF syntax to JavaScript
      processedFormula = processedFormula.replace(/IF\s*\(/gi, 'if(');
      
      // Handle Excel operators
      processedFormula = processedFormula.replace(/\bAND\b/gi, ' and ');
      processedFormula = processedFormula.replace(/\bOR\b/gi, ' or ');
      
      // Remove leading = if present
      if (processedFormula.startsWith('=')) {
        processedFormula = processedFormula.substring(1);
      }

      // Evaluate using mathjs
      const result = evaluate(processedFormula, scope);
      
      // Convert result to boolean
      if (typeof result === 'boolean') {
        return result;
      }
      if (typeof result === 'number') {
        return result !== 0;
      }
      if (typeof result === 'string') {
        return result !== '' && result.toLowerCase() !== 'false';
      }
      
      return Boolean(result);
    } catch (error) {
      console.error('Formula evaluation error:', error);
      throw new Error(`Invalid formula: ${error.message}`);
    }
  }

  // Log validation results
  static async logValidationResult(testId: string, ruleId: string, passed: boolean, reason?: string): Promise<void> {
    const id = `val_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const query = `
      INSERT INTO test_result_validations (id, test_id, rule_id, passed, failure_reason)
      VALUES (?, ?, ?, ?, ?)
    `;
    await this.executeQuery(query, [id, testId, ruleId, passed ? 1 : 0, reason]);
  }

  // Import rules from CSV
  static async importRulesFromCSV(csvData: string): Promise<ValidationRule[]> {
    const lines = csvData.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    const rules: ValidationRule[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const rule: any = {};
      
      headers.forEach((header, index) => {
        rule[header] = values[index];
      });

      if (rule.category && rule.field && rule.formula) {
        const ruleId = await this.addRule({
          category: rule.category,
          field: rule.field,
          formula: rule.formula,
          failure_reason: rule.failure_reason || 'Validation failed',
          severity: rule.severity === 'warning' ? 'warning' : 'critical',
          active: true,
          created_by: 'csv_import'
        });

        rules.push({
          id: ruleId,
          category: rule.category,
          field: rule.field,
          formula: rule.formula,
          failure_reason: rule.failure_reason || 'Validation failed',
          severity: rule.severity === 'warning' ? 'warning' : 'critical',
          active: true,
          created_at: new Date().toISOString(),
          created_by: 'csv_import'
        });
      }
    }

    return rules;
  }

  // Export rules to CSV
  static async exportRulesToCSV(): Promise<string> {
    const rules = await this.getAllRules();
    const headers = ['category', 'field', 'formula', 'failure_reason', 'severity', 'active'];
    const csvLines = [headers.join(',')];

    rules.forEach(rule => {
      const values = [
        rule.category,
        rule.field,
        `"${rule.formula.replace(/"/g, '""')}"`, // Escape quotes in formula
        `"${rule.failure_reason.replace(/"/g, '""')}"`,
        rule.severity,
        rule.active ? 'true' : 'false'
      ];
      csvLines.push(values.join(','));
    });

    return csvLines.join('\n');
  }

  // Get validation history for a test
  static async getValidationHistory(testId: string): Promise<TestResultValidation[]> {
    const query = `
      SELECT v.*, r.field, r.failure_reason as rule_reason
      FROM test_result_validations v
      LEFT JOIN validation_rules r ON v.rule_id = r.id
      WHERE v.test_id = ?
      ORDER BY v.evaluated_at DESC
    `;
    const result = await this.executeQuery(query, [testId]);
    return result;
  }

  // Helper methods
  private static mapRowToValidationRule(row: any): ValidationRule {
    return {
      id: row.id,
      category: row.category,
      field: row.field,
      formula: row.formula,
      failure_reason: row.failure_reason,
      severity: row.severity,
      active: row.active === 1,
      created_at: row.created_at,
      created_by: row.created_by
    };
  }

  // Test formula with sample data
  static testFormula(formula: string, sampleData: Record<string, any>): { success: boolean; result?: boolean; error?: string } {
    try {
      const result = this.evaluateFormula(formula, sampleData);
      return { success: true, result };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Get product categories for dropdown
  static async getProductCategories(): Promise<string[]> {
    try {
      const query = `SELECT DISTINCT category FROM validation_rules WHERE active = 1 ORDER BY category`;
      const result = await this.executeQuery(query);
      return result.map((row: any) => row.category);
    } catch (error) {
      // Fallback to standard categories if query fails
      return ['Aggregates', 'Cubes', 'Pavers', 'Blocks', 'Flagstones', 'Kerbs'];
    }
  }

  // Get fields for a category
  static async getFieldsForCategory(category: string): Promise<string[]> {
    try {
      const query = `SELECT DISTINCT field FROM validation_rules WHERE category = ? AND active = 1 ORDER BY field`;
      const result = await this.executeQuery(query, [category]);
      return result.map((row: any) => row.field);
    } catch (error) {
      console.error('Error getting fields for category:', error);
      return [];
    }
  }
}

// Initialize tables on startup
if (typeof window !== 'undefined' && window.electronAPI) {
  EnhancedValidationService.initializeTables().catch(console.error);
}

export default EnhancedValidationService;