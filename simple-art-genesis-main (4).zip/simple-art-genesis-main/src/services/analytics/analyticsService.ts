import { useState, useEffect } from 'react';

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface AnalyticsChart {
  id: string;
  user_id: string;
  chart_name: string;
  chart_type: string;
  data_source: string;
  chart_config: string;
  filters: string;
  created_at: string;
  updated_at: string;
}

class AnalyticsService {
  async getUserCharts(userId: string): Promise<AnalyticsChart[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      throw new Error('Analytics service requires Electron environment with SQLite database');
    }

    try {
      // Initialize charts table if needed
      await this.initializeChartsTable();
      
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM user_charts WHERE user_id = ? ORDER BY created_at DESC',
        [userId]
      );
      
      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }
      
      return result.data || [];
    } catch (error) {
      console.error('Error loading user charts from SQLite:', error);
      throw new Error('Failed to load analytics charts. Please check database connection.');
    }
  }

  async executeChart(chartId: string) {
    try {
      const charts = await this.getUserCharts('user_1');
      const chart = charts.find(c => c.id === chartId);
      
      if (!chart) {
        throw new Error('Chart not found');
      }

      // Execute the chart query and return formatted data
      const result = await this.executeQuery(chart.chart_config);
      return {
        chart_type: chart.chart_type,
        data: result,
        title: chart.chart_name
      };
    } catch (error) {
      console.error('Error executing chart:', error);
      throw error;
    }
  }

  private async executeQuery(config: string) {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      throw new Error('Analytics service requires Electron environment with SQLite database');
    }

    try {
      const chartConfig = JSON.parse(config);
      const result = await window.electronAPI.dbQuery(chartConfig.sql || 'SELECT 1');
      
      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }
      
      return result.data || [];
    } catch (error) {
      console.error('Error executing query:', error);
      throw new Error('Failed to execute analytics query.');
    }
  }

  async saveChart(chart: AnalyticsChart): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      throw new Error('Analytics service requires Electron environment with SQLite database');
    }

    try {
      await this.initializeChartsTable();
      
      const sql = `
        INSERT OR REPLACE INTO user_charts 
        (id, user_id, chart_name, chart_type, data_source, chart_config, filters, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const result = await window.electronAPI.dbRun(sql, [
        chart.id,
        chart.user_id,
        chart.chart_name,
        chart.chart_type,
        chart.data_source,
        chart.chart_config,
        chart.filters,
        chart.created_at,
        chart.updated_at
      ]);

      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }
    } catch (error) {
      console.error('Error saving chart to SQLite:', error);
      throw new Error('Failed to save analytics chart. Please check database connection.');
    }
  }

  async executeChartQuery(chart: AnalyticsChart): Promise<any[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      throw new Error('Analytics service requires Electron environment with SQLite database');
    }

    try {
      const config = JSON.parse(chart.chart_config);
      let sql = '';

      switch (chart.data_source) {
        case 'memos':
          sql = `
            SELECT 
              strftime('%Y-%m', created_at) as period,
              COUNT(*) as value
            FROM memos 
            WHERE 1=1 ${chart.filters ? `AND ${chart.filters}` : ''}
            GROUP BY strftime('%Y-%m', created_at)
            ORDER BY period DESC
            LIMIT 12
          `;
          break;
        case 'production_data':
          sql = `
            SELECT 
              json_extract(value, '$.product') as category,
              COUNT(*) as value
            FROM memos, json_each(production_data)
            WHERE json_extract(value, '$.product') IS NOT NULL
            ${chart.filters ? `AND ${chart.filters}` : ''}
            GROUP BY json_extract(value, '$.product')
            ORDER BY value DESC
            LIMIT 10
          `;
          break;
        case 'test_status':
          sql = `
            SELECT 
              status as category,
              COUNT(*) as value
            FROM memos 
            WHERE 1=1 ${chart.filters ? `AND ${chart.filters}` : ''}
            GROUP BY status
          `;
          break;
        default:
          throw new Error(`Unsupported data source: ${chart.data_source}`);
      }

      const result = await window.electronAPI.dbQuery(sql);
      
      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }
      
      return result.data || [];
    } catch (error) {
      console.error('Error executing chart query:', error);
      throw new Error('Failed to execute analytics query. Please check database connection.');
    }
  }

  private async initializeChartsTable(): Promise<void> {
    try {
      const createTableSQL = `
        CREATE TABLE IF NOT EXISTS user_charts (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          chart_name TEXT NOT NULL,
          chart_type TEXT NOT NULL,
          data_source TEXT NOT NULL,
          chart_config TEXT NOT NULL,
          filters TEXT DEFAULT '',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `;
      
      await window.electronAPI.dbRun(createTableSQL);
    } catch (error) {
      console.error('Error initializing charts table:', error);
    }
  }

}

export const analyticsService = new AnalyticsService();