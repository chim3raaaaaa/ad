import { toast } from '@/hooks/use-toast';

interface FormSubmissionData {
  formId: string;
  data: Record<string, any>;
  timestamp: string;
  submittedBy: string;
}

interface TableSchema {
  id: string;
  name: string;
  fields: Array<{
    name: string;
    type: string;
    required: boolean;
  }>;
}

export class FormSubmissionService {
  private isElectron(): boolean {
    return window.electronAPI !== undefined;
  }

  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  }

  private async executeRun(sql: string, params: any[] = []): Promise<any> {
    if (!this.isElectron()) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbRun(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database operation failed');
    }
    return result.data;
  }

  // Get form definition by ID
  async getFormDefinition(formId: string): Promise<any> {
    try {
      const forms = await this.executeQuery(
        'SELECT * FROM form_definitions WHERE id = ?',
        [formId]
      );
      
      if (forms.length === 0) {
        throw new Error('Form not found');
      }

      const form = forms[0] as any;
      return {
        ...form,
        fields: JSON.parse(form.fields || '[]')
      };
    } catch (error) {
      console.error('Error getting form definition:', error);
      throw error;
    }
  }

  // Create data table for form if it doesn't exist
  async createFormDataTable(formId: string, fields: any[]): Promise<void> {
    try {
      const tableName = `form_data_${formId.replace(/[^a-zA-Z0-9]/g, '_')}`;
      
      const columns = fields.map(field => {
        let sqlType = 'TEXT';
        switch (field.type) {
          case 'number':
            sqlType = 'REAL';
            break;
          case 'date':
            sqlType = 'DATETIME';
            break;
          case 'checkbox':
            sqlType = 'BOOLEAN';
            break;
          default:
            sqlType = 'TEXT';
        }
        
        return `${field.id.replace(/[^a-zA-Z0-9]/g, '_')} ${sqlType}${field.required ? ' NOT NULL' : ''}`;
      }).join(',\n');

      const createTableSQL = `
        CREATE TABLE IF NOT EXISTS ${tableName} (
          id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
          ${columns},
          submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          submitted_by TEXT,
          form_version TEXT
        )
      `;

      await this.executeRun(createTableSQL);

      // Log table creation
      await this.logAuditEvent('create_table', 'form_data_table', tableName, null, {
        formId,
        tableName,
        fields: fields.length
      });

    } catch (error) {
      console.error('Error creating form data table:', error);
      throw error;
    }
  }

  // Submit form data
  async submitForm(formId: string, formData: Record<string, any>, submittedBy: string = 'current_user'): Promise<string> {
    try {
      // Get form definition
      const formDef = await this.getFormDefinition(formId);
      
      // Ensure data table exists
      await this.createFormDataTable(formId, formDef.fields);
      
      const tableName = `form_data_${formId.replace(/[^a-zA-Z0-9]/g, '_')}`;
      
      // Validate form data against schema
      const validationErrors = this.validateFormData(formData, formDef.fields);
      if (validationErrors.length > 0) {
        throw new Error(`Validation errors: ${validationErrors.join(', ')}`);
      }

      // Prepare data for insertion
      const submissionId = crypto.randomUUID();
      const cleanFieldNames = formDef.fields.map(f => f.id.replace(/[^a-zA-Z0-9]/g, '_'));
      const values = formDef.fields.map(field => formData[field.id] || null);
      
      const insertSQL = `
        INSERT INTO ${tableName} (id, ${cleanFieldNames.join(', ')}, submitted_at, submitted_by, form_version)
        VALUES (?, ${cleanFieldNames.map(() => '?').join(', ')}, ?, ?, ?)
      `;

      await this.executeRun(insertSQL, [
        submissionId,
        ...values,
        new Date().toISOString(),
        submittedBy,
        '1.0'
      ]);

      // Log submission
      await this.logAuditEvent('form_submission', 'form_data', submissionId, null, {
        formId,
        tableName,
        fieldCount: formDef.fields.length,
        submittedBy
      });

      // Trigger workflows if any
      await this.triggerWorkflows('form_submit', formId, formData);

      return submissionId;

    } catch (error) {
      console.error('Error submitting form:', error);
      throw error;
    }
  }

  // Validate form data
  private validateFormData(data: Record<string, any>, fields: any[]): string[] {
    const errors: string[] = [];

    for (const field of fields) {
      const value = data[field.id];
      
      // Check required fields
      if (field.required && (value === undefined || value === null || value === '')) {
        errors.push(`${field.label} is required`);
        continue;
      }

      // Type validation
      if (value !== undefined && value !== null && value !== '') {
        switch (field.type) {
          case 'email':
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
              errors.push(`${field.label} must be a valid email`);
            }
            break;
          case 'number':
            if (isNaN(Number(value))) {
              errors.push(`${field.label} must be a number`);
            }
            break;
        }
      }

      // Custom validation rules
      if (field.validation && value) {
        if (field.validation.min && String(value).length < field.validation.min) {
          errors.push(`${field.label} must be at least ${field.validation.min} characters`);
        }
        if (field.validation.max && String(value).length > field.validation.max) {
          errors.push(`${field.label} must be no more than ${field.validation.max} characters`);
        }
        if (field.validation.pattern && !new RegExp(field.validation.pattern).test(value)) {
          errors.push(`${field.label} format is invalid`);
        }
      }
    }

    return errors;
  }

  // Get form submissions
  async getFormSubmissions(formId: string, limit: number = 50): Promise<any[]> {
    try {
      const tableName = `form_data_${formId.replace(/[^a-zA-Z0-9]/g, '_')}`;
      
      const submissions = await this.executeQuery(
        `SELECT * FROM ${tableName} ORDER BY submitted_at DESC LIMIT ?`,
        [limit]
      );

      return submissions;
    } catch (error) {
      // Table might not exist yet
      if (error.message.includes('no such table')) {
        return [];
      }
      console.error('Error getting form submissions:', error);
      throw error;
    }
  }

  // Update form submission
  async updateFormSubmission(formId: string, submissionId: string, updates: Record<string, any>): Promise<void> {
    try {
      const tableName = `form_data_${formId.replace(/[^a-zA-Z0-9]/g, '_')}`;
      
      const updateFields = Object.keys(updates).map(key => `${key.replace(/[^a-zA-Z0-9]/g, '_')} = ?`);
      const updateValues = Object.values(updates);
      
      if (updateFields.length === 0) return;

      const updateSQL = `
        UPDATE ${tableName} 
        SET ${updateFields.join(', ')}, submitted_at = ?
        WHERE id = ?
      `;

      await this.executeRun(updateSQL, [...updateValues, new Date().toISOString(), submissionId]);

      // Log update
      await this.logAuditEvent('update_form_submission', 'form_data', submissionId, null, {
        formId,
        tableName,
        updates: Object.keys(updates)
      });

    } catch (error) {
      console.error('Error updating form submission:', error);
      throw error;
    }
  }

  // Delete form submission
  async deleteFormSubmission(formId: string, submissionId: string): Promise<void> {
    try {
      const tableName = `form_data_${formId.replace(/[^a-zA-Z0-9]/g, '_')}`;
      
      await this.executeRun(
        `DELETE FROM ${tableName} WHERE id = ?`,
        [submissionId]
      );

      // Log deletion
      await this.logAuditEvent('delete_form_submission', 'form_data', submissionId, null, {
        formId,
        tableName
      });

    } catch (error) {
      console.error('Error deleting form submission:', error);
      throw error;
    }
  }

  // Trigger workflows based on events
  private async triggerWorkflows(triggerType: string, sourceId: string, data: any): Promise<void> {
    try {
      const workflows = await this.executeQuery(
        `SELECT * FROM workflow_definitions 
         WHERE is_active = 1 AND trigger_config LIKE ?`,
        [`%"type":"${triggerType}"%`]
      );

      for (const workflow of workflows) {
        const workflowData = workflow as any;
        const triggerConfig = JSON.parse(workflowData.trigger_config || '{}');
        
        // Check if workflow should trigger for this source
        if (!triggerConfig.source || triggerConfig.source === sourceId) {
          await this.executeWorkflow(workflowData.id, data);
        }
      }
    } catch (error) {
      console.error('Error triggering workflows:', error);
      // Don't throw - workflows are optional
    }
  }

  // Execute workflow
  private async executeWorkflow(workflowId: string, inputData: any): Promise<void> {
    try {
      const workflow = await this.executeQuery(
        'SELECT * FROM workflow_definitions WHERE id = ?',
        [workflowId]
      );

      if (workflow.length === 0) return;

      const workflowDef = workflow[0] as any;
      const steps = JSON.parse(workflowDef.steps || '[]');

      // Create execution record
      const executionId = crypto.randomUUID();
      await this.executeRun(
        `INSERT INTO workflow_executions (id, workflow_id, status, start_time, input_data)
         VALUES (?, ?, ?, ?, ?)`,
        [executionId, workflowId, 'running', new Date().toISOString(), JSON.stringify(inputData)]
      );

      // Execute steps sequentially
      let currentData = inputData;
      const executionLogs: string[] = [];

      for (const step of steps) {
        try {
          currentData = await this.executeWorkflowStep(step, currentData);
          executionLogs.push(`Step ${step.name} completed successfully`);
        } catch (stepError) {
          executionLogs.push(`Step ${step.name} failed: ${stepError.message}`);
          
          // Update execution as failed
          await this.executeRun(
            `UPDATE workflow_executions 
             SET status = ?, end_time = ?, error_message = ?, execution_logs = ?
             WHERE id = ?`,
            ['failed', new Date().toISOString(), stepError.message, JSON.stringify(executionLogs), executionId]
          );
          return;
        }
      }

      // Mark as completed
      await this.executeRun(
        `UPDATE workflow_executions 
         SET status = ?, end_time = ?, output_data = ?, execution_logs = ?
         WHERE id = ?`,
        ['completed', new Date().toISOString(), JSON.stringify(currentData), JSON.stringify(executionLogs), executionId]
      );

    } catch (error) {
      console.error('Error executing workflow:', error);
    }
  }

  // Execute individual workflow step
  private async executeWorkflowStep(step: any, data: any): Promise<any> {
    switch (step.type) {
      case 'query':
        return await this.executeWorkflowQuery(step.config, data);
      case 'calculation':
        return await this.executeWorkflowCalculation(step.config, data);
      case 'notification':
        await this.executeWorkflowNotification(step.config, data);
        return data;
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }

  private async executeWorkflowQuery(config: any, data: any): Promise<any> {
    if (!config.sql) throw new Error('No SQL query provided');
    
    // Simple parameter substitution
    let sql = config.sql;
    Object.keys(data).forEach(key => {
      sql = sql.replace(new RegExp(`\\$${key}`, 'g'), data[key]);
    });

    const result = await this.executeQuery(sql);
    return { ...data, queryResult: result };
  }

  private async executeWorkflowCalculation(config: any, data: any): Promise<any> {
    if (!config.formula) throw new Error('No calculation formula provided');
    
    // Simple calculation evaluation (would need more robust implementation)
    let formula = config.formula;
    Object.keys(data).forEach(key => {
      if (typeof data[key] === 'number') {
        formula = formula.replace(new RegExp(`\\$${key}`, 'g'), data[key].toString());
      }
    });

    try {
      // Very basic evaluation - in production would use a safe expression evaluator
      const result = Function(`"use strict"; return (${formula})`)();
      return { ...data, calculationResult: result };
    } catch (error) {
      throw new Error(`Calculation error: ${error.message}`);
    }
  }

  private async executeWorkflowNotification(config: any, data: any): Promise<void> {
    // Log notification instead of actually sending
    await this.logAuditEvent('workflow_notification', 'notification', crypto.randomUUID(), null, {
      message: config.message || 'Workflow notification',
      data: data
    });
  }

  // Log audit events
  private async logAuditEvent(action: string, resourceType: string, resourceId: string, oldData: any, newData: any): Promise<void> {
    try {
      const auditId = crypto.randomUUID();
      await this.executeRun(
        `INSERT INTO audit_logs (id, user_id, action, resource_type, resource_id, old_data, new_data, ip_address, user_agent, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          auditId,
          'current_user',
          action,
          resourceType,
          resourceId,
          oldData ? JSON.stringify(oldData) : null,
          newData ? JSON.stringify(newData) : null,
          '127.0.0.1',
          navigator.userAgent,
          new Date().toISOString()
        ]
      );
    } catch (error) {
      console.error('Error logging audit event:', error);
      // Don't throw - audit logging is not critical
    }
  }
}

export const formSubmissionService = new FormSubmissionService();