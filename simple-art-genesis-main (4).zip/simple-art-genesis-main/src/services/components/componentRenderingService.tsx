import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, Code } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ComponentDefinition {
  id: string;
  name: string;
  description?: string;
  component_code: string;
  props_schema?: Record<string, any>;
  placement: string;
  module_id?: string;
  custom_route?: string;
}

interface DynamicComponentProps {
  componentId: string;
  props?: Record<string, any>;
  fallback?: React.ReactNode;
  onError?: (error: Error) => void;
}

interface ComponentRegistryProps {
  placement?: string;
  moduleId?: string;
  showDebugInfo?: boolean;
}

export class ComponentRenderingService {
  private static instance: ComponentRenderingService;
  private componentCache = new Map<string, React.ComponentType<any>>();
  private isElectron = typeof window !== 'undefined' && window.electronAPI !== undefined;

  static getInstance(): ComponentRenderingService {
    if (!this.instance) {
      this.instance = new ComponentRenderingService();
    }
    return this.instance;
  }

  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (!this.isElectron) {
      throw new Error('Electron API not available');
    }

    const result = await window.electronAPI.dbQuery(sql, params);
    if (!result.success) {
      throw new Error(result.error || 'Database query failed');
    }
    return result.data || [];
  }

  // Load component definition from database
  async loadComponentDefinition(componentId: string): Promise<ComponentDefinition | null> {
    try {
      const components = await this.executeQuery<any>(
        'SELECT * FROM component_definitions WHERE id = ?',
        [componentId]
      );

      if (components.length === 0) return null;

      const component = components[0];
      return {
        id: component.id,
        name: component.name,
        description: component.description,
        component_code: component.component_code,
        props_schema: component.props_schema ? JSON.parse(component.props_schema) : undefined,
        placement: component.placement,
        module_id: component.module_id,
        custom_route: component.custom_route
      };
    } catch (error) {
      console.error('Error loading component definition:', error);
      return null;
    }
  }

  // Load components by placement
  async loadComponentsByPlacement(placement: string, moduleId?: string): Promise<ComponentDefinition[]> {
    try {
      let sql = 'SELECT * FROM component_definitions WHERE placement = ?';
      const params: any[] = [placement];

      if (moduleId) {
        sql += ' AND module_id = ?';
        params.push(moduleId);
      }

      sql += ' ORDER BY created_at DESC';

      const components = await this.executeQuery<any>(sql, params);

      return components.map(component => ({
        id: component.id,
        name: component.name,
        description: component.description,
        component_code: component.component_code,
        props_schema: component.props_schema ? JSON.parse(component.props_schema) : undefined,
        placement: component.placement,
        module_id: component.module_id,
        custom_route: component.custom_route
      }));
    } catch (error) {
      console.error('Error loading components by placement:', error);
      return [];
    }
  }

  // Compile component code to React component
  compileComponent(componentCode: string, componentName: string): React.ComponentType<any> {
    try {
      // Check cache first
      const cacheKey = `${componentName}_${btoa(componentCode).slice(0, 10)}`;
      if (this.componentCache.has(cacheKey)) {
        return this.componentCache.get(cacheKey)!;
      }

      // Create a safe execution context
      const React = window.React || require('react');
      const componentFunction = new Function(
        'React',
        'useState',
        'useEffect',
        'useMemo',
        'useCallback',
        `
        const { useState, useEffect, useMemo, useCallback } = React;
        ${componentCode}
        return ${componentName};
        `
      );

      const CompiledComponent = componentFunction(
        React,
        React.useState,
        React.useEffect,
        React.useMemo,
        React.useCallback
      );

      // Cache the compiled component
      this.componentCache.set(cacheKey, CompiledComponent);
      
      return CompiledComponent;
    } catch (error) {
      console.error('Error compiling component:', error);
      throw new Error(`Failed to compile component ${componentName}: ${error.message}`);
    }
  }

  // Clear component cache
  clearCache(): void {
    this.componentCache.clear();
  }

  // Validate component code
  validateComponentCode(componentCode: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Basic syntax checks
    if (!componentCode.trim()) {
      errors.push('Component code cannot be empty');
    }

    if (!componentCode.includes('function') && !componentCode.includes('=>')) {
      errors.push('Component code must contain a function declaration');
    }

    if (!componentCode.includes('return')) {
      errors.push('Component must return JSX');
    }

    // Security checks
    const dangerousPatterns = [
      /eval\s*\(/,
      /Function\s*\(/,
      /setTimeout\s*\(/,
      /setInterval\s*\(/,
      /fetch\s*\(/,
      /XMLHttpRequest/,
      /document\./,
      /window\./,
      /global\./,
      /process\./
    ];

    dangerousPatterns.forEach(pattern => {
      if (pattern.test(componentCode)) {
        errors.push(`Potentially unsafe code detected: ${pattern.source}`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

// Hook for using component rendering service
export function useComponentRenderer() {
  const service = ComponentRenderingService.getInstance();
  const { toast } = useToast();

  const renderComponent = async (componentId: string, props: Record<string, any> = {}) => {
    try {
      const definition = await service.loadComponentDefinition(componentId);
      if (!definition) {
        throw new Error('Component not found');
      }

      const validation = service.validateComponentCode(definition.component_code);
      if (!validation.isValid) {
        throw new Error(`Component validation failed: ${validation.errors.join(', ')}`);
      }

      const componentName = definition.name.replace(/\s+/g, '');
      return service.compileComponent(definition.component_code, componentName);
    } catch (error) {
      console.error('Error rendering component:', error);
      toast({
        title: "Component Error",
        description: error instanceof Error ? error.message : "Failed to render component",
        variant: "destructive"
      });
      return null;
    }
  };

  return { renderComponent, service };
}

// Dynamic component renderer
export function DynamicComponent({ 
  componentId, 
  props = {}, 
  fallback = null,
  onError 
}: DynamicComponentProps) {
  const [Component, setComponent] = useState<React.ComponentType<any> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { renderComponent } = useComponentRenderer();

  useEffect(() => {
    const loadComponent = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const CompiledComponent = await renderComponent(componentId, props);
        setComponent(() => CompiledComponent);
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Unknown error');
        setError(error);
        if (onError) onError(error);
      } finally {
        setIsLoading(false);
      }
    };

    loadComponent();
  }, [componentId]);

  if (isLoading) {
    return <div className="p-4 text-center">Loading component...</div>;
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-4 h-4" />
            Component Error
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{error.message}</p>
          {fallback}
        </CardContent>
      </Card>
    );
  }

  if (!Component) {
    return fallback || <div className="p-4 text-center text-muted-foreground">Component not found</div>;
  }

  try {
    return <Component {...props} />;
  } catch (renderError) {
    const error = renderError instanceof Error ? renderError : new Error('Render error');
    if (onError) onError(error);
    
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-4 h-4" />
            Render Error
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{error.message}</p>
          {fallback}
        </CardContent>
      </Card>
    );
  }
}

// Component registry for a specific placement
export function ComponentRegistry({ 
  placement, 
  moduleId, 
  showDebugInfo = false 
}: ComponentRegistryProps) {
  const [components, setComponents] = useState<ComponentDefinition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const service = ComponentRenderingService.getInstance();

  useEffect(() => {
    const loadComponents = async () => {
      if (!placement) return;
      
      try {
        setIsLoading(true);
        const loadedComponents = await service.loadComponentsByPlacement(placement, moduleId);
        setComponents(loadedComponents);
      } catch (error) {
        console.error('Error loading components:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadComponents();
  }, [placement, moduleId]);

  if (isLoading) {
    return <div className="p-4 text-center">Loading components...</div>;
  }

  if (components.length === 0) {
    return null; // Don't render anything if no components
  }

  return (
    <div className="space-y-4">
      {showDebugInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Code className="w-4 h-4" />
              Component Registry Debug
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs space-y-1">
              <p><strong>Placement:</strong> {placement}</p>
              <p><strong>Module ID:</strong> {moduleId || 'None'}</p>
              <p><strong>Components Found:</strong> {components.length}</p>
            </div>
          </CardContent>
        </Card>
      )}
      
      {components.map(component => (
        <div key={component.id} className="relative">
          {showDebugInfo && (
            <div className="absolute top-2 right-2 z-10">
              <Badge variant="outline" className="text-xs">
                {component.name}
              </Badge>
            </div>
          )}
          <DynamicComponent
            componentId={component.id}
            fallback={
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">
                    Component "{component.name}" failed to load
                  </p>
                </CardContent>
              </Card>
            }
          />
        </div>
      ))}
    </div>
  );
}

// ComponentRenderingService is already exported as part of the class declaration