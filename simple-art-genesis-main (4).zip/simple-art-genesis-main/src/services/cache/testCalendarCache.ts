import { TestCalendarEvent, TestCalendarFilters } from '../database/realTimeTestCalendarService';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresAt: number;
}

/**
 * Dedicated caching service for Test Calendar data
 */
class TestCalendarCacheService {
  private cache = new Map<string, CacheEntry<any>>();
  private readonly defaultTTL = 5 * 60 * 1000; // 5 minutes
  private readonly maxSize = 50;

  /**
   * Generate cache key from filters
   */
  private generateCacheKey(filters?: TestCalendarFilters): string {
    if (!filters || Object.keys(filters).length === 0) {
      return 'test-events-all';
    }

    const sortedFilters = Object.keys(filters)
      .sort()
      .reduce((result: any, key) => {
        result[key] = (filters as any)[key];
        return result;
      }, {});

    return `test-events-${JSON.stringify(sortedFilters)}`;
  }

  /**
   * Get cached test events
   */
  getEvents(filters?: TestCalendarFilters): TestCalendarEvent[] | null {
    const key = this.generateCacheKey(filters);
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    console.log(`Cache hit for key: ${key}`);
    return entry.data;
  }

  /**
   * Cache test events
   */
  setEvents(events: TestCalendarEvent[], filters?: TestCalendarFilters, customTTL?: number): void {
    const key = this.generateCacheKey(filters);
    const ttl = customTTL || this.defaultTTL;
    const now = Date.now();

    // Clean up expired entries if at capacity
    if (this.cache.size >= this.maxSize) {
      this.cleanup();
    }

    // If still at capacity, remove oldest entry
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey) {
        this.cache.delete(firstKey);
      }
    }

    this.cache.set(key, {
      data: events,
      timestamp: now,
      expiresAt: now + ttl
    });

    console.log(`Cached ${events.length} events with key: ${key}`);
  }

  /**
   * Invalidate cache entries
   */
  invalidate(filters?: TestCalendarFilters): void {
    if (!filters) {
      // Clear all cache
      this.cache.clear();
      console.log('Cleared all test calendar cache');
      return;
    }

    const key = this.generateCacheKey(filters);
    if (this.cache.delete(key)) {
      console.log(`Invalidated cache for key: ${key}`);
    }
  }

  /**
   * Invalidate all event-related cache entries
   */
  invalidateEvents(): void {
    const keysToDelete: string[] = [];
    
    for (const key of this.cache.keys()) {
      if (key.startsWith('test-events-')) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach(key => this.cache.delete(key));
    console.log(`Invalidated ${keysToDelete.length} event cache entries`);
  }

  /**
   * Cache reference data (lab sites, products, etc.)
   */
  setReferenceData(type: string, data: any[], ttl?: number): void {
    const key = `reference-${type}`;
    const effectiveTTL = ttl || this.defaultTTL * 2; // Reference data can be cached longer
    const now = Date.now();

    this.cache.set(key, {
      data,
      timestamp: now,
      expiresAt: now + effectiveTTL
    });

    console.log(`Cached reference data for: ${type}`);
  }

  /**
   * Get cached reference data
   */
  getReferenceData(type: string): any[] | null {
    const key = `reference-${type}`;
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  /**
   * Clean up expired entries
   */
  cleanup(): number {
    const now = Date.now();
    const keysToDelete: string[] = [];

    for (const [key, entry] of this.cache.entries()) {
      if (now > entry.expiresAt) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach(key => this.cache.delete(key));
    
    if (keysToDelete.length > 0) {
      console.log(`Cleaned up ${keysToDelete.length} expired cache entries`);
    }

    return keysToDelete.length;
  }

  /**
   * Get cache statistics
   */
  getStats() {
    const now = Date.now();
    let validEntries = 0;
    let expiredEntries = 0;

    for (const entry of this.cache.values()) {
      if (now > entry.expiresAt) {
        expiredEntries++;
      } else {
        validEntries++;
      }
    }

    return {
      totalEntries: this.cache.size,
      validEntries,
      expiredEntries,
      maxSize: this.maxSize
    };
  }

  /**
   * Check if cache has specific filters
   */
  has(filters?: TestCalendarFilters): boolean {
    const key = this.generateCacheKey(filters);
    const entry = this.cache.get(key);
    
    if (!entry) return false;
    
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return false;
    }
    
    return true;
  }
}

export const testCalendarCache = new TestCalendarCacheService();