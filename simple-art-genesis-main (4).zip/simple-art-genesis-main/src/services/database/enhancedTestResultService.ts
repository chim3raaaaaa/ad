// Enhanced Test Result Service - Local SQLite with Dynamic Forms
import { v4 as uuid } from 'uuid';

export interface TestResultData {
  id?: string;
  memo_id: string;
  test_type: 'aggregates' | 'cubes' | 'pavers' | 'blocks' | 'kerbs' | 'flagstones';
  status: 'draft' | 'submitted' | 'approved' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  due_date?: string;
  officer_id: string;
  test_data: Record<string, any>;
  validation_results?: Record<string, any>;
  source?: string;
  attachments?: Array<{
    id: string;
    file_name: string;
    file_path: string;
    file_type: string;
  }>;
  created_at: string;
  updated_at: string;
  submitted_at?: string;
  submitted_by?: string;
}

export interface ValidationRule {
  field: string;
  min?: number;
  max?: number;
  required?: boolean;
  pattern?: string;
  message: string;
}

export class EnhancedTestResultService {
  
  // Initialize all required tables
  static async initializeTables(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      // Test Results table with enhanced structure
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_results (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          test_type TEXT NOT NULL,
          status TEXT DEFAULT 'draft',
          priority TEXT DEFAULT 'medium',
          due_date TEXT,
          officer_id TEXT,
          test_data TEXT,
          validation_results TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          submitted_at TEXT,
          submitted_by TEXT
        )
      `);

      // Test Result Files table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_result_files (
          id TEXT PRIMARY KEY,
          test_result_id TEXT NOT NULL,
          file_name TEXT NOT NULL,
          file_path TEXT NOT NULL,
          file_type TEXT,
          uploaded_by TEXT,
          uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (test_result_id) REFERENCES test_results(id) ON DELETE CASCADE
        )
      `);

      // Validation Rules table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS validation_rules (
          id TEXT PRIMARY KEY,
          test_type TEXT NOT NULL,
          field_name TEXT NOT NULL,
          rule_type TEXT NOT NULL,
          min_value REAL,
          max_value REAL,
          required INTEGER DEFAULT 0,
          pattern TEXT,
          message TEXT,
          active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Test Type Schemas table (for dynamic form rendering)
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_type_schemas (
          id TEXT PRIMARY KEY,
          test_type TEXT NOT NULL UNIQUE,
          schema_json TEXT NOT NULL,
          version TEXT DEFAULT '1.0',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Insert default schemas and validation rules
      await this.insertDefaultSchemas();
      await this.insertDefaultValidationRules();

      console.log('Enhanced test result tables initialized successfully');
    } catch (error) {
      console.error('Failed to initialize enhanced test result tables:', error);
    }
  }

  // Insert default test type schemas
  static async insertDefaultSchemas(): Promise<void> {
    if (!window.electronAPI) return;

    const schemas = {
      aggregates: {
        fields: [
          { name: 'sieve_0_075', type: 'number', label: '0.075mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_0_15', type: 'number', label: '0.15mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_0_3', type: 'number', label: '0.3mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_0_6', type: 'number', label: '0.6mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_1_18', type: 'number', label: '1.18mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_2_36', type: 'number', label: '2.36mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_5', type: 'number', label: '5mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_10', type: 'number', label: '10mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'sieve_20', type: 'number', label: '20mm Sieve (%)', required: true, min: 0, max: 100 },
          { name: 'fineness_modulus', type: 'number', label: 'Fineness Modulus', required: true, min: 2.2, max: 3.2 },
          { name: 'sand_equivalent', type: 'number', label: 'Sand Equivalent (%)', required: false, min: 0, max: 100 },
          { name: 'methylene_blue', type: 'number', label: 'Blue Methylene Value', required: false, min: 0 },
          { name: 'water_absorption', type: 'number', label: 'Water Absorption (%)', required: false, min: 0, max: 6 }
        ]
      },
      cubes: {
        fields: [
          { name: 'age', type: 'select', label: 'Age (days)', required: true, options: [7, 14, 28] },
          { name: 'compressive_strength', type: 'number', label: 'Compressive Strength (MPa)', required: true, min: 25, max: 45 },
          { name: 'length', type: 'number', label: 'Length (mm)', required: true, min: 0 },
          { name: 'width', type: 'number', label: 'Width (mm)', required: true, min: 0 },
          { name: 'height', type: 'number', label: 'Height (mm)', required: true, min: 0 },
          { name: 'density', type: 'number', label: 'Density (kg/m³)', required: false, min: 0 },
          { name: 'load_kn', type: 'number', label: 'Load (kN)', required: true, min: 0 }
        ]
      },
      pavers: {
        fields: [
          { name: 'water_absorption', type: 'number', label: 'Water Absorption (%)', required: true, min: 0, max: 6 },
          { name: 'split_strength', type: 'number', label: 'Split Strength (MPa)', required: false, min: 0 },
          { name: 'visual_rating', type: 'select', label: 'Visual Rating', required: true, options: ['Pass', 'Fail'] },
          { name: 'surface_finish', type: 'select', label: 'Surface Finish', required: false, options: ['Good', 'Fair', 'Poor'] },
          { name: 'dimensions_check', type: 'select', label: 'Dimensions Check', required: true, options: ['Pass', 'Fail'] }
        ]
      },
      blocks: {
        fields: [
          { name: 'water_absorption', type: 'number', label: 'Water Absorption (%)', required: true, min: 0, max: 6 },
          { name: 'compressive_strength', type: 'number', label: 'Compressive Strength (MPa)', required: true, min: 15, max: 40 },
          { name: 'visual_rating', type: 'select', label: 'Visual Rating', required: true, options: ['Pass', 'Fail'] },
          { name: 'dimensional_tolerance', type: 'number', label: 'Dimensional Tolerance (mm)', required: false, min: 0, max: 5 }
        ]
      }
    };

    try {
      for (const [testType, schema] of Object.entries(schemas)) {
        await window.electronAPI.dbRun(
          'INSERT OR REPLACE INTO test_type_schemas (id, test_type, schema_json) VALUES (?, ?, ?)',
          [`schema_${testType}`, testType, JSON.stringify(schema)]
        );
      }
    } catch (error) {
      console.error('Failed to insert default schemas:', error);
    }
  }

  // Insert default validation rules
  static async insertDefaultValidationRules(): Promise<void> {
    if (!window.electronAPI) return;

    const validationRules: ValidationRule[] = [
      // Aggregates validations
      { field: 'fineness_modulus', min: 2.2, max: 3.2, required: true, message: 'Fineness Modulus must be between 2.2 and 3.2' },
      { field: 'water_absorption', min: 0, max: 6, required: false, message: 'Water absorption must not exceed 6%' },
      
      // Cubes validations
      { field: 'compressive_strength', min: 25, max: 45, required: true, message: 'Compressive strength must be between 25-45 MPa' },
      
      // Pavers/Blocks validations
      { field: 'water_absorption', min: 0, max: 6, required: true, message: 'Water absorption must not exceed 6%' }
    ];

    try {
      for (const rule of validationRules) {
        const id = `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await window.electronAPI.dbRun(`
          INSERT OR IGNORE INTO validation_rules 
          (id, test_type, field_name, rule_type, min_value, max_value, required, message)
          VALUES (?, 'general', ?, 'range', ?, ?, ?, ?)
        `, [id, rule.field, rule.min, rule.max, rule.required ? 1 : 0, rule.message]);
      }
    } catch (error) {
      console.error('Failed to insert validation rules:', error);
    }
  }

  // Save test result as draft
  static async saveTestResultDraft(data: Omit<TestResultData, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    if (!window.electronAPI) throw new Error('Electron API not available');

    const id = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();

    try {
      await window.electronAPI.dbRun(`
        INSERT INTO test_results 
        (id, memo_id, test_type, status, priority, due_date, officer_id, test_data, validation_results, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        data.memo_id,
        data.test_type,
        'draft',
        data.priority || 'medium',
        data.due_date || null,
        data.officer_id,
        JSON.stringify(data.test_data),
        JSON.stringify(data.validation_results || {}),
        now,
        now
      ]);

      return id;
    } catch (error) {
      console.error('Failed to save test result draft:', error);
      throw error;
    }
  }

  // Submit test result
  static async submitTestResult(id: string, submittedBy: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const now = new Date().toISOString();
      const result = await window.electronAPI.dbRun(`
        UPDATE test_results 
        SET status = 'submitted', submitted_at = ?, submitted_by = ?, updated_at = ?
        WHERE id = ?
      `, ['submitted', now, submittedBy, now, id]);

      return result.success;
    } catch (error) {
      console.error('Failed to submit test result:', error);
      return false;
    }
  }

  // Get test result schema by type
  static async getTestTypeSchema(testType: string): Promise<any> {
    if (!window.electronAPI) return null;

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT schema_json FROM test_type_schemas WHERE test_type = ?',
        [testType]
      );

      if (result.success && result.data.length > 0) {
        return JSON.parse(result.data[0].schema_json);
      }
      return null;
    } catch (error) {
      console.error('Failed to get test type schema:', error);
      return null;
    }
  }

  // Validate test data
  static async validateTestData(testType: string, data: Record<string, any>): Promise<{ isValid: boolean; errors: Record<string, string> }> {
    if (!window.electronAPI) return { isValid: true, errors: {} };

    try {
      const schema = await this.getTestTypeSchema(testType);
      if (!schema) return { isValid: true, errors: {} };

      const errors: Record<string, string> = {};

      for (const field of schema.fields) {
        const value = data[field.name];

        // Check required fields
        if (field.required && (value === undefined || value === null || value === '')) {
          errors[field.name] = `${field.label} is required`;
          continue;
        }

        // Skip validation if field is optional and empty
        if (!field.required && (value === undefined || value === null || value === '')) {
          continue;
        }

        // Check numeric ranges
        if (field.type === 'number') {
          const numValue = parseFloat(value);
          if (isNaN(numValue)) {
            errors[field.name] = `${field.label} must be a valid number`;
            continue;
          }

          if (field.min !== undefined && numValue < field.min) {
            errors[field.name] = `${field.label} must be at least ${field.min}`;
          }

          if (field.max !== undefined && numValue > field.max) {
            errors[field.name] = `${field.label} must not exceed ${field.max}`;
          }
        }

        // Check select options
        if (field.type === 'select' && field.options) {
          if (!field.options.includes(value)) {
            errors[field.name] = `${field.label} must be one of: ${field.options.join(', ')}`;
          }
        }
      }

      return {
        isValid: Object.keys(errors).length === 0,
        errors
      };
    } catch (error) {
      console.error('Failed to validate test data:', error);
      return { isValid: false, errors: { general: 'Validation failed' } };
    }
  }

  // Get all test results with filtering
  static async getTestResults(filters: {
    memo_id?: string;
    test_type?: string;
    status?: string;
    officer_id?: string;
    start_date?: string;
    end_date?: string;
  } = {}): Promise<TestResultData[]> {
    if (!window.electronAPI) return [];

    try {
      let whereClause = 'WHERE 1=1';
      const params: any[] = [];

      if (filters.memo_id) {
        whereClause += ' AND memo_id = ?';
        params.push(filters.memo_id);
      }

      if (filters.test_type) {
        whereClause += ' AND test_type = ?';
        params.push(filters.test_type);
      }

      if (filters.status) {
        whereClause += ' AND status = ?';
        params.push(filters.status);
      }

      if (filters.officer_id) {
        whereClause += ' AND officer_id = ?';
        params.push(filters.officer_id);
      }

      if (filters.start_date) {
        whereClause += ' AND created_at >= ?';
        params.push(filters.start_date);
      }

      if (filters.end_date) {
        whereClause += ' AND created_at <= ?';
        params.push(filters.end_date);
      }

      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_results ${whereClause} ORDER BY created_at DESC
      `, params);

      if (result.success) {
        return result.data.map((row: any) => ({
          ...row,
          test_data: JSON.parse(row.test_data || '{}'),
          validation_results: JSON.parse(row.validation_results || '{}')
        }));
      }

      return [];
    } catch (error) {
      console.error('Failed to get test results:', error);
      return [];
    }
  }

  // Add file attachment
  static async addAttachment(testResultId: string, file: {
    file_name: string;
    file_path: string;
    file_type: string;
    uploaded_by: string;
  }): Promise<string> {
    if (!window.electronAPI) throw new Error('Electron API not available');

    const id = `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();

    try {
      await window.electronAPI.dbRun(`
        INSERT INTO test_result_files 
        (id, test_result_id, file_name, file_path, file_type, uploaded_by, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [id, testResultId, file.file_name, file.file_path, file.file_type, file.uploaded_by, now]);

      return id;
    } catch (error) {
      console.error('Failed to add attachment:', error);
      throw error;
    }
  }

  // Get attachments for test result
  static async getAttachments(testResultId: string): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM test_result_files WHERE test_result_id = ? ORDER BY uploaded_at DESC',
        [testResultId]
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get attachments:', error);
      return [];
    }
  }

  // Compute KPIs and summary statistics
  static computeKPIs(testType: string, testData: Record<string, any>): Record<string, any> {
    switch (testType) {
      case 'aggregates':
        const sieves = [
          testData.sieve_0_075, testData.sieve_0_15, testData.sieve_0_3, 
          testData.sieve_0_6, testData.sieve_1_18, testData.sieve_2_36,
          testData.sieve_5, testData.sieve_10, testData.sieve_20
        ].filter(v => v !== undefined && v !== null);

        return {
          average_passing: sieves.length > 0 ? sieves.reduce((a, b) => a + b, 0) / sieves.length : 0,
          fineness_modulus_status: testData.fineness_modulus >= 2.2 && testData.fineness_modulus <= 3.2 ? 'Pass' : 'Fail',
          water_absorption_status: testData.water_absorption <= 6 ? 'Pass' : 'Fail'
        };

      case 'cubes':
        return {
          strength_status: testData.compressive_strength >= 25 && testData.compressive_strength <= 45 ? 'Pass' : 'Fail',
          volume: testData.length * testData.width * testData.height / 1000000, // Convert to m³
          load_per_area: testData.load_kn / ((testData.length * testData.width) / 1000000) // kN/m²
        };

      case 'pavers':
      case 'blocks':
        return {
          water_absorption_status: testData.water_absorption <= 6 ? 'Pass' : 'Fail',
          overall_rating: testData.visual_rating === 'Pass' && testData.water_absorption <= 6 ? 'Pass' : 'Fail'
        };

      default:
        return {};
    }
  }
}