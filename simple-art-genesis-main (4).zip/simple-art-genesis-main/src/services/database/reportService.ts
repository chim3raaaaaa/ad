// Enhanced database service for comprehensive report management
export class ReportService {
  // Initialize reports table if it doesn't exist
  static async initializeReportTables(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      // Create reports table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS reports (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          type TEXT NOT NULL,
          status TEXT DEFAULT 'draft',
          template_id TEXT,
          memo_id TEXT,
          content TEXT,
          settings TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          generated_by TEXT,
          file_path TEXT
        )
      `);

      // Create report templates table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS report_templates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          category TEXT,
          template_data TEXT,
          plant TEXT,
          content TEXT,
          created_by TEXT,
          is_default INTEGER DEFAULT 0,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create generated reports table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS generated_reports (
          id TEXT PRIMARY KEY,
          memo_id TEXT,
          generated_by TEXT,
          generated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          file_path TEXT,
          template_used TEXT,
          version INTEGER DEFAULT 1,
          status TEXT DEFAULT 'generated',
          report_type TEXT,
          settings TEXT
        )
      `);

      // Create report recipients table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS report_recipients (
          id TEXT PRIMARY KEY,
          report_id TEXT,
          recipient_email TEXT,
          sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
          delivery_status TEXT DEFAULT 'pending'
        )
      `);

      // Create certificates table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS certificates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          type TEXT NOT NULL,
          status TEXT DEFAULT 'ready',
          template_id TEXT,
          memo_id TEXT,
          content TEXT,
          settings TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          issued_by TEXT,
          file_path TEXT
        )
      `);

      // Insert default templates if they don't exist
      await this.insertDefaultTemplates();

      console.log('Report tables initialized successfully');
    } catch (error) {
      console.error('Failed to initialize report tables:', error);
    }
  }

  // Insert default report templates
  static async insertDefaultTemplates(): Promise<void> {
    if (!window.electronAPI) return;

    const defaultTemplates = [
      {
        id: 'TPL-001',
        name: 'Test Certificate',
        description: 'Individual test result certificate',
        category: 'Certificate',
        template_data: JSON.stringify({
          header: 'UBP Laboratory Test Certificate',
          sections: ['memo_details', 'test_results', 'production_data', 'signature'],
          layout: 'standard'
        }),
        is_default: 1
      },
      {
        id: 'TPL-002',
        name: 'Batch Summary',
        description: 'Summary of all tests in a batch',
        category: 'Summary',
        template_data: JSON.stringify({
          header: 'Batch Test Summary Report',
          sections: ['batch_overview', 'test_summary', 'statistics'],
          layout: 'summary'
        }),
        is_default: 0
      },
      {
        id: 'TPL-003',
        name: 'Quality Control Report',
        description: 'QC analysis and recommendations',
        category: 'Quality',
        template_data: JSON.stringify({
          header: 'Quality Control Analysis Report',
          sections: ['qc_analysis', 'recommendations', 'compliance_check'],
          layout: 'detailed'
        }),
        is_default: 0
      }
    ];

    for (const template of defaultTemplates) {
      try {
        await window.electronAPI.dbRun(
          `INSERT OR IGNORE INTO report_templates 
           (id, name, description, category, template_data, is_default)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [
            template.id,
            template.name,
            template.description,
            template.category,
            template.template_data,
            template.is_default
          ]
        );
      } catch (error) {
        console.error(`Failed to insert template ${template.id}:`, error);
      }
    }
  }

  // Get all reports
  static async getReports(): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM reports ORDER BY created_at DESC'
      );
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get reports:', error);
      return [];
    }
  }

  // Get all certificates
  static async getCertificates(): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM certificates ORDER BY created_at DESC'
      );
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get certificates:', error);
      return [];
    }
  }

  // Get all templates
  static async getTemplates(): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM report_templates ORDER BY name ASC'
      );
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get templates:', error);
      return [];
    }
  }

  // Create a new report
  static async createReport(reportData: {
    name: string;
    type: string;
    template_id: string;
    memo_id?: string;
    content?: string;
    settings?: string;
    generated_by?: string;
  }): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!window.electronAPI) {
      return { success: false, error: 'Database not available' };
    }

    try {
      const reportId = `report-${Date.now()}`;
      const result = await window.electronAPI.dbRun(
        `INSERT INTO reports 
         (id, name, type, template_id, memo_id, content, settings, generated_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          reportId,
          reportData.name,
          reportData.type,
          reportData.template_id,
          reportData.memo_id || null,
          reportData.content || '',
          reportData.settings || '{}',
          reportData.generated_by || 'system'
        ]
      );

      if (result.success) {
        return { success: true, id: reportId };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      console.error('Failed to create report:', error);
      return { success: false, error: 'Failed to create report' };
    }
  }

  // Create a new certificate
  static async createCertificate(certificateData: {
    name: string;
    type: string;
    template_id: string;
    memo_id?: string;
    content?: string;
    settings?: string;
    issued_by?: string;
  }): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!window.electronAPI) {
      return { success: false, error: 'Database not available' };
    }

    try {
      const certificateId = `cert-${Date.now()}`;
      const result = await window.electronAPI.dbRun(
        `INSERT INTO certificates 
         (id, name, type, template_id, memo_id, content, settings, issued_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          certificateId,
          certificateData.name,
          certificateData.type,
          certificateData.template_id,
          certificateData.memo_id || null,
          certificateData.content || '',
          certificateData.settings || '{}',
          certificateData.issued_by || 'system'
        ]
      );

      if (result.success) {
        return { success: true, id: certificateId };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      console.error('Failed to create certificate:', error);
      return { success: false, error: 'Failed to create certificate' };
    }
  }

  // Update report status
  static async updateReportStatus(reportId: string, status: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const result = await window.electronAPI.dbRun(
        'UPDATE reports SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [status, reportId]
      );
      return result.success;
    } catch (error) {
      console.error('Failed to update report status:', error);
      return false;
    }
  }

  // Delete report
  static async deleteReport(reportId: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const result = await window.electronAPI.dbRun(
        'DELETE FROM reports WHERE id = ?',
        [reportId]
      );
      return result.success;
    } catch (error) {
      console.error('Failed to delete report:', error);
      return false;
    }
  }

  // Delete certificate
  static async deleteCertificate(certificateId: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const result = await window.electronAPI.dbRun(
        'DELETE FROM certificates WHERE id = ?',
        [certificateId]
      );
      return result.success;
    } catch (error) {
      console.error('Failed to delete certificate:', error);
      return false;
    }
  }

  // Get reports by memo
  static async getReportsByMemo(memoId: string): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM reports WHERE memo_id = ? ORDER BY created_at DESC',
        [memoId]
      );
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get reports by memo:', error);
      return [];
    }
  }

  // Generate reports from memos
  static async generateReportsFromMemos(memos: any[]): Promise<void> {
    for (const memo of memos) {
      if (memo.status === 'completed') {
        // Check if report already exists
        const existingReports = await this.getReportsByMemo(memo.id);
        if (existingReports.length === 0) {
          // Create report
          await this.createReport({
            name: `Test Report - ${memo.reference}`,
            type: memo.extractedData?.testType || 'General',
            template_id: 'TPL-001',
            memo_id: memo.id,
            content: JSON.stringify(memo),
            generated_by: 'auto-generation'
          });

          // Create certificate
          await this.createCertificate({
            name: `Certificate - ${memo.reference}`,
            type: memo.extractedData?.testType || 'General',
            template_id: 'TPL-001',
            memo_id: memo.id,
            content: JSON.stringify(memo),
            issued_by: 'auto-generation'
          });
        }
      }
    }
  }

  // Save custom template
  static async saveTemplate(templateData: {
    id?: string;
    name: string;
    description?: string;
    category: string;
    content: string;
    plant?: string;
    created_by: string;
  }): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!window.electronAPI) {
      return { success: false, error: 'Database not available' };
    }

    try {
      const templateId = templateData.id || `template-${Date.now()}`;
      const result = await window.electronAPI.dbRun(
        `INSERT OR REPLACE INTO report_templates 
         (id, name, description, category, content, plant, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          templateId,
          templateData.name,
          templateData.description || '',
          templateData.category,
          templateData.content,
          templateData.plant || '',
          templateData.created_by
        ]
      );

      if (result.success) {
        return { success: true, id: templateId };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      console.error('Failed to save template:', error);
      return { success: false, error: 'Failed to save template' };
    }
  }

  // Generate and save report
  static async generateAndSaveReport(reportMeta: {
    memo_id: string;
    template_used: string;
    generated_by: string;
    report_type: string;
    file_path: string;
    settings?: string;
  }): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!window.electronAPI) {
      return { success: false, error: 'Database not available' };
    }

    try {
      const reportId = `generated-${Date.now()}`;
      const result = await window.electronAPI.dbRun(
        `INSERT INTO generated_reports 
         (id, memo_id, generated_by, file_path, template_used, report_type, settings)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          reportId,
          reportMeta.memo_id,
          reportMeta.generated_by,
          reportMeta.file_path,
          reportMeta.template_used,
          reportMeta.report_type,
          reportMeta.settings || '{}'
        ]
      );

      if (result.success) {
        return { success: true, id: reportId };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      console.error('Failed to save generated report:', error);
      return { success: false, error: 'Failed to save report' };
    }
  }

  // Log report send
  static async logReportSend(reportId: string, recipientEmail: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const result = await window.electronAPI.dbRun(
        `INSERT INTO report_recipients (id, report_id, recipient_email)
         VALUES (?, ?, ?)`,
        [`recipient-${Date.now()}`, reportId, recipientEmail]
      );
      return result.success;
    } catch (error) {
      console.error('Failed to log report send:', error);
      return false;
    }
  }

  // Get all generated reports
  static async getGeneratedReports(): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM generated_reports ORDER BY generated_at DESC'
      );
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get generated reports:', error);
      return [];
    }
  }

  // Get report filter options
  static async getReportFilterOptions(): Promise<{
    labSites: string[];
    productCategories: string[];
    testTypes: string[];
    memos: any[];
  }> {
    if (!window.electronAPI) {
      return { labSites: [], productCategories: [], testTypes: [], memos: [] };
    }

    try {
      // Get distinct lab sites from memos
      const sitesResult = await window.electronAPI.dbQuery(
        'SELECT DISTINCT plant as site FROM memos WHERE plant IS NOT NULL'
      );
      const labSites = sitesResult.success ? sitesResult.data.map((row: any) => row.site) : [];

      // Get distinct product categories
      const categoriesResult = await window.electronAPI.dbQuery(
        'SELECT DISTINCT product_type as category FROM memos WHERE product_type IS NOT NULL'
      );
      const productCategories = categoriesResult.success ? categoriesResult.data.map((row: any) => row.category) : [];

      // Get distinct test types
      const testTypesResult = await window.electronAPI.dbQuery(
        'SELECT DISTINCT test_type FROM test_results WHERE test_type IS NOT NULL'
      );
      const testTypes = testTypesResult.success ? testTypesResult.data.map((row: any) => row.test_type) : [];

      // Get all memos
      const memosResult = await window.electronAPI.dbQuery(
        'SELECT id, memo_ref, plant, product_type, created_at FROM memos ORDER BY created_at DESC LIMIT 100'
      );
      const memos = memosResult.success ? memosResult.data : [];

      return { labSites, productCategories, testTypes, memos };
    } catch (error) {
      console.error('Failed to get filter options:', error);
      return { labSites: [], productCategories: [], testTypes: [], memos: [] };
    }
  }

  // Generate report data based on filters
  static async generateReportData(filters: {
    labSite?: string;
    productCategory?: string;
    testType?: string;
    memoId?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<any> {
    if (!window.electronAPI) return null;

    try {
      let query = `
        SELECT 
          m.id as memo_id,
          m.memo_ref,
          m.plant,
          m.product_type,
          m.created_at as memo_date,
          tr.id as test_id,
          tr.test_type,
          tr.status as test_status,
          tr.created_at as test_date
        FROM memos m
        LEFT JOIN test_results tr ON m.id = tr.memo_id
        WHERE 1=1
      `;
      
      const params: any[] = [];

      if (filters.labSite) {
        query += ' AND m.plant = ?';
        params.push(filters.labSite);
      }

      if (filters.productCategory) {
        query += ' AND m.product_type = ?';
        params.push(filters.productCategory);
      }

      if (filters.testType) {
        query += ' AND tr.test_type = ?';
        params.push(filters.testType);
      }

      if (filters.memoId) {
        query += ' AND m.id = ?';
        params.push(filters.memoId);
      }

      if (filters.startDate) {
        query += ' AND DATE(m.created_at) >= ?';
        params.push(filters.startDate);
      }

      if (filters.endDate) {
        query += ' AND DATE(m.created_at) <= ?';
        params.push(filters.endDate);
      }

      query += ' ORDER BY m.created_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      
      if (result.success) {
        const data = result.data;
        
        // Group by memo
        const groupedData = data.reduce((acc: any, row: any) => {
          if (!acc[row.memo_id]) {
            acc[row.memo_id] = {
              memo_ref: row.memo_ref,
              plant: row.plant,
              product_type: row.product_type,
              memo_date: row.memo_date,
              tests: []
            };
          }
          
          if (row.test_id) {
            acc[row.memo_id].tests.push({
              id: row.test_id,
              test_type: row.test_type,
              status: row.test_status,
              test_date: row.test_date
            });
          }
          
          return acc;
        }, {});

        return {
          memos: Object.values(groupedData),
          totalTests: data.filter((row: any) => row.test_id).length,
          passedTests: data.filter((row: any) => row.test_status === 'passed').length,
          failedTests: data.filter((row: any) => row.test_status === 'failed').length
        };
      }

      return null;
    } catch (error) {
      console.error('Failed to generate report data:', error);
      return null;
    }
  }

  // Export report data
  static async exportAsJSON(reportData: any): Promise<void> {
    const dataStr = JSON.stringify(reportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `report_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  static async exportAsCSV(reportData: any): Promise<void> {
    if (!reportData?.memos) return;

    const csvRows = [];
    csvRows.push('Memo Reference,Plant,Product Type,Memo Date,Test Count,Pass Rate');

    reportData.memos.forEach((memo: any) => {
      const passedTests = memo.tests.filter((t: any) => t.status === 'passed').length;
      const totalTests = memo.tests.length;
      const passRate = totalTests > 0 ? ((passedTests / totalTests) * 100).toFixed(1) : '0';
      
      csvRows.push([
        memo.memo_ref,
        memo.plant,
        memo.product_type,
        memo.memo_date,
        totalTests.toString(),
        `${passRate}%`
      ].join(','));
    });

    const csvContent = csvRows.join('\n');
    const csvBlob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(csvBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `report_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}