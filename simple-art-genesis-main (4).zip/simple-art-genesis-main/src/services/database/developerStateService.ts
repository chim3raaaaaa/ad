// Enhanced Developer State Service for SQLite-based persistence (NO SUPABASE)
import { generateId } from '@/lib/utils';

export interface DevUserState {
  id: string;
  user_id: string;
  tool_id: string;
  state_data: string; // JSON string
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DevToolVisibility {
  id: string;
  tool_id: string;
  role: string;
  is_visible: boolean;
  created_at: string;
  updated_at: string;
}

export interface DevAuditLog {
  id: string;
  user_id: string;
  tool_id: string;
  action: string;
  details?: string;
  timestamp: string;
}

export interface DevBuilderTemplate {
  id: string;
  name: string;
  type: 'form' | 'component' | 'workflow' | 'api';
  template_data: string; // JSON string
  created_by: string;
  is_shared: boolean;
  created_at: string;
  updated_at: string;
}

export interface DevComponentUsage {
  id: string;
  component_id: string;
  used_in_type: 'form' | 'page' | 'workflow';
  used_in_id: string;
  usage_count: number;
  last_used: string;
}

export interface DevApiTestResult {
  id: string;
  endpoint_id: string;
  test_data: string; // JSON string
  response_data: string; // JSON string
  status_code: number;
  response_time: number;
  tested_by: string;
  tested_at: string;
}

class DeveloperStateService {
  private async ensureTablesExist() {
    const tables = [
      // Developer user states table
      `CREATE TABLE IF NOT EXISTS dev_user_states (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        state_data TEXT NOT NULL DEFAULT '{}',
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, tool_id)
      )`,
      
      // Tool visibility by role
      `CREATE TABLE IF NOT EXISTS dev_tool_visibility (
        id TEXT PRIMARY KEY,
        tool_id TEXT NOT NULL,
        role TEXT NOT NULL,
        is_visible INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(tool_id, role)
      )`,
      
      // Developer audit logs
      `CREATE TABLE IF NOT EXISTS dev_audit_logs (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        action TEXT NOT NULL,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Builder templates
      `CREATE TABLE IF NOT EXISTS dev_builder_templates (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('form', 'component', 'workflow', 'api')),
        template_data TEXT NOT NULL DEFAULT '{}',
        created_by TEXT NOT NULL,
        is_shared INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Component usage tracking
      `CREATE TABLE IF NOT EXISTS dev_component_usage (
        id TEXT PRIMARY KEY,
        component_id TEXT NOT NULL,
        used_in_type TEXT NOT NULL CHECK(used_in_type IN ('form', 'page', 'workflow')),
        used_in_id TEXT NOT NULL,
        usage_count INTEGER DEFAULT 1,
        last_used DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(component_id, used_in_type, used_in_id)
      )`,
      
      // API test results
      `CREATE TABLE IF NOT EXISTS dev_api_test_results (
        id TEXT PRIMARY KEY,
        endpoint_id TEXT NOT NULL,
        test_data TEXT NOT NULL DEFAULT '{}',
        response_data TEXT NOT NULL DEFAULT '{}',
        status_code INTEGER DEFAULT 0,
        response_time INTEGER DEFAULT 0,
        tested_by TEXT NOT NULL,
        tested_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    for (const sql of tables) {
      try {
        await window.electronAPI.dbRun(sql);
      } catch (error) {
        console.error('Failed to create developer table:', error);
      }
    }

    // Create indexes
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_dev_user_states_user_tool ON dev_user_states(user_id, tool_id)',
      'CREATE INDEX IF NOT EXISTS idx_dev_tool_visibility_role ON dev_tool_visibility(role)',
      'CREATE INDEX IF NOT EXISTS idx_dev_audit_logs_user_timestamp ON dev_audit_logs(user_id, timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_dev_component_usage_component ON dev_component_usage(component_id)',
      'CREATE INDEX IF NOT EXISTS idx_dev_api_test_results_endpoint ON dev_api_test_results(endpoint_id)'
    ];

    for (const sql of indexes) {
      try {
        await window.electronAPI.dbRun(sql);
      } catch (error) {
        console.error('Failed to create index:', error);
      }
    }

    // Insert default tool visibility settings
    await this.initializeDefaultToolVisibility();
  }

  private async initializeDefaultToolVisibility() {
    const defaultVisibility = [
      // Admin has access to all tools
      { tool_id: 'form-builder', role: 'admin', is_visible: true },
      { tool_id: 'component-builder', role: 'admin', is_visible: true },
      { tool_id: 'api-manager', role: 'admin', is_visible: true },
      { tool_id: 'theme-editor', role: 'admin', is_visible: true },
      { tool_id: 'workflow-builder', role: 'admin', is_visible: true },
      { tool_id: 'field-inspector', role: 'admin', is_visible: true },
      { tool_id: 'data-link-manager', role: 'admin', is_visible: true },
      { tool_id: 'audit-trail', role: 'admin', is_visible: true },
      { tool_id: 'schema-exporter', role: 'admin', is_visible: true },
      { tool_id: 'sqlite-console', role: 'admin', is_visible: true },
      { tool_id: 'user-flow-simulator', role: 'admin', is_visible: true },
      { tool_id: 'template-composer', role: 'admin', is_visible: true },
      
      // Lab Admin - most tools except sensitive ones
      { tool_id: 'form-builder', role: 'lab_admin', is_visible: true },
      { tool_id: 'component-builder', role: 'lab_admin', is_visible: true },
      { tool_id: 'api-manager', role: 'lab_admin', is_visible: true },
      { tool_id: 'theme-editor', role: 'lab_admin', is_visible: false },
      { tool_id: 'workflow-builder', role: 'lab_admin', is_visible: true },
      { tool_id: 'field-inspector', role: 'lab_admin', is_visible: true },
      { tool_id: 'data-link-manager', role: 'lab_admin', is_visible: true },
      { tool_id: 'audit-trail', role: 'lab_admin', is_visible: true },
      { tool_id: 'schema-exporter', role: 'lab_admin', is_visible: true },
      { tool_id: 'sqlite-console', role: 'lab_admin', is_visible: false },
      { tool_id: 'user-flow-simulator', role: 'lab_admin', is_visible: true },
      { tool_id: 'template-composer', role: 'lab_admin', is_visible: true },
      
      // Manager - limited tools
      { tool_id: 'form-builder', role: 'manager', is_visible: true },
      { tool_id: 'component-builder', role: 'manager', is_visible: false },
      { tool_id: 'api-manager', role: 'manager', is_visible: false },
      { tool_id: 'theme-editor', role: 'manager', is_visible: false },
      { tool_id: 'workflow-builder', role: 'manager', is_visible: false },
      { tool_id: 'field-inspector', role: 'manager', is_visible: false },
      { tool_id: 'data-link-manager', role: 'manager', is_visible: false },
      { tool_id: 'audit-trail', role: 'manager', is_visible: true },
      { tool_id: 'schema-exporter', role: 'manager', is_visible: true },
      { tool_id: 'sqlite-console', role: 'manager', is_visible: false },
      { tool_id: 'user-flow-simulator', role: 'manager', is_visible: false },
      { tool_id: 'template-composer', role: 'manager', is_visible: false },
      
      // Lab Technician - very limited
      { tool_id: 'form-builder', role: 'lab_technician', is_visible: false },
      { tool_id: 'component-builder', role: 'lab_technician', is_visible: false },
      { tool_id: 'api-manager', role: 'lab_technician', is_visible: false },
      { tool_id: 'theme-editor', role: 'lab_technician', is_visible: false },
      { tool_id: 'workflow-builder', role: 'lab_technician', is_visible: false },
      { tool_id: 'field-inspector', role: 'lab_technician', is_visible: false },
      { tool_id: 'data-link-manager', role: 'lab_technician', is_visible: false },
      { tool_id: 'audit-trail', role: 'lab_technician', is_visible: false },
      { tool_id: 'schema-exporter', role: 'lab_technician', is_visible: false },
      { tool_id: 'sqlite-console', role: 'lab_technician', is_visible: false },
      { tool_id: 'user-flow-simulator', role: 'lab_technician', is_visible: false },
      { tool_id: 'template-composer', role: 'lab_technician', is_visible: false },
      
      // Plant Officer - no access
      { tool_id: 'form-builder', role: 'plant_officer', is_visible: false },
      { tool_id: 'component-builder', role: 'plant_officer', is_visible: false },
      { tool_id: 'api-manager', role: 'plant_officer', is_visible: false },
      { tool_id: 'theme-editor', role: 'plant_officer', is_visible: false },
      { tool_id: 'workflow-builder', role: 'plant_officer', is_visible: false },
      { tool_id: 'field-inspector', role: 'plant_officer', is_visible: false },
      { tool_id: 'data-link-manager', role: 'plant_officer', is_visible: false },
      { tool_id: 'audit-trail', role: 'plant_officer', is_visible: false },
      { tool_id: 'schema-exporter', role: 'plant_officer', is_visible: false },
      { tool_id: 'sqlite-console', role: 'plant_officer', is_visible: false },
      { tool_id: 'user-flow-simulator', role: 'plant_officer', is_visible: false },
      { tool_id: 'template-composer', role: 'plant_officer', is_visible: false }
    ];

    for (const visibility of defaultVisibility) {
      try {
        await window.electronAPI.dbRun(
          `INSERT OR IGNORE INTO dev_tool_visibility (id, tool_id, role, is_visible) VALUES (?, ?, ?, ?)`,
          [generateId(), visibility.tool_id, visibility.role, visibility.is_visible ? 1 : 0]
        );
      } catch (error) {
        console.error('Failed to insert default tool visibility:', error);
      }
    }
  }

  // User State Management
  async getUserState(userId: string, toolId: string): Promise<DevUserState | null> {
    await this.ensureTablesExist();
    
    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM dev_user_states WHERE user_id = ? AND tool_id = ?',
        [userId, toolId]
      );
      return result.length > 0 ? result[0] : null;
    } catch (error) {
      console.error('Failed to get user state:', error);
      return null;
    }
  }

  async saveUserState(userId: string, toolId: string, stateData: any): Promise<void> {
    await this.ensureTablesExist();
    
    try {
      const id = generateId();
      const stateJson = JSON.stringify(stateData);
      
      await window.electronAPI.dbRun(
        `INSERT OR REPLACE INTO dev_user_states (id, user_id, tool_id, state_data, updated_at) 
         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`,
        [id, userId, toolId, stateJson]
      );
    } catch (error) {
      console.error('Failed to save user state:', error);
    }
  }

  // Tool Visibility Management
  async getToolVisibility(role: string): Promise<DevToolVisibility[]> {
    await this.ensureTablesExist();
    
    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM dev_tool_visibility WHERE role = ?',
        [role]
      );
      return result;
    } catch (error) {
      console.error('Failed to get tool visibility:', error);
      return [];
    }
  }

  async updateToolVisibility(toolId: string, role: string, isVisible: boolean): Promise<void> {
    await this.ensureTablesExist();
    
    try {
      await window.electronAPI.dbRun(
        `UPDATE dev_tool_visibility SET is_visible = ?, updated_at = CURRENT_TIMESTAMP 
         WHERE tool_id = ? AND role = ?`,
        [isVisible ? 1 : 0, toolId, role]
      );
    } catch (error) {
      console.error('Failed to update tool visibility:', error);
    }
  }

  // Audit Logging
  async logAction(userId: string, toolId: string, action: string, details?: string): Promise<void> {
    await this.ensureTablesExist();
    
    try {
      const id = generateId();
      await window.electronAPI.dbRun(
        'INSERT INTO dev_audit_logs (id, user_id, tool_id, action, details) VALUES (?, ?, ?, ?, ?)',
        [id, userId, toolId, action, details || null]
      );
    } catch (error) {
      console.error('Failed to log action:', error);
    }
  }

  async getAuditLogs(userId?: string, toolId?: string, limit = 100): Promise<DevAuditLog[]> {
    await this.ensureTablesExist();
    
    try {
      let query = 'SELECT * FROM dev_audit_logs';
      const params: any[] = [];
      const conditions: string[] = [];

      if (userId) {
        conditions.push('user_id = ?');
        params.push(userId);
      }

      if (toolId) {
        conditions.push('tool_id = ?');
        params.push(toolId);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY timestamp DESC LIMIT ?';
      params.push(limit);

      const result = await window.electronAPI.dbQuery(query, params);
      return result;
    } catch (error) {
      console.error('Failed to get audit logs:', error);
      return [];
    }
  }

  // Template Management
  async saveTemplate(template: Omit<DevBuilderTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    await this.ensureTablesExist();
    
    try {
      const id = generateId();
      await window.electronAPI.dbRun(
        `INSERT INTO dev_builder_templates (id, name, type, template_data, created_by, is_shared) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [id, template.name, template.type, template.template_data, template.created_by, template.is_shared ? 1 : 0]
      );
      return id;
    } catch (error) {
      console.error('Failed to save template:', error);
      throw error;
    }
  }

  async getTemplates(type?: string, isShared?: boolean): Promise<DevBuilderTemplate[]> {
    await this.ensureTablesExist();
    
    try {
      let query = 'SELECT * FROM dev_builder_templates';
      const params: any[] = [];
      const conditions: string[] = [];

      if (type) {
        conditions.push('type = ?');
        params.push(type);
      }

      if (isShared !== undefined) {
        conditions.push('is_shared = ?');
        params.push(isShared ? 1 : 0);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY created_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      return result;
    } catch (error) {
      console.error('Failed to get templates:', error);
      return [];
    }
  }

  // Component Usage Tracking
  async trackComponentUsage(componentId: string, usedInType: string, usedInId: string): Promise<void> {
    await this.ensureTablesExist();
    
    try {
      const existing = await window.electronAPI.dbQuery(
        'SELECT * FROM dev_component_usage WHERE component_id = ? AND used_in_type = ? AND used_in_id = ?',
        [componentId, usedInType, usedInId]
      );

      if (existing.length > 0) {
        await window.electronAPI.dbRun(
          'UPDATE dev_component_usage SET usage_count = usage_count + 1, last_used = CURRENT_TIMESTAMP WHERE id = ?',
          [existing[0].id]
        );
      } else {
        const id = generateId();
        await window.electronAPI.dbRun(
          'INSERT INTO dev_component_usage (id, component_id, used_in_type, used_in_id) VALUES (?, ?, ?, ?)',
          [id, componentId, usedInType, usedInId]
        );
      }
    } catch (error) {
      console.error('Failed to track component usage:', error);
    }
  }

  async getComponentUsage(componentId?: string): Promise<DevComponentUsage[]> {
    await this.ensureTablesExist();
    
    try {
      let query = 'SELECT * FROM dev_component_usage';
      const params: any[] = [];

      if (componentId) {
        query += ' WHERE component_id = ?';
        params.push(componentId);
      }

      query += ' ORDER BY last_used DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      return result;
    } catch (error) {
      console.error('Failed to get component usage:', error);
      return [];
    }
  }

  // API Test Results
  async saveApiTestResult(testResult: Omit<DevApiTestResult, 'id' | 'tested_at'>): Promise<void> {
    await this.ensureTablesExist();
    
    try {
      const id = generateId();
      await window.electronAPI.dbRun(
        `INSERT INTO dev_api_test_results (id, endpoint_id, test_data, response_data, status_code, response_time, tested_by) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [id, testResult.endpoint_id, testResult.test_data, testResult.response_data, testResult.status_code, testResult.response_time, testResult.tested_by]
      );
    } catch (error) {
      console.error('Failed to save API test result:', error);
    }
  }

  async getApiTestResults(endpointId?: string, limit = 50): Promise<DevApiTestResult[]> {
    await this.ensureTablesExist();
    
    try {
      let query = 'SELECT * FROM dev_api_test_results';
      const params: any[] = [];

      if (endpointId) {
        query += ' WHERE endpoint_id = ?';
        params.push(endpointId);
      }

      query += ' ORDER BY tested_at DESC LIMIT ?';
      params.push(limit);

      const result = await window.electronAPI.dbQuery(query, params);
      return result;
    } catch (error) {
      console.error('Failed to get API test results:', error);
      return [];
    }
  }
}

export const developerStateService = new DeveloperStateService();