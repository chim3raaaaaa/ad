// Validation Rules Engine Service
import type { IDataService } from '../api/interface';
import type { ValidationRule as ApiValidationRule, ValidationResult as ApiValidationResult } from '../api/types';

export interface ValidationRule extends Omit<ApiValidationRule, 'configuration'> {
  configuration: {
    min_value?: number;
    max_value?: number;
    pattern?: string;
    formula?: string;
    related_fields?: string[];
    error_message: string;
    warning_message?: string;
    [key: string]: any;
  };
}

export interface ValidationResult {
  id: string;
  rule_id: string;
  record_id: string;
  table_name: string;
  field_name: string;
  value: any;
  is_valid: boolean;
  message: string;
  severity: 'error' | 'warning' | 'info';
  validated_at: string;
}

export class ValidationService {
  constructor(private dataService: IDataService) {}

  // Rule Management
  async getRules(): Promise<ValidationRule[]> {
    const response = await this.dataService.getValidationRules();
    return (response.data || []).map(rule => ({
      ...rule,
      configuration: {
        ...rule.configuration,
        error_message: rule.configuration?.error_message || 'Validation failed'
      }
    })) as ValidationRule[];
  }

  async createRule(rule: Omit<ValidationRule, 'id' | 'created_at' | 'updated_at'>): Promise<ValidationRule> {
    const newRule: ValidationRule = {
      ...rule,
      id: `rule_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    await this.dataService.createValidationRule(newRule);
    return newRule;
  }

  async updateRule(id: string, updates: Partial<ValidationRule>): Promise<ValidationRule> {
    const updatedRule = {
      ...updates,
      id,
      updated_at: new Date().toISOString()
    };
    
    await this.dataService.updateValidationRule(id, updatedRule);
    return updatedRule as ValidationRule;
  }

  async deleteRule(id: string): Promise<void> {
    await this.dataService.deleteValidationRule(id);
  }

  async toggleRule(id: string, active: boolean): Promise<void> {
    await this.updateRule(id, { active });
  }

  // Validation Execution
  async validateRecord(tableName: string, recordId: string, data: Record<string, any>): Promise<ValidationResult[]> {
    const rules = await this.getRules();
    const applicableRules = rules.filter(rule => 
      rule.table_name === tableName && rule.active
    );

    const results: ValidationResult[] = [];

    for (const rule of applicableRules) {
      const result = await this.executeRule(rule, recordId, data);
      if (result) {
        results.push(result);
        await this.dataService.createValidationResult(result);
      }
    }

    return results;
  }

  async validateField(tableName: string, fieldName: string, value: any, recordId?: string): Promise<ValidationResult[]> {
    const rules = await this.getRules();
    const fieldRules = rules.filter(rule => 
      rule.table_name === tableName && 
      rule.field_name === fieldName && 
      rule.active
    );

    const results: ValidationResult[] = [];

    for (const rule of fieldRules) {
      const data = { [fieldName]: value };
      const result = await this.executeRule(rule, recordId || 'temp', data);
      if (result) {
        results.push(result);
      }
    }

    return results;
  }

  // Execute individual validation rule
  private async executeRule(rule: ValidationRule, recordId: string, data: Record<string, any>): Promise<ValidationResult | null> {
    const fieldValue = data[rule.field_name];
    let isValid = true;
    let message = '';
    let severity = rule.severity;

    try {
      switch (rule.rule_type) {
        case 'threshold':
          const result = this.validateThreshold(fieldValue, rule.configuration);
          isValid = result.isValid;
          message = result.message;
          severity = (result.severity as 'error' | 'warning' | 'info') || rule.severity;
          break;

        case 'pattern':
          const patternResult = this.validatePattern(fieldValue, rule.configuration);
          isValid = patternResult.isValid;
          message = patternResult.message;
          break;

        case 'formula':
          const formulaResult = this.validateFormula(data, rule.configuration);
          isValid = formulaResult.isValid;
          message = formulaResult.message;
          break;

        case 'cross_field':
          const crossResult = this.validateCrossField(data, rule.configuration);
          isValid = crossResult.isValid;
          message = crossResult.message;
          break;

        default:
          console.warn(`Unknown rule type: ${rule.rule_type}`);
          return null;
      }
    } catch (error) {
      console.error(`Error executing rule ${rule.id}:`, error);
      isValid = false;
      message = `Validation error: ${error.message}`;
      severity = 'error';
    }

    return {
      id: `result_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      rule_id: rule.id,
      record_id: recordId,
      table_name: rule.table_name,
      field_name: rule.field_name,
      value: fieldValue,
      is_valid: isValid,
      message,
      severity,
      validated_at: new Date().toISOString()
    };
  }

  // Validation rule implementations
  private validateThreshold(value: any, config: ValidationRule['configuration']): { isValid: boolean; message: string; severity?: string } {
    const numValue = parseFloat(value);
    
    if (isNaN(numValue)) {
      return {
        isValid: false,
        message: 'Value must be a number',
        severity: 'error'
      };
    }

    const { min_value, max_value, error_message, warning_message } = config;
    
    if (min_value !== undefined && numValue < min_value) {
      return {
        isValid: false,
        message: error_message || `Value must be >= ${min_value}`,
        severity: 'error'
      };
    }
    
    if (max_value !== undefined && numValue > max_value) {
      return {
        isValid: false,
        message: error_message || `Value must be <= ${max_value}`,
        severity: 'error'
      };
    }

    // Check for warning thresholds (90% of limits)
    if (warning_message) {
      const warningMinThreshold = min_value !== undefined ? min_value * 1.1 : undefined;
      const warningMaxThreshold = max_value !== undefined ? max_value * 0.9 : undefined;
      
      if ((warningMinThreshold && numValue < warningMinThreshold) ||
          (warningMaxThreshold && numValue > warningMaxThreshold)) {
        return {
          isValid: true,
          message: warning_message,
          severity: 'warning'
        };
      }
    }

    return { isValid: true, message: 'Valid' };
  }

  private validatePattern(value: any, config: ValidationRule['configuration']): { isValid: boolean; message: string } {
    const { pattern, error_message } = config;
    
    if (!pattern) {
      return { isValid: false, message: 'No pattern specified' };
    }

    try {
      const regex = new RegExp(pattern);
      const isValid = regex.test(String(value));
      
      return {
        isValid,
        message: isValid ? 'Valid' : (error_message || 'Value does not match required pattern')
      };
    } catch (error) {
      return { isValid: false, message: 'Invalid pattern configuration' };
    }
  }

  private validateFormula(data: Record<string, any>, config: ValidationRule['configuration']): { isValid: boolean; message: string } {
    const { formula, error_message } = config;
    
    if (!formula) {
      return { isValid: false, message: 'No formula specified' };
    }

    try {
      // Create a safe evaluation context
      const context = { ...data };
      
      // Simple formula evaluation (in production, use a proper expression parser)
      const result = Function(...Object.keys(context), `return ${formula}`)(...Object.values(context));
      
      return {
        isValid: Boolean(result),
        message: result ? 'Valid' : (error_message || 'Formula validation failed')
      };
    } catch (error) {
      return { isValid: false, message: 'Formula execution error' };
    }
  }

  private validateCrossField(data: Record<string, any>, config: ValidationRule['configuration']): { isValid: boolean; message: string } {
    const { related_fields, formula, error_message } = config;
    
    if (!related_fields || related_fields.length === 0) {
      return { isValid: false, message: 'No related fields specified' };
    }

    // Check if all related fields have values
    const missingFields = related_fields.filter(field => data[field] === undefined || data[field] === null);
    if (missingFields.length > 0) {
      return {
        isValid: false,
        message: `Missing required fields: ${missingFields.join(', ')}`
      };
    }

    // If formula is provided, use it for cross-field validation
    if (formula) {
      return this.validateFormula(data, { formula, error_message });
    }

    return { isValid: true, message: 'Valid' };
  }

  // Get validation results
  async getValidationResults(filters?: {
    table_name?: string;
    record_id?: string;
    severity?: string;
    is_valid?: boolean;
  }): Promise<ValidationResult[]> {
    const response = await this.dataService.getValidationResults();
    return (response.data || []).map((result: any) => ({
      id: result.id || 'unknown',
      rule_id: result.rule_id || 'unknown',
      record_id: result.record_id || 'unknown',
      table_name: result.table_name || 'unknown',
      field_name: result.field_name || 'unknown',
      value: result.field_value || result.value || null,
      is_valid: result.passed !== false && result.is_valid !== false,
      message: result.message || '',
      severity: (result.severity || 'info') as 'error' | 'warning' | 'info',
      validated_at: result.validated_at || new Date().toISOString()
    }));
  }

  // Test validation rules with sample data
  async testRule(rule: ValidationRule, testData: Record<string, any>): Promise<ValidationResult> {
    const result = await this.executeRule(rule, 'test', testData);
    return result || {
      id: 'test_result',
      rule_id: rule.id,
      record_id: 'test',
      table_name: rule.table_name,
      field_name: rule.field_name,
      value: testData[rule.field_name],
      is_valid: false,
      message: 'Test failed',
      severity: 'error',
      validated_at: new Date().toISOString()
    };
  }
}

// Export singleton instance
export const validationService = new ValidationService(
  // This will be injected at runtime
  null as any
);