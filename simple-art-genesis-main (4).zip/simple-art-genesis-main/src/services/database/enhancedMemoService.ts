// Enhanced Local Memo Service with SQLite integration
declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface MemoStatus {
  id: string;
  status: 'Draft' | 'Submitted' | 'In Review' | 'Completed' | 'Archived';
  memo_ref: string;
  updated_by: string;
  timestamp: string;
  remarks?: string;
}

export interface MemoAttachment {
  id: string;
  memo_ref: string;
  file_name: string;
  file_type: string;
  file_path: string;
  file_size: number;
  uploaded_by: string;
  uploaded_at: string;
}

export interface EnhancedMemoData {
  id: string;
  memo_ref: string;
  plant: string;
  officer: string;
  category: string;
  product_type?: string;
  test_type?: string;
  status: 'Draft' | 'Submitted' | 'In Review' | 'Completed' | 'Archived';
  date_created: string;
  date_submitted?: string;
  date_completed?: string;
  production_data?: any[];
  attachments?: MemoAttachment[];
  remarks?: string;
  created_by: string;
  updated_at: string;
}

class EnhancedMemoService {
  private isElectron = false;
  private isInitialized = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        await this.createRequiredTables();
        console.log('Enhanced Memo Service initialized with SQLite');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Enhanced Memo Service:', error);
      throw error;
    }
  }

  private async createRequiredTables(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Enhanced Memos table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS enhanced_memos (
          id TEXT PRIMARY KEY,
          memo_ref TEXT UNIQUE NOT NULL,
          plant TEXT NOT NULL,
          officer TEXT NOT NULL,
          category TEXT NOT NULL,
          product_type TEXT,
          test_type TEXT,
          status TEXT DEFAULT 'Draft',
          date_created TEXT NOT NULL,
          date_submitted TEXT,
          date_completed TEXT,
          production_data TEXT DEFAULT '[]',
          remarks TEXT,
          created_by TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `);

      // Memo Status Log
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS MemoStatusLog (
          id TEXT PRIMARY KEY,
          memo_ref TEXT NOT NULL,
          status TEXT NOT NULL,
          updated_by TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          remarks TEXT,
          FOREIGN KEY (memo_ref) REFERENCES enhanced_memos(memo_ref)
        )
      `);

      // Memo Attachments
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS MemoAttachments (
          id TEXT PRIMARY KEY,
          memo_ref TEXT NOT NULL,
          file_name TEXT NOT NULL,
          file_type TEXT NOT NULL,
          file_path TEXT NOT NULL,
          file_size INTEGER DEFAULT 0,
          uploaded_by TEXT NOT NULL,
          uploaded_at TEXT NOT NULL,
          FOREIGN KEY (memo_ref) REFERENCES enhanced_memos(memo_ref)
        )
      `);

      // Memo Reference Counter
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS memo_counter (
          plant TEXT PRIMARY KEY,
          last_sequence INTEGER DEFAULT 0,
          updated_at TEXT NOT NULL
        )
      `);

      // Create indexes
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_enhanced_memos_status ON enhanced_memos(status)
      `);
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_enhanced_memos_plant ON enhanced_memos(plant)
      `);
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_enhanced_memos_category ON enhanced_memos(category)
      `);

      console.log('Enhanced memo tables created successfully');
    } catch (error) {
      console.error('Error creating enhanced memo tables:', error);
      throw error;
    }
  }

  async generateMemoRef(plant: string, productType: string): Promise<string> {
    await this.initialize();

    if (!this.isElectron) {
      return `${plant}-${productType}-${new Date().toISOString().split('T')[0].replace(/-/g, '')}-0001`;
    }

    try {
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      
      // Get current sequence for the plant
      const result = await window.electronAPI.dbQuery(
        'SELECT last_sequence FROM memo_counter WHERE plant = ?',
        [plant]
      );

      let sequence = 1;
      if (result.success && result.data.length > 0) {
        sequence = result.data[0].last_sequence + 1;
        // Update sequence
        await window.electronAPI.dbQuery(
          'UPDATE memo_counter SET last_sequence = ?, updated_at = ? WHERE plant = ?',
          [sequence, new Date().toISOString(), plant]
        );
      } else {
        // Insert new counter
        await window.electronAPI.dbQuery(
          'INSERT INTO memo_counter (plant, last_sequence, updated_at) VALUES (?, ?, ?)',
          [plant, sequence, new Date().toISOString()]
        );
      }

      const sequenceStr = sequence.toString().padStart(4, '0');
      return `${plant}-${productType}-${today}-${sequenceStr}`;
    } catch (error) {
      console.error('Error generating memo reference:', error);
      // Fallback
      return `${plant}-${productType}-${new Date().toISOString().split('T')[0].replace(/-/g, '')}-0001`;
    }
  }

  async createMemo(data: {
    plant: string;
    officer: string;
    category: string;
    product_type?: string;
    test_type?: string;
    production_data?: any[];
    remarks?: string;
    created_by: string;
  }): Promise<string | null> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Memo created (browser mode)');
      return `mock_${Date.now()}`;
    }

    try {
      const id = `memo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const memoRef = await this.generateMemoRef(
        data.plant, 
        data.product_type || data.category.substring(0, 4).toUpperCase()
      );
      const timestamp = new Date().toISOString();

      const result = await window.electronAPI.dbQuery(`
        INSERT INTO enhanced_memos (
          id, memo_ref, plant, officer, category, product_type, test_type,
          status, date_created, production_data, remarks, created_by, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id, memoRef, data.plant, data.officer, data.category,
        data.product_type || null, data.test_type || null,
        'Draft', timestamp, JSON.stringify(data.production_data || []),
        data.remarks || null, data.created_by, timestamp
      ]);

      if (result.success) {
        // Log initial status
        await this.logStatusChange(memoRef, 'Draft', data.created_by, 'Memo created');
        console.log(`Created memo: ${memoRef}`);
        return memoRef;
      } else {
        console.error('Failed to create memo:', result.error);
        return null;
      }
    } catch (error) {
      console.error('Error creating memo:', error);
      return null;
    }
  }

  async updateMemoStatus(memoRef: string, newStatus: MemoStatus['status'], updatedBy: string, remarks?: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Memo status updated (browser mode)');
      return true;
    }

    try {
      const timestamp = new Date().toISOString();
      
      // Update memo status
      let updateFields = 'status = ?, updated_at = ?';
      let updateValues = [newStatus, timestamp];

      if (newStatus === 'Submitted') {
        updateFields += ', date_submitted = ?';
        updateValues.push(timestamp);
      } else if (newStatus === 'Completed') {
        updateFields += ', date_completed = ?';
        updateValues.push(timestamp);
      }

      updateValues.push(memoRef);

      const result = await window.electronAPI.dbQuery(
        `UPDATE enhanced_memos SET ${updateFields} WHERE memo_ref = ?`,
        updateValues
      );

      if (result.success) {
        // Log status change
        await this.logStatusChange(memoRef, newStatus, updatedBy, remarks);
        console.log(`Updated memo ${memoRef} status to ${newStatus}`);
        return true;
      } else {
        console.error('Failed to update memo status:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error updating memo status:', error);
      return false;
    }
  }

  private async logStatusChange(memoRef: string, status: string, updatedBy: string, remarks?: string): Promise<void> {
    if (!this.isElectron) return;

    try {
      const id = `status_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await window.electronAPI.dbQuery(`
        INSERT INTO MemoStatusLog (id, memo_ref, status, updated_by, timestamp, remarks)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [id, memoRef, status, updatedBy, new Date().toISOString(), remarks || null]);
    } catch (error) {
      console.error('Error logging status change:', error);
    }
  }

  async addAttachment(memoRef: string, file: {
    name: string;
    type: string;
    path: string;
    size: number;
  }, uploadedBy: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Attachment added (browser mode)');
      return true;
    }

    try {
      const id = `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const result = await window.electronAPI.dbQuery(`
        INSERT INTO MemoAttachments (id, memo_ref, file_name, file_type, file_path, file_size, uploaded_by, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [id, memoRef, file.name, file.type, file.path, file.size, uploadedBy, new Date().toISOString()]);

      if (result.success) {
        console.log(`Added attachment to memo ${memoRef}: ${file.name}`);
        return true;
      } else {
        console.error('Failed to add attachment:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error adding attachment:', error);
      return false;
    }
  }

  async searchMemos(filters: {
    status?: string;
    plant?: string;
    officer?: string;
    category?: string;
    dateFrom?: string;
    dateTo?: string;
    searchText?: string;
  }): Promise<EnhancedMemoData[]> {
    await this.initialize();

    if (!this.isElectron) {
      return this.getMockMemos();
    }

    try {
      let query = 'SELECT * FROM enhanced_memos WHERE 1=1';
      const params: any[] = [];

      if (filters.status) {
        query += ' AND status = ?';
        params.push(filters.status);
      }

      if (filters.plant) {
        query += ' AND plant = ?';
        params.push(filters.plant);
      }

      if (filters.officer) {
        query += ' AND officer = ?';
        params.push(filters.officer);
      }

      if (filters.category) {
        query += ' AND category = ?';
        params.push(filters.category);
      }

      if (filters.dateFrom) {
        query += ' AND date_created >= ?';
        params.push(filters.dateFrom);
      }

      if (filters.dateTo) {
        query += ' AND date_created <= ?';
        params.push(filters.dateTo);
      }

      if (filters.searchText) {
        query += ' AND (memo_ref LIKE ? OR remarks LIKE ? OR product_type LIKE ?)';
        const searchPattern = `%${filters.searchText}%`;
        params.push(searchPattern, searchPattern, searchPattern);
      }

      query += ' ORDER BY date_created DESC';

      const result = await window.electronAPI.dbQuery(query, params);

      if (!result.success) {
        console.error('Failed to search memos:', result.error);
        return [];
      }

      // Load attachments for each memo
      const memosWithAttachments = await Promise.all(
        result.data.map(async (memo: any) => {
          const attachmentsResult = await window.electronAPI.dbQuery(
            'SELECT * FROM MemoAttachments WHERE memo_ref = ?',
            [memo.memo_ref]
          );

          return {
            ...memo,
            production_data: JSON.parse(memo.production_data || '[]'),
            attachments: attachmentsResult.success ? attachmentsResult.data : []
          };
        })
      );

      return memosWithAttachments as EnhancedMemoData[];
    } catch (error) {
      console.error('Error searching memos:', error);
      return [];
    }
  }

  async getMemosByRole(userRole: string, userId?: string): Promise<EnhancedMemoData[]> {
    const filters: any = {};

    switch (userRole) {
      case 'plant_officer':
        if (userId) {
          filters.officer = userId;
        }
        break;
      case 'lab_technician':
        // Can see all memos
        break;
      case 'admin':
        // Can see all memos
        break;
    }

    return this.searchMemos(filters);
  }

  async deleteMemo(memoRef: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Memo deleted (browser mode)');
      return true;
    }

    try {
      // Delete attachments first
      await window.electronAPI.dbQuery('DELETE FROM MemoAttachments WHERE memo_ref = ?', [memoRef]);
      
      // Delete status log
      await window.electronAPI.dbQuery('DELETE FROM MemoStatusLog WHERE memo_ref = ?', [memoRef]);
      
      // Delete memo
      const result = await window.electronAPI.dbQuery('DELETE FROM enhanced_memos WHERE memo_ref = ?', [memoRef]);

      if (result.success) {
        console.log(`Deleted memo: ${memoRef}`);
        return true;
      } else {
        console.error('Failed to delete memo:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error deleting memo:', error);
      return false;
    }
  }

  private getMockMemos(): EnhancedMemoData[] {
    console.warn('Using mock memo data - database not available');
    return [];
  }
}

export const enhancedMemoService = new EnhancedMemoService();