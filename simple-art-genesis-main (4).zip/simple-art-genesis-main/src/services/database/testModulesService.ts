import { electronDataService } from '@/services/storage/electronDataService';

export interface TestModule {
  id: string;
  category: string;
  tests: string[];
  description?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TestModuleTest {
  id: string;
  moduleId: string;
  name: string;
  description?: string;
  procedure?: string;
  requirements?: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface TestModuleRow {
  id: string;
  category: string;
  description?: string;
  is_active: number;
  created_at: string;
  updated_at: string;
}

interface TestModuleTestRow {
  id: string;
  module_id: string;
  name: string;
  description?: string;
  procedure?: string;
  requirements?: string;
  is_active: number;
  created_at: string;
  updated_at: string;
}

class TestModulesService {
  private isElectron = typeof window !== 'undefined' && window.electronAPI;
  private storageKey = 'test_modules_data';

  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (this.isElectron) {
      const result = await window.electronAPI.dbQuery(sql, params);
      if (!result.success) {
        throw new Error(result.error || 'Database query failed');
      }
      return result.data || [];
    }
    
    // Fallback to localStorage for web environment
    return this.executeWebQuery<T>(sql, params);
  }

  private async executeRun(sql: string, params: any[] = []): Promise<any> {
    if (this.isElectron) {
      const result = await window.electronAPI.dbRun(sql, params);
      if (!result.success) {
        throw new Error(result.error || 'Database operation failed');
      }
      return result.data;
    }
    
    // Fallback to localStorage for web environment
    return this.executeWebRun(sql, params);
  }

  private getWebData(): { modules: TestModuleRow[], tests: TestModuleTestRow[] } {
    const stored = localStorage.getItem(this.storageKey);
    if (stored) {
      return JSON.parse(stored);
    }
    return { modules: [], tests: [] };
  }

  private saveWebData(data: { modules: TestModuleRow[], tests: TestModuleTestRow[] }): void {
    localStorage.setItem(this.storageKey, JSON.stringify(data));
  }

  private executeWebQuery<T>(sql: string, params: any[] = []): T[] {
    const data = this.getWebData();
    
    // Simple SQL parsing for common operations
    if (sql.includes('FROM test_modules')) {
      if (sql.includes('WHERE')) {
        // Handle search operations
        const searchTerm = params[0] as string;
        if (searchTerm) {
          return data.modules.filter(m => 
            m.category.toLowerCase().includes(searchTerm.replace('%', '').toLowerCase())
          ) as T[];
        }
      }
      return data.modules as T[];
    }
    
    if (sql.includes('FROM test_module_tests')) {
      if (sql.includes('WHERE module_id = ?')) {
        const moduleId = params[0] as string;
        return data.tests.filter(t => t.module_id === moduleId) as T[];
      }
      return data.tests as T[];
    }
    
    return [];
  }

  private executeWebRun(sql: string, params: any[]): any {
    const data = this.getWebData();
    
    if (sql.includes('CREATE TABLE')) {
      // Tables are virtual in web storage
      return { success: true };
    }
    
    if (sql.includes('INSERT INTO test_modules')) {
      const [id, category, description] = params;
      data.modules.push({
        id,
        category,
        description,
        is_active: 1,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      this.saveWebData(data);
      return { lastID: id };
    }
    
    if (sql.includes('INSERT INTO test_module_tests')) {
      const [id, module_id, name, description, procedure] = params;
      data.tests.push({
        id,
        module_id,
        name,
        description,
        procedure,
        requirements: null,
        is_active: 1,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      this.saveWebData(data);
      return { lastID: id };
    }
    
    if (sql.includes('UPDATE test_modules')) {
      const moduleId = params[params.length - 1];
      const moduleIndex = data.modules.findIndex(m => m.id === moduleId);
      if (moduleIndex >= 0) {
        // Simple update logic
        data.modules[moduleIndex].updated_at = new Date().toISOString();
        this.saveWebData(data);
      }
      return { changes: 1 };
    }
    
    if (sql.includes('UPDATE test_module_tests')) {
      const testId = params[params.length - 1];
      const testIndex = data.tests.findIndex(t => t.id === testId);
      if (testIndex >= 0) {
        data.tests[testIndex].updated_at = new Date().toISOString();
        this.saveWebData(data);
      }
      return { changes: 1 };
    }
    
    if (sql.includes('DELETE FROM test_modules')) {
      const moduleId = params[0];
      data.modules = data.modules.filter(m => m.id !== moduleId);
      data.tests = data.tests.filter(t => t.module_id !== moduleId);
      this.saveWebData(data);
      return { changes: 1 };
    }
    
    if (sql.includes('DELETE FROM test_module_tests')) {
      const testId = params[0];
      data.tests = data.tests.filter(t => t.id !== testId);
      this.saveWebData(data);
      return { changes: 1 };
    }
    
    return { success: true };
  }

  async initializeTables(): Promise<void> {
    try {
      // Create test_modules table
      await this.executeRun(`
        CREATE TABLE IF NOT EXISTS test_modules (
          id TEXT PRIMARY KEY,
          category TEXT NOT NULL,
          description TEXT,
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create test_module_tests table
      await this.executeRun(`
        CREATE TABLE IF NOT EXISTS test_module_tests (
          id TEXT PRIMARY KEY,
          module_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          procedure TEXT,
          requirements TEXT,
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (module_id) REFERENCES test_modules (id) ON DELETE CASCADE
        )
      `);

      // Initialize with default test modules if empty
      await this.initializeDefaultModules();
    } catch (error) {
      console.error('Error initializing test modules tables:', error);
      throw error;
    }
  }

  private async initializeDefaultModules(): Promise<void> {
    const existing = await this.getAllModules();
    if (existing.length > 0) return;

    console.log('Initializing default test modules...');

    const defaultModules = [
      {
        category: "Aggregates",
        tests: [
          "Silt & Clay content - % by mass passing 75µm sieve",
          "Moisture Content",
          "Sand Equivalent",
          "Methylene Blue Value",
          "Flakiness Index",
          "Shape Index",
          "Los Angeles Value",
          "Aggregate Crushing Value",
          "Ten percent fines value",
          "Aggregate Impact Value",
          "Dry Bulk Density (Loose & Compacted)",
          "Particle density & Water Absorption",
          "Chloride Content",
          "Sulphate Content",
          "Magnesium Sulfate Soundness",
          "Compaction Tests",
          "Organic Impurities in Fine Aggregates for concrete"
        ]
      },
      {
        category: "Blocks",
        tests: [
          "Compressive Strength",
          "Dimensions",
          "Water Absorption",
          "Net and Gross Density"
        ]
      },
      {
        category: "Pavings",
        tests: [
          "Tensile Splitting Test",
          "Measurement",
          "Abrasion Resistance",
          "Water Absorption",
          "Slip Resistance"
        ]
      },
      {
        category: "Flags",
        tests: ["Bending Strength"]
      },
      {
        category: "Kerbs",
        tests: ["Bending Strength"]
      },
      {
        category: "Concrete",
        tests: ["Compressive Strength"]
      },
      {
        category: "Railway Ballast",
        tests: [
          "Sieve Analysis, Fine particles & Fines content",
          "Flakiness Index",
          "Shape Index",
          "Particle length",
          "Los Angeles Value",
          "Magnesium Sulfate Soundness",
          "Particle density & Water Absorption"
        ]
      }
    ];

    for (const moduleData of defaultModules) {
      await this.createModule(moduleData.category, moduleData.tests);
    }
  }

  async getAllModules(): Promise<TestModule[]> {
    try {
      const result = await this.executeQuery<TestModuleRow>(`
        SELECT * FROM test_modules 
        ORDER BY category ASC
      `);

      const modules: TestModule[] = [];
      for (const row of result) {
        const tests = await this.getModuleTests(row.id);
        modules.push({
          id: row.id,
          category: row.category,
          tests: tests.map(t => t.name),
          description: row.description,
          isActive: Boolean(row.is_active),
          createdAt: row.created_at,
          updatedAt: row.updated_at
        });
      }

      return modules;
    } catch (error) {
      console.error('Error getting all modules:', error);
      return [];
    }
  }

  async getModuleTests(moduleId: string): Promise<TestModuleTest[]> {
    try {
      const result = await this.executeQuery<TestModuleTestRow>(`
        SELECT * FROM test_module_tests 
        WHERE module_id = ? AND is_active = 1
        ORDER BY name ASC
      `, [moduleId]);

      return result.map(row => ({
        id: row.id,
        moduleId: row.module_id,
        name: row.name,
        description: row.description,
        procedure: row.procedure,
        requirements: row.requirements ? JSON.parse(row.requirements) : [],
        isActive: Boolean(row.is_active),
        createdAt: row.created_at,
        updatedAt: row.updated_at
      }));
    } catch (error) {
      console.error('Error getting module tests:', error);
      return [];
    }
  }

  async createModule(category: string, tests: string[] = [], description?: string): Promise<string> {
    try {
      const moduleId = `module_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      await this.executeRun(`
        INSERT INTO test_modules (id, category, description, is_active, created_at, updated_at)
        VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `, [moduleId, category, description || null]);

      // Add tests
      for (const testName of tests) {
        await this.addTestToModule(moduleId, testName);
      }

      return moduleId;
    } catch (error) {
      console.error('Error creating module:', error);
      throw error;
    }
  }

  async addTestToModule(moduleId: string, testName: string, description?: string, procedure?: string): Promise<string> {
    try {
      const testId = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      await this.executeRun(`
        INSERT INTO test_module_tests (id, module_id, name, description, procedure, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `, [testId, moduleId, testName, description || null, procedure || null]);

      return testId;
    } catch (error) {
      console.error('Error adding test to module:', error);
      throw error;
    }
  }

  async updateModule(moduleId: string, updates: Partial<TestModule>): Promise<void> {
    try {
      const setClause = [];
      const values = [];

      if (updates.category !== undefined) {
        setClause.push('category = ?');
        values.push(updates.category);
      }
      if (updates.description !== undefined) {
        setClause.push('description = ?');
        values.push(updates.description);
      }
      if (updates.isActive !== undefined) {
        setClause.push('is_active = ?');
        values.push(updates.isActive ? 1 : 0);
      }

      setClause.push('updated_at = CURRENT_TIMESTAMP');
      values.push(moduleId);

      await this.executeRun(`
        UPDATE test_modules 
        SET ${setClause.join(', ')}
        WHERE id = ?
      `, values);
    } catch (error) {
      console.error('Error updating module:', error);
      throw error;
    }
  }

  async updateTest(testId: string, updates: Partial<TestModuleTest>): Promise<void> {
    try {
      const setClause = [];
      const values = [];

      if (updates.name !== undefined) {
        setClause.push('name = ?');
        values.push(updates.name);
      }
      if (updates.description !== undefined) {
        setClause.push('description = ?');
        values.push(updates.description);
      }
      if (updates.procedure !== undefined) {
        setClause.push('procedure = ?');
        values.push(updates.procedure);
      }
      if (updates.requirements !== undefined) {
        setClause.push('requirements = ?');
        values.push(JSON.stringify(updates.requirements));
      }
      if (updates.isActive !== undefined) {
        setClause.push('is_active = ?');
        values.push(updates.isActive ? 1 : 0);
      }

      setClause.push('updated_at = CURRENT_TIMESTAMP');
      values.push(testId);

      await this.executeRun(`
        UPDATE test_module_tests 
        SET ${setClause.join(', ')}
        WHERE id = ?
      `, values);
    } catch (error) {
      console.error('Error updating test:', error);
      throw error;
    }
  }

  async deleteModule(moduleId: string): Promise<void> {
    try {
      await this.executeRun('DELETE FROM test_modules WHERE id = ?', [moduleId]);
    } catch (error) {
      console.error('Error deleting module:', error);
      throw error;
    }
  }

  async deleteTest(testId: string): Promise<void> {
    try {
      await this.executeRun('DELETE FROM test_module_tests WHERE id = ?', [testId]);
    } catch (error) {
      console.error('Error deleting test:', error);
      throw error;
    }
  }

  async searchModules(searchTerm: string): Promise<TestModule[]> {
    try {
      const result = await this.executeQuery<TestModuleRow>(`
        SELECT DISTINCT tm.* FROM test_modules tm
        LEFT JOIN test_module_tests tmt ON tm.id = tmt.module_id
        WHERE tm.category LIKE ? OR tmt.name LIKE ?
        ORDER BY tm.category ASC
      `, [`%${searchTerm}%`, `%${searchTerm}%`]);

      const modules: TestModule[] = [];
      for (const row of result) {
        const tests = await this.getModuleTests(row.id);
        modules.push({
          id: row.id,
          category: row.category,
          tests: tests.map(t => t.name),
          description: row.description,
          isActive: Boolean(row.is_active),
          createdAt: row.created_at,
          updatedAt: row.updated_at
        });
      }

      return modules;
    } catch (error) {
      console.error('Error searching modules:', error);
      return [];
    }
  }
}

export const testModulesService = new TestModulesService();