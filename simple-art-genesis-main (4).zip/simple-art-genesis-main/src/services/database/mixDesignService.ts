// Mix Design Service - Local SQLite operations with sync support
// Phase 1: Core Infrastructure with Unified Test Integration
// Created: 2025-01-31

import { localSyncService } from '../sync/localSyncService';
import { unifiedTestService } from './unifiedTestService';
import { dataService } from '../api';

export interface ProductType {
  id: string;
  name: string;
  category: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MixDesignField {
  id: string;
  product_type_id: string;
  field_name: string;
  field_label: string;
  field_type: 'text' | 'number' | 'select' | 'textarea' | 'date';
  field_unit?: string;
  default_value?: string;
  is_required: boolean;
  validation_rules?: string; // JSON string
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MixDesign {
  id: string;
  name: string;
  product_type_id: string;
  plant_id?: string;
  design_code?: string;
  description?: string;
  design_data: string; // JSON string
  status: 'draft' | 'active' | 'archived' | 'under_review';
  created_by: string;
  approved_by?: string;
  approved_at?: string;
  is_template: boolean;
  parent_template_id?: string;
  version_number: number;
  created_at: string;
  updated_at: string;
}

export interface MixDesignTemplate {
  id: string;
  name: string;
  product_type_id: string;
  template_data: string; // JSON string
  description?: string;
  is_public: boolean;
  created_by: string;
  approved_by?: string;
  approved_at?: string;
  usage_count: number;
  created_at: string;
  updated_at: string;
}

export interface MixDesignTrial {
  id: string;
  mix_design_id: string;
  memo_id?: string;
  test_entry_id?: string;
  plant_id?: string;
  trial_date?: string;
  trial_results?: string; // JSON string from test_entries.test_data
  performance_rating?: 'excellent' | 'good' | 'acceptable' | 'poor';
  compliance_status?: 'pending' | 'compliant' | 'non_compliant' | 'under_review';
  variance_notes?: string;
  recommended_adjustments?: string; // JSON with recommended design adjustments
  notes?: string;
  created_by: string;
  created_at: string;
  updated_at?: string;
}

class MixDesignService {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;

  // Initialize the database schema
  async initializeSchema(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Read and execute schema migration
      const schemaSQL = await this.loadMigrationFile('001_mix_design_schema.sql');
      const dataSQL = await this.loadMigrationFile('002_mix_design_migration_data.sql');
      
      await (window as any).electronAPI.dbRun(schemaSQL);
      await (window as any).electronAPI.dbRun(dataSQL);
      
      console.log('Mix Design schema initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Mix Design schema:', error);
      throw error;
    }
  }

  private async loadMigrationFile(filename: string): Promise<string> {
    // In a real implementation, this would load from the migrations folder
    // For now, we'll return empty string and rely on manual execution
    return '';
  }

  // Execute SQL query
  private async executeQuery<T>(sql: string, params: any[] = []): Promise<T[]> {
    if (this.isElectron) {
      return await (window as any).electronAPI.dbQuery(sql, params);
    } else {
      // Fallback for browser environment - would use IndexedDB or similar
      throw new Error('Browser storage not implemented for Mix Design Service');
    }
  }

  // Execute SQL command
  private async executeRun(sql: string, params: any[] = []): Promise<any> {
    if (this.isElectron) {
      return await (window as any).electronAPI.dbRun(sql, params);
    } else {
      throw new Error('Browser storage not implemented for Mix Design Service');
    }
  }

  // Product Types operations
  async getProductTypes(): Promise<ProductType[]> {
    const sql = `
      SELECT * FROM product_types 
      WHERE is_active = 1 
      ORDER BY category, name
    `;
    return await this.executeQuery<ProductType>(sql);
  }

  async createProductType(data: Omit<ProductType, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = this.generateId();
    const sql = `
      INSERT INTO product_types (id, name, category, description, is_active)
      VALUES (?, ?, ?, ?, ?)
    `;
    await this.executeRun(sql, [id, data.name, data.category, data.description, data.is_active]);
    
    // Queue for sync
    await localSyncService.queueOperation('product_types', 'INSERT', { id, ...data });
    
    return id;
  }

  // Mix Design Fields operations
  async getMixDesignFields(productTypeId: string): Promise<MixDesignField[]> {
    const sql = `
      SELECT * FROM mix_design_fields 
      WHERE product_type_id = ? AND is_active = 1 
      ORDER BY display_order, field_label
    `;
    return await this.executeQuery<MixDesignField>(sql, [productTypeId]);
  }

  async createMixDesignField(data: Omit<MixDesignField, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = this.generateId();
    const sql = `
      INSERT INTO mix_design_fields 
      (id, product_type_id, field_name, field_label, field_type, field_unit, 
       default_value, is_required, validation_rules, display_order, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await this.executeRun(sql, [
      id, data.product_type_id, data.field_name, data.field_label, data.field_type,
      data.field_unit, data.default_value, data.is_required, data.validation_rules,
      data.display_order, data.is_active
    ]);
    
    await localSyncService.queueOperation('mix_design_fields', 'INSERT', { id, ...data });
    
    return id;
  }

  // Mix Designs operations
  async getMixDesigns(filters?: {
    product_type_id?: string;
    status?: string;
    created_by?: string;
    is_template?: boolean;
  }): Promise<MixDesign[]> {
    let sql = `
      SELECT md.*, pt.name as product_type_name 
      FROM mix_designs md
      LEFT JOIN product_types pt ON md.product_type_id = pt.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (filters?.product_type_id) {
      sql += ' AND md.product_type_id = ?';
      params.push(filters.product_type_id);
    }
    if (filters?.status) {
      sql += ' AND md.status = ?';
      params.push(filters.status);
    }
    if (filters?.created_by) {
      sql += ' AND md.created_by = ?';
      params.push(filters.created_by);
    }
    if (filters?.is_template !== undefined) {
      sql += ' AND md.is_template = ?';
      params.push(filters.is_template ? 1 : 0);
    }

    sql += ' ORDER BY md.updated_at DESC';
    
    return await this.executeQuery<MixDesign>(sql, params);
  }

  async getMixDesignById(id: string): Promise<MixDesign | null> {
    const sql = `
      SELECT md.*, pt.name as product_type_name 
      FROM mix_designs md
      LEFT JOIN product_types pt ON md.product_type_id = pt.id
      WHERE md.id = ?
    `;
    const results = await this.executeQuery<MixDesign>(sql, [id]);
    return results[0] || null;
  }

  async createMixDesign(data: Omit<MixDesign, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = this.generateId();
    const sql = `
      INSERT INTO mix_designs 
      (id, name, product_type_id, plant_id, design_code, description, design_data, 
       status, created_by, is_template, parent_template_id, version_number)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await this.executeRun(sql, [
      id, data.name, data.product_type_id, data.plant_id, data.design_code,
      data.description, data.design_data, data.status, data.created_by,
      data.is_template ? 1 : 0, data.parent_template_id, data.version_number
    ]);
    
    await localSyncService.queueOperation('mix_designs', 'INSERT', { id, ...data });
    
    return id;
  }

  async updateMixDesign(id: string, data: Partial<MixDesign>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'id').map(key => `${key} = ?`);
    const values = Object.keys(data).filter(key => key !== 'id').map(key => (data as any)[key]);
    
    const sql = `UPDATE mix_designs SET ${fields.join(', ')} WHERE id = ?`;
    await this.executeRun(sql, [...values, id]);
    
    await localSyncService.queueOperation('mix_designs', 'UPDATE', { id, ...data }, id);
  }

  async deleteMixDesign(id: string): Promise<void> {
    const sql = 'DELETE FROM mix_designs WHERE id = ?';
    await this.executeRun(sql, [id]);
    
    await localSyncService.queueOperation('mix_designs', 'DELETE', { id }, id);
  }

  // Templates operations
  async getMixDesignTemplates(productTypeId?: string): Promise<MixDesignTemplate[]> {
    let sql = `
      SELECT mt.*, pt.name as product_type_name 
      FROM mix_design_templates mt
      LEFT JOIN product_types pt ON mt.product_type_id = pt.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (productTypeId) {
      sql += ' AND mt.product_type_id = ?';
      params.push(productTypeId);
    }

    sql += ' ORDER BY mt.is_public DESC, mt.usage_count DESC, mt.name';
    
    return await this.executeQuery<MixDesignTemplate>(sql, params);
  }

  async createMixDesignTemplate(data: Omit<MixDesignTemplate, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = this.generateId();
    const sql = `
      INSERT INTO mix_design_templates 
      (id, name, product_type_id, template_data, description, is_public, created_by, usage_count)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await this.executeRun(sql, [
      id, data.name, data.product_type_id, data.template_data, data.description,
      data.is_public ? 1 : 0, data.created_by, data.usage_count
    ]);
    
    await localSyncService.queueOperation('mix_design_templates', 'INSERT', { id, ...data });
    
    return id;
  }

  // Trial results operations
  async getMixDesignTrials(mixDesignId: string): Promise<MixDesignTrial[]> {
    const sql = `
      SELECT * FROM mix_design_trials 
      WHERE mix_design_id = ? 
      ORDER BY trial_date DESC, created_at DESC
    `;
    return await this.executeQuery<MixDesignTrial>(sql, [mixDesignId]);
  }

  async createMixDesignTrial(data: Omit<MixDesignTrial, 'id' | 'created_at'>): Promise<string> {
    const id = this.generateId();
    const sql = `
      INSERT INTO mix_design_trials 
      (id, mix_design_id, memo_id, test_entry_id, trial_date, trial_results, 
       performance_rating, notes, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await this.executeRun(sql, [
      id, data.mix_design_id, data.memo_id, data.test_entry_id, data.trial_date,
      data.trial_results, data.performance_rating, data.notes, data.created_by
    ]);
    
    await localSyncService.queueOperation('mix_design_trials', 'INSERT', { id, ...data });
    
    return id;
  }

  // Utility methods
  private generateId(): string {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }

  // Unified Test Integration methods
  async linkTrialToTestEntry(trialId: string, testEntryId: string): Promise<void> {
    const sql = 'UPDATE mix_design_trials SET test_entry_id = ? WHERE id = ?';
    await this.executeRun(sql, [testEntryId, trialId]);
    
    await localSyncService.queueOperation('mix_design_trials', 'UPDATE', { 
      id: trialId, 
      test_entry_id: testEntryId 
    }, trialId);
  }

  async syncTrialResultsFromTestEntry(trialId: string): Promise<void> {
    const trial = await this.getTrialById(trialId);
    if (!trial?.test_entry_id) {
      throw new Error('Trial has no linked test entry');
    }

    try {
      // Get test results from unified test service
      const testEntries = await unifiedTestService.getTestEntries({
        search: trial.test_entry_id // Use search field since test_entry_id isn't in filter interface
      });

      if (testEntries.length === 0) {
        console.warn(`No test entry found for ID: ${trial.test_entry_id}`);
        return;
      }

      const testEntry = testEntries[0];
      let testData: any = {};
      try {
        testData = typeof testEntry.test_data === 'string' ? JSON.parse(testEntry.test_data) : testEntry.test_data;
      } catch (e) {
        console.warn('Failed to parse test data, using raw data');
        testData = testEntry.test_data;
      }

      // Update trial with latest test results
      await this.updateMixDesignTrial(trialId, {
        trial_results: JSON.stringify(testData),
        trial_date: testEntry.test_date,
        plant_id: testEntry.plant_id
      });

      console.log('Trial results synced from test entry:', trial.test_entry_id);
    } catch (error) {
      console.error('Failed to sync trial results:', error);
      throw error;
    }
  }

  async createTrialFromMemo(mixDesignId: string, memoId: string, createdBy: string): Promise<string> {
    try {
      // Find test entries related to this memo
      const testEntries = await unifiedTestService.getTestEntries({
        memo_id: memoId
      });

      if (testEntries.length === 0) {
        throw new Error(`No test entries found for memo: ${memoId}`);
      }

      // Use the latest test entry
      const latestTest = testEntries[testEntries.length - 1];
      let testData: any = {};
      try {
        testData = typeof latestTest.test_data === 'string' ? JSON.parse(latestTest.test_data) : latestTest.test_data;
      } catch (e) {
        console.warn('Failed to parse test data, using raw data');
        testData = latestTest.test_data;
      }

      // Create trial linked to the test entry
      const trialId = await this.createMixDesignTrial({
        mix_design_id: mixDesignId,
        memo_id: memoId,
        test_entry_id: latestTest.id,
        plant_id: latestTest.plant_id,
        trial_date: latestTest.test_date,
        trial_results: JSON.stringify(testData),
        compliance_status: 'pending',
        created_by: createdBy
      });

      return trialId;
    } catch (error) {
      console.error('Failed to create trial from memo:', error);
      throw error;
    }
  }

  private async getTrialById(id: string): Promise<MixDesignTrial | null> {
    const sql = 'SELECT * FROM mix_design_trials WHERE id = ?';
    const results = await this.executeQuery<MixDesignTrial>(sql, [id]);
    return results[0] || null;
  }

  private async updateMixDesignTrial(id: string, data: Partial<MixDesignTrial>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'id').map(key => `${key} = ?`);
    const values = Object.keys(data).filter(key => key !== 'id').map(key => (data as any)[key]);
    
    const sql = `UPDATE mix_design_trials SET ${fields.join(', ')} WHERE id = ?`;
    await this.executeRun(sql, [...values, id]);
    
    await localSyncService.queueOperation('mix_design_trials', 'UPDATE', { id, ...data }, id);
  }

  // Reference Data Integration methods
  async getProductTypesFromReference(): Promise<ProductType[]> {
    try {
      // Note: dataService.getProductTypes doesn't exist in current interface
      // This would need to be implemented in the dataService interface
      console.warn('Product types integration not yet implemented in dataService');
    } catch (error) {
      console.warn('Failed to get product types from reference service, using local:', error);
    }

    // Fallback to local database
    return await this.getProductTypes();
  }

  async syncProductTypesFromReference(): Promise<void> {
    try {
      // Note: This would be implemented when dataService interface is extended
      console.warn('Product types sync not yet implemented in dataService');
      return;
    } catch (error) {
      console.error('Failed to sync product types from reference:', error);
    }
  }

  // Performance Analysis methods
  async analyzeTrialPerformance(trialId: string): Promise<{
    compliance: boolean;
    variances: Array<{ parameter: string; expected: number; actual: number; variance: number }>;
    recommendations: string[];
  }> {
    const trial = await this.getTrialById(trialId);
    if (!trial) {
      throw new Error('Trial not found');
    }

    const mixDesign = await this.getMixDesignById(trial.mix_design_id);
    if (!mixDesign) {
      throw new Error('Mix design not found');
    }

    try {
      const designData = JSON.parse(mixDesign.design_data);
      const trialResults = trial.trial_results ? JSON.parse(trial.trial_results) : {};
      
      const variances: Array<{ parameter: string; expected: number; actual: number; variance: number }> = [];
      const recommendations: string[] = [];
      let compliance = true;

      // Analyze key parameters
      const keyParameters = ['cement_content', 'water_content', 'fine_aggregate', 'coarse_aggregate', 'water_cement_ratio'];
      
      for (const param of keyParameters) {
        if (designData[param] && trialResults[param]) {
          const expected = parseFloat(designData[param]);
          const actual = parseFloat(trialResults[param]);
          const variance = ((actual - expected) / expected) * 100;
          
          variances.push({
            parameter: param,
            expected,
            actual,
            variance
          });

          // Check compliance (±5% tolerance for most parameters)
          const tolerance = param === 'water_cement_ratio' ? 2 : 5;
          if (Math.abs(variance) > tolerance) {
            compliance = false;
            recommendations.push(`${param}: Variance of ${variance.toFixed(1)}% exceeds tolerance of ±${tolerance}%`);
          }
        }
      }

      return {
        compliance,
        variances,
        recommendations
      };
    } catch (error) {
      console.error('Failed to analyze trial performance:', error);
      throw error;
    }
  }

  // Validation helper
  validateFieldValue(field: MixDesignField, value: any): { isValid: boolean; error?: string } {
    if (field.is_required && (value === null || value === undefined || value === '')) {
      return { isValid: false, error: `${field.field_label} is required` };
    }

    if (field.validation_rules) {
      try {
        const rules = JSON.parse(field.validation_rules);
        
        if (field.field_type === 'number' && typeof value === 'number') {
          if (rules.min !== undefined && value < rules.min) {
            return { isValid: false, error: `${field.field_label} must be at least ${rules.min}` };
          }
          if (rules.max !== undefined && value > rules.max) {
            return { isValid: false, error: `${field.field_label} must be at most ${rules.max}` };
          }
        }
        
        if (field.field_type === 'select' && rules.options && !rules.options.includes(value)) {
          return { isValid: false, error: `${field.field_label} must be one of: ${rules.options.join(', ')}` };
        }
      } catch (error) {
        console.warn('Invalid validation rules JSON:', field.validation_rules);
      }
    }

    return { isValid: true };
  }
}

export const mixDesignService = new MixDesignService();