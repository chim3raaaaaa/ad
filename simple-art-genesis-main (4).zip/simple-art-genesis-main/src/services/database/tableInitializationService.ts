/**
 * Central database table initialization service
 * Ensures all required tables exist with proper schemas
 */

interface TableSchema {
  name: string;
  sql: string;
  description: string;
}

const REQUIRED_TABLES: TableSchema[] = [
  {
    name: 'validation_rules',
    description: 'Validation rules for test data',
    sql: `
      CREATE TABLE IF NOT EXISTS validation_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        field_name TEXT NOT NULL,
        rule_type TEXT NOT NULL,
        rule_value TEXT,
        error_message TEXT,
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `
  },
  {
    name: 'conformity_check_logs',
    description: 'Logs from automated conformity checks',
    sql: `
      CREATE TABLE IF NOT EXISTS conformity_check_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        memo_ref TEXT NOT NULL,
        product TEXT NOT NULL,
        conformity_result TEXT NOT NULL,
        failed_fields TEXT,
        reason TEXT,
        checked_by TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `
  },
  {
    name: 'reference_datasets',
    description: 'Reference dataset schemas',
    sql: `
      CREATE TABLE IF NOT EXISTS reference_datasets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL,
        schema TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `
  },
  {
    name: 'reference_dataset_records',
    description: 'Reference dataset data records',
    sql: `
      CREATE TABLE IF NOT EXISTS reference_dataset_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        dataset_id INTEGER NOT NULL,
        data TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (dataset_id) REFERENCES reference_datasets(id) ON DELETE CASCADE
      )
    `
  },
  {
    name: 'version_control',
    description: 'Version control for database snapshots',
    sql: `
      CREATE TABLE IF NOT EXISTS version_control (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_name TEXT NOT NULL,
        snapshot_data TEXT NOT NULL,
        version_number INTEGER NOT NULL,
        description TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `
  },
  {
    name: 'audit_logs',
    description: 'System audit trail',
    sql: `
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        user TEXT NOT NULL,
        action TEXT NOT NULL,
        resource TEXT NOT NULL,
        details TEXT,
        ip_address TEXT,
        severity TEXT DEFAULT 'info'
      )
    `
  },
  {
    name: 'test_result_validations',
    description: 'Validation results for test data',
    sql: `
      CREATE TABLE IF NOT EXISTS test_result_validations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        memo_ref TEXT NOT NULL,
        field_name TEXT NOT NULL,
        rule_id INTEGER,
        passed INTEGER NOT NULL DEFAULT 0,
        error_message TEXT,
        validated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (rule_id) REFERENCES validation_rules(id)
      )
    `
  },
  {
    name: 'grading_limits',
    description: 'Sieve grading limits for aggregate materials',
    sql: `
      CREATE TABLE IF NOT EXISTS grading_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        material_type TEXT NOT NULL,
        standard TEXT NOT NULL,
        sieve_0_075 INTEGER,
        sieve_0_15 INTEGER,
        sieve_0_3 INTEGER,
        sieve_0_6 INTEGER,
        sieve_1_18 INTEGER,
        sieve_2_36 INTEGER,
        sieve_5 INTEGER,
        sieve_10 INTEGER,
        sieve_14 INTEGER,
        sieve_16 INTEGER,
        sieve_20 INTEGER,
        sieve_31_5 INTEGER,
        sieve_37_5 INTEGER,
        sieve_45 INTEGER,
        sieve_50 INTEGER,
        sieve_63 INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(material_type, standard)
      )
    `
  },
  {
    name: 'table_metadata',
    description: 'Metadata for dynamic tables',
    sql: `
      CREATE TABLE IF NOT EXISTS table_metadata (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_name TEXT NOT NULL UNIQUE,
        display_name TEXT,
        category TEXT,
        template_data TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `
  }
];

export class DatabaseInitializationService {
  static async initializeAllTables(): Promise<{ success: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    if (!window.electronAPI?.dbRun) {
      errors.push('Electron API not available - running in browser mode');
      return { success: false, errors };
    }

    try {
      console.log('Initializing database tables...');
      
      for (const table of REQUIRED_TABLES) {
        try {
          await window.electronAPI.dbRun(table.sql, []);
          console.log(`✓ Table '${table.name}' initialized successfully`);
        } catch (error) {
          const errorMsg = `Failed to create table '${table.name}': ${error}`;
          console.error(errorMsg);
          errors.push(errorMsg);
        }
      }

      // Create indexes for better performance
      await this.createIndexes();
      
      console.log(`Database initialization complete. ${REQUIRED_TABLES.length - errors.length}/${REQUIRED_TABLES.length} tables created successfully.`);
      
      return { 
        success: errors.length === 0, 
        errors 
      };
      
    } catch (error) {
      const errorMsg = `Database initialization failed: ${error}`;
      console.error(errorMsg);
      errors.push(errorMsg);
      return { success: false, errors };
    }
  }

  private static async createIndexes(): Promise<void> {
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_validation_rules_category ON validation_rules(category)',
      'CREATE INDEX IF NOT EXISTS idx_validation_rules_active ON validation_rules(active)',
      'CREATE INDEX IF NOT EXISTS idx_conformity_logs_memo_ref ON conformity_check_logs(memo_ref)',
      'CREATE INDEX IF NOT EXISTS idx_conformity_logs_timestamp ON conformity_check_logs(timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user)',
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action)',
      'CREATE INDEX IF NOT EXISTS idx_version_control_table ON version_control(table_name)',
      'CREATE INDEX IF NOT EXISTS idx_test_validations_memo ON test_result_validations(memo_ref)',
      'CREATE INDEX IF NOT EXISTS idx_grading_limits_material ON grading_limits(material_type)',
      'CREATE INDEX IF NOT EXISTS idx_grading_limits_standard ON grading_limits(standard)'
    ];

    for (const indexSql of indexes) {
      try {
        await window.electronAPI.dbRun(indexSql, []);
      } catch (error) {
        console.warn(`Failed to create index: ${error}`);
      }
    }
  }

  static async checkTableExists(tableName: string): Promise<boolean> {
    if (!window.electronAPI?.dbQuery) {
      return false;
    }

    try {
      const result = await window.electronAPI.dbQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        [tableName]
      );
      return result.length > 0;
    } catch (error) {
      console.error(`Error checking table existence: ${error}`);
      return false;
    }
  }

  static async getTableRowCount(tableName: string): Promise<number> {
    if (!window.electronAPI?.dbQuery) {
      return 0;
    }

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT COUNT(*) as count FROM ${tableName}`,
        []
      );
      return result[0]?.count || 0;
    } catch (error) {
      console.error(`Error getting row count for ${tableName}: ${error}`);
      return 0;
    }
  }

  static logAuditEntry(user: string, action: string, resource: string, details?: string): void {
    if (window.electronAPI?.dbRun) {
      window.electronAPI.dbRun(
        'INSERT INTO audit_logs (user, action, resource, details, ip_address) VALUES (?, ?, ?, ?, ?)',
        [user, action, resource, details || '', '127.0.0.1']
      ).catch(error => {
        console.error('Failed to log audit entry:', error);
      });
    }
  }
}