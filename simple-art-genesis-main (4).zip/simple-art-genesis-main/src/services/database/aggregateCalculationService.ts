// Database query will be handled through electronAPI
import { CalculationFormulaService } from './calculationFormulaService';

export interface MoistureContentData {
  id?: string;
  test_entry_id: string;
  ph: number; // wet mass
  ps: number; // dry mass
  w_percent: number; // calculated moisture content
  created_at?: string;
  updated_at?: string;
}

export interface SandEquivalentData {
  id?: string;
  test_entry_id: string;
  s1_readings: number[];
  s2_readings: number[];
  esv: number;
  esp: number;
  mean_esv: number;
  mean_esp: number;
  created_at?: string;
  updated_at?: string;
}

export interface MethyleneBlueData {
  id?: string;
  test_entry_id: string;
  dry_mass: number;
  volume_absorbed: number;
  dye_volume: number;
  normality: number;
  mb_value: number;
  created_at?: string;
  updated_at?: string;
}

export interface SieveRawMassData {
  id?: string;
  test_entry_id: string;
  sieve_size: string;
  cumulative_retained: number;
  percent_passing: number;
  total_sample_mass: number;
  created_at?: string;
  updated_at?: string;
}

export class AggregateCalculationService {
  static async initializeTables(): Promise<void> {
    const schemas = [
      `CREATE TABLE IF NOT EXISTS aggregate_moisture (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        test_entry_id TEXT NOT NULL,
        ph REAL NOT NULL,
        ps REAL NOT NULL,
        w_percent REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS aggregate_sand_equivalent (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        test_entry_id TEXT NOT NULL,
        s1_readings TEXT NOT NULL,
        s2_readings TEXT NOT NULL,
        esv REAL NOT NULL,
        esp REAL NOT NULL,
        mean_esv REAL NOT NULL,
        mean_esp REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS aggregate_methylene_blue (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        test_entry_id TEXT NOT NULL,
        dry_mass REAL NOT NULL,
        volume_absorbed REAL NOT NULL,
        dye_volume REAL NOT NULL,
        normality REAL NOT NULL,
        mb_value REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS aggregate_sieve_raw_masses (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        test_entry_id TEXT NOT NULL,
        sieve_size TEXT NOT NULL,
        cumulative_retained REAL NOT NULL,
        percent_passing REAL NOT NULL,
        total_sample_mass REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    try {
      if (window.electronAPI) {
        for (const schema of schemas) {
          await window.electronAPI.dbQuery(schema);
        }
      }
    } catch (error) {
      console.error('Error initializing aggregate calculation tables:', error);
      throw error;
    }
  }

  // Create Test Entry method for compatibility
  static async createTestEntry(tableName: string, entryData: any): Promise<any> {
    try {
      if (window.electronAPI) {
        // First ensure the table exists
        await window.electronAPI.dbQuery(`
          CREATE TABLE IF NOT EXISTS ${tableName} (
            id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
            memo_reference TEXT,
            sampling_date TEXT,
            material_type TEXT,
            officer_id TEXT,
            machine_no TEXT,
            location TEXT,
            sample_id TEXT,
            remarks TEXT,
            production_date TEXT,
            test_date TEXT,
            plant_id TEXT,
            aggregate_type_id TEXT,
            machine_id TEXT,
            sampling_place_id TEXT,
            moisture_condition_id TEXT,
            climatic_condition_id TEXT,
            sampled_by_id TEXT,
            sieve_075 REAL,
            sieve_150 REAL,
            sieve_300 REAL,
            sieve_600 REAL,
            sieve_118 REAL,
            sieve_236 REAL,
            sieve_475 REAL,
            sieve_950 REAL,
            sieve_2 REAL,
            sieve_5 REAL,
            sieve_10 REAL,
            sieve_14 REAL,
            sieve_20 REAL,
            sieve_28 REAL,
            sieve_40 REAL,
            specific_gravity REAL,
            bulk_density REAL,
            water_absorption REAL,
            los_angeles_abrasion REAL,
            aggregate_impact_value REAL,
            aggregate_crushing_value REAL,
            flakiness_index REAL,
            elongation_index REAL,
            soundness_test REAL,
            fineness_modulus REAL,
            moisture_content REAL,
            sand_equivalent REAL,
            methylene_blue REAL,
            bulk_density_loose REAL,
            bulk_density_compacted REAL,
            bulk_density_ssd REAL,
            bulk_density_apparent REAL,
            bulk_density_oven_dried REAL,
            organic_impurities REAL,
            grading_conformity TEXT,
            cleanliness_conformity TEXT,
            test_performed BOOLEAN,
            calculation_sheet_path TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Insert the data
        const columns = Object.keys(entryData).filter(key => entryData[key] !== undefined);
        const values = columns.map(key => entryData[key]);
        const placeholders = columns.map(() => '?').join(',');

        const result = await window.electronAPI.dbQuery(
          `INSERT INTO ${tableName} (${columns.join(',')}) VALUES (${placeholders})`,
          values
        );

        if (result.success) {
          const saved = await window.electronAPI.dbQuery(
            `SELECT * FROM ${tableName} ORDER BY created_at DESC LIMIT 1`
          );
          return saved.data?.[0];
        }
      }
      throw new Error('Failed to create test entry');
    } catch (error) {
      console.error('Error creating test entry:', error);
      throw error;
    }
  }

  // Moisture Content Methods
  static async saveMoistureContent(data: Omit<MoistureContentData, 'id' | 'created_at' | 'updated_at'>): Promise<MoistureContentData> {
    try {
      const wPercent = await CalculationFormulaService.evaluateFormula('Moisture Content', {
        Ph: data.ph,
        Ps: data.ps
      });

      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO aggregate_moisture (test_entry_id, ph, ps, w_percent) VALUES (?, ?, ?, ?)`,
          [data.test_entry_id, data.ph, data.ps, wPercent]
        );

        if (result.success) {
          const saved = await window.electronAPI.dbQuery(
            `SELECT * FROM aggregate_moisture WHERE test_entry_id = ? ORDER BY created_at DESC LIMIT 1`,
            [data.test_entry_id]
          );
          return saved.data[0];
        }
      }
      throw new Error('Failed to save moisture content data');
    } catch (error) {
      console.error('Error saving moisture content:', error);
      throw error;
    }
  }

  static async getMoistureContent(testEntryId: string): Promise<MoistureContentData | null> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM aggregate_moisture WHERE test_entry_id = ?`,
          [testEntryId]
        );
        return result.data?.[0] || null;
      }
      return null;
    } catch (error) {
      console.error('Error getting moisture content:', error);
      return null;
    }
  }

  // Sand Equivalent Methods
  static async saveSandEquivalent(data: Omit<SandEquivalentData, 'id' | 'esv' | 'esp' | 'mean_esv' | 'mean_esp' | 'created_at' | 'updated_at'>): Promise<SandEquivalentData> {
    try {
      const sumS1 = data.s1_readings.reduce((a, b) => a + b, 0);
      const sumS2 = data.s2_readings.reduce((a, b) => a + b, 0);

      const esv = await CalculationFormulaService.evaluateFormula('Sand Equivalent ESV', {
        sum_s1: sumS1,
        sum_s2: sumS2
      });

      // Calculate ESP (assuming similar formula for now)
      const esp = esv; // Can be modified for different ESP calculation
      const meanEsv = data.s1_readings.length > 0 ? esv : 0;
      const meanEsp = data.s2_readings.length > 0 ? esp : 0;

      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO aggregate_sand_equivalent (test_entry_id, s1_readings, s2_readings, esv, esp, mean_esv, mean_esp) 
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            data.test_entry_id,
            JSON.stringify(data.s1_readings),
            JSON.stringify(data.s2_readings),
            esv,
            esp,
            meanEsv,
            meanEsp
          ]
        );

        if (result.success) {
          const saved = await window.electronAPI.dbQuery(
            `SELECT * FROM aggregate_sand_equivalent WHERE test_entry_id = ? ORDER BY created_at DESC LIMIT 1`,
            [data.test_entry_id]
          );
          return {
            ...saved.data[0],
            s1_readings: JSON.parse(saved.data[0].s1_readings),
            s2_readings: JSON.parse(saved.data[0].s2_readings)
          };
        }
      }
      throw new Error('Failed to save sand equivalent data');
    } catch (error) {
      console.error('Error saving sand equivalent:', error);
      throw error;
    }
  }

  // Methylene Blue Methods
  static async saveMethyleneBlue(data: Omit<MethyleneBlueData, 'id' | 'mb_value' | 'created_at' | 'updated_at'>): Promise<MethyleneBlueData> {
    try {
      const mbValue = await CalculationFormulaService.evaluateFormula('Methylene Blue Value', {
        V1: data.dye_volume,
        normality: data.normality,
        sample_mass: data.dry_mass
      });

      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO aggregate_methylene_blue (test_entry_id, dry_mass, volume_absorbed, dye_volume, normality, mb_value) 
           VALUES (?, ?, ?, ?, ?, ?)`,
          [data.test_entry_id, data.dry_mass, data.volume_absorbed, data.dye_volume, data.normality, mbValue]
        );

        if (result.success) {
          const saved = await window.electronAPI.dbQuery(
            `SELECT * FROM aggregate_methylene_blue WHERE test_entry_id = ? ORDER BY created_at DESC LIMIT 1`,
            [data.test_entry_id]
          );
          return saved.data[0];
        }
      }
      throw new Error('Failed to save methylene blue data');
    } catch (error) {
      console.error('Error saving methylene blue:', error);
      throw error;
    }
  }

  // Sieve Analysis Methods
  static async saveSieveRawMass(data: Omit<SieveRawMassData, 'id' | 'percent_passing' | 'created_at' | 'updated_at'>): Promise<SieveRawMassData> {
    try {
      const percentPassing = await CalculationFormulaService.evaluateFormula('Percent Passing', {
        cum_retained: data.cumulative_retained,
        total_mass: data.total_sample_mass
      });

      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT OR REPLACE INTO aggregate_sieve_raw_masses 
           (test_entry_id, sieve_size, cumulative_retained, percent_passing, total_sample_mass) 
           VALUES (?, ?, ?, ?, ?)`,
          [data.test_entry_id, data.sieve_size, data.cumulative_retained, percentPassing, data.total_sample_mass]
        );

        if (result.success) {
          const saved = await window.electronAPI.dbQuery(
            `SELECT * FROM aggregate_sieve_raw_masses WHERE test_entry_id = ? AND sieve_size = ?`,
            [data.test_entry_id, data.sieve_size]
          );
          return saved.data[0];
        }
      }
      throw new Error('Failed to save sieve raw mass data');
    } catch (error) {
      console.error('Error saving sieve raw mass:', error);
      throw error;
    }
  }

  static async getSieveData(testEntryId: string): Promise<SieveRawMassData[]> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM aggregate_sieve_raw_masses WHERE test_entry_id = ? ORDER BY sieve_size`,
          [testEntryId]
        );
        return result.data || [];
      }
      return [];
    } catch (error) {
      console.error('Error getting sieve data:', error);
      return [];
    }
  }

  static async calculateFinenessModulus(testEntryId: string): Promise<number> {
    try {
      const sieveData = await this.getSieveData(testEntryId);
      const targetSizes = ['0.15', '0.30', '0.60', '1.18', '2.36'];
      
      const retainedPercentages = targetSizes.map(size => {
        const data = sieveData.find(d => d.sieve_size === size);
        return data ? (100 - data.percent_passing) : 0;
      });

      return await CalculationFormulaService.evaluateFormula('Fineness Modulus', {
        ret_150: retainedPercentages[0],
        ret_300: retainedPercentages[1],
        ret_600: retainedPercentages[2],
        ret_118: retainedPercentages[3],
        ret_236: retainedPercentages[4]
      });
    } catch (error) {
      console.error('Error calculating fineness modulus:', error);
      return 0;
    }
  }
}

export const aggregateCalculationService = new AggregateCalculationService();