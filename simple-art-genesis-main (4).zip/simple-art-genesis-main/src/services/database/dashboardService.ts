import type { DashboardLayout, DashboardWidget } from '@/types/dashboard';

declare global {
  interface Window {
    electronAPI: any;
  }
}

class DashboardService {
  async initializeTables(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      console.log('Browser environment: Using localStorage fallback for dashboard');
      return;
    }

    try {
      // Create dashboard_layouts table
      const createLayoutsTable = `
        CREATE TABLE IF NOT EXISTS dashboard_layouts (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          widgets TEXT NOT NULL, -- JSON string of widgets array
          locked INTEGER DEFAULT 0, -- 0 = false, 1 = true
          is_default INTEGER DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `;
      
      const result = await window.electronAPI.dbRun(createLayoutsTable);
      if (!result.success) {
        throw new Error(result.error);
      }

      // Create default layout if none exists
      await this.ensureDefaultLayout('user_1'); // Default user for now
    } catch (error) {
      console.error('Failed to initialize dashboard tables:', error);
      throw error;
    }
  }

  async ensureDefaultLayout(userId: string): Promise<void> {
    const existingLayouts = await this.getUserLayouts(userId);
    
    if (existingLayouts.length === 0) {
      const defaultLayout: DashboardLayout = {
        id: `default_${userId}_${Date.now()}`,
        user_id: userId,
        name: 'Default Layout',
        widgets: this.getDefaultWidgets(),
        locked: false,
        is_default: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      await this.saveLayout(defaultLayout);
    }
  }

  private getDefaultWidgets(): DashboardWidget[] {
    return [
      { id: "welcome-header", type: "welcome", title: "Welcome", x: 0, y: 0, w: 5, h: 3, minW: 3, minH: 2, enabled: true },
      { id: "calendar", type: "calendar", title: "Upcoming Tests", x: 5, y: 0, w: 7, h: 3, minW: 4, minH: 2, enabled: true },
      { id: "active-memos", type: "kpi", title: "Active Memos", x: 0, y: 3, w: 2, h: 2, minW: 1, minH: 1, enabled: true },
      { id: "pending-tests", type: "kpi", title: "Pending Tests", x: 2, y: 3, w: 2, h: 2, minW: 1, minH: 1, enabled: true },
      { id: "tests-in-progress", type: "kpi", title: "Tests in Progress", x: 4, y: 3, w: 2, h: 2, minW: 1, minH: 1, enabled: true },
      { id: "completed-today", type: "kpi", title: "Completed Today", x: 6, y: 3, w: 2, h: 2, minW: 1, minH: 1, enabled: true },
      { id: "connection-status", type: "connection", title: "Connection Status", x: 8, y: 3, w: 2, h: 2, minW: 1, minH: 1, enabled: true },
      { id: "test-requests-chart", type: "chart", title: "Test Requests Status", x: 0, y: 5, w: 4, h: 6, minW: 3, minH: 4, enabled: true },
      { id: "test-results-chart", type: "chart", title: "Test Status Distribution", x: 4, y: 5, w: 4, h: 6, minW: 3, minH: 4, enabled: true },
      { id: "monthly-trends-chart", type: "chart", title: "Performance Trends", x: 8, y: 5, w: 4, h: 6, minW: 3, minH: 4, enabled: true }
    ];
  }

  async getUserLayouts(userId: string): Promise<DashboardLayout[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      // Fallback to localStorage
      return this.getLayoutsFromLocalStorage(userId);
    }

    try {
      const sql = 'SELECT * FROM dashboard_layouts WHERE user_id = ? ORDER BY is_default DESC, created_at DESC';
      const result = await window.electronAPI.dbQuery(sql, [userId]);
      
      if (!result.success) {
        throw new Error(result.error);
      }

      return result.data.map(this.mapRowToLayout);
    } catch (error) {
      console.error('Failed to get user layouts:', error);
      return this.getLayoutsFromLocalStorage(userId);
    }
  }

  async getCurrentLayout(userId: string): Promise<DashboardLayout | null> {
    const layouts = await this.getUserLayouts(userId);
    return layouts.find(l => l.is_default) || layouts[0] || null;
  }

  async saveLayout(layout: DashboardLayout): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      this.saveLayoutToLocalStorage(layout);
      return;
    }

    try {
      const sql = `
        INSERT OR REPLACE INTO dashboard_layouts 
        (id, user_id, name, widgets, locked, is_default, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      const params = [
        layout.id,
        layout.user_id,
        layout.name,
        JSON.stringify(layout.widgets),
        layout.locked ? 1 : 0,
        layout.is_default ? 1 : 0,
        layout.created_at,
        layout.updated_at
      ];

      const result = await window.electronAPI.dbRun(sql, params);
      if (!result.success) {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Failed to save layout:', error);
      this.saveLayoutToLocalStorage(layout);
    }
  }

  async updateLayoutLockStatus(layoutId: string, locked: boolean): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      const layouts = this.getLayoutsFromLocalStorage('user_1');
      const updatedLayouts = layouts.map(layout => 
        layout.id === layoutId 
          ? { ...layout, locked, updated_at: new Date().toISOString() }
          : layout
      );
      localStorage.setItem('dashboard-layouts', JSON.stringify(updatedLayouts));
      return;
    }

    try {
      const sql = 'UPDATE dashboard_layouts SET locked = ?, updated_at = ? WHERE id = ?';
      const result = await window.electronAPI.dbRun(sql, [locked ? 1 : 0, new Date().toISOString(), layoutId]);
      
      if (!result.success) {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Failed to update lock status:', error);
      throw error;
    }
  }

  async removeWidget(userId: string, layoutId: string, widgetId: string): Promise<void> {
    const layouts = await this.getUserLayouts(userId);
    const layout = layouts.find(l => l.id === layoutId);
    
    if (!layout) {
      throw new Error('Layout not found');
    }

    if (layout.locked) {
      throw new Error('Cannot modify locked layout');
    }

    const updatedLayout: DashboardLayout = {
      ...layout,
      widgets: layout.widgets.map(widget => 
        widget.id === widgetId 
          ? { ...widget, enabled: false }
          : widget
      ),
      updated_at: new Date().toISOString()
    };

    await this.saveLayout(updatedLayout);
  }

  async addWidget(userId: string, layoutId: string, widget: DashboardWidget): Promise<void> {
    console.log('dashboardService.addWidget called with:', { userId, layoutId, widget });
    
    const layouts = await this.getUserLayouts(userId);
    console.log('Retrieved layouts:', layouts);
    
    const layout = layouts.find(l => l.id === layoutId);
    console.log('Found layout:', layout);
    
    if (!layout) {
      console.error('Layout not found for ID:', layoutId);
      throw new Error('Layout not found');
    }

    if (layout.locked) {
      console.error('Layout is locked:', layoutId);
      throw new Error('Cannot modify locked layout');
    }

    const updatedLayout: DashboardLayout = {
      ...layout,
      widgets: [...layout.widgets.filter(w => w.id !== widget.id), widget],
      updated_at: new Date().toISOString()
    };
    
    console.log('About to save updated layout:', updatedLayout);
    await this.saveLayout(updatedLayout);
    console.log('Layout saved successfully');
  }

  async updateWidgetPositions(userId: string, layoutId: string, widgets: DashboardWidget[]): Promise<void> {
    const layouts = await this.getUserLayouts(userId);
    const layout = layouts.find(l => l.id === layoutId);
    
    if (!layout) {
      throw new Error('Layout not found');
    }

    if (layout.locked) {
      throw new Error('Cannot modify locked layout');
    }

    const updatedLayout: DashboardLayout = {
      ...layout,
      widgets,
      updated_at: new Date().toISOString()
    };

    await this.saveLayout(updatedLayout);
  }

  // LocalStorage fallback methods
  private getLayoutsFromLocalStorage(userId: string): DashboardLayout[] {
    try {
      const saved = localStorage.getItem('dashboard-layouts');
      if (!saved) return [];
      
      const allLayouts = JSON.parse(saved);
      return allLayouts.filter((l: DashboardLayout) => l.user_id === userId);
    } catch {
      return [];
    }
  }

  private saveLayoutToLocalStorage(layout: DashboardLayout): void {
    try {
      const existing = localStorage.getItem('dashboard-layouts');
      const layouts = existing ? JSON.parse(existing) : [];
      
      const updatedLayouts = layouts.filter((l: DashboardLayout) => l.id !== layout.id);
      updatedLayouts.push(layout);
      
      localStorage.setItem('dashboard-layouts', JSON.stringify(updatedLayouts));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  }

  private mapRowToLayout(row: any): DashboardLayout {
    return {
      id: row.id,
      user_id: row.user_id,
      name: row.name,
      widgets: JSON.parse(row.widgets),
      locked: Boolean(row.locked),
      is_default: Boolean(row.is_default),
      created_at: row.created_at,
      updated_at: row.updated_at
    };
  }
}

export const dashboardService = new DashboardService();