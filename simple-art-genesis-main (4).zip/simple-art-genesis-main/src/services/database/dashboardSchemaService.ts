declare global {
  interface Window {
    electronAPI: any;
  }
}

export class DashboardSchemaService {
  async initializeDashboardTables(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) {
      console.warn('Dashboard schema initialization requires Electron environment');
      return;
    }

    try {
      // Dashboard Layouts Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS dashboard_layouts (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          is_default BOOLEAN DEFAULT FALSE,
          is_shared BOOLEAN DEFAULT FALSE,
          layout_config TEXT NOT NULL,
          theme_config TEXT DEFAULT '{}',
          permissions TEXT DEFAULT '{}',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          created_by TEXT NOT NULL,
          last_modified_by TEXT
        )
      `);

      // Dashboard Widgets Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS dashboard_widgets (
          id TEXT PRIMARY KEY,
          layout_id TEXT NOT NULL,
          widget_type TEXT NOT NULL,
          title TEXT NOT NULL,
          description TEXT,
          position_x INTEGER NOT NULL,
          position_y INTEGER NOT NULL,
          width INTEGER NOT NULL,
          height INTEGER NOT NULL,
          min_width INTEGER DEFAULT 2,
          min_height INTEGER DEFAULT 2,
          config TEXT DEFAULT '{}',
          data_source TEXT,
          refresh_interval INTEGER DEFAULT 300000,
          is_enabled BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (layout_id) REFERENCES dashboard_layouts(id) ON DELETE CASCADE
        )
      `);

      // Dashboard Data Sources Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS dashboard_data_sources (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          description TEXT,
          source_type TEXT NOT NULL CHECK (source_type IN ('sql', 'api', 'calculated', 'realtime')),
          query_config TEXT NOT NULL,
          cache_duration INTEGER DEFAULT 300000,
          last_cached DATETIME,
          cached_data TEXT,
          is_active BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Dashboard Permissions Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS dashboard_permissions (
          id TEXT PRIMARY KEY,
          layout_id TEXT NOT NULL,
          user_id TEXT,
          role TEXT,
          permission_type TEXT NOT NULL CHECK (permission_type IN ('view', 'edit', 'admin', 'owner')),
          granted_by TEXT NOT NULL,
          granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (layout_id) REFERENCES dashboard_layouts(id) ON DELETE CASCADE
        )
      `);

      // Test Schedule Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS test_schedule (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          test_type TEXT NOT NULL,
          production_date DATE NOT NULL,
          scheduled_date DATE NOT NULL,
          due_date DATE NOT NULL,
          priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'critical')),
          status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'completed', 'overdue', 'cancelled')),
          assigned_to TEXT,
          plant_location TEXT,
          product_type TEXT,
          batch_number TEXT,
          notes TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          completed_at DATETIME,
          completed_by TEXT,
          FOREIGN KEY (memo_id) REFERENCES memos(id) ON DELETE CASCADE
        )
      `);

      // Test Completions Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS test_completions (
          id TEXT PRIMARY KEY,
          schedule_id TEXT NOT NULL,
          actual_completion_date DATETIME NOT NULL,
          completed_by TEXT NOT NULL,
          test_results TEXT,
          compliance_status TEXT CHECK (compliance_status IN ('pass', 'fail', 'pending', 'retest')),
          notes TEXT,
          attachments TEXT DEFAULT '[]',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (schedule_id) REFERENCES test_schedule(id) ON DELETE CASCADE
        )
      `);

      // Test Reminders Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS test_reminders (
          id TEXT PRIMARY KEY,
          schedule_id TEXT NOT NULL,
          reminder_type TEXT NOT NULL CHECK (reminder_type IN ('email', 'sms', 'push', 'dashboard')),
          reminder_time DATETIME NOT NULL,
          message TEXT NOT NULL,
          recipient TEXT NOT NULL,
          sent_status BOOLEAN DEFAULT FALSE,
          sent_at DATETIME,
          error_message TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (schedule_id) REFERENCES test_schedule(id) ON DELETE CASCADE
        )
      `);

      // Test Calendar Settings Table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS test_calendar_settings (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL UNIQUE,
          default_view TEXT DEFAULT 'month' CHECK (default_view IN ('day', 'week', 'month', 'year')),
          working_days TEXT DEFAULT '["monday","tuesday","wednesday","thursday","friday"]',
          working_hours_start TIME DEFAULT '08:00',
          working_hours_end TIME DEFAULT '17:00',
          notification_preferences TEXT DEFAULT '{}',
          auto_schedule BOOLEAN DEFAULT TRUE,
          default_priority TEXT DEFAULT 'normal',
          timezone TEXT DEFAULT 'UTC',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create indexes for better performance
      await window.electronAPI.dbQuery(`CREATE INDEX IF NOT EXISTS idx_dashboard_layouts_user_id ON dashboard_layouts(user_id)`);
      await window.electronAPI.dbQuery(`CREATE INDEX IF NOT EXISTS idx_dashboard_widgets_layout_id ON dashboard_widgets(layout_id)`);
      await window.electronAPI.dbQuery(`CREATE INDEX IF NOT EXISTS idx_test_schedule_memo_id ON test_schedule(memo_id)`);
      await window.electronAPI.dbQuery(`CREATE INDEX IF NOT EXISTS idx_test_schedule_due_date ON test_schedule(due_date)`);
      await window.electronAPI.dbQuery(`CREATE INDEX IF NOT EXISTS idx_test_schedule_status ON test_schedule(status)`);

      console.log('Dashboard and Test Calendar schema initialized successfully');
    } catch (error) {
      console.error('Error initializing dashboard schema:', error);
      throw error;
    }
  }

  async seedDefaultData(userId: string): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    
    if (!isElectron) return;

    try {
      // Check if user already has layouts
      const existingLayouts = await window.electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM dashboard_layouts WHERE user_id = ?',
        [userId]
      );

      if (existingLayouts.success && existingLayouts.data[0]?.count > 0) {
        return; // User already has layouts
      }

      // Create default layout
      const defaultLayoutId = `layout_${userId}_default_${Date.now()}`;
      
      await window.electronAPI.dbQuery(`
        INSERT INTO dashboard_layouts (
          id, user_id, name, description, is_default, layout_config, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        defaultLayoutId,
        userId,
        'Default Dashboard',
        'Your main dashboard view',
        true,
        JSON.stringify({
          cols: 12,
          rowHeight: 60,
          breakpoints: { lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }
        }),
        userId
      ]);

      // Add default widgets
      const defaultWidgets = [
        {
          id: `widget_${Date.now()}_1`,
          widget_type: 'kpi',
          title: 'Total Memos',
          description: 'Total number of memos this month',
          position_x: 0,
          position_y: 0,
          width: 3,
          height: 2,
          config: JSON.stringify({
            metric: 'totalMemos',
            format: 'number',
            target: 100
          }),
          data_source: 'memos_count'
        },
        {
          id: `widget_${Date.now()}_2`,
          widget_type: 'kpi',
          title: 'Tests Due Today',
          description: 'Number of tests due today',
          position_x: 3,
          position_y: 0,
          width: 3,
          height: 2,
          config: JSON.stringify({
            metric: 'testsDueToday',
            format: 'number',
            alert: true
          }),
          data_source: 'tests_due_today'
        },
        {
          id: `widget_${Date.now()}_3`,
          widget_type: 'chart',
          title: 'Monthly Test Trends',
          description: 'Test completion trends over time',
          position_x: 0,
          position_y: 2,
          width: 6,
          height: 4,
          config: JSON.stringify({
            chartType: 'line',
            xAxis: 'month',
            yAxis: 'tests'
          }),
          data_source: 'monthly_trends'
        }
      ];

      for (const widget of defaultWidgets) {
        await window.electronAPI.dbQuery(`
          INSERT INTO dashboard_widgets (
            id, layout_id, widget_type, title, description,
            position_x, position_y, width, height, config, data_source
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          widget.id,
          defaultLayoutId,
          widget.widget_type,
          widget.title,
          widget.description,
          widget.position_x,
          widget.position_y,
          widget.width,
          widget.height,
          widget.config,
          widget.data_source
        ]);
      }

      // Create default calendar settings
      await window.electronAPI.dbQuery(`
        INSERT OR IGNORE INTO test_calendar_settings (
          id, user_id, notification_preferences
        ) VALUES (?, ?, ?)
      `, [
        `settings_${userId}_${Date.now()}`,
        userId,
        JSON.stringify({
          email: true,
          dashboard: true,
          reminderHours: [24, 2]
        })
      ]);

      console.log('Default dashboard data seeded successfully');
    } catch (error) {
      console.error('Error seeding default data:', error);
      throw error;
    }
  }
}

export const dashboardSchemaService = new DashboardSchemaService();