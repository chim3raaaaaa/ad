// Database Schema Management Service
import type { IDataService } from '../api/interface';

export interface TableSchema {
  name: string;
  columns: ColumnSchema[];
  indexes: IndexSchema[];
  foreignKeys: ForeignKeySchema[];
  created_at: string;
  updated_at: string;
}

export interface ColumnSchema {
  name: string;
  type: 'TEXT' | 'INTEGER' | 'REAL' | 'BLOB' | 'BOOLEAN' | 'DATETIME';
  nullable: boolean;
  defaultValue?: string;
  primaryKey: boolean;
  unique: boolean;
  autoIncrement: boolean;
  check?: string;
  description?: string;
}

export interface IndexSchema {
  name: string;
  columns: string[];
  unique: boolean;
  partial?: string;
}

export interface ForeignKeySchema {
  name: string;
  column: string;
  referencedTable: string;
  referencedColumn: string;
  onDelete: 'CASCADE' | 'SET NULL' | 'RESTRICT' | 'NO ACTION';
  onUpdate: 'CASCADE' | 'SET NULL' | 'RESTRICT' | 'NO ACTION';
}

export interface DataRelationship {
  id: string;
  sourceTable: string;
  sourceColumn: string;
  targetTable: string;
  targetColumn: string;
  relationshipType: '1:1' | '1:N' | 'N:1' | 'N:N' | 'lookup';
  cascadeDelete: boolean;
  description?: string;
  created_at: string;
}

export class SchemaService {
  constructor(private dataService: IDataService) {}

  // Table Management
  async getTables(): Promise<string[]> {
    return await this.dataService.getTables();
  }

  async getTableSchema(tableName: string): Promise<TableSchema | null> {
    return await this.dataService.getTableSchema(tableName);
  }

  async createTable(schema: Omit<TableSchema, 'created_at' | 'updated_at'>): Promise<void> {
    const fullSchema = {
      ...schema,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    const sql = this.generateCreateTableSQL(fullSchema);
    await this.dataService.executeSQL(sql);
    
    // Create indexes
    for (const index of schema.indexes || []) {
      const indexSQL = this.generateCreateIndexSQL(schema.name, index);
      await this.dataService.executeSQL(indexSQL);
    }
  }

  async dropTable(tableName: string): Promise<void> {
    const sql = `DROP TABLE IF EXISTS ${tableName}`;
    await this.dataService.executeSQL(sql);
  }

  // Column Management
  async addColumn(tableName: string, column: ColumnSchema): Promise<void> {
    const sql = `ALTER TABLE ${tableName} ADD COLUMN ${this.generateColumnDefinition(column)}`;
    await this.dataService.executeSQL(sql);
  }

  async dropColumn(tableName: string, columnName: string): Promise<void> {
    // SQLite doesn't support DROP COLUMN directly, need to recreate table
    const schema = await this.getTableSchema(tableName);
    if (!schema) throw new Error(`Table ${tableName} not found`);

    const newSchema = {
      ...schema,
      columns: schema.columns.filter(col => col.name !== columnName)
    };

    await this.recreateTable(tableName, newSchema);
  }

  async modifyColumn(tableName: string, columnName: string, newColumn: ColumnSchema): Promise<void> {
    const schema = await this.getTableSchema(tableName);
    if (!schema) throw new Error(`Table ${tableName} not found`);

    const newSchema = {
      ...schema,
      columns: schema.columns.map(col => 
        col.name === columnName ? newColumn : col
      )
    };

    await this.recreateTable(tableName, newSchema);
  }

  // Relationship Management
  async getRelationships(): Promise<DataRelationship[]> {
    return await this.dataService.getDataRelationships();
  }

  async createRelationship(relationship: Omit<DataRelationship, 'id' | 'created_at'>): Promise<DataRelationship> {
    const newRelationship: DataRelationship = {
      ...relationship,
      id: `rel_${Date.now()}`,
      created_at: new Date().toISOString()
    };

    await this.dataService.createDataRelationship(newRelationship);
    return newRelationship;
  }

  async deleteRelationship(id: string): Promise<void> {
    await this.dataService.deleteDataRelationship(id);
  }

  // Utility Methods
  private generateCreateTableSQL(schema: TableSchema): string {
    const columns = schema.columns.map(col => this.generateColumnDefinition(col));
    const primaryKeys = schema.columns.filter(col => col.primaryKey).map(col => col.name);
    
    if (primaryKeys.length > 1) {
      columns.push(`PRIMARY KEY (${primaryKeys.join(', ')})`);
    }

    return `CREATE TABLE ${schema.name} (\n  ${columns.join(',\n  ')}\n)`;
  }

  private generateColumnDefinition(column: ColumnSchema): string {
    let definition = `${column.name} ${column.type}`;
    
    if (column.primaryKey && !column.autoIncrement) {
      definition += ' PRIMARY KEY';
    }
    
    if (column.autoIncrement) {
      definition += ' PRIMARY KEY AUTOINCREMENT';
    }
    
    if (!column.nullable) {
      definition += ' NOT NULL';
    }
    
    if (column.unique && !column.primaryKey) {
      definition += ' UNIQUE';
    }
    
    if (column.defaultValue !== undefined) {
      definition += ` DEFAULT ${column.defaultValue}`;
    }
    
    if (column.check) {
      definition += ` CHECK(${column.check})`;
    }

    return definition;
  }

  private generateCreateIndexSQL(tableName: string, index: IndexSchema): string {
    const uniqueClause = index.unique ? 'UNIQUE ' : '';
    const partialClause = index.partial ? ` WHERE ${index.partial}` : '';
    
    return `CREATE ${uniqueClause}INDEX ${index.name} ON ${tableName} (${index.columns.join(', ')})${partialClause}`;
  }

  private async recreateTable(tableName: string, newSchema: TableSchema): Promise<void> {
    const tempTableName = `${tableName}_temp`;
    
    // Create new table with temporary name
    const createSQL = this.generateCreateTableSQL({ ...newSchema, name: tempTableName });
    await this.dataService.executeSQL(createSQL);
    
    // Copy data from old table to new table
    const commonColumns = newSchema.columns.map(col => col.name).join(', ');
    const copySQL = `INSERT INTO ${tempTableName} (${commonColumns}) SELECT ${commonColumns} FROM ${tableName}`;
    await this.dataService.executeSQL(copySQL);
    
    // Drop old table
    await this.dataService.executeSQL(`DROP TABLE ${tableName}`);
    
    // Rename new table
    await this.dataService.executeSQL(`ALTER TABLE ${tempTableName} RENAME TO ${tableName}`);
    
    // Recreate indexes
    for (const index of newSchema.indexes || []) {
      const indexSQL = this.generateCreateIndexSQL(tableName, index);
      await this.dataService.executeSQL(indexSQL);
    }
  }

  // Data Dictionary
  async getDataDictionary(): Promise<{
    tables: TableSchema[];
    relationships: DataRelationship[];
    statistics: {
      totalTables: number;
      totalColumns: number;
      totalRelationships: number;
    };
  }> {
    const tableNames = await this.getTables();
    const tables: TableSchema[] = [];
    
    for (const tableName of tableNames) {
      const schema = await this.getTableSchema(tableName);
      if (schema) {
        tables.push(schema);
      }
    }
    
    const relationships = await this.getRelationships();
    
    return {
      tables,
      relationships,
      statistics: {
        totalTables: tables.length,
        totalColumns: tables.reduce((sum, table) => sum + table.columns.length, 0),
        totalRelationships: relationships.length
      }
    };
  }

  // Export schema as SQL
  async exportSchema(): Promise<string> {
    const dictionary = await this.getDataDictionary();
    const sqlStatements: string[] = [];
    
    // Add table creation statements
    for (const table of dictionary.tables) {
      sqlStatements.push(this.generateCreateTableSQL(table));
      
      // Add index creation statements
      for (const index of table.indexes) {
        sqlStatements.push(this.generateCreateIndexSQL(table.name, index));
      }
    }
    
    return sqlStatements.join(';\n\n') + ';';
  }
}

// Export singleton instance
export const schemaService = new SchemaService(
  // This will be injected at runtime
  null as any
);