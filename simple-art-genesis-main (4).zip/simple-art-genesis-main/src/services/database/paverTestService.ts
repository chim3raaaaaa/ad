import { toast } from '@/hooks/use-toast';

export interface PaverTestData {
  id: string;
  memo_reference: string;
  plant_id: string;
  product_type: string;
  test_date: string;
  officer_id: string;
  machine_id?: string;
  
  // Paver-specific parameters
  thickness: number;
  length: number;
  width: number;
  compressive_strength: number;
  water_absorption: number;
  abrasion_resistance: number;
  slip_resistance: number;
  freeze_thaw_cycles: number;
  
  // Results
  pass_fail_status: 'pass' | 'fail' | 'pending';
  compliance_notes?: string;
  
  created_at: string;
  updated_at: string;
}

class PaverTestService {
  private storageKey = 'paver_databases';

  async getPlantDatabases(plantId: string): Promise<any[]> {
    try {
      const stored = localStorage.getItem(this.storageKey);
      const allDatabases = stored ? JSON.parse(stored) : [];
      return allDatabases.filter((db: any) => db.plant_id === plantId);
    } catch (error) {
      console.error('Error fetching paver databases:', error);
      return [];
    }
  }

  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const tableName = `paver_tests_${plantId}_${productType}`.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    const database = {
      id: `paver_db_${Date.now()}`,
      name: `Paver Tests - ${productType}`,
      plant_id: plantId,
      product_type: productType,
      table_name: tableName,
      created_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(this.storageKey);
    const databases = stored ? JSON.parse(stored) : [];
    databases.push(database);
    localStorage.setItem(this.storageKey, JSON.stringify(databases));
    localStorage.setItem(tableName, JSON.stringify([]));

    toast({
      title: "Database Created",
      description: `Paver test database created for ${productType}`
    });

    return database.id;
  }

  async getTestEntries(tableName: string, filters?: Record<string, any>): Promise<PaverTestData[]> {
    try {
      const stored = localStorage.getItem(tableName);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      return [];
    }
  }

  async createTestEntry(tableName: string, testData: Omit<PaverTestData, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const entry: PaverTestData = {
      ...testData,
      id: `paver_test_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    entries.push(entry);
    localStorage.setItem(tableName, JSON.stringify(entries));

    toast({
      title: "Test Entry Created",
      description: `Paver test entry created successfully`
    });

    return entry.id;
  }

  async updateTestEntry(tableName: string, id: string, updates: Partial<PaverTestData>): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    const index = entries.findIndex((entry: any) => entry.id === id);
    
    if (index !== -1) {
      entries[index] = { ...entries[index], ...updates, updated_at: new Date().toISOString() };
      localStorage.setItem(tableName, JSON.stringify(entries));
    }
  }

  async deleteTestEntry(tableName: string, id: string): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    const filtered = entries.filter((entry: any) => entry.id !== id);
    localStorage.setItem(tableName, JSON.stringify(filtered));
  }

  async validateTestData(testData: PaverTestData): Promise<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    if (testData.compressive_strength < 35) {
      errors.push('Compressive strength must be at least 35 MPa');
    }
    if (testData.water_absorption > 6) {
      errors.push('Water absorption must not exceed 6%');
    }
    if (testData.thickness < 60) {
      errors.push('Minimum thickness is 60mm');
    }

    return { isValid: errors.length === 0, errors };
  }
}

export const paverTestService = new PaverTestService();