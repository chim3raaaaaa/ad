import { toast } from '@/hooks/use-toast';

// Aggregate Test Database Interfaces
export interface AggregateTestEntry {
  id?: string;
  memo_reference?: string;
  production_date?: string;
  test_date?: string;
  sampling_date?: string;
  plant_id?: string;
  officer_id?: string;
  aggregate_type_id?: string;
  machine_id?: string;
  machine_no?: string;
  sampling_place_id?: string;
  location?: string;
  moisture_condition_id?: string;
  climatic_condition_id?: string;
  sampled_by_id?: string;
  
  // Basic info compatibility
  material_type?: string;
  sample_id?: string;
  remarks?: string;
  
  // Sieve analysis
  sieve_0_075?: number | null;
  sieve_0_15?: number | null;
  sieve_0_3?: number | null;
  sieve_0_6?: number | null;
  sieve_1_18?: number | null;
  sieve_2_36?: number | null;
  sieve_5?: number | null;
  sieve_10?: number | null;
  sieve_075?: number | null;
  sieve_150?: number | null;
  sieve_300?: number | null;
  sieve_600?: number | null;
  sieve_118?: number | null;
  sieve_236?: number | null;
  sieve_475?: number | null;
  sieve_950?: number | null;
  sieve_2?: number | null;
  sieve_14?: number | null;
  sieve_20?: number | null;
  sieve_28?: number | null;
  sieve_40?: number | null;
  
  // Physical properties
  specific_gravity?: number | null;
  bulk_density?: number | null;
  water_absorption?: number | null;
  moisture_content?: number | null;
  fineness_modulus?: number | null;
  sand_equivalent?: number | null;
  methylene_blue?: number | null;
  
  // Test results
  los_angeles_abrasion?: number | null;
  aggregate_impact_value?: number | null;
  aggregate_crushing_value?: number | null;
  flakiness_index?: number | null;
  elongation_index?: number | null;
  soundness_test?: number | null;
  
  // Density properties
  bulk_density_loose?: number | null;
  bulk_density_compacted?: number | null;
  bulk_density_ssd?: number | null;
  bulk_density_apparent?: number | null;
  bulk_density_oven_dried?: number | null;
  organic_impurities?: number | null;
  
  // Results
  observations?: string | null;
  grading_conformity?: 'pass' | 'fail' | 'pending';
  cleanliness_conformity?: 'pass' | 'fail' | 'pending';
  test_performed?: boolean;
  calculation_sheet_path?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface PlantTestDatabase {
  plant_id: string;
  plant_name: string;
  category: string;
  product_type: string;
  table_name: string;
  entry_count: number;
  last_updated: string;
}

class AggregateTestService {
  // Create plant-specific database
  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const tableName = `aggregate_tests_${plantId.toLowerCase().replace(/\s+/g, '_')}_${productType.toLowerCase().replace(/\s+/g, '_')}`;
    
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.createElectronTable(tableName);
      } else {
        await this.createBrowserTable(tableName);
      }
      
      toast({
        title: "Database Created",
        description: `Created aggregate test database for ${plantName} - ${productType}`
      });
      
      return tableName;
    } catch (error) {
      console.error('Error creating plant database:', error);
      toast({
        title: "Database Creation Failed",
        description: "Failed to create aggregate test database",
        variant: "destructive"
      });
      throw error;
    }
  }

  private async createElectronTable(tableName: string): Promise<void> {
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id TEXT PRIMARY KEY,
        memo_reference TEXT NOT NULL,
        
        -- Dates
        production_date TEXT NOT NULL,
        test_date TEXT NOT NULL,
        sampling_date TEXT NOT NULL,
        
        -- Reference Info
        plant_id TEXT NOT NULL,
        officer_id TEXT NOT NULL,
        aggregate_type_id TEXT NOT NULL,
        machine_id TEXT,
        
        -- Sampling Info
        sampling_place_id TEXT NOT NULL,
        moisture_condition_id TEXT NOT NULL,
        climatic_condition_id TEXT NOT NULL,
        sampled_by_id TEXT NOT NULL,
        
        -- Test Details - Sieve Analysis
        sieve_0_075 REAL,
        sieve_0_15 REAL,
        sieve_0_3 REAL,
        sieve_0_6 REAL,
        sieve_1_18 REAL,
        sieve_2_36 REAL,
        sieve_5 REAL,
        sieve_10 REAL,
        
        -- Physical Properties
        moisture_content REAL,
        fineness_modulus REAL,
        sand_equivalent REAL,
        methylene_blue REAL,
        
        -- Density Properties
        bulk_density_loose REAL,
        bulk_density_compacted REAL,
        bulk_density_ssd REAL,
        bulk_density_apparent REAL,
        bulk_density_oven_dried REAL,
        
        -- Other Properties
        water_absorption REAL,
        organic_impurities TEXT,
        
        -- Results
        observations TEXT,
        grading_conformity TEXT DEFAULT 'pending' CHECK (grading_conformity IN ('conforming', 'non_conforming', 'pending')),
        cleanliness_conformity TEXT DEFAULT 'pending' CHECK (cleanliness_conformity IN ('conforming', 'non_conforming', 'pending')),
        
        -- Test Status
        test_performed BOOLEAN DEFAULT 0,
        
        -- PDF Attachment
        calculation_sheet_path TEXT,
        
        -- Metadata
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        created_by TEXT
      )
    `;
    
    await (window as any).electronAPI.executeSQL(createTableSQL);
  }

  private async createBrowserTable(tableName: string): Promise<void> {
    // For browser storage, create empty array in localStorage
    if (!localStorage.getItem(tableName)) {
      localStorage.setItem(tableName, JSON.stringify([]));
    }
  }

  // Get all plant databases for aggregates
  async getPlantDatabases(): Promise<PlantTestDatabase[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        return await this.getElectronPlantDatabases();
      } else {
        return await this.getBrowserPlantDatabases();
      }
    } catch (error) {
      console.error('Error fetching plant databases:', error);
      return [];
    }
  }

  private async getElectronPlantDatabases(): Promise<PlantTestDatabase[]> {
    try {
      // Get all tables that match the aggregate test pattern
      const tables = await (window as any).electronAPI.executeSQL(
        "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'aggregate_tests_%'"
      );
      
      const databases: PlantTestDatabase[] = [];
      
      for (const table of tables) {
        const tableName = table.name;
        const parts = tableName.replace('aggregate_tests_', '').split('_');
        const plantId = parts.slice(0, -1).join('_');
        const productType = parts[parts.length - 1];
        
        // Get entry count
        const countResult = await (window as any).electronAPI.executeSQL(
          `SELECT COUNT(*) as count FROM ${tableName}`
        );
        const entryCount = countResult?.[0]?.count || 0;
        
        // Get last updated
        const lastUpdatedResult = await (window as any).electronAPI.executeSQL(
          `SELECT MAX(updated_at) as last_updated FROM ${tableName}`
        );
        const lastUpdated = lastUpdatedResult?.[0]?.last_updated || new Date().toISOString();
        
        databases.push({
          plant_id: plantId,
          plant_name: plantId.replace(/_/g, ' ').toUpperCase(),
          category: 'Aggregates',
          product_type: productType.replace(/_/g, ' '),
          table_name: tableName,
          entry_count: entryCount,
          last_updated: lastUpdated
        });
      }
      
      return databases;
    } catch (error) {
      console.error('Error fetching Electron plant databases:', error);
      return [];
    }
  }

  private async getBrowserPlantDatabases(): Promise<PlantTestDatabase[]> {
    const databases: PlantTestDatabase[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('aggregate_tests_')) {
        const parts = key.replace('aggregate_tests_', '').split('_');
        const plantId = parts.slice(0, -1).join('_');
        const productType = parts[parts.length - 1];
        
        const data = JSON.parse(localStorage.getItem(key) || '[]');
        const entryCount = data.length;
        const lastUpdated = data.length > 0 
          ? Math.max(...data.map((entry: AggregateTestEntry) => new Date(entry.updated_at).getTime()))
          : new Date().getTime();
        
        databases.push({
          plant_id: plantId,
          plant_name: plantId.replace(/_/g, ' ').toUpperCase(),
          category: 'Aggregates',
          product_type: productType.replace(/_/g, ' '),
          table_name: key,
          entry_count: entryCount,
          last_updated: new Date(lastUpdated).toISOString()
        });
      }
    }
    
    return databases;
  }

  // CRUD operations for test entries
  async getTestEntries(tableName: string, filters?: Record<string, any>): Promise<AggregateTestEntry[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        return await this.getElectronTestEntries(tableName, filters);
      } else {
        return await this.getBrowserTestEntries(tableName, filters);
      }
    } catch (error) {
      console.error('Error fetching test entries:', error);
      return [];
    }
  }

  private async getElectronTestEntries(tableName: string, filters?: Record<string, any>): Promise<AggregateTestEntry[]> {
    let query = `SELECT * FROM ${tableName}`;
    const params: any[] = [];
    
    if (filters) {
      const conditions: string[] = [];
      
      if (filters.memo_reference) {
        conditions.push('memo_reference LIKE ?');
        params.push(`%${filters.memo_reference}%`);
      }
      
      if (filters.start_date) {
        conditions.push('test_date >= ?');
        params.push(filters.start_date);
      }
      
      if (filters.end_date) {
        conditions.push('test_date <= ?');
        params.push(filters.end_date);
      }
      
      if (filters.test_performed !== undefined) {
        conditions.push('test_performed = ?');
        params.push(filters.test_performed ? 1 : 0);
      }
      
      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }
    }
    
    query += ' ORDER BY test_date DESC';
    
    const result = await (window as any).electronAPI.executeSQL(query, params);
    return result || [];
  }

  private async getBrowserTestEntries(tableName: string, filters?: Record<string, any>): Promise<AggregateTestEntry[]> {
    const data = JSON.parse(localStorage.getItem(tableName) || '[]');
    
    if (!filters) {
      return data.sort((a: AggregateTestEntry, b: AggregateTestEntry) => 
        new Date(b.test_date).getTime() - new Date(a.test_date).getTime()
      );
    }
    
    return data.filter((entry: AggregateTestEntry) => {
      if (filters.memo_reference && !entry.memo_reference.toLowerCase().includes(filters.memo_reference.toLowerCase())) {
        return false;
      }
      
      if (filters.start_date && entry.test_date < filters.start_date) {
        return false;
      }
      
      if (filters.end_date && entry.test_date > filters.end_date) {
        return false;
      }
      
      if (filters.test_performed !== undefined && entry.test_performed !== filters.test_performed) {
        return false;
      }
      
      return true;
    }).sort((a: AggregateTestEntry, b: AggregateTestEntry) => 
      new Date(b.test_date).getTime() - new Date(a.test_date).getTime()
    );
  }

  async createTestEntry(tableName: string, entryData: Omit<AggregateTestEntry, 'id' | 'created_at' | 'updated_at'>): Promise<AggregateTestEntry> {
    const newEntry: AggregateTestEntry = {
      ...entryData,
      id: `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.createElectronTestEntry(tableName, newEntry);
      } else {
        await this.createBrowserTestEntry(tableName, newEntry);
      }
      
      toast({
        title: "Test Entry Created",
        description: `Test entry ${newEntry.memo_reference} has been saved.`
      });
      
      return newEntry;
    } catch (error) {
      console.error('Error creating test entry:', error);
      toast({
        title: "Failed to Create Entry",
        description: "Could not save the test entry.",
        variant: "destructive"
      });
      throw error;
    }
  }

  private async createElectronTestEntry(tableName: string, entry: AggregateTestEntry): Promise<void> {
    const fields = Object.keys(entry).join(', ');
    const placeholders = Object.keys(entry).map(() => '?').join(', ');
    const values = Object.values(entry);
    
    const query = `INSERT INTO ${tableName} (${fields}) VALUES (${placeholders})`;
    await (window as any).electronAPI.executeSQL(query, values);
  }

  private async createBrowserTestEntry(tableName: string, entry: AggregateTestEntry): Promise<void> {
    const data = JSON.parse(localStorage.getItem(tableName) || '[]');
    data.push(entry);
    localStorage.setItem(tableName, JSON.stringify(data));
  }

  async updateTestEntry(tableName: string, entryId: string, updates: Partial<AggregateTestEntry>): Promise<void> {
    const updatedData = {
      ...updates,
      updated_at: new Date().toISOString()
    };

    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.updateElectronTestEntry(tableName, entryId, updatedData);
      } else {
        await this.updateBrowserTestEntry(tableName, entryId, updatedData);
      }
      
      toast({
        title: "Test Entry Updated",
        description: "Test entry has been successfully updated."
      });
    } catch (error) {
      console.error('Error updating test entry:', error);
      toast({
        title: "Update Failed",
        description: "Could not update the test entry.",
        variant: "destructive"
      });
      throw error;
    }
  }

  private async updateElectronTestEntry(tableName: string, entryId: string, updates: Partial<AggregateTestEntry>): Promise<void> {
    const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
    const values = [...Object.values(updates), entryId];
    
    const query = `UPDATE ${tableName} SET ${fields} WHERE id = ?`;
    await (window as any).electronAPI.executeSQL(query, values);
  }

  private async updateBrowserTestEntry(tableName: string, entryId: string, updates: Partial<AggregateTestEntry>): Promise<void> {
    const data = JSON.parse(localStorage.getItem(tableName) || '[]');
    const index = data.findIndex((entry: AggregateTestEntry) => entry.id === entryId);
    
    if (index !== -1) {
      data[index] = { ...data[index], ...updates };
      localStorage.setItem(tableName, JSON.stringify(data));
    }
  }

  async deleteTestEntry(tableName: string, entryId: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await (window as any).electronAPI.executeSQL(
          `DELETE FROM ${tableName} WHERE id = ?`,
          [entryId]
        );
      } else {
        const data = JSON.parse(localStorage.getItem(tableName) || '[]');
        const filteredData = data.filter((entry: AggregateTestEntry) => entry.id !== entryId);
        localStorage.setItem(tableName, JSON.stringify(filteredData));
      }
      
      toast({
        title: "Test Entry Deleted",
        description: "Test entry has been successfully deleted."
      });
    } catch (error) {
      console.error('Error deleting test entry:', error);
      toast({
        title: "Delete Failed",
        description: "Could not delete the test entry.",
        variant: "destructive"
      });
      throw error;
    }
  }

  // Validation helpers
  async validateTestData(testData: Partial<AggregateTestEntry>, referenceData: any): Promise<{isValid: boolean; errors: string[]}> {
    const errors: string[] = [];
    
    // Validate required fields
    if (!testData.memo_reference) {
      errors.push('Memo reference is required');
    }
    
    if (!testData.plant_id) {
      errors.push('Plant selection is required');
    }
    
    if (!testData.officer_id) {
      errors.push('Officer selection is required');
    }
    
    if (!testData.aggregate_type_id) {
      errors.push('Aggregate type selection is required');
    }
    
    // Validate test data if test is performed
    if (testData.test_performed) {
      if (!testData.test_date) {
        errors.push('Test date is required when test is performed');
      }
      
      // Validate sieve analysis data
      const sieves = ['sieve_0_075', 'sieve_0_15', 'sieve_0_3', 'sieve_0_6', 'sieve_1_18', 'sieve_2_36', 'sieve_5', 'sieve_10'];
      const hasAnySieveData = sieves.some(sieve => testData[sieve as keyof AggregateTestEntry] !== null && testData[sieve as keyof AggregateTestEntry] !== undefined);
      
      if (!hasAnySieveData) {
        errors.push('At least one sieve analysis result is required when test is performed');
      }
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

export const aggregateTestService = new AggregateTestService();
