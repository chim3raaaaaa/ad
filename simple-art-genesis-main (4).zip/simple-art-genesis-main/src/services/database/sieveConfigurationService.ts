import { toast } from "@/hooks/use-toast";

export interface SieveConfiguration {
  id: string;
  aggregate_type: string;
  sieve_sizes: string[]; // Array of sieve field keys like ['0_075', '0_15', '0_3', etc.]
  display_order?: number;
  created_at?: string;
  updated_at?: string;
}

export interface GradingLimit {
  id: string;
  aggregate_type: string;
  standard: string;
  sieve_size: string; // e.g., '0_075', '0_15', etc.
  min_limit?: number;
  max_limit?: number;
  target_value?: number;
  tolerance?: number;
  created_at?: string;
  updated_at?: string;
}

class SieveConfigurationService {
  private async executeQuery(query: string, params: any[] = []): Promise<any> {
    try {
      if (window.electronAPI) {
        return await window.electronAPI.executeQuery(query, params);
      } else {
        return this.simulateQuery(query, params);
      }
    } catch (error) {
      console.error('Database query failed:', error);
      throw error;
    }
  }

  private simulateQuery(query: string, params: any[]): any {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('create table')) {
      return { success: true };
    }
    
    if (lowerQuery.includes('insert')) {
      return { success: true, lastInsertRowid: Math.random().toString(36) };
    }
    
    if (lowerQuery.includes('select')) {
      const table = this.extractTableName(query);
      const data = JSON.parse(localStorage.getItem(`sieve_${table}`) || '[]');
      return data;
    }
    
    return { success: true };
  }

  private extractTableName(query: string): string {
    const match = query.match(/from\s+(\w+)/i);
    return match ? match[1] : 'unknown';
  }

  async initializeTables(): Promise<void> {
    try {
      // Create sieve configurations table
      await this.executeQuery(`
        CREATE TABLE IF NOT EXISTS aggregate_sieve_configurations (
          id TEXT PRIMARY KEY,
          aggregate_type TEXT NOT NULL,
          sieve_sizes TEXT NOT NULL, -- JSON array of sieve field keys
          display_order INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create grading limits table
      await this.executeQuery(`
        CREATE TABLE IF NOT EXISTS aggregate_grading_limits (
          id TEXT PRIMARY KEY,
          aggregate_type TEXT NOT NULL,
          standard TEXT NOT NULL,
          sieve_size TEXT NOT NULL,
          min_limit REAL,
          max_limit REAL,
          target_value REAL,
          tolerance REAL DEFAULT 5.0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Populate default configurations
      await this.populateDefaultConfigurations();
    } catch (error) {
      console.error('Error initializing sieve tables:', error);
      throw error;
    }
  }

  private async populateDefaultConfigurations(): Promise<void> {
    // Check if we already have configurations
    const existing = await this.executeQuery('SELECT COUNT(*) as count FROM aggregate_sieve_configurations');
    if (existing[0]?.count > 0) return;

    // Default sieve configurations for different aggregate types
    const defaultConfigs: Omit<SieveConfiguration, 'id' | 'created_at' | 'updated_at'>[] = [
      {
        aggregate_type: 'Fine Aggregate (0-4mm)',
        sieve_sizes: ['0_075', '0_15', '0_3', '0_6', '1_18', '2_36'],
        display_order: 1
      },
      {
        aggregate_type: 'Coarse Aggregate (4-20mm)',
        sieve_sizes: ['5', '10', '14', '16', '20'],
        display_order: 2
      },
      {
        aggregate_type: 'All-in Aggregate (0-20mm)',
        sieve_sizes: ['0_075', '0_15', '0_3', '0_6', '1_18', '2_36', '5', '10', '14', '16', '20'],
        display_order: 3
      },
      {
        aggregate_type: 'Large Aggregate (20-63mm)',
        sieve_sizes: ['20', '31_5', '37_5', '45', '50', '63'],
        display_order: 4
      }
    ];

    for (const config of defaultConfigs) {
      await this.saveSieveConfiguration(config);
    }

    // Default grading limits (BS 882 standards)
    const defaultLimits: Omit<GradingLimit, 'id' | 'created_at' | 'updated_at'>[] = [
      // Fine aggregate limits
      { aggregate_type: 'Fine Aggregate (0-4mm)', standard: 'BS 882 - Zone M', sieve_size: '2_36', min_limit: 65, max_limit: 100 },
      { aggregate_type: 'Fine Aggregate (0-4mm)', standard: 'BS 882 - Zone M', sieve_size: '1_18', min_limit: 45, max_limit: 80 },
      { aggregate_type: 'Fine Aggregate (0-4mm)', standard: 'BS 882 - Zone M', sieve_size: '0_6', min_limit: 25, max_limit: 60 },
      { aggregate_type: 'Fine Aggregate (0-4mm)', standard: 'BS 882 - Zone M', sieve_size: '0_3', min_limit: 5, max_limit: 30 },
      { aggregate_type: 'Fine Aggregate (0-4mm)', standard: 'BS 882 - Zone M', sieve_size: '0_15', min_limit: 0, max_limit: 15 },
      
      // Coarse aggregate limits
      { aggregate_type: 'Coarse Aggregate (4-20mm)', standard: 'BS 882 - Single Size', sieve_size: '20', min_limit: 85, max_limit: 100 },
      { aggregate_type: 'Coarse Aggregate (4-20mm)', standard: 'BS 882 - Single Size', sieve_size: '14', min_limit: 0, max_limit: 25 },
      { aggregate_type: 'Coarse Aggregate (4-20mm)', standard: 'BS 882 - Single Size', sieve_size: '10', min_limit: 0, max_limit: 5 }
    ];

    for (const limit of defaultLimits) {
      await this.saveGradingLimit(limit);
    }
  }

  // CRUD Operations for Sieve Configurations
  async getSieveConfigurationsByType(aggregateType: string): Promise<SieveConfiguration | null> {
    const result = await this.executeQuery(
      'SELECT * FROM aggregate_sieve_configurations WHERE aggregate_type = ?',
      [aggregateType]
    );
    
    if (result.length > 0) {
      const config = result[0];
      return {
        ...config,
        sieve_sizes: JSON.parse(config.sieve_sizes)
      };
    }
    return null;
  }

  async getAllSieveConfigurations(): Promise<SieveConfiguration[]> {
    const result = await this.executeQuery('SELECT * FROM aggregate_sieve_configurations ORDER BY display_order');
    return result.map((config: any) => ({
      ...config,
      sieve_sizes: JSON.parse(config.sieve_sizes)
    }));
  }

  async saveSieveConfiguration(config: Omit<SieveConfiguration, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = Math.random().toString(36).substr(2, 9);
    await this.executeQuery(`
      INSERT INTO aggregate_sieve_configurations (id, aggregate_type, sieve_sizes, display_order)
      VALUES (?, ?, ?, ?)
    `, [id, config.aggregate_type, JSON.stringify(config.sieve_sizes), config.display_order || 0]);
    return id;
  }

  async updateSieveConfiguration(id: string, config: Partial<SieveConfiguration>): Promise<void> {
    const updates: string[] = [];
    const values: any[] = [];

    if (config.aggregate_type) {
      updates.push('aggregate_type = ?');
      values.push(config.aggregate_type);
    }
    if (config.sieve_sizes) {
      updates.push('sieve_sizes = ?');
      values.push(JSON.stringify(config.sieve_sizes));
    }
    if (config.display_order !== undefined) {
      updates.push('display_order = ?');
      values.push(config.display_order);
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    await this.executeQuery(`
      UPDATE aggregate_sieve_configurations 
      SET ${updates.join(', ')} 
      WHERE id = ?
    `, values);
  }

  async deleteSieveConfiguration(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM aggregate_sieve_configurations WHERE id = ?', [id]);
  }

  // CRUD Operations for Grading Limits
  async getGradingLimits(aggregateType: string, standard: string): Promise<GradingLimit[]> {
    const result = await this.executeQuery(
      'SELECT * FROM aggregate_grading_limits WHERE aggregate_type = ? AND standard = ?',
      [aggregateType, standard]
    );
    return result;
  }

  async getAllGradingLimits(): Promise<GradingLimit[]> {
    const result = await this.executeQuery('SELECT * FROM aggregate_grading_limits ORDER BY aggregate_type, standard, sieve_size');
    return result;
  }

  async saveGradingLimit(limit: Omit<GradingLimit, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    const id = Math.random().toString(36).substr(2, 9);
    await this.executeQuery(`
      INSERT INTO aggregate_grading_limits 
      (id, aggregate_type, standard, sieve_size, min_limit, max_limit, target_value, tolerance)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      id, 
      limit.aggregate_type, 
      limit.standard, 
      limit.sieve_size, 
      limit.min_limit, 
      limit.max_limit, 
      limit.target_value, 
      limit.tolerance || 5.0
    ]);
    return id;
  }

  async updateGradingLimit(id: string, limit: Partial<GradingLimit>): Promise<void> {
    const updates: string[] = [];
    const values: any[] = [];

    Object.entries(limit).forEach(([key, value]) => {
      if (key !== 'id' && key !== 'created_at' && key !== 'updated_at' && value !== undefined) {
        updates.push(`${key} = ?`);
        values.push(value);
      }
    });

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    await this.executeQuery(`
      UPDATE aggregate_grading_limits 
      SET ${updates.join(', ')} 
      WHERE id = ?
    `, values);
  }

  async deleteGradingLimit(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM aggregate_grading_limits WHERE id = ?', [id]);
  }

  // Helper methods
  async getAggregateTypes(): Promise<string[]> {
    const result = await this.executeQuery('SELECT DISTINCT aggregate_type FROM aggregate_sieve_configurations ORDER BY aggregate_type');
    return result.map((row: any) => row.aggregate_type);
  }

  async getStandardsByType(aggregateType: string): Promise<string[]> {
    const result = await this.executeQuery(
      'SELECT DISTINCT standard FROM aggregate_grading_limits WHERE aggregate_type = ? ORDER BY standard',
      [aggregateType]
    );
    return result.map((row: any) => row.standard);
  }

  async getGradingLimitForSieve(aggregateType: string, standard: string, sieveSize: string): Promise<GradingLimit | null> {
    const result = await this.executeQuery(
      'SELECT * FROM aggregate_grading_limits WHERE aggregate_type = ? AND standard = ? AND sieve_size = ?',
      [aggregateType, standard, sieveSize]
    );
    return result.length > 0 ? result[0] : null;
  }
}

export const sieveConfigurationService = new SieveConfigurationService();