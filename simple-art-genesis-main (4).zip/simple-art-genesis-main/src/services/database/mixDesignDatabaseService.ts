// Mix Design Database Service - Handles database initialization and migration
// Phase 1: Database Integration with Existing System
// Created: 2025-01-31

import { mixDesignService } from './mixDesignService';
import { mixDesignMigrationService } from './mixDesignMigration';

class MixDesignDatabaseService {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;
  private isInitialized = false;

  // Initialize the entire mix design database system
  async initialize(): Promise<void> {
    if (this.isInitialized || !this.isElectron) {
      return;
    }

    try {
      console.log('Initializing Mix Design Database System...');

      // Step 1: Create tables if they don't exist
      await this.createTables();

      // Step 2: Check for legacy data and migrate if needed
      const migrationStatus = await mixDesignMigrationService.getMigrationStatus();
      
      if (migrationStatus.hasLegacyData && !migrationStatus.migrationComplete) {
        console.log('Legacy data detected, starting migration...');
        await this.performMigration();
      }

      // Step 3: Seed default data if needed
      await this.seedDefaultData();

      // Step 4: Initialize sync tables
      await this.initializeSyncTables();

      this.isInitialized = true;
      console.log('Mix Design Database System initialized successfully');

    } catch (error) {
      console.error('Failed to initialize Mix Design Database System:', error);
      throw error;
    }
  }

  // Create all necessary tables
  private async createTables(): Promise<void> {
    const schemas = [
      this.getProductTypesSchema(),
      this.getMixDesignFieldsSchema(),
      this.getMixDesignsSchema(),
      this.getMixDesignVersionsSchema(),
      this.getMixDesignTemplatesSchema(),
      this.getMixDesignTrialsSchema(),
      this.getSyncOperationsSchema(),
      this.getIndexesSchema(),
      this.getTriggersSchema()
    ];

    for (const schema of schemas) {
      try {
        await (window as any).electronAPI.dbRun(schema);
      } catch (error) {
        console.warn('Schema creation warning (table may already exist):', error);
      }
    }
  }

  // Seed default data if tables are empty
  private async seedDefaultData(): Promise<void> {
    try {
      // Check if product types exist
      const productTypes = await mixDesignService.getProductTypes();
      
      if (productTypes.length === 0) {
        console.log('Seeding default product types...');
        await this.seedProductTypes();
      }

      // Check if field definitions exist
      const fields = await (window as any).electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM mix_design_fields'
      );
      
      if (fields[0].count === 0) {
        console.log('Seeding default field definitions...');
        await this.seedFieldDefinitions();
      }

      // Check if templates exist
      const templates = await mixDesignService.getMixDesignTemplates();
      
      if (templates.length === 0) {
        console.log('Seeding default templates...');
        await this.seedDefaultTemplates();
      }

    } catch (error) {
      console.error('Failed to seed default data:', error);
    }
  }

  // Perform legacy data migration
  private async performMigration(): Promise<void> {
    try {
      const result = await mixDesignMigrationService.migrateLegacyMixDesigns();
      
      if (result.errors.length > 0) {
        console.warn('Migration completed with errors:', result.errors);
      }
      
      console.log(`Migration completed: ${result.migrated} items migrated`);
    } catch (error) {
      console.error('Migration failed:', error);
      throw error;
    }
  }

  // Initialize sync operation tables
  private async initializeSyncTables(): Promise<void> {
    const syncTableSchema = `
      CREATE TABLE IF NOT EXISTS mix_design_sync_ops (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
        operation_data TEXT NOT NULL,
        sync_status TEXT DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
        retry_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        synced_at DATETIME
      );
      
      CREATE INDEX IF NOT EXISTS idx_mix_design_sync_ops_status 
      ON mix_design_sync_ops(sync_status);
      
      CREATE INDEX IF NOT EXISTS idx_mix_design_sync_ops_table 
      ON mix_design_sync_ops(table_name);
    `;

    await (window as any).electronAPI.dbRun(syncTableSchema);
  }

  // Schema definitions
  private getProductTypesSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS product_types (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `;
  }

  private getMixDesignFieldsSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_design_fields (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        product_type_id TEXT NOT NULL,
        field_name TEXT NOT NULL,
        field_label TEXT NOT NULL,
        field_type TEXT NOT NULL CHECK (field_type IN ('text', 'number', 'select', 'textarea', 'date')),
        field_unit TEXT,
        default_value TEXT,
        is_required BOOLEAN DEFAULT 0,
        validation_rules TEXT,
        display_order INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id) ON DELETE CASCADE
      );
    `;
  }

  private getMixDesignsSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_designs (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL,
        product_type_id TEXT NOT NULL,
        plant_id TEXT,
        design_code TEXT UNIQUE,
        description TEXT,
        design_data TEXT NOT NULL,
        status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived', 'under_review')),
        created_by TEXT NOT NULL,
        approved_by TEXT,
        approved_at DATETIME,
        is_template BOOLEAN DEFAULT 0,
        parent_template_id TEXT,
        version_number INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id),
        FOREIGN KEY (parent_template_id) REFERENCES mix_designs(id)
      );
    `;
  }

  private getMixDesignVersionsSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_design_versions (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        mix_design_id TEXT NOT NULL,
        version_number INTEGER NOT NULL,
        design_data TEXT NOT NULL,
        change_summary TEXT,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (mix_design_id) REFERENCES mix_designs(id) ON DELETE CASCADE
      );
    `;
  }

  private getMixDesignTemplatesSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_design_templates (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL,
        product_type_id TEXT NOT NULL,
        template_data TEXT NOT NULL,
        description TEXT,
        is_public BOOLEAN DEFAULT 0,
        created_by TEXT NOT NULL,
        approved_by TEXT,
        approved_at DATETIME,
        usage_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id)
      );
    `;
  }

  private getMixDesignTrialsSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_design_trials (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        mix_design_id TEXT NOT NULL,
        memo_id TEXT,
        test_entry_id TEXT,
        plant_id TEXT,
        trial_date DATE,
        trial_results TEXT,
        performance_rating TEXT CHECK (performance_rating IN ('excellent', 'good', 'acceptable', 'poor')),
        compliance_status TEXT DEFAULT 'pending' CHECK (compliance_status IN ('pending', 'compliant', 'non_compliant', 'under_review')),
        variance_notes TEXT,
        recommended_adjustments TEXT,
        notes TEXT,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (mix_design_id) REFERENCES mix_designs(id) ON DELETE CASCADE
      );
    `;
  }

  private getSyncOperationsSchema(): string {
    return `
      CREATE TABLE IF NOT EXISTS mix_design_sync_ops (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
        operation_data TEXT NOT NULL,
        sync_status TEXT DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
        retry_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        synced_at DATETIME
      );
    `;
  }

  private getIndexesSchema(): string {
    return `
      CREATE INDEX IF NOT EXISTS idx_mix_designs_product_type ON mix_designs(product_type_id);
      CREATE INDEX IF NOT EXISTS idx_mix_designs_status ON mix_designs(status);
      CREATE INDEX IF NOT EXISTS idx_mix_designs_created_by ON mix_designs(created_by);
      CREATE INDEX IF NOT EXISTS idx_mix_design_fields_product_type ON mix_design_fields(product_type_id);
      CREATE INDEX IF NOT EXISTS idx_mix_design_versions_mix_design ON mix_design_versions(mix_design_id);
      CREATE INDEX IF NOT EXISTS idx_mix_design_trials_mix_design ON mix_design_trials(mix_design_id);
      CREATE INDEX IF NOT EXISTS idx_mix_design_trials_memo ON mix_design_trials(memo_id);
      CREATE INDEX IF NOT EXISTS idx_mix_design_trials_test_entry ON mix_design_trials(test_entry_id);
      CREATE INDEX IF NOT EXISTS idx_mix_design_sync_ops_status ON mix_design_sync_ops(sync_status);
    `;
  }

  private getTriggersSchema(): string {
    return `
      CREATE TRIGGER IF NOT EXISTS update_mix_designs_updated_at
        AFTER UPDATE ON mix_designs
        FOR EACH ROW
        BEGIN
          UPDATE mix_designs SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

      CREATE TRIGGER IF NOT EXISTS update_product_types_updated_at
        AFTER UPDATE ON product_types
        FOR EACH ROW
        BEGIN
          UPDATE product_types SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

      CREATE TRIGGER IF NOT EXISTS update_mix_design_fields_updated_at
        AFTER UPDATE ON mix_design_fields
        FOR EACH ROW
        BEGIN
          UPDATE mix_design_fields SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

      CREATE TRIGGER IF NOT EXISTS update_mix_design_templates_updated_at
        AFTER UPDATE ON mix_design_templates
        FOR EACH ROW
        BEGIN
          UPDATE mix_design_templates SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

      CREATE TRIGGER IF NOT EXISTS update_mix_design_trials_updated_at
        AFTER UPDATE ON mix_design_trials
        FOR EACH ROW
        BEGIN
          UPDATE mix_design_trials SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;
    `;
  }

  // Data seeding methods
  private async seedProductTypes(): Promise<void> {
    const defaultProductTypes = [
      { name: 'Standard Concrete', category: 'Concrete', description: 'Standard concrete mix designs' },
      { name: 'High Strength Concrete', category: 'Concrete', description: 'High strength concrete mix designs' },
      { name: 'Lightweight Concrete', category: 'Concrete', description: 'Lightweight concrete mix designs' },
      { name: 'Hot Mix Asphalt', category: 'Asphalt', description: 'Hot mix asphalt designs' },
      { name: 'Warm Mix Asphalt', category: 'Asphalt', description: 'Warm mix asphalt designs' },
      { name: 'Masonry Mortar', category: 'Mortar', description: 'Masonry mortar mix designs' },
      { name: 'Plastering Mortar', category: 'Mortar', description: 'Plastering mortar mix designs' }
    ];

    for (const productType of defaultProductTypes) {
      await mixDesignService.createProductType({
        ...productType,
        is_active: true
      });
    }
  }

  private async seedFieldDefinitions(): Promise<void> {
    // This would be implemented with the default field definitions from the migration data
    const seedDataSQL = await this.getFieldDefinitionsSeedData();
    await (window as any).electronAPI.dbRun(seedDataSQL);
  }

  private async seedDefaultTemplates(): Promise<void> {
    // This would be implemented with the default templates from the migration data
    const seedDataSQL = await this.getTemplatesSeedData();
    await (window as any).electronAPI.dbRun(seedDataSQL);
  }

  private async getFieldDefinitionsSeedData(): Promise<string> {
    // Return the field definitions insert statements from the migration
    return `
      INSERT OR IGNORE INTO mix_design_fields (product_type_id, field_name, field_label, field_type, field_unit, is_required, validation_rules, display_order) 
      SELECT 'concrete-standard', 'cement_content', 'Cement Content', 'number', 'kg/m³', 1, '{"min": 200, "max": 600}', 1
      WHERE EXISTS (SELECT 1 FROM product_types WHERE id = 'concrete-standard');
    `;
  }

  private async getTemplatesSeedData(): Promise<string> {
    // Return the template insert statements from the migration
    return `
      INSERT OR IGNORE INTO mix_design_templates (id, name, product_type_id, template_data, description, is_public, created_by)
      SELECT 'template-concrete-c25', 'C25/30 Standard Concrete', 'concrete-standard', 
             '{"cement_content": 350, "water_content": 175}', 'Standard C25/30 concrete template', 1, 'system'
      WHERE EXISTS (SELECT 1 FROM product_types WHERE id = 'concrete-standard');
    `;
  }

  // Status check
  async getInitializationStatus(): Promise<{
    isInitialized: boolean;
    tablesExist: boolean;
    hasData: boolean;
    migrationStatus: any;
  }> {
    if (!this.isElectron) {
      return {
        isInitialized: false,
        tablesExist: false,
        hasData: false,
        migrationStatus: null
      };
    }

    try {
      // Check if main tables exist
      const tables = await (window as any).electronAPI.dbQuery(`
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name IN ('mix_designs', 'product_types', 'mix_design_fields')
      `);
      
      const tablesExist = tables.length >= 3;
      
      // Check if we have data
      let hasData = false;
      if (tablesExist) {
        const productTypes = await mixDesignService.getProductTypes();
        hasData = productTypes.length > 0;
      }

      // Get migration status
      const migrationStatus = await mixDesignMigrationService.getMigrationStatus();

      return {
        isInitialized: this.isInitialized,
        tablesExist,
        hasData,
        migrationStatus
      };
    } catch (error) {
      console.error('Failed to check initialization status:', error);
      return {
        isInitialized: false,
        tablesExist: false,
        hasData: false,
        migrationStatus: null
      };
    }
  }
}

export const mixDesignDatabaseService = new MixDesignDatabaseService();