// Reports Database Service - Local SQLite Integration
export class ReportsService {

  // Get completed test results for reports
  static async getCompletedTestResults(filters: {
    labSiteId?: string;
    startDate?: string;
    endDate?: string;
    productCategory?: string;
    testTypeId?: string;
    memoId?: string;
  } = {}): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      let sql = `
        SELECT 
          tr.id as result_id,
          tr.test_date,
          tr.results,
          tr.status,
          tr.notes,
          m.id as memo_id,
          m.title as memo_title,
          m.created_at as memo_date,
          mp.production_date,
          mp.machine,
          mp.samples_count,
          mp.batch_number,
          mp.details as production_details,
          p.name as product_name,
          p.category as product_category,
          p.type as product_type,
          tt.name as test_type_name,
          tt.description as test_description,
          ls.name as lab_site_name,
          ls.location as lab_site_location,
          o.name as officer_name,
          o.role as officer_role,
          o.department as officer_department
        FROM test_results tr
        JOIN memos m ON tr.memo_id = m.id
        JOIN memo_productions mp ON tr.production_id = mp.id
        JOIN products p ON mp.product_id = p.id
        JOIN test_types tt ON tr.test_type_id = tt.id
        LEFT JOIN lab_sites ls ON m.lab_site_id = ls.id
        JOIN officers o ON tr.officer_id = o.id
        WHERE tr.status IN ('pass', 'fail')
      `;

      const params: any[] = [];

      if (filters.labSiteId) {
        sql += ' AND ls.id = ?';
        params.push(filters.labSiteId);
      }

      if (filters.startDate) {
        sql += ' AND tr.test_date >= ?';
        params.push(filters.startDate);
      }

      if (filters.endDate) {
        sql += ' AND tr.test_date <= ?';
        params.push(filters.endDate);
      }

      if (filters.productCategory) {
        sql += ' AND p.category = ?';
        params.push(filters.productCategory);
      }

      if (filters.testTypeId) {
        sql += ' AND tt.id = ?';
        params.push(filters.testTypeId);
      }

      if (filters.memoId) {
        sql += ' AND m.id = ?';
        params.push(filters.memoId);
      }

      sql += ' ORDER BY tr.test_date DESC, m.created_at DESC';

      const result = await window.electronAPI.dbQuery(sql, params);
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get completed test results:', error);
      return [];
    }
  }

  // Get report filter options
  static async getReportFilterOptions(): Promise<{
    labSites: any[];
    productCategories: any[];
    testTypes: any[];
    memos: any[];
  }> {
    if (!window.electronAPI) return { labSites: [], productCategories: [], testTypes: [], memos: [] };

    try {
      const [labSitesResult, productsResult, testTypesResult, memosResult] = await Promise.all([
        window.electronAPI.dbQuery('SELECT * FROM lab_sites WHERE active = 1 ORDER BY name'),
        window.electronAPI.dbQuery('SELECT DISTINCT category FROM products WHERE active = 1 ORDER BY category'),
        window.electronAPI.dbQuery('SELECT * FROM test_types WHERE active = 1 ORDER BY name'),
        window.electronAPI.dbQuery(`
          SELECT DISTINCT m.id, m.title, m.created_at 
          FROM memos m 
          JOIN test_results tr ON m.id = tr.memo_id 
          ORDER BY m.created_at DESC
        `)
      ]);

      return {
        labSites: labSitesResult.success ? labSitesResult.data : [],
        productCategories: productsResult.success ? productsResult.data.map(p => ({ category: p.category })) : [],
        testTypes: testTypesResult.success ? testTypesResult.data : [],
        memos: memosResult.success ? memosResult.data : []
      };
    } catch (error) {
      console.error('Failed to get report filter options:', error);
      return { labSites: [], productCategories: [], testTypes: [], memos: [] };
    }
  }

  // Generate report data
  static async generateReportData(filters: any): Promise<{
    summary: any;
    testResults: any[];
    metadata: any;
  }> {
    try {
      const testResults = await this.getCompletedTestResults(filters);
      
      // Calculate summary statistics
      const summary = {
        totalTests: testResults.length,
        passedTests: testResults.filter(r => r.status === 'pass').length,
        failedTests: testResults.filter(r => r.status === 'fail').length,
        uniqueMemos: new Set(testResults.map(r => r.memo_id)).size,
        testTypes: new Set(testResults.map(r => r.test_type_name)).size,
        dateRange: {
          start: testResults.length > 0 ? testResults[testResults.length - 1].test_date : null,
          end: testResults.length > 0 ? testResults[0].test_date : null
        },
        passRate: '0'
      };

      summary.passRate = summary.totalTests > 0 ? ((summary.passedTests / summary.totalTests) * 100).toFixed(2) : '0';

      // Group results by memo
      const memoGroups = testResults.reduce((groups, result) => {
        const memoId = result.memo_id;
        if (!groups[memoId]) {
          groups[memoId] = {
            memo: {
              id: result.memo_id,
              title: result.memo_title,
              date: result.memo_date,
              labSite: result.lab_site_name
            },
            productions: {}
          };
        }

        const productionKey = `${result.production_date}_${result.machine}`;
        if (!groups[memoId].productions[productionKey]) {
          groups[memoId].productions[productionKey] = {
            production: {
              date: result.production_date,
              machine: result.machine,
              samplesCount: result.samples_count,
              batchNumber: result.batch_number,
              productName: result.product_name,
              productCategory: result.product_category
            },
            tests: []
          };
        }

        groups[memoId].productions[productionKey].tests.push({
          id: result.result_id,
          testDate: result.test_date,
          testType: result.test_type_name,
          testDescription: result.test_description,
          results: JSON.parse(result.results || '{}'),
          status: result.status,
          notes: result.notes,
          officer: {
            name: result.officer_name,
            role: result.officer_role,
            department: result.officer_department
          }
        });

        return groups;
      }, {});

      const metadata = {
        generatedAt: new Date().toISOString(),
        generatedBy: 'Lab Report System',
        filters: filters,
        reportType: 'Test Results Report'
      };

      return {
        summary,
        testResults: Object.values(memoGroups),
        metadata
      };
    } catch (error) {
      console.error('Failed to generate report data:', error);
      return {
        summary: { totalTests: 0, passedTests: 0, failedTests: 0, passRate: '0' },
        testResults: [],
        metadata: { generatedAt: new Date().toISOString(), error: error.message }
      };
    }
  }

  // Export report as JSON
  static exportAsJSON(reportData: any, filename: string): void {
    try {
      const dataStr = JSON.stringify(reportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export JSON:', error);
    }
  }

  // Export report as CSV
  static exportAsCSV(reportData: any, filename: string): void {
    try {
      const headers = [
        'Memo ID', 'Memo Title', 'Production Date', 'Machine', 'Product', 
        'Test Type', 'Test Date', 'Status', 'Officer', 'Notes'
      ];

      const rows = [];
      reportData.testResults.forEach((memoGroup: any) => {
        Object.values(memoGroup.productions).forEach((production: any) => {
          production.tests.forEach((test: any) => {
            rows.push([
              memoGroup.memo.id,
              memoGroup.memo.title,
              production.production.date,
              production.production.machine,
              production.production.productName,
              test.testType,
              test.testDate,
              test.status,
              test.officer.name,
              test.notes || ''
            ]);
          });
        });
      });

      const csvContent = [headers, ...rows]
        .map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
        .join('\n');

      const dataBlob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export CSV:', error);
    }
  }
}