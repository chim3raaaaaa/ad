import { toast } from '@/hooks/use-toast';

export interface MemoTestAssignment {
  id: string;
  memo_reference: string;
  test_type: string;
  test_category: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  assigned_date: string;
  started_date?: string;
  completed_date?: string;
  test_results?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface MemoWithTests {
  memo: {
    memo_ref: string;
    plant: string;
    officer: string;
    category: string;
    remarks?: string;
  };
  tests: Array<{
    test_type: string;
    test_category: string;
  }>;
}

export interface MemoTestDashboardData {
  memo_reference: string;
  plant: string;
  officer: string;
  category: string;
  total_tests: number;
  completed_tests: number;
  pending_tests: number;
  in_progress_tests: number;
  created_at: string;
  tests: MemoTestAssignment[];
}

class MemoTestService {
  private readonly STORAGE_KEY = 'memo_test_assignments';
  private readonly MEMO_DASHBOARD_KEY = 'memo_dashboard_data';

  // Get all memo test assignments
  async getAllMemoTestAssignments(): Promise<MemoTestAssignment[]> {
    try {
      if (window.electronAPI?.database) {
        return await window.electronAPI.database.getMemoTestAssignments();
      }
      
      const stored = localStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading memo test assignments:', error);
      return [];
    }
  }

  // Get memo test assignments by memo reference
  async getMemoTestAssignments(memoRef: string): Promise<MemoTestAssignment[]> {
    const allAssignments = await this.getAllMemoTestAssignments();
    return allAssignments.filter(assignment => assignment.memo_reference === memoRef);
  }

  // Create memo with test assignments
  async createMemoWithTests(data: MemoWithTests): Promise<string> {
    try {
      const memoRef = data.memo.memo_ref;
      const timestamp = new Date().toISOString();
      
      // Create test assignments
      const assignments: MemoTestAssignment[] = data.tests.map(test => ({
        id: `${memoRef}_${test.test_type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        memo_reference: memoRef,
        test_type: test.test_type,
        test_category: test.test_category,
        status: 'pending',
        assigned_date: timestamp,
        created_at: timestamp,
        updated_at: timestamp
      }));

      // Save assignments
      if (window.electronAPI?.database) {
        await window.electronAPI.database.saveMemoTestAssignments(assignments);
      } else {
        const existing = await this.getAllMemoTestAssignments();
        const updated = [...existing, ...assignments];
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated));
      }

      // Create dashboard entry
      const dashboardEntry: MemoTestDashboardData = {
        memo_reference: memoRef,
        plant: data.memo.plant,
        officer: data.memo.officer,
        category: data.memo.category,
        total_tests: assignments.length,
        completed_tests: 0,
        pending_tests: assignments.length,
        in_progress_tests: 0,
        created_at: timestamp,
        tests: assignments
      };

      await this.saveDashboardEntry(dashboardEntry);

      toast({
        title: "Memo Created Successfully",
        description: `Memo ${memoRef} created with ${assignments.length} test assignments`
      });

      return memoRef;
    } catch (error) {
      console.error('Error creating memo with tests:', error);
      throw new Error('Failed to create memo with tests');
    }
  }

  // Update test status
  async updateTestStatus(assignmentId: string, status: MemoTestAssignment['status'], testResults?: Record<string, any>): Promise<void> {
    try {
      const assignments = await this.getAllMemoTestAssignments();
      const assignmentIndex = assignments.findIndex(a => a.id === assignmentId);
      
      if (assignmentIndex === -1) {
        throw new Error('Test assignment not found');
      }

      const assignment = assignments[assignmentIndex];
      const timestamp = new Date().toISOString();

      // Update assignment
      assignment.status = status;
      assignment.updated_at = timestamp;
      
      if (status === 'in_progress' && !assignment.started_date) {
        assignment.started_date = timestamp;
      }
      
      if (status === 'completed') {
        assignment.completed_date = timestamp;
        if (testResults) {
          assignment.test_results = testResults;
        }
      }

      assignments[assignmentIndex] = assignment;

      // Save updated assignments
      if (window.electronAPI?.database) {
        await window.electronAPI.database.updateMemoTestAssignment(assignment);
      } else {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(assignments));
      }

      // Update dashboard data
      await this.updateDashboardStats(assignment.memo_reference);

      toast({
        title: "Test Status Updated",
        description: `Test ${assignment.test_type} status changed to ${status}`
      });
    } catch (error) {
      console.error('Error updating test status:', error);
      throw error;
    }
  }

  // Get dashboard data
  async getDashboardData(): Promise<MemoTestDashboardData[]> {
    try {
      if (window.electronAPI?.database) {
        return await window.electronAPI.database.getMemoTestDashboard();
      }
      
      const stored = localStorage.getItem(this.MEMO_DASHBOARD_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      return [];
    }
  }

  // Get memo by reference
  async getMemoByRef(memoRef: string): Promise<MemoTestDashboardData | null> {
    const dashboardData = await this.getDashboardData();
    return dashboardData.find(memo => memo.memo_reference === memoRef) || null;
  }

  // Submit test result
  async submitTestResult(assignmentId: string, testResults: Record<string, any>): Promise<void> {
    await this.updateTestStatus(assignmentId, 'completed', testResults);
  }

  // Get pending tests
  async getPendingTests(category?: string): Promise<MemoTestAssignment[]> {
    const assignments = await this.getAllMemoTestAssignments();
    let pending = assignments.filter(a => a.status === 'pending' || a.status === 'in_progress');
    
    if (category) {
      pending = pending.filter(a => a.test_category === category);
    }
    
    return pending;
  }

  // Private helper methods
  private async saveDashboardEntry(entry: MemoTestDashboardData): Promise<void> {
    if (window.electronAPI?.database) {
      await window.electronAPI.database.saveMemoTestDashboard(entry);
    } else {
      const existing = await this.getDashboardData();
      const updated = [...existing, entry];
      localStorage.setItem(this.MEMO_DASHBOARD_KEY, JSON.stringify(updated));
    }
  }

  private async updateDashboardStats(memoRef: string): Promise<void> {
    const assignments = await this.getMemoTestAssignments(memoRef);
    const dashboardData = await this.getDashboardData();
    const entryIndex = dashboardData.findIndex(d => d.memo_reference === memoRef);
    
    if (entryIndex !== -1) {
      const entry = dashboardData[entryIndex];
      entry.total_tests = assignments.length;
      entry.completed_tests = assignments.filter(a => a.status === 'completed').length;
      entry.pending_tests = assignments.filter(a => a.status === 'pending').length;
      entry.in_progress_tests = assignments.filter(a => a.status === 'in_progress').length;
      entry.tests = assignments;

      if (window.electronAPI?.database) {
        await window.electronAPI.database.updateMemoTestDashboard(entry);
      } else {
        localStorage.setItem(this.MEMO_DASHBOARD_KEY, JSON.stringify(dashboardData));
      }
    }
  }

  // Delete memo and all associated tests
  async deleteMemo(memoRef: string): Promise<void> {
    try {
      // Remove test assignments
      const assignments = await this.getAllMemoTestAssignments();
      const filteredAssignments = assignments.filter(a => a.memo_reference !== memoRef);
      
      if (window.electronAPI?.database) {
        await window.electronAPI.database.deleteMemoTestAssignments(memoRef);
      } else {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredAssignments));
      }

      // Remove dashboard entry
      const dashboardData = await this.getDashboardData();
      const filteredDashboard = dashboardData.filter(d => d.memo_reference !== memoRef);
      
      if (window.electronAPI?.database) {
        await window.electronAPI.database.deleteMemoTestDashboard(memoRef);
      } else {
        localStorage.setItem(this.MEMO_DASHBOARD_KEY, JSON.stringify(filteredDashboard));
      }

      toast({
        title: "Memo Deleted",
        description: `Memo ${memoRef} and all associated tests have been deleted`
      });
    } catch (error) {
      console.error('Error deleting memo:', error);
      throw error;
    }
  }
}

export const memoTestService = new MemoTestService();