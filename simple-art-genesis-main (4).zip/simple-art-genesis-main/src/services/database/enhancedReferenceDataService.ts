import { toast } from "@/hooks/use-toast";

// ============= COMPREHENSIVE REFERENCE DATA INTERFACES =============

// Core Reference Data Types
export interface ProductCategory {
  category_id: string;
  name: string;
  description?: string;
  test_module: string; // blocks, aggregates, kerbs, flags, pavers, concrete
}

export interface Product {
  product_id: string;
  name: string;
  category_id: string;
  product_code: string;
  grade_id?: string;
  test_module: string;
}

export interface Grade {
  grade_id: string;
  name: string;
  mpa_value?: number;
  description?: string;
}

export interface Machine {
  machine_id: string;
  name: string;
  type: string;
  location?: string;
  capacity?: string;
}

export interface MouldReference {
  mould_id: string;
  name: string;
  code: string;
  machine_id?: string;
  dimensions?: string;
  position_numbers?: string; // JSON array of 1-16 positions
}

export interface Plant {
  plant_id: string;
  name: string;
  location?: string;
  code?: string;
}

export interface Officer {
  officer_id: string;
  name: string;
  role: string;
  department?: string;
  certification?: string;
}

export interface Aggregate {
  aggregate_id: string;
  name: string;
  size_range: string; // e.g., "6-10mm", "0-4mm"
  type: string;
  density?: number;
}

export interface Admixture {
  admixture_id: string;
  name: string;
  type: string; // plasticizer, accelerator, etc.
  dosage_range?: string;
  supplier?: string;
}

export interface FreeWater {
  water_id: string;
  name: string;
  source: string;
  quality_grade?: string;
  ph_value?: number;
}

export interface CementType {
  cement_id: string;
  name: string;
  type: string; // PC, PPC, PSC
  grade?: string;
  supplier?: string;
}

export interface VibratorStatus {
  status_id: string;
  name: string;
  code: string; // VIB, NON-VIB
  description?: string;
}

export interface ConformityOption {
  option_id: string;
  symbol: string; // ✓, ✗, %
  name: string;
  description?: string;
}

export interface TestType {
  test_type_id: string;
  name: string;
  category: string;
  standard?: string;
  equipment_required?: string;
}

export interface ClimaticCondition {
  climatic_id: string;
  name: string;
  description?: string;
}

export interface SamplingPlace {
  place_id: string;
  name: string;
  location?: string;
  description?: string;
}

export interface SampledBy {
  sampler_id: string;
  name: string;
  role?: string;
  certification?: string;
}

// ============= ENHANCED REFERENCE DATA SERVICE =============

class EnhancedReferenceDataService {
  private async executeQuery(query: string, params: any[] = []): Promise<any> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.executeQuery(query, params);
        return result;
      } else {
        // Web fallback - localStorage simulation
        return this.simulateQuery(query, params);
      }
    } catch (error) {
      console.error('Database query failed:', error);
      throw error;
    }
  }

  private simulateQuery(query: string, params: any[]): any {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('create table')) {
      return { success: true };
    }
    
    if (lowerQuery.includes('insert')) {
      return { success: true, lastInsertRowid: Math.random().toString(36) };
    }
    
    if (lowerQuery.includes('select')) {
      const table = this.extractTableName(query);
      const data = JSON.parse(localStorage.getItem(`ref_${table}`) || '[]');
      return data;
    }
    
    return { success: true };
  }

  private extractTableName(query: string): string {
    const match = query.match(/from\s+(\w+)/i);
    return match ? match[1] : 'unknown';
  }

  // ============= INITIALIZATION =============

  async initializeAllReferenceTables(): Promise<void> {
    const tables = [
      // Core tables
      `CREATE TABLE IF NOT EXISTS product_categories (
        category_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        test_module TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS products (
        product_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category_id TEXT,
        product_code TEXT NOT NULL,
        grade_id TEXT,
        test_module TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES product_categories(category_id)
      )`,
      
      `CREATE TABLE IF NOT EXISTS grades (
        grade_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        mpa_value INTEGER,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS machines (
        machine_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT,
        location TEXT,
        capacity TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS mould_references (
        mould_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        machine_id TEXT,
        dimensions TEXT,
        position_numbers TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (machine_id) REFERENCES machines(machine_id)
      )`,
      
      `CREATE TABLE IF NOT EXISTS plants (
        plant_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        location TEXT,
        code TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS officers (
        officer_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        role TEXT,
        department TEXT,
        certification TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Material tables
      `CREATE TABLE IF NOT EXISTS aggregates (
        aggregate_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        size_range TEXT NOT NULL,
        type TEXT,
        density REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS admixtures (
        admixture_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT,
        dosage_range TEXT,
        supplier TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS free_water (
        water_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        source TEXT,
        quality_grade TEXT,
        ph_value REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS cement_types (
        cement_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT,
        grade TEXT,
        supplier TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Test configuration tables
      `CREATE TABLE IF NOT EXISTS vibrator_status (
        status_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS conformity_options (
        option_id TEXT PRIMARY KEY,
        symbol TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS test_types (
        test_type_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT,
        standard TEXT,
        equipment_required TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Additional reference tables for aggregate forms
      `CREATE TABLE IF NOT EXISTS climatic_conditions (
        climatic_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS sampling_places (
        place_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        location TEXT,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS sampled_by (
        sampler_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        role TEXT,
        certification TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    for (const tableQuery of tables) {
      await this.executeQuery(tableQuery);
    }
  }

  // ============= VALIDATION METHODS =============

  async validateProductCategory(categoryId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM product_categories WHERE category_id = ?',
      [categoryId]
    );
    return (result[0]?.count || 0) > 0;
  }

  async validateProduct(productId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM products WHERE product_id = ?',
      [productId]
    );
    return (result[0]?.count || 0) > 0;
  }

  async validateMachine(machineId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM machines WHERE machine_id = ?',
      [machineId]
    );
    return (result[0]?.count || 0) > 0;
  }

  async validateOfficer(officerId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM officers WHERE officer_id = ?',
      [officerId]
    );
    return (result[0]?.count || 0) > 0;
  }

  async validatePlant(plantId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM plants WHERE plant_id = ?',
      [plantId]
    );
    return (result[0]?.count || 0) > 0;
  }

  async validateMouldReference(mouldId: string): Promise<boolean> {
    const result = await this.executeQuery(
      'SELECT COUNT(*) as count FROM mould_references WHERE mould_id = ?',
      [mouldId]
    );
    return (result[0]?.count || 0) > 0;
  }

  // ============= BULK VALIDATION =============

  async validateTestData(testData: Record<string, any>): Promise<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];

    // Validate required reference data
    if (testData.category_id && !(await this.validateProductCategory(testData.category_id))) {
      errors.push(`Invalid product category: ${testData.category_id}`);
    }

    if (testData.product_id && !(await this.validateProduct(testData.product_id))) {
      errors.push(`Invalid product: ${testData.product_id}`);
    }

    if (testData.machine_id && !(await this.validateMachine(testData.machine_id))) {
      errors.push(`Invalid machine: ${testData.machine_id}`);
    }

    if (testData.officer_id && !(await this.validateOfficer(testData.officer_id))) {
      errors.push(`Invalid officer: ${testData.officer_id}`);
    }

    if (testData.plant_id && !(await this.validatePlant(testData.plant_id))) {
      errors.push(`Invalid plant: ${testData.plant_id}`);
    }

    if (testData.mould_id && !(await this.validateMouldReference(testData.mould_id))) {
      errors.push(`Invalid mould reference: ${testData.mould_id}`);
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // ============= DATA RETRIEVAL METHODS =============

  async getProductCategories(): Promise<ProductCategory[]> {
    return await this.executeQuery('SELECT * FROM product_categories ORDER BY name');
  }

  async getProductsByCategory(categoryId: string): Promise<Product[]> {
    return await this.executeQuery(
      'SELECT * FROM products WHERE category_id = ? ORDER BY name',
      [categoryId]
    );
  }

  async getAllProducts(): Promise<Product[]> {
    return await this.executeQuery('SELECT * FROM products ORDER BY name');
  }

  async getGrades(): Promise<Grade[]> {
    return await this.executeQuery('SELECT * FROM grades ORDER BY name');
  }

  async getMachines(): Promise<Machine[]> {
    return await this.executeQuery('SELECT * FROM machines ORDER BY name');
  }

  async getMouldReferences(): Promise<MouldReference[]> {
    return await this.executeQuery('SELECT * FROM mould_references ORDER BY name');
  }

  async getPlants(): Promise<Plant[]> {
    return await this.executeQuery('SELECT * FROM plants ORDER BY name');
  }

  async getOfficers(): Promise<Officer[]> {
    return await this.executeQuery('SELECT * FROM officers ORDER BY name');
  }

  async getAggregates(): Promise<Aggregate[]> {
    return await this.executeQuery('SELECT * FROM aggregates ORDER BY size_range');
  }

  async getAdmixtures(): Promise<Admixture[]> {
    return await this.executeQuery('SELECT * FROM admixtures ORDER BY name');
  }

  async getFreeWaterTypes(): Promise<FreeWater[]> {
    return await this.executeQuery('SELECT * FROM free_water ORDER BY name');
  }

  async getCementTypes(): Promise<CementType[]> {
    return await this.executeQuery('SELECT * FROM cement_types ORDER BY name');
  }

  async getVibratorStatuses(): Promise<VibratorStatus[]> {
    return await this.executeQuery('SELECT * FROM vibrator_status ORDER BY name');
  }

  async getConformityOptions(): Promise<ConformityOption[]> {
    return await this.executeQuery('SELECT * FROM conformity_options ORDER BY name');
  }

  async getTestTypes(): Promise<TestType[]> {
    return await this.executeQuery('SELECT * FROM test_types ORDER BY name');
  }

  async getClimaticConditions(): Promise<ClimaticCondition[]> {
    return await this.executeQuery('SELECT * FROM climatic_conditions ORDER BY name');
  }

  async getSamplingPlaces(): Promise<SamplingPlace[]> {
    return await this.executeQuery('SELECT * FROM sampling_places ORDER BY name');
  }

  async getSampledByOptions(): Promise<SampledBy[]> {
    return await this.executeQuery('SELECT * FROM sampled_by ORDER BY name');
  }

  // ============= CRUD OPERATIONS =============

  // Product Categories CRUD
  async addProductCategory(data: Omit<ProductCategory, 'category_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO product_categories (category_id, name, description, test_module) VALUES (?, ?, ?, ?)',
      [id, data.name, data.description || '', data.test_module]
    );
    return id;
  }

  async updateProductCategory(id: string, data: Partial<ProductCategory>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'category_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'category_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE product_categories SET ${fields} WHERE category_id = ?`,
      [...values, id]
    );
  }

  async deleteProductCategory(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM product_categories WHERE category_id = ?', [id]);
  }

  // Products CRUD
  async addProduct(data: Omit<Product, 'product_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO products (product_id, name, category_id, product_code, grade_id, test_module) VALUES (?, ?, ?, ?, ?, ?)',
      [id, data.name, data.category_id, data.product_code, data.grade_id || null, data.test_module]
    );
    return id;
  }

  async updateProduct(id: string, data: Partial<Product>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'product_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'product_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE products SET ${fields} WHERE product_id = ?`,
      [...values, id]
    );
  }

  async deleteProduct(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM products WHERE product_id = ?', [id]);
  }

  // Grades CRUD
  async addGrade(data: Omit<Grade, 'grade_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO grades (grade_id, name, mpa_value, description) VALUES (?, ?, ?, ?)',
      [id, data.name, data.mpa_value || null, data.description || '']
    );
    return id;
  }

  async updateGrade(id: string, data: Partial<Grade>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'grade_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'grade_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE grades SET ${fields} WHERE grade_id = ?`,
      [...values, id]
    );
  }

  async deleteGrade(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM grades WHERE grade_id = ?', [id]);
  }

  // Plants CRUD
  async addPlant(data: Omit<Plant, 'plant_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO plants (plant_id, name, location, code) VALUES (?, ?, ?, ?)',
      [id, data.name, data.location || '', data.code || '']
    );
    return id;
  }

  async updatePlant(id: string, data: Partial<Plant>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'plant_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'plant_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE plants SET ${fields} WHERE plant_id = ?`,
      [...values, id]
    );
  }

  async deletePlant(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM plants WHERE plant_id = ?', [id]);
  }

  // Officers CRUD
  async addOfficer(data: Omit<Officer, 'officer_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO officers (officer_id, name, role, department, certification) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.role, data.department || '', data.certification || '']
    );
    return id;
  }

  async updateOfficer(id: string, data: Partial<Officer>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'officer_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'officer_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE officers SET ${fields} WHERE officer_id = ?`,
      [...values, id]
    );
  }

  async deleteOfficer(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM officers WHERE officer_id = ?', [id]);
  }

  // Machines CRUD
  async addMachine(data: Omit<Machine, 'machine_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO machines (machine_id, name, type, location, capacity) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.type, data.location || '', data.capacity || '']
    );
    return id;
  }

  async updateMachine(id: string, data: Partial<Machine>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'machine_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'machine_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE machines SET ${fields} WHERE machine_id = ?`,
      [...values, id]
    );
  }

  async deleteMachine(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM machines WHERE machine_id = ?', [id]);
  }

  // Aggregates CRUD
  async addAggregate(data: Omit<Aggregate, 'aggregate_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO aggregates (aggregate_id, name, size_range, type, density) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.size_range, data.type, data.density || null]
    );
    return id;
  }

  async updateAggregate(id: string, data: Partial<Aggregate>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'aggregate_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'aggregate_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE aggregates SET ${fields} WHERE aggregate_id = ?`,
      [...values, id]
    );
  }

  async deleteAggregate(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM aggregates WHERE aggregate_id = ?', [id]);
  }

  // Admixtures CRUD
  async addAdmixture(data: Omit<Admixture, 'admixture_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO admixtures (admixture_id, name, type, dosage_range, supplier) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.type, data.dosage_range || '', data.supplier || '']
    );
    return id;
  }

  async updateAdmixture(id: string, data: Partial<Admixture>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'admixture_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'admixture_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE admixtures SET ${fields} WHERE admixture_id = ?`,
      [...values, id]
    );
  }

  async deleteAdmixture(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM admixtures WHERE admixture_id = ?', [id]);
  }

  // Free Water CRUD
  async addFreeWater(data: Omit<FreeWater, 'water_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO free_water (water_id, name, source, quality_grade, ph_value) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.source, data.quality_grade || '', data.ph_value || null]
    );
    return id;
  }

  async updateFreeWater(id: string, data: Partial<FreeWater>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'water_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'water_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE free_water SET ${fields} WHERE water_id = ?`,
      [...values, id]
    );
  }

  async deleteFreeWater(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM free_water WHERE water_id = ?', [id]);
  }

  // Cement Types CRUD
  async addCementType(data: Omit<CementType, 'cement_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO cement_types (cement_id, name, type, grade, supplier) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.type, data.grade || '', data.supplier || '']
    );
    return id;
  }

  async updateCementType(id: string, data: Partial<CementType>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'cement_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'cement_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE cement_types SET ${fields} WHERE cement_id = ?`,
      [...values, id]
    );
  }

  async deleteCementType(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM cement_types WHERE cement_id = ?', [id]);
  }

  // Vibrator Status CRUD
  async addVibratorStatus(data: Omit<VibratorStatus, 'status_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO vibrator_status (status_id, name, code, description) VALUES (?, ?, ?, ?)',
      [id, data.name, data.code, data.description || '']
    );
    return id;
  }

  async updateVibratorStatus(id: string, data: Partial<VibratorStatus>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'status_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'status_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE vibrator_status SET ${fields} WHERE status_id = ?`,
      [...values, id]
    );
  }

  async deleteVibratorStatus(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM vibrator_status WHERE status_id = ?', [id]);
  }

  // Conformity Options CRUD
  async addConformityOption(data: Omit<ConformityOption, 'option_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO conformity_options (option_id, symbol, name, description) VALUES (?, ?, ?, ?)',
      [id, data.symbol, data.name, data.description || '']
    );
    return id;
  }

  async updateConformityOption(id: string, data: Partial<ConformityOption>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'option_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'option_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE conformity_options SET ${fields} WHERE option_id = ?`,
      [...values, id]
    );
  }

  async deleteConformityOption(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM conformity_options WHERE option_id = ?', [id]);
  }

  // Test Types CRUD
  async addTestType(data: Omit<TestType, 'test_type_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO test_types (test_type_id, name, category, standard, equipment_required) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.category, data.standard || '', data.equipment_required || '']
    );
    return id;
  }

  async updateTestType(id: string, data: Partial<TestType>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'test_type_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'test_type_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE test_types SET ${fields} WHERE test_type_id = ?`,
      [...values, id]
    );
  }

  async deleteTestType(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM test_types WHERE test_type_id = ?', [id]);
  }

  // Climatic Conditions CRUD
  async addClimaticCondition(data: Omit<ClimaticCondition, 'climatic_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO climatic_conditions (climatic_id, name, description) VALUES (?, ?, ?)',
      [id, data.name, data.description || '']
    );
    return id;
  }

  async updateClimaticCondition(id: string, data: Partial<ClimaticCondition>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'climatic_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'climatic_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE climatic_conditions SET ${fields} WHERE climatic_id = ?`,
      [...values, id]
    );
  }

  async deleteClimaticCondition(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM climatic_conditions WHERE climatic_id = ?', [id]);
  }

  // Sampling Places CRUD
  async addSamplingPlace(data: Omit<SamplingPlace, 'place_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO sampling_places (place_id, name, location, description) VALUES (?, ?, ?, ?)',
      [id, data.name, data.location || '', data.description || '']
    );
    return id;
  }

  async updateSamplingPlace(id: string, data: Partial<SamplingPlace>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'place_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'place_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE sampling_places SET ${fields} WHERE place_id = ?`,
      [...values, id]
    );
  }

  async deleteSamplingPlace(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM sampling_places WHERE place_id = ?', [id]);
  }

  // Sampled By CRUD
  async addSampledBy(data: Omit<SampledBy, 'sampler_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO sampled_by (sampler_id, name, role, certification) VALUES (?, ?, ?, ?)',
      [id, data.name, data.role || '', data.certification || '']
    );
    return id;
  }

  async updateSampledBy(id: string, data: Partial<SampledBy>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'sampler_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'sampler_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE sampled_by SET ${fields} WHERE sampler_id = ?`,
      [...values, id]
    );
  }

  async deleteSampledBy(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM sampled_by WHERE sampler_id = ?', [id]);
  }

  // Mould References CRUD
  async addMouldReference(data: Omit<MouldReference, 'mould_id'>): Promise<string> {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    await this.executeQuery(
      'INSERT INTO mould_references (mould_id, name, code, machine_id, dimensions, position_numbers) VALUES (?, ?, ?, ?, ?, ?)',
      [id, data.name, data.code, data.machine_id || null, data.dimensions || '', data.position_numbers || '']
    );
    return id;
  }

  async updateMouldReference(id: string, data: Partial<MouldReference>): Promise<void> {
    const fields = Object.keys(data).filter(key => key !== 'mould_id').join(' = ?, ') + ' = ?';
    const values = Object.entries(data).filter(([key]) => key !== 'mould_id').map(([, value]) => value);
    await this.executeQuery(
      `UPDATE mould_references SET ${fields} WHERE mould_id = ?`,
      [...values, id]
    );
  }

  async deleteMouldReference(id: string): Promise<void> {
    await this.executeQuery('DELETE FROM mould_references WHERE mould_id = ?', [id]);
  }

  // ============= CSV IMPORT METHODS =============

  async importProductCategories(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM product_categories');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO product_categories (category_id, name, description, test_module) VALUES (?, ?, ?, ?)',
        [
          row.category_id || row.id || row.code,
          row.name,
          row.description || '',
          row.test_module || 'blocks'
        ]
      );
    }
  }

  async importProducts(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM products');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO products (product_id, name, category_id, product_code, grade_id, test_module) VALUES (?, ?, ?, ?, ?, ?)',
        [
          row.product_id || row.id,
          row.name,
          row.category_id,
          row.product_code || row.code,
          row.grade_id || null,
          row.test_module || 'blocks'
        ]
      );
    }
  }

  async importMachines(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM machines');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO machines (machine_id, name, type, location, capacity) VALUES (?, ?, ?, ?, ?)',
        [
          row.machine_id || row.id || row.code,
          row.name,
          row.type || '',
          row.location || '',
          row.capacity || ''
        ]
      );
    }
  }

  async importOfficers(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM officers');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO officers (officer_id, name, role, department, certification) VALUES (?, ?, ?, ?, ?)',
        [
          row.officer_id || row.id || row.code,
          row.name,
          row.role || '',
          row.department || '',
          row.certification || ''
        ]
      );
    }
  }

  async importPlants(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM plants');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO plants (plant_id, name, location, code) VALUES (?, ?, ?, ?)',
        [
          row.plant_id || row.id,
          row.name,
          row.location || '',
          row.code || ''
        ]
      );
    }
  }

  async importAggregates(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM aggregates');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO aggregates (aggregate_id, name, size_range, type, density) VALUES (?, ?, ?, ?, ?)',
        [
          row.aggregate_id || row.id,
          row.name,
          row.size_range || '',
          row.type || '',
          parseFloat(row.density) || null
        ]
      );
    }
  }

  async importAdmixtures(csvData: any[]): Promise<void> {
    await this.executeQuery('DELETE FROM admixtures');
    
    for (const row of csvData) {
      await this.executeQuery(
        'INSERT INTO admixtures (admixture_id, name, type, dosage_range, supplier) VALUES (?, ?, ?, ?, ?)',
        [
          row.admixture_id || row.id,
          row.name,
          row.type || '',
          row.dosage_range || '',
          row.supplier || ''
        ]
      );
    }
  }

  // ============= TEST MODULE ROUTING =============

  getTestModuleForCategory(categoryId: string): string {
    // Map categories to their corresponding test module databases
    const categoryModuleMap: Record<string, string> = {
      'blocks': 'blocks',
      'aggregates': 'aggregates', 
      'concrete': 'concrete',
      'kerbs': 'kerbs',
      'flags': 'flags',
      'pavers': 'pavers'
    };

    return categoryModuleMap[categoryId.toLowerCase()] || 'blocks';
  }

  async getTestModuleDbName(categoryId: string): Promise<string> {
    const module = this.getTestModuleForCategory(categoryId);
    return `${module}.db`;
  }

  // ============= CSV PARSING UTILITY =============

  parseCSV(csvContent: string): any[] {
    const lines = csvContent.trim().split('\n');
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      const row: any = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      data.push(row);
    }

    return data;
  }

  // ============= IMPORT DISPATCHER =============

  async importReferenceData(filename: string, csvContent: string): Promise<void> {
    const data = this.parseCSV(csvContent);
    
    if (data.length === 0) {
      throw new Error('No data found in CSV file');
    }

    const lowerFilename = filename.toLowerCase();
    
    try {
      if (lowerFilename.includes('categor') || lowerFilename.includes('product_categories')) {
        await this.importProductCategories(data);
        toast({ title: "Success", description: `Imported ${data.length} product categories` });
      } else if (lowerFilename.includes('product') && !lowerFilename.includes('categor')) {
        await this.importProducts(data);
        toast({ title: "Success", description: `Imported ${data.length} products` });
      } else if (lowerFilename.includes('machine')) {
        await this.importMachines(data);
        toast({ title: "Success", description: `Imported ${data.length} machines` });
      } else if (lowerFilename.includes('officer')) {
        await this.importOfficers(data);
        toast({ title: "Success", description: `Imported ${data.length} officers` });
      } else if (lowerFilename.includes('plant')) {
        await this.importPlants(data);
        toast({ title: "Success", description: `Imported ${data.length} plants` });
      } else if (lowerFilename.includes('aggregate')) {
        await this.importAggregates(data);
        toast({ title: "Success", description: `Imported ${data.length} aggregates` });
      } else if (lowerFilename.includes('admixture')) {
        await this.importAdmixtures(data);
        toast({ title: "Success", description: `Imported ${data.length} admixtures` });
      } else {
        throw new Error(`Unknown reference data type for file: ${filename}`);
      }
    } catch (error) {
      console.error('Import failed:', error);
      toast({ 
        title: "Import Failed", 
        description: `Failed to import ${filename}: ${error}`,
        variant: "destructive"
      });
      throw error;
    }
  }

  // ============= POPULATE SAMPLE DATA =============

  async populateAllSampleData(): Promise<void> {
    try {
      // Initialize tables first
      await this.initializeAllReferenceTables();

      // For clean prototype - skip sample data population
      console.log('Sample data population disabled for clean prototype');
      return;
    } catch (error) {
      console.error('Failed to populate sample reference data:', error);
      throw error;
    }
  }

  async populateAggregateReferenceData(): Promise<void> {
    try {
      // Initialize tables first  
      await this.initializeAllReferenceTables();

      // For clean prototype - skip sample data population
      console.log('Aggregate sample data population disabled for clean prototype');
      return;
    } catch (error) {
      console.error('Failed to populate aggregate reference data:', error);
      throw error;
    }
  }
}

export const enhancedReferenceDataService = new EnhancedReferenceDataService();