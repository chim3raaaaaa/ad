// Test Modules Database Migration Service

// Migration utility functions
function generateMigrationId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

async function logMigration(migrationId: string, name: string, status: string, message: string): Promise<void> {
  if (!window.electronAPI) return;
  
  try {
    await window.electronAPI.dbQuery(
      `INSERT OR REPLACE INTO migration_history (id, name, status, message, executed_at) 
       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [migrationId, name, status, message]
    );
  } catch (error) {
    console.error('Failed to log migration:', error);
  }
}

async function getMigrationHistory(pattern?: string): Promise<any[]> {
  if (!window.electronAPI) return [];
  
  try {
    const query = pattern 
      ? `SELECT * FROM migration_history WHERE name LIKE ? ORDER BY executed_at DESC`
      : `SELECT * FROM migration_history ORDER BY executed_at DESC`;
    const params = pattern ? [pattern] : [];
    
    const result = await window.electronAPI.dbQuery(query, params);
    return result.success ? result.data : [];
  } catch (error) {
    console.error('Failed to get migration history:', error);
    return [];
  }
}

export interface MigrationResult {
  success: boolean;
  migrationId: string;
  message: string;
  tablesCreated: string[];
  dataSeeded: number;
}

export class TestModulesMigrationService {
  
  /**
   * Run all test modules migrations
   */
  static async runMigrations(): Promise<MigrationResult> {
    const migrationId = generateMigrationId('test_modules_init');
    
    try {
      console.log('Starting Test Modules migrations...');
      
      const tablesCreated: string[] = [];
      let dataSeeded = 0;

      // Create core tables
      await this.createProductCategoriesTable();
      tablesCreated.push('product_categories');

      await this.createProductTypesTable();
      tablesCreated.push('product_types');

      await this.createProductFieldsTable();
      tablesCreated.push('product_fields');

      await this.createTestEntriesTable();
      tablesCreated.push('test_entries');

      await this.createPlantConfigurationTables();
      tablesCreated.push('plant_configurations', 'plant_machines', 'plant_officers');

      await this.createMemoTestAssignmentsTable();
      tablesCreated.push('memo_test_assignments');

      // Seed default data
      const seededCount = await this.seedDefaultData();
      dataSeeded = seededCount;

      // Log successful migration
      await logMigration(migrationId, 'test_modules_init', 'success', 
        `Created ${tablesCreated.length} tables and seeded ${dataSeeded} records`);

      return {
        success: true,
        migrationId,
        message: `Test Modules migration completed successfully. Created ${tablesCreated.length} tables.`,
        tablesCreated,
        dataSeeded
      };

    } catch (error) {
      console.error('Test Modules migration failed:', error);
      
      // Log failed migration
      await logMigration(migrationId, 'test_modules_init', 'failed', 
        error instanceof Error ? error.message : 'Unknown error');

      return {
        success: false,
        migrationId,
        message: `Migration failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        tablesCreated: [],
        dataSeeded: 0
      };
    }
  }

  /**
   * Create product categories table
   */
  private static async createProductCategoriesTable(): Promise<void> {
    if (!window.electronAPI) return;

    const sql = `
      CREATE TABLE IF NOT EXISTS product_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        icon TEXT DEFAULT 'TestTube',
        sort_order INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    const result = await window.electronAPI.dbQuery(sql);
    if (!result.success) {
      throw new Error(`Failed to create product_categories table: ${result.error}`);
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_categories_active ON product_categories(is_active)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_categories_sort ON product_categories(sort_order)`
    );
  }

  /**
   * Create product types table
   */
  private static async createProductTypesTable(): Promise<void> {
    if (!window.electronAPI) return;

    const sql = `
      CREATE TABLE IF NOT EXISTS product_types (
        id TEXT PRIMARY KEY,
        category_id TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        table_suffix TEXT NOT NULL UNIQUE,
        is_active BOOLEAN DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES product_categories(id),
        UNIQUE(category_id, name)
      )
    `;

    const result = await window.electronAPI.dbQuery(sql);
    if (!result.success) {
      throw new Error(`Failed to create product_types table: ${result.error}`);
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_types_category ON product_types(category_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_types_active ON product_types(is_active)`
    );
  }

  /**
   * Create product fields table
   */
  private static async createProductFieldsTable(): Promise<void> {
    if (!window.electronAPI) return;

    const sql = `
      CREATE TABLE IF NOT EXISTS product_fields (
        id TEXT PRIMARY KEY,
        product_type_id TEXT NOT NULL,
        field_name TEXT NOT NULL,
        field_label TEXT NOT NULL,
        field_type TEXT NOT NULL CHECK (field_type IN ('text', 'number', 'date', 'select', 'textarea', 'boolean', 'file')),
        field_unit TEXT,
        is_required BOOLEAN DEFAULT 0,
        validation_rules TEXT DEFAULT '[]',
        field_options TEXT,
        sort_order INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id),
        UNIQUE(product_type_id, field_name)
      )
    `;

    const result = await window.electronAPI.dbQuery(sql);
    if (!result.success) {
      throw new Error(`Failed to create product_fields table: ${result.error}`);
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_fields_type ON product_fields(product_type_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_product_fields_sort ON product_fields(sort_order)`
    );
  }

  /**
   * Create test entries table
   */
  private static async createTestEntriesTable(): Promise<void> {
    if (!window.electronAPI) return;

    const sql = `
      CREATE TABLE IF NOT EXISTS test_entries (
        id TEXT PRIMARY KEY,
        product_type_id TEXT NOT NULL,
        memo_id TEXT,
        plant_id TEXT NOT NULL,
        officer_id TEXT NOT NULL,
        test_date DATE NOT NULL,
        test_data TEXT NOT NULL DEFAULT '{}',
        status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'approved', 'rejected')),
        notes TEXT,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id)
      )
    `;

    const result = await window.electronAPI.dbQuery(sql);
    if (!result.success) {
      throw new Error(`Failed to create test_entries table: ${result.error}`);
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_test_entries_product_type ON test_entries(product_type_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_test_entries_memo ON test_entries(memo_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_test_entries_plant ON test_entries(plant_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_test_entries_date ON test_entries(test_date)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_test_entries_status ON test_entries(status)`
    );
  }

  /**
   * Create plant configuration tables
   */
  private static async createPlantConfigurationTables(): Promise<void> {
    if (!window.electronAPI) return;

    // Plant configurations table
    const plantsSql = `
      CREATE TABLE IF NOT EXISTS plant_configurations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        location TEXT,
        contact_info TEXT DEFAULT '{}',
        is_active BOOLEAN DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Plant machines table
    const machinesSql = `
      CREATE TABLE IF NOT EXISTS plant_machines (
        id TEXT PRIMARY KEY,
        plant_id TEXT NOT NULL,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        specifications TEXT DEFAULT '{}',
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (plant_id) REFERENCES plant_configurations(id),
        UNIQUE(plant_id, name)
      )
    `;

    // Plant officers table
    const officersSql = `
      CREATE TABLE IF NOT EXISTS plant_officers (
        id TEXT PRIMARY KEY,
        plant_id TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        contact_info TEXT DEFAULT '{}',
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (plant_id) REFERENCES plant_configurations(id),
        UNIQUE(plant_id, name)
      )
    `;

    const results = await Promise.all([
      window.electronAPI.dbQuery(plantsSql),
      window.electronAPI.dbQuery(machinesSql),
      window.electronAPI.dbQuery(officersSql)
    ]);

    for (const result of results) {
      if (!result.success) {
        throw new Error(`Failed to create plant configuration tables: ${result.error}`);
      }
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_plant_machines_plant ON plant_machines(plant_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_plant_officers_plant ON plant_officers(plant_id)`
    );
  }

  /**
   * Create memo test assignments table
   */
  private static async createMemoTestAssignmentsTable(): Promise<void> {
    if (!window.electronAPI) return;

    const sql = `
      CREATE TABLE IF NOT EXISTS memo_test_assignments (
        id TEXT PRIMARY KEY,
        memo_id TEXT NOT NULL,
        product_type_id TEXT NOT NULL,
        required_tests TEXT DEFAULT '[]',
        assigned_to TEXT,
        due_date DATE,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'overdue')),
        test_entry_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_type_id) REFERENCES product_types(id),
        FOREIGN KEY (test_entry_id) REFERENCES test_entries(id),
        UNIQUE(memo_id, product_type_id)
      )
    `;

    const result = await window.electronAPI.dbQuery(sql);
    if (!result.success) {
      throw new Error(`Failed to create memo_test_assignments table: ${result.error}`);
    }

    // Create indexes
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_memo_assignments_memo ON memo_test_assignments(memo_id)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_memo_assignments_assigned ON memo_test_assignments(assigned_to)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_memo_assignments_status ON memo_test_assignments(status)`
    );
    await window.electronAPI.dbQuery(
      `CREATE INDEX IF NOT EXISTS idx_memo_assignments_due ON memo_test_assignments(due_date)`
    );
  }

  /**
   * Seed default data
   */
  private static async seedDefaultData(): Promise<number> {
    if (!window.electronAPI) return 0;

    let seededCount = 0;

    try {
      // Check if data already exists
      const existingCategories = await window.electronAPI.dbQuery(
        `SELECT COUNT(*) as count FROM product_categories`
      );

      if (existingCategories.success && existingCategories.data[0].count > 0) {
        console.log('Default data already exists, skipping seeding');
        return 0;
      }

      // Seed product categories
      const categories = [
        {
          id: 'aggregates',
          name: 'Aggregates',
          description: 'Sand, gravel, and crushed stone testing',
          icon: 'TestTube',
          sort_order: 1
        },
        {
          id: 'concrete',
          name: 'Concrete',
          description: 'Concrete mix and cube testing',
          icon: 'Building',
          sort_order: 2
        },
        {
          id: 'blocks',
          name: 'Blocks',
          description: 'Concrete block testing',
          icon: 'Package2',
          sort_order: 3
        },
        {
          id: 'pavers',
          name: 'Pavers',
          description: 'Paving stone testing',
          icon: 'Layers',
          sort_order: 4
        },
        {
          id: 'kerbs',
          name: 'Kerbs',
          description: 'Kerb stone testing',
          icon: 'Database',
          sort_order: 5
        },
        {
          id: 'flagstones',
          name: 'Flagstones',
          description: 'Flagstone testing',
          icon: 'Zap',
          sort_order: 6
        }
      ];

      for (const category of categories) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_categories (id, name, description, icon, sort_order, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, 1, 'system')`,
          [category.id, category.name, category.description, category.icon, category.sort_order]
        );
        if (result.success) seededCount++;
      }

      // Seed default product types for aggregates
      const aggregateTypes = [
        {
          id: 'fine_aggregates',
          category_id: 'aggregates',
          name: 'Fine Aggregates',
          description: 'Sand and fine aggregate testing',
          table_suffix: 'fine_aggregates'
        },
        {
          id: 'coarse_aggregates',
          category_id: 'aggregates',
          name: 'Coarse Aggregates',
          description: 'Gravel and coarse aggregate testing',
          table_suffix: 'coarse_aggregates'
        }
      ];

      for (const type of aggregateTypes) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_types (id, category_id, name, description, table_suffix, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, 1, 'system')`,
          [type.id, type.category_id, type.name, type.description, type.table_suffix]
        );
        if (result.success) seededCount++;
      }

      // Seed default fields for fine aggregates
      const fineAggregateFields = [
        {
          id: 'field_sampling_date',
          product_type_id: 'fine_aggregates',
          field_name: 'sampling_date',
          field_label: 'Date of Sampling',
          field_type: 'date',
          is_required: true,
          sort_order: 1
        },
        {
          id: 'field_material_type',
          product_type_id: 'fine_aggregates',
          field_name: 'material_type',
          field_label: 'Type of Material',
          field_type: 'select',
          is_required: true,
          field_options: JSON.stringify(['River Sand', 'Manufactured Sand', 'Beach Sand', 'Desert Sand']),
          sort_order: 2
        },
        {
          id: 'field_fineness_modulus',
          product_type_id: 'fine_aggregates',
          field_name: 'fineness_modulus',
          field_label: 'Fineness Modulus',
          field_type: 'number',
          field_unit: '',
          is_required: true,
          validation_rules: JSON.stringify([
            { type: 'min', value: 1.0, message: 'Fineness modulus must be at least 1.0' },
            { type: 'max', value: 4.0, message: 'Fineness modulus must be at most 4.0' }
          ]),
          sort_order: 3
        },
        {
          id: 'field_specific_gravity',
          product_type_id: 'fine_aggregates',
          field_name: 'specific_gravity',
          field_label: 'Specific Gravity',
          field_type: 'number',
          field_unit: '',
          is_required: true,
          validation_rules: JSON.stringify([
            { type: 'min', value: 2.0, message: 'Specific gravity must be at least 2.0' },
            { type: 'max', value: 3.0, message: 'Specific gravity must be at most 3.0' }
          ]),
          sort_order: 4
        },
        {
          id: 'field_water_absorption',
          product_type_id: 'fine_aggregates',
          field_name: 'water_absorption',
          field_label: 'Water Absorption',
          field_type: 'number',
          field_unit: '%',
          is_required: true,
          validation_rules: JSON.stringify([
            { type: 'min', value: 0, message: 'Water absorption cannot be negative' },
            { type: 'max', value: 10, message: 'Water absorption seems too high (>10%)' }
          ]),
          sort_order: 5
        }
      ];

      for (const field of fineAggregateFields) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO product_fields 
           (id, product_type_id, field_name, field_label, field_type, field_unit, is_required, 
            validation_rules, field_options, sort_order, is_active, created_by) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'system')`,
          [field.id, field.product_type_id, field.field_name, field.field_label, 
           field.field_type, field.field_unit || null, field.is_required,
           field.validation_rules || '[]', field.field_options || null, field.sort_order]
        );
        if (result.success) seededCount++;
      }

      // Seed default plant configuration
      const defaultPlant = {
        id: 'plant_main',
        name: 'Main Plant',
        location: 'Port Louis, Mauritius',
        contact_info: JSON.stringify({
          phone: '+230 123 4567',
          email: 'plant@ubp.mu',
          address: 'Industrial Zone, Port Louis'
        })
      };

      const plantResult = await window.electronAPI.dbQuery(
        `INSERT INTO plant_configurations (id, name, location, contact_info, is_active, created_by) 
         VALUES (?, ?, ?, ?, 1, 'system')`,
        [defaultPlant.id, defaultPlant.name, defaultPlant.location, defaultPlant.contact_info]
      );
      if (plantResult.success) seededCount++;

      // Seed default officers
      const defaultOfficers = [
        {
          id: 'officer_chief',
          plant_id: 'plant_main',
          name: 'Chief Testing Officer',
          role: 'Chief Officer',
          contact_info: JSON.stringify({ extension: '101' })
        },
        {
          id: 'officer_tech',
          plant_id: 'plant_main',
          name: 'Laboratory Technician',
          role: 'Technician',
          contact_info: JSON.stringify({ extension: '102' })
        }
      ];

      for (const officer of defaultOfficers) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO plant_officers (id, plant_id, name, role, contact_info, is_active) 
           VALUES (?, ?, ?, ?, ?, 1)`,
          [officer.id, officer.plant_id, officer.name, officer.role, officer.contact_info]
        );
        if (result.success) seededCount++;
      }

      console.log(`Seeded ${seededCount} default records`);
      return seededCount;

    } catch (error) {
      console.error('Failed to seed default data:', error);
      throw error;
    }
  }

  /**
   * Check if migrations are needed
   */
  static async checkMigrationStatus(): Promise<{ needed: boolean; reason: string }> {
    try {
      if (!window.electronAPI) {
        return { needed: false, reason: 'Not in Electron environment' };
      }

      // Check if core tables exist
      const tables = ['product_categories', 'product_types', 'product_fields', 'test_entries'];
      
      for (const table of tables) {
        const result = await window.electronAPI.dbQuery(
          `SELECT name FROM sqlite_master WHERE type='table' AND name=?`,
          [table]
        );
        
        if (!result.success || result.data.length === 0) {
          return { needed: true, reason: `Missing table: ${table}` };
        }
      }

      // Check if default data exists
      const categoryCount = await window.electronAPI.dbQuery(
        `SELECT COUNT(*) as count FROM product_categories`
      );

      if (categoryCount.success && categoryCount.data[0].count === 0) {
        return { needed: true, reason: 'No default data found' };
      }

      return { needed: false, reason: 'All migrations completed' };

    } catch (error) {
      return { needed: true, reason: `Migration check failed: ${error}` };
    }
  }

  /**
   * Get migration history for test modules
   */
  static async getMigrationHistory(): Promise<any[]> {
    return getMigrationHistory('test_modules_%');
  }
}