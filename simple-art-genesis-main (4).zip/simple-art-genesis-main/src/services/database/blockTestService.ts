import { toast } from '@/hooks/use-toast';

export interface BlockTestData {
  id: string;
  memo_reference: string;
  plant_id: string;
  product_type: string;
  test_date: string;
  officer_id: string;
  machine_id?: string;
  
  // Block-specific test parameters
  block_type: string;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  weight: number;
  density: number;
  compressive_strength: number;
  water_absorption: number;
  thermal_conductivity?: number;
  
  // Test conditions
  curing_period: number;
  test_temperature: number;
  humidity: number;
  
  // Results
  pass_fail_status: 'pass' | 'fail' | 'pending';
  compliance_notes?: string;
  
  created_at: string;
  updated_at: string;
}

export interface BlockDatabase {
  id: string;
  name: string;
  plant_id: string;
  product_type: string;
  table_name: string;
  created_at: string;
  record_count: number;
}

class BlockTestService {
  private storageKey = 'block_databases';

  async getPlantDatabases(plantId: string): Promise<BlockDatabase[]> {
    try {
      const stored = localStorage.getItem(this.storageKey);
      const allDatabases: BlockDatabase[] = stored ? JSON.parse(stored) : [];
      
      // Filter by plant and add record counts
      const plantDatabases = allDatabases.filter(db => db.plant_id === plantId);
      return plantDatabases.map(db => ({
        ...db,
        record_count: this.getRecordCount(db.table_name)
      }));
    } catch (error) {
      console.error('Error fetching block databases:', error);
      return [];
    }
  }

  private getRecordCount(tableName: string): number {
    try {
      const stored = localStorage.getItem(tableName);
      return stored ? JSON.parse(stored).length : 0;
    } catch {
      return 0;
    }
  }

  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const tableName = `block_tests_${plantId}_${productType}`.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    try {
      // Create the database entry
      const database: BlockDatabase = {
        id: `block_db_${Date.now()}`,
        name: `Block Tests - ${productType}`,
        plant_id: plantId,
        product_type: productType,
        table_name: tableName,
        created_at: new Date().toISOString(),
        record_count: 0
      };

      // Store database metadata
      const stored = localStorage.getItem(this.storageKey);
      const databases: BlockDatabase[] = stored ? JSON.parse(stored) : [];
      databases.push(database);
      localStorage.setItem(this.storageKey, JSON.stringify(databases));

      // Initialize empty table
      localStorage.setItem(tableName, JSON.stringify([]));

      toast({
        title: "Database Created",
        description: `Block test database created for ${productType} at plant ${plantName}`
      });

      return database.id;
    } catch (error) {
      console.error('Error creating block database:', error);
      toast({
        title: "Error",
        description: "Failed to create block test database",
        variant: "destructive"
      });
      throw error;
    }
  }

  async getTestEntries(tableName: string, filters?: Record<string, any>): Promise<BlockTestData[]> {
    try {
      const stored = localStorage.getItem(tableName);
      const entries: BlockTestData[] = stored ? JSON.parse(stored) : [];
      
      // Apply filters if provided
      if (filters && Object.keys(filters).length > 0) {
        return entries.filter(entry => {
          return Object.entries(filters).every(([key, value]) => entry[key as keyof BlockTestData] === value);
        });
      }
      
      return entries;
    } catch (error) {
      console.error('Error fetching block test entries:', error);
      return [];
    }
  }

  async createTestEntry(tableName: string, testData: Omit<BlockTestData, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    try {
      const entry: BlockTestData = {
        ...testData,
        id: `block_test_${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // Store the entry
      const stored = localStorage.getItem(tableName);
      const entries: BlockTestData[] = stored ? JSON.parse(stored) : [];
      entries.push(entry);
      localStorage.setItem(tableName, JSON.stringify(entries));

      toast({
        title: "Test Entry Created",
        description: `Block test entry ${entry.id} created successfully`
      });

      return entry.id;
    } catch (error) {
      console.error('Error creating block test entry:', error);
      toast({
        title: "Error",
        description: "Failed to create block test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  async updateTestEntry(tableName: string, id: string, updates: Partial<BlockTestData>): Promise<void> {
    try {
      const stored = localStorage.getItem(tableName);
      const entries: BlockTestData[] = stored ? JSON.parse(stored) : [];
      
      const index = entries.findIndex(entry => entry.id === id);
      if (index === -1) {
        throw new Error(`Entry with ID ${id} not found`);
      }

      entries[index] = {
        ...entries[index],
        ...updates,
        updated_at: new Date().toISOString()
      };

      localStorage.setItem(tableName, JSON.stringify(entries));

      toast({
        title: "Test Entry Updated",
        description: `Block test entry ${id} updated successfully`
      });
    } catch (error) {
      console.error('Error updating block test entry:', error);
      toast({
        title: "Error",
        description: "Failed to update block test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  async deleteTestEntry(tableName: string, id: string): Promise<void> {
    try {
      const stored = localStorage.getItem(tableName);
      const entries: BlockTestData[] = stored ? JSON.parse(stored) : [];
      
      const filteredEntries = entries.filter(entry => entry.id !== id);
      localStorage.setItem(tableName, JSON.stringify(filteredEntries));

      toast({
        title: "Test Entry Deleted",
        description: `Block test entry ${id} deleted successfully`
      });
    } catch (error) {
      console.error('Error deleting block test entry:', error);
      toast({
        title: "Error",
        description: "Failed to delete block test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  async validateTestData(testData: BlockTestData, referenceData: any): Promise<{
    isValid: boolean;
    errors: string[];
    warnings: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Validate compressive strength
    if (testData.compressive_strength < 3.5) {
      errors.push(`Compressive strength ${testData.compressive_strength} MPa is below minimum requirement of 3.5 MPa`);
    } else if (testData.compressive_strength < 5.0) {
      warnings.push(`Compressive strength ${testData.compressive_strength} MPa is below recommended minimum of 5.0 MPa`);
    }

    // Validate water absorption
    if (testData.water_absorption > 10) {
      errors.push(`Water absorption ${testData.water_absorption}% exceeds maximum limit of 10%`);
    } else if (testData.water_absorption > 8) {
      warnings.push(`Water absorption ${testData.water_absorption}% is above recommended maximum of 8%`);
    }

    // Validate dimensions
    const { length, width, height } = testData.dimensions;
    if (length < 100 || width < 100 || height < 100) {
      errors.push('Block dimensions must be at least 100mm in all directions');
    }

    // Validate density
    if (testData.density < 1000 || testData.density > 2500) {
      warnings.push(`Density ${testData.density} kg/m³ is outside typical range (1000-2500 kg/m³)`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}

export const blockTestService = new BlockTestService();