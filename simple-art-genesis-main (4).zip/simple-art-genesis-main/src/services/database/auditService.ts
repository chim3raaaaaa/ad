// Audit Trail Service for tracking system activities
import type { IDataService } from '../api/interface';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user_id: string;
  user_name: string;
  action: 'create' | 'update' | 'delete' | 'view' | 'export' | 'login' | 'logout';
  resource_type: string;
  resource_id?: string;
  resource_name?: string;
  old_data?: any;
  new_data?: any;
  ip_address: string;
  user_agent: string;
  session_id: string;
  severity: 'info' | 'warning' | 'critical';
  details?: string;
}

export interface AuditFilters {
  search?: string;
  action?: string;
  resource?: string;
  user?: string;
  severity?: string;
  startDate?: string;
  endDate?: string;
}

export class AuditService {
  constructor(private dataService: IDataService) {}

  // Log an action to the audit trail
  async logAction(
    action: AuditLogEntry['action'],
    resourceType: string,
    resourceId?: string,
    resourceName?: string,
    oldData?: any,
    newData?: any,
    userId = 'current_user',
    severity: AuditLogEntry['severity'] = 'info',
    details?: string
  ): Promise<void> {
    const logEntry: AuditLogEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      user_id: userId,
      user_name: await this.getUserName(userId),
      action,
      resource_type: resourceType,
      resource_id: resourceId,
      resource_name: resourceName,
      old_data: oldData,
      new_data: newData,
      ip_address: await this.getClientIP(),
      user_agent: navigator.userAgent,
      session_id: this.getSessionId(),
      severity,
      details
    };

    // Use the data service to persist the audit log
    await this.dataService.createAuditLog(logEntry);
  }

  // Get filtered audit logs
  async getAuditLogs(filters: AuditFilters = {}): Promise<AuditLogEntry[]> {
    return await this.dataService.getAuditLogs(filters);
  }

  // Get audit statistics
  async getAuditStats(): Promise<{
    totalEntries: number;
    criticalCount: number;
    warningCount: number;
    infoCount: number;
    recentActivity: AuditLogEntry[];
  }> {
    const logs = await this.getAuditLogs();
    
    return {
      totalEntries: logs.length,
      criticalCount: logs.filter(log => log.severity === 'critical').length,
      warningCount: logs.filter(log => log.severity === 'warning').length,
      infoCount: logs.filter(log => log.severity === 'info').length,
      recentActivity: logs.slice(0, 10) // Last 10 entries
    };
  }

  // Export audit logs
  async exportAuditLogs(format: 'csv' | 'json', filters?: AuditFilters): Promise<string> {
    const logs = await this.getAuditLogs(filters);
    
    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    } else {
      const headers = [
        'Timestamp', 'User', 'Action', 'Resource Type', 'Resource Name', 
        'Details', 'Severity', 'IP Address'
      ];
      
      const rows = logs.map(log => [
        log.timestamp,
        log.user_name,
        log.action,
        log.resource_type,
        log.resource_name || '',
        log.details || '',
        log.severity,
        log.ip_address
      ]);
      
      return [headers.join(','), ...rows.map(row => 
        row.map(field => `"${field}"`).join(',')
      )].join('\n');
    }
  }

  // Helper methods
  private async getUserName(userId: string): Promise<string> {
    try {
      const user = await this.dataService.getUserProfile(userId);
      return user.data?.name || 'Unknown User';
    } catch {
      return 'Unknown User';
    }
  }

  private async getClientIP(): Promise<string> {
    try {
      // In a real app, this would get the actual client IP
      return '127.0.0.1';
    } catch {
      return '127.0.0.1';
    }
  }

  private getSessionId(): string {
    // Generate or retrieve session ID
    let sessionId = sessionStorage.getItem('audit_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('audit_session_id', sessionId);
    }
    return sessionId;
  }
}

// Export singleton instance
export const auditService = new AuditService(
  // This will be injected at runtime
  null as any
);