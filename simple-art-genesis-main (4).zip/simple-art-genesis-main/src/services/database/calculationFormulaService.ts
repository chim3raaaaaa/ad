// Database query will be handled through electronAPI

export interface CalculationFormula {
  id?: number;
  name: string;
  expression: string;
  description?: string;
  category: string;
  parameters: string[];
  created_at?: string;
  updated_at?: string;
}

export class CalculationFormulaService {
  private static readonly TABLE_NAME = 'calculation_formulas';

  static async initializeTable(): Promise<void> {
    const schema = `
      CREATE TABLE IF NOT EXISTS ${this.TABLE_NAME} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        expression TEXT NOT NULL,
        description TEXT,
        category TEXT NOT NULL,
        parameters TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `;

    try {
      if (window.electronAPI) {
        await window.electronAPI.dbQuery(schema);
        await this.seedDefaultFormulas();
      }
    } catch (error) {
      console.error('Error initializing calculation formulas table:', error);
      throw error;
    }
  }

  static async seedDefaultFormulas(): Promise<void> {
    const defaultFormulas: Omit<CalculationFormula, 'id' | 'created_at' | 'updated_at'>[] = [
      {
        name: 'Moisture Content',
        expression: '((Ph - Ps) / Ps) * 100',
        description: 'Calculate moisture content percentage from wet and dry masses',
        category: 'aggregate',
        parameters: ['Ph', 'Ps']
      },
      {
        name: 'Percent Passing',
        expression: '100 - ((cum_retained / total_mass) * 100)',
        description: 'Calculate percentage passing through sieve from cumulative retained mass',
        category: 'sieve',
        parameters: ['cum_retained', 'total_mass']
      },
      {
        name: 'Fineness Modulus',
        expression: '(ret_150 + ret_300 + ret_600 + ret_118 + ret_236) / 100',
        description: 'Calculate fineness modulus from cumulative percentages retained',
        category: 'sieve',
        parameters: ['ret_150', 'ret_300', 'ret_600', 'ret_118', 'ret_236']
      },
      {
        name: 'Sand Equivalent ESV',
        expression: '(sum_s1 / sum_s2) * 100',
        description: 'Calculate Sand Equivalent ESV value',
        category: 'sand_equivalent',
        parameters: ['sum_s1', 'sum_s2']
      },
      {
        name: 'Methylene Blue Value',
        expression: '(V1 * normality * 3.1) / sample_mass',
        description: 'Calculate Methylene Blue Value',
        category: 'methylene_blue',
        parameters: ['V1', 'normality', 'sample_mass']
      }
    ];

    for (const formula of defaultFormulas) {
      try {
        await this.createFormula(formula);
      } catch (error) {
        // Ignore duplicate errors on seeding
        if (!error.message?.includes('UNIQUE constraint failed')) {
          console.error('Error seeding formula:', formula.name, error);
        }
      }
    }
  }

  static async listFormulas(): Promise<CalculationFormula[]> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM ${this.TABLE_NAME} ORDER BY category, name`
        );
        return result.data || [];
      }
      return [];
    } catch (error) {
      console.error('Error listing formulas:', error);
      return [];
    }
  }

  static async getFormulasByCategory(category: string): Promise<CalculationFormula[]> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM ${this.TABLE_NAME} WHERE category = ? ORDER BY name`,
          [category]
        );
        return result.data || [];
      }
      return [];
    } catch (error) {
      console.error('Error getting formulas by category:', error);
      return [];
    }
  }

  static async getFormula(name: string): Promise<CalculationFormula | null> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM ${this.TABLE_NAME} WHERE name = ?`,
          [name]
        );
        return result.data?.[0] || null;
      }
      return null;
    } catch (error) {
      console.error('Error getting formula:', error);
      return null;
    }
  }

  static async createFormula(formula: Omit<CalculationFormula, 'id' | 'created_at' | 'updated_at'>): Promise<CalculationFormula> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `INSERT INTO ${this.TABLE_NAME} (name, expression, description, category, parameters) 
           VALUES (?, ?, ?, ?, ?)`,
          [
            formula.name,
            formula.expression,
            formula.description || '',
            formula.category,
            JSON.stringify(formula.parameters)
          ]
        );
        
        if (result.success) {
          return await this.getFormula(formula.name) as CalculationFormula;
        }
      }
      throw new Error('Failed to create formula');
    } catch (error) {
      console.error('Error creating formula:', error);
      throw error;
    }
  }

  static async updateFormula(id: number, updates: Partial<CalculationFormula>): Promise<boolean> {
    try {
      if (window.electronAPI) {
        const setParts = [];
        const values = [];

        if (updates.expression !== undefined) {
          setParts.push('expression = ?');
          values.push(updates.expression);
        }
        if (updates.description !== undefined) {
          setParts.push('description = ?');
          values.push(updates.description);
        }
        if (updates.parameters !== undefined) {
          setParts.push('parameters = ?');
          values.push(JSON.stringify(updates.parameters));
        }

        setParts.push('updated_at = CURRENT_TIMESTAMP');
        values.push(id);

        const result = await window.electronAPI.dbQuery(
          `UPDATE ${this.TABLE_NAME} SET ${setParts.join(', ')} WHERE id = ?`,
          values
        );
        
        return result.success;
      }
      return false;
    } catch (error) {
      console.error('Error updating formula:', error);
      return false;
    }
  }

  static async deleteFormula(id: number): Promise<boolean> {
    try {
      if (window.electronAPI) {
        const result = await window.electronAPI.dbQuery(
          `DELETE FROM ${this.TABLE_NAME} WHERE id = ?`,
          [id]
        );
        return result.success;
      }
      return false;
    } catch (error) {
      console.error('Error deleting formula:', error);
      return false;
    }
  }

  static async evaluateFormula(name: string, parameters: Record<string, number>): Promise<number> {
    try {
      const formula = await this.getFormula(name);
      if (!formula) {
        throw new Error(`Formula '${name}' not found`);
      }

      // Parse parameters from JSON string
      const expectedParams = typeof formula.parameters === 'string' 
        ? JSON.parse(formula.parameters) 
        : formula.parameters;

      // Validate all required parameters are provided
      for (const param of expectedParams) {
        if (!(param in parameters)) {
          throw new Error(`Missing parameter: ${param}`);
        }
      }

      // Create a safe evaluation function
      const expression = formula.expression;
      const paramNames = Object.keys(parameters);
      const paramValues = Object.values(parameters);

      // Simple validation to prevent dangerous code
      if (expression.includes('eval') || expression.includes('Function') || expression.includes('require')) {
        throw new Error('Invalid expression: contains prohibited functions');
      }

      try {
        // Create function with parameter names and return the expression result
        const func = new Function(...paramNames, `return ${expression}`);
        const result = func(...paramValues);
        
        if (typeof result !== 'number' || isNaN(result)) {
          throw new Error('Formula evaluation did not return a valid number');
        }
        
        return result;
      } catch (evalError) {
        throw new Error(`Expression evaluation failed: ${evalError.message}`);
      }
    } catch (error) {
      console.error('Error evaluating formula:', error);
      throw error;
    }
  }
}

export const calculationFormulaService = new CalculationFormulaService();