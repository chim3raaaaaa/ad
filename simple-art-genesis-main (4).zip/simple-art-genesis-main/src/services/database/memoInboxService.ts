// Memo Inbox Service with SQLite integration
declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface MemoInboxEntry {
  id: string;
  memo_id: string;
  status: 'pending' | 'acknowledged' | 'flagged' | 'revision_required';
  submitted_by: string;
  submitted_at: string;
  acknowledged_by?: string;
  acknowledged_at?: string;
  current_revision: number;
  priority_level: 'low' | 'normal' | 'high' | 'critical';
  category: string;
  memo_reference: string;
}

export interface AcknowledgmentChecklist {
  id: string;
  name: string;
  category: string;
  description: string;
  checklist_items: ChecklistItem[];
  required_fields: string[];
  created_by: string;
  is_active: boolean;
  created_at: string;
}

export interface ChecklistItem {
  id: string;
  name: string;
  description: string;
  required: boolean;
  category: string;
}

export interface MemoAcknowledgment {
  id: string;
  memo_id: string;
  acknowledger_id: string;
  checklist_id: string;
  checklist_responses: Record<string, boolean | string>;
  acknowledgment_notes: string;
  acknowledged_at: string;
}

export interface MemoDiscrepancy {
  id: string;
  memo_id: string;
  flagged_by: string;
  flagged_at: string;
  discrepancy_category: string;
  description: string;
  priority: 'minor' | 'major' | 'critical';
  resolution_status: 'open' | 'in_progress' | 'resolved';
  resolved_by?: string;
  resolved_at?: string;
}

class MemoInboxService {
  private isElectron = false;
  private isInitialized = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        await this.createRequiredTables();
        console.log('Memo Inbox Service initialized with SQLite');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Memo Inbox Service:', error);
      throw error;
    }
  }

  private async createRequiredTables(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Memo Inbox table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS memo_inbox (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          status TEXT DEFAULT 'pending',
          submitted_by TEXT NOT NULL,
          submitted_at TEXT NOT NULL,
          acknowledged_by TEXT,
          acknowledged_at TEXT,
          current_revision INTEGER DEFAULT 1,
          priority_level TEXT DEFAULT 'normal',
          category TEXT NOT NULL,
          memo_reference TEXT NOT NULL,
          FOREIGN KEY (memo_id) REFERENCES enhanced_memos(id)
        )
      `);

      // Acknowledgment Checklists table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS acknowledgment_checklists (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          category TEXT NOT NULL,
          description TEXT,
          checklist_items TEXT DEFAULT '[]',
          required_fields TEXT DEFAULT '[]',
          created_by TEXT NOT NULL,
          is_active BOOLEAN DEFAULT 1,
          created_at TEXT NOT NULL
        )
      `);

      // Memo Acknowledgments table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS memo_acknowledgments (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          acknowledger_id TEXT NOT NULL,
          checklist_id TEXT NOT NULL,
          checklist_responses TEXT DEFAULT '{}',
          acknowledgment_notes TEXT,
          acknowledged_at TEXT NOT NULL,
          FOREIGN KEY (memo_id) REFERENCES enhanced_memos(id),
          FOREIGN KEY (checklist_id) REFERENCES acknowledgment_checklists(id)
        )
      `);

      // Memo Discrepancies table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS memo_discrepancies (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          flagged_by TEXT NOT NULL,
          flagged_at TEXT NOT NULL,
          discrepancy_category TEXT NOT NULL,
          description TEXT NOT NULL,
          priority TEXT DEFAULT 'minor',
          resolution_status TEXT DEFAULT 'open',
          resolved_by TEXT,
          resolved_at TEXT,
          FOREIGN KEY (memo_id) REFERENCES enhanced_memos(id)
        )
      `);

      console.log('Memo Inbox tables created successfully');
    } catch (error) {
      console.error('Error creating memo inbox tables:', error);
      throw error;
    }
  }

  // Memo Inbox Operations
  async submitMemoToInbox(memoId: string, submittedBy: string, category: string, memoReference: string): Promise<string> {
    await this.initialize();

    const inboxEntry: MemoInboxEntry = {
      id: crypto.randomUUID(),
      memo_id: memoId,
      status: 'pending',
      submitted_by: submittedBy,
      submitted_at: new Date().toISOString(),
      current_revision: 1,
      priority_level: 'normal',
      category,
      memo_reference: memoReference
    };

    try {
      if (this.isElectron) {
        await window.electronAPI.dbQuery(`
          INSERT INTO memo_inbox (id, memo_id, status, submitted_by, submitted_at, current_revision, priority_level, category, memo_reference)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [inboxEntry.id, inboxEntry.memo_id, inboxEntry.status, inboxEntry.submitted_by, inboxEntry.submitted_at, 
            inboxEntry.current_revision, inboxEntry.priority_level, inboxEntry.category, inboxEntry.memo_reference]);
      } else {
        // Store in localStorage as fallback
        const inboxEntries = JSON.parse(localStorage.getItem('memo-inbox') || '[]');
        inboxEntries.push(inboxEntry);
        localStorage.setItem('memo-inbox', JSON.stringify(inboxEntries));
      }

      return inboxEntry.id;
    } catch (error) {
      console.error('Error submitting memo to inbox:', error);
      throw error;
    }
  }

  async getInboxEntries(status?: string): Promise<MemoInboxEntry[]> {
    await this.initialize();

    try {
      if (this.isElectron) {
        const query = status 
          ? `SELECT * FROM memo_inbox WHERE status = ? ORDER BY submitted_at DESC`
          : `SELECT * FROM memo_inbox ORDER BY submitted_at DESC`;
        const params = status ? [status] : [];
        
        const result = await window.electronAPI.dbQuery(query, params);
        return result || [];
      } else {
        // Fallback to localStorage
        const inboxEntries = JSON.parse(localStorage.getItem('memo-inbox') || '[]');
        return status ? inboxEntries.filter((entry: MemoInboxEntry) => entry.status === status) : inboxEntries;
      }
    } catch (error) {
      console.error('Error getting inbox entries:', error);
      throw error;
    }
  }

  async acknowledgeMemo(inboxId: string, acknowledgerId: string, checklistId: string, responses: Record<string, boolean | string>, notes: string): Promise<boolean> {
    await this.initialize();

    try {
      const acknowledgmentId = crypto.randomUUID();
      const acknowledgedAt = new Date().toISOString();

      if (this.isElectron) {
        // Update inbox entry
        await window.electronAPI.dbQuery(`
          UPDATE memo_inbox 
          SET status = 'acknowledged', acknowledged_by = ?, acknowledged_at = ?
          WHERE id = ?
        `, [acknowledgerId, acknowledgedAt, inboxId]);

        // Create acknowledgment record
        await window.electronAPI.dbQuery(`
          INSERT INTO memo_acknowledgments (id, memo_id, acknowledger_id, checklist_id, checklist_responses, acknowledgment_notes, acknowledged_at)
          VALUES (?, (SELECT memo_id FROM memo_inbox WHERE id = ?), ?, ?, ?, ?, ?)
        `, [acknowledgmentId, inboxId, acknowledgerId, checklistId, JSON.stringify(responses), notes, acknowledgedAt]);
      } else {
        // Fallback to localStorage
        const inboxEntries = JSON.parse(localStorage.getItem('memo-inbox') || '[]');
        const acknowledgments = JSON.parse(localStorage.getItem('memo-acknowledgments') || '[]');
        
        const entryIndex = inboxEntries.findIndex((entry: MemoInboxEntry) => entry.id === inboxId);
        if (entryIndex !== -1) {
          inboxEntries[entryIndex].status = 'acknowledged';
          inboxEntries[entryIndex].acknowledged_by = acknowledgerId;
          inboxEntries[entryIndex].acknowledged_at = acknowledgedAt;
          
          acknowledgments.push({
            id: acknowledgmentId,
            memo_id: inboxEntries[entryIndex].memo_id,
            acknowledger_id: acknowledgerId,
            checklist_id: checklistId,
            checklist_responses: responses,
            acknowledgment_notes: notes,
            acknowledged_at: acknowledgedAt
          });
          
          localStorage.setItem('memo-inbox', JSON.stringify(inboxEntries));
          localStorage.setItem('memo-acknowledgments', JSON.stringify(acknowledgments));
        }
      }

      return true;
    } catch (error) {
      console.error('Error acknowledging memo:', error);
      throw error;
    }
  }

  async flagMemoDiscrepancy(inboxId: string, flaggedBy: string, category: string, description: string, priority: 'minor' | 'major' | 'critical'): Promise<boolean> {
    await this.initialize();

    try {
      const discrepancyId = crypto.randomUUID();
      const flaggedAt = new Date().toISOString();

      if (this.isElectron) {
        // Update inbox entry status
        await window.electronAPI.dbQuery(`
          UPDATE memo_inbox 
          SET status = 'flagged'
          WHERE id = ?
        `, [inboxId]);

        // Create discrepancy record
        await window.electronAPI.dbQuery(`
          INSERT INTO memo_discrepancies (id, memo_id, flagged_by, flagged_at, discrepancy_category, description, priority)
          VALUES (?, (SELECT memo_id FROM memo_inbox WHERE id = ?), ?, ?, ?, ?, ?)
        `, [discrepancyId, inboxId, flaggedBy, flaggedAt, category, description, priority]);
      } else {
        // Fallback to localStorage
        const inboxEntries = JSON.parse(localStorage.getItem('memo-inbox') || '[]');
        const discrepancies = JSON.parse(localStorage.getItem('memo-discrepancies') || '[]');
        
        const entryIndex = inboxEntries.findIndex((entry: MemoInboxEntry) => entry.id === inboxId);
        if (entryIndex !== -1) {
          inboxEntries[entryIndex].status = 'flagged';
          
          discrepancies.push({
            id: discrepancyId,
            memo_id: inboxEntries[entryIndex].memo_id,
            flagged_by: flaggedBy,
            flagged_at: flaggedAt,
            discrepancy_category: category,
            description,
            priority,
            resolution_status: 'open'
          });
          
          localStorage.setItem('memo-inbox', JSON.stringify(inboxEntries));
          localStorage.setItem('memo-discrepancies', JSON.stringify(discrepancies));
        }
      }

      return true;
    } catch (error) {
      console.error('Error flagging memo discrepancy:', error);
      throw error;
    }
  }

  // Checklist Management
  async createChecklist(name: string, category: string, description: string, items: ChecklistItem[], requiredFields: string[], createdBy: string): Promise<string> {
    await this.initialize();

    const checklistId = crypto.randomUUID();
    const createdAt = new Date().toISOString();

    try {
      if (this.isElectron) {
        await window.electronAPI.dbQuery(`
          INSERT INTO acknowledgment_checklists (id, name, category, description, checklist_items, required_fields, created_by, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [checklistId, name, category, description, JSON.stringify(items), JSON.stringify(requiredFields), createdBy, createdAt]);
      } else {
        // Fallback to localStorage
        const checklists = JSON.parse(localStorage.getItem('acknowledgment-checklists') || '[]');
        checklists.push({
          id: checklistId,
          name,
          category,
          description,
          checklist_items: items,
          required_fields: requiredFields,
          created_by: createdBy,
          is_active: true,
          created_at: createdAt
        });
        localStorage.setItem('acknowledgment-checklists', JSON.stringify(checklists));
      }

      return checklistId;
    } catch (error) {
      console.error('Error creating checklist:', error);
      throw error;
    }
  }

  async getChecklists(category?: string): Promise<AcknowledgmentChecklist[]> {
    await this.initialize();

    try {
      if (this.isElectron) {
        const query = category 
          ? `SELECT * FROM acknowledgment_checklists WHERE category = ? AND is_active = 1 ORDER BY name`
          : `SELECT * FROM acknowledgment_checklists WHERE is_active = 1 ORDER BY name`;
        const params = category ? [category] : [];
        
        const result = await window.electronAPI.dbQuery(query, params);
        return (result || []).map((row: any) => ({
          ...row,
          checklist_items: JSON.parse(row.checklist_items || '[]'),
          required_fields: JSON.parse(row.required_fields || '[]')
        }));
      } else {
        // Fallback to localStorage
        const checklists = JSON.parse(localStorage.getItem('acknowledgment-checklists') || '[]');
        return category 
          ? checklists.filter((list: AcknowledgmentChecklist) => list.category === category && list.is_active)
          : checklists.filter((list: AcknowledgmentChecklist) => list.is_active);
      }
    } catch (error) {
      console.error('Error getting checklists:', error);
      throw error;
    }
  }

  async getDiscrepancies(memoId?: string): Promise<MemoDiscrepancy[]> {
    await this.initialize();

    try {
      if (this.isElectron) {
        const query = memoId 
          ? `SELECT * FROM memo_discrepancies WHERE memo_id = ? ORDER BY flagged_at DESC`
          : `SELECT * FROM memo_discrepancies ORDER BY flagged_at DESC`;
        const params = memoId ? [memoId] : [];
        
        const result = await window.electronAPI.dbQuery(query, params);
        return result || [];
      } else {
        // Fallback to localStorage
        const discrepancies = JSON.parse(localStorage.getItem('memo-discrepancies') || '[]');
        return memoId 
          ? discrepancies.filter((d: MemoDiscrepancy) => d.memo_id === memoId)
          : discrepancies;
      }
    } catch (error) {
      console.error('Error getting discrepancies:', error);
      throw error;
    }
  }
}

export const memoInboxService = new MemoInboxService();