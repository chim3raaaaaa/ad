import { toast } from '@/hooks/use-toast';

// Cube Test Database Interfaces
export interface CubeTestEntry {
  id: string;
  memo_reference: string;
  
  // Dates
  production_date: string;
  test_date: string;
  age_days: number;
  
  // Reference Info
  plant_id: string;
  officer_id: string;
  concrete_grade: string;
  mix_design_ref: string;
  machine_id?: string;
  
  // Production Info
  batch_number: string;
  cast_time: string;
  curing_method: string;
  
  // Test Details
  cube_dimensions: {
    length: number | null;
    width: number | null;
    height: number | null;
  };
  
  // Test Results
  compressive_strength_7_day: number | null;
  compressive_strength_28_day: number | null;
  compressive_strength_actual: number | null;
  failure_mode: string | null;
  density: number | null;
  
  // Quality Results
  observations: string | null;
  strength_conformity: 'conforming' | 'non_conforming' | 'pending';
  
  // Test Status
  test_performed: boolean;
  
  // PDF Attachment
  calculation_sheet_path: string | null;
  
  // Metadata
  created_at: string;
  updated_at: string;
  created_by?: string;
}

export interface PlantCubeDatabase {
  plant_id: string;
  plant_name: string;
  category: string;
  product_type: string;
  table_name: string;
  entry_count: number;
  last_updated: string;
}

class CubeTestService {
  // Create plant-specific database
  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const tableName = `cube_tests_${plantId.toLowerCase().replace(/\s+/g, '_')}_${productType.toLowerCase().replace(/\s+/g, '_')}`;
    
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.createElectronTable(tableName);
      } else {
        await this.createBrowserTable(tableName);
      }
      
      toast({
        title: "Database Created",
        description: `Created cube test database for ${plantName} - ${productType}`
      });
      
      return tableName;
    } catch (error) {
      console.error('Error creating plant database:', error);
      toast({
        title: "Database Creation Failed",
        description: "Failed to create plant database",
        variant: "destructive"
      });
      throw error;
    }
  }

  // Create table in Electron environment
  private async createElectronTable(tableName: string): Promise<void> {
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id TEXT PRIMARY KEY,
        memo_reference TEXT NOT NULL,
        production_date TEXT NOT NULL,
        test_date TEXT NOT NULL,
        age_days INTEGER NOT NULL,
        plant_id TEXT NOT NULL,
        officer_id TEXT NOT NULL,
        concrete_grade TEXT NOT NULL,
        mix_design_ref TEXT NOT NULL,
        machine_id TEXT,
        batch_number TEXT NOT NULL,
        cast_time TEXT NOT NULL,
        curing_method TEXT NOT NULL,
        cube_dimensions_length REAL,
        cube_dimensions_width REAL,
        cube_dimensions_height REAL,
        compressive_strength_7_day REAL,
        compressive_strength_28_day REAL,
        compressive_strength_actual REAL,
        failure_mode TEXT,
        density REAL,
        observations TEXT,
        strength_conformity TEXT DEFAULT 'pending',
        test_performed BOOLEAN DEFAULT FALSE,
        calculation_sheet_path TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT
      )
    `;
    
    await (window as any).electronAPI.dbRun(createTableSQL);
  }

  // Create table in browser environment
  private async createBrowserTable(tableName: string): Promise<void> {
    const existingData = localStorage.getItem(tableName);
    if (!existingData) {
      localStorage.setItem(tableName, JSON.stringify([]));
    }
  }

  // Get all plant databases
  async getPlantDatabases(): Promise<PlantCubeDatabase[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        return await this.getElectronPlantDatabases();
      } else {
        return await this.getBrowserPlantDatabases();
      }
    } catch (error) {
      console.error('Error getting plant databases:', error);
      return [];
    }
  }

  // Get plant databases from Electron
  private async getElectronPlantDatabases(): Promise<PlantCubeDatabase[]> {
    const tables = await (window as any).electronAPI.dbQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'cube_tests_%'"
    );
    
    const databases: PlantCubeDatabase[] = [];
    
    for (const table of tables) {
      const tableName = table.name;
      const parts = tableName.replace('cube_tests_', '').split('_');
      const plantId = parts[0];
      const productType = parts.slice(1).join('_');
      
      const countResult = await (window as any).electronAPI.dbQuery(
        `SELECT COUNT(*) as count FROM ${tableName}`
      );
      const count = countResult[0]?.count || 0;
      
      const lastUpdatedResult = await (window as any).electronAPI.dbQuery(
        `SELECT MAX(updated_at) as last_updated FROM ${tableName}`
      );
      const lastUpdated = lastUpdatedResult[0]?.last_updated || new Date().toISOString();
      
      databases.push({
        plant_id: plantId,
        plant_name: plantId.replace(/_/g, ' ').toUpperCase(),
        category: 'cubes',
        product_type: productType.replace(/_/g, ' '),
        table_name: tableName,
        entry_count: count,
        last_updated: lastUpdated
      });
    }
    
    return databases;
  }

  // Get plant databases from browser
  private async getBrowserPlantDatabases(): Promise<PlantCubeDatabase[]> {
    const databases: PlantCubeDatabase[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('cube_tests_')) {
        const data = JSON.parse(localStorage.getItem(key) || '[]');
        const parts = key.replace('cube_tests_', '').split('_');
        const plantId = parts[0];
        const productType = parts.slice(1).join('_');
        
        databases.push({
          plant_id: plantId,
          plant_name: plantId.replace(/_/g, ' ').toUpperCase(),
          category: 'cubes',
          product_type: productType.replace(/_/g, ' '),
          table_name: key,
          entry_count: data.length,
          last_updated: data.length > 0 ? data[data.length - 1]?.updated_at || new Date().toISOString() : new Date().toISOString()
        });
      }
    }
    
    return databases;
  }

  // Get test entries for a specific table
  async getTestEntries(tableName: string, filters?: Record<string, any>): Promise<CubeTestEntry[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        return await this.getElectronTestEntries(tableName, filters);
      } else {
        return await this.getBrowserTestEntries(tableName, filters);
      }
    } catch (error) {
      console.error('Error getting test entries:', error);
      return [];
    }
  }

  // Get test entries from Electron
  private async getElectronTestEntries(tableName: string, filters?: Record<string, any>): Promise<CubeTestEntry[]> {
    let sql = `SELECT * FROM ${tableName}`;
    const params: any[] = [];
    
    if (filters && Object.keys(filters).length > 0) {
      const conditions: string[] = [];
      
      if (filters.startDate) {
        conditions.push('test_date >= ?');
        params.push(filters.startDate);
      }
      
      if (filters.endDate) {
        conditions.push('test_date <= ?');
        params.push(filters.endDate);
      }
      
      if (filters.officer_id) {
        conditions.push('officer_id = ?');
        params.push(filters.officer_id);
      }
      
      if (conditions.length > 0) {
        sql += ' WHERE ' + conditions.join(' AND ');
      }
    }
    
    sql += ' ORDER BY test_date DESC';
    
    const rows = await (window as any).electronAPI.dbQuery(sql, params);
    
    return rows.map((row: any) => ({
      ...row,
      cube_dimensions: {
        length: row.cube_dimensions_length,
        width: row.cube_dimensions_width,
        height: row.cube_dimensions_height
      }
    }));
  }

  // Get test entries from browser
  private async getBrowserTestEntries(tableName: string, filters?: Record<string, any>): Promise<CubeTestEntry[]> {
    const data = JSON.parse(localStorage.getItem(tableName) || '[]');
    
    if (!filters || Object.keys(filters).length === 0) {
      return data;
    }
    
    return data.filter((entry: CubeTestEntry) => {
      if (filters.startDate && entry.test_date < filters.startDate) return false;
      if (filters.endDate && entry.test_date > filters.endDate) return false;
      if (filters.officer_id && entry.officer_id !== filters.officer_id) return false;
      
      return true;
    });
  }

  // Create new test entry
  async createTestEntry(
    tableName: string, 
    entryData: Omit<CubeTestEntry, 'id' | 'created_at' | 'updated_at'>
  ): Promise<CubeTestEntry> {
    const id = `cube_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    
    const fullEntry: CubeTestEntry = {
      ...entryData,
      id,
      created_at: now,
      updated_at: now
    };
    
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.createElectronTestEntry(tableName, fullEntry);
      } else {
        await this.createBrowserTestEntry(tableName, fullEntry);
      }
      
      toast({
        title: "Test Entry Created",
        description: `Cube test entry ${id} created successfully`
      });
      
      return fullEntry;
    } catch (error) {
      console.error('Error creating test entry:', error);
      toast({
        title: "Creation Failed",
        description: "Failed to create test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  // Create test entry in Electron
  private async createElectronTestEntry(tableName: string, entry: CubeTestEntry): Promise<void> {
    const sql = `
      INSERT INTO ${tableName} (
        id, memo_reference, production_date, test_date, age_days,
        plant_id, officer_id, concrete_grade, mix_design_ref, machine_id,
        batch_number, cast_time, curing_method,
        cube_dimensions_length, cube_dimensions_width, cube_dimensions_height,
        compressive_strength_7_day, compressive_strength_28_day, compressive_strength_actual,
        failure_mode, density, observations, strength_conformity, test_performed,
        calculation_sheet_path, created_at, updated_at, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const params = [
      entry.id, entry.memo_reference, entry.production_date, entry.test_date, entry.age_days,
      entry.plant_id, entry.officer_id, entry.concrete_grade, entry.mix_design_ref, entry.machine_id,
      entry.batch_number, entry.cast_time, entry.curing_method,
      entry.cube_dimensions.length, entry.cube_dimensions.width, entry.cube_dimensions.height,
      entry.compressive_strength_7_day, entry.compressive_strength_28_day, entry.compressive_strength_actual,
      entry.failure_mode, entry.density, entry.observations, entry.strength_conformity, entry.test_performed,
      entry.calculation_sheet_path, entry.created_at, entry.updated_at, entry.created_by
    ];
    
    await (window as any).electronAPI.dbRun(sql, params);
  }

  // Create test entry in browser
  private async createBrowserTestEntry(tableName: string, entry: CubeTestEntry): Promise<void> {
    const existingData = JSON.parse(localStorage.getItem(tableName) || '[]');
    existingData.push(entry);
    localStorage.setItem(tableName, JSON.stringify(existingData));
  }

  // Update test entry
  async updateTestEntry(tableName: string, entryId: string, updates: Partial<CubeTestEntry>): Promise<void> {
    try {
      const updatedData = {
        ...updates,
        updated_at: new Date().toISOString()
      };
      
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.updateElectronTestEntry(tableName, entryId, updatedData);
      } else {
        await this.updateBrowserTestEntry(tableName, entryId, updatedData);
      }
      
      toast({
        title: "Test Entry Updated",
        description: `Cube test entry ${entryId} updated successfully`
      });
    } catch (error) {
      console.error('Error updating test entry:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  // Update test entry in Electron
  private async updateElectronTestEntry(tableName: string, entryId: string, updates: Partial<CubeTestEntry>): Promise<void> {
    let setClause = Object.keys(updates)
      .filter(key => key !== 'cube_dimensions')
      .map(key => `${key} = ?`)
      .join(', ');
    
    const values = Object.entries(updates)
      .filter(([key]) => key !== 'cube_dimensions')
      .map(([, value]) => value);
    
    if (updates.cube_dimensions) {
      const dimensionUpdates = [
        'cube_dimensions_length = ?',
        'cube_dimensions_width = ?', 
        'cube_dimensions_height = ?'
      ];
      setClause += ', ' + dimensionUpdates.join(', ');
      values.push(
        updates.cube_dimensions.length,
        updates.cube_dimensions.width,
        updates.cube_dimensions.height
      );
    }
    
    const sql = `UPDATE ${tableName} SET ${setClause} WHERE id = ?`;
    await (window as any).electronAPI.dbRun(sql, [...values, entryId]);
  }

  // Update test entry in browser
  private async updateBrowserTestEntry(tableName: string, entryId: string, updates: Partial<CubeTestEntry>): Promise<void> {
    const data = JSON.parse(localStorage.getItem(tableName) || '[]');
    const index = data.findIndex((entry: CubeTestEntry) => entry.id === entryId);
    
    if (index !== -1) {
      data[index] = { ...data[index], ...updates };
      localStorage.setItem(tableName, JSON.stringify(data));
    }
  }

  // Delete test entry
  async deleteTestEntry(tableName: string, entryId: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await (window as any).electronAPI.dbRun(`DELETE FROM ${tableName} WHERE id = ?`, [entryId]);
      } else {
        const data = JSON.parse(localStorage.getItem(tableName) || '[]');
        const filteredData = data.filter((entry: CubeTestEntry) => entry.id !== entryId);
        localStorage.setItem(tableName, JSON.stringify(filteredData));
      }
      
      toast({
        title: "Test Entry Deleted",
        description: `Cube test entry ${entryId} deleted successfully`
      });
    } catch (error) {
      console.error('Error deleting test entry:', error);
      toast({
        title: "Deletion Failed",
        description: "Failed to delete test entry",
        variant: "destructive"
      });
      throw error;
    }
  }

  // Validate test data
  async validateTestData(
    testData: Partial<CubeTestEntry>,
    referenceData: any
  ): Promise<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    // Required field validation
    if (!testData.memo_reference) errors.push('Memo reference is required');
    if (!testData.production_date) errors.push('Production date is required');
    if (!testData.test_date) errors.push('Test date is required');
    if (!testData.plant_id) errors.push('Plant is required');
    if (!testData.officer_id) errors.push('Officer is required');
    if (!testData.concrete_grade) errors.push('Concrete grade is required');
    if (!testData.mix_design_ref) errors.push('Mix design reference is required');
    if (!testData.batch_number) errors.push('Batch number is required');
    if (!testData.cast_time) errors.push('Cast time is required');
    if (!testData.curing_method) errors.push('Curing method is required');
    
    // Reference data validation
    if (referenceData) {
      if (testData.plant_id && !referenceData.plants?.some((p: any) => p.id === testData.plant_id)) {
        errors.push('Invalid plant selected');
      }
      
      if (testData.officer_id && !referenceData.officers?.some((o: any) => o.id === testData.officer_id)) {
        errors.push('Invalid officer selected');
      }
    }
    
    // Business logic validation
    if (testData.production_date && testData.test_date) {
      if (new Date(testData.test_date) < new Date(testData.production_date)) {
        errors.push('Test date cannot be before production date');
      }
    }
    
    if (testData.age_days && testData.age_days < 0) {
      errors.push('Age in days cannot be negative');
    }
    
    if (testData.compressive_strength_7_day && testData.compressive_strength_7_day < 0) {
      errors.push('7-day compressive strength cannot be negative');
    }
    
    if (testData.compressive_strength_28_day && testData.compressive_strength_28_day < 0) {
      errors.push('28-day compressive strength cannot be negative');
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

export const cubeTestService = new CubeTestService();