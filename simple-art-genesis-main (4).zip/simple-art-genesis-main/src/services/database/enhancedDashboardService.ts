import { dashboardSchemaService } from './dashboardSchemaService';

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface DashboardLayout {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  is_default: boolean;
  is_shared: boolean;
  layout_config: any;
  theme_config: any;
  permissions: any;
  created_at: string;
  updated_at: string;
  created_by: string;
  last_modified_by?: string;
  widgets: DashboardWidget[];
}

export interface DashboardWidget {
  id: string;
  layout_id: string;
  widget_type: string;
  title: string;
  description?: string;
  position_x: number;
  position_y: number;
  width: number;
  height: number;
  min_width: number;
  min_height: number;
  config: any;
  data_source?: string;
  refresh_interval: number;
  is_enabled: boolean;
  created_at: string;
  updated_at: string;
  data?: any;
}

export interface TestScheduleEvent {
  id: string;
  memo_id: string;
  test_type: string;
  production_date: string;
  scheduled_date: string;
  due_date: string;
  priority: 'low' | 'normal' | 'high' | 'critical';
  status: 'scheduled' | 'in_progress' | 'completed' | 'overdue' | 'cancelled';
  assigned_to?: string;
  plant_location?: string;
  product_type?: string;
  batch_number?: string;
  notes?: string;
  completed_at?: string;
  completed_by?: string;
}

class EnhancedDashboardService {
  private isElectron = typeof window !== 'undefined' && window.electronAPI;

  async initialize(): Promise<void> {
    if (!this.isElectron) return;
    
    try {
      await dashboardSchemaService.initializeDashboardTables();
      console.log('Enhanced Dashboard Service initialized');
    } catch (error) {
      console.error('Failed to initialize Enhanced Dashboard Service:', error);
      throw error;
    }
  }

  // Dashboard Layout Management
  async getUserLayouts(userId: string): Promise<DashboardLayout[]> {
    if (!this.isElectron) return [];

    try {
      const layoutsResult = await window.electronAPI.dbQuery(`
        SELECT * FROM dashboard_layouts 
        WHERE user_id = ? OR is_shared = TRUE
        ORDER BY is_default DESC, created_at DESC
      `, [userId]);

      if (!layoutsResult.success) return [];

      const layouts: DashboardLayout[] = [];
      
      for (const layoutRow of layoutsResult.data) {
        const widgetsResult = await window.electronAPI.dbQuery(`
          SELECT * FROM dashboard_widgets 
          WHERE layout_id = ? AND is_enabled = TRUE
          ORDER BY position_y, position_x
        `, [layoutRow.id]);

        const widgets = widgetsResult.success ? widgetsResult.data.map(this.mapRowToWidget) : [];
        
        layouts.push({
          ...layoutRow,
          layout_config: JSON.parse(layoutRow.layout_config || '{}'),
          theme_config: JSON.parse(layoutRow.theme_config || '{}'),
          permissions: JSON.parse(layoutRow.permissions || '{}'),
          widgets
        });
      }

      return layouts;
    } catch (error) {
      console.error('Error fetching user layouts:', error);
      return [];
    }
  }

  async createLayout(layout: Partial<DashboardLayout>): Promise<string> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    const layoutId = `layout_${layout.user_id}_${Date.now()}`;
    
    try {
      await window.electronAPI.dbQuery(`
        INSERT INTO dashboard_layouts (
          id, user_id, name, description, is_default, is_shared,
          layout_config, theme_config, permissions, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        layoutId,
        layout.user_id,
        layout.name,
        layout.description || '',
        layout.is_default || false,
        layout.is_shared || false,
        JSON.stringify(layout.layout_config || {}),
        JSON.stringify(layout.theme_config || {}),
        JSON.stringify(layout.permissions || {}),
        layout.user_id
      ]);

      return layoutId;
    } catch (error) {
      console.error('Error creating layout:', error);
      throw error;
    }
  }

  async updateLayout(layoutId: string, updates: Partial<DashboardLayout>): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      const setParts = [];
      const values = [];

      if (updates.name) {
        setParts.push('name = ?');
        values.push(updates.name);
      }
      if (updates.description !== undefined) {
        setParts.push('description = ?');
        values.push(updates.description);
      }
      if (updates.layout_config) {
        setParts.push('layout_config = ?');
        values.push(JSON.stringify(updates.layout_config));
      }
      if (updates.theme_config) {
        setParts.push('theme_config = ?');
        values.push(JSON.stringify(updates.theme_config));
      }
      if (updates.last_modified_by) {
        setParts.push('last_modified_by = ?');
        values.push(updates.last_modified_by);
      }

      setParts.push('updated_at = CURRENT_TIMESTAMP');
      values.push(layoutId);

      await window.electronAPI.dbQuery(`
        UPDATE dashboard_layouts 
        SET ${setParts.join(', ')}
        WHERE id = ?
      `, values);
    } catch (error) {
      console.error('Error updating layout:', error);
      throw error;
    }
  }

  async deleteLayout(layoutId: string): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      await window.electronAPI.dbQuery('DELETE FROM dashboard_layouts WHERE id = ?', [layoutId]);
    } catch (error) {
      console.error('Error deleting layout:', error);
      throw error;
    }
  }

  // Widget Management
  async addWidget(widget: Omit<DashboardWidget, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    const widgetId = `widget_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      await window.electronAPI.dbQuery(`
        INSERT INTO dashboard_widgets (
          id, layout_id, widget_type, title, description, position_x, position_y,
          width, height, min_width, min_height, config, data_source, 
          refresh_interval, is_enabled
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        widgetId,
        widget.layout_id,
        widget.widget_type,
        widget.title,
        widget.description || '',
        widget.position_x,
        widget.position_y,
        widget.width,
        widget.height,
        widget.min_width || 2,
        widget.min_height || 2,
        JSON.stringify(widget.config || {}),
        widget.data_source || '',
        widget.refresh_interval || 300000,
        widget.is_enabled !== false
      ]);

      return widgetId;
    } catch (error) {
      console.error('Error adding widget:', error);
      throw error;
    }
  }

  async updateWidget(widgetId: string, updates: Partial<DashboardWidget>): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      const setParts = [];
      const values = [];

      Object.entries(updates).forEach(([key, value]) => {
        if (key === 'id' || key === 'created_at') return;
        
        if (key === 'config') {
          setParts.push('config = ?');
          values.push(JSON.stringify(value));
        } else {
          setParts.push(`${key} = ?`);
          values.push(value);
        }
      });

      if (setParts.length === 0) return;

      setParts.push('updated_at = CURRENT_TIMESTAMP');
      values.push(widgetId);

      await window.electronAPI.dbQuery(`
        UPDATE dashboard_widgets 
        SET ${setParts.join(', ')}
        WHERE id = ?
      `, values);
    } catch (error) {
      console.error('Error updating widget:', error);
      throw error;
    }
  }

  async removeWidget(widgetId: string): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      await window.electronAPI.dbQuery('DELETE FROM dashboard_widgets WHERE id = ?', [widgetId]);
    } catch (error) {
      console.error('Error removing widget:', error);
      throw error;
    }
  }

  // Test Calendar Management
  async getTestEvents(filters?: {
    startDate?: string;
    endDate?: string;
    status?: string[];
    priority?: string[];
    plantLocation?: string;
  }): Promise<TestScheduleEvent[]> {
    if (!this.isElectron) return [];

    try {
      let query = 'SELECT * FROM test_schedule WHERE 1=1';
      const params = [];

      if (filters?.startDate) {
        query += ' AND scheduled_date >= ?';
        params.push(filters.startDate);
      }
      if (filters?.endDate) {
        query += ' AND scheduled_date <= ?';
        params.push(filters.endDate);
      }
      if (filters?.status && filters.status.length > 0) {
        query += ` AND status IN (${filters.status.map(() => '?').join(',')})`;
        params.push(...filters.status);
      }
      if (filters?.priority && filters.priority.length > 0) {
        query += ` AND priority IN (${filters.priority.map(() => '?').join(',')})`;
        params.push(...filters.priority);
      }
      if (filters?.plantLocation) {
        query += ' AND plant_location = ?';
        params.push(filters.plantLocation);
      }

      query += ' ORDER BY due_date ASC, priority DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Error fetching test events:', error);
      return [];
    }
  }

  async createTestEvent(event: Omit<TestScheduleEvent, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    const eventId = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      await window.electronAPI.dbQuery(`
        INSERT INTO test_schedule (
          id, memo_id, test_type, production_date, scheduled_date, due_date,
          priority, status, assigned_to, plant_location, product_type, batch_number, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        eventId,
        event.memo_id,
        event.test_type,
        event.production_date,
        event.scheduled_date,
        event.due_date,
        event.priority || 'normal',
        event.status || 'scheduled',
        event.assigned_to || '',
        event.plant_location || '',
        event.product_type || '',
        event.batch_number || '',
        event.notes || ''
      ]);

      return eventId;
    } catch (error) {
      console.error('Error creating test event:', error);
      throw error;
    }
  }

  async updateTestEvent(eventId: string, updates: Partial<TestScheduleEvent>): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      const setParts = [];
      const values = [];

      Object.entries(updates).forEach(([key, value]) => {
        if (key === 'id' || key === 'created_at') return;
        setParts.push(`${key} = ?`);
        values.push(value);
      });

      if (setParts.length === 0) return;

      setParts.push('updated_at = CURRENT_TIMESTAMP');
      values.push(eventId);

      await window.electronAPI.dbQuery(`
        UPDATE test_schedule 
        SET ${setParts.join(', ')}
        WHERE id = ?
      `, values);
    } catch (error) {
      console.error('Error updating test event:', error);
      throw error;
    }
  }

  async markTestCompleted(eventId: string, completedBy: string, notes?: string): Promise<void> {
    if (!this.isElectron) throw new Error('Requires Electron environment');

    try {
      await window.electronAPI.dbQuery(`
        UPDATE test_schedule 
        SET status = 'completed', completed_at = CURRENT_TIMESTAMP, completed_by = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [completedBy, notes || '', eventId]);

      // Create completion record
      const completionId = `completion_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await window.electronAPI.dbQuery(`
        INSERT INTO test_completions (id, schedule_id, actual_completion_date, completed_by, notes)
        VALUES (?, ?, CURRENT_TIMESTAMP, ?, ?)
      `, [completionId, eventId, completedBy, notes || '']);
    } catch (error) {
      console.error('Error marking test completed:', error);
      throw error;
    }
  }

  // Data Sources for Widgets
  async getWidgetData(dataSource: string, config?: any): Promise<any> {
    if (!this.isElectron) return null;

    try {
      switch (dataSource) {
        case 'memos_count':
          return await this.getMemosCount();
        case 'tests_due_today':
          return await this.getTestsDueToday();
        case 'monthly_trends':
          return await this.getMonthlyTrends();
        case 'test_status_distribution':
          return await this.getTestStatusDistribution();
        case 'overdue_tests':
          return await this.getOverdueTests();
        default:
          return null;
      }
    } catch (error) {
      console.error(`Error fetching data for ${dataSource}:`, error);
      return null;
    }
  }

  private async getMemosCount(): Promise<number> {
    const result = await window.electronAPI.dbQuery(
      'SELECT COUNT(*) as count FROM memos WHERE created_at >= date("now", "start of month")'
    );
    return result.success ? result.data[0]?.count || 0 : 0;
  }

  private async getTestsDueToday(): Promise<number> {
    const today = new Date().toISOString().split('T')[0];
    const result = await window.electronAPI.dbQuery(
      'SELECT COUNT(*) as count FROM test_schedule WHERE due_date = ? AND status != "completed"',
      [today]
    );
    return result.success ? result.data[0]?.count || 0 : 0;
  }

  private async getMonthlyTrends(): Promise<any[]> {
    const result = await window.electronAPI.dbQuery(`
      SELECT 
        strftime('%Y-%m', created_at) as month,
        COUNT(*) as tests,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
      FROM test_schedule 
      WHERE created_at >= date('now', '-6 months')
      GROUP BY strftime('%Y-%m', created_at)
      ORDER BY month DESC
    `);
    return result.success ? result.data : [];
  }

  private async getTestStatusDistribution(): Promise<any[]> {
    const result = await window.electronAPI.dbQuery(`
      SELECT status as name, COUNT(*) as value
      FROM test_schedule 
      GROUP BY status
    `);
    return result.success ? result.data : [];
  }

  private async getOverdueTests(): Promise<TestScheduleEvent[]> {
    const today = new Date().toISOString().split('T')[0];
    const result = await window.electronAPI.dbQuery(
      'SELECT * FROM test_schedule WHERE due_date < ? AND status != "completed" ORDER BY due_date ASC',
      [today]
    );
    return result.success ? result.data : [];
  }

  private mapRowToWidget(row: any): DashboardWidget {
    return {
      ...row,
      config: JSON.parse(row.config || '{}'),
      min_width: row.min_width || 2,
      min_height: row.min_height || 2,
      refresh_interval: row.refresh_interval || 300000,
      is_enabled: Boolean(row.is_enabled)
    };
  }

  // Initialize user with default dashboard
  async initializeUserDashboard(userId: string): Promise<void> {
    try {
      await this.initialize();
      await dashboardSchemaService.seedDefaultData(userId);
    } catch (error) {
      console.error('Error initializing user dashboard:', error);
      throw error;
    }
  }
}

export const enhancedDashboardService = new EnhancedDashboardService();