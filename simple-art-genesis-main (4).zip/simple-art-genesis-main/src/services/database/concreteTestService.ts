import { toast } from '@/hooks/use-toast';

export interface ConcreteTestData {
  id: string;
  memo_reference: string;
  plant_id: string;
  product_type: string;
  test_date: string;
  officer_id: string;
  machine_id?: string;
  
  // Concrete-specific parameters
  mix_design: string;
  cement_content: number;
  water_cement_ratio: number;
  slump: number;
  air_content: number;
  compressive_strength_7day?: number;
  compressive_strength_28day: number;
  cylinder_diameter: number;
  cylinder_height: number;
  
  // Environmental conditions
  ambient_temperature: number;
  humidity: number;
  curing_method: 'water' | 'moist_air' | 'steam' | 'membrane';
  
  // Results
  pass_fail_status: 'pass' | 'fail' | 'pending';
  compliance_notes?: string;
  
  created_at: string;
  updated_at: string;
}

class ConcreteTestService {
  private storageKey = 'concrete_databases';

  async getPlantDatabases(plantId: string): Promise<any[]> {
    try {
      const stored = localStorage.getItem(this.storageKey);
      const allDatabases = stored ? JSON.parse(stored) : [];
      return allDatabases.filter((db: any) => db.plant_id === plantId);
    } catch (error) {
      console.error('Error fetching concrete databases:', error);
      return [];
    }
  }

  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const database = {
      id: `concrete_db_${Date.now()}`,
      name: `Concrete Tests - ${productType}`,
      plant_id: plantId,
      product_type: productType,
      table_name: `concrete_tests_${plantId}_${productType}`.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      created_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(this.storageKey);
    const databases = stored ? JSON.parse(stored) : [];
    databases.push(database);
    localStorage.setItem(this.storageKey, JSON.stringify(databases));
    localStorage.setItem(database.table_name, JSON.stringify([]));

    toast({
      title: "Database Created",
      description: `Concrete test database created for ${productType}`
    });

    return database.id;
  }

  async getTestEntries(tableName: string, filters?: Record<string, any>): Promise<ConcreteTestData[]> {
    try {
      const stored = localStorage.getItem(tableName);
      const entries = stored ? JSON.parse(stored) : [];
      
      if (filters && Object.keys(filters).length > 0) {
        return entries.filter((entry: any) => {
          return Object.entries(filters).every(([key, value]) => entry[key] === value);
        });
      }
      
      return entries;
    } catch (error) {
      return [];
    }
  }

  async createTestEntry(tableName: string, testData: any): Promise<string> {
    const entry = {
      ...testData,
      id: `concrete_test_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    entries.push(entry);
    localStorage.setItem(tableName, JSON.stringify(entries));

    toast({
      title: "Test Entry Created",
      description: "Concrete test entry created successfully"
    });

    return entry.id;
  }

  async updateTestEntry(tableName: string, id: string, updates: any): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    const index = entries.findIndex((entry: any) => entry.id === id);
    
    if (index !== -1) {
      entries[index] = { ...entries[index], ...updates, updated_at: new Date().toISOString() };
      localStorage.setItem(tableName, JSON.stringify(entries));
    }
  }

  async deleteTestEntry(tableName: string, id: string): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    localStorage.setItem(tableName, JSON.stringify(entries.filter((e: any) => e.id !== id)));
  }

  async validateTestData(testData: ConcreteTestData): Promise<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    // Extract grade from product type (e.g., "C25" -> 25)
    const expectedStrength = parseInt(testData.product_type.replace('C', '')) || 25;
    
    if (testData.compressive_strength_28day < expectedStrength) {
      errors.push(`28-day compressive strength must be at least ${expectedStrength} MPa for grade ${testData.product_type}`);
    }
    if (testData.water_cement_ratio > 0.65) {
      errors.push('Water-cement ratio should not exceed 0.65');
    }
    if (testData.slump < 25 || testData.slump > 200) {
      errors.push('Slump must be between 25mm and 200mm');
    }
    if (testData.air_content > 8) {
      errors.push('Air content should not exceed 8%');
    }

    return { isValid: errors.length === 0, errors };
  }
}

export const concreteTestService = new ConcreteTestService();