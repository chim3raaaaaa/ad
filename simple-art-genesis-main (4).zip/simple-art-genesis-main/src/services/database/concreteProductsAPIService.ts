import { directInputService } from './DirectInputService';

export interface TabletDataPayload {
  memo_reference: string;
  production_date: string;
  test_date: string;
  age_days: number;
  operator_name: string;
  machine_no?: string;
  product?: string;
  load_kn: number;
  weight_kg: number;
  strength_mpa: number;
  product_type: string;
  device_id?: string;
  device_name?: string;
  batch_id?: string;
}

export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

export class ConcreteProductsAPIService {
  
  /**
   * Process incoming data from tablet applications
   */
  static async processTabletData(payload: TabletDataPayload): Promise<APIResponse> {
    try {
      // Validate required fields
      const validationError = this.validateTabletPayload(payload);
      if (validationError) {
        return {
          success: false,
          error: validationError,
          timestamp: new Date().toISOString()
        };
      }

      // Enrich data with source tracking
      const enrichedData = {
        product_type: payload.product_type,
        memo_reference: payload.memo_reference,
        production_date: payload.production_date,
        test_date: payload.test_date,
        operator: payload.operator_name,
        machine_no: payload.machine_no || '',
        product: payload.product || '',
        data_source: 'tablet_app',
        status: 'pending' as const,
        created_by: `tablet_${payload.device_id || 'unknown'}`,
        test_data: payload
      };

      // Save to database
      const result = await directInputService.createDirectInputResult(enrichedData);
      
      return {
        success: true,
        data: {
          id: result.id,
          memo_reference: payload.memo_reference,
          status: result.status,
          created_at: result.created_at
        },
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error processing tablet data:', error);
      return {
        success: false,
        error: error.message || 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Process batch data from multiple tablets
   */
  static async processBatchTabletData(payloads: TabletDataPayload[]): Promise<APIResponse[]> {
    const results: APIResponse[] = [];
    
    for (const payload of payloads) {
      const result = await this.processTabletData(payload);
      results.push(result);
    }
    
    return results;
  }

  /**
   * Get sync status for tablet devices
   */
  static async getSyncStatus(deviceId?: string): Promise<APIResponse> {
    try {
      let filters: any = {};
      
      if (deviceId) {
        filters = {
          created_by: `tablet_${deviceId}`
        };
      }

      const results = await directInputService.getDirectInputResults(filters);
      const tabletResults = results.filter(r => r.data_source === 'tablet_app');
      
      const stats = {
        totalRecords: tabletResults.length,
        lastSync: tabletResults.length > 0 ? 
          Math.max(...tabletResults.map(r => new Date(r.created_at).getTime())) : null,
        deviceId,
        syncedToday: tabletResults.filter(r => {
          const today = new Date().toDateString();
          return new Date(r.created_at).toDateString() === today;
        }).length
      };

      return {
        success: true,
        data: stats,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message || 'Failed to get sync status',
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Validate tablet payload data
   */
  private static validateTabletPayload(payload: TabletDataPayload): string | null {
    if (!payload.memo_reference?.trim()) {
      return 'Memo reference is required';
    }
    
    if (!payload.production_date) {
      return 'Production date is required';
    }
    
    if (!payload.test_date) {
      return 'Test date is required';
    }
    
    if (!payload.operator_name?.trim()) {
      return 'Operator name is required';
    }
    
    if (typeof payload.load_kn !== 'number' || payload.load_kn <= 0) {
      return 'Valid load (kN) value is required';
    }
    
    if (typeof payload.weight_kg !== 'number' || payload.weight_kg <= 0) {
      return 'Valid weight (kg) value is required';
    }
    
    if (typeof payload.strength_mpa !== 'number' || payload.strength_mpa <= 0) {
      return 'Valid strength (MPa) value is required';
    }
    
    if (!payload.product_type?.trim()) {
      return 'Product type is required';
    }
    
    const validProductTypes = ['blocks', 'cubes', 'pavers', 'kerbs', 'flagstones'];
    if (!validProductTypes.includes(payload.product_type.toLowerCase())) {
      return 'Invalid product type';
    }
    
    return null;
  }

  /**
   * Get available memos for tablet reference
   */
  static async getAvailableMemos(): Promise<APIResponse> {
    try {
      // This would typically come from memo management system
      const memos = [
        { id: 'MEMO-2024-001', description: 'Concrete Blocks - Batch A' },
        { id: 'MEMO-2024-002', description: 'Pavers Production - Week 12' },
        { id: 'MEMO-2024-003', description: 'Kerbs Testing - March' }
      ];

      return {
        success: true,
        data: memos,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message || 'Failed to get available memos',
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Register tablet device for tracking
   */
  static async registerTabletDevice(deviceInfo: {
    device_id: string;
    device_name: string;
    operator_name?: string;
    location?: string;
  }): Promise<APIResponse> {
    try {
      // In a real implementation, this would save device info to database
      console.log('Tablet device registered:', deviceInfo);
      
      return {
        success: true,
        data: {
          device_id: deviceInfo.device_id,
          registered_at: new Date().toISOString(),
          status: 'active'
        },
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message || 'Failed to register device',
        timestamp: new Date().toISOString()
      };
    }
  }
}