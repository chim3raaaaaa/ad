// Enhanced Reports Service - Consolidated SQLite Integration
import type { Memo, UserProfile } from '@/types';

export interface ReportTemplate {
  id: string;
  name: string;
  product_type: string;
  layout_json: string;
  uploaded_by: string;
  uploaded_at: string;
  file_path?: string;
  template_type: 'canvas' | 'docx' | 'xlsx' | 'pdf';
  version: number;
  is_active: boolean;
}

export interface ReportAttachment {
  id: string;
  report_id: string;
  file_name: string;
  file_type: string;
  file_path: string;
  file_size: number;
  uploaded_by: string;
  uploaded_at: string;
  embed_type: 'inline' | 'link' | 'icon';
}

export interface GeneratedReport {
  id: string;
  memo_id: string;
  template_id: string;
  generated_by: string;
  generated_at: string;
  file_path: string;
  version: number;
  watermark?: string;
  parameters: string; // JSON
}

export interface AnalyticsChart {
  id: string;
  chart_type: string;
  name: string;
  description: string;
  data_source: string;
  config: string; // JSON
  created_by: string;
  created_at: string;
  is_public: boolean;
}

export class EnhancedReportsService {
  
  // Initialize database schema
  static async initializeSchema(): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const queries = [
        // Report Templates table
        `CREATE TABLE IF NOT EXISTS report_templates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          product_type TEXT NOT NULL,
          layout_json TEXT NOT NULL,
          uploaded_by TEXT NOT NULL,
          uploaded_at TEXT NOT NULL,
          file_path TEXT,
          template_type TEXT DEFAULT 'canvas',
          version INTEGER DEFAULT 1,
          is_active BOOLEAN DEFAULT 1
        )`,

        // Report Attachments table
        `CREATE TABLE IF NOT EXISTS report_attachments (
          id TEXT PRIMARY KEY,
          report_id TEXT,
          file_name TEXT NOT NULL,
          file_type TEXT NOT NULL,
          file_path TEXT NOT NULL,
          file_size INTEGER NOT NULL,
          uploaded_by TEXT NOT NULL,
          uploaded_at TEXT NOT NULL,
          embed_type TEXT DEFAULT 'inline'
        )`,

        // Generated Reports table
        `CREATE TABLE IF NOT EXISTS generated_reports (
          id TEXT PRIMARY KEY,
          memo_id TEXT,
          template_id TEXT,
          generated_by TEXT NOT NULL,
          generated_at TEXT NOT NULL,
          file_path TEXT NOT NULL,
          version INTEGER DEFAULT 1,
          watermark TEXT,
          parameters TEXT
        )`,

        // Analytics Charts table
        `CREATE TABLE IF NOT EXISTS analytics_charts (
          id TEXT PRIMARY KEY,
          chart_type TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          data_source TEXT NOT NULL,
          config TEXT NOT NULL,
          created_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_public BOOLEAN DEFAULT 1
        )`,

        // Chart-Template bindings
        `CREATE TABLE IF NOT EXISTS report_chart_bindings (
          id TEXT PRIMARY KEY,
          template_id TEXT NOT NULL,
          chart_id TEXT NOT NULL,
          position_x INTEGER NOT NULL,
          position_y INTEGER NOT NULL,
          width INTEGER NOT NULL,
          height INTEGER NOT NULL,
          created_at TEXT NOT NULL
        )`,

        // File upload tracking
        `CREATE TABLE IF NOT EXISTS uploaded_files (
          id TEXT PRIMARY KEY,
          original_name TEXT NOT NULL,
          stored_path TEXT NOT NULL,
          file_type TEXT NOT NULL,
          file_size INTEGER NOT NULL,
          uploaded_by TEXT NOT NULL,
          uploaded_at TEXT NOT NULL,
          category TEXT DEFAULT 'attachment'
        )`,

        // Template history and versions
        `CREATE TABLE IF NOT EXISTS template_versions (
          id TEXT PRIMARY KEY,
          template_id TEXT NOT NULL,
          version INTEGER NOT NULL,
          layout_json TEXT NOT NULL,
          created_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          notes TEXT
        )`
      ];

      for (const query of queries) {
        const result = await window.electronAPI.dbRun(query);
        if (!result.success) {
          throw new Error(`Failed to create table: ${result.error}`);
        }
      }

      // Insert default analytics charts
      await this.insertDefaultCharts();
      
      return true;
    } catch (error) {
      console.error('Failed to initialize enhanced reports schema:', error);
      return false;
    }
  }

  // Insert default analytics charts
  static async insertDefaultCharts(): Promise<void> {
    const defaultCharts = [
      {
        id: 'sieve-analysis-chart',
        chart_type: 'sieve-analysis',
        name: 'Sieve Analysis',
        description: 'Particle size distribution analysis',
        data_source: 'test_results',
        config: JSON.stringify({
          chartType: 'line',
          xAxis: 'sieve_size',
          yAxis: 'passing_percentage',
          showGrid: true,
          showLegend: true
        })
      },
      {
        id: 'strength-trend-chart',
        chart_type: 'strength-trend',
        name: 'Strength Over Time',
        description: 'Compressive strength trend analysis',
        data_source: 'test_results',
        config: JSON.stringify({
          chartType: 'line',
          xAxis: 'test_date',
          yAxis: 'compressive_strength',
          showTrendline: true,
          showTarget: true
        })
      },
      {
        id: 'fineness-modulus-chart',
        chart_type: 'fineness-trend',
        name: 'Fineness Modulus Trend',
        description: 'FM value tracking over time',
        data_source: 'test_results',
        config: JSON.stringify({
          chartType: 'gauge',
          value: 'fineness_modulus',
          min: 2.0,
          max: 4.0,
          target: 2.8
        })
      },
      {
        id: 'water-absorption-chart',
        chart_type: 'water-absorption',
        name: 'Water Absorption Distribution',
        description: 'Water absorption percentage distribution',
        data_source: 'test_results',
        config: JSON.stringify({
          chartType: 'pie',
          dataKey: 'water_absorption_category',
          showPercentage: true
        })
      },
      {
        id: 'conformity-heatmap-chart',
        chart_type: 'conformity-heatmap',
        name: 'Conformity Status Heatmap',
        description: 'Pass/fail status visualization',
        data_source: 'test_results',
        config: JSON.stringify({
          chartType: 'heatmap',
          xAxis: 'test_date',
          yAxis: 'test_type',
          colorScale: ['#ff4444', '#ffaa44', '#44ff44']
        })
      }
    ];

    for (const chart of defaultCharts) {
      try {
        await window.electronAPI.dbRun(
          `INSERT OR REPLACE INTO analytics_charts 
           (id, chart_type, name, description, data_source, config, created_by, created_at, is_public)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            chart.id,
            chart.chart_type,
            chart.name,
            chart.description,
            chart.data_source,
            chart.config,
            'system',
            new Date().toISOString(),
            true
          ]
        );
      } catch (error) {
        console.error(`Failed to insert default chart ${chart.name}:`, error);
      }
    }
  }

  // Template Management
  static async saveTemplate(template: Omit<ReportTemplate, 'id' | 'uploaded_at'>): Promise<string | null> {
    if (!window.electronAPI) return null;

    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      const result = await window.electronAPI.dbRun(
        `INSERT INTO report_templates 
         (id, name, product_type, layout_json, uploaded_by, uploaded_at, file_path, template_type, version, is_active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          template.name,
          template.product_type,
          template.layout_json,
          template.uploaded_by,
          now,
          template.file_path || null,
          template.template_type || 'canvas',
          template.version || 1,
          template.is_active !== false
        ]
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      // Save version history
      await window.electronAPI.dbRun(
        `INSERT INTO template_versions (id, template_id, version, layout_json, created_by, created_at, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          crypto.randomUUID(),
          id,
          template.version || 1,
          template.layout_json,
          template.uploaded_by,
          now,
          'Initial version'
        ]
      );

      return id;
    } catch (error) {
      console.error('Failed to save template:', error);
      return null;
    }
  }

  static async getTemplatesByProductType(productType: string): Promise<ReportTemplate[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM report_templates 
         WHERE product_type = ? AND is_active = 1 
         ORDER BY uploaded_at DESC`,
        [productType]
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get templates:', error);
      return [];
    }
  }

  static async getTemplateById(id: string): Promise<ReportTemplate | null> {
    if (!window.electronAPI) return null;

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM report_templates WHERE id = ?`,
        [id]
      );

      return result.success && result.data.length > 0 ? result.data[0] : null;
    } catch (error) {
      console.error('Failed to get template by ID:', error);
      return null;
    }
  }

  // Analytics Charts Management
  static async getAnalyticsCharts(): Promise<AnalyticsChart[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM analytics_charts WHERE is_public = 1 ORDER BY name`
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get analytics charts:', error);
      return [];
    }
  }

  static async getChartsByType(chartType: string): Promise<AnalyticsChart[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM analytics_charts WHERE chart_type = ? AND is_public = 1`,
        [chartType]
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get charts by type:', error);
      return [];
    }
  }

  // File Upload Management
  static async saveUploadedFile(
    originalName: string,
    storedPath: string,
    fileType: string,
    fileSize: number,
    uploadedBy: string,
    category: string = 'attachment'
  ): Promise<string | null> {
    if (!window.electronAPI) return null;

    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      const result = await window.electronAPI.dbRun(
        `INSERT INTO uploaded_files 
         (id, original_name, stored_path, file_type, file_size, uploaded_by, uploaded_at, category)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, originalName, storedPath, fileType, fileSize, uploadedBy, now, category]
      );

      return result.success ? id : null;
    } catch (error) {
      console.error('Failed to save uploaded file:', error);
      return null;
    }
  }

  // Report Generation
  static async saveGeneratedReport(
    memoId: string,
    templateId: string,
    filePath: string,
    generatedBy: string,
    parameters: any = {},
    watermark?: string
  ): Promise<string | null> {
    if (!window.electronAPI) return null;

    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      const result = await window.electronAPI.dbRun(
        `INSERT INTO generated_reports 
         (id, memo_id, template_id, generated_by, generated_at, file_path, version, watermark, parameters)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          memoId,
          templateId,
          generatedBy,
          now,
          filePath,
          1,
          watermark || null,
          JSON.stringify(parameters)
        ]
      );

      return result.success ? id : null;
    } catch (error) {
      console.error('Failed to save generated report:', error);
      return null;
    }
  }

  static async getGeneratedReports(memoId?: string): Promise<GeneratedReport[]> {
    if (!window.electronAPI) return [];

    try {
      let query = `
        SELECT gr.*, rt.name as template_name 
        FROM generated_reports gr 
        LEFT JOIN report_templates rt ON gr.template_id = rt.id
        WHERE 1=1
      `;
      const params: string[] = [];

      if (memoId) {
        query += ' AND gr.memo_id = ?';
        params.push(memoId);
      }

      query += ' ORDER BY gr.generated_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get generated reports:', error);
      return [];
    }
  }

  // Attachment Management
  static async saveReportAttachment(attachment: Omit<ReportAttachment, 'id' | 'uploaded_at'>): Promise<string | null> {
    if (!window.electronAPI) return null;

    try {
      const id = crypto.randomUUID();
      const now = new Date().toISOString();

      const result = await window.electronAPI.dbRun(
        `INSERT INTO report_attachments 
         (id, report_id, file_name, file_type, file_path, file_size, uploaded_by, uploaded_at, embed_type)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          attachment.report_id,
          attachment.file_name,
          attachment.file_type,
          attachment.file_path,
          attachment.file_size,
          attachment.uploaded_by,
          now,
          attachment.embed_type || 'inline'
        ]
      );

      return result.success ? id : null;
    } catch (error) {
      console.error('Failed to save report attachment:', error);
      return null;
    }
  }

  static async getReportAttachments(reportId: string): Promise<ReportAttachment[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(
        `SELECT * FROM report_attachments WHERE report_id = ? ORDER BY uploaded_at DESC`,
        [reportId]
      );

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get report attachments:', error);
      return [];
    }
  }

  // Data Binding for Templates
  static async bindMemoDataToTemplate(memoId: string, templateId: string): Promise<any> {
    if (!window.electronAPI) return null;

    try {
      // Get memo data
      const memoResult = await window.electronAPI.dbQuery(
        `SELECT * FROM memos WHERE id = ?`,
        [memoId]
      );

      if (!memoResult.success || memoResult.data.length === 0) {
        throw new Error('Memo not found');
      }

      const memo = memoResult.data[0];

      // Get test results for this memo
      const testResults = await window.electronAPI.dbQuery(
        `SELECT tr.*, tt.name as test_type_name, o.name as officer_name
         FROM test_results tr
         LEFT JOIN test_types tt ON tr.test_type_id = tt.id
         LEFT JOIN officers o ON tr.officer_id = o.id
         WHERE tr.memo_id = ?
         ORDER BY tr.test_date DESC`,
        [memoId]
      );

      // Get production data
      const productionResult = await window.electronAPI.dbQuery(
        `SELECT mp.*, p.name as product_name, p.category as product_category
         FROM memo_productions mp
         LEFT JOIN products p ON mp.product_id = p.id
         WHERE mp.memo_id = ?`,
        [memoId]
      );

      return {
        memo,
        testResults: testResults.success ? testResults.data : [],
        productions: productionResult.success ? productionResult.data : [],
        bindingDate: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to bind memo data to template:', error);
      return null;
    }
  }

  // Search and Filtering
  static async searchTemplates(searchTerm: string, productType?: string): Promise<ReportTemplate[]> {
    if (!window.electronAPI) return [];

    try {
      let query = `
        SELECT * FROM report_templates 
        WHERE is_active = 1 AND (name LIKE ? OR product_type LIKE ?)
      `;
      const params = [`%${searchTerm}%`, `%${searchTerm}%`];

      if (productType) {
        query += ' AND product_type = ?';
        params.push(productType);
      }

      query += ' ORDER BY uploaded_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to search templates:', error);
      return [];
    }
  }

  // Template Deletion
  static async deleteTemplate(templateId: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      // Soft delete - mark as inactive
      const result = await window.electronAPI.dbRun(
        `UPDATE report_templates SET is_active = 0 WHERE id = ?`,
        [templateId]
      );

      return result.success;
    } catch (error) {
      console.error('Failed to delete template:', error);
      return false;
    }
  }
}