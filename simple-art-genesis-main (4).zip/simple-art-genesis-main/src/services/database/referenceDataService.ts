import { toast } from '@/hooks/use-toast';

// Reference data interfaces
export interface Plant {
  id: string;
  name: string;
  code: string;
  location?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface Officer {
  id: string;
  name: string;
  employee_id?: string;
  department?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface AggregateType {
  id: string;
  name: string;
  size_range: string;
  category: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface Machine {
  id: string;
  name: string;
  type: string;
  plant_id?: string;
  model?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface MoistureCondition {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface SamplingPlace {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface ClimaticCondition {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface SampledBy {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface TestType {
  id: string;
  name: string;
  category: string;
  description?: string;
  units?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  code: string;
  category_id: string;
  description?: string;
  specifications?: Record<string, any>;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface GradingLimit {
  id: string;
  name: string;
  type: 'BS' | 'RDA' | 'UBP' | 'Custom';
  category: string;
  size_range: string;
  limits: Record<string, any>;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

class ReferenceDataService {
  private dbName = 'reference_data.db';

  // Initialize all reference data tables
  async initializeTables(): Promise<void> {
    try {
      // Check if running in Electron
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await this.initializeElectronTables();
      } else {
        await this.initializeBrowserTables();
      }
      
      toast({
        title: "Reference Data Initialized",
        description: "All reference data tables have been set up successfully."
      });
    } catch (error) {
      console.error('Error initializing reference data tables:', error);
      toast({
        title: "Initialization Error",
        description: "Failed to initialize reference data tables.",
        variant: "destructive"
      });
      throw error;
    }
  }

  private async initializeElectronTables(): Promise<void> {
    const tables = [
      this.createPlantsTable(),
      this.createOfficersTable(),
      this.createAggregateTypesTable(),
      this.createMachinesTable(),
      this.createMoistureConditionsTable(),
      this.createSamplingPlacesTable(),
      this.createClimaticConditionsTable(),
      this.createSampledByTable(),
      this.createTestTypesTable(),
      this.createProductCategoriesTable(),
      this.createProductsTable(),
      this.createGradingLimitsTable()
    ];

    for (const tableSQL of tables) {
      await (window as any).electronAPI.executeSQL(tableSQL);
    }
  }

  private async initializeBrowserTables(): Promise<void> {
    // For browser storage, we'll use localStorage with structured data
    const defaultData = this.getDefaultReferenceData();
    
    Object.entries(defaultData).forEach(([key, data]) => {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify(data));
      }
    });
  }

  // SQL table creation statements
  private createPlantsTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS plants (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        code TEXT UNIQUE,
        location TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createOfficersTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS officers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        employee_id TEXT UNIQUE,
        department TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createAggregateTypesTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS aggregate_types (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        size_range TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createMachinesTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS machines (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL,
        plant_id TEXT,
        model TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (plant_id) REFERENCES plants(id)
      )
    `;
  }

  private createMoistureConditionsTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS moisture_conditions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createSamplingPlacesTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS sampling_places (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createClimaticConditionsTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS climatic_conditions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createSampledByTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS sampled_by (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createTestTypesTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS test_types (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL,
        description TEXT,
        units TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createProductCategoriesTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS product_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  private createProductsTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT UNIQUE,
        category_id TEXT NOT NULL,
        description TEXT,
        specifications TEXT,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (category_id) REFERENCES product_categories(id)
      )
    `;
  }

  private createGradingLimitsTable(): string {
    return `
      CREATE TABLE IF NOT EXISTS grading_limits (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK (type IN ('BS', 'RDA', 'UBP', 'Custom')),
        category TEXT NOT NULL,
        size_range TEXT NOT NULL,
        limits TEXT NOT NULL,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `;
  }

  // Default reference data for browser storage
  private getDefaultReferenceData() {
    const now = new Date().toISOString();
    
    return {
      plants: [
        { id: '1', name: 'FAST', code: 'FAST', location: 'Fast Location', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'GEOFFROY ROAD I', code: 'GEO1', location: 'Geoffroy Road', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'PLAINE MAGNIEN', code: 'PLM', location: 'Plaine Magnien', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'SAINT JULIEN', code: 'STJ', location: 'Saint Julien', status: 'active', created_at: now, updated_at: now }
      ],
      officers: [
        { id: '1', name: 'B. VERLOPPE', employee_id: 'BV001', department: 'Quality Control', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'F. APPADOO', employee_id: 'FA001', department: 'Quality Control', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'R. RAMLUGUN', employee_id: 'RR001', department: 'Quality Control', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'S. BOODHOO', employee_id: 'SB001', department: 'Quality Control', status: 'active', created_at: now, updated_at: now }
      ],
      aggregate_types: [
        { id: '1', name: '0-1mm', size_range: '0-1', category: 'Fine', description: 'Fine aggregate 0-1mm', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: '0-2mm', size_range: '0-2', category: 'Fine', description: 'Fine aggregate 0-2mm', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: '4-6mm', size_range: '4-6', category: 'Coarse', description: 'Coarse aggregate 4-6mm', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: '20-31.5mm', size_range: '20-31.5', category: 'Coarse', description: 'Coarse aggregate 20-31.5mm', status: 'active', created_at: now, updated_at: now }
      ],
      machines: [
        { id: '1', name: 'DERRICK', type: 'Crusher', plant_id: '1', model: 'DRK-2000', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'HP 200', type: 'Crusher', plant_id: '2', model: 'HP200', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'SBM', type: 'Crusher', plant_id: '3', model: 'SBM-100', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'Barmac', type: 'VSI', plant_id: '4', model: 'BAR-500', status: 'active', created_at: now, updated_at: now }
      ],
      moisture_conditions: [
        { id: '1', name: 'DRY', description: 'Dry condition', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'UNWASHED', description: 'Unwashed condition', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'WASHED', description: 'Washed condition', status: 'active', created_at: now, updated_at: now }
      ],
      sampling_places: [
        { id: '1', name: 'Stockpile', description: 'From stockpile', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'Conveyor', description: 'From conveyor belt', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: "Client's site", description: 'At client location', status: 'active', created_at: now, updated_at: now }
      ],
      climatic_conditions: [
        { id: '1', name: 'Fine', description: 'Fine weather', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'Sunny', description: 'Sunny weather', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'Rainy', description: 'Rainy weather', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'Cloudy', description: 'Cloudy weather', status: 'active', created_at: now, updated_at: now }
      ],
      sampled_by: [
        { id: '1', name: 'LAB', description: 'Laboratory staff', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'UBP/DMX Lab', description: 'UBP/DMX Laboratory', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'Client', description: 'Client representative', status: 'active', created_at: now, updated_at: now }
      ],
      test_types: [
        { id: '1', name: 'Moisture', category: 'Physical', description: 'Moisture content test', units: '%', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'Fineness Modulus', category: 'Physical', description: 'Fineness modulus test', units: '', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'Flakiness', category: 'Physical', description: 'Flakiness index test', units: '%', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'Methylene Blue', category: 'Chemical', description: 'Methylene blue test', units: 'g/kg', status: 'active', created_at: now, updated_at: now }
      ],
      product_categories: [
        { id: '1', name: 'Aggregates', description: 'All types of aggregates', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'Blocks', description: 'Concrete blocks', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'Cubes', description: 'Test cubes', status: 'active', created_at: now, updated_at: now },
        { id: '4', name: 'Pavers', description: 'Paving stones', status: 'active', created_at: now, updated_at: now },
        { id: '5', name: 'Kerbs', description: 'Kerb stones', status: 'active', created_at: now, updated_at: now },
        { id: '6', name: 'Flagstones', description: 'Flag stones', status: 'active', created_at: now, updated_at: now }
      ],
      products: [
        { id: '1', name: '0-4mm Fine Aggregate', code: 'FA04', category_id: '1', description: 'Fine aggregate 0-4mm', specifications: '{}', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: '4-20mm Coarse Aggregate', code: 'CA420', category_id: '1', description: 'Coarse aggregate 4-20mm', specifications: '{}', status: 'active', created_at: now, updated_at: now },
        { id: '3', name: 'Standard Block', code: 'SB001', category_id: '2', description: 'Standard concrete block', specifications: '{}', status: 'active', created_at: now, updated_at: now }
      ],
      grading_limits: [
        { id: '1', name: 'BS 4-6mm Limits', type: 'BS', category: 'Aggregates', size_range: '4-6', limits: '{"min": 90, "max": 100}', status: 'active', created_at: now, updated_at: now },
        { id: '2', name: 'RDA All in 0-20mm', type: 'RDA', category: 'Aggregates', size_range: '0-20', limits: '{"min": 95, "max": 100}', status: 'active', created_at: now, updated_at: now }
      ]
    };
  }

  // CRUD operations for Plants
  async getPlants(): Promise<Plant[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM plants WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('plants');
        return data ? JSON.parse(data).filter((p: Plant) => p.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching plants:', error);
      return [];
    }
  }

  async createPlant(plant: Omit<Plant, 'id' | 'created_at' | 'updated_at'>): Promise<Plant> {
    const newPlant: Plant = {
      ...plant,
      id: `plant_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        await (window as any).electronAPI.executeSQL(
          'INSERT INTO plants (id, name, code, location, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [newPlant.id, newPlant.name, newPlant.code, newPlant.location, newPlant.status, newPlant.created_at, newPlant.updated_at]
        );
      } else {
        const plants = await this.getPlants();
        plants.push(newPlant);
        localStorage.setItem('plants', JSON.stringify(plants));
      }
      return newPlant;
    } catch (error) {
      console.error('Error creating plant:', error);
      throw error;
    }
  }

  // CRUD operations for Officers
  async getOfficers(): Promise<Officer[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM officers WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('officers');
        return data ? JSON.parse(data).filter((o: Officer) => o.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching officers:', error);
      return [];
    }
  }

  // CRUD operations for Aggregate Types
  async getAggregateTypes(): Promise<AggregateType[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM aggregate_types WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('aggregate_types');
        return data ? JSON.parse(data).filter((a: AggregateType) => a.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching aggregate types:', error);
      return [];
    }
  }

  // CRUD operations for Machines
  async getMachines(): Promise<Machine[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM machines WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('machines');
        return data ? JSON.parse(data).filter((m: Machine) => m.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching machines:', error);
      return [];
    }
  }

  // CRUD operations for Product Categories
  async getProductCategories(): Promise<ProductCategory[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM product_categories WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('product_categories');
        return data ? JSON.parse(data).filter((c: ProductCategory) => c.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching product categories:', error);
      return [];
    }
  }

  // CRUD operations for Products
  async getProducts(categoryId?: string): Promise<Product[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const query = categoryId 
          ? 'SELECT * FROM products WHERE status = "active" AND category_id = ? ORDER BY name'
          : 'SELECT * FROM products WHERE status = "active" ORDER BY name';
        const params = categoryId ? [categoryId] : [];
        const result = await (window as any).electronAPI.executeSQL(query, params);
        return result || [];
      } else {
        const data = localStorage.getItem('products');
        const products = data ? JSON.parse(data).filter((p: Product) => p.status === 'active') : [];
        return categoryId ? products.filter((p: Product) => p.category_id === categoryId) : products;
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      return [];
    }
  }

  // Get all dropdown options for different reference types
  async getAllDropdownOptions() {
    try {
      const [
        plants,
        officers,
        aggregateTypes,
        machines,
        moistureConditions,
        samplingPlaces,
        climaticConditions,
        sampledBy,
        testTypes,
        productCategories
      ] = await Promise.all([
        this.getPlants(),
        this.getOfficers(),
        this.getAggregateTypes(),
        this.getMachines(),
        this.getMoistureConditions(),
        this.getSamplingPlaces(),
        this.getClimaticConditions(),
        this.getSampledBy(),
        this.getTestTypes(),
        this.getProductCategories()
      ]);

      return {
        plants: plants.map(p => ({ value: p.id, label: p.name })),
        officers: officers.map(o => ({ value: o.id, label: o.name })),
        aggregateTypes: aggregateTypes.map(a => ({ value: a.id, label: a.name })),
        machines: machines.map(m => ({ value: m.id, label: m.name })),
        moistureConditions: moistureConditions.map(m => ({ value: m.id, label: m.name })),
        samplingPlaces: samplingPlaces.map(s => ({ value: s.id, label: s.name })),
        climaticConditions: climaticConditions.map(c => ({ value: c.id, label: c.name })),
        sampledBy: sampledBy.map(s => ({ value: s.id, label: s.name })),
        testTypes: testTypes.map(t => ({ value: t.id, label: t.name })),
        productCategories: productCategories.map(c => ({ value: c.id, label: c.name }))
      };
    } catch (error) {
      console.error('Error fetching dropdown options:', error);
      return {
        plants: [],
        officers: [],
        aggregateTypes: [],
        machines: [],
        moistureConditions: [],
        samplingPlaces: [],
        climaticConditions: [],
        sampledBy: [],
        testTypes: [],
        productCategories: []
      };
    }
  }

  // Helper methods for other reference data types
  async getMoistureConditions(): Promise<MoistureCondition[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM moisture_conditions WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('moisture_conditions');
        return data ? JSON.parse(data).filter((m: MoistureCondition) => m.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching moisture conditions:', error);
      return [];
    }
  }

  async getSamplingPlaces(): Promise<SamplingPlace[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM sampling_places WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('sampling_places');
        return data ? JSON.parse(data).filter((s: SamplingPlace) => s.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching sampling places:', error);
      return [];
    }
  }

  async getClimaticConditions(): Promise<ClimaticCondition[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM climatic_conditions WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('climatic_conditions');
        return data ? JSON.parse(data).filter((c: ClimaticCondition) => c.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching climatic conditions:', error);
      return [];
    }
  }

  async getSampledBy(): Promise<SampledBy[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM sampled_by WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('sampled_by');
        return data ? JSON.parse(data).filter((s: SampledBy) => s.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching sampled by options:', error);
      return [];
    }
  }

  async getTestTypes(): Promise<TestType[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const result = await (window as any).electronAPI.executeSQL('SELECT * FROM test_types WHERE status = "active" ORDER BY name');
        return result || [];
      } else {
        const data = localStorage.getItem('test_types');
        return data ? JSON.parse(data).filter((t: TestType) => t.status === 'active') : [];
      }
    } catch (error) {
      console.error('Error fetching test types:', error);
      return [];
    }
  }

  async getGradingLimits(category?: string): Promise<GradingLimit[]> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        const query = category 
          ? 'SELECT * FROM grading_limits WHERE status = "active" AND category = ? ORDER BY name'
          : 'SELECT * FROM grading_limits WHERE status = "active" ORDER BY name';
        const params = category ? [category] : [];
        const result = await (window as any).electronAPI.executeSQL(query, params);
        return result || [];
      } else {
        const data = localStorage.getItem('grading_limits');
        const limits = data ? JSON.parse(data).filter((g: GradingLimit) => g.status === 'active') : [];
        return category ? limits.filter((g: GradingLimit) => g.category === category) : limits;
      }
    } catch (error) {
      console.error('Error fetching grading limits:', error);
      return [];
    }
  }
}

export const referenceDataService = new ReferenceDataService();