import { toast } from '@/hooks/use-toast';

export interface KerbTestData {
  id: string;
  memo_reference: string;
  plant_id: string;
  product_type: string;
  test_date: string;
  officer_id: string;
  machine_id?: string;
  
  // Kerb-specific parameters
  profile_type: 'standard' | 'heavy_duty' | 'barrier';
  length: number;
  height: number;
  width: number;
  compressive_strength: number;
  water_absorption: number;
  impact_resistance: number;
  
  // Results
  pass_fail_status: 'pass' | 'fail' | 'pending';
  compliance_notes?: string;
  
  created_at: string;
  updated_at: string;
}

class KerbTestService {
  private storageKey = 'kerb_databases';

  async getPlantDatabases(plantId: string): Promise<any[]> {
    try {
      const stored = localStorage.getItem(this.storageKey);
      const allDatabases = stored ? JSON.parse(stored) : [];
      return allDatabases.filter((db: any) => db.plant_id === plantId);
    } catch (error) {
      return [];
    }
  }

  async createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string> {
    const database = {
      id: `kerb_db_${Date.now()}`,
      name: `Kerb Tests - ${productType}`,
      plant_id: plantId,
      product_type: productType,
      table_name: `kerb_tests_${plantId}_${productType}`.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      created_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(this.storageKey);
    const databases = stored ? JSON.parse(stored) : [];
    databases.push(database);
    localStorage.setItem(this.storageKey, JSON.stringify(databases));
    localStorage.setItem(database.table_name, JSON.stringify([]));

    return database.id;
  }

  async getTestEntries(tableName: string): Promise<KerbTestData[]> {
    const stored = localStorage.getItem(tableName);
    return stored ? JSON.parse(stored) : [];
  }

  async createTestEntry(tableName: string, testData: any): Promise<string> {
    const entry = {
      ...testData,
      id: `kerb_test_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    entries.push(entry);
    localStorage.setItem(tableName, JSON.stringify(entries));

    return entry.id;
  }

  async updateTestEntry(tableName: string, id: string, updates: any): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    const index = entries.findIndex((entry: any) => entry.id === id);
    
    if (index !== -1) {
      entries[index] = { ...entries[index], ...updates, updated_at: new Date().toISOString() };
      localStorage.setItem(tableName, JSON.stringify(entries));
    }
  }

  async deleteTestEntry(tableName: string, id: string): Promise<void> {
    const stored = localStorage.getItem(tableName);
    const entries = stored ? JSON.parse(stored) : [];
    localStorage.setItem(tableName, JSON.stringify(entries.filter((e: any) => e.id !== id)));
  }

  async validateTestData(testData: KerbTestData): Promise<{ isValid: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    if (testData.compressive_strength < 30) {
      errors.push('Compressive strength must be at least 30 MPa');
    }
    if (testData.water_absorption > 8) {
      errors.push('Water absorption must not exceed 8%');
    }

    return { isValid: errors.length === 0, errors };
  }
}

export const kerbTestService = new KerbTestService();