import { ApiClient } from '@/lib/apiClient';

export interface MemoData {
  id?: string;
  memo_ref: string;
  category: string;
  plant: string;
  product_type: string;
  material_type?: string;
  date_of_sampling: string;
  officer: string;
  machine?: string;
  status: 'draft' | 'pending' | 'approved' | 'rejected';
  created_by: string;
  created_at: string;
  updated_at: string;
  extracted_data?: any;
  attachments?: MemoAttachment[];
}

export interface MemoAttachment {
  id: string;
  memo_ref: string;
  filename: string;
  file_path: string;
  file_size: number;
  uploaded_by: string;
  uploaded_at: string;
}

export interface MemoInboxEntry {
  id?: string;
  memo_ref: string;
  status: 'pending' | 'acknowledged' | 'flagged';
  assigned_to?: string;
  acknowledged_by?: string;
  acknowledged_at?: string;
  discrepancy_flags?: string;
  remarks?: string;
  created_at: string;
}

export interface MemoCategory {
  id: string;
  name: string;
  table_name: string;
  modal_component: string;
  fields: any;
  is_active: boolean;
}

class MemoService {
  private isElectron: boolean;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!(window as any).electronAPI;
  }

  async initialize(): Promise<void> {
    if (this.isElectron) {
      await this.createTables();
    }
  }

  private async createTables(): Promise<void> {
    const tables = [
      `CREATE TABLE IF NOT EXISTS memo_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        table_name TEXT NOT NULL,
        modal_component TEXT NOT NULL,
        fields TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )`,
      `CREATE TABLE IF NOT EXISTS memos (
        id TEXT PRIMARY KEY,
        memo_ref TEXT UNIQUE NOT NULL,
        category TEXT NOT NULL,
        plant TEXT NOT NULL,
        product_type TEXT NOT NULL,
        material_type TEXT,
        date_of_sampling TEXT NOT NULL,
        officer TEXT NOT NULL,
        machine TEXT,
        status TEXT DEFAULT 'draft',
        created_by TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        extracted_data TEXT
      )`,
      `CREATE TABLE IF NOT EXISTS memo_attachments (
        id TEXT PRIMARY KEY,
        memo_ref TEXT NOT NULL,
        filename TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        uploaded_by TEXT NOT NULL,
        uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memo_ref) REFERENCES memos(memo_ref)
      )`,
      `CREATE TABLE IF NOT EXISTS memo_inbox (
        id TEXT PRIMARY KEY,
        memo_ref TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        assigned_to TEXT,
        acknowledged_by TEXT,
        acknowledged_at TEXT,
        discrepancy_flags TEXT,
        remarks TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memo_ref) REFERENCES memos(memo_ref)
      )`,
      `CREATE TABLE IF NOT EXISTS memo_checklists (
        id TEXT PRIMARY KEY,
        memo_ref TEXT NOT NULL,
        checklist_data TEXT NOT NULL,
        completed_by TEXT,
        completed_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memo_ref) REFERENCES memos(memo_ref)
      )`
    ];

    for (const sql of tables) {
      await (window as any).electronAPI.dbRun(sql);
    }

    // Insert default categories
    await this.insertDefaultCategories();
  }

  private async insertDefaultCategories(): Promise<void> {
    const defaultCategories = [
      {
        id: 'aggregates',
        name: 'Aggregates',
        table_name: 'aggregates_test',
        modal_component: 'AggregateModalForm',
        fields: JSON.stringify(['gradingAnalysis', 'moistureContent', 'specificGravity'])
      },
      {
        id: 'concrete',
        name: 'Concrete Products',
        table_name: 'concrete_test',
        modal_component: 'ConcreteModalForm',
        fields: JSON.stringify(['compressiveStrength', 'density', 'absorptionRate'])
      },
      {
        id: 'pavers',
        name: 'Pavers',
        table_name: 'pavers_test',
        modal_component: 'PaverMemoModal',
        fields: JSON.stringify(['thickness', 'length', 'width', 'weight'])
      }
    ];

    for (const category of defaultCategories) {
      const exists = await this.getCategoryById(category.id);
      if (!exists) {
        const sql = `INSERT INTO memo_categories (id, name, table_name, modal_component, fields) 
                     VALUES (?, ?, ?, ?, ?)`;
        await (window as any).electronAPI.dbRun(sql, [
          category.id,
          category.name,
          category.table_name,
          category.modal_component,
          category.fields
        ]);
      }
    }
  }

  // Memo operations
  async createMemo(memoData: Omit<MemoData, 'id' | 'created_at' | 'updated_at'>): Promise<string> {
    if (this.isElectron) {
      const sql = `INSERT INTO memos (id, memo_ref, category, plant, product_type, material_type, 
                   date_of_sampling, officer, machine, status, created_by, extracted_data)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
      const id = crypto.randomUUID();
      await (window as any).electronAPI.dbRun(sql, [
        id, memoData.memo_ref, memoData.category, memoData.plant, memoData.product_type,
        memoData.material_type, memoData.date_of_sampling, memoData.officer,
        memoData.machine, memoData.status, memoData.created_by,
        JSON.stringify(memoData.extracted_data)
      ]);
      return id;
    } else {
      const response = await fetch('/api/memos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(memoData)
      });
      const data = await response.json();
      return data.id;
    }
  }

  async getMemos(filters?: any): Promise<MemoData[]> {
    if (this.isElectron) {
      let sql = `SELECT m.*, GROUP_CONCAT(ma.filename) as attachment_files
                 FROM memos m
                 LEFT JOIN memo_attachments ma ON m.memo_ref = ma.memo_ref`;
      const params: any[] = [];

      if (filters) {
        const conditions = [];
        if (filters.category) {
          conditions.push('m.category = ?');
          params.push(filters.category);
        }
        if (filters.status) {
          conditions.push('m.status = ?');
          params.push(filters.status);
        }
        if (filters.plant) {
          conditions.push('m.plant = ?');
          params.push(filters.plant);
        }
        if (conditions.length > 0) {
          sql += ' WHERE ' + conditions.join(' AND ');
        }
      }

      sql += ' GROUP BY m.id ORDER BY m.created_at DESC';
      const result = await (window as any).electronAPI.dbQuery(sql, params);
      return result.map((row: any) => ({
        ...row,
        extracted_data: row.extracted_data ? JSON.parse(row.extracted_data) : null
      }));
    } else {
      const queryParams = new URLSearchParams(filters || {});
      const response = await fetch(`/api/memos?${queryParams}`);
      return response.json();
    }
  }

  async updateMemo(id: string, updates: Partial<MemoData>): Promise<boolean> {
    if (this.isElectron) {
      const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const sql = `UPDATE memos SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
      const values = [...Object.values(updates), id];
      await (window as any).electronAPI.dbRun(sql, values);
      return true;
    } else {
      const response = await fetch(`/api/memos/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      return response.ok;
    }
  }

  async deleteMemo(id: string): Promise<boolean> {
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun('DELETE FROM memo_attachments WHERE memo_ref = (SELECT memo_ref FROM memos WHERE id = ?)', [id]);
      await (window as any).electronAPI.dbRun('DELETE FROM memo_inbox WHERE memo_ref = (SELECT memo_ref FROM memos WHERE id = ?)', [id]);
      await (window as any).electronAPI.dbRun('DELETE FROM memos WHERE id = ?', [id]);
      return true;
    } else {
      const response = await fetch(`/api/memos/${id}`, { method: 'DELETE' });
      return response.ok;
    }
  }

  // Category operations
  async getCategories(): Promise<MemoCategory[]> {
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT * FROM memo_categories WHERE is_active = 1 ORDER BY name'
      );
      return result.map((row: any) => ({
        ...row,
        fields: JSON.parse(row.fields),
        is_active: Boolean(row.is_active)
      }));
    } else {
      const response = await fetch('/api/memo-categories');
      return response.json();
    }
  }

  async getCategoryById(id: string): Promise<MemoCategory | null> {
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT * FROM memo_categories WHERE id = ?', [id]
      );
      if (result.length === 0) return null;
      const row = result[0];
      return {
        ...row,
        fields: JSON.parse(row.fields),
        is_active: Boolean(row.is_active)
      };
    } else {
      const response = await fetch(`/api/memo-categories/${id}`);
      if (!response.ok) return null;
      return response.json();
    }
  }

  async createCategory(category: Omit<MemoCategory, 'id'>): Promise<string> {
    const id = crypto.randomUUID();
    if (this.isElectron) {
      const sql = `INSERT INTO memo_categories (id, name, table_name, modal_component, fields, is_active)
                   VALUES (?, ?, ?, ?, ?, ?)`;
      await (window as any).electronAPI.dbRun(sql, [
        id, category.name, category.table_name, category.modal_component,
        JSON.stringify(category.fields), category.is_active ? 1 : 0
      ]);
    } else {
      await fetch('/api/memo-categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...category, id })
      });
    }
    return id;
  }

  // Inbox operations
  async submitToInbox(memoRef: string, assignedTo?: string): Promise<boolean> {
    if (this.isElectron) {
      const sql = `INSERT INTO memo_inbox (id, memo_ref, assigned_to) VALUES (?, ?, ?)`;
      await (window as any).electronAPI.dbRun(sql, [crypto.randomUUID(), memoRef, assignedTo]);
      return true;
    } else {
      const response = await fetch('/api/memo-inbox', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memo_ref: memoRef, assigned_to: assignedTo })
      });
      return response.ok;
    }
  }

  async getInboxEntries(status?: string): Promise<MemoInboxEntry[]> {
    if (this.isElectron) {
      let sql = 'SELECT * FROM memo_inbox';
      const params: any[] = [];
      if (status) {
        sql += ' WHERE status = ?';
        params.push(status);
      }
      sql += ' ORDER BY created_at DESC';
      return await (window as any).electronAPI.dbQuery(sql, params);
    } else {
      const queryParams = status ? `?status=${status}` : '';
      const response = await fetch(`/api/memo-inbox${queryParams}`);
      return response.json();
    }
  }

  async acknowledgeMemo(memoRef: string, acknowledgedBy: string, remarks?: string): Promise<boolean> {
    if (this.isElectron) {
      const sql = `UPDATE memo_inbox SET status = 'acknowledged', acknowledged_by = ?, 
                   acknowledged_at = CURRENT_TIMESTAMP, remarks = ? WHERE memo_ref = ?`;
      await (window as any).electronAPI.dbRun(sql, [acknowledgedBy, remarks, memoRef]);
      return true;
    } else {
      const response = await fetch(`/api/memo-inbox/${memoRef}/acknowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acknowledged_by: acknowledgedBy, remarks })
      });
      return response.ok;
    }
  }

  // Attachment operations
  async addAttachment(memoRef: string, file: File, uploadedBy: string): Promise<boolean> {
    if (this.isElectron) {
      // Save file using electron API and store reference
      const filePath = await (window as any).electronAPI.saveFile(file.name, await file.arrayBuffer());
      const sql = `INSERT INTO memo_attachments (id, memo_ref, filename, file_path, file_size, uploaded_by)
                   VALUES (?, ?, ?, ?, ?, ?)`;
      await (window as any).electronAPI.dbRun(sql, [
        crypto.randomUUID(), memoRef, file.name, filePath, file.size, uploadedBy
      ]);
      return true;
    } else {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('memo_ref', memoRef);
      formData.append('uploaded_by', uploadedBy);
      
      const response = await fetch('/api/memo-attachments', {
        method: 'POST',
        body: formData
      });
      return response.ok;
    }
  }

  // Generate memo reference
  async generateMemoRef(plant: string, category: string): Promise<string> {
    const year = new Date().getFullYear();
    const prefix = `${plant.toUpperCase()}-${category.toUpperCase()}-${year}`;
    
    if (this.isElectron) {
      const result = await (window as any).electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM memos WHERE memo_ref LIKE ?',
        [`${prefix}-%`]
      );
      const count = result[0]?.count || 0;
      return `${prefix}-${String(count + 1).padStart(4, '0')}`;
    } else {
      const response = await fetch(`/api/memo-ref/generate?plant=${plant}&category=${category}`);
      const data = await response.json();
      return data.memo_ref;
    }
  }
}

export const memoService = new MemoService();