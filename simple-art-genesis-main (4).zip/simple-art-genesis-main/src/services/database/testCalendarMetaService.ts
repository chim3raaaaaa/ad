import { enhancedDashboardService } from './enhancedDashboardService';

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface TestCalendarMeta {
  id: string;
  test_id: string;
  test_type: string;
  memo_ref: string;
  officer: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'overdue';
  scheduled_date: string;
  completed_date?: string;
  recurring_rule?: string;
  priority: 'low' | 'normal' | 'high' | 'critical';
  plant_location?: string;
  sample_location?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

class TestCalendarMetaService {
  private isElectron = false;
  private isInitialized = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        await this.createTestCalendarMetaTable();
        console.log('Test Calendar Meta Service initialized');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Test Calendar Meta Service:', error);
      throw error;
    }
  }

  private async createTestCalendarMetaTable(): Promise<void> {
    if (!this.isElectron) return;

    try {
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS TestCalendarMeta (
          id TEXT PRIMARY KEY,
          test_id TEXT NOT NULL,
          test_type TEXT NOT NULL,
          memo_ref TEXT NOT NULL,
          officer TEXT NOT NULL,
          status TEXT DEFAULT 'pending',
          scheduled_date TEXT NOT NULL,
          completed_date TEXT,
          recurring_rule TEXT,
          priority TEXT DEFAULT 'normal',
          plant_location TEXT,
          sample_location TEXT,
          notes TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (memo_ref) REFERENCES memos(id)
        )
      `);

      // Create indexes for better performance
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_test_calendar_meta_memo_ref ON TestCalendarMeta(memo_ref)
      `);
      
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_test_calendar_meta_status ON TestCalendarMeta(status)
      `);
      
      await window.electronAPI.dbQuery(`
        CREATE INDEX IF NOT EXISTS idx_test_calendar_meta_scheduled_date ON TestCalendarMeta(scheduled_date)
      `);

      console.log('TestCalendarMeta table and indexes created successfully');
    } catch (error) {
      console.error('Error creating TestCalendarMeta table:', error);
      throw error;
    }
  }

  async createCalendarEntry(data: {
    test_id: string;
    test_type: string;
    memo_ref: string;
    officer: string;
    scheduled_date: string;
    recurring_rule?: string;
    priority?: string;
    plant_location?: string;
    sample_location?: string;
    notes?: string;
  }): Promise<string | null> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Calendar entry created (browser mode)');
      return `mock_${Date.now()}`;
    }

    try {
      const id = `tcm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const result = await window.electronAPI.dbQuery(`
        INSERT INTO TestCalendarMeta (
          id, test_id, test_type, memo_ref, officer, status, scheduled_date, 
          recurring_rule, priority, plant_location, sample_location, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        data.test_id,
        data.test_type,
        data.memo_ref,
        data.officer,
        'pending',
        data.scheduled_date,
        data.recurring_rule || null,
        data.priority || 'normal',
        data.plant_location || null,
        data.sample_location || null,
        data.notes || null
      ]);

      if (result.success) {
        console.log(`Created calendar entry: ${id}`);
        return id;
      } else {
        console.error('Failed to create calendar entry:', result.error);
        return null;
      }
    } catch (error) {
      console.error('Error creating calendar entry:', error);
      return null;
    }
  }

  async markCalendarTestComplete(test_id: string, completed_by?: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Calendar test marked complete (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE TestCalendarMeta 
        SET status = 'completed', 
            completed_date = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE test_id = ?
      `, [test_id]);

      if (result.success) {
        console.log(`Marked calendar test ${test_id} as completed`);
        return true;
      } else {
        console.error('Failed to mark calendar test complete:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error marking calendar test complete:', error);
      return false;
    }
  }

  async getCalendarMeta(filters?: {
    status?: string;
    date_range?: { start: string; end: string };
    officer?: string;
    memo_ref?: string;
  }): Promise<TestCalendarMeta[]> {
    await this.initialize();

    if (!this.isElectron) {
      return this.getMockCalendarMeta();
    }

    try {
      let query = 'SELECT * FROM TestCalendarMeta WHERE 1=1';
      const params: any[] = [];

      if (filters?.status) {
        query += ' AND status = ?';
        params.push(filters.status);
      }

      if (filters?.date_range) {
        query += ' AND scheduled_date BETWEEN ? AND ?';
        params.push(filters.date_range.start, filters.date_range.end);
      }

      if (filters?.officer) {
        query += ' AND officer = ?';
        params.push(filters.officer);
      }

      if (filters?.memo_ref) {
        query += ' AND memo_ref = ?';
        params.push(filters.memo_ref);
      }

      query += ' ORDER BY scheduled_date ASC, priority DESC';

      const result = await window.electronAPI.dbQuery(query, params);

      if (!result.success) {
        console.error('Failed to fetch calendar meta:', result.error);
        return [];
      }

      return result.data as TestCalendarMeta[];
    } catch (error) {
      console.error('Error fetching calendar meta:', error);
      return [];
    }
  }

  async updateCalendarEntry(id: string, updates: Partial<TestCalendarMeta>): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Calendar entry updated (browser mode)');
      return true;
    }

    try {
      const fields = Object.keys(updates).filter(key => key !== 'id');
      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const values = fields.map(field => updates[field as keyof TestCalendarMeta]);

      const result = await window.electronAPI.dbQuery(`
        UPDATE TestCalendarMeta 
        SET ${setClause}, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [...values, id]);

      if (result.success) {
        console.log(`Updated calendar entry: ${id}`);
        return true;
      } else {
        console.error('Failed to update calendar entry:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error updating calendar entry:', error);
      return false;
    }
  }

  async deleteCalendarEntry(id: string): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Calendar entry deleted (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(
        'DELETE FROM TestCalendarMeta WHERE id = ?',
        [id]
      );

      if (result.success) {
        console.log(`Deleted calendar entry: ${id}`);
        return true;
      } else {
        console.error('Failed to delete calendar entry:', result.error);
        return false;
      }
    } catch (error) {
      console.error('Error deleting calendar entry:', error);
      return false;
    }
  }

  private getMockCalendarMeta(): TestCalendarMeta[] {
    console.warn('Using mock calendar meta data - database not available');
    return [];
  }
}

export const testCalendarMetaService = new TestCalendarMetaService();