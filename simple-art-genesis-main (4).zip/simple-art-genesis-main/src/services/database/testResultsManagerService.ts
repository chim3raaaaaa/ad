// Test Results Manager Database Service - Local SQLite Integration
export class TestResultsManagerService {
  
  // Initialize all required tables
  static async initializeTables(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      // Lab Sites table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS lab_sites (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          location TEXT,
          active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Products table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS products (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          category TEXT NOT NULL,
          type TEXT,
          description TEXT,
          active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Test Types table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_types (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          product_category TEXT,
          active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Officers table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS officers (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          role TEXT NOT NULL,
          department TEXT,
          lab_site_id TEXT,
          active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (lab_site_id) REFERENCES lab_sites(id)
        )
      `);

      // Memo Productions table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS memo_productions (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          production_date TEXT NOT NULL,
          machine TEXT,
          samples_count INTEGER DEFAULT 0,
          batch_number TEXT,
          product_id TEXT,
          details TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (memo_id) REFERENCES memos(id),
          FOREIGN KEY (product_id) REFERENCES products(id)
        )
      `);

      // Test Results table
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_results (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          production_id TEXT NOT NULL,
          test_type_id TEXT NOT NULL,
          officer_id TEXT NOT NULL,
          test_date TEXT NOT NULL,
          results TEXT NOT NULL,
          status TEXT CHECK(status IN ('pass', 'fail', 'pending')) DEFAULT 'pending',
          notes TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(memo_id, production_id, test_type_id),
          FOREIGN KEY (memo_id) REFERENCES memos(id),
          FOREIGN KEY (production_id) REFERENCES memo_productions(id),
          FOREIGN KEY (test_type_id) REFERENCES test_types(id),
          FOREIGN KEY (officer_id) REFERENCES officers(id)
        )
      `);

      // Test Requests table (updated)
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS test_requests (
          id TEXT PRIMARY KEY,
          memo_id TEXT NOT NULL,
          production_id TEXT NOT NULL,
          test_type_id TEXT NOT NULL,
          status TEXT CHECK(status IN ('pending', 'in_progress', 'completed')) DEFAULT 'pending',
          assigned_to TEXT,
          priority TEXT CHECK(priority IN ('low', 'medium', 'high', 'urgent')) DEFAULT 'medium',
          due_date TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(memo_id, production_id, test_type_id),
          FOREIGN KEY (memo_id) REFERENCES memos(id),
          FOREIGN KEY (production_id) REFERENCES memo_productions(id),
          FOREIGN KEY (test_type_id) REFERENCES test_types(id),
          FOREIGN KEY (assigned_to) REFERENCES officers(id)
        )
      `);

      // Insert default data if tables are empty
      await this.insertDefaultData();

      console.log('Test requests tables initialized successfully');
    } catch (error) {
      console.error('Failed to initialize test requests tables:', error);
    }
  }

  // Insert default data
  static async insertDefaultData(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      // Default lab sites
      const defaultSites = [
        { id: 'site-001', name: 'Main Laboratory', location: 'Building A' },
        { id: 'site-002', name: 'Quality Control Lab', location: 'Building B' },
        { id: 'site-003', name: 'Research Lab', location: 'Building C' }
      ];

      for (const site of defaultSites) {
        await window.electronAPI.dbRun(
          'INSERT OR IGNORE INTO lab_sites (id, name, location) VALUES (?, ?, ?)',
          [site.id, site.name, site.location]
        );
      }

      // Default products
      const defaultProducts = [
        { id: 'prod-001', name: 'Concrete Blocks', category: 'Construction', type: 'Precast' },
        { id: 'prod-002', name: 'Steel Rebar', category: 'Materials', type: 'Reinforcement' },
        { id: 'prod-003', name: 'Asphalt Mix', category: 'Road Construction', type: 'Bituminous' },
        { id: 'prod-004', name: 'Cement Samples', category: 'Materials', type: 'Binding' }
      ];

      for (const product of defaultProducts) {
        await window.electronAPI.dbRun(
          'INSERT OR IGNORE INTO products (id, name, category, type) VALUES (?, ?, ?, ?)',
          [product.id, product.name, product.category, product.type]
        );
      }

      // Default test types
      const defaultTestTypes = [
        { id: 'test-001', name: 'Compression Test', description: '28-day strength test', product_category: 'Construction' },
        { id: 'test-002', name: 'Tensile Test', description: 'Material tensile strength', product_category: 'Materials' },
        { id: 'test-003', name: 'Density Test', description: 'Material density measurement', product_category: 'Road Construction' },
        { id: 'test-004', name: 'Chemical Analysis', description: 'Chemical composition', product_category: 'Materials' }
      ];

      for (const testType of defaultTestTypes) {
        await window.electronAPI.dbRun(
          'INSERT OR IGNORE INTO test_types (id, name, description, product_category) VALUES (?, ?, ?, ?)',
          [testType.id, testType.name, testType.description, testType.product_category]
        );
      }

      // Default officers
      const defaultOfficers = [
        { id: 'officer-001', name: 'John Smith', role: 'Lab Manager', department: 'Quality Control', lab_site_id: 'site-001' },
        { id: 'officer-002', name: 'Jane Doe', role: 'Lab Technician', department: 'Testing', lab_site_id: 'site-001' },
        { id: 'officer-003', name: 'Mike Johnson', role: 'Senior Technician', department: 'Research', lab_site_id: 'site-002' },
        { id: 'officer-004', name: 'Sarah Wilson', role: 'Quality Officer', department: 'Quality Control', lab_site_id: 'site-003' }
      ];

      for (const officer of defaultOfficers) {
        await window.electronAPI.dbRun(
          'INSERT OR IGNORE INTO officers (id, name, role, department, lab_site_id) VALUES (?, ?, ?, ?, ?)',
          [officer.id, officer.name, officer.role, officer.department, officer.lab_site_id]
        );
      }

    } catch (error) {
      console.error('Failed to insert default data:', error);
    }
  }

  // Get all pending test requests with details
  static async getPendingTestRequests(): Promise<any[]> {
    if (!window.electronAPI) return [];

    try {
      const result = await window.electronAPI.dbQuery(`
        SELECT 
          tr.id,
          tr.memo_id,
          tr.production_id,
          tr.test_type_id,
          tr.status,
          tr.assigned_to,
          tr.priority,
          tr.due_date,
          tr.created_at,
          m.title as memo_title,
          m.created_at as memo_date,
          mp.production_date,
          mp.machine,
          mp.samples_count,
          mp.batch_number,
          p.name as product_name,
          p.category as product_category,
          tt.name as test_type_name,
          tt.description as test_description,
          ls.name as lab_site_name,
          o.name as officer_name
        FROM test_requests tr
        LEFT JOIN memos m ON tr.memo_id = m.id
        LEFT JOIN memo_productions mp ON tr.production_id = mp.id
        LEFT JOIN products p ON mp.product_id = p.id
        LEFT JOIN test_types tt ON tr.test_type_id = tt.id
        LEFT JOIN lab_sites ls ON m.lab_site_id = ls.id
        LEFT JOIN officers o ON tr.assigned_to = o.id
        WHERE tr.status IN ('pending', 'in_progress')
        ORDER BY tr.priority DESC, tr.created_at ASC
      `);

      return result.success ? result.data : [];
    } catch (error) {
      console.error('Failed to get pending test requests:', error);
      return [];
    }
  }

  // Update test request status
  static async updateTestRequestStatus(id: string, status: string, assignedTo?: string): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      const updates = ['status = ?', 'updated_at = ?'];
      const values = [status, new Date().toISOString()];

      if (assignedTo) {
        updates.push('assigned_to = ?');
        values.push(assignedTo);
      }

      const result = await window.electronAPI.dbRun(
        `UPDATE test_requests SET ${updates.join(', ')} WHERE id = ?`,
        [...values, id]
      );

      return result.success;
    } catch (error) {
      console.error('Failed to update test request status:', error);
      return false;
    }
  }

  // Submit test results
  static async submitTestResults(data: {
    testRequestId: string;
    memoId: string;
    productionId: string;
    testTypeId: string;
    officerId: string;
    results: any;
    status: 'pass' | 'fail';
    notes?: string;
  }): Promise<boolean> {
    if (!window.electronAPI) return false;

    try {
      // Insert test results
      const resultId = `result-${Date.now()}`;
      const testResult = await window.electronAPI.dbRun(`
        INSERT INTO test_results 
        (id, memo_id, production_id, test_type_id, officer_id, test_date, results, status, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        resultId,
        data.memoId,
        data.productionId,
        data.testTypeId,
        data.officerId,
        new Date().toISOString(),
        JSON.stringify(data.results),
        data.status,
        data.notes || ''
      ]);

      if (!testResult.success) {
        return false;
      }

      // Update test request status to completed
      const requestUpdate = await window.electronAPI.dbRun(
        'UPDATE test_requests SET status = ?, updated_at = ? WHERE id = ?',
        ['completed', new Date().toISOString(), data.testRequestId]
      );

      return requestUpdate.success;
    } catch (error) {
      console.error('Failed to submit test results:', error);
      return false;
    }
  }

  // Get filter options
  static async getFilterOptions(): Promise<{
    labSites: any[];
    productCategories: any[];
    testTypes: any[];
    officers: any[];
  }> {
    if (!window.electronAPI) return { labSites: [], productCategories: [], testTypes: [], officers: [] };

    try {
      const [labSitesResult, productsResult, testTypesResult, officersResult] = await Promise.all([
        window.electronAPI.dbQuery('SELECT * FROM lab_sites WHERE active = 1'),
        window.electronAPI.dbQuery('SELECT DISTINCT category FROM products WHERE active = 1'),
        window.electronAPI.dbQuery('SELECT * FROM test_types WHERE active = 1'),
        window.electronAPI.dbQuery('SELECT * FROM officers WHERE active = 1')
      ]);

      return {
        labSites: labSitesResult.success ? labSitesResult.data : [],
        productCategories: productsResult.success ? productsResult.data : [],
        testTypes: testTypesResult.success ? testTypesResult.data : [],
        officers: officersResult.success ? officersResult.data : []
      };
    } catch (error) {
      console.error('Failed to get filter options:', error);
      return { labSites: [], productCategories: [], testTypes: [], officers: [] };
    }
  }

  // Method to create test requests from memo data (when needed)
  static async createTestRequestsFromMemo(memoId: string, productions: any[]): Promise<void> {
    if (!window.electronAPI) return;

    try {
      const testTypes = await window.electronAPI.dbQuery('SELECT id FROM test_types WHERE active = 1');
      if (!testTypes.success || !testTypes.data.length) return;

      for (const production of productions) {
        // Create test request for each production
        const testRequestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const randomTestType = testTypes.data[Math.floor(Math.random() * testTypes.data.length)];
        
        await window.electronAPI.dbRun(`
          INSERT OR IGNORE INTO test_requests 
          (id, memo_id, production_id, test_type_id, status, priority)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [
          testRequestId,
          memoId,
          production.id,
          randomTestType.id,
          'pending',
          'medium'
        ]);
      }

      console.log('Test requests created from memo data');
    } catch (error) {
      console.error('Failed to create test requests from memo:', error);
    }
  }
}