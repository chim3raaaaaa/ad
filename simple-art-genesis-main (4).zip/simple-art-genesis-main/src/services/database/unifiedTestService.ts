// Unified test service to replace separate test data systems
import { v4 as uuidv4 } from 'uuid';

export interface UnifiedTestEntry {
  id: string;
  plant_id: string;
  product_type_id: string;
  memo_id?: string;
  officer_id: string;
  test_date: string;
  status: 'draft' | 'completed' | 'approved' | 'rejected';
  notes?: string;
  grading_conformity?: 'pass' | 'fail' | 'pending';
  cleanliness_conformity?: 'pass' | 'fail' | 'pending';
  test_data: Record<string, any>; // JSON fallback
  created_by: string;
  updated_by: string;
  created_at: string;
  updated_at: string;
}

export class UnifiedTestService {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;

  // Create unified schema
  async initializeUnifiedSchema(): Promise<void> {
    if (!this.isElectron) return;

    const createTestEntriesTable = `
      CREATE TABLE IF NOT EXISTS test_entries (
        id TEXT PRIMARY KEY,
        plant_id TEXT NOT NULL,
        product_type_id TEXT NOT NULL,
        memo_id TEXT,
        officer_id TEXT NOT NULL,
        test_date TEXT NOT NULL,
        status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'completed', 'approved', 'rejected')),
        notes TEXT,
        grading_conformity TEXT CHECK (grading_conformity IN ('pass', 'fail', 'pending')),
        cleanliness_conformity TEXT CHECK (cleanliness_conformity IN ('pass', 'fail', 'pending')),
        test_data TEXT DEFAULT '{}',
        created_by TEXT NOT NULL,
        updated_by TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (plant_id) REFERENCES plants(id),
        FOREIGN KEY (product_type_id) REFERENCES product_types(id),
        FOREIGN KEY (memo_id) REFERENCES memos(id),
        FOREIGN KEY (officer_id) REFERENCES officers(id)
      )
    `;

    await (window as any).electronAPI.dbRun(createTestEntriesTable);
    
    // Create indexes for performance
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_test_entries_plant ON test_entries(plant_id)',
      'CREATE INDEX IF NOT EXISTS idx_test_entries_product_type ON test_entries(product_type_id)', 
      'CREATE INDEX IF NOT EXISTS idx_test_entries_memo ON test_entries(memo_id)',
      'CREATE INDEX IF NOT EXISTS idx_test_entries_date ON test_entries(test_date)',
      'CREATE INDEX IF NOT EXISTS idx_test_entries_status ON test_entries(status)'
    ];

    for (const sql of indexes) {
      await (window as any).electronAPI.dbRun(sql);
    }
  }

  // Create test entry with dynamic data structure
  async createTestEntry(entry: Omit<UnifiedTestEntry, 'id' | 'created_at' | 'updated_at'>): Promise<UnifiedTestEntry> {
    const now = new Date().toISOString();
    const newEntry: UnifiedTestEntry = {
      ...entry,
      id: uuidv4(),
      created_at: now,
      updated_at: now
    };

    if (this.isElectron) {
      await (window as any).electronAPI.dbRun(
        `INSERT INTO test_entries (
          id, plant_id, product_type_id, memo_id, officer_id, test_date, 
          status, notes, grading_conformity, cleanliness_conformity, 
          test_data, created_by, updated_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          newEntry.id, newEntry.plant_id, newEntry.product_type_id, 
          newEntry.memo_id, newEntry.officer_id, newEntry.test_date,
          newEntry.status, newEntry.notes, newEntry.grading_conformity,
          newEntry.cleanliness_conformity, JSON.stringify(newEntry.test_data),
          newEntry.created_by, newEntry.updated_by, newEntry.created_at, newEntry.updated_at
        ]
      );

      // Save to product-specific table if exists
      await this.saveToProductTable(newEntry);
    }

    return newEntry;
  }

  // Get test entries with filtering
  async getTestEntries(filters: {
    plant_id?: string;
    product_type_id?: string;
    memo_id?: string;
    status?: string;
    date_from?: string;
    date_to?: string;
    search?: string;
  } = {}): Promise<UnifiedTestEntry[]> {
    if (!this.isElectron) return [];

    let sql = 'SELECT * FROM test_entries WHERE 1=1';
    const params: any[] = [];

    if (filters.plant_id) {
      sql += ' AND plant_id = ?';
      params.push(filters.plant_id);
    }

    if (filters.product_type_id) {
      sql += ' AND product_type_id = ?';
      params.push(filters.product_type_id);
    }

    if (filters.memo_id) {
      sql += ' AND memo_id = ?';
      params.push(filters.memo_id);
    }

    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }

    if (filters.date_from) {
      sql += ' AND test_date >= ?';
      params.push(filters.date_from);
    }

    if (filters.date_to) {
      sql += ' AND test_date <= ?';
      params.push(filters.date_to);
    }

    if (filters.search) {
      sql += ' AND (notes LIKE ? OR test_data LIKE ?)';
      params.push(`%${filters.search}%`, `%${filters.search}%`);
    }

    sql += ' ORDER BY test_date DESC, created_at DESC';

    const results = await (window as any).electronAPI.dbQuery(sql, params);
    return results.map((row: any) => ({
      ...row,
      test_data: JSON.parse(row.test_data || '{}')
    }));
  }

  // Save to product-specific table for structured data
  private async saveToProductTable(entry: UnifiedTestEntry): Promise<void> {
    const tableName = `test_data_${entry.product_type_id}`;
    
    try {
      // Check if product-specific table exists
      const tableExists = await (window as any).electronAPI.dbQuery(
        `SELECT name FROM sqlite_master WHERE type='table' AND name=?`,
        [tableName]
      );

      if (tableExists.length > 0) {
        // Save structured data to product table
        const dataWithId = {
          test_entry_id: entry.id,
          ...entry.test_data
        };

        const columns = Object.keys(dataWithId);
        const placeholders = columns.map(() => '?').join(', ');
        const values = Object.values(dataWithId);

        await (window as any).electronAPI.dbRun(
          `INSERT OR REPLACE INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders})`,
          values
        );
      }
    } catch (error) {
      console.warn(`Failed to save to product table ${tableName}:`, error);
      // Continue without product-specific table
    }
  }

  // Delete test entry
  async deleteTestEntry(id: string): Promise<void> {
    if (this.isElectron) {
      await (window as any).electronAPI.dbRun('DELETE FROM test_entries WHERE id = ?', [id]);
    }
    // Browser implementation would handle localStorage
  }
}

export const unifiedTestService = new UnifiedTestService();