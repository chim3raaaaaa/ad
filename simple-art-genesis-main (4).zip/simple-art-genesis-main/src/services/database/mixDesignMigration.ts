// Mix Design Migration Service - Handles migration from old schema to new unified system
// Phase 1: Migration utilities
// Created: 2025-01-31

import { mixDesignService } from './mixDesignService';

interface LegacyMixDesign {
  id: string;
  name: string;
  product_type: string; // String instead of FK
  design_data: any;
  created_by: string;
  created_at: string;
}

interface LegacyTemplate {
  id: string;
  name: string;
  product_type: string;
  template_data: any;
  created_by: string;
}

class MixDesignMigrationService {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;

  // Check if old tables exist
  async hasLegacyTables(): Promise<boolean> {
    if (!this.isElectron) return false;

    try {
      const result = await (window as any).electronAPI.dbQuery(`
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name IN ('mix_designs_old', 'mix_design_templates_old')
      `);
      return result.length > 0;
    } catch {
      return false;
    }
  }

  // Backup existing data before migration
  async backupLegacyData(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Rename existing tables to backup versions
      await (window as any).electronAPI.dbRun(`
        ALTER TABLE mix_designs RENAME TO mix_designs_backup_${Date.now()}
      `);
      
      await (window as any).electronAPI.dbRun(`
        ALTER TABLE mix_design_templates RENAME TO mix_design_templates_backup_${Date.now()}
      `);

      console.log('Legacy mix design data backed up successfully');
    } catch (error) {
      console.warn('No legacy tables to backup:', error);
    }
  }

  // Migrate legacy mix designs to new schema
  async migrateLegacyMixDesigns(): Promise<{ migrated: number; errors: string[] }> {
    if (!this.isElectron) {
      return { migrated: 0, errors: ['Migration only supported in Electron environment'] };
    }

    let migrated = 0;
    const errors: string[] = [];

    try {
      // Get legacy mix designs
      const legacyDesigns = await this.getLegacyMixDesigns();
      
      for (const legacy of legacyDesigns) {
        try {
          // Find or create product type
          const productTypeId = await this.findOrCreateProductType(legacy.product_type);
          
          // Migrate the design
          await mixDesignService.createMixDesign({
            name: legacy.name,
            product_type_id: productTypeId,
            design_data: JSON.stringify(legacy.design_data),
            status: 'active',
            created_by: legacy.created_by || 'migration',
            is_template: false,
            version_number: 1,
            description: `Migrated from legacy system on ${new Date().toISOString()}`
          });
          
          migrated++;
        } catch (error) {
          errors.push(`Failed to migrate design ${legacy.name}: ${error}`);
        }
      }

      // Migrate templates
      const legacyTemplates = await this.getLegacyTemplates();
      
      for (const legacy of legacyTemplates) {
        try {
          const productTypeId = await this.findOrCreateProductType(legacy.product_type);
          
          await mixDesignService.createMixDesignTemplate({
            name: legacy.name,
            product_type_id: productTypeId,
            template_data: JSON.stringify(legacy.template_data),
            is_public: true,
            created_by: legacy.created_by || 'migration',
            usage_count: 0,
            description: `Migrated template from legacy system`
          });
          
          migrated++;
        } catch (error) {
          errors.push(`Failed to migrate template ${legacy.name}: ${error}`);
        }
      }

    } catch (error) {
      errors.push(`Migration failed: ${error}`);
    }

    return { migrated, errors };
  }

  private async getLegacyMixDesigns(): Promise<LegacyMixDesign[]> {
    try {
      // Try different possible legacy table names
      const tableNames = ['mix_designs_old', 'mix_designs_backup', 'mix_designs_legacy'];
      
      for (const tableName of tableNames) {
        try {
          const result = await (window as any).electronAPI.dbQuery(`
            SELECT * FROM ${tableName} ORDER BY created_at
          `);
          if (result.length > 0) {
            return result;
          }
        } catch {
          // Table doesn't exist, try next
          continue;
        }
      }
      
      return [];
    } catch {
      return [];
    }
  }

  private async getLegacyTemplates(): Promise<LegacyTemplate[]> {
    try {
      const tableNames = ['mix_design_templates_old', 'mix_design_templates_backup', 'mix_design_templates_legacy'];
      
      for (const tableName of tableNames) {
        try {
          const result = await (window as any).electronAPI.dbQuery(`
            SELECT * FROM ${tableName} ORDER BY name
          `);
          if (result.length > 0) {
            return result;
          }
        } catch {
          continue;
        }
      }
      
      return [];
    } catch {
      return [];
    }
  }

  private async findOrCreateProductType(productTypeName: string): Promise<string> {
    // Clean up the product type name
    const cleanName = productTypeName.trim();
    
    // Try to find existing product type
    const existingTypes = await mixDesignService.getProductTypes();
    const existing = existingTypes.find(pt => 
      pt.name.toLowerCase() === cleanName.toLowerCase()
    );
    
    if (existing) {
      return existing.id;
    }

    // Create new product type based on name
    const category = this.guessProductCategory(cleanName);
    
    return await mixDesignService.createProductType({
      name: cleanName,
      category,
      description: `Migrated product type from legacy system`,
      is_active: true
    });
  }

  private guessProductCategory(productName: string): string {
    const name = productName.toLowerCase();
    
    if (name.includes('concrete') || name.includes('cement')) {
      return 'Concrete';
    } else if (name.includes('asphalt') || name.includes('bitumen')) {
      return 'Asphalt';
    } else if (name.includes('mortar') || name.includes('plaster')) {
      return 'Mortar';
    } else if (name.includes('aggregate') || name.includes('stone')) {
      return 'Aggregate';
    } else {
      return 'Other';
    }
  }

  // Create default field definitions for migrated product types
  async createDefaultFieldsForProductType(productTypeId: string, productName: string): Promise<void> {
    const name = productName.toLowerCase();
    
    if (name.includes('concrete')) {
      await this.createConcreteFields(productTypeId);
    } else if (name.includes('asphalt')) {
      await this.createAsphaltFields(productTypeId);
    } else if (name.includes('mortar')) {
      await this.createMortarFields(productTypeId);
    } else {
      await this.createGenericFields(productTypeId);
    }
  }

  private async createConcreteFields(productTypeId: string): Promise<void> {
    const fields = [
      { name: 'cement_content', label: 'Cement Content', type: 'number', unit: 'kg/m³', required: true, order: 1 },
      { name: 'water_content', label: 'Water Content', type: 'number', unit: 'kg/m³', required: true, order: 2 },
      { name: 'fine_aggregate', label: 'Fine Aggregate', type: 'number', unit: 'kg/m³', required: true, order: 3 },
      { name: 'coarse_aggregate', label: 'Coarse Aggregate', type: 'number', unit: 'kg/m³', required: true, order: 4 },
      { name: 'water_cement_ratio', label: 'W/C Ratio', type: 'number', unit: '', required: true, order: 5 },
      { name: 'target_strength', label: 'Target Strength', type: 'number', unit: 'MPa', required: true, order: 6 }
    ];

    for (const field of fields) {
      await mixDesignService.createMixDesignField({
        product_type_id: productTypeId,
        field_name: field.name,
        field_label: field.label,
        field_type: field.type as any,
        field_unit: field.unit,
        is_required: field.required,
        display_order: field.order,
        is_active: true,
        validation_rules: field.type === 'number' ? '{"min": 0}' : undefined
      });
    }
  }

  private async createAsphaltFields(productTypeId: string): Promise<void> {
    const fields = [
      { name: 'binder_content', label: 'Binder Content', type: 'number', unit: '%', required: true, order: 1 },
      { name: 'aggregate_grading', label: 'Aggregate Grading', type: 'textarea', unit: '', required: true, order: 2 },
      { name: 'mixing_temp', label: 'Mixing Temperature', type: 'number', unit: '°C', required: true, order: 3 }
    ];

    for (const field of fields) {
      await mixDesignService.createMixDesignField({
        product_type_id: productTypeId,
        field_name: field.name,
        field_label: field.label,
        field_type: field.type as any,
        field_unit: field.unit,
        is_required: field.required,
        display_order: field.order,
        is_active: true,
        validation_rules: field.type === 'number' ? '{"min": 0}' : undefined
      });
    }
  }

  private async createMortarFields(productTypeId: string): Promise<void> {
    const fields = [
      { name: 'cement_content', label: 'Cement Content', type: 'number', unit: 'kg/m³', required: true, order: 1 },
      { name: 'sand_content', label: 'Sand Content', type: 'number', unit: 'kg/m³', required: true, order: 2 },
      { name: 'water_content', label: 'Water Content', type: 'number', unit: 'kg/m³', required: true, order: 3 }
    ];

    for (const field of fields) {
      await mixDesignService.createMixDesignField({
        product_type_id: productTypeId,
        field_name: field.name,
        field_label: field.label,
        field_type: field.type as any,
        field_unit: field.unit,
        is_required: field.required,
        display_order: field.order,
        is_active: true,
        validation_rules: field.type === 'number' ? '{"min": 0}' : undefined
      });
    }
  }

  private async createGenericFields(productTypeId: string): Promise<void> {
    const fields = [
      { name: 'description', label: 'Description', type: 'textarea', unit: '', required: true, order: 1 },
      { name: 'specification', label: 'Specification', type: 'text', unit: '', required: false, order: 2 }
    ];

    for (const field of fields) {
      await mixDesignService.createMixDesignField({
        product_type_id: productTypeId,
        field_name: field.name,
        field_label: field.label,
        field_type: field.type as any,
        field_unit: field.unit,
        is_required: field.required,
        display_order: field.order,
        is_active: true,
        validation_rules: undefined
      });
    }
  }

  // Migration status check
  async getMigrationStatus(): Promise<{
    hasLegacyData: boolean;
    newSchemaExists: boolean;
    migrationComplete: boolean;
  }> {
    const hasLegacyData = await this.hasLegacyTables();
    
    let newSchemaExists = false;
    let migrationComplete = false;
    
    try {
      const productTypes = await mixDesignService.getProductTypes();
      newSchemaExists = true;
      migrationComplete = productTypes.length > 0;
    } catch {
      newSchemaExists = false;
    }

    return {
      hasLegacyData,
      newSchemaExists,
      migrationComplete
    };
  }
}

export const mixDesignMigrationService = new MixDesignMigrationService();