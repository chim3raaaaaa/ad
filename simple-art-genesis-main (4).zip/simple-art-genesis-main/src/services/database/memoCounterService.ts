// Database service for managing memo reference counters
export class MemoCounterService {
  // Initialize memo counter table if it doesn't exist
  static async initializeCounterTable(): Promise<void> {
    if (!window.electronAPI) return;

    try {
      await window.electronAPI.dbRun(`
        CREATE TABLE IF NOT EXISTS memo_counters (
          date_key TEXT PRIMARY KEY,
          counter INTEGER NOT NULL DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      
      console.log('Memo counter table initialized');
    } catch (error) {
      console.error('Failed to initialize memo counter table:', error);
    }
  }

  // Get next counter for a specific date key (atomic operation)
  static async getNextCounter(dateKey: string): Promise<number> {
    if (!window.electronAPI) {
      throw new Error('Electron API not available');
    }

    try {
      // Use INSERT ... ON CONFLICT for atomic increment
      const result = await window.electronAPI.dbRun(
        `INSERT INTO memo_counters (date_key, counter, updated_at) 
         VALUES (?, 1, CURRENT_TIMESTAMP) 
         ON CONFLICT(date_key) 
         DO UPDATE SET 
           counter = counter + 1,
           updated_at = CURRENT_TIMESTAMP
         RETURNING counter`,
        [dateKey]
      );

      if (result.success && result.data?.counter) {
        return result.data.counter;
      }

      // Fallback: manual query and increment
      const currentResult = await window.electronAPI.dbQuery(
        'SELECT counter FROM memo_counters WHERE date_key = ?',
        [dateKey]
      );

      if (currentResult.success && currentResult.data.length > 0) {
        const newCounter = currentResult.data[0].counter + 1;
        await window.electronAPI.dbRun(
          'UPDATE memo_counters SET counter = ?, updated_at = CURRENT_TIMESTAMP WHERE date_key = ?',
          [newCounter, dateKey]
        );
        return newCounter;
      } else {
        // First time for this date
        await window.electronAPI.dbRun(
          'INSERT INTO memo_counters (date_key, counter) VALUES (?, 1)',
          [dateKey]
        );
        return 1;
      }
    } catch (error) {
      console.error('Failed to get next counter:', error);
      throw new Error('Failed to generate counter');
    }
  }

  // Reset counter for testing (dev only)
  static async resetCounter(dateKey: string): Promise<void> {
    if (!window.electronAPI) return;

    try {
      await window.electronAPI.dbRun(
        'UPDATE memo_counters SET counter = 0 WHERE date_key = ?',
        [dateKey]
      );
    } catch (error) {
      console.error('Failed to reset counter:', error);
    }
  }
}