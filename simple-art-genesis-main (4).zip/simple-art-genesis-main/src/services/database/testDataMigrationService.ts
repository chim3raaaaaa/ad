// Data migration service to move existing test data to unified schema
import { unifiedTestService } from './unifiedTestService';
import { TestModulesAPI } from '@/services/api/testModulesAPI';

export interface MigrationResult {
  success: boolean;
  migrated: number;
  errors: string[];
  warnings: string[];
  tablesMigrated: string[];
}

export class TestDataMigrationService {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;

  // Main migration function
  async migrateAllTestData(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      migrated: 0,
      errors: [],
      warnings: [],
      tablesMigrated: []
    };

    if (!this.isElectron) {
      result.errors.push('Migration only supported in Electron environment');
      result.success = false;
      return result;
    }

    try {
      // Initialize unified schema first
      await unifiedTestService.initializeUnifiedSchema();

      // Backup existing data
      await this.createBackup();

      // Migrate aggregate tests
      const aggregateResult = await this.migrateAggregateTests();
      result.migrated += aggregateResult.migrated;
      result.errors.push(...aggregateResult.errors);
      result.warnings.push(...aggregateResult.warnings);
      result.tablesMigrated.push(...aggregateResult.tablesMigrated);

      // Migrate concrete tests
      const concreteResult = await this.migrateConcreteTests();
      result.migrated += concreteResult.migrated;
      result.errors.push(...concreteResult.errors);
      result.warnings.push(...concreteResult.warnings);
      result.tablesMigrated.push(...concreteResult.tablesMigrated);

      // Migrate test_entries from Test Modules if exists
      const testEntriesResult = await this.migrateTestModulesEntries();
      result.migrated += testEntriesResult.migrated;
      result.errors.push(...testEntriesResult.errors);
      result.warnings.push(...testEntriesResult.warnings);

      result.success = result.errors.length === 0;

    } catch (error) {
      result.success = false;
      result.errors.push(`Migration failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  // Migrate aggregate_tests and plant-specific aggregate tables
  private async migrateAggregateTests(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      migrated: 0,
      errors: [],
      warnings: [],
      tablesMigrated: []
    };

    try {
      // Get all aggregate test tables
      const tables = await (window as any).electronAPI.dbQuery(
        `SELECT name FROM sqlite_master WHERE type='table' AND (name = 'aggregate_tests' OR name LIKE '%_aggregate_tests' OR name LIKE 'aggregate_tests_%')`
      );

      for (const table of tables) {
        const tableName = table.name;
        console.log(`Migrating table: ${tableName}`);

        try {
          // Get all records from this table
          const records = await (window as any).electronAPI.dbQuery(`SELECT * FROM ${tableName}`);
          
          for (const record of records) {
            const unifiedEntry = await this.mapAggregateToUnified(record, tableName);
            if (unifiedEntry) {
              await unifiedTestService.createTestEntry(unifiedEntry);
              result.migrated++;
            }
          }

          result.tablesMigrated.push(tableName);
          
          // Rename old table instead of dropping
          const backupTableName = `${tableName}_migrated_backup`;
          await (window as any).electronAPI.dbRun(
            `ALTER TABLE ${tableName} RENAME TO ${backupTableName}`
          );

        } catch (error) {
          result.errors.push(`Failed to migrate table ${tableName}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

    } catch (error) {
      result.errors.push(`Failed to migrate aggregate tests: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  // Migrate concrete_tests tables
  private async migrateConcreteTests(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      migrated: 0,
      errors: [],
      warnings: [],
      tablesMigrated: []
    };

    try {
      // Get all concrete test tables
      const tables = await (window as any).electronAPI.dbQuery(
        `SELECT name FROM sqlite_master WHERE type='table' AND (name = 'concrete_tests' OR name LIKE '%_concrete_tests' OR name LIKE 'concrete_tests_%')`
      );

      for (const table of tables) {
        const tableName = table.name;
        console.log(`Migrating table: ${tableName}`);

        try {
          const records = await (window as any).electronAPI.dbQuery(`SELECT * FROM ${tableName}`);
          
          for (const record of records) {
            const unifiedEntry = await this.mapConcreteToUnified(record, tableName);
            if (unifiedEntry) {
              await unifiedTestService.createTestEntry(unifiedEntry);
              result.migrated++;
            }
          }

          result.tablesMigrated.push(tableName);
          
          // Rename old table
          const backupTableName = `${tableName}_migrated_backup`;
          await (window as any).electronAPI.dbRun(
            `ALTER TABLE ${tableName} RENAME TO ${backupTableName}`
          );

        } catch (error) {
          result.errors.push(`Failed to migrate table ${tableName}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

    } catch (error) {
      result.errors.push(`Failed to migrate concrete tests: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  // Migrate existing test_entries from Test Modules
  private async migrateTestModulesEntries(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      migrated: 0,
      errors: [],
      warnings: [],
      tablesMigrated: []
    };

    try {
      // Check if old test_entries table exists
      const existingTable = await (window as any).electronAPI.dbQuery(
        `SELECT name FROM sqlite_master WHERE type='table' AND name='test_entries_old'`
      );

      if (existingTable.length === 0) {
        // Rename current test_entries to test_entries_old if it exists
        const currentTable = await (window as any).electronAPI.dbQuery(
          `SELECT name FROM sqlite_master WHERE type='table' AND name='test_entries'`
        );

        if (currentTable.length > 0) {
          await (window as any).electronAPI.dbRun(
            `ALTER TABLE test_entries RENAME TO test_entries_old`
          );
        }
      }

      // Now migrate from test_entries_old
      const oldEntries = await (window as any).electronAPI.dbQuery(
        `SELECT * FROM test_entries_old`
      ).catch(() => []);

      for (const entry of oldEntries) {
        try {
          // Map old test_entries structure to new unified structure
          const unifiedEntry = {
            plant_id: entry.plant_id || 'unknown',
            product_type_id: entry.product_type_id || 'unknown',
            memo_id: entry.memo_id,
            officer_id: entry.officer_id || 'unknown',
            test_date: entry.test_date || new Date().toISOString(),
            status: entry.status || 'draft',
            notes: entry.notes,
            test_data: JSON.parse(entry.test_data || '{}'),
            created_by: entry.created_by || 'migration',
            updated_by: entry.updated_by || 'migration'
          };

          await unifiedTestService.createTestEntry(unifiedEntry);
          result.migrated++;
        } catch (error) {
          result.errors.push(`Failed to migrate test entry ${entry.id}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

      if (oldEntries.length > 0) {
        result.tablesMigrated.push('test_entries_old');
      }

    } catch (error) {
      result.warnings.push(`Could not migrate test modules entries: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  // Map aggregate test record to unified format
  private async mapAggregateToUnified(record: any, tableName: string): Promise<any | null> {
    try {
      // Extract plant from table name or record
      let plantId = record.plant_id || 'unknown';
      if (tableName.includes('_')) {
        const parts = tableName.split('_');
        if (parts.length > 1) {
          plantId = parts[1] || plantId;
        }
      }

      // Get or create aggregate product type
      const productTypeId = await this.getOrCreateProductType('aggregates', record.aggregate_type_id || 'fine_aggregate');

      // Map sieve data to test_data JSON
      const testData: any = {
        // Physical properties
        moisture_content: record.moisture_content,
        sand_equivalent: record.sand_equivalent,
        fineness_modulus: record.fineness_modulus,
        methylene_blue: record.methylene_blue,
        
        // Sieve analysis data
        sieve_data: {}
      };

      // Extract sieve percentages
      const sieveFields = [
        'sieve_0_075', 'sieve_0_15', 'sieve_0_3', 'sieve_0_6', 'sieve_1_18',
        'sieve_2_36', 'sieve_5', 'sieve_10', 'sieve_14', 'sieve_16',
        'sieve_20', 'sieve_31_5', 'sieve_37_5', 'sieve_45', 'sieve_50', 'sieve_63'
      ];

      sieveFields.forEach(field => {
        if (record[field] !== undefined && record[field] !== null) {
          testData.sieve_data[field] = record[field];
        }
      });

      return {
        plant_id: plantId,
        product_type_id: productTypeId,
        memo_id: record.memo_id,
        officer_id: record.officer_id || 'unknown',
        test_date: record.test_date || record.created_at || new Date().toISOString(),
        status: record.status || 'completed',
        notes: record.notes,
        grading_conformity: record.grading_conformity,
        cleanliness_conformity: record.cleanliness_conformity,
        test_data: testData,
        created_by: record.created_by || 'migration',
        updated_by: record.updated_by || 'migration'
      };

    } catch (error) {
      console.error('Failed to map aggregate record:', error);
      return null;
    }
  }

  // Map concrete test record to unified format
  private async mapConcreteToUnified(record: any, tableName: string): Promise<any | null> {
    try {
      // Extract plant from table name or record
      let plantId = record.plant_id || 'unknown';
      if (tableName.includes('_')) {
        const parts = tableName.split('_');
        if (parts.length > 1) {
          plantId = parts[1] || plantId;
        }
      }

      // Get or create concrete product type
      const productTypeId = await this.getOrCreateProductType('concrete', record.product_type || 'concrete_cube');

      const testData: any = {
        // Concrete specific fields
        strength_grade: record.strength_grade,
        slump_value: record.slump_value,
        air_content: record.air_content,
        temperature: record.temperature,
        
        // Test results
        compressive_strength_7d: record.compressive_strength_7d,
        compressive_strength_28d: record.compressive_strength_28d,
        
        // Mix details
        water_cement_ratio: record.water_cement_ratio,
        cement_content: record.cement_content,
        aggregate_content: record.aggregate_content,
        
        // Specimen details
        specimen_id: record.specimen_id,
        casting_date: record.casting_date,
        testing_date: record.testing_date
      };

      return {
        plant_id: plantId,
        product_type_id: productTypeId,
        memo_id: record.memo_id,
        officer_id: record.officer_id || record.operator_name || 'unknown',
        test_date: record.test_date || record.testing_date || record.created_at || new Date().toISOString(),
        status: record.status || 'completed',
        notes: record.notes || record.remarks,
        test_data: testData,
        created_by: record.created_by || record.operator_name || 'migration',
        updated_by: record.updated_by || record.operator_name || 'migration'
      };

    } catch (error) {
      console.error('Failed to map concrete record:', error);
      return null;
    }
  }

  // Get or create product type for migration
  private async getOrCreateProductType(category: string, typeId: string): Promise<string> {
    try {
      // Try to find existing product type
      const productTypes = await TestModulesAPI.getProductTypes();
      const existing = productTypes.find(pt => 
        pt.name.toLowerCase().includes(typeId.toLowerCase()) || 
        pt.id === typeId
      );

      if (existing) {
        return existing.id;
      }

      // Create new product type for migration
      const newProductType = {
        name: `Migrated ${typeId}`,
        category_id: 'migration',
        table_suffix: typeId.toLowerCase(),
        description: `Auto-created during migration for ${typeId}`,
        is_active: true,
        created_by: 'migration'
      };

      const created = await TestModulesAPI.createProductType(newProductType);
      return created || typeId;

    } catch (error) {
      console.warn(`Could not create product type for ${typeId}, using default`);
      return typeId;
    }
  }

  // Create backup before migration
  private async createBackup(): Promise<void> {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = `backup_before_migration_${timestamp}.db`;
      
      // This would be handled by the main Electron process
      console.log(`Creating backup at: ${backupPath}`);
      
    } catch (error) {
      console.warn('Could not create backup:', error);
    }
  }

  // Rollback migration if needed
  async rollbackMigration(): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      migrated: 0,
      errors: [],
      warnings: [],
      tablesMigrated: []
    };

    try {
      // Find all backup tables
      const backupTables = await (window as any).electronAPI.dbQuery(
        `SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%_migrated_backup'`
      );

      for (const table of backupTables) {
        const originalName = table.name.replace('_migrated_backup', '');
        
        try {
          // Drop current table if exists
          await (window as any).electronAPI.dbRun(`DROP TABLE IF EXISTS ${originalName}`);
          
          // Restore from backup
          await (window as any).electronAPI.dbRun(
            `ALTER TABLE ${table.name} RENAME TO ${originalName}`
          );
          
          result.tablesMigrated.push(originalName);
        } catch (error) {
          result.errors.push(`Failed to rollback table ${originalName}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

      // Drop unified test_entries table
      await (window as any).electronAPI.dbRun(`DROP TABLE IF EXISTS test_entries`);

    } catch (error) {
      result.success = false;
      result.errors.push(`Rollback failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }
}

export const testDataMigrationService = new TestDataMigrationService();