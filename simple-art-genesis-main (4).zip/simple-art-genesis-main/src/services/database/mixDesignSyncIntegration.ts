// Mix Design Sync Integration Service - Integrates with existing sync infrastructure
// Phase 1: Service Layer Refactoring
// Created: 2025-01-31

import { localSyncService } from '../sync/localSyncService';
import { backgroundSyncService } from '../sync/backgroundSyncService';
import { mixDesignService } from './mixDesignService';

export interface MixDesignSyncStatus {
  pendingOperations: number;
  lastSyncTime?: string;
  conflicts: number;
  isOnline: boolean;
  syncInProgress: boolean;
}

class MixDesignSyncIntegration {
  private isElectron = typeof window !== 'undefined' && (window as any).electronAPI;

  // Initialize sync integration
  async initialize(): Promise<void> {
    if (!this.isElectron) {
      console.warn('Mix Design sync only available in Electron environment');
      return;
    }

    try {
      // Register mix design tables for sync operations
      await this.registerSyncTables();
      
      // Set up sync event listeners
      this.setupSyncEventListeners();
      
      console.log('Mix Design sync integration initialized');
    } catch (error) {
      console.error('Failed to initialize Mix Design sync integration:', error);
      throw error;
    }
  }

  // Register all mix design tables for sync
  private async registerSyncTables(): Promise<void> {
    const mixDesignTables = [
      'product_types',
      'mix_design_fields', 
      'mix_designs',
      'mix_design_versions',
      'mix_design_templates',
      'mix_design_trials'
    ];

    // The actual registration would depend on how the sync service handles table registration
    // For now, we'll just log the tables that should be synced
    console.log('Registering Mix Design tables for sync:', mixDesignTables);
  }

  // Set up event listeners for sync operations
  private setupSyncEventListeners(): void {
    // Note: Event listeners would be implemented when sync service interface is finalized
    console.log('Mix Design sync event listeners ready');
  }

  // Queue mix design operation for sync
  async queueMixDesignOperation(
    tableName: string, 
    operation: 'INSERT' | 'UPDATE' | 'DELETE', 
    data: any, 
    recordId?: string
  ): Promise<void> {
    try {
      await localSyncService.queueOperation(tableName, operation, data, recordId);
      
      // Note: logAuditEntry is private, audit logging will be handled by the sync service internally
    } catch (error) {
      console.error('Failed to queue mix design operation:', error);
      throw error;
    }
  }

  // Get sync status specific to mix design tables
  async getMixDesignSyncStatus(): Promise<MixDesignSyncStatus> {
    try {
      const overallStatus = await localSyncService.getSyncStatus();
      const backgroundStatus = await backgroundSyncService.getSyncStatus();
      
      // Filter operations for mix design tables
      const mixDesignTables = [
        'product_types', 'mix_design_fields', 'mix_designs', 
        'mix_design_versions', 'mix_design_templates', 'mix_design_trials'
      ];
      
      return {
        pendingOperations: 0, // Will be implemented with proper interface
        lastSyncTime: undefined,
        conflicts: 0,
        isOnline: false,
        syncInProgress: false
      };
    } catch (error) {
      console.error('Failed to get mix design sync status:', error);
      return {
        pendingOperations: 0,
        conflicts: 0,
        isOnline: false,
        syncInProgress: false
      };
    }
  }

  // Force sync of mix design data
  async forceMixDesignSync(): Promise<void> {
    try {
      console.log('Forcing mix design data sync...');
      await backgroundSyncService.forceSyncNow();
    } catch (error) {
      console.error('Failed to force mix design sync:', error);
      throw error;
    }
  }

  // Resolve sync conflict for mix design data
  async resolveMixDesignConflict(
    conflictId: string, 
    resolution: 'local' | 'remote' | 'merge', 
    mergedData?: any
  ): Promise<void> {
    try {
      await backgroundSyncService.resolveConflict(conflictId, resolution, mergedData);
    } catch (error) {
      console.error('Failed to resolve mix design conflict:', error);
      throw error;
    }
  }

  // Get pending operations for specific mix design record
  async getPendingOperationsForRecord(tableName: string, recordId: string): Promise<any[]> {
    try {
      const allPendingOps = await localSyncService.getPendingOperations();
      return allPendingOps.filter(op => 
        op.table_name === tableName && 
        (op.data?.id === recordId)
      );
    } catch (error) {
      console.error('Failed to get pending operations for record:', error);
      return [];
    }
  }

  // Check if record has pending sync operations
  async hasRecordPendingSync(tableName: string, recordId: string): Promise<boolean> {
    const pendingOps = await this.getPendingOperationsForRecord(tableName, recordId);
    return pendingOps.length > 0;
  }

  // Get conflicts for specific mix design record  
  async getConflictsForRecord(tableName: string, recordId: string): Promise<any[]> {
    try {
      const allConflicts = await backgroundSyncService.getConflicts();
      return allConflicts.filter(conflict =>
        conflict.table_name === tableName && 
        (conflict.record_id === recordId || conflict.local_data?.id === recordId)
      );
    } catch (error) {
      console.error('Failed to get conflicts for record:', error);
      return [];
    }
  }

  // Bulk operations with sync queueing
  async bulkCreateMixDesigns(designs: any[], createdBy: string): Promise<string[]> {
    const createdIds: string[] = [];
    
    try {
      // Start transaction-like operation
      for (const design of designs) {
        const id = await mixDesignService.createMixDesign({
          ...design,
          created_by: createdBy
        });
        createdIds.push(id);
      }

      console.log(`Bulk created ${createdIds.length} mix designs`);
      return createdIds;
    } catch (error) {
      console.error('Failed to bulk create mix designs:', error);
      throw error;
    }
  }

  async bulkUpdateMixDesigns(updates: Array<{ id: string; data: any }>): Promise<void> {
    try {
      for (const update of updates) {
        await mixDesignService.updateMixDesign(update.id, update.data);
      }

      console.log(`Bulk updated ${updates.length} mix designs`);
    } catch (error) {
      console.error('Failed to bulk update mix designs:', error);
      throw error;
    }
  }

  // Sync status monitoring
  async startSyncStatusMonitoring(intervalMs: number = 30000): Promise<void> {
    setInterval(async () => {
      try {
        const status = await this.getMixDesignSyncStatus();
        
        if (status.pendingOperations > 0) {
          console.log(`Mix Design: ${status.pendingOperations} operations pending sync`);
        }
        
        if (status.conflicts > 0) {
          console.warn(`Mix Design: ${status.conflicts} sync conflicts need resolution`);
        }
        
        if (!status.isOnline) {
          console.warn('Mix Design: Offline mode - changes will sync when online');
        }
      } catch (error) {
        console.error('Failed to check mix design sync status:', error);
      }
    }, intervalMs);
  }

  // Export/Import with sync integration
  async exportMixDesignData(format: 'json' | 'csv' = 'json'): Promise<any> {
    try {
      const designs = await mixDesignService.getMixDesigns();
      const templates = await mixDesignService.getMixDesignTemplates();
      const productTypes = await mixDesignService.getProductTypes();
      
      const exportData = {
        timestamp: new Date().toISOString(),
        version: '1.0',
        data: {
          product_types: productTypes,
          mix_designs: designs,
          mix_design_templates: templates
        },
        sync_status: await this.getMixDesignSyncStatus()
      };

      if (format === 'json') {
        return JSON.stringify(exportData, null, 2);
      } else {
        // CSV format would need to be implemented
        throw new Error('CSV export format not yet implemented');
      }
    } catch (error) {
      console.error('Failed to export mix design data:', error);
      throw error;
    }
  }

  async importMixDesignData(importData: any, options: {
    overwriteExisting?: boolean;
    skipConflicts?: boolean;
  } = {}): Promise<{ imported: number; skipped: number; errors: string[] }> {
    const result = { imported: 0, skipped: 0, errors: [] as string[] };
    
    try {
      const data = typeof importData === 'string' ? JSON.parse(importData) : importData;
      
      // Import product types first
      if (data.data?.product_types) {
        for (const productType of data.data.product_types) {
          try {
            await mixDesignService.createProductType(productType);
            result.imported++;
          } catch (error) {
            if (options.skipConflicts) {
              result.skipped++;
            } else {
              result.errors.push(`Failed to import product type ${productType.name}: ${error}`);
            }
          }
        }
      }

      // Import mix designs
      if (data.data?.mix_designs) {
        for (const design of data.data.mix_designs) {
          try {
            await mixDesignService.createMixDesign(design);
            result.imported++;
          } catch (error) {
            if (options.skipConflicts) {
              result.skipped++;
            } else {
              result.errors.push(`Failed to import mix design ${design.name}: ${error}`);
            }
          }
        }
      }

      console.log('Mix design import completed:', result);
      return result;
    } catch (error) {
      console.error('Failed to import mix design data:', error);
      result.errors.push(`Import failed: ${error}`);
      return result;
    }
  }
}

export const mixDesignSyncIntegration = new MixDesignSyncIntegration();