// Database Migration Scripts for Reports System
export class ReportsMigrationService {
  
  // Run all migrations in sequence
  static async runMigrations(): Promise<{ success: boolean; migrationsRun: string[] }> {
    const migrationsRun: string[] = [];
    
    try {
      // Check if running in Electron environment
      if (!window.electronAPI) {
        console.warn('Migration service requires Electron environment');
        return { success: false, migrationsRun: [] };
      }

      // Run migrations in order
      const migrations = [
        { name: 'create_categories_table', fn: this.createCategoriesTable },
        { name: 'create_product_definitions_table', fn: this.createProductDefinitionsTable },
        { name: 'create_enhanced_report_templates_table', fn: this.createEnhancedReportTemplatesTable },
        { name: 'create_analytics_charts_table', fn: this.createAnalyticsChartsTable },
        { name: 'create_generated_reports_table', fn: this.createGeneratedReportsTable },
        { name: 'migrate_legacy_templates', fn: this.migrateLegacyTemplates },
        { name: 'migrate_legacy_reports', fn: this.migrateLegacyReports },
        { name: 'update_memo_status_for_reports', fn: this.updateMemoStatusForReports },
        { name: 'create_report_sharing_table', fn: this.createReportSharingTable },
        { name: 'add_analytics_chart_bindings', fn: this.addAnalyticsChartBindings }
      ];

      for (const migration of migrations) {
        try {
          await migration.fn();
          migrationsRun.push(migration.name);
          console.log(`Migration completed: ${migration.name}`);
        } catch (error) {
          console.error(`Migration failed: ${migration.name}`, error);
          // Continue with other migrations
        }
      }

      // Insert seed data
      await this.insertSeedData();
      migrationsRun.push('insert_seed_data');

      return { success: true, migrationsRun };
    } catch (error) {
      console.error('Migration process failed:', error);
      return { success: false, migrationsRun };
    }
  }

  // Individual migration functions
  private static async createCategoriesTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS report_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        is_active BOOLEAN DEFAULT 1,
        sort_order INTEGER DEFAULT 0
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create index for better performance
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_report_categories_active ON report_categories(is_active)'
    );
  }

  private static async createProductDefinitionsTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS product_definitions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category_id TEXT NOT NULL,
        field_definitions TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        is_active BOOLEAN DEFAULT 1,
        version INTEGER DEFAULT 1,
        FOREIGN KEY (category_id) REFERENCES report_categories (id) ON DELETE CASCADE
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create indexes
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_product_definitions_category ON product_definitions(category_id)'
    );
  }

  private static async createEnhancedReportTemplatesTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS report_templates_new (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        product_type TEXT NOT NULL,
        layout_json TEXT NOT NULL,
        uploaded_by TEXT NOT NULL,
        uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        file_path TEXT,
        template_type TEXT DEFAULT 'canvas',
        version INTEGER DEFAULT 1,
        is_active BOOLEAN DEFAULT 1,
        shared_with TEXT DEFAULT '[]',
        owner_id TEXT,
        tags TEXT DEFAULT '[]',
        thumbnail_path TEXT,
        file_size INTEGER DEFAULT 0,
        access_level TEXT DEFAULT 'private'
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Check if old table exists and migrate data
    const checkOldTable = await window.electronAPI.dbQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='report_templates'"
    );
    
    if (checkOldTable.success && checkOldTable.data.length > 0) {
      // Migrate existing data
      await window.electronAPI.dbRun(`
        INSERT INTO report_templates_new 
        (id, name, description, product_type, layout_json, uploaded_by, uploaded_at, 
         file_path, template_type, version, is_active)
        SELECT id, name, description, product_type, layout_json, uploaded_by, uploaded_at,
               file_path, template_type, version, is_active
        FROM report_templates
      `);
      
      // Drop old table and rename new one
      await window.electronAPI.dbRun('DROP TABLE report_templates');
    }
    
    await window.electronAPI.dbRun('ALTER TABLE report_templates_new RENAME TO report_templates');
    
    // Create indexes
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_report_templates_product_type ON report_templates(product_type)'
    );
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_report_templates_owner ON report_templates(uploaded_by)'
    );
  }

  private static async createAnalyticsChartsTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS analytics_charts (
        id TEXT PRIMARY KEY,
        chart_type TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        data_source TEXT NOT NULL,
        config TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        is_public BOOLEAN DEFAULT 1,
        category TEXT DEFAULT 'general',
        thumbnail_path TEXT
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create index
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_analytics_charts_public ON analytics_charts(is_public)'
    );
  }

  private static async createGeneratedReportsTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS generated_reports (
        id TEXT PRIMARY KEY,
        memo_id TEXT,
        template_id TEXT NOT NULL,
        generated_by TEXT NOT NULL,
        generated_at TEXT NOT NULL DEFAULT (datetime('now')),
        file_path TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        parameters TEXT DEFAULT '{}',
        status TEXT DEFAULT 'completed',
        watermark TEXT,
        notes TEXT,
        shared_with TEXT DEFAULT '[]',
        download_count INTEGER DEFAULT 0,
        expires_at TEXT,
        FOREIGN KEY (template_id) REFERENCES report_templates (id) ON DELETE CASCADE
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create indexes
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_generated_reports_memo ON generated_reports(memo_id)'
    );
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_generated_reports_template ON generated_reports(template_id)'
    );
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_generated_reports_date ON generated_reports(generated_at)'
    );
  }

  private static async migrateLegacyTemplates(): Promise<void> {
    // Check for legacy template storage and migrate
    try {
      const legacyTemplates = await window.electronAPI.dbQuery(
        "SELECT * FROM templates WHERE type = 'report'"
      );
      
      if (legacyTemplates.success && legacyTemplates.data.length > 0) {
        for (const template of legacyTemplates.data) {
          await window.electronAPI.dbRun(`
            INSERT OR IGNORE INTO report_templates 
            (id, name, description, product_type, layout_json, uploaded_by, uploaded_at, template_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            template.id,
            template.name || 'Migrated Template',
            template.description || 'Migrated from legacy system',
            template.category || 'general',
            template.data || '[]',
            template.created_by || 'system',
            template.created_at || new Date().toISOString(),
            'canvas'
          ]);
        }
        
        console.log(`Migrated ${legacyTemplates.data.length} legacy templates`);
      }
    } catch (error) {
      console.log('No legacy templates to migrate');
    }
  }

  private static async migrateLegacyReports(): Promise<void> {
    // Check for legacy report records and migrate
    try {
      const legacyReports = await window.electronAPI.dbQuery(
        "SELECT * FROM reports WHERE template_id IS NOT NULL"
      );
      
      if (legacyReports.success && legacyReports.data.length > 0) {
        for (const report of legacyReports.data) {
          await window.electronAPI.dbRun(`
            INSERT OR IGNORE INTO generated_reports 
            (id, memo_id, template_id, generated_by, generated_at, file_path, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `, [
            report.id,
            report.memo_id,
            report.template_id,
            report.generated_by || 'system',
            report.generated_at || new Date().toISOString(),
            report.file_path || '/reports/legacy/' + report.id + '.pdf',
            'completed'
          ]);
        }
        
        console.log(`Migrated ${legacyReports.data.length} legacy reports`);
      }
    } catch (error) {
      console.log('No legacy reports to migrate');
    }
  }

  private static async updateMemoStatusForReports(): Promise<void> {
    // Add report-related status updates to memos
    try {
      await window.electronAPI.dbRun(`
        UPDATE memos 
        SET status = 'report_generated' 
        WHERE id IN (
          SELECT DISTINCT memo_id 
          FROM generated_reports 
          WHERE memo_id IS NOT NULL
        )
      `);
      
      // Add report_requested status for memos that need reports
      await window.electronAPI.dbRun(`
        UPDATE memos 
        SET status = 'report_requested' 
        WHERE status = 'completed' 
        AND id NOT IN (
          SELECT DISTINCT memo_id 
          FROM generated_reports 
          WHERE memo_id IS NOT NULL
        )
      `);
    } catch (error) {
      console.log('Memo status update not applicable');
    }
  }

  private static async createReportSharingTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS report_sharing (
        id TEXT PRIMARY KEY,
        report_id TEXT NOT NULL,
        shared_by TEXT NOT NULL,
        shared_with TEXT NOT NULL,
        shared_at TEXT NOT NULL DEFAULT (datetime('now')),
        expires_at TEXT,
        permissions TEXT DEFAULT '["view"]',
        access_count INTEGER DEFAULT 0,
        FOREIGN KEY (report_id) REFERENCES generated_reports (id) ON DELETE CASCADE
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create indexes
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_report_sharing_report ON report_sharing(report_id)'
    );
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_report_sharing_shared_with ON report_sharing(shared_with)'
    );
  }

  private static async addAnalyticsChartBindings(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS report_chart_bindings (
        id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL,
        chart_id TEXT NOT NULL,
        position_x INTEGER NOT NULL,
        position_y INTEGER NOT NULL,
        width INTEGER NOT NULL,
        height INTEGER NOT NULL,
        config TEXT DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (template_id) REFERENCES report_templates (id) ON DELETE CASCADE,
        FOREIGN KEY (chart_id) REFERENCES analytics_charts (id) ON DELETE CASCADE
      )
    `;
    
    await window.electronAPI.dbRun(query);
    
    // Create indexes
    await window.electronAPI.dbRun(
      'CREATE INDEX IF NOT EXISTS idx_chart_bindings_template ON report_chart_bindings(template_id)'
    );
  }

  private static async insertSeedData(): Promise<void> {
    // Insert default categories
    const categories = [
      { id: 'aggregates', name: 'Aggregates', description: 'Stone and sand materials testing' },
      { id: 'concrete', name: 'Concrete', description: 'Concrete mix testing' },
      { id: 'blocks', name: 'Blocks', description: 'Concrete block testing' },
      { id: 'pavers', name: 'Pavers', description: 'Paving stone testing' },
      { id: 'kerbs', name: 'Kerbs', description: 'Kerb stone testing' },
      { id: 'flagstones', name: 'Flagstones', description: 'Flagstone testing' }
    ];

    for (const category of categories) {
      await window.electronAPI.dbRun(`
        INSERT OR IGNORE INTO report_categories 
        (id, name, description, created_by, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [
        category.id,
        category.name,
        category.description,
        'system',
        new Date().toISOString(),
        true
      ]);
    }

    // Insert default product definitions
    const productDefinitions = [
      {
        id: 'agg-10-14mm',
        name: '10-14mm Aggregate',
        category_id: 'aggregates',
        field_definitions: [
          { id: '1', name: 'Date of Test', token: '{{date_of_test}}', type: 'date', required: true },
          { id: '2', name: 'Officer in Charge', token: '{{officer_in_charge}}', type: 'text', required: true },
          { id: '3', name: 'Moisture Content (%)', token: '{{moisture_content}}', type: 'number', required: true },
          { id: '4', name: 'Fineness Modulus', token: '{{fineness_modulus}}', type: 'number', required: true },
          { id: '5', name: 'Specific Gravity', token: '{{specific_gravity}}', type: 'number', required: true }
        ]
      },
      {
        id: 'concrete-cube',
        name: 'Concrete Cube Test',
        category_id: 'concrete',
        field_definitions: [
          { id: '6', name: 'Mix Design', token: '{{mix_design}}', type: 'text', required: true },
          { id: '7', name: 'Slump Value (mm)', token: '{{slump_value}}', type: 'number', required: true },
          { id: '8', name: '7-Day Strength (MPa)', token: '{{strength_7_day}}', type: 'number', required: true },
          { id: '9', name: '28-Day Strength (MPa)', token: '{{strength_28_day}}', type: 'number', required: true },
          { id: '10', name: 'Water-Cement Ratio', token: '{{water_cement_ratio}}', type: 'number', required: true }
        ]
      }
    ];

    for (const product of productDefinitions) {
      await window.electronAPI.dbRun(`
        INSERT OR IGNORE INTO product_definitions 
        (id, name, category_id, field_definitions, created_by, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        product.id,
        product.name,
        product.category_id,
        JSON.stringify(product.field_definitions),
        'system',
        new Date().toISOString(),
        true
      ]);
    }

    // Insert default analytics charts
    const charts = [
      {
        id: 'sieve-analysis',
        chart_type: 'line',
        name: 'Sieve Analysis',
        description: 'Particle size distribution analysis',
        data_source: 'test_results',
        config: {
          chartType: 'line',
          xAxis: 'sieve_size',
          yAxis: 'passing_percentage',
          showGrid: true,
          showLegend: true
        }
      },
      {
        id: 'strength-trend',
        chart_type: 'line',
        name: 'Strength Over Time',
        description: 'Compressive strength trend analysis',
        data_source: 'test_results',
        config: {
          chartType: 'line',
          xAxis: 'test_date',
          yAxis: 'compressive_strength',
          showTrendline: true,
          showTarget: true
        }
      },
      {
        id: 'fineness-gauge',
        chart_type: 'gauge',
        name: 'Fineness Modulus Gauge',
        description: 'Current fineness modulus reading',
        data_source: 'test_results',
        config: {
          chartType: 'gauge',
          value: 'fineness_modulus',
          min: 2.0,
          max: 4.0,
          target: 2.8
        }
      }
    ];

    for (const chart of charts) {
      await window.electronAPI.dbRun(`
        INSERT OR IGNORE INTO analytics_charts 
        (id, chart_type, name, description, data_source, config, created_by, created_at, is_public)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        chart.id,
        chart.chart_type,
        chart.name,
        chart.description,
        chart.data_source,
        JSON.stringify(chart.config),
        'system',
        new Date().toISOString(),
        true
      ]);
    }
  }

  // Utility methods for checking migration status
  static async getMigrationStatus(): Promise<{ 
    tablesCreated: string[]; 
    dataSeeded: boolean; 
    lastMigration: string 
  }> {
    try {
      const tables = ['report_categories', 'product_definitions', 'report_templates', 'analytics_charts', 'generated_reports'];
      const tablesCreated: string[] = [];
      
      for (const table of tables) {
        const result = await window.electronAPI.dbQuery(
          `SELECT name FROM sqlite_master WHERE type='table' AND name='${table}'`
        );
        if (result.success && result.data.length > 0) {
          tablesCreated.push(table);
        }
      }
      
      // Check if seed data exists
      const categoryCount = await window.electronAPI.dbQuery(
        'SELECT COUNT(*) as count FROM report_categories WHERE created_by = "system"'
      );
      const dataSeeded = categoryCount.success && categoryCount.data[0]?.count > 0;
      
      return {
        tablesCreated,
        dataSeeded,
        lastMigration: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to get migration status:', error);
      return {
        tablesCreated: [],
        dataSeeded: false,
        lastMigration: 'never'
      };
    }
  }
}