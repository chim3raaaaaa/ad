-- Mix Design Manager Database Schema Migration
-- Phase 1: Core Infrastructure with Local SQLite
-- Created: 2025-01-31

-- Note: product_types table should already exist from the unified test system
-- If not present, create it to maintain compatibility
CREATE TABLE IF NOT EXISTS product_types (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  name TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Mix Design field definitions (dynamic form schema)
CREATE TABLE IF NOT EXISTS mix_design_fields (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  product_type_id TEXT NOT NULL,
  field_name TEXT NOT NULL,
  field_label TEXT NOT NULL,
  field_type TEXT NOT NULL CHECK (field_type IN ('text', 'number', 'select', 'textarea', 'date')),
  field_unit TEXT,
  default_value TEXT,
  is_required BOOLEAN DEFAULT 0,
  validation_rules TEXT, -- JSON string for validation rules
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id) ON DELETE CASCADE
);

-- Main mix designs table
CREATE TABLE IF NOT EXISTS mix_designs (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  name TEXT NOT NULL,
  product_type_id TEXT NOT NULL,
  plant_id TEXT,
  design_code TEXT UNIQUE,
  description TEXT,
  design_data TEXT NOT NULL, -- JSON string containing all form field values
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived', 'under_review')),
  created_by TEXT NOT NULL,
  approved_by TEXT,
  approved_at DATETIME,
  is_template BOOLEAN DEFAULT 0,
  parent_template_id TEXT,
  version_number INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id),
  FOREIGN KEY (parent_template_id) REFERENCES mix_designs(id)
);

-- Mix design versions (for version history)
CREATE TABLE IF NOT EXISTS mix_design_versions (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  mix_design_id TEXT NOT NULL,
  version_number INTEGER NOT NULL,
  design_data TEXT NOT NULL, -- JSON snapshot of design at this version
  change_summary TEXT,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (mix_design_id) REFERENCES mix_designs(id) ON DELETE CASCADE
);

-- Mix design templates (shared templates)
CREATE TABLE IF NOT EXISTS mix_design_templates (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  name TEXT NOT NULL,
  product_type_id TEXT NOT NULL,
  template_data TEXT NOT NULL, -- JSON containing template field values
  description TEXT,
  is_public BOOLEAN DEFAULT 0,
  created_by TEXT NOT NULL,
  approved_by TEXT,
  approved_at DATETIME,
  usage_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_type_id) REFERENCES product_types(id)
);

-- Trial results linkage (connects to unified test system)
-- Note: This integrates with the existing test_entries table from unifiedTestService
CREATE TABLE IF NOT EXISTS mix_design_trials (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  mix_design_id TEXT NOT NULL,
  memo_id TEXT, -- References memo system
  test_entry_id TEXT, -- References test_entries.id from unified test system
  plant_id TEXT, -- Plant where trial was conducted
  trial_date DATE,
  trial_results TEXT, -- JSON containing test results from test_entries.test_data
  performance_rating TEXT CHECK (performance_rating IN ('excellent', 'good', 'acceptable', 'poor')),
  compliance_status TEXT DEFAULT 'pending' CHECK (compliance_status IN ('pending', 'compliant', 'non_compliant', 'under_review')),
  variance_notes TEXT, -- Notes about variances from design
  recommended_adjustments TEXT, -- JSON with recommended design adjustments
  notes TEXT,
  created_by TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (mix_design_id) REFERENCES mix_designs(id) ON DELETE CASCADE
);

-- Sync operations tracking
CREATE TABLE IF NOT EXISTS mix_design_sync_ops (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  operation TEXT NOT NULL CHECK (operation IN ('INSERT', 'UPDATE', 'DELETE')),
  operation_data TEXT NOT NULL, -- JSON containing operation details
  sync_status TEXT DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'failed')),
  retry_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  synced_at DATETIME
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_mix_designs_product_type ON mix_designs(product_type_id);
CREATE INDEX IF NOT EXISTS idx_mix_designs_status ON mix_designs(status);
CREATE INDEX IF NOT EXISTS idx_mix_designs_created_by ON mix_designs(created_by);
CREATE INDEX IF NOT EXISTS idx_mix_design_fields_product_type ON mix_design_fields(product_type_id);
CREATE INDEX IF NOT EXISTS idx_mix_design_versions_mix_design ON mix_design_versions(mix_design_id);
CREATE INDEX IF NOT EXISTS idx_mix_design_trials_mix_design ON mix_design_trials(mix_design_id);
CREATE INDEX IF NOT EXISTS idx_mix_design_sync_ops_status ON mix_design_sync_ops(sync_status);

-- Triggers for updated_at timestamps
CREATE TRIGGER IF NOT EXISTS update_mix_designs_updated_at
  AFTER UPDATE ON mix_designs
  FOR EACH ROW
  BEGIN
    UPDATE mix_designs SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
  END;

CREATE TRIGGER IF NOT EXISTS update_product_types_updated_at
  AFTER UPDATE ON product_types
  FOR EACH ROW
  BEGIN
    UPDATE product_types SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
  END;

CREATE TRIGGER IF NOT EXISTS update_mix_design_fields_updated_at
  AFTER UPDATE ON mix_design_fields
  FOR EACH ROW
  BEGIN
    UPDATE mix_design_fields SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
  END;

CREATE TRIGGER IF NOT EXISTS update_mix_design_templates_updated_at
  AFTER UPDATE ON mix_design_templates
  FOR EACH ROW
  BEGIN
    UPDATE mix_design_templates SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
  END;