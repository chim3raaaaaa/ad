-- Mix Design Manager - Initial Data Migration
-- Phase 1: Seed data and migration from old schema
-- Created: 2025-01-31

-- Insert default product types for common mix designs
INSERT OR IGNORE INTO product_types (id, name, category, description) VALUES
('concrete-standard', 'Standard Concrete', 'Concrete', 'Standard concrete mix designs'),
('concrete-high-strength', 'High Strength Concrete', 'Concrete', 'High strength concrete mix designs'),
('concrete-lightweight', 'Lightweight Concrete', 'Concrete', 'Lightweight concrete mix designs'),
('asphalt-hot-mix', 'Hot Mix Asphalt', 'Asphalt', 'Hot mix asphalt designs'),
('asphalt-warm-mix', 'Warm Mix Asphalt', 'Asphalt', 'Warm mix asphalt designs'),
('mortar-masonry', 'Masonry Mortar', 'Mortar', 'Masonry mortar mix designs'),
('mortar-plastering', 'Plastering Mortar', 'Mortar', 'Plastering mortar mix designs');

-- Insert default field definitions for concrete mix designs
INSERT OR IGNORE INTO mix_design_fields (product_type_id, field_name, field_label, field_type, field_unit, is_required, validation_rules, display_order) VALUES
-- Concrete Standard Fields
('concrete-standard', 'cement_content', 'Cement Content', 'number', 'kg/m³', 1, '{"min": 200, "max": 600}', 1),
('concrete-standard', 'water_content', 'Water Content', 'number', 'kg/m³', 1, '{"min": 120, "max": 250}', 2),
('concrete-standard', 'fine_aggregate', 'Fine Aggregate', 'number', 'kg/m³', 1, '{"min": 600, "max": 900}', 3),
('concrete-standard', 'coarse_aggregate', 'Coarse Aggregate', 'number', 'kg/m³', 1, '{"min": 800, "max": 1200}', 4),
('concrete-standard', 'water_cement_ratio', 'Water/Cement Ratio', 'number', '', 1, '{"min": 0.25, "max": 0.7, "step": 0.01}', 5),
('concrete-standard', 'slump', 'Target Slump', 'number', 'mm', 1, '{"min": 25, "max": 200}', 6),
('concrete-standard', 'target_strength', 'Target Strength', 'number', 'MPa', 1, '{"min": 15, "max": 100}', 7),
('concrete-standard', 'admixture_type', 'Admixture Type', 'select', '', 0, '{"options": ["None", "Plasticizer", "Superplasticizer", "Retarder", "Accelerator"]}', 8),
('concrete-standard', 'admixture_dosage', 'Admixture Dosage', 'number', '% by cement weight', 0, '{"min": 0, "max": 5, "step": 0.1}', 9),
('concrete-standard', 'exposure_class', 'Exposure Class', 'select', '', 1, '{"options": ["XO", "XC1", "XC2", "XC3", "XC4", "XD1", "XD2", "XD3", "XS1", "XS2", "XS3"]}', 10),

-- High Strength Concrete Additional Fields
('concrete-high-strength', 'cement_content', 'Cement Content', 'number', 'kg/m³', 1, '{"min": 350, "max": 800}', 1),
('concrete-high-strength', 'water_content', 'Water Content', 'number', 'kg/m³', 1, '{"min": 120, "max": 200}', 2),
('concrete-high-strength', 'fine_aggregate', 'Fine Aggregate', 'number', 'kg/m³', 1, '{"min": 600, "max": 900}', 3),
('concrete-high-strength', 'coarse_aggregate', 'Coarse Aggregate', 'number', 'kg/m³', 1, '{"min": 800, "max": 1200}', 4),
('concrete-high-strength', 'water_cement_ratio', 'Water/Cement Ratio', 'number', '', 1, '{"min": 0.25, "max": 0.45, "step": 0.01}', 5),
('concrete-high-strength', 'silica_fume', 'Silica Fume', 'number', 'kg/m³', 0, '{"min": 0, "max": 80}', 6),
('concrete-high-strength', 'fly_ash', 'Fly Ash', 'number', 'kg/m³', 0, '{"min": 0, "max": 150}', 7),
('concrete-high-strength', 'target_strength', 'Target Strength', 'number', 'MPa', 1, '{"min": 40, "max": 150}', 8),

-- Asphalt Hot Mix Fields
('asphalt-hot-mix', 'asphalt_binder_grade', 'Asphalt Binder Grade', 'select', '', 1, '{"options": ["PG 64-22", "PG 70-22", "PG 76-22", "PG 82-22"]}', 1),
('asphalt-hot-mix', 'binder_content', 'Binder Content', 'number', '% by weight', 1, '{"min": 4.0, "max": 8.0, "step": 0.1}', 2),
('asphalt-hot-mix', 'aggregate_19mm', '19mm Aggregate', 'number', '% passing', 1, '{"min": 0, "max": 100}', 3),
('asphalt-hot-mix', 'aggregate_12_5mm', '12.5mm Aggregate', 'number', '% passing', 1, '{"min": 0, "max": 100}', 4),
('asphalt-hot-mix', 'aggregate_9_5mm', '9.5mm Aggregate', 'number', '% passing', 1, '{"min": 0, "max": 100}', 5),
('asphalt-hot-mix', 'aggregate_4_75mm', '4.75mm Aggregate', 'number', '% passing', 1, '{"min": 0, "max": 100}', 6),
('asphalt-hot-mix', 'aggregate_2_36mm', '2.36mm Aggregate', 'number', '% passing', 1, '{"min": 0, "max": 100}', 7),
('asphalt-hot-mix', 'aggregate_0_075mm', '0.075mm Aggregate', 'number', '% passing', 1, '{"min": 2, "max": 10}', 8),
('asphalt-hot-mix', 'air_voids', 'Target Air Voids', 'number', '%', 1, '{"min": 3.0, "max": 8.0, "step": 0.1}', 9),
('asphalt-hot-mix', 'mixing_temp', 'Mixing Temperature', 'number', '°C', 1, '{"min": 140, "max": 180}', 10),

-- Mortar Masonry Fields
('mortar-masonry', 'cement_content', 'Cement Content', 'number', 'kg/m³', 1, '{"min": 200, "max": 500}', 1),
('mortar-masonry', 'lime_content', 'Lime Content', 'number', 'kg/m³', 0, '{"min": 0, "max": 200}', 2),
('mortar-masonry', 'sand_content', 'Sand Content', 'number', 'kg/m³', 1, '{"min": 1200, "max": 1800}', 3),
('mortar-masonry', 'water_content', 'Water Content', 'number', 'kg/m³', 1, '{"min": 200, "max": 350}', 4),
('mortar-masonry', 'mortar_type', 'Mortar Type', 'select', '', 1, '{"options": ["Type N", "Type S", "Type M", "Type O"]}', 5),
('mortar-masonry', 'compressive_strength', 'Target Compressive Strength', 'number', 'MPa', 1, '{"min": 5, "max": 25}', 6);

-- Insert sample templates
INSERT OR IGNORE INTO mix_design_templates (id, name, product_type_id, template_data, description, is_public, created_by) VALUES
('template-concrete-c25', 'C25/30 Standard Concrete', 'concrete-standard', 
 '{"cement_content": 350, "water_content": 175, "fine_aggregate": 750, "coarse_aggregate": 1050, "water_cement_ratio": 0.5, "slump": 75, "target_strength": 25, "exposure_class": "XC1"}',
 'Standard C25/30 concrete mix design template', 1, 'system'),
 
('template-concrete-c40', 'C40/50 High Strength Concrete', 'concrete-high-strength',
 '{"cement_content": 450, "water_content": 180, "fine_aggregate": 700, "coarse_aggregate": 1000, "water_cement_ratio": 0.4, "silica_fume": 25, "target_strength": 40}',
 'High strength C40/50 concrete mix design template', 1, 'system'),
 
('template-asphalt-dense', 'Dense Graded Asphalt', 'asphalt-hot-mix',
 '{"asphalt_binder_grade": "PG 64-22", "binder_content": 5.5, "aggregate_19mm": 100, "aggregate_12_5mm": 90, "aggregate_9_5mm": 70, "aggregate_4_75mm": 45, "aggregate_2_36mm": 30, "aggregate_0_075mm": 6, "air_voids": 4.0, "mixing_temp": 160}',
 'Dense graded hot mix asphalt template', 1, 'system'),
 
('template-mortar-type-n', 'Type N Masonry Mortar', 'mortar-masonry',
 '{"cement_content": 300, "lime_content": 100, "sand_content": 1500, "water_content": 250, "mortar_type": "Type N", "compressive_strength": 12}',
 'Type N masonry mortar mix design template', 1, 'system');