import { aggregateTestService } from './aggregateTestService';
import { blockTestService } from './blockTestService';
import { cubeTestService } from './cubeTestService';
import { paverTestService } from './paverTestService';
import { kerbTestService } from './kerbTestService';
import { flagstoneTestService } from './flagstoneTestService';
import { concreteTestService } from './concreteTestService';
import { toast } from '@/hooks/use-toast';

// Unified interface for all test services
export interface TestService {
  createPlantDatabase(plantId: string, plantName: string, productType: string): Promise<string>;
  getPlantDatabases(plantId: string): Promise<any[]>;
  getTestEntries(tableName: string, filters?: Record<string, any>): Promise<any[]>;
  createTestEntry(tableName: string, entryData: any): Promise<any>;
  updateTestEntry(tableName: string, entryId: string, updates: any): Promise<void>;
  deleteTestEntry(tableName: string, entryId: string): Promise<void>;
  validateTestData(testData: any, referenceData: any): Promise<{ isValid: boolean; errors: string[] }>;
}

// Product category interface for dynamic loading
export interface ProductCategory {
  id: string;
  name: string;
  service: TestService | null;
  description: string;
  icon: string;
}

// Product field interface for dynamic form generation
export interface ProductField {
  id: string;
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea';
  category: string;
  productType: string;
  required: boolean;
  description: string;
  icon: string;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    options?: string[];
  };
}

// Memo data interface
export interface MemoData {
  id: string;
  memo_ref: string;
  plant: string;
  officer: string;
  category: string;
  product_type: string;
  date_created: string;
  date_sampling?: string;
  status: 'pending' | 'in_progress' | 'completed';
  test_data?: Record<string, any>;
  metadata?: Record<string, any>;
}

// Product category configuration - can be extended dynamically
export const PRODUCT_CATEGORIES: ProductCategory[] = [
  { id: 'aggregates', name: 'Aggregates', service: aggregateTestService, description: 'Aggregate materials testing', icon: '🪨' },
  { id: 'blocks', name: 'Blocks', service: blockTestService, description: 'Concrete block testing', icon: '🟧' },
  { id: 'cubes', name: 'Cubes', service: cubeTestService, description: 'Cube testing and analysis', icon: '🧊' },
  { id: 'pavers', name: 'Pavers', service: paverTestService, description: 'Paver testing and quality control', icon: '⬜' },
  { id: 'kerbs', name: 'Kerbs', service: kerbTestService, description: 'Kerb stone testing', icon: '〰️' },
  { id: 'flagstones', name: 'Flagstones', service: flagstoneTestService, description: 'Flagstone testing', icon: '🔳' },
  { id: 'concrete', name: 'Concrete', service: concreteTestService, description: 'Concrete testing and analysis', icon: '🧱' }
];

// Unified Plant Test Service
class PlantTestService {
  private readonly PRODUCT_FIELDS_KEY = 'product_fields';
  private readonly MEMOS_KEY = 'memos_data';

  // Get available product categories
  async getProductCategories(): Promise<ProductCategory[]> {
    return PRODUCT_CATEGORIES;
  }

  // Initialize default data if needed
  async initializeDefaultData(): Promise<void> {
    try {
      const existingFields = await this.getProductFields();
      if (existingFields.length === 0) {
        await this.saveProductFields(this.getDefaultProductFields());
      }
    } catch (error) {
      console.error('Error initializing default data:', error);
    }
  }

  // Product Fields Management
  async getProductFields(productType?: string): Promise<ProductField[]> {
    try {
      if (window.electronAPI?.dbQuery) {
        const query = productType 
          ? `SELECT * FROM product_fields WHERE productType = ? ORDER BY name`
          : `SELECT * FROM product_fields ORDER BY name`;
        const params = productType ? [productType] : [];
        const result = await window.electronAPI.dbQuery(query, params);
        return result || [];
      }
      
      const stored = localStorage.getItem(this.PRODUCT_FIELDS_KEY);
      const allFields = stored ? JSON.parse(stored) : this.getDefaultProductFields();
      
      return productType 
        ? allFields.filter((field: ProductField) => field.productType === productType || field.productType === 'all')
        : allFields;
    } catch (error) {
      console.error('Error loading product fields:', error);
      const defaultFields = this.getDefaultProductFields();
      return productType 
        ? defaultFields.filter(f => f.productType === productType || f.productType === 'all')
        : defaultFields;
    }
  }

  async saveProductFields(fields: ProductField[]): Promise<void> {
    try {
      if (window.electronAPI?.dbQuery) {
        for (const field of fields) {
          await window.electronAPI.dbQuery(
            `INSERT OR REPLACE INTO product_fields 
             (id, name, label, type, category, productType, required, description, icon, validation) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              field.id, field.name, field.label, field.type, field.category,
              field.productType, field.required, field.description, field.icon,
              JSON.stringify(field.validation || {})
            ]
          );
        }
      } else {
        localStorage.setItem(this.PRODUCT_FIELDS_KEY, JSON.stringify(fields));
      }
    } catch (error) {
      console.error('Error saving product fields:', error);
    }
  }

  // Memo Management
  async getMemoByRef(memoRef: string): Promise<MemoData | null> {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM memos WHERE memo_ref = ?`,
          [memoRef]
        );
        return result && result.length > 0 ? result[0] : null;
      }
      
      const stored = localStorage.getItem(this.MEMOS_KEY);
      const memos = stored ? JSON.parse(stored) : [];
      return memos.find((memo: MemoData) => memo.memo_ref === memoRef) || null;
    } catch (error) {
      console.error('Error loading memo:', error);
      return null;
    }
  }

  async getAllMemos(): Promise<MemoData[]> {
    try {
      if (window.electronAPI?.dbQuery) {
        const result = await window.electronAPI.dbQuery(
          `SELECT * FROM memos ORDER BY date_created DESC`
        );
        return result || [];
      }
      
      const stored = localStorage.getItem(this.MEMOS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading memos:', error);
      return [];
    }
  }

  async saveMemo(memo: Omit<MemoData, 'id'>): Promise<string> {
    try {
      const id = `memo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const memoWithId = { ...memo, id };

      if (window.electronAPI?.dbQuery) {
        await window.electronAPI.dbQuery(
          `INSERT INTO memos 
           (id, memo_ref, plant, officer, category, product_type, date_created, date_sampling, status, test_data, metadata)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id, memo.memo_ref, memo.plant, memo.officer, memo.category,
            memo.product_type, memo.date_created, memo.date_sampling,
            memo.status, JSON.stringify(memo.test_data || {}), JSON.stringify(memo.metadata || {})
          ]
        );
      } else {
        const memos = await this.getAllMemos();
        memos.push(memoWithId);
        localStorage.setItem(this.MEMOS_KEY, JSON.stringify(memos));
      }

      return id;
    } catch (error) {
      console.error('Error saving memo:', error);
      throw error;
    }
  }

  // Get product types for a specific category
  async getProductTypesForCategory(category: string): Promise<string[]> {
    const productTypes: { [key: string]: string[] } = {
      aggregates: ['0-4mm', '4-6mm', '6-10mm', '10-14mm', '14-20mm', '20-31.5mm'],
      blocks: ['190x140x90', '190x190x90', '390x140x90', '390x190x90'],
      cubes: ['100mm', '150mm', '200mm'],
      pavers: ['60mm', '80mm', '100mm'],
      kerbs: ['Standard', 'Heavy Duty', 'Barrier'],
      flagstones: ['20mm', '30mm', '40mm', '50mm'],
      concrete: ['C20', 'C25', 'C30', 'C35', 'C40']
    };
    
    return productTypes[category] || [];
  }

  // Validate product type exists for category
  async validateProductType(category: string, productType: string): Promise<boolean> {
    const validTypes = await this.getProductTypesForCategory(category);
    return validTypes.includes(productType);
  }

  // Validate plant exists in reference data
  async validatePlant(plantId: string): Promise<boolean> {
    // For now, allow all plants - could validate against reference data in future
    return true;
  }

  // Get service for a specific category
  getServiceForCategory(category: string): TestService | null {
    const categoryConfig = PRODUCT_CATEGORIES.find(c => c.id === category);
    return categoryConfig?.service || null;
  }

  // Get all databases across all categories for a specific plant
  async getAllPlantDatabases(plantId?: string): Promise<Array<{
    category: string;
    plant_id: string;
    plant_name: string;
    product_type: string;
    table_name: string;
    entry_count: number;
    last_updated: string;
  }>> {
    const allDatabases: any[] = [];
    
    for (const category of PRODUCT_CATEGORIES) {
      if (category.service) {
        try {
          const databases = await category.service.getPlantDatabases(plantId || '');
          
          // Filter by plant if specified
          const filteredDatabases = plantId 
            ? databases.filter(db => db.plant_id === plantId)
            : databases;
            
          allDatabases.push(...filteredDatabases.map(db => ({
            ...db,
            category: category.id
          })));
        } catch (error) {
          console.error(`Error getting databases for ${category.name}:`, error);
        }
      }
    }
    
    return allDatabases.sort((a, b) => 
      new Date(b.last_updated).getTime() - new Date(a.last_updated).getTime()
    );
  }

  // Create database for specific category and plant
  async createPlantDatabase(
    category: string, 
    plantId: string, 
    plantName: string, 
    productType: string
  ): Promise<string> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      throw new Error(`Service not implemented for category: ${category}`);
    }
    
    return await service.createPlantDatabase(plantId, plantName, productType);
  }

  // Get test entries for a specific database
  async getTestEntries(
    category: string,
    tableName: string, 
    filters?: Record<string, any>
  ): Promise<any[]> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      toast({
        title: "Service Not Available",
        description: `Test service for ${category} is not yet implemented`,
        variant: "destructive"
      });
      return [];
    }
    
    return await service.getTestEntries(tableName, filters);
  }

  // Create test entry
  async createTestEntry(
    category: string,
    tableName: string, 
    entryData: any
  ): Promise<any> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      throw new Error(`Service not implemented for category: ${category}`);
    }
    
    return await service.createTestEntry(tableName, entryData);
  }

  // Update test entry
  async updateTestEntry(
    category: string,
    tableName: string, 
    entryId: string, 
    updates: any
  ): Promise<void> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      throw new Error(`Service not implemented for category: ${category}`);
    }
    
    return await service.updateTestEntry(tableName, entryId, updates);
  }

  // Delete test entry
  async deleteTestEntry(
    category: string,
    tableName: string, 
    entryId: string
  ): Promise<void> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      throw new Error(`Service not implemented for category: ${category}`);
    }
    
    return await service.deleteTestEntry(tableName, entryId);
  }

  // Validate test data
  async validateTestData(
    category: string,
    testData: any, 
    referenceData: any
  ): Promise<{ isValid: boolean; errors: string[] }> {
    const service = this.getServiceForCategory(category);
    
    if (!service) {
      throw new Error(`Service not implemented for category: ${category}`);
    }
    
    return await service.validateTestData(testData, referenceData);
  }

  // Get statistics for a plant across all categories
  async getPlantStatistics(plantId: string): Promise<{
    totalDatabases: number;
    totalEntries: number;
    categoriesUsed: string[];
    lastUpdated: string;
  }> {
    const databases = await this.getAllPlantDatabases(plantId);
    
    const totalEntries = databases.reduce((sum, db) => sum + db.entry_count, 0);
    const categoriesUsed = [...new Set(databases.map(db => db.category))];
    const lastUpdated = databases.length > 0 
      ? databases.sort((a, b) => new Date(b.last_updated).getTime() - new Date(a.last_updated).getTime())[0].last_updated
      : new Date().toISOString();
    
    return {
      totalDatabases: databases.length,
      totalEntries,
      categoriesUsed,
      lastUpdated
    };
  }

  // Backup plant data across all categories
  async backupPlantData(plantId: string): Promise<{
    success: boolean;
    backupPath?: string;
    error?: string;
  }> {
    try {
      if (typeof window !== 'undefined' && (window as any).electronAPI) {
        // Electron backup implementation
        const databases = await this.getAllPlantDatabases(plantId);
        const backupData = {
          plantId,
          timestamp: new Date().toISOString(),
          databases: {}
        };
        
        // Collect all data for the plant
        for (const db of databases) {
          const service = this.getServiceForCategory(db.category);
          if (service) {
            const entries = await service.getTestEntries(db.table_name);
            (backupData.databases as any)[db.table_name] = {
              category: db.category,
              entries
            };
          }
        }
        
        const backupPath = await (window as any).electronAPI.createBackup();
        
        toast({
          title: "Backup Created",
          description: `Plant data backup created successfully`
        });
        
        return { success: true, backupPath };
      } else {
        // Browser backup implementation
        const databases = await this.getAllPlantDatabases(plantId);
        const backupData = {
          plantId,
          timestamp: new Date().toISOString(),
          databases: {} as any
        };
        
        for (const db of databases) {
          const data = localStorage.getItem(db.table_name);
          if (data) {
            backupData.databases[db.table_name] = {
              category: db.category,
              entries: JSON.parse(data)
            };
          }
        }
        
        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `plant_${plantId}_backup_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        toast({
          title: "Backup Downloaded",
          description: `Plant data backup downloaded successfully`
        });
        
        return { success: true };
      }
    } catch (error) {
      console.error('Backup failed:', error);
      toast({
        title: "Backup Failed",
        description: "Failed to create plant data backup",
        variant: "destructive"
      });
      
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  // Default product fields for different categories
  private getDefaultProductFields(): ProductField[] {
    return [
      // Common fields
      {
        id: 'memo-ref',
        name: 'memo_ref',
        label: 'Memo Reference',
        type: 'text',
        category: 'common',
        productType: 'all',
        required: true,
        description: 'Reference number of the memo',
        icon: 'Hash'
      },
      {
        id: 'date-sampling',
        name: 'date_sampling',
        label: 'Date of Sampling',
        type: 'date',
        category: 'common',
        productType: 'all',
        required: true,
        description: 'Date when samples were collected',
        icon: 'Calendar'
      },
      {
        id: 'officer',
        name: 'testing_officer',
        label: 'Testing Officer',
        type: 'text',
        category: 'common',
        productType: 'all',
        required: true,
        description: 'Name of the testing officer',
        icon: 'User'
      },
      {
        id: 'plant',
        name: 'plant_location',
        label: 'Plant/Location',
        type: 'text',
        category: 'common',
        productType: 'all',
        required: true,
        description: 'Testing plant or location',
        icon: 'Building'
      },

      // Aggregates fields
      {
        id: 'material-type',
        name: 'material_type',
        label: 'Material Type',
        type: 'select',
        category: 'aggregates',
        productType: 'aggregates',
        required: true,
        description: 'Type of aggregate material',
        icon: 'Package2',
        validation: {
          options: ['Fine Sand', 'Coarse Sand', 'Stone Chips', 'Gravel', 'Crushed Stone']
        }
      },
      {
        id: 'fineness-modulus',
        name: 'fineness_modulus',
        label: 'Fineness Modulus',
        type: 'number',
        category: 'aggregates',
        productType: 'aggregates',
        required: false,
        description: 'Fineness modulus value',
        icon: 'Target',
        validation: { min: 0, max: 10 }
      },
      {
        id: 'specific-gravity',
        name: 'specific_gravity',
        label: 'Specific Gravity',
        type: 'number',
        category: 'aggregates',
        productType: 'aggregates',
        required: false,
        description: 'Specific gravity measurement',
        icon: 'Activity',
        validation: { min: 1, max: 5 }
      },
      {
        id: 'water-absorption',
        name: 'water_absorption',
        label: 'Water Absorption (%)',
        type: 'number',
        category: 'aggregates',
        productType: 'aggregates',
        required: false,
        description: 'Water absorption percentage',
        icon: 'TrendingUp',
        validation: { min: 0, max: 100 }
      },

      // Concrete fields
      {
        id: 'mix-design',
        name: 'mix_design',
        label: 'Mix Design',
        type: 'text',
        category: 'concrete',
        productType: 'concrete',
        required: true,
        description: 'Concrete mix design details',
        icon: 'Database'
      },
      {
        id: 'slump-test',
        name: 'slump_test',
        label: 'Slump Test (mm)',
        type: 'number',
        category: 'concrete',
        productType: 'concrete',
        required: false,
        description: 'Slump test results',
        icon: 'TestTube',
        validation: { min: 0, max: 300 }
      },
      {
        id: 'compressive-strength',
        name: 'compressive_strength',
        label: 'Compressive Strength (MPa)',
        type: 'number',
        category: 'concrete',
        productType: 'concrete',
        required: false,
        description: 'Compressive strength at 28 days',
        icon: 'TrendingUp',
        validation: { min: 0, max: 100 }
      },

      // Blocks fields
      {
        id: 'block-dimensions',
        name: 'block_dimensions',
        label: 'Block Dimensions',
        type: 'text',
        category: 'blocks',
        productType: 'blocks',
        required: true,
        description: 'Dimensions of the blocks',
        icon: 'Layers'
      },
      {
        id: 'density',
        name: 'density',
        label: 'Density (kg/m³)',
        type: 'number',
        category: 'blocks',
        productType: 'blocks',
        required: false,
        description: 'Block density measurement',
        icon: 'Activity',
        validation: { min: 1000, max: 3000 }
      },

      // Pavers fields
      {
        id: 'paver-thickness',
        name: 'paver_thickness',
        label: 'Paver Thickness (mm)',
        type: 'number',
        category: 'pavers',
        productType: 'pavers',
        required: true,
        description: 'Thickness measurement',
        icon: 'Layers',
        validation: { min: 10, max: 100 }
      },
      {
        id: 'slip-resistance',
        name: 'slip_resistance',
        label: 'Slip Resistance',
        type: 'text',
        category: 'pavers',
        productType: 'pavers',
        required: false,
        description: 'Slip resistance test results',
        icon: 'Target'
      },

      // Kerbs fields
      {
        id: 'kerb-profile',
        name: 'kerb_profile',
        label: 'Kerb Profile',
        type: 'text',
        category: 'kerbs',
        productType: 'kerbs',
        required: true,
        description: 'Kerb profile specifications',
        icon: 'Layers'
      },
      {
        id: 'impact-strength',
        name: 'impact_strength',
        label: 'Impact Strength',
        type: 'number',
        category: 'kerbs',
        productType: 'kerbs',
        required: false,
        description: 'Impact strength test results',
        icon: 'TrendingUp',
        validation: { min: 0, max: 50 }
      },

      // Flagstones fields
      {
        id: 'surface-finish',
        name: 'surface_finish',
        label: 'Surface Finish',
        type: 'select',
        category: 'flagstones',
        productType: 'flagstones',
        required: true,
        description: 'Surface finish quality',
        icon: 'Palette',
        validation: {
          options: ['Smooth', 'Textured', 'Natural', 'Polished', 'Brushed']
        }
      },
      {
        id: 'weathering-resistance',
        name: 'weathering_resistance',
        label: 'Weathering Resistance',
        type: 'text',
        category: 'flagstones',
        productType: 'flagstones',
        required: false,
        description: 'Weathering resistance properties',
        icon: 'Activity'
      }
    ];
  }

}

export const plantTestService = new PlantTestService();