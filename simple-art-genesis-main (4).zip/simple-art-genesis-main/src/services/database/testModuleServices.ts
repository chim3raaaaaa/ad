import { enhancedReferenceDataService } from './enhancedReferenceDataService';
import { toast } from '@/hooks/use-toast';

export interface TestRecord {
  id: string;
  memo_reference: string;
  category_id: string;
  product_id: string;
  test_type: string;
  test_performed: boolean;
  test_date?: string;
  officer_id?: string;
  machine_id?: string;
  plant_id?: string;
  mould_id?: string;
  results?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface MemoData {
  memo_reference: string;
  category_id: string;
  product_id: string;
  product_code: string;
  plant_id: string;
  officer_id: string;
  machine_id?: string;
  production_date: string;
  pdf_path: string;
  parsed_fields: Record<string, any>;
}

class TestModuleService {
  async saveMemoOnly(memoData: MemoData): Promise<string> {
    const memoId = `RTB${new Date().toISOString().slice(2, 10).replace(/-/g, '')}${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    
    toast({
      title: "Memo Saved",
      description: `Memo ${memoId} saved as PDF. No test data written until test is performed.`
    });

    return memoId;
  }

  async completeTest(testData: {
    memo_reference: string;
    test_type: string;
    test_results: Record<string, any>;
    test_performed: boolean;
  }): Promise<void> {
    if (!testData.test_performed) {
      toast({
        title: "Test Not Performed",
        description: "Test data will not be saved until test is marked as performed.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Test Completed",
      description: "Test data validated and saved to appropriate module database"
    });
  }

  async canSaveTestRecord(memoReference: string): Promise<{ canSave: boolean; reason?: string }> {
    return { canSave: true };
  }

  async getAllTestModules(): Promise<string[]> {
    return ['blocks', 'aggregates', 'concrete', 'kerbs', 'flags', 'pavers'];
  }

  async getTestRecords(categoryId: string, filters?: Record<string, any>): Promise<TestRecord[]> {
    return [];
  }
}

export const testModuleService = new TestModuleService();