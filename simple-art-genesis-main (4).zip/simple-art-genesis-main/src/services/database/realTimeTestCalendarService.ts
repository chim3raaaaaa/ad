import { enhancedDashboardService, TestScheduleEvent } from './enhancedDashboardService';

declare global {
  interface Window {
    electronAPI: any;
  }
}

export interface TestCalendarEvent {
  id: string;
  memo_id: string;
  test_type: string;
  production_date: string;
  due_date: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'overdue' | 'cancelled';
  priority: 'low' | 'normal' | 'high' | 'critical';
  product: string;
  assigned_to?: string;
  plant_location?: string;
  batch_number?: string;
  remaining_days: number;
  notes?: string;
  completed_at?: string;
  completed_by?: string;
}

export interface TestCalendarFilters {
  labSite?: string;
  product?: string;
  testType?: string;
  status?: string;
  startDate?: string;
  endDate?: string;
}

class RealTimeTestCalendarService {
  private isElectron = false;
  private isInitialized = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
    console.log('Test Calendar Service - Electron detected:', this.isElectron);
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        // Ensure all required tables exist
        await this.createRequiredTables();
        await enhancedDashboardService.initialize();
        await this.syncMemosToTestSchedule();
        console.log('Real-time Test Calendar Service initialized with database');
      } else {
        console.warn('Test Calendar Service running in browser mode - limited functionality');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Real-time Test Calendar Service:', error);
      throw error;
    }
  }

  private async createRequiredTables(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Ensure memos table exists
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS memos (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          content TEXT,
          production_data TEXT DEFAULT '[]',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          plant_location TEXT,
          lab_site_id TEXT
        )
      `);

      console.log('Required tables verified/created');
    } catch (error) {
      console.error('Error creating required tables:', error);
      throw error;
    }
  }

  async getTestEvents(filters?: TestCalendarFilters): Promise<TestCalendarEvent[]> {
    await this.initialize();

    if (!this.isElectron) {
      console.warn('Using mock data - Electron not available');
      return this.getMockTestEvents();
    }

    try {
      // Sync latest memo data first
      await this.syncMemosToTestSchedule();

      let query = 'SELECT * FROM test_schedule WHERE 1=1';
      const params: any[] = [];

      // Apply filters
      if (filters?.startDate) {
        query += ' AND due_date >= ?';
        params.push(filters.startDate);
      }
      if (filters?.endDate) {
        query += ' AND due_date <= ?';
        params.push(filters.endDate);
      }
      if (filters?.status) {
        query += ' AND status = ?';
        params.push(filters.status);
      }
      if (filters?.labSite) {
        query += ' AND plant_location = ?';
        params.push(filters.labSite);
      }
      if (filters?.product) {
        query += ' AND product_type LIKE ?';
        params.push(`%${filters.product}%`);
      }
      if (filters?.testType) {
        query += ' AND test_type LIKE ?';
        params.push(`%${filters.testType}%`);
      }

      query += ' ORDER BY due_date ASC, priority DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      
      if (!result.success) {
        console.error('Database query failed:', result.error);
        return [];
      }

      return result.data.map((event: any) => this.mapToCalendarEvent(event));
    } catch (error) {
      console.error('Error fetching test events:', error);
      return [];
    }
  }

  async markTestDone(eventId: string, userId: string = 'current_user'): Promise<boolean> {
    await this.initialize();

    if (!this.isElectron) {
      console.log('Mock: Test marked as done (browser mode)');
      return true;
    }

    try {
      const result = await window.electronAPI.dbQuery(`
        UPDATE test_schedule 
        SET status = 'completed', 
            completed_at = CURRENT_TIMESTAMP, 
            completed_by = ?, 
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [userId, eventId]);

      if (!result.success) {
        console.error('Failed to mark test as done:', result.error);
        return false;
      }

      console.log(`Test ${eventId} marked as completed by ${userId}`);
      return true;
    } catch (error) {
      console.error('Error marking test as done:', error);
      return false;
    }
  }

  async getOverdueTests(): Promise<TestCalendarEvent[]> {
    await this.initialize();

    if (!this.isElectron) {
      return this.getMockTestEvents().filter(event => event.status === 'overdue');
    }

    try {
      const today = new Date().toISOString().split('T')[0];
      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_schedule 
        WHERE due_date < ? AND status NOT IN ('completed', 'cancelled')
        ORDER BY due_date ASC
      `, [today]);

      if (!result.success) return [];

      return result.data.map((event: any) => this.mapToCalendarEvent(event));
    } catch (error) {
      console.error('Error fetching overdue tests:', error);
      return [];
    }
  }

  async getTestsDueToday(): Promise<TestCalendarEvent[]> {
    await this.initialize();

    if (!this.isElectron) {
      const today = new Date().toISOString().split('T')[0];
      return this.getMockTestEvents().filter(event => event.due_date === today);
    }

    try {
      const today = new Date().toISOString().split('T')[0];
      const result = await window.electronAPI.dbQuery(`
        SELECT * FROM test_schedule 
        WHERE due_date = ? AND status NOT IN ('completed', 'cancelled')
        ORDER BY priority DESC
      `, [today]);

      if (!result.success) return [];

      return result.data.map((event: any) => this.mapToCalendarEvent(event));
    } catch (error) {
      console.error('Error fetching tests due today:', error);
      return [];
    }
  }

  async createTestFromMemo(memoId: string, productionData: any): Promise<string | null> {
    if (!this.isElectron) return null;

    try {
      const productionDate = new Date(productionData.production_date);
      const dueDate = new Date(productionDate);
      dueDate.setDate(dueDate.getDate() + 28); // Standard 28-day test period

      const eventId = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const result = await window.electronAPI.dbQuery(`
        INSERT INTO test_schedule (
          id, memo_id, test_type, production_date, scheduled_date, due_date,
          priority, status, plant_location, product_type, batch_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        eventId,
        memoId,
        '28-day Cube Test',
        productionDate.toISOString().split('T')[0],
        dueDate.toISOString().split('T')[0],
        dueDate.toISOString().split('T')[0],
        'normal',
        'scheduled',
        productionData.plant_location || productionData.plant || '',
        productionData.product || 'Unknown Product',
        productionData.batch_number || ''
      ]);

      if (result.success) {
        console.log(`Created test schedule for memo ${memoId}: ${eventId}`);
        return eventId;
      } else {
        console.error('Failed to create test schedule:', result.error);
        return null;
      }
    } catch (error) {
      console.error('Error creating test from memo:', error);
      return null;
    }
  }

  private async syncMemosToTestSchedule(): Promise<void> {
    if (!this.isElectron) return;

    try {
      // Get all memos with production data that don't have scheduled tests
      const memosResult = await window.electronAPI.dbQuery(`
        SELECT m.id, m.production_data, m.plant_location
        FROM memos m
        LEFT JOIN test_schedule ts ON m.id = ts.memo_id
        WHERE m.production_data IS NOT NULL 
        AND m.production_data != '[]'
        AND ts.id IS NULL
        LIMIT 50
      `);

      if (!memosResult.success || !memosResult.data.length) {
        console.log('No new memos to sync to test schedule');
        return;
      }

      console.log(`Syncing ${memosResult.data.length} memos to test schedule`);

      for (const memo of memosResult.data) {
        try {
          const productionData = JSON.parse(memo.production_data || '[]');
          if (Array.isArray(productionData) && productionData.length > 0) {
            for (const production of productionData.slice(0, 3)) { // Limit to first 3 productions per memo
              if (production.production_date) {
                await this.createTestFromMemo(memo.id, {
                  ...production,
                  plant_location: memo.plant_location
                });
              }
            }
          }
        } catch (parseError) {
          console.warn(`Failed to parse production data for memo ${memo.id}:`, parseError);
        }
      }

      console.log('Memo sync to test schedule completed');
    } catch (error) {
      console.error('Error syncing memos to test schedule:', error);
    }
  }

  private mapToCalendarEvent(event: TestScheduleEvent): TestCalendarEvent {
    const today = new Date();
    const dueDate = new Date(event.due_date);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let status = event.status;
    if (status !== 'completed' && diffDays < 0) {
      status = 'overdue';
    }

    return {
      id: event.id,
      memo_id: event.memo_id,
      test_type: event.test_type,
      production_date: event.production_date,
      due_date: event.due_date,
      status: status as any,
      priority: event.priority,
      product: event.product_type || 'Unknown Product',
      assigned_to: event.assigned_to,
      plant_location: event.plant_location,
      batch_number: event.batch_number,
      remaining_days: diffDays,
      notes: event.notes,
      completed_at: event.completed_at,
      completed_by: event.completed_by
    };
  }

  private getMockTestEvents(): TestCalendarEvent[] {
    console.warn('Using mock test events - database not available');
    return [];
  }

  // Real-time notifications and alerts
  async checkForAlerts(): Promise<{
    overdue: number;
    dueToday: number;
    dueTomorrow: number;
  }> {
    await this.initialize();

    if (!this.isElectron) {
      return { overdue: 2, dueToday: 3, dueTomorrow: 5 };
    }

    try {
      const today = new Date().toISOString().split('T')[0];
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      const [overdueResult, todayResult, tomorrowResult] = await Promise.all([
        window.electronAPI.dbQuery(
          'SELECT COUNT(*) as count FROM test_schedule WHERE due_date < ? AND status NOT IN ("completed", "cancelled")',
          [today]
        ),
        window.electronAPI.dbQuery(
          'SELECT COUNT(*) as count FROM test_schedule WHERE due_date = ? AND status NOT IN ("completed", "cancelled")',
          [today]
        ),
        window.electronAPI.dbQuery(
          'SELECT COUNT(*) as count FROM test_schedule WHERE due_date = ? AND status NOT IN ("completed", "cancelled")',
          [tomorrowStr]
        )
      ]);

      const result = {
        overdue: overdueResult.success ? overdueResult.data[0]?.count || 0 : 0,
        dueToday: todayResult.success ? todayResult.data[0]?.count || 0 : 0,
        dueTomorrow: tomorrowResult.success ? tomorrowResult.data[0]?.count || 0 : 0
      };

      console.log('Test alerts check:', result);
      return result;
    } catch (error) {
      console.error('Error checking for alerts:', error);
      return { overdue: 0, dueToday: 0, dueTomorrow: 0 };
    }
  }
}

export const realTimeTestCalendarService = new RealTimeTestCalendarService();