import { toast } from '@/components/ui/use-toast';

export interface EmailConfig {
  smtpHost: string;
  smtpPort: number;
  username: string;
  password: string;
  fromEmail: string;
  fromName: string;
  security: 'none' | 'tls' | 'ssl';
}

export interface EmailMessage {
  to: string[];
  cc?: string[];
  bcc?: string[];
  subject: string;
  html?: string;
  text?: string;
  attachments?: EmailAttachment[];
}

export interface EmailAttachment {
  filename: string;
  content: string | Buffer;
  contentType?: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  html: string;
  variables: string[];
}

class EmailService {
  private config: EmailConfig | null = null;
  private templates: EmailTemplate[] = [
    {
      id: 'test-completed',
      name: 'Test Completed Notification',
      subject: 'Test {{testId}} Completed',
      html: `
        <h2>Test Completed</h2>
        <p>Hello {{recipientName}},</p>
        <p>Test <strong>{{testId}}</strong> has been completed.</p>
        <p><strong>Results:</strong> {{results}}</p>
        <p>Generated on: {{date}}</p>
        <p>Best regards,<br>Laboratory Management System</p>
      `,
      variables: ['testId', 'recipientName', 'results', 'date']
    },
    {
      id: 'memo-created',
      name: 'New Memo Notification',
      subject: 'New Memo: {{title}}',
      html: `
        <h2>New Memo Created</h2>
        <p>Hello {{recipientName}},</p>
        <p>A new memo has been created:</p>
        <p><strong>Title:</strong> {{title}}</p>
        <p><strong>Content:</strong> {{content}}</p>
        <p><strong>Priority:</strong> {{priority}}</p>
        <p>Created on: {{date}}</p>
        <p>Best regards,<br>Laboratory Management System</p>
      `,
      variables: ['title', 'content', 'priority', 'recipientName', 'date']
    },
    {
      id: 'user-created',
      name: 'Welcome New User',
      subject: 'Welcome to Laboratory Management System',
      html: `
        <h2>Welcome to Laboratory Management System</h2>
        <p>Hello {{userName}},</p>
        <p>Your account has been created successfully.</p>
        <p><strong>Username:</strong> {{username}}</p>
        <p><strong>Role:</strong> {{role}}</p>
        <p>Please change your password on first login.</p>
        <p>Best regards,<br>Laboratory Management System</p>
      `,
      variables: ['userName', 'username', 'role']
    }
  ];

  configure(config: EmailConfig): void {
    this.config = config;
    // Store config securely (in production, use encrypted storage)
    localStorage.setItem('email_config', JSON.stringify(config));
    
    toast({
      title: "Email configured",
      description: "SMTP settings have been saved"
    });
  }

  getConfig(): EmailConfig | null {
    if (this.config) return this.config;
    
    try {
      const stored = localStorage.getItem('email_config');
      if (stored) {
        this.config = JSON.parse(stored);
        return this.config;
      }
    } catch (error) {
      console.error('Failed to load email config:', error);
    }
    
    return null;
  }

  async sendEmail(message: EmailMessage): Promise<boolean> {
    const config = this.getConfig();
    
    if (!config) {
      toast({
        title: "Email not configured",
        description: "Please configure SMTP settings first",
        variant: "destructive"
      });
      return false;
    }

    try {
      // Check if running in Electron
      if (window.electronAPI) {
        // Use Electron's email sending capability
        const result = await window.electronAPI.sendEmail({
          config,
          message
        });
        
        if (result.success) {
          toast({
            title: "Email sent",
            description: `Email sent to ${message.to.join(', ')}`
          });
          return true;
        } else {
          throw new Error(result.error);
        }
      } else {
        // Browser fallback - simulate sending
        console.log('Email would be sent:', { config, message });
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        toast({
          title: "Email simulated",
          description: `Email would be sent to ${message.to.join(', ')} (browser mode)`
        });
        return true;
      }
    } catch (error) {
      console.error('Failed to send email:', error);
      toast({
        title: "Email failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive"
      });
      return false;
    }
  }

  getTemplates(): EmailTemplate[] {
    return this.templates;
  }

  getTemplate(id: string): EmailTemplate | undefined {
    return this.templates.find(t => t.id === id);
  }

  async sendTemplateEmail(
    templateId: string, 
    to: string[], 
    variables: Record<string, string>,
    attachments?: EmailAttachment[]
  ): Promise<boolean> {
    const template = this.getTemplate(templateId);
    if (!template) {
      toast({
        title: "Template not found",
        description: `Email template ${templateId} not found`,
        variant: "destructive"
      });
      return false;
    }

    // Replace variables in template
    let subject = template.subject;
    let html = template.html;

    Object.entries(variables).forEach(([key, value]) => {
      const placeholder = new RegExp(`{{${key}}}`, 'g');
      subject = subject.replace(placeholder, value);
      html = html.replace(placeholder, value);
    });

    return this.sendEmail({
      to,
      subject,
      html,
      attachments
    });
  }

  // Notification helpers
  async notifyTestCompleted(testId: string, results: string, recipientEmail: string): Promise<boolean> {
    return this.sendTemplateEmail('test-completed', [recipientEmail], {
      testId,
      results,
      recipientName: recipientEmail.split('@')[0],
      date: new Date().toLocaleString()
    });
  }

  async notifyMemoCreated(memo: any, recipientEmails: string[]): Promise<boolean> {
    return this.sendTemplateEmail('memo-created', recipientEmails, {
      title: memo.title,
      content: memo.content,
      priority: memo.priority,
      recipientName: 'Team',
      date: new Date().toLocaleString()
    });
  }

  async notifyUserCreated(user: any, recipientEmail: string): Promise<boolean> {
    return this.sendTemplateEmail('user-created', [recipientEmail], {
      userName: user.full_name || user.username,
      username: user.username,
      role: user.role
    });
  }

  testConnection(): Promise<boolean> {
    const config = this.getConfig();
    
    if (!config) {
      toast({
        title: "No configuration",
        description: "Please configure SMTP settings first",
        variant: "destructive"
      });
      return Promise.resolve(false);
    }

    return this.sendEmail({
      to: [config.fromEmail],
      subject: 'SMTP Test Connection',
      html: '<h2>SMTP Test</h2><p>This is a test email to verify SMTP configuration.</p>'
    });
  }
}

export const emailService = new EmailService();