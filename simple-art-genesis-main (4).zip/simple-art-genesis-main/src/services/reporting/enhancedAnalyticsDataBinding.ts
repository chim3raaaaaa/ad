// Enhanced Analytics Data Binding Service
import { ReportsAPI } from '@/services/api/reportsAPI';
import { EnhancedAnalyticsIntegration, ChartDefinition, LiveChartData } from './enhancedAnalyticsIntegration';
import { DataBindingService, ReportData } from './dataBindingService';

export interface ChartBinding {
  chartId: string;
  elementId: string;
  config: ChartBindingConfig;
  filters: ChartFilter[];
  refreshInterval?: number;
}

export interface ChartBindingConfig {
  dataSource: 'live' | 'memo' | 'template';
  memoId?: string;
  dateRange?: {
    start: string;
    end: string;
  };
  productFilter?: string[];
  plantFilter?: string[];
  customFilters?: Record<string, any>;
  styling?: {
    width?: number;
    height?: number;
    theme?: string;
    colors?: string[];
  };
}

export interface ChartFilter {
  field: string;
  operator: 'equals' | 'contains' | 'range' | 'greater' | 'less';
  value: any;
  displayName: string;
}

export interface AnalyticsElement {
  id: string;
  type: 'chart';
  chartType: string;
  title: string;
  binding: ChartBinding;
  data?: any;
  isLoading?: boolean;
  error?: string;
}

export class EnhancedAnalyticsDataBinding {
  private static dataBindingService = new DataBindingService();
  private static chartCache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  /**
   * Get all available charts with enhanced metadata
   */
  static async getAvailableChartsWithMetadata(): Promise<ChartDefinition[]> {
    try {
      // Try API first (cross-platform)
      const apiCharts = await ReportsAPI.getAnalyticsCharts();
      if (apiCharts.length > 0) {
        return this.enhanceChartDefinitions(apiCharts);
      }

      // Fallback to Electron API
      const electronCharts = await EnhancedAnalyticsIntegration.getAvailableCharts();
      return this.enhanceChartDefinitions(electronCharts);
    } catch (error) {
      console.error('Failed to get charts:', error);
      return this.getDefaultChartDefinitions();
    }
  }

  /**
   * Enhance chart definitions with additional metadata
   */
  private static enhanceChartDefinitions(charts: any[]): ChartDefinition[] {
    return charts.map(chart => ({
      ...chart,
      category: this.getCategoryFromType(chart.chart_type || chart.type),
      icon: this.getIconFromType(chart.chart_type || chart.type),
      isAvailable: true,
      config: {
        ...chart.config,
        chartType: chart.chart_type || chart.type,
        styling: {
          colors: this.getDefaultColors(chart.chart_type || chart.type),
          showGrid: true,
          showLegend: true,
          showTrendline: false,
          ...chart.config?.styling
        }
      }
    }));
  }

  /**
   * Create chart binding for template elements
   */
  static createChartBinding(
    chartId: string,
    elementId: string,
    config: Partial<ChartBindingConfig> = {}
  ): ChartBinding {
    return {
      chartId,
      elementId,
      config: {
        dataSource: 'live',
        styling: {
          width: 400,
          height: 300,
          theme: 'default',
          colors: this.getDefaultColors()
        },
        ...config
      },
      filters: [],
      refreshInterval: 300000 // 5 minutes default
    };
  }

  /**
   * Bind chart data to template element
   */
  static async bindChartData(
    binding: ChartBinding,
    reportData?: ReportData
  ): Promise<AnalyticsElement> {
    const cacheKey = this.getCacheKey(binding);
    const cached = this.chartCache.get(cacheKey);
    
    // Return cached data if still valid
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return {
        id: binding.elementId,
        type: 'chart',
        chartType: binding.chartId,
        title: await this.getChartTitle(binding.chartId),
        binding,
        data: cached.data,
        isLoading: false
      };
    }

    try {
      let chartData: any;

      // Get data based on source
      switch (binding.config.dataSource) {
        case 'memo':
          chartData = await this.getMemoChartData(binding, reportData);
          break;
        case 'template':
          chartData = await this.getTemplateChartData(binding);
          break;
        case 'live':
        default:
          chartData = await this.getLiveChartData(binding);
          break;
      }

      // Apply filters
      if (binding.filters.length > 0) {
        chartData = this.applyFilters(chartData, binding.filters);
      }

      // Cache the result
      this.chartCache.set(cacheKey, {
        data: chartData,
        timestamp: Date.now(),
        ttl: binding.refreshInterval || 300000
      });

      return {
        id: binding.elementId,
        type: 'chart',
        chartType: binding.chartId,
        title: await this.getChartTitle(binding.chartId),
        binding,
        data: chartData,
        isLoading: false
      };
    } catch (error) {
      console.error('Failed to bind chart data:', error);
      return {
        id: binding.elementId,
        type: 'chart',
        chartType: binding.chartId,
        title: await this.getChartTitle(binding.chartId),
        binding,
        data: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Failed to load chart data'
      };
    }
  }

  /**
   * Get live chart data from analytics service
   */
  private static async getLiveChartData(binding: ChartBinding): Promise<any> {
    try {
      // Try API first
      const apiData = await ReportsAPI.getChartData(binding.chartId, binding.config.memoId);
      if (apiData) {
        return this.transformChartData(apiData, binding);
      }

      // Fallback to Electron
      const electronData = await EnhancedAnalyticsIntegration.getChartData(
        binding.chartId,
        binding.config.memoId,
        binding.config.customFilters
      );
      
      return electronData ? this.transformChartData(electronData, binding) : null;
    } catch (error) {
      console.error('Failed to get live chart data:', error);
      return this.generateMockData(binding.chartId);
    }
  }

  /**
   * Get memo-specific chart data
   */
  private static async getMemoChartData(binding: ChartBinding, reportData?: ReportData): Promise<any> {
    if (!reportData || !binding.config.memoId) {
      return this.generateMockData(binding.chartId);
    }

    // Use bound memo data for charts
    const analyticsData = this.dataBindingService.getAnalyticsData(binding.chartId, reportData);
    return this.transformAnalyticsData(analyticsData, binding);
  }

  /**
   * Get template-based chart data (static/mock)
   */
  private static async getTemplateChartData(binding: ChartBinding): Promise<any> {
    return this.generateMockData(binding.chartId);
  }

  /**
   * Transform chart data for consistent format
   */
  private static transformChartData(data: LiveChartData | any, binding: ChartBinding): any {
    if (!data) return null;

    // Handle LiveChartData format
    if (data.chartId && data.data) {
      return {
        ...data.data,
        metadata: data.metadata,
        lastUpdated: data.lastUpdated
      };
    }

    // Handle direct data
    return data;
  }

  /**
   * Transform analytics data from DataBindingService
   */
  private static transformAnalyticsData(analyticsData: any, binding: ChartBinding): any {
    const chartType = binding.chartId;

    switch (chartType) {
      case 'sieve-analysis':
        return analyticsData.sieveAnalysis || [];
      case 'strength-trend':
        return analyticsData.strengthData || [];
      case 'fineness-trend':
        return [{ value: analyticsData.fineness || 2.65, target: 2.8 }];
      case 'water-absorption':
        return [{ value: analyticsData.waterAbsorption || 1.2, target: 2.0 }];
      case 'conformity-heatmap':
        return analyticsData.conformityData || [];
      default:
        return analyticsData;
    }
  }

  /**
   * Apply filters to chart data
   */
  private static applyFilters(data: any, filters: ChartFilter[]): any {
    if (!data || !Array.isArray(data)) return data;

    return data.filter(item => {
      return filters.every(filter => {
        const value = item[filter.field];
        if (value === undefined) return true;

        switch (filter.operator) {
          case 'equals':
            return value === filter.value;
          case 'contains':
            return String(value).toLowerCase().includes(String(filter.value).toLowerCase());
          case 'greater':
            return Number(value) > Number(filter.value);
          case 'less':
            return Number(value) < Number(filter.value);
          case 'range':
            return Number(value) >= filter.value.min && Number(value) <= filter.value.max;
          default:
            return true;
        }
      });
    });
  }

  /**
   * Generate mock data for fallback
   */
  private static generateMockData(chartType: string): any {
    switch (chartType) {
      case 'sieve-analysis':
        return [
          { size: '10mm', passing: 95 },
          { size: '5mm', passing: 75 },
          { size: '2.36mm', passing: 55 },
          { size: '1.18mm', passing: 35 },
          { size: '0.6mm', passing: 25 },
          { size: '0.3mm', passing: 15 },
          { size: '0.15mm', passing: 8 },
          { size: '0.075mm', passing: 3 }
        ];
      
      case 'strength-trend':
        return [
          { age: 7, strength: 25.5, target: 20 },
          { age: 14, strength: 32.8, target: 30 },
          { age: 28, strength: 42.1, target: 40 }
        ];
      
      case 'fineness-trend':
        return [{ value: 2.65, target: 2.8, status: 'pass' }];
      
      case 'water-absorption':
        return [
          { range: 'Low (< 2%)', count: 15, percentage: 60 },
          { range: 'Medium (2-4%)', count: 8, percentage: 32 },
          { range: 'High (4-6%)', count: 2, percentage: 8 },
          { range: 'Very High (> 6%)', count: 0, percentage: 0 }
        ];
      
      case 'conformity-heatmap':
        return [
          { date: '2024-01-01', test_type: 'Compressive', value: 1, status: 'pass' },
          { date: '2024-01-01', test_type: 'Absorption', value: 1, status: 'pass' },
          { date: '2024-01-02', test_type: 'Compressive', value: -1, status: 'fail' },
          { date: '2024-01-02', test_type: 'Absorption', value: 1, status: 'pass' }
        ];
      
      default:
        return [];
    }
  }

  /**
   * Get default chart definitions for fallback
   */
  private static getDefaultChartDefinitions(): ChartDefinition[] {
    return [
      {
        id: 'sieve-analysis',
        type: 'sieve-analysis',
        name: 'Sieve Analysis',
        description: 'Particle size distribution analysis',
        category: 'aggregates',
        icon: 'BarChart3',
        dataSource: 'test_results',
        config: {
          chartType: 'bar',
          xAxis: 'size',
          yAxis: 'passing',
          styling: { colors: ['#3b82f6'], showGrid: true, showLegend: false }
        },
        isAvailable: true
      },
      {
        id: 'strength-trend',
        type: 'strength-trend',
        name: 'Strength Trend',
        description: 'Compressive strength over time',
        category: 'concrete',
        icon: 'TrendingUp',
        dataSource: 'test_results',
        config: {
          chartType: 'line',
          xAxis: 'age',
          yAxis: 'strength',
          styling: { colors: ['#10b981', '#ef4444'], showGrid: true, showLegend: true }
        },
        isAvailable: true
      },
      {
        id: 'fineness-trend',
        type: 'fineness-trend',
        name: 'Fineness Modulus',
        description: 'Fineness modulus gauge',
        category: 'aggregates',
        icon: 'Gauge',
        dataSource: 'test_results',
        config: {
          chartType: 'gauge',
          dataKey: 'value',
          styling: { colors: ['#10b981', '#f59e0b', '#ef4444'] }
        },
        isAvailable: true
      },
      {
        id: 'water-absorption',
        type: 'water-absorption',
        name: 'Water Absorption',
        description: 'Water absorption distribution',
        category: 'aggregates',
        icon: 'PieChart',
        dataSource: 'test_results',
        config: {
          chartType: 'pie',
          dataKey: 'percentage',
          styling: { colors: ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6'] }
        },
        isAvailable: true
      },
      {
        id: 'conformity-heatmap',
        type: 'conformity-heatmap',
        name: 'Conformity Heatmap',
        description: 'Test conformity over time',
        category: 'quality',
        icon: 'Grid3x3',
        dataSource: 'test_results',
        config: {
          chartType: 'heatmap',
          xAxis: 'date',
          yAxis: 'test_type',
          styling: { colors: ['#ef4444', '#f59e0b', '#10b981'] }
        },
        isAvailable: true
      }
    ];
  }

  /**
   * Utility methods
   */
  private static getCacheKey(binding: ChartBinding): string {
    return `${binding.chartId}-${binding.elementId}-${JSON.stringify(binding.config)}-${JSON.stringify(binding.filters)}`;
  }

  private static async getChartTitle(chartId: string): Promise<string> {
    const charts = await this.getAvailableChartsWithMetadata();
    const chart = charts.find(c => c.id === chartId);
    return chart?.name || 'Chart';
  }

  private static getCategoryFromType(chartType: string): string {
    if (chartType.includes('sieve') || chartType.includes('fineness') || chartType.includes('absorption')) {
      return 'aggregates';
    }
    if (chartType.includes('strength') || chartType.includes('concrete') || chartType.includes('cube')) {
      return 'concrete';
    }
    if (chartType.includes('conformity') || chartType.includes('quality')) {
      return 'quality';
    }
    return 'general';
  }

  private static getIconFromType(chartType: string): string {
    switch (chartType) {
      case 'bar': return 'BarChart3';
      case 'line': return 'TrendingUp';
      case 'pie': return 'PieChart';
      case 'gauge': return 'Gauge';
      case 'heatmap': return 'Grid3x3';
      case 'scatter': return 'Scatter';
      default: return 'BarChart3';
    }
  }

  private static getDefaultColors(chartType?: string): string[] {
    switch (chartType) {
      case 'pie':
        return ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
      case 'heatmap':
        return ['#ef4444', '#f59e0b', '#10b981'];
      case 'gauge':
        return ['#10b981', '#f59e0b', '#ef4444'];
      default:
        return ['#3b82f6', '#10b981'];
    }
  }

  /**
   * Clear chart cache
   */
  static clearCache(chartId?: string): void {
    if (chartId) {
      for (const [key] of this.chartCache.entries()) {
        if (key.startsWith(chartId)) {
          this.chartCache.delete(key);
        }
      }
    } else {
      this.chartCache.clear();
    }
  }

  /**
   * Refresh chart data
   */
  static async refreshChartData(binding: ChartBinding, reportData?: ReportData): Promise<AnalyticsElement> {
    // Clear cache for this binding
    const cacheKey = this.getCacheKey(binding);
    this.chartCache.delete(cacheKey);
    
    // Fetch fresh data
    return this.bindChartData(binding, reportData);
  }
}