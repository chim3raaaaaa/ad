export interface ReportData {
  memoId: string;
  memoRef: string;
  testData: any;
  analyticsData: any;
  attachments: any[];
}

export class DataBindingService {
  /**
   * Get field value from report data based on field name
   */
  getFieldValue(fieldName: string, reportData: ReportData): string {
    const fieldMap: { [key: string]: string } = {
      // Memo fields
      'memo-ref': reportData.memoRef,
      'memo-reference': reportData.memoRef,
      'reference': reportData.memoRef,
      
      // Test data fields
      'date-sampling': this.formatDate(reportData.testData?.samplingDate),
      'sampling-date': this.formatDate(reportData.testData?.samplingDate),
      'officer': reportData.testData?.officer || 'N/A',
      'testing-officer': reportData.testData?.officer || 'N/A',
      'plant': reportData.testData?.plant || 'N/A',
      'test-type': reportData.testData?.testType || 'N/A',
      
      // Product-specific fields
      'material-type': reportData.testData?.materialType || 'N/A',
      'aggregate-type': reportData.testData?.materialType || 'N/A',
      'fineness-modulus': this.formatNumber(reportData.analyticsData?.fineness),
      'specific-gravity': this.formatNumber(reportData.testData?.specificGravity),
      'water-absorption': this.formatPercentage(reportData.analyticsData?.waterAbsorption),
      
      // Concrete fields
      'mix-design': reportData.testData?.mixDesign || 'N/A',
      'slump-test': this.formatNumber(reportData.analyticsData?.slump, 'mm'),
      'compressive-strength': this.formatNumber(reportData.testData?.compressiveStrength, 'MPa'),
      'cube-details': reportData.testData?.cubeDetails || 'N/A',
      
      // Block fields
      'block-dimensions': this.formatDimensions(reportData.testData?.blockDimensions),
      'density': this.formatNumber(reportData.testData?.density, 'kg/m³'),
      
      // Paver fields
      'paver-thickness': this.formatNumber(reportData.testData?.paverThickness, 'mm'),
      'slip-resistance': reportData.testData?.slipResistance || 'N/A',
      'freeze-thaw': reportData.testData?.freezeThaw || 'N/A',
      
      // Kerb fields
      'kerb-profile': reportData.testData?.kerbProfile || 'N/A',
      'impact-strength': this.formatNumber(reportData.testData?.impactStrength, 'J'),
      
      // Flagstone fields
      'surface-finish': reportData.testData?.surfaceFinish || 'N/A',
      'weathering-resistance': reportData.testData?.weatheringResistance || 'N/A',
      
      // General fields
      'generated-date': new Date().toLocaleDateString(),
      'generated-time': new Date().toLocaleTimeString(),
      'report-title': `Test Report - ${reportData.memoRef}`,
      'lab-name': 'UBP Mauritius Laboratory',
      'lab-address': 'Port Louis, Mauritius',
      'lab-phone': '+230 123 4567'
    };
    
    // Check if field exists in map
    const value = fieldMap[fieldName.toLowerCase()];
    if (value !== undefined) {
      return value;
    }
    
    // Try to get from nested data
    const nestedValue = this.getNestedValue(reportData, fieldName);
    if (nestedValue !== null) {
      return String(nestedValue);
    }
    
    // Return placeholder if field not found
    return `[${fieldName}]`;
  }

  /**
   * Get nested value from object using dot notation
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : null;
    }, obj);
  }

  /**
   * Format date value
   */
  private formatDate(date: any): string {
    if (!date) return 'N/A';
    
    if (typeof date === 'string') {
      const parsedDate = new Date(date);
      return isNaN(parsedDate.getTime()) ? date : parsedDate.toLocaleDateString();
    }
    
    if (date instanceof Date) {
      return date.toLocaleDateString();
    }
    
    return String(date);
  }

  /**
   * Format number with optional unit
   */
  private formatNumber(value: any, unit?: string): string {
    if (value === null || value === undefined || value === '') return 'N/A';
    
    const num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return 'N/A';
    
    const formatted = num.toFixed(2).replace(/\.?0+$/, '');
    return unit ? `${formatted} ${unit}` : formatted;
  }

  /**
   * Format percentage value
   */
  private formatPercentage(value: any): string {
    if (value === null || value === undefined || value === '') return 'N/A';
    
    const num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return 'N/A';
    
    return `${num.toFixed(2)}%`;
  }

  /**
   * Format dimensions object
   */
  private formatDimensions(dimensions: any): string {
    if (!dimensions) return 'N/A';
    
    if (typeof dimensions === 'string') return dimensions;
    
    if (typeof dimensions === 'object') {
      const { length, width, height } = dimensions;
      if (length && width && height) {
        return `${length}mm × ${width}mm × ${height}mm`;
      }
      if (length && width) {
        return `${length}mm × ${width}mm`;
      }
    }
    
    return 'N/A';
  }

  /**
   * Get analytics data for charts
   */
  getAnalyticsData(chartType: string, reportData: ReportData): any {
    switch (chartType) {
      case 'sieve-analysis':
        return {
          sieveAnalysis: reportData.analyticsData?.sieveAnalysis || this.getMockSieveData()
        };
      
      case 'strength-trend':
        return {
          strengthData: reportData.analyticsData?.strengthData || this.getMockStrengthData()
        };
      
      case 'fineness-trend':
        return {
          fineness: reportData.analyticsData?.fineness || 2.65
        };
      
      case 'water-absorption':
        return {
          waterAbsorption: reportData.analyticsData?.waterAbsorption || 1.2
        };
      
      case 'conformity-heatmap':
        return {
          conformityData: reportData.analyticsData?.conformityData || this.getMockConformityData()
        };
      
      default:
        return reportData.analyticsData || {};
    }
  }

  /**
   * Get mock sieve data for fallback
   */
  private getMockSieveData() {
    return [
      { size: '10mm', passing: 95 },
      { size: '5mm', passing: 75 },
      { size: '2.36mm', passing: 55 },
      { size: '1.18mm', passing: 35 },
      { size: '0.6mm', passing: 25 },
      { size: '0.3mm', passing: 15 },
      { size: '0.15mm', passing: 8 },
      { size: '0.075mm', passing: 3 }
    ];
  }

  /**
   * Get mock strength data for fallback
   */
  private getMockStrengthData() {
    return [
      { age: 7, strength: 25.5 },
      { age: 14, strength: 32.8 },
      { age: 28, strength: 42.1 }
    ];
  }

  /**
   * Get mock conformity data for fallback
   */
  private getMockConformityData() {
    return [
      { test: 'Compressive Strength', status: 'pass' },
      { test: 'Water Absorption', status: 'pass' },
      { test: 'Density', status: 'warning' },
      { test: 'Dimensions', status: 'pass' }
    ];
  }

  /**
   * Bind real memo data to template
   */
  async bindMemoData(memoId: string): Promise<ReportData> {
    try {
      // Fetch memo data from SQLite
      if (window.electronAPI) {
        const memoQuery = `
          SELECT * FROM memos WHERE id = ?
        `;
        const memoResults = await window.electronAPI.dbQuery(memoQuery, [memoId]);
        
        if (memoResults.length === 0) {
          throw new Error('Memo not found');
        }
        
        const memo = memoResults[0];
        
        // Fetch related test data
        const testQuery = `
          SELECT * FROM test_results WHERE memo_id = ?
        `;
        const testResults = await window.electronAPI.dbQuery(testQuery, [memoId]);
        
        // Fetch attachments
        const attachmentQuery = `
          SELECT * FROM report_template_attachments WHERE linked_to = ?
        `;
        const attachments = await window.electronAPI.dbQuery(attachmentQuery, [memoId]);
        
        return {
          memoId: memo.id,
          memoRef: memo.memo_ref,
          testData: {
            officer: memo.officer_in_charge,
            plant: memo.lab_site,
            samplingDate: memo.created_at,
            testType: memo.product_type,
            ...testResults[0] // Merge test result data
          },
          analyticsData: await this.getAnalyticsForMemo(memoId),
          attachments: attachments
        };
      }
      
      // Fallback to mock data if Electron not available
      return this.getMockReportData(memoId);
    } catch (error) {
      console.error('Error binding memo data:', error);
      return this.getMockReportData(memoId);
    }
  }

  /**
   * Get analytics data for specific memo
   */
  private async getAnalyticsForMemo(memoId: string): Promise<any> {
    try {
      if (window.electronAPI) {
        // This would fetch from analytics tables
        // For now, return mock data
        return {
          fineness: 2.65,
          waterAbsorption: 1.2,
          sieveAnalysis: this.getMockSieveData(),
          strengthData: this.getMockStrengthData(),
          conformityData: this.getMockConformityData()
        };
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
    
    return {};
  }

  /**
   * Get mock report data for fallback
   */
  private getMockReportData(memoId: string): ReportData {
    return {
      memoId,
      memoRef: `MOCK-${memoId.slice(-6)}`,
      testData: {
        officer: 'Test Officer',
        plant: 'Test Plant',
        samplingDate: new Date().toISOString(),
        testType: 'Aggregates',
        materialType: 'Crushed Stone',
        specificGravity: 2.65,
        compressiveStrength: 42.1
      },
      analyticsData: {
        fineness: 2.65,
        waterAbsorption: 1.2,
        sieveAnalysis: this.getMockSieveData(),
        strengthData: this.getMockStrengthData(),
        conformityData: this.getMockConformityData()
      },
      attachments: []
    };
  }
}