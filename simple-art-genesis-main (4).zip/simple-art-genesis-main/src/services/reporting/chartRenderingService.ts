// Chart rendering service for PDF export

export class ChartRenderingService {
  private static canvas: HTMLCanvasElement | null = null;

  /**
   * Generate chart image for PDF embedding
   */
  async generateChartImage(
    chartType: string,
    chartConfig: any,
    data: any
  ): Promise<Blob | null> {
    try {
      // Create off-screen canvas for chart rendering
      const canvas = this.getCanvas();
      const ctx = canvas.getContext('2d');
      
      if (!ctx) return null;

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Generate chart based on type
      switch (chartType) {
        case 'sieve-analysis':
          return await this.generateSieveChart(canvas, data);
        case 'strength-trend':
          return await this.generateStrengthChart(canvas, data);
        case 'fineness-trend':
          return await this.generateFinenessChart(canvas, data);
        case 'water-absorption':
          return await this.generateWaterAbsorptionChart(canvas, data);
        case 'conformity-heatmap':
          return await this.generateConformityChart(canvas, data);
        default:
          return await this.generateGenericChart(canvas, chartType, data);
      }
    } catch (error) {
      console.error('Chart rendering error:', error);
      return null;
    }
  }

  /**
   * Get or create off-screen canvas
   */
  private getCanvas(): HTMLCanvasElement {
    if (!ChartRenderingService.canvas) {
      ChartRenderingService.canvas = document.createElement('canvas');
      ChartRenderingService.canvas.width = 600;
      ChartRenderingService.canvas.height = 400;
    }
    return ChartRenderingService.canvas;
  }

  /**
   * Generate sieve analysis chart
   */
  private async generateSieveChart(canvas: HTMLCanvasElement, data: any): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    const sieveData = data.sieveAnalysis || [];
    
    if (sieveData.length === 0) {
      return this.generatePlaceholderChart(canvas, 'Sieve Analysis');
    }

    // Chart dimensions
    const padding = 50;
    const chartWidth = canvas.width - 2 * padding;
    const chartHeight = canvas.height - 2 * padding;

    // Draw axes
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.stroke();

    // Draw title
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Sieve Analysis', canvas.width / 2, 30);

    // Draw data points and line
    ctx.strokeStyle = '#2563eb';
    ctx.fillStyle = '#2563eb';
    ctx.lineWidth = 2;
    ctx.beginPath();

    sieveData.forEach((point: any, index: number) => {
      const x = padding + (index / (sieveData.length - 1)) * chartWidth;
      const y = canvas.height - padding - (point.passing / 100) * chartHeight;
      
      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
      
      // Draw data point
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, 2 * Math.PI);
      ctx.fill();
      ctx.beginPath();
    });
    
    ctx.stroke();

    // Draw labels
    ctx.fillStyle = '#666';
    ctx.font = '10px Arial';
    ctx.textAlign = 'center';
    sieveData.forEach((point: any, index: number) => {
      const x = padding + (index / (sieveData.length - 1)) * chartWidth;
      ctx.fillText(point.size, x, canvas.height - padding + 15);
    });

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }

  /**
   * Generate strength trend chart
   */
  private async generateStrengthChart(canvas: HTMLCanvasElement, data: any): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    const strengthData = data.strengthData || [];
    
    if (strengthData.length === 0) {
      return this.generatePlaceholderChart(canvas, 'Strength Trend');
    }

    const padding = 50;
    const chartWidth = canvas.width - 2 * padding;
    const chartHeight = canvas.height - 2 * padding;

    // Draw axes
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.stroke();

    // Draw title
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Compressive Strength Over Time', canvas.width / 2, 30);

    // Draw bars
    const barWidth = chartWidth / strengthData.length * 0.8;
    const maxStrength = Math.max(...strengthData.map((d: any) => d.strength));

    strengthData.forEach((point: any, index: number) => {
      const x = padding + (index + 0.1) * (chartWidth / strengthData.length);
      const barHeight = (point.strength / maxStrength) * chartHeight;
      const y = canvas.height - padding - barHeight;
      
      // Draw bar
      ctx.fillStyle = '#10b981';
      ctx.fillRect(x, y, barWidth, barHeight);
      
      // Draw value label
      ctx.fillStyle = '#333';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${point.strength} MPa`, x + barWidth/2, y - 5);
      
      // Draw age label
      ctx.fillText(`${point.age} days`, x + barWidth/2, canvas.height - padding + 15);
    });

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }

  /**
   * Generate fineness modulus trend chart
   */
  private async generateFinenessChart(canvas: HTMLCanvasElement, data: any): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    
    // Mock fineness data if not available
    const fineness = data.fineness || 2.65;
    
    const padding = 50;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 80;

    // Draw title
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Fineness Modulus', centerX, 30);

    // Draw gauge background
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0.75 * Math.PI, 0.25 * Math.PI);
    ctx.stroke();

    // Draw gauge value
    const angle = 0.75 * Math.PI + ((fineness - 1) / 5) * 1.5 * Math.PI;
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0.75 * Math.PI, angle);
    ctx.stroke();

    // Draw value text
    ctx.fillStyle = '#333';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(fineness.toFixed(2), centerX, centerY + 10);
    
    ctx.font = '14px Arial';
    ctx.fillText('FM Value', centerX, centerY + 30);

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }

  /**
   * Generate water absorption pie chart
   */
  private async generateWaterAbsorptionChart(canvas: HTMLCanvasElement, data: any): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    const waterAbsorption = data.waterAbsorption || 1.2;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 100;

    // Draw title
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Water Absorption', centerX, 30);

    // Calculate angles
    const absorptionAngle = (waterAbsorption / 5) * 2 * Math.PI; // Assuming max 5%
    const remainingAngle = 2 * Math.PI - absorptionAngle;

    // Draw absorbed portion
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, -Math.PI/2, -Math.PI/2 + absorptionAngle);
    ctx.closePath();
    ctx.fill();

    // Draw remaining portion
    ctx.fillStyle = '#e5e7eb';
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, -Math.PI/2 + absorptionAngle, -Math.PI/2 + 2 * Math.PI);
    ctx.closePath();
    ctx.fill();

    // Draw percentage text
    ctx.fillStyle = '#333';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${waterAbsorption}%`, centerX, centerY + 5);

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }

  /**
   * Generate conformity heatmap
   */
  private async generateConformityChart(canvas: HTMLCanvasElement, data: any): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    
    // Mock conformity data
    const conformityData = data.conformityData || [
      { test: 'Compressive Strength', status: 'pass' },
      { test: 'Water Absorption', status: 'pass' },
      { test: 'Density', status: 'warning' },
      { test: 'Dimensions', status: 'pass' }
    ];

    const padding = 50;
    const cellHeight = 40;
    const cellWidth = 120;

    // Draw title
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Conformity Status', canvas.width / 2, 30);

    // Draw conformity cells
    conformityData.forEach((item: any, index: number) => {
      const x = padding;
      const y = padding + 30 + index * (cellHeight + 10);
      
      // Set color based on status
      let color = '#10b981'; // green for pass
      if (item.status === 'warning') color = '#f59e0b'; // yellow for warning
      if (item.status === 'fail') color = '#ef4444'; // red for fail
      
      // Draw cell
      ctx.fillStyle = color;
      ctx.fillRect(x, y, cellWidth, cellHeight);
      
      // Draw text
      ctx.fillStyle = '#fff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'left';
      ctx.fillText(item.test, x + 10, y + 15);
      ctx.fillText(item.status.toUpperCase(), x + 10, y + 30);
    });

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }

  /**
   * Generate generic chart for unknown types
   */
  private async generateGenericChart(canvas: HTMLCanvasElement, chartType: string, data: any): Promise<Blob> {
    return this.generatePlaceholderChart(canvas, chartType);
  }

  /**
   * Generate placeholder chart
   */
  private async generatePlaceholderChart(canvas: HTMLCanvasElement, title: string): Promise<Blob> {
    const ctx = canvas.getContext('2d')!;
    
    // Clear canvas
    ctx.fillStyle = '#f9fafb';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw border
    ctx.strokeStyle = '#d1d5db';
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    
    // Draw placeholder text
    ctx.fillStyle = '#6b7280';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`[${title}]`, canvas.width / 2, canvas.height / 2);
    
    ctx.font = '14px Arial';
    ctx.fillText('Chart data not available', canvas.width / 2, canvas.height / 2 + 30);

    return new Promise(resolve => canvas.toBlob(resolve as BlobCallback, 'image/png'));
  }
}