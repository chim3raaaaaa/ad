import jsPDF from 'jspdf';
import { ChartRenderingService } from './chartRenderingService';
import { DataBindingService } from './dataBindingService';

export interface CanvasBlock {
  id: string;
  type: 'field' | 'static' | 'chart' | 'attachment';
  x: number;
  y: number;
  width: number;
  height: number;
  content?: any;
  fieldName?: string;
  chartType?: string;
  chartConfig?: any;
  filePath?: string;
  styles?: {
    fontSize?: number;
    fontWeight?: string;
    color?: string;
    backgroundColor?: string;
  };
}

export interface ReportTemplate {
  id: string;
  name: string;
  productType: string;
  blocks: CanvasBlock[];
  layoutJson: string;
  memoBinding?: any;
}

export interface ReportData {
  memoId: string;
  memoRef: string;
  testData: any;
  analyticsData: any;
  attachments: any[];
}

export class TemplateToPdfService {
  private static chartService = new ChartRenderingService();
  private static dataService = new DataBindingService();

  /**
   * Generate PDF from template blocks with real data binding
   */
  static async generateFromTemplate(
    template: ReportTemplate, 
    reportData: ReportData,
    watermark?: string
  ): Promise<Blob> {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Add watermark if specified
    if (watermark) {
      this.addWatermark(pdf, watermark);
    }

    // Process each canvas block
    for (const block of template.blocks) {
      await this.renderBlock(pdf, block, reportData);
    }

    return pdf.output('blob');
  }

  /**
   * Render individual block on PDF based on its type
   */
  private static async renderBlock(
    pdf: jsPDF, 
    block: CanvasBlock, 
    reportData: ReportData
  ): Promise<void> {
    const pdfX = block.x * 0.264583; // Convert pixels to mm (96 DPI to 72 DPI)
    const pdfY = block.y * 0.264583;
    const pdfWidth = block.width * 0.264583;
    const pdfHeight = block.height * 0.264583;

    switch (block.type) {
      case 'field':
        await this.renderFieldBlock(pdf, block, reportData, pdfX, pdfY);
        break;
      
      case 'static':
        await this.renderStaticBlock(pdf, block, pdfX, pdfY);
        break;
      
      case 'chart':
        await this.renderChartBlock(pdf, block, reportData, pdfX, pdfY, pdfWidth, pdfHeight);
        break;
      
      case 'attachment':
        await this.renderAttachmentBlock(pdf, block, reportData, pdfX, pdfY, pdfWidth, pdfHeight);
        break;
    }
  }

  /**
   * Render field block with real data
   */
  private static async renderFieldBlock(
    pdf: jsPDF,
    block: CanvasBlock,
    reportData: ReportData,
    x: number,
    y: number
  ): Promise<void> {
    const fieldValue = this.dataService.getFieldValue(block.fieldName || '', reportData);
    
    // Apply styles
    const fontSize = block.styles?.fontSize || 12;
    const fontWeight = block.styles?.fontWeight === 'bold' ? 'bold' : 'normal';
    
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', fontWeight);
    
    if (block.styles?.color) {
      const color = this.hexToRgb(block.styles.color);
      pdf.setTextColor(color.r, color.g, color.b);
    }

    // Add background if specified
    if (block.styles?.backgroundColor) {
      const bgColor = this.hexToRgb(block.styles.backgroundColor);
      pdf.setFillColor(bgColor.r, bgColor.g, bgColor.b);
      pdf.rect(x, y - fontSize * 0.264583, 100, fontSize * 0.264583, 'F');
    }

    pdf.text(fieldValue, x, y);
  }

  /**
   * Render static text/element block
   */
  private static async renderStaticBlock(
    pdf: jsPDF,
    block: CanvasBlock,
    x: number,
    y: number
  ): Promise<void> {
    const content = block.content || '';
    const fontSize = block.styles?.fontSize || 12;
    const fontWeight = block.styles?.fontWeight === 'bold' ? 'bold' : 'normal';
    
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', fontWeight);
    
    if (block.styles?.color) {
      const color = this.hexToRgb(block.styles.color);
      pdf.setTextColor(color.r, color.g, color.b);
    }

    // Handle special static elements
    switch (block.id) {
      case 'company-logo':
        // Add company logo placeholder or actual logo
        pdf.rect(x, y, 50, 20);
        pdf.text('[Company Logo]', x + 2, y + 10);
        break;
      
      case 'signature-box':
        pdf.rect(x, y, 60, 20);
        pdf.text('Signature: ____________________', x + 2, y + 15);
        break;
      
      case 'date-stamp':
        pdf.text(`Date: ${new Date().toLocaleDateString()}`, x, y);
        break;
      
      default:
        pdf.text(content, x, y);
    }
  }

  /**
   * Render chart block with actual chart visualization
   */
  private static async renderChartBlock(
    pdf: jsPDF,
    block: CanvasBlock,
    reportData: ReportData,
    x: number,
    y: number,
    width: number,
    height: number
  ): Promise<void> {
    try {
      // Generate chart image based on block configuration and data
      const chartImageBlob = await this.chartService.generateChartImage(
        block.chartType || 'line',
        block.chartConfig || {},
        reportData.analyticsData
      );

      if (chartImageBlob) {
        // Convert blob to base64 for jsPDF
        const imageDataUrl = await this.blobToDataUrl(chartImageBlob);
        pdf.addImage(imageDataUrl, 'PNG', x, y, width, height);
      } else {
        // Fallback to placeholder
        pdf.rect(x, y, width, height);
        pdf.text(`[${block.chartType || 'Chart'}]`, x + 5, y + height/2);
      }
    } catch (error) {
      console.error('Error rendering chart:', error);
      // Fallback to placeholder
      pdf.rect(x, y, width, height);
      pdf.text('[Chart Error]', x + 5, y + height/2);
    }
  }

  /**
   * Render file attachment block
   */
  private static async renderAttachmentBlock(
    pdf: jsPDF,
    block: CanvasBlock,
    reportData: ReportData,
    x: number,
    y: number,
    width: number,
    height: number
  ): Promise<void> {
    const attachment = reportData.attachments.find(att => att.id === block.content?.attachmentId);
    
    if (attachment) {
      if (attachment.fileType === 'image') {
        try {
          // If it's an image, embed it directly
          pdf.addImage(attachment.filePath, 'JPEG', x, y, width, height);
        } catch (error) {
          pdf.rect(x, y, width, height);
          pdf.text(`[Image: ${attachment.fileName}]`, x + 5, y + height/2);
        }
      } else {
        // For other file types, show reference
        pdf.rect(x, y, width, height);
        pdf.text(`📎 ${attachment.fileName}`, x + 5, y + 10);
        pdf.text(`Type: ${attachment.fileType}`, x + 5, y + 20);
      }
    } else {
      pdf.rect(x, y, width, height);
      pdf.text('[No Attachment]', x + 5, y + height/2);
    }
  }

  /**
   * Add watermark to PDF
   */
  private static addWatermark(pdf: jsPDF, text: string): void {
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    pdf.saveGraphicsState();
    pdf.setGState(pdf.GState({ opacity: 0.1 }));
    pdf.setTextColor(128, 128, 128);
    pdf.setFontSize(60);
    pdf.text(text, pageWidth / 2, pageHeight / 2, {
      angle: 45,
      align: 'center'
    });
    pdf.restoreGraphicsState();
  }

  /**
   * Convert hex color to RGB
   */
  private static hexToRgb(hex: string): { r: number; g: number; b: number } {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  }

  /**
   * Convert blob to data URL
   */
  private static blobToDataUrl(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  /**
   * Preview template with mock data
   */
  static async generatePreview(template: ReportTemplate): Promise<Blob> {
    const mockData: ReportData = {
      memoId: 'preview-123',
      memoRef: 'PREVIEW-001',
      testData: {
        officer: 'Preview Officer',
        plant: 'Preview Plant',
        samplingDate: new Date().toLocaleDateString(),
        testType: template.productType
      },
      analyticsData: this.generateMockAnalyticsData(template.productType),
      attachments: []
    };

    return this.generateFromTemplate(template, mockData, 'PREVIEW MODE');
  }

  /**
   * Generate mock analytics data for preview
   */
  private static generateMockAnalyticsData(productType: string): any {
    switch (productType) {
      case 'aggregates':
        return {
          sieveAnalysis: [
            { size: '10mm', passing: 95 },
            { size: '5mm', passing: 75 },
            { size: '2.36mm', passing: 55 },
            { size: '1.18mm', passing: 35 },
            { size: '0.6mm', passing: 25 },
            { size: '0.3mm', passing: 15 },
            { size: '0.15mm', passing: 8 },
            { size: '0.075mm', passing: 3 }
          ],
          fineness: 2.65,
          waterAbsorption: 1.2
        };
      
      case 'concrete':
        return {
          strengthData: [
            { age: 7, strength: 25.5 },
            { age: 14, strength: 32.8 },
            { age: 28, strength: 42.1 }
          ],
          slump: 75
        };
      
      default:
        return {};
    }
  }
}