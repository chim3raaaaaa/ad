import { DashboardWidget } from '@/types/dashboard';
import { dataExportService } from '@/services/export/dataExportService';
import { enhancedNotificationService } from '@/services/notifications/enhancedNotificationService';

export interface ReportSchedule {
  id: string;
  name: string;
  description: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly';
  dayOfWeek?: number; // 0-6 for weekly
  dayOfMonth?: number; // 1-31 for monthly
  time: string; // HH:MM format
  timezone: string;
  enabled: boolean;
  widgets: string[]; // Widget IDs to include
  recipients: string[]; // Email addresses
  format: 'pdf' | 'excel' | 'both';
  lastRun?: string;
  nextRun?: string;
  created_at: string;
}

export interface ReportTemplate {
  id: string;
  name: string;
  description: string;
  layout: 'portrait' | 'landscape';
  includeCharts: boolean;
  includeSummary: boolean;
  customSections: Array<{
    title: string;
    content: string;
    widgets: string[];
  }>;
  styling: {
    headerColor: string;
    accentColor: string;
    fontSize: number;
    logoUrl?: string;
  };
  created_at: string;
}

export interface AnalyticsInsight {
  id: string;
  type: 'trend' | 'anomaly' | 'threshold' | 'prediction';
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  data: Record<string, any>;
  recommendations: string[];
  created_at: string;
}

export interface KPIThreshold {
  id: string;
  widgetId: string;
  metricName: string;
  operator: '>' | '<' | '>=' | '<=' | '=' | '!=';
  value: number;
  severity: 'warning' | 'critical';
  enabled: boolean;
  notificationEnabled: boolean;
  created_at: string;
}

class AdvancedReportingService {
  private schedules: Map<string, ReportSchedule> = new Map();
  private templates: Map<string, ReportTemplate> = new Map();
  private thresholds: Map<string, KPIThreshold> = new Map();
  private insights: AnalyticsInsight[] = [];

  constructor() {
    this.initializeDatabase();
    this.initializeDefaultTemplates();
    this.startScheduleRunner();
  }

  private async initializeDatabase() {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      // Create report schedules table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS report_schedules (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          frequency TEXT NOT NULL,
          day_of_week INTEGER,
          day_of_month INTEGER,
          time TEXT NOT NULL,
          timezone TEXT NOT NULL,
          enabled INTEGER DEFAULT 1,
          widgets TEXT NOT NULL,
          recipients TEXT NOT NULL,
          format TEXT NOT NULL,
          last_run TEXT,
          next_run TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create report templates table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS report_templates (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          layout TEXT DEFAULT 'portrait',
          include_charts INTEGER DEFAULT 1,
          include_summary INTEGER DEFAULT 1,
          custom_sections TEXT,
          styling TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create KPI thresholds table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS kpi_thresholds (
          id TEXT PRIMARY KEY,
          widget_id TEXT NOT NULL,
          metric_name TEXT NOT NULL,
          operator TEXT NOT NULL,
          value REAL NOT NULL,
          severity TEXT NOT NULL,
          enabled INTEGER DEFAULT 1,
          notification_enabled INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Create analytics insights table
      await window.electronAPI.dbQuery(`
        CREATE TABLE IF NOT EXISTS analytics_insights (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL,
          title TEXT NOT NULL,
          description TEXT NOT NULL,
          severity TEXT NOT NULL,
          data TEXT NOT NULL,
          recommendations TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `);

      await this.loadSchedules();
      await this.loadTemplates();
      await this.loadThresholds();
      await this.loadInsights();
    } catch (error) {
      console.error('Error initializing reporting database:', error);
    }
  }

  private initializeDefaultTemplates() {
    const defaultTemplate: ReportTemplate = {
      id: 'default-executive',
      name: 'Executive Summary',
      description: 'High-level overview for management',
      layout: 'portrait',
      includeCharts: true,
      includeSummary: true,
      customSections: [
        {
          title: 'Key Performance Indicators',
          content: 'Overview of critical metrics and trends',
          widgets: []
        },
        {
          title: 'Quality Metrics',
          content: 'Test results and quality indicators',
          widgets: []
        },
        {
          title: 'Operational Efficiency',
          content: 'Lab capacity and scheduling metrics',
          widgets: []
        }
      ],
      styling: {
        headerColor: '#1e40af',
        accentColor: '#3b82f6',
        fontSize: 12
      },
      created_at: new Date().toISOString()
    };

    this.templates.set(defaultTemplate.id, defaultTemplate);
  }

  async createSchedule(schedule: Omit<ReportSchedule, 'id' | 'created_at'>): Promise<ReportSchedule> {
    const newSchedule: ReportSchedule = {
      ...schedule,
      id: crypto.randomUUID(),
      created_at: new Date().toISOString(),
      nextRun: this.calculateNextRun({
        ...schedule,
        id: '',
        created_at: ''
      } as ReportSchedule)
    };

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbQuery(
          `INSERT INTO report_schedules 
           (id, name, description, frequency, day_of_week, day_of_month, time, timezone, 
            enabled, widgets, recipients, format, next_run, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newSchedule.id,
            newSchedule.name,
            newSchedule.description || '',
            newSchedule.frequency,
            newSchedule.dayOfWeek || null,
            newSchedule.dayOfMonth || null,
            newSchedule.time,
            newSchedule.timezone,
            newSchedule.enabled ? 1 : 0,
            JSON.stringify(newSchedule.widgets),
            JSON.stringify(newSchedule.recipients),
            newSchedule.format,
            newSchedule.nextRun || null,
            newSchedule.created_at
          ]
        );
      } catch (error) {
        console.error('Error saving report schedule:', error);
      }
    }

    this.schedules.set(newSchedule.id, newSchedule);
    return newSchedule;
  }

  async generateReport(
    widgetIds: string[],
    templateId?: string,
    format: 'pdf' | 'excel' = 'pdf'
  ): Promise<string | null> {
    try {
      const template = templateId ? this.templates.get(templateId) : undefined;
      
      // Get widgets data (mock implementation)
      const widgets = await this.getWidgetsData(widgetIds);
      
      if (widgets.length === 0) {
        throw new Error('No widget data available for report generation');
      }

      // Generate insights for the report
      const insights = await this.generateInsights(widgets);

      // Create enhanced export with template and insights
      const reportData = {
        title: template?.name || 'Dashboard Report',
        description: template?.description || 'Generated dashboard report',
        generatedAt: new Date().toISOString(),
        template: template,
        insights: insights,
        widgets: widgets
      };

      // Use existing export service with enhancements
      const filename = `report-${Date.now()}`;
      await dataExportService.exportDashboard(widgets, {
        format,
        filename,
        includeCharts: template?.includeCharts ?? true
      });

      // Log the report generation
      await this.logReportGeneration(filename, widgetIds, templateId);

      return filename;
    } catch (error) {
      console.error('Error generating report:', error);
      throw error;
    }
  }

  async scheduleReport(scheduleId: string): Promise<void> {
    const schedule = this.schedules.get(scheduleId);
    if (!schedule || !schedule.enabled) return;

    try {
      const filename = await this.generateReport(
        schedule.widgets,
        undefined,
        schedule.format === 'both' ? 'pdf' : schedule.format
      );

      if (filename && schedule.format === 'both') {
        // Generate Excel version too
        await this.generateReport(schedule.widgets, undefined, 'excel');
      }

      // Send email to recipients (simulated)
      await this.sendReportEmail(schedule, filename || 'report');

      // Update schedule
      schedule.lastRun = new Date().toISOString();
      schedule.nextRun = this.calculateNextRun(schedule);

      // Update in database
      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      if (isElectron) {
        await window.electronAPI.dbQuery(
          'UPDATE report_schedules SET last_run = ?, next_run = ? WHERE id = ?',
          [schedule.lastRun, schedule.nextRun, scheduleId]
        );
      }

    } catch (error) {
      console.error(`Error running scheduled report ${scheduleId}:`, error);
      
      // Create notification about failed report
      await enhancedNotificationService.createNotification({
        type: 'error',
        category: 'reports',
        title: 'Scheduled Report Failed',
        message: `Report "${schedule.name}" failed to generate: ${error instanceof Error ? error.message : 'Unknown error'}`,
        priority: 'high'
      });
    }
  }

  private calculateNextRun(schedule: ReportSchedule): string {
    const now = new Date();
    const [hours, minutes] = schedule.time.split(':').map(Number);
    
    let nextRun = new Date(now);
    nextRun.setHours(hours, minutes, 0, 0);

    switch (schedule.frequency) {
      case 'daily':
        if (nextRun <= now) {
          nextRun.setDate(nextRun.getDate() + 1);
        }
        break;
      
      case 'weekly':
        const targetDay = schedule.dayOfWeek || 1; // Default to Monday
        const daysUntilTarget = (targetDay - now.getDay() + 7) % 7;
        nextRun.setDate(now.getDate() + (daysUntilTarget || 7));
        break;
      
      case 'monthly':
        const targetDate = schedule.dayOfMonth || 1;
        nextRun.setDate(targetDate);
        if (nextRun <= now) {
          nextRun.setMonth(nextRun.getMonth() + 1);
        }
        break;
      
      case 'quarterly':
        nextRun.setMonth(now.getMonth() + 3);
        break;
    }

    return nextRun.toISOString();
  }

  private async sendReportEmail(schedule: ReportSchedule, filename: string): Promise<void> {
    // Simulate email sending
    console.log(`Sending report "${filename}" to:`, schedule.recipients);
    
    // In real implementation, integrate with email service
    // await emailService.sendReportEmail(schedule.recipients, filename, schedule.name);
  }

  async createKPIThreshold(threshold: Omit<KPIThreshold, 'id' | 'created_at'>): Promise<KPIThreshold> {
    const newThreshold: KPIThreshold = {
      ...threshold,
      id: crypto.randomUUID(),
      created_at: new Date().toISOString()
    };

    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (isElectron) {
      try {
        await window.electronAPI.dbQuery(
          `INSERT INTO kpi_thresholds 
           (id, widget_id, metric_name, operator, value, severity, enabled, notification_enabled, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            newThreshold.id,
            newThreshold.widgetId,
            newThreshold.metricName,
            newThreshold.operator,
            newThreshold.value,
            newThreshold.severity,
            newThreshold.enabled ? 1 : 0,
            newThreshold.notificationEnabled ? 1 : 0,
            newThreshold.created_at
          ]
        );
      } catch (error) {
        console.error('Error saving KPI threshold:', error);
      }
    }

    this.thresholds.set(newThreshold.id, newThreshold);
    return newThreshold;
  }

  async checkKPIThresholds(widgetId: string, value: number, metricName: string): Promise<void> {
    const widgetThresholds = Array.from(this.thresholds.values())
      .filter(t => t.widgetId === widgetId && t.metricName === metricName && t.enabled);

    for (const threshold of widgetThresholds) {
      const breached = this.evaluateThreshold(value, threshold);
      
      if (breached && threshold.notificationEnabled) {
        await enhancedNotificationService.createNotification({
          type: threshold.severity === 'critical' ? 'error' : 'warning',
          category: 'system',
          title: `KPI Threshold Breached`,
          message: `${metricName} (${value}) ${threshold.operator} ${threshold.value}`,
          priority: threshold.severity === 'critical' ? 'high' : 'normal',
          data: {
            widgetId,
            thresholdId: threshold.id,
            actualValue: value,
            thresholdValue: threshold.value
          }
        });
      }
    }
  }

  private evaluateThreshold(value: number, threshold: KPIThreshold): boolean {
    switch (threshold.operator) {
      case '>': return value > threshold.value;
      case '<': return value < threshold.value;
      case '>=': return value >= threshold.value;
      case '<=': return value <= threshold.value;
      case '=': return value === threshold.value;
      case '!=': return value !== threshold.value;
      default: return false;
    }
  }

  private async generateInsights(widgets: any[]): Promise<AnalyticsInsight[]> {
    const insights: AnalyticsInsight[] = [];

    // Simple trend analysis
    for (const widget of widgets) {
      if (widget.type === 'kpi' && widget.data) {
        const currentValue = widget.data[0]?.value || 0;
        
        // Mock trend analysis
        const trend = Math.random() > 0.5 ? 'increasing' : 'decreasing';
        const changePercent = Math.floor(Math.random() * 20) + 5;
        
        insights.push({
          id: crypto.randomUUID(),
          type: 'trend',
          title: `${widget.title} Trend`,
          description: `This metric is ${trend} by ${changePercent}% compared to last period`,
          severity: changePercent > 15 ? 'medium' : 'low',
          data: { currentValue, changePercent, trend },
          recommendations: [
            trend === 'increasing' ? 
              'Monitor this positive trend and identify contributing factors' :
              'Investigate potential causes for the decline'
          ],
          created_at: new Date().toISOString()
        });
      }
    }

    return insights;
  }

  private async getWidgetsData(widgetIds: string[]): Promise<any[]> {
    // Mock widgets data - in real implementation, fetch from actual widgets
    return widgetIds.map(id => ({
      id,
      type: 'kpi',
      title: `Widget ${id}`,
      data: [{ value: Math.floor(Math.random() * 100) + 50 }]
    }));
  }

  private async logReportGeneration(filename: string, widgetIds: string[], templateId?: string): Promise<void> {
    console.log(`Report generated: ${filename}`, { widgetIds, templateId });
  }

  private async loadSchedules(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      const result = await window.electronAPI.dbQuery('SELECT * FROM report_schedules');
      if (result.success) {
        result.data.forEach((row: any) => {
          const schedule: ReportSchedule = {
            id: row.id,
            name: row.name,
            description: row.description,
            frequency: row.frequency,
            dayOfWeek: row.day_of_week,
            dayOfMonth: row.day_of_month,
            time: row.time,
            timezone: row.timezone,
            enabled: Boolean(row.enabled),
            widgets: JSON.parse(row.widgets),
            recipients: JSON.parse(row.recipients),
            format: row.format,
            lastRun: row.last_run,
            nextRun: row.next_run,
            created_at: row.created_at
          };
          this.schedules.set(schedule.id, schedule);
        });
      }
    } catch (error) {
      console.error('Error loading schedules:', error);
    }
  }

  private async loadTemplates(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      const result = await window.electronAPI.dbQuery('SELECT * FROM report_templates');
      if (result.success) {
        result.data.forEach((row: any) => {
          const template: ReportTemplate = {
            id: row.id,
            name: row.name,
            description: row.description,
            layout: row.layout,
            includeCharts: Boolean(row.include_charts),
            includeSummary: Boolean(row.include_summary),
            customSections: row.custom_sections ? JSON.parse(row.custom_sections) : [],
            styling: row.styling ? JSON.parse(row.styling) : {},
            created_at: row.created_at
          };
          this.templates.set(template.id, template);
        });
      }
    } catch (error) {
      console.error('Error loading templates:', error);
    }
  }

  private async loadThresholds(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      const result = await window.electronAPI.dbQuery('SELECT * FROM kpi_thresholds');
      if (result.success) {
        result.data.forEach((row: any) => {
          const threshold: KPIThreshold = {
            id: row.id,
            widgetId: row.widget_id,
            metricName: row.metric_name,
            operator: row.operator,
            value: row.value,
            severity: row.severity,
            enabled: Boolean(row.enabled),
            notificationEnabled: Boolean(row.notification_enabled),
            created_at: row.created_at
          };
          this.thresholds.set(threshold.id, threshold);
        });
      }
    } catch (error) {
      console.error('Error loading thresholds:', error);
    }
  }

  private async loadInsights(): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      const result = await window.electronAPI.dbQuery(
        'SELECT * FROM analytics_insights ORDER BY created_at DESC LIMIT 50'
      );
      if (result.success) {
        this.insights = result.data.map((row: any) => ({
          id: row.id,
          type: row.type,
          title: row.title,
          description: row.description,
          severity: row.severity,
          data: JSON.parse(row.data),
          recommendations: row.recommendations ? JSON.parse(row.recommendations) : [],
          created_at: row.created_at
        }));
      }
    } catch (error) {
      console.error('Error loading insights:', error);
    }
  }

  private startScheduleRunner(): void {
    // Check for due reports every minute
    setInterval(async () => {
      const now = new Date().toISOString();
      
      for (const schedule of this.schedules.values()) {
        if (schedule.enabled && schedule.nextRun && schedule.nextRun <= now) {
          await this.scheduleReport(schedule.id);
        }
      }
    }, 60 * 1000); // 1 minute
  }

  getSchedules(): ReportSchedule[] {
    return Array.from(this.schedules.values());
  }

  getTemplates(): ReportTemplate[] {
    return Array.from(this.templates.values());
  }

  getThresholds(): KPIThreshold[] {
    return Array.from(this.thresholds.values());
  }

  getInsights(): AnalyticsInsight[] {
    return this.insights;
  }
}

export const advancedReportingService = new AdvancedReportingService();