// Permission guard service for protecting operations
import { PermissionChecker } from './permissions';
import type { LocalUser } from '@/services/auth/localAuthService';

export class PermissionGuard {
  private permissionChecker: PermissionChecker;

  constructor(user: LocalUser | null) {
    // Get user permissions from their role
    const permissions = this.getUserPermissions(user);
    this.permissionChecker = new PermissionChecker(permissions);
  }

  private getUserPermissions(user: LocalUser | null): string[] {
    if (!user) return [];

    // For system roles, get their predefined permissions
    const rolePermissionMap: Record<string, string[]> = {
      'admin': [
        'system.full_access',
        'system.developer_mode', 
        'system.advanced_features',
        'users.view', 'users.create', 'users.edit', 'users.delete',
        'roles.view', 'roles.create', 'roles.edit', 'roles.delete',
        'tests.view', 'tests.create', 'tests.edit', 'tests.approve',
        'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
        'reports.view', 'reports.generate', 'reports.export',
        'modules.view', 'modules.install', 'modules.configure',
        'dashboard.view', 'dashboard.create', 'dashboard.edit', 'dashboard.delete', 'dashboard.manage',
        'settings.view', 'settings.edit', 'settings.password_policy'
      ],
      'lab_manager': [
        'users.view', 'users.edit',
        'tests.view', 'tests.create', 'tests.edit', 'tests.approve', 'tests.procedures.manage',
        'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
        'reports.view', 'reports.advanced', 'reports.export',
        'dashboard.view', 'dashboard.edit',
        'settings.view', 'settings.password_policy'
      ],
      'qa_manager': [
        'users.view',
        'tests.view', 'tests.create', 'tests.edit', 'tests.approve',
        'memos.view', 'memos.create', 'memos.edit',
        'reports.view', 'reports.advanced', 'reports.export',
        'dashboard.view',
        'settings.view'
      ],
      'lab_technician': [
        'tests.view', 'tests.create', 'tests.edit',
        'memos.view', 'memos.create', 'memos.edit',
        'dashboard.view',
        'reports.view'
      ]
    };

    return rolePermissionMap[user.role] || [];
  }

  // Core permission checking
  hasPermission(permission: string): boolean {
    return this.permissionChecker.hasPermission(permission);
  }

  // User management guards
  canViewUsers(): boolean {
    return this.permissionChecker.hasPermission('users.view');
  }

  canCreateUsers(): boolean {
    return this.permissionChecker.hasPermission('users.create');
  }

  canEditUsers(): boolean {
    return this.permissionChecker.hasPermission('users.edit');
  }

  canDeleteUsers(): boolean {
    return this.permissionChecker.hasPermission('users.delete');
  }

  canManageRoles(): boolean {
    return this.permissionChecker.hasPermission('roles.manage');
  }

  // Test management guards
  canViewTests(): boolean {
    return this.permissionChecker.hasPermission('tests.view');
  }

  canCreateTests(): boolean {
    return this.permissionChecker.hasPermission('tests.create');
  }

  canEditTests(): boolean {
    return this.permissionChecker.hasPermission('tests.edit');
  }

  canDeleteTests(): boolean {
    return this.permissionChecker.hasPermission('tests.delete');
  }

  canApproveTests(): boolean {
    return this.permissionChecker.hasPermission('tests.approve');
  }

  canManageTestProcedures(): boolean {
    return this.permissionChecker.hasPermission('tests.procedures.manage');
  }

  // Memo management guards
  canViewMemos(): boolean {
    return this.permissionChecker.hasPermission('memos.view');
  }

  canCreateMemos(): boolean {
    return this.permissionChecker.hasPermission('memos.create');
  }

  canEditMemos(): boolean {
    return this.permissionChecker.hasPermission('memos.edit');
  }

  canDeleteMemos(): boolean {
    return this.permissionChecker.hasPermission('memos.delete');
  }

  // Report management guards
  canViewReports(): boolean {
    return this.permissionChecker.hasPermission('reports.view');
  }

  canViewAdvancedReports(): boolean {
    return this.permissionChecker.hasPermission('reports.advanced');
  }

  canExportReports(): boolean {
    return this.permissionChecker.hasPermission('reports.export');
  }

  // Settings management guards
  canViewSettings(): boolean {
    return this.permissionChecker.hasPermission('settings.view');
  }

  canEditSettings(): boolean {
    return this.permissionChecker.hasPermission('settings.edit');
  }

  canManagePasswordPolicy(): boolean {
    return this.permissionChecker.hasPermission('settings.password_policy');
  }

  // Developer tools guards
  canAccessDeveloperMode(): boolean {
    return this.permissionChecker.hasPermission('system.developer_mode');
  }

  canAccessAuditLogs(): boolean {
    return this.permissionChecker.hasPermission('system.audit_logs');
  }

  // Composite permission checks
  canManageSystem(): boolean {
    return this.permissionChecker.hasPermission('system.full_access');
  }

  canManageUsers(): boolean {
    return this.permissionChecker.canManageUsers();
  }

  canManageTests(): boolean {
    return this.permissionChecker.canManageTests();
  }

  canManageMemos(): boolean {
    return this.permissionChecker.canManageMemos();
  }

  // Dashboard management guards
  canViewDashboard(): boolean {
    return this.permissionChecker.hasPermission('dashboard.view');
  }

  canCreateDashboard(): boolean {
    return this.permissionChecker.hasPermission('dashboard.create');
  }

  canEditDashboard(): boolean {
    return this.permissionChecker.hasPermission('dashboard.edit');
  }

  canDeleteDashboard(): boolean {
    return this.permissionChecker.hasPermission('dashboard.delete');
  }

  canManageDashboard(): boolean {
    return this.permissionChecker.hasPermission('dashboard.manage');
  }

  // Guard methods that throw errors for critical operations
  guardUserManagement(operation: string): void {
    if (!this.canManageUsers()) {
      throw new Error(`Access denied: You don't have permission to ${operation} users`);
    }
  }

  guardTestManagement(operation: string): void {
    if (!this.canManageTests()) {
      throw new Error(`Access denied: You don't have permission to ${operation} tests`);
    }
  }

  guardMemoManagement(operation: string): void {
    if (!this.canManageMemos()) {
      throw new Error(`Access denied: You don't have permission to ${operation} memos`);
    }
  }

  guardSystemAccess(): void {
    if (!this.canManageSystem()) {
      throw new Error('Access denied: Administrator privileges required');
    }
  }

  guardDeveloperMode(): void {
    if (!this.canAccessDeveloperMode()) {
      throw new Error('Access denied: Developer mode access required');
    }
  }
}

// Hook for easy permission checking in components  
import { useAuth } from '@/contexts/AuthContext';

export const usePermissions = () => {
  const { user } = useAuth();
  const guard = new PermissionGuard(user);

  return {
    guard,
    hasPermission: (permission: string) => guard.hasPermission(permission),
    canViewUsers: () => guard.canViewUsers(),
    canCreateUsers: () => guard.canCreateUsers(),
    canEditUsers: () => guard.canEditUsers(),
    canDeleteUsers: () => guard.canDeleteUsers(),
    canManageRoles: () => guard.canManageRoles(),
    canViewTests: () => guard.canViewTests(),
    canCreateTests: () => guard.canCreateTests(),
    canEditTests: () => guard.canEditTests(),
    canDeleteTests: () => guard.canDeleteTests(),
    canApproveTests: () => guard.canApproveTests(),
    canManageTestProcedures: () => guard.canManageTestProcedures(),
    canViewMemos: () => guard.canViewMemos(),
    canCreateMemos: () => guard.canCreateMemos(),
    canEditMemos: () => guard.canEditMemos(),
    canDeleteMemos: () => guard.canDeleteMemos(),
    canViewReports: () => guard.canViewReports(),
    canViewAdvancedReports: () => guard.canViewAdvancedReports(),
    canExportReports: () => guard.canExportReports(),
    canViewSettings: () => guard.canViewSettings(),
    canEditSettings: () => guard.canEditSettings(),
    canManagePasswordPolicy: () => guard.canManagePasswordPolicy(),
    canAccessDeveloperMode: () => guard.canAccessDeveloperMode(),
    canAccessAuditLogs: () => guard.canAccessAuditLogs(),
    canManageSystem: () => guard.canManageSystem(),
    canManageUsers: () => guard.canManageUsers(),
    canManageTests: () => guard.canManageTests(),
    canManageMemos: () => guard.canManageMemos(),
    canViewDashboard: () => guard.canViewDashboard(),
    canCreateDashboard: () => guard.canCreateDashboard(),
    canEditDashboard: () => guard.canEditDashboard(),
    canDeleteDashboard: () => guard.canDeleteDashboard(),
    canManageDashboard: () => guard.canManageDashboard()
  };
};