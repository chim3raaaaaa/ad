// RBAC (Role-Based Access Control) for Mix Design Manager
// Phase 3: RBAC & Validation Implementation
// Created: 2025-01-31

export type UserRole = 'admin' | 'manager' | 'lab_technician' | 'plant_officer' | 'viewer';

export interface Permission {
  action: string;
  resource: string;
  condition?: (context: any) => boolean;
}

export interface RolePermissions {
  role: UserRole;
  permissions: Permission[];
  description: string;
}

// Define role-based permissions for Mix Design Manager
export const MIX_DESIGN_PERMISSIONS: RolePermissions[] = [
  {
    role: 'admin',
    description: 'Full access to everything including developer mode',
    permissions: [
      // Mix Designs
      { action: 'create', resource: 'mix_design' },
      { action: 'read', resource: 'mix_design' },
      { action: 'update', resource: 'mix_design' },
      { action: 'delete', resource: 'mix_design' },
      { action: 'approve', resource: 'mix_design' },
      { action: 'archive', resource: 'mix_design' },
      { action: 'restore', resource: 'mix_design' },
      
      // Templates
      { action: 'create', resource: 'mix_design_template' },
      { action: 'read', resource: 'mix_design_template' },
      { action: 'update', resource: 'mix_design_template' },
      { action: 'delete', resource: 'mix_design_template' },
      { action: 'approve', resource: 'mix_design_template' },
      { action: 'publish', resource: 'mix_design_template' },
      
      // Product Types & Fields
      { action: 'create', resource: 'product_type' },
      { action: 'update', resource: 'product_type' },
      { action: 'delete', resource: 'product_type' },
      { action: 'create', resource: 'mix_design_field' },
      { action: 'update', resource: 'mix_design_field' },
      { action: 'delete', resource: 'mix_design_field' },
      
      // Trials & Analysis
      { action: 'create', resource: 'mix_design_trial' },
      { action: 'read', resource: 'mix_design_trial' },
      { action: 'update', resource: 'mix_design_trial' },
      { action: 'delete', resource: 'mix_design_trial' },
      { action: 'analyze', resource: 'mix_design_trial' },
      
      // System
      { action: 'export', resource: 'mix_design_data' },
      { action: 'import', resource: 'mix_design_data' },
      { action: 'audit', resource: 'mix_design_logs' },
      { action: 'developer_mode', resource: 'system' }
    ]
  },
  
  {
    role: 'manager',
    description: 'Full access but not developer mode or critical control of app',
    permissions: [
      // Mix Designs
      { action: 'create', resource: 'mix_design' },
      { action: 'read', resource: 'mix_design' },
      { action: 'update', resource: 'mix_design' },
      { action: 'delete', resource: 'mix_design', condition: (ctx) => ctx.created_by === ctx.current_user_id },
      { action: 'approve', resource: 'mix_design' },
      { action: 'archive', resource: 'mix_design' },
      
      // Templates
      { action: 'create', resource: 'mix_design_template' },
      { action: 'read', resource: 'mix_design_template' },
      { action: 'update', resource: 'mix_design_template' },
      { action: 'delete', resource: 'mix_design_template', condition: (ctx) => ctx.created_by === ctx.current_user_id },
      { action: 'approve', resource: 'mix_design_template' },
      { action: 'publish', resource: 'mix_design_template' },
      
      // Trials & Analysis
      { action: 'create', resource: 'mix_design_trial' },
      { action: 'read', resource: 'mix_design_trial' },
      { action: 'update', resource: 'mix_design_trial' },
      { action: 'analyze', resource: 'mix_design_trial' },
      
      // System
      { action: 'export', resource: 'mix_design_data' },
      { action: 'audit', resource: 'mix_design_logs' }
    ]
  },
  
  {
    role: 'lab_technician',
    description: 'Restricted access for lab operations',
    permissions: [
      // Mix Designs
      { action: 'create', resource: 'mix_design' },
      { action: 'read', resource: 'mix_design' },
      { action: 'update', resource: 'mix_design', condition: (ctx) => ctx.created_by === ctx.current_user_id && ctx.status !== 'approved' },
      { action: 'delete', resource: 'mix_design', condition: (ctx) => ctx.created_by === ctx.current_user_id && ctx.status === 'draft' },
      
      // Templates
      { action: 'read', resource: 'mix_design_template' },
      { action: 'create', resource: 'mix_design_template', condition: (ctx) => !ctx.is_public },
      { action: 'update', resource: 'mix_design_template', condition: (ctx) => ctx.created_by === ctx.current_user_id && !ctx.is_public },
      
      // Trials & Analysis
      { action: 'create', resource: 'mix_design_trial' },
      { action: 'read', resource: 'mix_design_trial' },
      { action: 'update', resource: 'mix_design_trial', condition: (ctx) => ctx.created_by === ctx.current_user_id },
      { action: 'analyze', resource: 'mix_design_trial' },
      
      // System
      { action: 'export', resource: 'mix_design_data', condition: (ctx) => ctx.scope === 'own_data' }
    ]
  },
  
  {
    role: 'plant_officer',
    description: 'Can create memos and track status only',
    permissions: [
      // Mix Designs
      { action: 'read', resource: 'mix_design' },
      
      // Templates
      { action: 'read', resource: 'mix_design_template' },
      
      // Trials (limited to viewing and creating trial requests)
      { action: 'read', resource: 'mix_design_trial' },
      { action: 'create', resource: 'mix_design_trial', condition: (ctx) => ctx.trial_type === 'request' }
    ]
  },
  
  {
    role: 'viewer',
    description: 'Read-only access',
    permissions: [
      // Mix Designs
      { action: 'read', resource: 'mix_design' },
      
      // Templates
      { action: 'read', resource: 'mix_design_template' },
      
      // Trials
      { action: 'read', resource: 'mix_design_trial' }
    ]
  }
];

// RBAC Service Class
export class MixDesignRBACService {
  private currentUser: { id: string; role: UserRole } | null = null;
  
  constructor(userId: string, userRole: UserRole) {
    this.currentUser = { id: userId, role: userRole };
  }

  // Check if user has permission to perform action on resource
  hasPermission(action: string, resource: string, context: any = {}): boolean {
    if (!this.currentUser) return false;

    const rolePermissions = MIX_DESIGN_PERMISSIONS.find(rp => rp.role === this.currentUser!.role);
    if (!rolePermissions) return false;

    const permission = rolePermissions.permissions.find(p => 
      p.action === action && p.resource === resource
    );

    if (!permission) return false;

    // Check conditional permissions
    if (permission.condition) {
      const contextWithUser = {
        ...context,
        current_user_id: this.currentUser.id,
        current_user_role: this.currentUser.role
      };
      return permission.condition(contextWithUser);
    }

    return true;
  }

  // Get all permissions for current user role
  getUserPermissions(): Permission[] {
    if (!this.currentUser) return [];

    const rolePermissions = MIX_DESIGN_PERMISSIONS.find(rp => rp.role === this.currentUser!.role);
    return rolePermissions?.permissions || [];
  }

  // Check if user can perform action on specific mix design
  canAccessMixDesign(action: string, mixDesign: any): boolean {
    return this.hasPermission(action, 'mix_design', {
      created_by: mixDesign.created_by,
      status: mixDesign.status,
      approved_by: mixDesign.approved_by
    });
  }

  // Check if user can perform action on template
  canAccessTemplate(action: string, template: any): boolean {
    return this.hasPermission(action, 'mix_design_template', {
      created_by: template.created_by,
      is_public: template.is_public,
      approved_by: template.approved_by
    });
  }

  // Check if user can perform action on trial
  canAccessTrial(action: string, trial: any): boolean {
    return this.hasPermission(action, 'mix_design_trial', {
      created_by: trial.created_by,
      trial_type: trial.trial_type || 'standard'
    });
  }

  // Get filtered actions for UI
  getAvailableActions(resource: string, context: any = {}): string[] {
    const permissions = this.getUserPermissions();
    const resourcePermissions = permissions.filter(p => p.resource === resource);
    
    return resourcePermissions
      .filter(p => !p.condition || p.condition({ ...context, current_user_id: this.currentUser?.id }))
      .map(p => p.action);
  }

  // Role hierarchy check
  isRoleAtLeast(requiredRole: UserRole): boolean {
    if (!this.currentUser) return false;

    const roleHierarchy: UserRole[] = ['viewer', 'plant_officer', 'lab_technician', 'manager', 'admin'];
    const currentRoleIndex = roleHierarchy.indexOf(this.currentUser.role);
    const requiredRoleIndex = roleHierarchy.indexOf(requiredRole);
    
    return currentRoleIndex >= requiredRoleIndex;
  }

  // Update user context
  updateUser(userId: string, userRole: UserRole): void {
    this.currentUser = { id: userId, role: userRole };
  }
}

// Permission Wrapper Component for UI
import React from 'react';

interface PermissionWrapperProps {
  action: string;
  resource: string;
  context?: any;
  rbacService: MixDesignRBACService;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export const PermissionWrapper: React.FC<PermissionWrapperProps> = ({
  action,
  resource,
  context = {},
  rbacService,
  children,
  fallback = null
}) => {
  const hasPermission = rbacService.hasPermission(action, resource, context);
  
  return hasPermission ? children : fallback;
};

// Hook for using RBAC in components
export const useMixDesignPermissions = (userId: string, userRole: UserRole) => {
  const rbacService = React.useMemo(() => new MixDesignRBACService(userId, userRole), [userId, userRole]);
  
  return {
    hasPermission: (action: string, resource: string, context?: any) => 
      rbacService.hasPermission(action, resource, context),
    canAccessMixDesign: (action: string, mixDesign: any) => 
      rbacService.canAccessMixDesign(action, mixDesign),
    canAccessTemplate: (action: string, template: any) => 
      rbacService.canAccessTemplate(action, template),
    canAccessTrial: (action: string, trial: any) => 
      rbacService.canAccessTrial(action, trial),
    getAvailableActions: (resource: string, context?: any) => 
      rbacService.getAvailableActions(resource, context),
    isRoleAtLeast: (requiredRole: UserRole) => 
      rbacService.isRoleAtLeast(requiredRole),
    rbacService
  };
};