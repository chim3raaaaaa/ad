// Enhanced Role-Based Access Control System
export interface Permission {
  id: string;
  name: string;
  description: string;
  category: PermissionCategory;
}

export type PermissionCategory = 
  | 'system_management'
  | 'user_management' 
  | 'test_management'
  | 'memo_management'
  | 'report_management'
  | 'settings_management'
  | 'developer_tools';

export interface Role {
  id: string;
  name: string;
  displayName: string;
  description: string;
  permissions: string[];
  isSystemRole: boolean; // Cannot be deleted
  created_at: string;
  updated_at: string;
}

// Comprehensive permission definitions
export const PERMISSIONS: Record<string, Permission> = {
  // System Management (Admin only)
  'system.full_access': {
    id: 'system.full_access',
    name: 'Full System Access',
    description: 'Complete access to all system features',
    category: 'system_management'
  },
  'system.developer_mode': {
    id: 'system.developer_mode',
    name: 'Developer Mode',
    description: 'Access to developer tools and form/table builders',
    category: 'developer_tools'
  },
  'system.audit_logs': {
    id: 'system.audit_logs',
    name: 'View Audit Logs',
    description: 'Access to system audit trails and activity logs',
    category: 'system_management'
  },

  // User Management
  'users.view': {
    id: 'users.view',
    name: 'View Users',
    description: 'View user profiles and basic information',
    category: 'user_management'
  },
  'users.create': {
    id: 'users.create',
    name: 'Create Users',
    description: 'Create new user accounts',
    category: 'user_management'
  },
  'users.edit': {
    id: 'users.edit',
    name: 'Edit Users',
    description: 'Modify existing user profiles and roles',
    category: 'user_management'
  },
  'users.delete': {
    id: 'users.delete',
    name: 'Delete Users',
    description: 'Remove user accounts from the system',
    category: 'user_management'
  },
  'roles.manage': {
    id: 'roles.manage',
    name: 'Manage Roles',
    description: 'Create, edit, and delete user roles and permissions',
    category: 'user_management'
  },

  // Test Management
  'tests.view': {
    id: 'tests.view',
    name: 'View Tests',
    description: 'View test requests and results',
    category: 'test_management'
  },
  'tests.create': {
    id: 'tests.create',
    name: 'Create Tests',
    description: 'Create new test requests',
    category: 'test_management'
  },
  'tests.edit': {
    id: 'tests.edit',
    name: 'Edit Tests',
    description: 'Modify test requests and parameters',
    category: 'test_management'
  },
  'tests.delete': {
    id: 'tests.delete',
    name: 'Delete Tests',
    description: 'Remove test requests',
    category: 'test_management'
  },
  'tests.approve': {
    id: 'tests.approve',
    name: 'Approve Tests',
    description: 'Approve and finalize test results',
    category: 'test_management'
  },
  'tests.procedures.manage': {
    id: 'tests.procedures.manage',
    name: 'Manage Test Procedures',
    description: 'Create and modify test procedures and workflows',
    category: 'test_management'
  },

  // Memo Management
  'memos.view': {
    id: 'memos.view',
    name: 'View Memos',
    description: 'View laboratory memos and production data',
    category: 'memo_management'
  },
  'memos.create': {
    id: 'memos.create',
    name: 'Create Memos',
    description: 'Create new laboratory memos',
    category: 'memo_management'
  },
  'memos.edit': {
    id: 'memos.edit',
    name: 'Edit Memos',
    description: 'Modify existing memos',
    category: 'memo_management'
  },
  'memos.delete': {
    id: 'memos.delete',
    name: 'Delete Memos',
    description: 'Remove memos from the system',
    category: 'memo_management'
  },

  // Report Management
  'reports.view': {
    id: 'reports.view',
    name: 'View Reports',
    description: 'Access to basic reports and analytics',
    category: 'report_management'
  },
  'reports.advanced': {
    id: 'reports.advanced',
    name: 'Advanced Reports',
    description: 'Access to detailed analytics and custom reports',
    category: 'report_management'
  },
  'reports.export': {
    id: 'reports.export',
    name: 'Export Reports',
    description: 'Export reports to PDF, Excel, or other formats',
    category: 'report_management'
  },

  // Settings Management
  'settings.view': {
    id: 'settings.view',
    name: 'View Settings',
    description: 'View system settings and configuration',
    category: 'settings_management'
  },
  'settings.edit': {
    id: 'settings.edit',
    name: 'Edit Settings',
    description: 'Modify system settings and configuration',
    category: 'settings_management'
  },
  'settings.password_policy': {
    id: 'settings.password_policy',
    name: 'Password Policy',
    description: 'Manage password policies and security settings',
    category: 'settings_management'
  }
};

// Default system roles
export const SYSTEM_ROLES: Role[] = [
  {
    id: 'admin',
    name: 'admin',
    displayName: 'Administrator',
    description: 'Full system administrator with complete access',
    permissions: ['system.full_access'],
    isSystemRole: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 'lab_manager',
    name: 'lab_manager', 
    displayName: 'Lab Manager',
    description: 'Laboratory manager with advanced permissions',
    permissions: [
      'users.view', 'users.edit',
      'tests.view', 'tests.create', 'tests.edit', 'tests.approve', 'tests.procedures.manage',
      'memos.view', 'memos.create', 'memos.edit', 'memos.delete',
      'reports.view', 'reports.advanced', 'reports.export',
      'settings.view', 'settings.password_policy'
    ],
    isSystemRole: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 'qa_manager',
    name: 'qa_manager',
    displayName: 'QA Manager', 
    description: 'Quality assurance manager with approval rights',
    permissions: [
      'users.view',
      'tests.view', 'tests.create', 'tests.edit', 'tests.approve',
      'memos.view', 'memos.create', 'memos.edit',
      'reports.view', 'reports.advanced', 'reports.export',
      'settings.view'
    ],
    isSystemRole: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 'lab_technician',
    name: 'lab_technician',
    displayName: 'Lab Technician',
    description: 'Laboratory technician with basic operational access',
    permissions: [
      'tests.view', 'tests.create', 'tests.edit',
      'memos.view', 'memos.create', 'memos.edit',
      'reports.view'
    ],
    isSystemRole: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

// Permission checker class
export class PermissionChecker {
  constructor(private userPermissions: string[]) {}

  hasPermission(permission: string): boolean {
    // Admin has all permissions
    if (this.userPermissions.includes('system.full_access')) {
      return true;
    }
    
    return this.userPermissions.includes(permission);
  }

  hasAnyPermission(permissions: string[]): boolean {
    return permissions.some(permission => this.hasPermission(permission));
  }

  hasAllPermissions(permissions: string[]): boolean {
    return permissions.every(permission => this.hasPermission(permission));
  }

  // Specific permission groups
  canManageUsers(): boolean {
    return this.hasAnyPermission(['users.create', 'users.edit', 'users.delete']);
  }

  canManageTests(): boolean {
    return this.hasAnyPermission(['tests.create', 'tests.edit', 'tests.delete', 'tests.procedures.manage']);
  }

  canManageMemos(): boolean {
    return this.hasAnyPermission(['memos.create', 'memos.edit', 'memos.delete']);
  }

  canAccessDeveloperMode(): boolean {
    return this.hasPermission('system.developer_mode');
  }

  canManageSettings(): boolean {
    return this.hasPermission('settings.edit');
  }

  canApproveTests(): boolean {
    return this.hasPermission('tests.approve');
  }

  canExportReports(): boolean {
    return this.hasPermission('reports.export');
  }
}

// Role utility functions
export const getRoleById = (roles: Role[], roleId: string): Role | undefined => {
  return roles.find(role => role.id === roleId);
};

export const getPermissionsByCategory = (category: PermissionCategory): Permission[] => {
  return Object.values(PERMISSIONS).filter(permission => permission.category === category);
};

export const getAllPermissions = (): Permission[] => {
  return Object.values(PERMISSIONS);
};

export const getPermissionCategories = (): PermissionCategory[] => {
  return [
    'system_management',
    'user_management',
    'test_management', 
    'memo_management',
    'report_management',
    'settings_management',
    'developer_tools'
  ];
};