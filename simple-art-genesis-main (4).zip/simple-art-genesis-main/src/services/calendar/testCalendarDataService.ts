import { TestCalendarEvent, TestCalendarFilters } from '@/services/database/realTimeTestCalendarService';

declare global {
  interface Window {
    electronAPI: any;
  }
}

/**
 * Enhanced Test Calendar Data Service
 * Provides complete data abstraction layer for test calendar operations
 */
export class TestCalendarDataService {
  private static instance: TestCalendarDataService;
  private isElectron = false;
  private isInitialized = false;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && !!window.electronAPI;
  }

  static getInstance(): TestCalendarDataService {
    if (!TestCalendarDataService.instance) {
      TestCalendarDataService.instance = new TestCalendarDataService();
    }
    return TestCalendarDataService.instance;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      if (this.isElectron) {
        await this.createRequiredTables();
        await this.ensureIndexes();
        console.log('Test Calendar Data Service initialized successfully');
      } else {
        console.warn('Test Calendar Data Service: Running in browser mode');
        throw new Error('Electron environment required for Test Calendar functionality');
      }
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize Test Calendar Data Service:', error);
      throw error;
    }
  }

  private async createRequiredTables(): Promise<void> {
    const tables = [
      {
        name: 'test_schedule',
        query: `
          CREATE TABLE IF NOT EXISTS test_schedule (
            id TEXT PRIMARY KEY,
            memo_id TEXT NOT NULL,
            test_type TEXT NOT NULL,
            production_date TEXT NOT NULL,
            scheduled_date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'completed', 'overdue', 'cancelled')),
            priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'critical')),
            product_type TEXT,
            plant_location TEXT,
            batch_number TEXT,
            assigned_to TEXT,
            notes TEXT,
            completed_at TEXT,
            completed_by TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
          )
        `
      },
      {
        name: 'test_calendar_filters',
        query: `
          CREATE TABLE IF NOT EXISTS test_calendar_filters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filter_type TEXT NOT NULL,
            filter_value TEXT NOT NULL,
            usage_count INTEGER DEFAULT 0,
            last_used TEXT DEFAULT (datetime('now')),
            created_at TEXT DEFAULT (datetime('now'))
          )
        `
      }
    ];

    for (const table of tables) {
      try {
        await window.electronAPI.dbRun(table.query);
        console.log(`Table ${table.name} verified/created`);
      } catch (error) {
        console.error(`Error creating table ${table.name}:`, error);
        throw error;
      }
    }
  }

  private async ensureIndexes(): Promise<void> {
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_test_schedule_due_date ON test_schedule(due_date)',
      'CREATE INDEX IF NOT EXISTS idx_test_schedule_status ON test_schedule(status)',
      'CREATE INDEX IF NOT EXISTS idx_test_schedule_plant_location ON test_schedule(plant_location)',
      'CREATE INDEX IF NOT EXISTS idx_test_schedule_memo_id ON test_schedule(memo_id)',
      'CREATE INDEX IF NOT EXISTS idx_filter_type ON test_calendar_filters(filter_type)',
    ];

    for (const indexQuery of indexes) {
      try {
        await window.electronAPI.dbRun(indexQuery);
      } catch (error) {
        console.warn('Index creation warning:', error);
      }
    }
  }

  async getTestEvents(filters?: TestCalendarFilters): Promise<TestCalendarEvent[]> {
    await this.initialize();

    try {
      let query = `
        SELECT ts.*, 
               CASE 
                 WHEN ts.status != 'completed' AND ts.due_date < date('now') THEN 'overdue'
                 ELSE ts.status 
               END as current_status,
               CAST(julianday(ts.due_date) - julianday('now') AS INTEGER) as remaining_days
        FROM test_schedule ts 
        WHERE 1=1
      `;
      const params: any[] = [];

      // Apply filters
      if (filters?.startDate) {
        query += ' AND ts.due_date >= ?';
        params.push(filters.startDate);
      }
      if (filters?.endDate) {
        query += ' AND ts.due_date <= ?';
        params.push(filters.endDate);
      }
      if (filters?.status) {
        if (filters.status === 'overdue') {
          query += ' AND ts.status != "completed" AND ts.due_date < date("now")';
        } else {
          query += ' AND ts.status = ?';
          params.push(filters.status);
        }
      }
      if (filters?.labSite) {
        query += ' AND ts.plant_location = ?';
        params.push(filters.labSite);
      }
      if (filters?.product) {
        query += ' AND ts.product_type LIKE ?';
        params.push(`%${filters.product}%`);
      }
      if (filters?.testType) {
        query += ' AND ts.test_type LIKE ?';
        params.push(`%${filters.testType}%`);
      }

      query += ' ORDER BY ts.due_date ASC, ts.priority DESC, ts.created_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      
      if (!result.success) {
        throw new Error(result.error || 'Database query failed');
      }

      return result.data.map((row: any) => this.mapRowToEvent(row));
    } catch (error) {
      console.error('Error fetching test events:', error);
      throw error;
    }
  }

  async getFilterOptions(): Promise<{
    labSites: string[];
    products: string[];
    testTypes: string[];
    statuses: string[];
  }> {
    await this.initialize();

    try {
      const [labSitesResult, productsResult, testTypesResult] = await Promise.all([
        window.electronAPI.dbQuery(`
          SELECT DISTINCT plant_location as value, COUNT(*) as count
          FROM test_schedule 
          WHERE plant_location IS NOT NULL AND plant_location != ''
          GROUP BY plant_location
          ORDER BY count DESC, value ASC
        `),
        window.electronAPI.dbQuery(`
          SELECT DISTINCT product_type as value, COUNT(*) as count
          FROM test_schedule 
          WHERE product_type IS NOT NULL AND product_type != ''
          GROUP BY product_type
          ORDER BY count DESC, value ASC
        `),
        window.electronAPI.dbQuery(`
          SELECT DISTINCT test_type as value, COUNT(*) as count
          FROM test_schedule 
          WHERE test_type IS NOT NULL AND test_type != ''
          GROUP BY test_type
          ORDER BY count DESC, value ASC
        `)
      ]);

      return {
        labSites: labSitesResult.success ? labSitesResult.data.map((row: any) => row.value) : [],
        products: productsResult.success ? productsResult.data.map((row: any) => row.value) : [],
        testTypes: testTypesResult.success ? testTypesResult.data.map((row: any) => row.value) : [],
        statuses: ['scheduled', 'in_progress', 'completed', 'overdue', 'cancelled']
      };
    } catch (error) {
      console.error('Error loading filter options:', error);
      return { labSites: [], products: [], testTypes: [], statuses: [] };
    }
  }

  async markTestDone(eventId: string, userId: string = 'current_user'): Promise<boolean> {
    await this.initialize();

    try {
      const result = await window.electronAPI.dbRun(`
        UPDATE test_schedule 
        SET status = 'completed', 
            completed_at = datetime('now'), 
            completed_by = ?, 
            updated_at = datetime('now')
        WHERE id = ?
      `, [userId, eventId]);

      if (!result.success) {
        throw new Error(result.error || 'Failed to update test status');
      }

      console.log(`Test ${eventId} marked as completed by ${userId}`);
      return true;
    } catch (error) {
      console.error('Error marking test as done:', error);
      throw error;
    }
  }

  async updateTestStatus(eventId: string, status: string, userId: string = 'current_user'): Promise<boolean> {
    await this.initialize();

    try {
      const result = await window.electronAPI.dbRun(`
        UPDATE test_schedule 
        SET status = ?, 
            updated_at = datetime('now')
        WHERE id = ?
      `, [status, eventId]);

      if (!result.success) {
        throw new Error(result.error || 'Failed to update test status');
      }

      return true;
    } catch (error) {
      console.error('Error updating test status:', error);
      throw error;
    }
  }

  async deleteTest(eventId: string): Promise<boolean> {
    await this.initialize();

    try {
      const result = await window.electronAPI.dbRun(`
        DELETE FROM test_schedule WHERE id = ?
      `, [eventId]);

      if (!result.success) {
        throw new Error(result.error || 'Failed to delete test');
      }

      return true;
    } catch (error) {
      console.error('Error deleting test:', error);
      throw error;
    }
  }

  async getAlertCounts(): Promise<{
    overdue: number;
    dueToday: number;
    dueTomorrow: number;
  }> {
    await this.initialize();

    try {
      const [overdueResult, todayResult, tomorrowResult] = await Promise.all([
        window.electronAPI.dbQuery(`
          SELECT COUNT(*) as count 
          FROM test_schedule 
          WHERE status NOT IN ('completed', 'cancelled') 
          AND due_date < date('now')
        `),
        window.electronAPI.dbQuery(`
          SELECT COUNT(*) as count 
          FROM test_schedule 
          WHERE status NOT IN ('completed', 'cancelled') 
          AND due_date = date('now')
        `),
        window.electronAPI.dbQuery(`
          SELECT COUNT(*) as count 
          FROM test_schedule 
          WHERE status NOT IN ('completed', 'cancelled') 
          AND due_date = date('now', '+1 day')
        `)
      ]);

      return {
        overdue: overdueResult.success ? overdueResult.data[0]?.count || 0 : 0,
        dueToday: todayResult.success ? todayResult.data[0]?.count || 0 : 0,
        dueTomorrow: tomorrowResult.success ? tomorrowResult.data[0]?.count || 0 : 0
      };
    } catch (error) {
      console.error('Error getting alert counts:', error);
      return { overdue: 0, dueToday: 0, dueTomorrow: 0 };
    }
  }

  async createTestFromMemo(memoId: string, testData: {
    testType: string;
    productionDate: string;
    dueDate: string;
    productType?: string;
    plantLocation?: string;
    batchNumber?: string;
    priority?: string;
  }): Promise<string> {
    await this.initialize();

    try {
      const eventId = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const result = await window.electronAPI.dbRun(`
        INSERT INTO test_schedule (
          id, memo_id, test_type, production_date, scheduled_date, due_date,
          priority, status, plant_location, product_type, batch_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        eventId,
        memoId,
        testData.testType,
        testData.productionDate,
        testData.dueDate,
        testData.dueDate,
        testData.priority || 'normal',
        'scheduled',
        testData.plantLocation || '',
        testData.productType || '',
        testData.batchNumber || ''
      ]);

      if (!result.success) {
        throw new Error(result.error || 'Failed to create test');
      }

      console.log(`Created test schedule for memo ${memoId}: ${eventId}`);
      return eventId;
    } catch (error) {
      console.error('Error creating test from memo:', error);
      throw error;
    }
  }

  private mapRowToEvent(row: any): TestCalendarEvent {
    return {
      id: row.id,
      memo_id: row.memo_id,
      test_type: row.test_type,
      production_date: row.production_date,
      due_date: row.due_date,
      status: row.current_status || row.status,
      priority: row.priority,
      product: row.product_type || 'Unknown Product',
      assigned_to: row.assigned_to,
      plant_location: row.plant_location,
      batch_number: row.batch_number,
      remaining_days: row.remaining_days || 0,
      notes: row.notes,
      completed_at: row.completed_at,
      completed_by: row.completed_by
    };
  }
}

export const testCalendarDataService = TestCalendarDataService.getInstance();