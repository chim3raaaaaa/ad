/**
 * Real-time Performance Monitoring Service for Test Calendar
 * Measures API latency, render times, memory usage, and other metrics
 */
export interface PerformanceMetrics {
  loadTime: number;
  apiCalls: number;
  cacheHits: number;
  memoryUsage: string;
  eventsCount: number;
  filterTime: number;
  queryTime: number;
  renderTime: number;
  apiLatency: number;
  lastUpdated: number;
}

export class RealTimePerformanceService {
  private static instance: RealTimePerformanceService;
  private metrics: PerformanceMetrics;
  private startTimes: Map<string, number> = new Map();
  private apiCallCount = 0;
  private cacheHitCount = 0;

  constructor() {
    this.metrics = {
      loadTime: 0,
      apiCalls: 0,
      cacheHits: 0,
      memoryUsage: '0MB',
      eventsCount: 0,
      filterTime: 0,
      queryTime: 0,
      renderTime: 0,
      apiLatency: 0,
      lastUpdated: Date.now()
    };
  }

  static getInstance(): RealTimePerformanceService {
    if (!RealTimePerformanceService.instance) {
      RealTimePerformanceService.instance = new RealTimePerformanceService();
    }
    return RealTimePerformanceService.instance;
  }

  startTimer(operation: string): void {
    this.startTimes.set(operation, performance.now());
  }

  endTimer(operation: string): number {
    const startTime = this.startTimes.get(operation);
    if (!startTime) return 0;
    
    const duration = performance.now() - startTime;
    this.startTimes.delete(operation);
    
    // Update relevant metrics based on operation type
    switch (operation) {
      case 'pageLoad':
        this.metrics.loadTime = duration;
        break;
      case 'filter':
        this.metrics.filterTime = duration;
        break;
      case 'query':
        this.metrics.queryTime = duration;
        break;
      case 'render':
        this.metrics.renderTime = duration;
        break;
      case 'api':
        this.metrics.apiLatency = duration;
        this.apiCallCount++;
        this.metrics.apiCalls = this.apiCallCount;
        break;
    }
    
    this.updateTimestamp();
    return duration;
  }

  recordCacheHit(): void {
    this.cacheHitCount++;
    this.metrics.cacheHits = this.cacheHitCount;
    this.updateTimestamp();
  }

  updateEventsCount(count: number): void {
    this.metrics.eventsCount = count;
    this.updateTimestamp();
  }

  updateMemoryUsage(): void {
    if (typeof window !== 'undefined' && (performance as any).memory) {
      const memoryInfo = (performance as any).memory;
      const usedMB = Math.round(memoryInfo.usedJSHeapSize / 1024 / 1024);
      this.metrics.memoryUsage = `${usedMB}MB`;
    } else {
      // Fallback estimate based on data size
      const estimatedMB = Math.round(this.metrics.eventsCount * 0.001); // Rough estimate
      this.metrics.memoryUsage = `~${estimatedMB}MB`;
    }
    this.updateTimestamp();
  }

  private updateTimestamp(): void {
    this.metrics.lastUpdated = Date.now();
  }

  getMetrics(): PerformanceMetrics {
    this.updateMemoryUsage();
    return { ...this.metrics };
  }

  resetMetrics(): void {
    this.apiCallCount = 0;
    this.cacheHitCount = 0;
    this.startTimes.clear();
    this.metrics = {
      loadTime: 0,
      apiCalls: 0,
      cacheHits: 0,
      memoryUsage: '0MB',
      eventsCount: 0,
      filterTime: 0,
      queryTime: 0,
      renderTime: 0,
      apiLatency: 0,
      lastUpdated: Date.now()
    };
  }

  getPerformanceReport(): {
    overall: 'excellent' | 'good' | 'fair' | 'poor';
    recommendations: string[];
    scores: {
      loadTime: number;
      cacheEfficiency: number;
      queryPerformance: number;
      memoryEfficiency: number;
    };
  } {
    const metrics = this.getMetrics();
    
    // Calculate scores (0-100)
    const loadTimeScore = Math.max(0, 100 - (metrics.loadTime / 30)); // 30ms = 70 points
    const cacheEfficiency = metrics.apiCalls > 0 ? (metrics.cacheHits / metrics.apiCalls) * 100 : 100;
    const queryScore = Math.max(0, 100 - (metrics.queryTime / 10)); // 10ms = 90 points
    const memoryScore = Math.max(0, 100 - (parseInt(metrics.memoryUsage) / 2)); // 2MB = 50 points
    
    const averageScore = (loadTimeScore + cacheEfficiency + queryScore + memoryScore) / 4;
    
    let overall: 'excellent' | 'good' | 'fair' | 'poor';
    if (averageScore >= 85) overall = 'excellent';
    else if (averageScore >= 70) overall = 'good';
    else if (averageScore >= 50) overall = 'fair';
    else overall = 'poor';
    
    const recommendations: string[] = [];
    
    if (metrics.loadTime > 2000) {
      recommendations.push('Reduce initial data load size or implement lazy loading');
    }
    if (cacheEfficiency < 50 && metrics.apiCalls > 5) {
      recommendations.push('Implement better caching strategy to reduce API calls');
    }
    if (metrics.queryTime > 500) {
      recommendations.push('Optimize database queries or reduce filter complexity');
    }
    if (metrics.eventsCount > 1000) {
      recommendations.push('Implement pagination for large datasets');
    }
    if (parseInt(metrics.memoryUsage) > 50) {
      recommendations.push('Optimize data structures to reduce memory usage');
    }
    if (metrics.renderTime > 100) {
      recommendations.push('Optimize component rendering or reduce UI complexity');
    }
    
    if (recommendations.length === 0) {
      recommendations.push('Performance is optimal - no recommendations needed');
    }
    
    return {
      overall,
      recommendations,
      scores: {
        loadTime: Math.round(loadTimeScore),
        cacheEfficiency: Math.round(cacheEfficiency),
        queryPerformance: Math.round(queryScore),
        memoryEfficiency: Math.round(memoryScore)
      }
    };
  }
}

export const realTimePerformanceService = RealTimePerformanceService.getInstance();