import { toast } from '@/hooks/use-toast';

export interface CalendarProvider {
  id: string;
  name: string;
  type: 'google' | 'outlook' | 'exchange' | 'caldav';
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
  config?: Record<string, any>;
}

export interface ExternalCalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  location?: string;
  attendees?: string[];
  calendarId: string;
  source: 'lims' | 'external';
  syncStatus: 'synced' | 'pending' | 'error';
}

export interface CalendarSyncConfig {
  autoSync: boolean;
  syncInterval: number; // minutes
  conflictResolution: 'lims_priority' | 'external_priority' | 'manual';
  syncDirection: 'bidirectional' | 'lims_to_external' | 'external_to_lims';
  eventPrefix: string;
}

class ExternalCalendarService {
  private providers: Map<string, CalendarProvider> = new Map();
  private events: ExternalCalendarEvent[] = [];
  private config: CalendarSyncConfig = {
    autoSync: true,
    syncInterval: 30,
    conflictResolution: 'lims_priority',
    syncDirection: 'bidirectional',
    eventPrefix: '[LIMS]'
  };

  constructor() {
    this.initializeProviders();
    this.loadConfiguration();
  }

  private initializeProviders() {
    // Initialize available calendar providers
    const defaultProviders: CalendarProvider[] = [
      {
        id: 'google',
        name: 'Google Calendar',
        type: 'google',
        status: 'disconnected'
      },
      {
        id: 'outlook',
        name: 'Microsoft Outlook',
        type: 'outlook',
        status: 'disconnected'
      },
      {
        id: 'exchange',
        name: 'Exchange Server',
        type: 'exchange',
        status: 'disconnected'
      }
    ];

    defaultProviders.forEach(provider => {
      this.providers.set(provider.id, provider);
    });
  }

  private async loadConfiguration() {
    try {
      const stored = localStorage.getItem('lims-calendar-config');
      if (stored) {
        this.config = { ...this.config, ...JSON.parse(stored) };
      }
    } catch (error) {
      console.error('Error loading calendar configuration:', error);
    }
  }

  async connectProvider(providerId: string, credentials?: any): Promise<boolean> {
    const provider = this.providers.get(providerId);
    if (!provider) {
      throw new Error(`Provider ${providerId} not found`);
    }

    try {
      switch (provider.type) {
        case 'google':
          return await this.connectGoogleCalendar(credentials);
        case 'outlook':
          return await this.connectOutlookCalendar(credentials);
        case 'exchange':
          return await this.connectExchangeCalendar(credentials);
        default:
          throw new Error(`Unsupported provider type: ${provider.type}`);
      }
    } catch (error) {
      console.error(`Error connecting to ${provider.name}:`, error);
      provider.status = 'error';
      toast({
        title: 'Connection Failed',
        description: `Failed to connect to ${provider.name}: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: 'destructive'
      });
      return false;
    }
  }

  private async connectGoogleCalendar(credentials: any): Promise<boolean> {
    // Simulate Google Calendar API integration
    // In real implementation, use Google Calendar API with OAuth
    
    try {
      // Mock implementation for demonstration
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const provider = this.providers.get('google')!;
      provider.status = 'connected';
      provider.lastSync = new Date().toISOString();
      provider.config = {
        accessToken: credentials?.accessToken || 'mock_token',
        refreshToken: credentials?.refreshToken || 'mock_refresh',
        calendarId: credentials?.calendarId || 'primary'
      };

      toast({
        title: 'Connected to Google Calendar',
        description: 'Successfully connected to Google Calendar. Events will now sync automatically.',
      });

      return true;
    } catch (error) {
      console.error('Google Calendar connection error:', error);
      return false;
    }
  }

  private async connectOutlookCalendar(credentials: any): Promise<boolean> {
    // Simulate Outlook Calendar API integration
    // In real implementation, use Microsoft Graph API
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const provider = this.providers.get('outlook')!;
      provider.status = 'connected';
      provider.lastSync = new Date().toISOString();
      provider.config = {
        accessToken: credentials?.accessToken || 'mock_token',
        tenantId: credentials?.tenantId || 'mock_tenant',
        calendarId: credentials?.calendarId || 'primary'
      };

      toast({
        title: 'Connected to Outlook',
        description: 'Successfully connected to Microsoft Outlook. Events will now sync automatically.',
      });

      return true;
    } catch (error) {
      console.error('Outlook connection error:', error);
      return false;
    }
  }

  private async connectExchangeCalendar(credentials: any): Promise<boolean> {
    // Simulate Exchange Server integration
    // In real implementation, use Exchange Web Services (EWS)
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const provider = this.providers.get('exchange')!;
      provider.status = 'connected';
      provider.lastSync = new Date().toISOString();
      provider.config = {
        serverUrl: credentials?.serverUrl || 'https://exchange.example.com',
        username: credentials?.username || 'user@example.com',
        domain: credentials?.domain || 'DOMAIN'
      };

      toast({
        title: 'Connected to Exchange',
        description: 'Successfully connected to Exchange Server. Events will now sync automatically.',
      });

      return true;
    } catch (error) {
      console.error('Exchange connection error:', error);
      return false;
    }
  }

  async syncEvents(providerId?: string): Promise<{ imported: number; exported: number; conflicts: number }> {
    const providers = providerId ? 
      [this.providers.get(providerId)].filter(Boolean) : 
      Array.from(this.providers.values()).filter(p => p.status === 'connected');

    let totalImported = 0;
    let totalExported = 0;
    let totalConflicts = 0;

    for (const provider of providers) {
      try {
        const result = await this.syncProviderEvents(provider!);
        totalImported += result.imported;
        totalExported += result.exported;
        totalConflicts += result.conflicts;

        provider!.lastSync = new Date().toISOString();
      } catch (error) {
        console.error(`Error syncing ${provider!.name}:`, error);
        provider!.status = 'error';
      }
    }

    if (totalImported > 0 || totalExported > 0) {
      toast({
        title: 'Calendar Sync Complete',
        description: `Imported ${totalImported}, exported ${totalExported} events. ${totalConflicts} conflicts detected.`,
      });
    }

    return { imported: totalImported, exported: totalExported, conflicts: totalConflicts };
  }

  private async syncProviderEvents(provider: CalendarProvider): Promise<{ imported: number; exported: number; conflicts: number }> {
    let imported = 0;
    let exported = 0;
    let conflicts = 0;

    try {
      // Import events from external calendar
      if (this.config.syncDirection === 'bidirectional' || this.config.syncDirection === 'external_to_lims') {
        const externalEvents = await this.fetchExternalEvents(provider);
        imported = await this.importEvents(externalEvents);
      }

      // Export LIMS events to external calendar
      if (this.config.syncDirection === 'bidirectional' || this.config.syncDirection === 'lims_to_external') {
        const limsEvents = await this.getLIMSEvents();
        exported = await this.exportEvents(limsEvents, provider);
      }

      // Detect and resolve conflicts
      conflicts = await this.detectAndResolveConflicts(provider);

    } catch (error) {
      console.error(`Error in provider sync for ${provider.name}:`, error);
      throw error;
    }

    return { imported, exported, conflicts };
  }

  private async fetchExternalEvents(provider: CalendarProvider): Promise<ExternalCalendarEvent[]> {
    // Mock external events fetch
    // In real implementation, call respective calendar APIs
    
    const mockEvents: ExternalCalendarEvent[] = [
      {
        id: `ext_${provider.id}_1`,
        title: 'Team Meeting',
        description: 'Weekly team sync',
        startTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        endTime: new Date(Date.now() + 25 * 60 * 60 * 1000).toISOString(),
        calendarId: provider.id,
        source: 'external',
        syncStatus: 'pending'
      }
    ];

    return mockEvents;
  }

  private async getLIMSEvents(): Promise<ExternalCalendarEvent[]> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return [];

    try {
      const result = await window.electronAPI.dbQuery(`
        SELECT 
          id,
          test_type,
          scheduled_date,
          scheduled_time,
          estimated_end_time,
          memo_id,
          priority
        FROM scheduled_tests
        WHERE scheduled_date >= date('now')
        ORDER BY scheduled_date, scheduled_time
      `);

      if (!result.success) return [];

      return result.data.map((test: any) => ({
        id: `lims_${test.id}`,
        title: `${this.config.eventPrefix} ${test.test_type}`,
        description: `Test for memo ${test.memo_id}\nPriority: ${test.priority}`,
        startTime: `${test.scheduled_date}T${test.scheduled_time}:00`,
        endTime: `${test.scheduled_date}T${test.estimated_end_time}:00`,
        location: 'Laboratory',
        calendarId: 'lims',
        source: 'lims' as const,
        syncStatus: 'pending' as const
      }));
    } catch (error) {
      console.error('Error fetching LIMS events:', error);
      return [];
    }
  }

  private async importEvents(events: ExternalCalendarEvent[]): Promise<number> {
    let imported = 0;

    for (const event of events) {
      try {
        // Check if event conflicts with existing LIMS events
        const hasConflict = await this.checkEventConflict(event);
        
        if (!hasConflict || this.config.conflictResolution === 'external_priority') {
          // Import event as read-only information
          // In a real implementation, you might create calendar entries in LIMS
          console.log(`Importing external event: ${event.title}`);
          imported++;
        }
      } catch (error) {
        console.error(`Error importing event ${event.id}:`, error);
      }
    }

    return imported;
  }

  private async exportEvents(events: ExternalCalendarEvent[], provider: CalendarProvider): Promise<number> {
    let exported = 0;

    for (const event of events) {
      try {
        // Export to external calendar
        // In real implementation, call respective calendar APIs
        console.log(`Exporting to ${provider.name}: ${event.title}`);
        exported++;
      } catch (error) {
        console.error(`Error exporting event ${event.id} to ${provider.name}:`, error);
      }
    }

    return exported;
  }

  private async checkEventConflict(event: ExternalCalendarEvent): Promise<boolean> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return false;

    try {
      const eventDate = new Date(event.startTime).toISOString().split('T')[0];
      const eventTime = new Date(event.startTime).toTimeString().split(' ')[0].substring(0, 5);

      const result = await window.electronAPI.dbQuery(`
        SELECT COUNT(*) as conflict_count
        FROM scheduled_tests
        WHERE scheduled_date = ? AND scheduled_time = ?
      `, [eventDate, eventTime]);

      return result.success && result.data[0]?.conflict_count > 0;
    } catch (error) {
      console.error('Error checking event conflict:', error);
      return false;
    }
  }

  private async detectAndResolveConflicts(provider: CalendarProvider): Promise<number> {
    // Simplified conflict detection
    // In real implementation, compare timestamps and resolve based on config
    return 0;
  }

  async updateConfiguration(newConfig: Partial<CalendarSyncConfig>): Promise<void> {
    this.config = { ...this.config, ...newConfig };
    localStorage.setItem('lims-calendar-config', JSON.stringify(this.config));

    toast({
      title: 'Configuration Updated',
      description: 'Calendar sync settings have been saved.',
    });
  }

  getProviders(): CalendarProvider[] {
    return Array.from(this.providers.values());
  }

  getConfiguration(): CalendarSyncConfig {
    return { ...this.config };
  }

  async disconnectProvider(providerId: string): Promise<void> {
    const provider = this.providers.get(providerId);
    if (provider) {
      provider.status = 'disconnected';
      provider.config = undefined;
      provider.lastSync = undefined;

      toast({
        title: 'Provider Disconnected',
        description: `Disconnected from ${provider.name}`,
      });
    }
  }

  async startAutoSync(): Promise<void> {
    if (!this.config.autoSync) return;

    const syncInterval = this.config.syncInterval * 60 * 1000; // Convert to milliseconds

    setInterval(async () => {
      try {
        await this.syncEvents();
      } catch (error) {
        console.error('Error in auto sync:', error);
      }
    }, syncInterval);

    console.log(`Auto sync started with ${this.config.syncInterval} minute interval`);
  }
}

export const externalCalendarService = new ExternalCalendarService();