import { TestCalendarEvent } from '@/types';

export interface ExportOptions {
  format: 'pdf' | 'csv' | 'ical';
  dateRange?: {
    start: Date;
    end: Date;
  };
  filters?: {
    status?: string;
    product?: string;
    location?: string;
  };
}

export class CalendarExportService {
  static async exportToPDF(events: TestCalendarEvent[], options?: ExportOptions): Promise<Blob> {
    const { jsPDF } = await import('jspdf');
    require('jspdf-autotable');
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(20);
    doc.text('Test Calendar Report', 20, 20);
    
    // Add metadata
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);
    doc.text(`Total Events: ${events.length}`, 20, 35);
    
    if (options?.dateRange) {
      doc.text(`Date Range: ${options.dateRange.start.toLocaleDateString()} to ${options.dateRange.end.toLocaleDateString()}`, 20, 40);
    }
    
    // Prepare table data
    const tableData = events.map(event => [
      event.memo_id,
      event.test_type,
      event.product,
      new Date(event.due_date).toLocaleDateString(),
      event.status.charAt(0).toUpperCase() + event.status.slice(1),
      event.priority?.charAt(0).toUpperCase() + event.priority?.slice(1) || 'Normal',
      event.assigned_to || 'Unassigned',
      event.plant_location || 'N/A'
    ]);
    
    // Add table with autoTable
    (doc as any).autoTable({
      head: [['Memo ID', 'Test Type', 'Product', 'Due Date', 'Status', 'Priority', 'Officer', 'Location']],
      body: tableData,
      startY: options?.dateRange ? 50 : 45,
      styles: {
        fontSize: 8,
        cellPadding: 2
      },
      headStyles: {
        fillColor: [66, 139, 202],
        textColor: 255
      },
      alternateRowStyles: {
        fillColor: [245, 245, 245]
      },
      columnStyles: {
        0: { cellWidth: 20 }, // Memo ID
        1: { cellWidth: 25 }, // Test Type
        2: { cellWidth: 25 }, // Product
        3: { cellWidth: 20 }, // Due Date
        4: { cellWidth: 18 }, // Status
        5: { cellWidth: 18 }, // Priority
        6: { cellWidth: 25 }, // Officer
        7: { cellWidth: 25 }  // Location
      }
    });
    
    return doc.output('blob');
  }

  static async exportToCSV(events: TestCalendarEvent[]): Promise<Blob> {
    const headers = ['ID', 'Memo ID', 'Product', 'Test Type', 'Due Date', 'Status', 'Priority', 'Plant Location', 'Batch Number', 'Assigned To', 'Notes'];
    const csvContent = [
      headers.join(','),
      ...events.map(event => [
        event.id,
        event.memo_id,
        event.product,
        event.test_type,
        event.due_date,
        event.status,
        event.priority || '',
        event.plant_location || '',
        event.batch_number || '',
        event.assigned_to || '',
        event.notes || ''
      ].map(field => `"${field}"`).join(','))
    ].join('\n');
    
    return new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  }

  static async exportToICal(events: TestCalendarEvent[]): Promise<Blob> {
    const icalHeader = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Test Calendar//Test Events//EN',
      'CALSCALE:GREGORIAN'
    ].join('\r\n');
    
    const icalEvents = events.map(event => {
      const startDate = new Date(event.due_date).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      return [
        'BEGIN:VEVENT',
        `UID:${event.id}@testcalendar.local`,
        `DTSTART:${startDate}`,
        `SUMMARY:${event.product} - ${event.test_type}`,
        `DESCRIPTION:Test event for ${event.product}${event.plant_location ? ` at ${event.plant_location}` : ''}${event.notes ? ` - ${event.notes}` : ''}`,
        `LOCATION:${event.plant_location || ''}`,
        `STATUS:${event.status.toUpperCase()}`,
        'END:VEVENT'
      ].join('\r\n');
    }).join('\r\n');
    
    const icalFooter = 'END:VCALENDAR';
    const icalContent = [icalHeader, icalEvents, icalFooter].join('\r\n');
    
    return new Blob([icalContent], { type: 'text/calendar;charset=utf-8;' });
  }

  static downloadBlob(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}