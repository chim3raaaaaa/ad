import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { DashboardWidget } from '@/types/dashboard';

// Extend jsPDF with autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export interface ExportOptions {
  format: 'pdf' | 'excel' | 'csv' | 'json';
  filename?: string;
  includeCharts?: boolean;
  dateRange?: {
    start: string;
    end: string;
  };
}

export interface ExportData {
  title: string;
  data: Record<string, any>[];
  headers?: string[];
  metadata?: {
    exportDate: string;
    generatedBy: string;
    description?: string;
  };
}

class DataExportService {
  async exportDashboard(widgets: DashboardWidget[], options: ExportOptions): Promise<void> {
    const exportData: ExportData[] = [];

    // Collect data from all widgets
    for (const widget of widgets) {
      const widgetData = await this.getWidgetData(widget);
      if (widgetData) {
        exportData.push(widgetData);
      }
    }

    const filename = options.filename || `dashboard-export-${new Date().toISOString().split('T')[0]}`;

    switch (options.format) {
      case 'pdf':
        await this.exportToPDF(exportData, filename);
        break;
      case 'excel':
        await this.exportToExcel(exportData, filename);
        break;
      case 'csv':
        await this.exportToCSV(exportData, filename);
        break;
      case 'json':
        await this.exportToJSON(exportData, filename);
        break;
    }
  }

  async exportWidget(widget: DashboardWidget, options: ExportOptions): Promise<void> {
    const widgetData = await this.getWidgetData(widget);
    if (!widgetData) return;

    const filename = options.filename || `${widget.title.toLowerCase().replace(/\s+/g, '-')}-export`;

    switch (options.format) {
      case 'pdf':
        await this.exportToPDF([widgetData], filename);
        break;
      case 'excel':
        await this.exportToExcel([widgetData], filename);
        break;
      case 'csv':
        await this.exportToCSV([widgetData], filename);
        break;
      case 'json':
        await this.exportToJSON([widgetData], filename);
        break;
    }
  }

  private async getWidgetData(widget: DashboardWidget): Promise<ExportData | null> {
    try {
      const isElectron = typeof window !== 'undefined' && window.electronAPI;
      
      if (!isElectron) {
        throw new Error('Data export requires Electron environment with SQLite database');
      }

      // Get real data based on widget type
      switch (widget.type) {
        case 'kpi':
          return await this.getKPIData(widget);
        case 'chart':
        case 'bar':
        case 'line':
        case 'pie':
          return await this.getChartData(widget);
        case 'calendar':
          return await this.getCalendarData(widget);
        default:
          throw new Error(`Unsupported widget type: ${widget.type}`);
      }
    } catch (error) {
      console.error(`Error getting data for widget ${widget.id}:`, error);
      throw new Error(`Failed to export widget "${widget.title}": ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async getKPIData(widget: DashboardWidget): Promise<ExportData> {
    try {
      // Query relevant data based on widget configuration
      const result = await window.electronAPI.dbQuery(`
        SELECT 
          'Total Memos' as metric,
          COUNT(*) as value,
          'current' as period
        FROM memos
        UNION ALL
        SELECT 
          'Completed Tests' as metric,
          COUNT(*) as value,
          'current' as period
        FROM memos WHERE status = 'completed'
      `);

      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }

      return {
        title: widget.title,
        data: result.data || [],
        headers: ['Metric', 'Value', 'Period'],
        metadata: {
          exportDate: new Date().toISOString(),
          generatedBy: 'Dashboard Export',
          description: widget.description
        }
      };
    } catch (error) {
      console.error('Error getting KPI data:', error);
      throw new Error('Failed to retrieve KPI data from database');
    }
  }

  private async getChartData(widget: DashboardWidget): Promise<ExportData> {
    try {
      // Get chart data based on widget configuration
      const result = await window.electronAPI.dbQuery(`
        SELECT 
          strftime('%Y-%m', created_at) as period,
          COUNT(*) as value,
          status
        FROM memos 
        WHERE created_at >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', created_at), status
        ORDER BY period DESC
      `);

      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }

      return {
        title: widget.title,
        data: result.data || [],
        headers: ['Period', 'Value', 'Status'],
        metadata: {
          exportDate: new Date().toISOString(),
          generatedBy: 'Dashboard Export',
          description: widget.description
        }
      };
    } catch (error) {
      console.error('Error getting chart data:', error);
      throw new Error('Failed to retrieve chart data from database');
    }
  }

  private async getCalendarData(widget: DashboardWidget): Promise<ExportData> {
    try {
      const result = await window.electronAPI.dbQuery(`
        SELECT 
          memo_ref,
          json_extract(production_data, '$[0].production_date') as production_date,
          date(json_extract(production_data, '$[0].production_date'), '+28 days') as due_date,
          status,
          created_at
        FROM memos 
        WHERE json_extract(production_data, '$[0].production_date') IS NOT NULL
        ORDER BY due_date ASC
      `);

      if (!result.success) {
        throw new Error(`Database error: ${result.error}`);
      }

      return {
        title: widget.title,
        data: result.data || [],
        headers: ['Memo Ref', 'Production Date', 'Due Date', 'Status', 'Created At'],
        metadata: {
          exportDate: new Date().toISOString(),
          generatedBy: 'Dashboard Export',
          description: widget.description
        }
      };
    } catch (error) {
      console.error('Error getting calendar data:', error);
      throw new Error('Failed to retrieve calendar data from database');
    }
  }


  private async exportToPDF(data: ExportData[], filename: string): Promise<void> {
    const pdf = new jsPDF();
    let yPosition = 20;

    // Add title
    pdf.setFontSize(20);
    pdf.text('Dashboard Export', 20, yPosition);
    yPosition += 20;

    // Add metadata
    pdf.setFontSize(10);
    pdf.text(`Generated: ${new Date().toLocaleString()}`, 20, yPosition);
    yPosition += 10;

    for (const dataset of data) {
      // Check if we need a new page
      if (yPosition > 250) {
        pdf.addPage();
        yPosition = 20;
      }

      // Add dataset title
      pdf.setFontSize(14);
      pdf.text(dataset.title, 20, yPosition);
      yPosition += 10;

      // Add table
      if (dataset.data.length > 0) {
        const headers = dataset.headers || Object.keys(dataset.data[0]);
        const rows = dataset.data.map(row => headers.map(header => row[header] || ''));

        pdf.autoTable({
          head: [headers],
          body: rows,
          startY: yPosition,
          margin: { left: 20, right: 20 }
        });

        yPosition = (pdf as any).lastAutoTable.finalY + 20;
      }
    }

    pdf.save(`${filename}.pdf`);
  }

  private async exportToExcel(data: ExportData[], filename: string): Promise<void> {
    const workbook = XLSX.utils.book_new();

    for (const dataset of data) {
      // Create worksheet
      const worksheet = XLSX.utils.json_to_sheet(dataset.data);
      
      // Add custom headers if provided
      if (dataset.headers) {
        XLSX.utils.sheet_add_aoa(worksheet, [dataset.headers], { origin: 'A1' });
      }

      // Add metadata as a separate sheet
      const metaWorksheet = XLSX.utils.json_to_sheet([dataset.metadata || {}]);
      
      // Add worksheets to workbook
      const sheetName = dataset.title.substring(0, 31); // Excel sheet name limit
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
      XLSX.utils.book_append_sheet(workbook, metaWorksheet, `${sheetName}_Meta`);
    }

    // Write file
    XLSX.writeFile(workbook, `${filename}.xlsx`);
  }

  private async exportToCSV(data: ExportData[], filename: string): Promise<void> {
    for (const dataset of data) {
      const worksheet = XLSX.utils.json_to_sheet(dataset.data);
      const csv = XLSX.utils.sheet_to_csv(worksheet);
      
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}-${dataset.title.toLowerCase().replace(/\s+/g, '-')}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    }
  }

  private async exportToJSON(data: ExportData[], filename: string): Promise<void> {
    const exportObject = {
      exportDate: new Date().toISOString(),
      datasets: data
    };

    const json = JSON.stringify(exportObject, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  async exportMemoData(options: ExportOptions & { memoIds?: string[] }): Promise<void> {
    const isElectron = typeof window !== 'undefined' && window.electronAPI;
    if (!isElectron) return;

    try {
      let query = 'SELECT * FROM memos';
      let params: any[] = [];

      if (options.memoIds && options.memoIds.length > 0) {
        query += ` WHERE id IN (${options.memoIds.map(() => '?').join(',')})`;
        params = options.memoIds;
      } else if (options.dateRange) {
        query += ' WHERE created_at BETWEEN ? AND ?';
        params = [options.dateRange.start, options.dateRange.end];
      }

      query += ' ORDER BY created_at DESC';

      const result = await window.electronAPI.dbQuery(query, params);
      
      if (result.success) {
        const exportData: ExportData = {
          title: 'Memo Data Export',
          data: result.data,
          headers: ['ID', 'Memo Ref', 'Status', 'Created At', 'Updated At', 'Production Data'],
          metadata: {
            exportDate: new Date().toISOString(),
            generatedBy: 'LIMS Export System',
            description: 'Complete memo data export'
          }
        };

        const filename = options.filename || `memo-export-${new Date().toISOString().split('T')[0]}`;

        switch (options.format) {
          case 'pdf':
            await this.exportToPDF([exportData], filename);
            break;
          case 'excel':
            await this.exportToExcel([exportData], filename);
            break;
          case 'csv':
            await this.exportToCSV([exportData], filename);
            break;
          case 'json':
            await this.exportToJSON([exportData], filename);
            break;
        }
      }
    } catch (error) {
      console.error('Error exporting memo data:', error);
      throw error;
    }
  }
}

export const dataExportService = new DataExportService();