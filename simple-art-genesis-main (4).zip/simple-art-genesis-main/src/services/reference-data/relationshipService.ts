import { dataService } from '../api';

export interface DataRelationship {
  id: string;
  name: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  relationshipType: '1:1' | '1:M' | 'M:1' | 'M:M';
  description?: string;
  created_at: string;
  updated_at: string;
  active: boolean;
}

export interface DependencyIssue {
  id: string;
  type: 'missing_reference' | 'orphaned_record' | 'circular_dependency' | 'invalid_constraint';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  sourceTable: string;
  sourceRecord?: string;
  targetTable?: string;
  targetRecord?: string;
  suggestion: string;
  detected_at: string;
  resolved: boolean;
}

export interface RelationshipValidation {
  valid: boolean;
  issues: DependencyIssue[];
  affectedRecords: number;
}

class RelationshipService {
  private predefinedRelationships: Omit<DataRelationship, 'id' | 'created_at' | 'updated_at'>[] = [
    {
      name: 'Product to Category',
      sourceTable: 'products',
      sourceField: 'category_id',
      targetTable: 'product_categories',
      targetField: 'id',
      relationshipType: 'M:1',
      description: 'Each product belongs to one category',
      active: true
    },
    {
      name: 'Plant to Sampling Places',
      sourceTable: 'sampling_places',
      sourceField: 'plant_id',
      targetTable: 'plants',
      targetField: 'id',
      relationshipType: 'M:1',
      description: 'Sampling places belong to plants',
      active: true
    },
    {
      name: 'Test Requests to Products',
      sourceTable: 'test_requests',
      sourceField: 'product_id',
      targetTable: 'products',
      targetField: 'id',
      relationshipType: 'M:1',
      description: 'Test requests are for specific products',
      active: true
    },
    {
      name: 'Test Requests to Clients',
      sourceTable: 'test_requests',
      sourceField: 'client_id',
      targetTable: 'clients',
      targetField: 'id',
      relationshipType: 'M:1',
      description: 'Test requests are submitted by clients',
      active: true
    }
  ];

  async getRelationships(): Promise<DataRelationship[]> {
    try {
      const relationships = await dataService.getDataRelationships();
      return relationships;
    } catch (error) {
      console.error('Error fetching relationships:', error);
      // Return predefined relationships as fallback
      return this.predefinedRelationships.map(rel => ({
        ...rel,
        id: crypto.randomUUID(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }));
    }
  }

  async createRelationship(relationship: Omit<DataRelationship, 'id' | 'created_at' | 'updated_at'>): Promise<DataRelationship> {
    try {
      const newRelationship = {
        ...relationship,
        id: crypto.randomUUID(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      await dataService.createDataRelationship(newRelationship);
      return newRelationship;
    } catch (error) {
      console.error('Error creating relationship:', error);
      throw error;
    }
  }

  async updateRelationship(id: string, updates: Partial<DataRelationship>): Promise<DataRelationship> {
    try {
      const relationships = await this.getRelationships();
      const existing = relationships.find(r => r.id === id);
      if (!existing) {
        throw new Error('Relationship not found');
      }

      const updated = {
        ...existing,
        ...updates,
        updated_at: new Date().toISOString()
      };

      // In a real implementation, this would update the database
      return updated;
    } catch (error) {
      console.error('Error updating relationship:', error);
      throw error;
    }
  }

  async deleteRelationship(id: string): Promise<boolean> {
    try {
      await dataService.deleteDataRelationship(id);
      return true;
    } catch (error) {
      console.error('Error deleting relationship:', error);
      return false;
    }
  }

  async validateRelationships(): Promise<RelationshipValidation> {
    try {
      const relationships = await this.getRelationships();
      const issues: DependencyIssue[] = [];
      let affectedRecords = 0;

      for (const relationship of relationships) {
        if (!relationship.active) continue;

        // Check for missing references
        const missingRefs = await this.findMissingReferences(relationship);
        issues.push(...missingRefs);
        affectedRecords += missingRefs.length;

        // Check for orphaned records
        const orphaned = await this.findOrphanedRecords(relationship);
        issues.push(...orphaned);
        affectedRecords += orphaned.length;
      }

      // Check for circular dependencies
      const circular = await this.findCircularDependencies(relationships);
      issues.push(...circular);

      return {
        valid: issues.length === 0,
        issues,
        affectedRecords
      };
    } catch (error) {
      console.error('Error validating relationships:', error);
      return {
        valid: false,
        issues: [{
          id: crypto.randomUUID(),
          type: 'invalid_constraint',
          severity: 'critical',
          title: 'Validation Error',
          description: 'Failed to validate relationships',
          sourceTable: 'system',
          suggestion: 'Check database connectivity and retry validation',
          detected_at: new Date().toISOString(),
          resolved: false
        }],
        affectedRecords: 0
      };
    }
  }

  private async findMissingReferences(relationship: DataRelationship): Promise<DependencyIssue[]> {
    const issues: DependencyIssue[] = [];
    
    try {
      // Get source data
      const sourceData = await dataService.getReferenceData(relationship.sourceTable);
      const targetData = await dataService.getReferenceData(relationship.targetTable);
      
      const targetIds = new Set(targetData.map(record => record[relationship.targetField]));
      
      sourceData.forEach(sourceRecord => {
        const foreignKey = sourceRecord[relationship.sourceField];
        if (foreignKey && !targetIds.has(foreignKey)) {
          issues.push({
            id: crypto.randomUUID(),
            type: 'missing_reference',
            severity: 'high',
            title: 'Missing Reference',
            description: `Record in ${relationship.sourceTable} references non-existent ${relationship.targetTable}`,
            sourceTable: relationship.sourceTable,
            sourceRecord: sourceRecord.id,
            targetTable: relationship.targetTable,
            targetRecord: foreignKey,
            suggestion: `Create the missing ${relationship.targetTable} record or update the reference`,
            detected_at: new Date().toISOString(),
            resolved: false
          });
        }
      });
    } catch (error) {
      console.error('Error finding missing references:', error);
    }
    
    return issues;
  }

  private async findOrphanedRecords(relationship: DataRelationship): Promise<DependencyIssue[]> {
    const issues: DependencyIssue[] = [];
    
    try {
      // For 1:M relationships, check if target records have any source references
      if (relationship.relationshipType === '1:M') {
        const sourceData = await dataService.getReferenceData(relationship.sourceTable);
        const targetData = await dataService.getReferenceData(relationship.targetTable);
        
        const referencedIds = new Set(
          sourceData
            .map(record => record[relationship.sourceField])
            .filter(id => id != null)
        );
        
        targetData.forEach(targetRecord => {
          const targetId = targetRecord[relationship.targetField];
          if (!referencedIds.has(targetId)) {
            issues.push({
              id: crypto.randomUUID(),
              type: 'orphaned_record',
              severity: 'medium',
              title: 'Orphaned Record',
              description: `Record in ${relationship.targetTable} has no references from ${relationship.sourceTable}`,
              sourceTable: relationship.targetTable,
              sourceRecord: targetRecord.id,
              suggestion: `Consider removing the orphaned record or create references to it`,
              detected_at: new Date().toISOString(),
              resolved: false
            });
          }
        });
      }
    } catch (error) {
      console.error('Error finding orphaned records:', error);
    }
    
    return issues;
  }

  private async findCircularDependencies(relationships: DataRelationship[]): Promise<DependencyIssue[]> {
    const issues: DependencyIssue[] = [];
    
    // Build dependency graph
    const graph: Record<string, string[]> = {};
    relationships.forEach(rel => {
      if (!graph[rel.sourceTable]) graph[rel.sourceTable] = [];
      graph[rel.sourceTable].push(rel.targetTable);
    });
    
    // Check for cycles using DFS
    const visited = new Set<string>();
    const recursionStack = new Set<string>();
    
    const hasCycle = (node: string): boolean => {
      if (recursionStack.has(node)) return true;
      if (visited.has(node)) return false;
      
      visited.add(node);
      recursionStack.add(node);
      
      const neighbors = graph[node] || [];
      for (const neighbor of neighbors) {
        if (hasCycle(neighbor)) return true;
      }
      
      recursionStack.delete(node);
      return false;
    };
    
    Object.keys(graph).forEach(table => {
      if (hasCycle(table)) {
        issues.push({
          id: crypto.randomUUID(),
          type: 'circular_dependency',
          severity: 'critical',
          title: 'Circular Dependency Detected',
          description: `Circular dependency detected involving table: ${table}`,
          sourceTable: table,
          suggestion: 'Review relationship definitions to eliminate circular references',
          detected_at: new Date().toISOString(),
          resolved: false
        });
      }
    });
    
    return issues;
  }

  async getRelatedRecords(tableName: string, recordId: string): Promise<any[]> {
    try {
      const relationships = await this.getRelationships();
      const relatedData = [];

      for (const relationship of relationships) {
        if (relationship.sourceTable === tableName) {
          // This table references another table
          const targetData = await dataService.getReferenceData(relationship.targetTable);
          const sourceRecord = await this.getRecordById(tableName, recordId);
          const foreignKey = sourceRecord?.[relationship.sourceField];
          
          if (foreignKey) {
            const relatedRecord = targetData.find(r => r[relationship.targetField] === foreignKey);
            if (relatedRecord) {
              relatedData.push({
                relationship: relationship.name,
                table: relationship.targetTable,
                record: relatedRecord,
                type: 'references'
              });
            }
          }
        } else if (relationship.targetTable === tableName) {
          // Other tables reference this table
          const sourceData = await dataService.getReferenceData(relationship.sourceTable);
          const referencingRecords = sourceData.filter(r => r[relationship.sourceField] === recordId);
          
          referencingRecords.forEach(record => {
            relatedData.push({
              relationship: relationship.name,
              table: relationship.sourceTable,
              record,
              type: 'referenced_by'
            });
          });
        }
      }

      return relatedData;
    } catch (error) {
      console.error('Error getting related records:', error);
      return [];
    }
  }

  private async getRecordById(tableName: string, recordId: string): Promise<any> {
    try {
      const data = await dataService.getReferenceData(tableName);
      return data.find(record => record.id === recordId);
    } catch (error) {
      console.error('Error getting record by ID:', error);
      return null;
    }
  }

  async resolveDependencyIssue(issueId: string, resolution: 'fix_data' | 'ignore' | 'delete_relationship'): Promise<boolean> {
    try {
      // In a real implementation, this would apply the resolution
      // For now, we'll just mark it as resolved
      console.log(`Resolving issue ${issueId} with resolution: ${resolution}`);
      return true;
    } catch (error) {
      console.error('Error resolving dependency issue:', error);
      return false;
    }
  }

  async getTableDependencies(tableName: string): Promise<{ dependencies: string[], dependents: string[] }> {
    try {
      const relationships = await this.getRelationships();
      
      const dependencies = relationships
        .filter(rel => rel.sourceTable === tableName)
        .map(rel => rel.targetTable);
      
      const dependents = relationships
        .filter(rel => rel.targetTable === tableName)
        .map(rel => rel.sourceTable);
      
      return {
        dependencies: [...new Set(dependencies)],
        dependents: [...new Set(dependents)]
      };
    } catch (error) {
      console.error('Error getting table dependencies:', error);
      return { dependencies: [], dependents: [] };
    }
  }
}

export const relationshipService = new RelationshipService();
