import { dataService } from '../api';
import { toast } from '@/hooks/use-toast';

export interface CSVUploadResult {
  success: boolean;
  tableName: string;
  rowsInserted: number;
  errors: string[];
  timestamp: string;
}

export interface ReferenceTableInfo {
  tableName: string;
  displayName: string;
  lastUpdated?: string;
  rowCount: number;
  description: string;
}

export interface CSVMapping {
  csvColumn: string;
  targetField: string;
  dataType: 'text' | 'number' | 'date' | 'boolean';
  required: boolean;
  transform?: (value: string) => any;
}

class CSVUploadService {
  private predefinedTables: ReferenceTableInfo[] = [
    {
      tableName: 'product_categories',
      displayName: 'Product Categories',
      rowCount: 0,
      description: 'Product category definitions and hierarchies'
    },
    {
      tableName: 'products',
      displayName: 'Products',
      rowCount: 0,
      description: 'Product master data and specifications'
    },
    {
      tableName: 'plants',
      displayName: 'Plants',
      rowCount: 0,
      description: 'Plant locations and facility information'
    },
    {
      tableName: 'sampling_places',
      displayName: 'Sampling Places',
      rowCount: 0,
      description: 'Sample collection points and locations'
    },
    {
      tableName: 'test_standards',
      displayName: 'Test Standards',
      rowCount: 0,
      description: 'Testing standards and specifications'
    },
    {
      tableName: 'clients',
      displayName: 'Clients',
      rowCount: 0,
      description: 'Client and customer information'
    }
  ];

  async parseCSV(content: string): Promise<any[]> {
    const lines = content.split('\n').filter(line => line.trim());
    if (lines.length === 0) return [];

    const headers = this.parseCSVLine(lines[0]);
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = this.parseCSVLine(lines[i]);
      if (values.length === headers.length) {
        const row: any = {};
        headers.forEach((header, index) => {
          row[header.trim()] = values[index]?.trim() || '';
        });
        data.push(row);
      }
    }

    return data;
  }

  private parseCSVLine(line: string): string[] {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current);
    return result;
  }

  async uploadCSV(
    file: File,
    tableName: string,
    mappings: CSVMapping[],
    replaceExisting: boolean = false
  ): Promise<CSVUploadResult> {
    try {
      const content = await file.text();
      const csvData = await this.parseCSV(content);

      if (csvData.length === 0) {
        return {
          success: false,
          tableName,
          rowsInserted: 0,
          errors: ['CSV file is empty or invalid'],
          timestamp: new Date().toISOString()
        };
      }

      // Transform data according to mappings
      const transformedData = csvData.map((row, index) => {
        const transformed: any = {
          id: crypto.randomUUID(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          active: true
        };

        const rowErrors: string[] = [];

        mappings.forEach(mapping => {
          if (mapping.targetField === 'none') return;

          const value = row[mapping.csvColumn];
          
          if (mapping.required && (!value || value.trim() === '')) {
            rowErrors.push(`Row ${index + 1}: Required field '${mapping.targetField}' is empty`);
            return;
          }

          if (value && value.trim() !== '') {
            try {
              transformed[mapping.targetField] = mapping.transform 
                ? mapping.transform(value)
                : this.transformValue(value, mapping.dataType);
            } catch (error) {
              rowErrors.push(`Row ${index + 1}: Invalid ${mapping.dataType} value for '${mapping.targetField}': ${value}`);
            }
          }
        });

        if (rowErrors.length > 0) {
          throw new Error(rowErrors.join('; '));
        }

        return transformed;
      });

      // Upload to database
      const result = await dataService.uploadReferenceDataset(tableName, transformedData, replaceExisting);

      // Create audit log
      await dataService.createAuditLog({
        action: 'UPLOAD_CSV',
        table_name: tableName,
        record_id: null,
        user_name: 'Current User',
        changes: [`Uploaded ${result.rowsInserted} records from CSV file: ${file.name}`],
        timestamp: new Date().toISOString(),
        ip_address: 'local',
        user_agent: navigator.userAgent
      });

      return {
        success: result.success,
        tableName,
        rowsInserted: result.rowsInserted,
        errors: result.error ? [result.error] : [],
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error('CSV upload error:', error);
      return {
        success: false,
        tableName,
        rowsInserted: 0,
        errors: [error instanceof Error ? error.message : 'Unknown upload error'],
        timestamp: new Date().toISOString()
      };
    }
  }

  private transformValue(value: string, dataType: string): any {
    switch (dataType) {
      case 'number':
        const num = parseFloat(value);
        if (isNaN(num)) throw new Error(`Invalid number: ${value}`);
        return num;
      case 'date':
        const date = new Date(value);
        if (isNaN(date.getTime())) throw new Error(`Invalid date: ${value}`);
        return date.toISOString();
      case 'boolean':
        return ['true', '1', 'yes', 'y'].includes(value.toLowerCase());
      default:
        return value;
    }
  }

  async getTableInfo(): Promise<ReferenceTableInfo[]> {
    try {
      const tablesWithCounts = await Promise.all(
        this.predefinedTables.map(async (table) => {
          try {
            const data = await dataService.getReferenceData(table.tableName);
            return {
              ...table,
              rowCount: data.length,
              lastUpdated: data.length > 0 ? new Date().toISOString() : undefined
            };
          } catch (error) {
            return { ...table, rowCount: 0 };
          }
        })
      );

      return tablesWithCounts;
    } catch (error) {
      console.error('Error getting table info:', error);
      return this.predefinedTables;
    }
  }

  async getUploadHistory(limit: number = 50): Promise<any[]> {
    try {
      const auditLogs = await dataService.getAuditLogs({
        action: 'UPLOAD_CSV',
        limit
      });
      return auditLogs;
    } catch (error) {
      console.error('Error getting upload history:', error);
      return [];
    }
  }

  getFieldSuggestions(tableName: string): any[] {
    const commonFields = [
      { key: 'name', label: 'Name', dataType: 'text', required: true },
      { key: 'description', label: 'Description', dataType: 'text', required: false },
      { key: 'code', label: 'Code', dataType: 'text', required: false },
      { key: 'active', label: 'Active', dataType: 'boolean', required: false }
    ];

    const tableSpecificFields: Record<string, any[]> = {
      products: [
        { key: 'product_code', label: 'Product Code', dataType: 'text', required: true },
        { key: 'category', label: 'Category', dataType: 'text', required: false },
        { key: 'unit', label: 'Unit', dataType: 'text', required: false }
      ],
      plants: [
        { key: 'plant_code', label: 'Plant Code', dataType: 'text', required: true },
        { key: 'location', label: 'Location', dataType: 'text', required: false },
        { key: 'manager', label: 'Manager', dataType: 'text', required: false }
      ],
      clients: [
        { key: 'client_code', label: 'Client Code', dataType: 'text', required: true },
        { key: 'contact_email', label: 'Contact Email', dataType: 'text', required: false },
        { key: 'phone', label: 'Phone', dataType: 'text', required: false }
      ]
    };

    return [...commonFields, ...(tableSpecificFields[tableName] || [])];
  }
}

export const csvUploadService = new CSVUploadService();