// Modern reference data service with local-first sync capabilities
import { localSyncService } from '../sync/localSyncService';
import { backgroundSyncService } from '../sync/backgroundSyncService';
import { DatasetDefinition, FieldDefinition, SyncStatus } from '../sync/syncTypes';
import { PermissionWrapper } from '@/components/rbac/PermissionWrapper';

export interface ReferenceDataItem {
  id: string;
  [key: string]: any;
  created_at: string;
  updated_at: string;
  created_by?: string;
  updated_by?: string;
}

export interface CSVImportResult {
  success: boolean;
  imported: number;
  errors: string[];
  warnings?: string[];
}

export interface ValidationError {
  field: string;
  message: string;
  value: any;
}

export class ModernReferenceDataService {
  private isElectron: boolean;

  constructor() {
    this.isElectron = typeof window !== 'undefined' && (window as any).electronAPI;
  }

  // Dataset definition management
  async getDatasetDefinitions(): Promise<DatasetDefinition[]> {
    return localSyncService.getDatasetDefinitions();
  }

  async createDatasetDefinition(
    definition: Omit<DatasetDefinition, 'id' | 'created_at' | 'updated_at' | 'version'>
  ): Promise<DatasetDefinition> {
    const newDefinition: DatasetDefinition = {
      ...definition,
      id: `dataset_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      version: 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Save definition locally
    await localSyncService.saveDatasetDefinition(newDefinition);
    
    // Create corresponding table
    await this.createDataTable(newDefinition.table_name, newDefinition.fields);
    
    // Queue for sync
    await localSyncService.queueOperation('dataset_definitions', 'INSERT', newDefinition);
    
    return newDefinition;
  }

  async updateDatasetDefinition(
    id: string,
    updates: Partial<DatasetDefinition>
  ): Promise<DatasetDefinition> {
    const definitions = await this.getDatasetDefinitions();
    const existing = definitions.find(d => d.id === id);
    
    if (!existing) {
      throw new Error(`Dataset definition not found: ${id}`);
    }

    const updated: DatasetDefinition = {
      ...existing,
      ...updates,
      version: existing.version + 1,
      updated_at: new Date().toISOString()
    };

    // Save updated definition
    await localSyncService.saveDatasetDefinition(updated);
    
    // Handle schema changes if fields were modified
    if (updates.fields) {
      await this.alterDataTable(existing.table_name, existing.fields, updates.fields);
    }
    
    // Queue for sync
    await localSyncService.queueOperation('dataset_definitions', 'UPDATE', updated);
    
    return updated;
  }

  async deleteDatasetDefinition(id: string): Promise<void> {
    const definitions = await this.getDatasetDefinitions();
    const existing = definitions.find(d => d.id === id);
    
    if (!existing) {
      throw new Error(`Dataset definition not found: ${id}`);
    }

    // Check if table has data before deletion
    const hasData = await this.hasTableData(existing.table_name);
    if (hasData) {
      throw new Error('Cannot delete dataset with existing data. Please clear all data first.');
    }

    // Mark as inactive
    const updated = { ...existing, is_active: false, updated_at: new Date().toISOString() };
    await localSyncService.saveDatasetDefinition(updated);
    
    // Drop table
    await this.dropDataTable(existing.table_name);
    
    // Queue for sync
    await localSyncService.queueOperation('dataset_definitions', 'DELETE', { id });
  }

  // Data table management
  private async createDataTable(tableName: string, fields: FieldDefinition[]): Promise<void> {
    if (!this.isElectron) return; // Browser fallback doesn't need table creation

    const columnDefinitions = fields.map(field => {
      let columnDef = `${field.name} `;
      
      switch (field.type) {
        case 'number':
          columnDef += 'REAL';
          break;
        case 'date':
          columnDef += 'DATETIME';
          break;
        case 'boolean':
          columnDef += 'INTEGER';
          break;
        default:
          columnDef += 'TEXT';
      }
      
      if (field.required) {
        columnDef += ' NOT NULL';
      }
      
      if (field.default_value !== undefined) {
        columnDef += ` DEFAULT ${typeof field.default_value === 'string' ? `'${field.default_value}'` : field.default_value}`;
      }
      
      return columnDef;
    }).join(', ');

    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id TEXT PRIMARY KEY,
        ${columnDefinitions},
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT,
        updated_by TEXT
      )
    `;

    await (window as any).electronAPI.dbRun(createTableSQL);
  }

  private async alterDataTable(
    tableName: string,
    oldFields: FieldDefinition[],
    newFields: FieldDefinition[]
  ): Promise<void> {
    if (!this.isElectron) return;

    // For SQLite, we need to recreate the table for complex schema changes
    // This is a simplified approach - in production, consider more sophisticated migration
    
    const tempTableName = `${tableName}_temp_${Date.now()}`;
    
    try {
      // Create new table with updated schema
      await this.createDataTable(tempTableName, newFields);
      
      // Copy data from old table to new table
      const commonFields = newFields
        .filter(newField => oldFields.some(oldField => oldField.name === newField.name))
        .map(field => field.name);
      
      if (commonFields.length > 0) {
        const fieldsStr = ['id', ...commonFields, 'created_at', 'updated_at', 'created_by', 'updated_by'].join(', ');
        await (window as any).electronAPI.dbRun(
          `INSERT INTO ${tempTableName} (${fieldsStr}) SELECT ${fieldsStr} FROM ${tableName}`
        );
      }
      
      // Drop old table and rename new table
      await (window as any).electronAPI.dbRun(`DROP TABLE ${tableName}`);
      await (window as any).electronAPI.dbRun(`ALTER TABLE ${tempTableName} RENAME TO ${tableName}`);
      
    } catch (error) {
      // Cleanup on error
      await (window as any).electronAPI.dbRun(`DROP TABLE IF EXISTS ${tempTableName}`);
      throw error;
    }
  }

  private async dropDataTable(tableName: string): Promise<void> {
    if (!this.isElectron) {
      // Browser fallback
      localStorage.removeItem(`reference_data_${tableName}`);
      return;
    }

    await (window as any).electronAPI.dbRun(`DROP TABLE IF EXISTS ${tableName}`);
  }

  private async hasTableData(tableName: string): Promise<boolean> {
    if (!this.isElectron) {
      const data = localStorage.getItem(`reference_data_${tableName}`);
      return data ? JSON.parse(data).length > 0 : false;
    }

    const result = await (window as any).electronAPI.dbQuery(
      `SELECT COUNT(*) as count FROM ${tableName}`
    );
    return result[0]?.count > 0;
  }

  // CRUD operations for reference data
  async getTableData(tableName: string, filters?: Record<string, any>): Promise<ReferenceDataItem[]> {
    if (!this.isElectron) {
      // Browser fallback
      const data = JSON.parse(localStorage.getItem(`reference_data_${tableName}`) || '[]');
      return this.applyFilters(data, filters);
    }

    let sql = `SELECT * FROM ${tableName}`;
    const params: any[] = [];
    
    if (filters && Object.keys(filters).length > 0) {
      const conditions = Object.entries(filters)
        .filter(([_, value]) => value !== undefined && value !== null && value !== '')
        .map(([key, _]) => `${key} = ?`);
      
      if (conditions.length > 0) {
        sql += ` WHERE ${conditions.join(' AND ')}`;
        params.push(...Object.values(filters).filter(v => v !== undefined && v !== null && v !== ''));
      }
    }
    
    sql += ' ORDER BY created_at DESC';
    
    return (window as any).electronAPI.dbQuery(sql, params);
  }

  async createTableItem(tableName: string, data: any): Promise<ReferenceDataItem> {
    const currentUser = this.getCurrentUser();
    const now = new Date().toISOString();
    
    const item: ReferenceDataItem = {
      id: `${tableName}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...data,
      created_at: now,
      updated_at: now,
      created_by: currentUser,
      updated_by: currentUser
    };

    // Validate data
    await this.validateItem(tableName, item);

    if (!this.isElectron) {
      // Browser fallback
      const existing = JSON.parse(localStorage.getItem(`reference_data_${tableName}`) || '[]');
      existing.push(item);
      localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(existing));
    } else {
      // Electron implementation
      const columns = Object.keys(item);
      const placeholders = columns.map(() => '?').join(', ');
      const values = Object.values(item);

      await (window as any).electronAPI.dbRun(
        `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders})`,
        values
      );
    }

    // Queue for sync
    await localSyncService.queueOperation(tableName, 'INSERT', item);

    return item;
  }

  async updateTableItem(tableName: string, id: string, data: any): Promise<ReferenceDataItem> {
    const currentUser = this.getCurrentUser();
    const now = new Date().toISOString();
    
    const updates = {
      ...data,
      updated_at: now,
      updated_by: currentUser
    };

    // Get existing item
    const existing = await this.getTableItem(tableName, id);
    if (!existing) {
      throw new Error(`Item not found: ${id}`);
    }

    const updated = { ...existing, ...updates };
    
    // Validate data
    await this.validateItem(tableName, updated);

    if (!this.isElectron) {
      // Browser fallback
      const allItems = JSON.parse(localStorage.getItem(`reference_data_${tableName}`) || '[]');
      const index = allItems.findIndex((item: any) => item.id === id);
      if (index >= 0) {
        allItems[index] = updated;
        localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(allItems));
      }
    } else {
      // Electron implementation
      const updateFields = Object.keys(updates).filter(key => key !== 'id');
      const setClause = updateFields.map(field => `${field} = ?`).join(', ');
      const values = [...updateFields.map(field => updates[field]), id];

      await (window as any).electronAPI.dbRun(
        `UPDATE ${tableName} SET ${setClause} WHERE id = ?`,
        values
      );
    }

    // Queue for sync
    await localSyncService.queueOperation(tableName, 'UPDATE', updated, id);

    return updated;
  }

  async deleteTableItem(tableName: string, id: string): Promise<void> {
    if (!this.isElectron) {
      // Browser fallback
      const allItems = JSON.parse(localStorage.getItem(`reference_data_${tableName}`) || '[]');
      const filtered = allItems.filter((item: any) => item.id !== id);
      localStorage.setItem(`reference_data_${tableName}`, JSON.stringify(filtered));
    } else {
      await (window as any).electronAPI.dbRun(
        `DELETE FROM ${tableName} WHERE id = ?`,
        [id]
      );
    }

    // Queue for sync
    await localSyncService.queueOperation(tableName, 'DELETE', { id });
  }

  async getTableItem(tableName: string, id: string): Promise<ReferenceDataItem | null> {
    if (!this.isElectron) {
      // Browser fallback
      const allItems = JSON.parse(localStorage.getItem(`reference_data_${tableName}`) || '[]');
      return allItems.find((item: any) => item.id === id) || null;
    }

    const result = await (window as any).electronAPI.dbQuery(
      `SELECT * FROM ${tableName} WHERE id = ?`,
      [id]
    );
    return result[0] || null;
  }

  // CSV Import/Export
  async importCSV(
    tableName: string,
    csvData: string,
    fieldMappings: Record<string, string>,
    replaceExisting: boolean = false
  ): Promise<CSVImportResult> {
    const lines = csvData.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    
    if (replaceExisting) {
      await this.clearTableData(tableName);
    }

    const errors: string[] = [];
    const warnings: string[] = [];
    let imported = 0;

    for (let i = 1; i < lines.length; i++) {
      try {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        const rowData: any = {};

        // Map CSV columns to table fields
        Object.entries(fieldMappings).forEach(([csvColumn, tableField]) => {
          const columnIndex = headers.indexOf(csvColumn);
          if (columnIndex >= 0 && columnIndex < values.length) {
            rowData[tableField] = values[columnIndex];
          }
        });

        // Validate and create item
        await this.createTableItem(tableName, rowData);
        imported++;
        
      } catch (error) {
        errors.push(`Row ${i + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    return {
      success: errors.length === 0,
      imported,
      errors,
      warnings
    };
  }

  async exportCSV(tableName: string, filters?: Record<string, any>): Promise<string> {
    const data = await this.getTableData(tableName, filters);
    
    if (data.length === 0) {
      return '';
    }

    const headers = Object.keys(data[0]).filter(key => key !== 'created_by' && key !== 'updated_by');
    const csv = [
      headers.join(','),
      ...data.map(item => 
        headers.map(header => `"${item[header] || ''}"`).join(',')
      )
    ].join('\n');

    return csv;
  }

  // Validation
  private async validateItem(tableName: string, item: any): Promise<void> {
    const definitions = await this.getDatasetDefinitions();
    const definition = definitions.find(d => d.table_name === tableName);
    
    if (!definition) {
      return; // No validation rules defined
    }

    const errors: ValidationError[] = [];

    for (const field of definition.fields) {
      const value = item[field.name];
      
      // Required field validation
      if (field.required && (value === undefined || value === null || value === '')) {
        errors.push({
          field: field.name,
          message: `${field.name} is required`,
          value
        });
        continue;
      }

      // Type validation
      if (value !== undefined && value !== null && value !== '') {
        switch (field.type) {
          case 'number':
            if (isNaN(Number(value))) {
              errors.push({
                field: field.name,
                message: `${field.name} must be a valid number`,
                value
              });
            }
            break;
          case 'date':
            if (isNaN(Date.parse(value))) {
              errors.push({
                field: field.name,
                message: `${field.name} must be a valid date`,
                value
              });
            }
            break;
          case 'boolean':
            if (typeof value !== 'boolean' && value !== '0' && value !== '1' && value !== 'true' && value !== 'false') {
              errors.push({
                field: field.name,
                message: `${field.name} must be a boolean value`,
                value
              });
            }
            break;
        }
      }

      // Custom validation rules
      if (field.validation_rules) {
        for (const rule of field.validation_rules) {
          switch (rule.type) {
            case 'min':
              if (field.type === 'number' && Number(value) < rule.value) {
                errors.push({
                  field: field.name,
                  message: rule.message || `${field.name} must be at least ${rule.value}`,
                  value
                });
              }
              break;
            case 'max':
              if (field.type === 'number' && Number(value) > rule.value) {
                errors.push({
                  field: field.name,
                  message: rule.message || `${field.name} must be at most ${rule.value}`,
                  value
                });
              }
              break;
            case 'regex':
              if (typeof value === 'string' && !new RegExp(rule.value).test(value)) {
                errors.push({
                  field: field.name,
                  message: rule.message || `${field.name} format is invalid`,
                  value
                });
              }
              break;
          }
        }
      }
    }

    if (errors.length > 0) {
      const errorMessages = errors.map(e => e.message).join(', ');
      throw new Error(`Validation failed: ${errorMessages}`);
    }
  }

  // Utility methods
  private applyFilters(data: any[], filters?: Record<string, any>): any[] {
    if (!filters || Object.keys(filters).length === 0) {
      return data;
    }

    return data.filter(item => {
      return Object.entries(filters).every(([key, value]) => {
        if (value === undefined || value === null || value === '') {
          return true;
        }
        return item[key] === value;
      });
    });
  }

  private getCurrentUser(): string {
    return localStorage.getItem('current_user_id') || 'anonymous';
  }

  private async clearTableData(tableName: string): Promise<void> {
    if (!this.isElectron) {
      localStorage.removeItem(`reference_data_${tableName}`);
      return;
    }

    await (window as any).electronAPI.dbRun(`DELETE FROM ${tableName}`);
  }

  // Sync-related methods
  async getSyncStatus(): Promise<SyncStatus> {
    return backgroundSyncService.getSyncStatus();
  }

  async forceSyncNow(): Promise<void> {
    return backgroundSyncService.forceSyncNow();
  }

  async getConflicts() {
    return backgroundSyncService.getConflicts();
  }

  async resolveConflict(conflictId: string, resolution: 'local' | 'remote' | 'merge', mergedData?: any) {
    return backgroundSyncService.resolveConflict(conflictId, resolution, mergedData);
  }
}

export const modernReferenceDataService = new ModernReferenceDataService();