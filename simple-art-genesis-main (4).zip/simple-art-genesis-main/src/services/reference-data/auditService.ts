import { dataService } from '../api';

export interface AuditLogEntry {
  id: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'UPLOAD_CSV' | 'BULK_UPDATE' | 'BULK_DELETE';
  table_name: string;
  record_id: string | null;
  user_name: string;
  changes: string[];
  timestamp: string;
  ip_address: string;
  user_agent: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface AuditFilters {
  search?: string;
  action?: string;
  tableName?: string;
  userId?: string;
  severity?: string;
  startDate?: string;
  endDate?: string;
  limit?: number;
}

export interface AuditStats {
  totalLogs: number;
  actionCounts: Record<string, number>;
  severityCounts: Record<string, number>;
  recentActivity: number;
  topUsers: Array<{ user: string; count: number }>;
  topTables: Array<{ table: string; count: number }>;
}

class ReferenceDataAuditService {
  async logAction(
    action: AuditLogEntry['action'],
    tableName: string,
    recordId: string | null,
    changes: string[],
    severity: AuditLogEntry['severity'] = 'low'
  ): Promise<void> {
    try {
      const entry: Omit<AuditLogEntry, 'id'> = {
        action,
        table_name: tableName,
        record_id: recordId,
        user_name: await this.getCurrentUserName(),
        changes,
        timestamp: new Date().toISOString(),
        ip_address: await this.getClientIP(),
        user_agent: navigator.userAgent,
        severity
      };

      await dataService.createAuditLog(entry);
    } catch (error) {
      console.error('Failed to log audit entry:', error);
    }
  }

  async getAuditLogs(filters: AuditFilters = {}): Promise<AuditLogEntry[]> {
    try {
      const logs = await dataService.getAuditLogs(filters);
      return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      return [];
    }
  }

  async getAuditStats(): Promise<AuditStats> {
    try {
      const logs = await this.getAuditLogs({ limit: 1000 });
      
      const actionCounts: Record<string, number> = {};
      const severityCounts: Record<string, number> = {};
      const userCounts: Record<string, number> = {};
      const tableCounts: Record<string, number> = {};

      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      let recentActivity = 0;

      logs.forEach(log => {
        // Count actions
        actionCounts[log.action] = (actionCounts[log.action] || 0) + 1;
        
        // Count severity
        severityCounts[log.severity] = (severityCounts[log.severity] || 0) + 1;
        
        // Count users
        userCounts[log.user_name] = (userCounts[log.user_name] || 0) + 1;
        
        // Count tables
        tableCounts[log.table_name] = (tableCounts[log.table_name] || 0) + 1;
        
        // Count recent activity
        if (new Date(log.timestamp) > oneDayAgo) {
          recentActivity++;
        }
      });

      const topUsers = Object.entries(userCounts)
        .map(([user, count]) => ({ user, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      const topTables = Object.entries(tableCounts)
        .map(([table, count]) => ({ table, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      return {
        totalLogs: logs.length,
        actionCounts,
        severityCounts,
        recentActivity,
        topUsers,
        topTables
      };
    } catch (error) {
      console.error('Error calculating audit stats:', error);
      return {
        totalLogs: 0,
        actionCounts: {},
        severityCounts: {},
        recentActivity: 0,
        topUsers: [],
        topTables: []
      };
    }
  }

  async exportAuditLogs(format: 'csv' | 'json', filters?: AuditFilters): Promise<string> {
    const logs = await this.getAuditLogs(filters);

    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    }

    // CSV format
    const headers = ['Timestamp', 'Action', 'Table', 'Record ID', 'User', 'Changes', 'Severity', 'IP Address'];
    const csvRows = [headers.join(',')];

    logs.forEach(log => {
      const row = [
        log.timestamp,
        log.action,
        log.table_name,
        log.record_id || '',
        log.user_name,
        `"${log.changes.join('; ')}"`,
        log.severity,
        log.ip_address
      ];
      csvRows.push(row.join(','));
    });

    return csvRows.join('\n');
  }

  private async getCurrentUserName(): Promise<string> {
    try {
      const user = await dataService.getCurrentUser();
      return user.data?.name || 'Unknown User';
    } catch (error) {
      return 'System';
    }
  }

  private async getClientIP(): Promise<string> {
    // In a local environment, return local identifier
    return 'localhost';
  }

  // Convenience methods for common audit operations
  async logCreate(tableName: string, recordId: string, data: any): Promise<void> {
    const changes = [`Created new record with data: ${JSON.stringify(data)}`];
    await this.logAction('CREATE', tableName, recordId, changes, 'low');
  }

  async logUpdate(tableName: string, recordId: string, oldData: any, newData: any): Promise<void> {
    const changes: string[] = [];
    Object.keys(newData).forEach(key => {
      if (oldData[key] !== newData[key]) {
        changes.push(`Changed ${key} from "${oldData[key]}" to "${newData[key]}"`);
      }
    });
    await this.logAction('UPDATE', tableName, recordId, changes, 'low');
  }

  async logDelete(tableName: string, recordId: string, data: any): Promise<void> {
    const changes = [`Deleted record: ${JSON.stringify(data)}`];
    await this.logAction('DELETE', tableName, recordId, changes, 'medium');
  }

  async logBulkOperation(
    action: 'BULK_UPDATE' | 'BULK_DELETE',
    tableName: string,
    recordCount: number,
    details: string
  ): Promise<void> {
    const changes = [`${action.replace('BULK_', '')} ${recordCount} records: ${details}`];
    const severity = recordCount > 100 ? 'high' : recordCount > 10 ? 'medium' : 'low';
    await this.logAction(action, tableName, null, changes, severity);
  }
}

export const referenceDataAuditService = new ReferenceDataAuditService();