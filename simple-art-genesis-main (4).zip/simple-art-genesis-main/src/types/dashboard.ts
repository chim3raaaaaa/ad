export interface DashboardWidget {
  id: string;
  type: string;
  title: string;
  description?: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  enabled: boolean;
  data?: any;
}

export interface DashboardLayout {
  id: string;
  user_id: string;
  name: string;
  widgets: DashboardWidget[];
  locked: boolean;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface DashboardState {
  currentLayout: DashboardLayout | null;
  availableWidgets: DashboardWidget[];
  isLocked: boolean;
  isAdmin: boolean;
  loading: boolean;
  error: string | null;
}

export interface WidgetComponent {
  id: string;
  type: string;
  title: string;
  component: React.ComponentType<any>;
  defaultSize: { w: number; h: number; minW?: number; minH?: number };
  description?: string;
}