declare global {
  interface Window {
    electronAPI: any; // Use any to avoid conflicts
  }
}