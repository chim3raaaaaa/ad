// ============= Production-Ready Type Definitions =============

// Base types
export type UserRole = 'admin' | 'lab_manager' | 'lab_technician' | 'other';
export type TestPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TestStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';
export type ValidationSeverity = 'error' | 'warning' | 'info';
export type ChangeRequestStatus = 'pending' | 'approved' | 'rejected' | 'implemented';

// Field schema types
export interface FieldSchema {
  name: string;
  type: 'text' | 'number' | 'date' | 'boolean' | 'select' | 'textarea' | 'file';
  label: string;
  required: boolean;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    message?: string;
  };
  options?: Array<{ value: string; label: string }>;
  defaultValue?: string | number | boolean;
}

// Test result types
export interface TestResult {
  id: string;
  test_request_id: string;
  test_type: string;
  results: Record<string, number | string | boolean>;
  measurements: Record<string, number>;
  compliance_status: 'pass' | 'fail' | 'pending';
  performed_by: string;
  performed_at: string;
  equipment_used?: string[];
  environmental_conditions?: {
    temperature?: number;
    humidity?: number;
    pressure?: number;
  };
  notes?: string;
  attachments?: string[];
  verified_by?: string;
  verified_at?: string;
}

// Test Calendar Event type - matches existing service structure
export interface TestCalendarEvent {
  id: string;
  memo_id: string;
  product: string;
  test_type: string;
  due_date: string;
  status: 'completed' | 'overdue' | 'in_progress' | 'scheduled' | 'cancelled' | 'pending';
  location?: string;
  notes?: string;
  assigned_to?: string;
  priority?: 'low' | 'medium' | 'high' | 'normal' | 'critical';
  estimated_duration?: number;
  memo_reference?: string;
  plant_id?: string;
  plant_location?: string;
  production_date?: string;
  batch_number?: string;
  remaining_days?: number;
}

// Test Calendar Filters type
export interface TestCalendarFilters {
  dateRange?: {
    start: Date;
    end: Date;
  };
  status?: string;
  product?: string;
  location?: string;
  priority?: string;
  assignedTo?: string;
  testType?: string;
}

// Re-export enhanced types from API types
export * from '@/services/api/types';
import type { ModuleSchema, ModuleComponent } from '@/services/api/types';

// Module metadata
export interface ModuleMeta {
  name: string;
  slug: string;
  version: string;
  description: string;
  author: string;
  license?: string;
  menu: {
    section: string;
    position: number;
    label: string;
    route: string;
    icon?: string;
  };
  dependencies: string[];
  permissions: string[];
  schema: ModuleSchema;
  components: ModuleComponent[];
  configuration?: Record<string, unknown>;
}

// Enhanced Electron API types to match existing implementation
export interface EnhancedElectronAPI {
  dbQuery: (sql: string, params?: unknown[]) => Promise<{ 
    success: boolean; 
    data?: unknown; 
    error?: string; 
  }>;
  dbRun: (sql: string, params?: unknown[]) => Promise<{ 
    success: boolean; 
    data?: unknown; 
    error?: string; 
  }>;
  createBackup: () => Promise<{ 
    success: boolean; 
    data?: string; 
    error?: string; 
  }>;
  restoreBackup: (backupPath: string) => Promise<{ 
    success: boolean; 
    error?: string; 
  }>;
  exportData: (format: 'json' | 'sqlite') => Promise<{ 
    success: boolean; 
    data?: string; 
    error?: string; 
  }>;
  importData: () => Promise<{ 
    success: boolean; 
    error?: string; 
  }>;
  getAppPaths: () => Promise<{
    userData: string;
    dataDir: string;
    dbDir: string;
    backupsDir: string;
    schemasDir: string;
    modulesDir: string;
  }>;
  saveFile: (data: Buffer | string, filename: string) => Promise<{
    success: boolean;
    path?: string;
    error?: string;
  }>;
  sendEmail: (emailData: {
    config: {
      smtpHost: string;
      smtpPort: number;
      username: string;
      password: string;
      fromEmail: string;
      fromName: string;
      security: string;
    };
    message: {
      to: string[];
      cc?: string[];
      bcc?: string[];
      subject: string;
      html?: string;
      text?: string;
      attachments?: Array<{
        filename: string;
        content: string | Buffer;
        contentType?: string;
      }>;
    };
  }) => Promise<{
    success: boolean;
    messageId?: string;
    error?: string;
  }>;
}

// Developer tools types
export interface DeveloperTool {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType;
  color: string;
  component: React.ComponentType<{ onClose?: () => void }>;
  permissions?: string[];
}

// Form builder types
export interface FormFieldConfig {
  id: string;
  type: FieldSchema['type'];
  label: string;
  name: string;
  required: boolean;
  validation?: FieldSchema['validation'];
  options?: FieldSchema['options'];
  defaultValue?: FieldSchema['defaultValue'];
  metadata?: Record<string, unknown>;
}

export interface FormConfig {
  id: string;
  name: string;
  description?: string;
  fields: FormFieldConfig[];
  layout: {
    columns: number;
    sections?: Array<{
      title: string;
      fields: string[];
    }>;
  };
  validation?: {
    rules: Array<{
      field: string;
      type: string;
      config: Record<string, unknown>;
    }>;
  };
  actions: Array<{
    type: 'submit' | 'cancel' | 'save_draft';
    label: string;
    permissions?: string[];
  }>;
}

// Table builder types
export interface TableColumn {
  id: string;
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'boolean' | 'enum' | 'json';
  required: boolean;
  primaryKey?: boolean;
  foreignKey?: {
    table: string;
    column: string;
  };
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
  defaultValue?: unknown;
  indexed?: boolean;
}

export interface TableConfig {
  id: string;
  name: string;
  displayName: string;
  description?: string;
  columns: TableColumn[];
  relationships: Array<{
    type: '1:1' | '1:N' | 'N:N';
    target_table: string;
    foreign_key: string;
    display_field?: string;
  }>;
  permissions: {
    create: string[];
    read: string[];
    update: string[];
    delete: string[];
  };
  audit: boolean;
  versioning: boolean;
}

// Export template types
export interface ExportTemplate {
  id: string;
  name: string;
  description?: string;
  type: 'pdf' | 'excel' | 'csv' | 'json';
  template: {
    pageSize: 'A4' | 'A3' | 'Letter';
    orientation: 'portrait' | 'landscape';
    margins: {
      top: number;
      right: number;
      bottom: number;
      left: number;
    };
    elements: ExportElement[];
  };
  data_source: {
    table: string;
    fields: string[];
    filters?: Record<string, unknown>;
  };
  permissions: string[];
}

export interface ExportElement {
  id: string;
  type: 'text' | 'image' | 'table' | 'signature' | 'date' | 'header' | 'footer';
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  content: unknown;
  style: {
    fontSize?: number;
    fontWeight?: 'normal' | 'bold';
    color?: string;
    textAlign?: 'left' | 'center' | 'right';
    backgroundColor?: string;
    border?: string;
  };
}

// Generic utility types
export interface PaginatedData<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface SortConfig {
  field: string;
  direction: 'asc' | 'desc';
}

export interface FilterConfig {
  field: string;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'between' | 'in';
  value: unknown;
}

// Error handling types
export interface AppError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  timestamp: string;
}

export interface ValidationError extends AppError {
  field?: string;
  value?: unknown;
  rule?: string;
}

// Audit types
export interface AuditLog {
  id: string;
  table_name: string;
  record_id: string;
  action: 'create' | 'update' | 'delete' | 'view';
  old_data?: Record<string, unknown>;
  new_data?: Record<string, unknown>;
  changed_fields?: string[];
  user_id: string;
  user_name: string;
  timestamp: string;
  ip_address?: string;
  user_agent?: string;
  session_id?: string;
}

// Note: Global window.electronAPI is already declared in electronDataService.ts