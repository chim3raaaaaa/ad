// Developer Mode types and interfaces

export interface PlacementOption {
  id: string;
  label: string;
  description: string;
  route?: string;
}

export interface BuilderDefinition {
  id: string;
  name: string;
  description?: string;
  placement: string;
  module_id?: string;
  usage_type?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface FormDefinition extends BuilderDefinition {
  fields: FormField[];
  validation_rules?: ValidationRule[];
  conditional_logic?: ConditionalLogic[];
}

export interface TableDefinition extends BuilderDefinition {
  columns: TableColumn[];
  primary_key?: string;
  indexes?: string[];
  data_source: string;
  api_endpoint?: string;
  features: TableFeature[];
}

export interface ComponentDefinition extends BuilderDefinition {
  component_type: 'ui' | 'functional' | 'layout';
  template_code: string;
  props_schema?: any;
  style_config?: any;
  dependencies?: string[];
  category: string;
  is_reusable: boolean;
}

export interface WorkflowDefinition extends BuilderDefinition {
  trigger_config: TriggerConfig;
  steps: WorkflowStep[];
  status: 'active' | 'inactive' | 'draft';
  execution_count: number;
  last_execution?: string;
}

export interface ApiEndpointDefinition extends BuilderDefinition {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  headers?: Record<string, string>;
  query_params?: Record<string, any>;
  request_body_schema?: any;
  response_schema?: any;
  auth_required: boolean;
  rate_limit?: number;
  is_active: boolean;
}

export interface FormField {
  id: string;
  name: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'dropdown' | 'checkbox' | 'textarea' | 'email' | 'password';
  required: boolean;
  placeholder?: string;
  default_value?: any;
  options?: { label: string; value: string }[];
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    message?: string;
  };
}

export interface ValidationRule {
  field: string;
  rule: string;
  value: any;
  message: string;
}

export interface ConditionalLogic {
  condition: {
    field: string;
    operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than';
    value: any;
  };
  action: {
    type: 'show' | 'hide' | 'require' | 'disable';
    target: string;
  };
}

export interface TableColumn {
  name: string;
  type: 'TEXT' | 'INTEGER' | 'REAL' | 'BLOB' | 'BOOLEAN' | 'DATETIME';
  nullable: boolean;
  default_value?: any;
  unique?: boolean;
  auto_increment?: boolean;
}

export interface TableFeature {
  type: 'search' | 'filter' | 'sort' | 'pagination' | 'export' | 'import';
  enabled: boolean;
  config?: any;
}

export interface TriggerConfig {
  type: 'form_submit' | 'data_change' | 'schedule' | 'manual' | 'api_call';
  source?: string;
  conditions?: any[];
  schedule?: string; // cron expression for scheduled triggers
}

export interface WorkflowStep {
  id: string;
  type: 'query' | 'calculation' | 'notification' | 'api_call' | 'conditional' | 'delay';
  name: string;
  config: any;
  next_step?: string;
  error_handling?: {
    retry_count: number;
    on_error: 'stop' | 'continue' | 'fallback';
    fallback_step?: string;
  };
}

export interface PlacementSelector {
  selectedPlacement: string;
  moduleId?: string;
  customRoute?: string;
}

export interface SuccessMessage {
  title: string;
  description: string;
  saved_location: string;
  view_location?: string;
  action_button?: {
    label: string;
    route: string;
  };
}

export const PLACEMENT_OPTIONS: PlacementOption[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    description: 'Show on main dashboard',
    route: '/dashboard'
  },
  {
    id: 'test-modules',
    label: 'Test Modules',
    description: 'Display in test modules section',
    route: '/test-modules'
  },
  {
    id: 'advanced-data',
    label: 'Advanced Data',
    description: 'Add to advanced data features',
    route: '/advanced-data-features'
  },
  {
    id: 'analytics',
    label: 'Analytics',
    description: 'Include in analytics section',
    route: '/analytics'
  },
  {
    id: 'test-data-explorer',
    label: 'Test Data Explorer',
    description: 'Show in test data explorer',
    route: '/test-data-explorer'
  },
  {
    id: 'reports',
    label: 'Reports',
    description: 'Add to reports section',
    route: '/reports'
  },
  {
    id: 'custom-route',
    label: 'Custom Route',
    description: 'Create a new custom page/route'
  }
];