#!/bin/bash

# Setup script for Reference Data Sync Server

echo "Setting up Reference Data Sync Server..."

# Create server directory if it doesn't exist
mkdir -p server

# Navigate to server directory
cd server

# Install dependencies
echo "Installing dependencies..."
npm install

# Create TypeScript config
echo "Creating TypeScript configuration..."
cat > tsconfig.json << EOF
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true
  },
  "include": [
    "./**/*"
  ],
  "exclude": [
    "node_modules",
    "dist"
  ]
}
EOF

# Create environment file
echo "Creating environment configuration..."
cat > .env << EOF
PORT=3001
DB_PATH=./reference_data_server.db
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
MAX_FILE_SIZE=10mb
EOF

# Create start script
echo "Creating start scripts..."
cat > start-server.sh << EOF
#!/bin/bash
echo "Starting Reference Data Sync Server..."
npm run dev
EOF

chmod +x start-server.sh

# Build the server
echo "Building server..."
npm run build

echo "✅ Reference Data Sync Server setup complete!"
echo ""
echo "To start the server:"
echo "  cd server"
echo "  npm run dev"
echo ""
echo "Or use the start script:"
echo "  ./server/start-server.sh"
echo ""
echo "Server will be available at: http://localhost:3001"