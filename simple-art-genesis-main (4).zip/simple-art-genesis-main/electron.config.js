module.exports = {
  // App configuration
  appId: "app.lovable.a924a17a9f4b442dbba5fd0929aa20ff",
  productName: "Simple Art Genesis",
  
  // Build configuration
  directories: {
    output: "dist-electron"
  },
  
  // Files to include
  files: [
    "dist/**/*",
    "electron/**/*",
    "node_modules/**/*"
  ],
  
  // Platform-specific configurations
  mac: {
    target: "dmg",
    icon: "assets/icon.icns"
  },
  
  win: {
    target: "nsis",
    icon: "assets/icon.ico"
  },
  
  linux: {
    target: "AppImage",
    icon: "assets/icon.png"
  }
};