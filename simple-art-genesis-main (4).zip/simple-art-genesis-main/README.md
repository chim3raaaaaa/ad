# Lab Memo Automation System

A Python desktop application for Windows that automatically processes incoming lab memos from Outlook emails and manages them in a local file system with database tracking.

## Features

- **Automatic Folder Creation**: Creates necessary folders on first run with notifications
- **Outlook Integration**: Scans emails for memo attachments using keywords
- **PDF Download**: Automatically downloads PDF attachments from matching emails
- **File Monitoring**: Watches for manually added files in the incoming folder
- **Database Tracking**: SQLite database for memo metadata and processing logs
- **Desktop Notifications**: Real-time notifications for folder creation and memo imports
- **Error Handling**: Graceful error handling with logging and user notifications

## Requirements

- Windows 10/11
- Python 3.10 or higher
- Microsoft Outlook installed and configured
- Administrator privileges (for first-time folder creation in C:\\ drive)

## Installation

1. **Install Python**: Download Python 3.10+ from [python.org](https://python.org)

2. **Clone or download** this application to your preferred directory

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure Outlook** (if not already done):
   - Ensure Outlook is installed and configured with your email account
   - Run Outlook at least once to complete initial setup
   - The application will connect to your default Outlook profile

## Quick Start

### Easy Installation
1. Run the batch file: `run_memo_service.bat`
2. Or use the installer: `python install_service.py`

### Manual Start
```bash
python main.py
```

## Configuration

The application uses a `config.ini` file for configuration. On first run, a default configuration will be created. You can modify these settings:

### Folder Paths
- `base_folder`: Primary location for memo folders (default: C:\LabMemos)
- `fallback_folder`: Backup location if primary isn't writable (default: Documents\LabMemos)

### Email Scanning
- `scan_interval_minutes`: How often to check for new emails (default: 5 minutes)
- `keywords`: Comma-separated keywords to search for (default: "Memo,Test Request,Lab Request")
- `outlook_processed_folder`: Outlook folder name for processed emails

### Notifications
- `show_folder_creation`: Show notifications when folders are created
- `show_memo_import`: Show notifications when memos are imported
- `notification_duration`: How long notifications stay visible (seconds)

## Usage

### Automatic Email Processing

The application will:

1. **Scan Outlook** every 5 minutes (configurable) for unread emails
2. **Search** for emails containing keywords like "Memo", "Test Request", etc.
3. **Download** PDF attachments from matching emails to the incoming folder
4. **Mark emails as read** and move them to a "Processed Memos" folder
5. **Show notification** for each imported memo
6. **Log all activities** in the database and log file

### Manual File Addition

You can also manually add PDF files to the incoming folder:
- Copy PDF files directly to `C:\LabMemos\incoming` (or your configured path)
- The application will detect new files and add them to the database
- Notifications will be shown for manually added files

### Folder Structure

The application creates the following folder structure:

```
C:\LabMemos\          (or Documents\LabMemos\ if C:\ not writable)
├── incoming\         (New memo PDFs)
├── processed\        (Successfully processed files)
├── error\           (Files that caused errors)
├── memos.db         (SQLite database)
└── memo_processor.log (Application log file)
```

## Troubleshooting

### Common Issues

1. **"Cannot connect to Outlook"**
   - Ensure Outlook is running
   - Check that Outlook is properly configured with an email account
   - Try running the script as Administrator
   - Verify pywin32 is installed: `pip show pywin32`

2. **"Permission denied" for folder creation**
   - The application will automatically fallback to Documents folder
   - To use C:\LabMemos, run as Administrator on first launch

3. **No notifications appearing**
   - Check if notification permissions are enabled in Windows
   - Verify notification libraries are installed: `pip show plyer win10toast`

4. **Files not being detected**
   - Check that the watchdog library is installed: `pip show watchdog`
   - Verify the incoming folder path in config.ini
   - Check the application log file for errors

### Log Files

- **Application Log**: `memo_processor.log` in the application directory
- **Database**: `memos.db` in the LabMemos folder
- Check these files for detailed error information

## Database Schema

The SQLite database contains two main tables:

### `memos` table
- `id`: Unique identifier
- `filename`: PDF filename
- `received_date`: When the memo was imported
- `sender`: Email sender (if from email)
- `subject`: Email subject (if from email)
- `file_path`: Full path to the PDF file
- `status`: Processing status
- `created_at`: Database record creation time

### `processing_log` table
- `id`: Unique identifier
- `memo_id`: Reference to memo
- `action`: Type of action performed
- `details`: Additional details
- `timestamp`: When the action occurred

## Security Considerations

- The application only reads emails and downloads attachments
- No email content is stored permanently
- Database contains only metadata, not PDF content
- All operations are logged for audit purposes
- Files are stored locally on the user's machine

## Support

For issues or questions:
1. Check the log files for error details
2. Verify all requirements are installed
3. Ensure Outlook is properly configured
4. Check Windows notification settings

## License

This software is provided as-is for lab automation purposes. Modify as needed for your specific requirements.