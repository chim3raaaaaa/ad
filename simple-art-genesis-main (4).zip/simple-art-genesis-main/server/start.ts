// Server startup script for the Reference Data Sync Server
import { ReferenceDataSyncServer } from './referenceDataSyncServer';
import path from 'path';

const config = {
  port: parseInt(process.env.PORT || '3001'),
  dbPath: process.env.DB_PATH || path.join(process.cwd(), 'reference_data_server.db'),
  allowedOrigins: (process.env.ALLOWED_ORIGINS || 'http://localhost:3000,http://localhost:5173').split(','),
  maxFileSize: process.env.MAX_FILE_SIZE || '10mb'
};

console.log('Starting Reference Data Sync Server...');
console.log('Configuration:', config);

const server = new ReferenceDataSyncServer(config);
server.start();

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nReceived SIGINT. Graceful shutdown...');
  server.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\nReceived SIGTERM. Graceful shutdown...');
  server.stop();
  process.exit(0);
});