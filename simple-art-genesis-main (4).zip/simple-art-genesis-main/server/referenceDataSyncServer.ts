// Central HTTP server for reference data synchronization
// This server runs locally to coordinate data between devices

import express from 'express';
import cors from 'cors';
import { Database } from 'sqlite3';
import { promisify } from 'util';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';

interface ServerConfig {
  port: number;
  dbPath: string;
  allowedOrigins: string[];
  maxFileSize: string;
}

export class ReferenceDataSyncServer {
  private app: express.Application;
  private db: Database;
  private config: ServerConfig;
  private dbGet: (sql: string, params?: any[]) => Promise<any>;
  private dbAll: (sql: string, params?: any[]) => Promise<any[]>;
  private dbRun: (sql: string, params?: any[]) => Promise<any>;

  constructor(config: ServerConfig) {
    this.config = config;
    this.app = express();
    this.setupDatabase();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupDatabase(): void {
    this.db = new Database(this.config.dbPath);
    this.dbGet = promisify(this.db.get.bind(this.db));
    this.dbAll = promisify(this.db.all.bind(this.db));
    this.dbRun = promisify(this.db.run.bind(this.db));
    
    this.initializeTables();
  }

  private async initializeTables(): Promise<void> {
    const tables = [
      // Dataset definitions
      `CREATE TABLE IF NOT EXISTS dataset_definitions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        category TEXT NOT NULL,
        icon TEXT,
        table_name TEXT NOT NULL UNIQUE,
        fields TEXT NOT NULL,
        permissions TEXT,
        version INTEGER DEFAULT 1,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        sync_version INTEGER DEFAULT 1
      )`,
      
      // Sync operations log
      `CREATE TABLE IF NOT EXISTS sync_operations (
        id TEXT PRIMARY KEY,
        device_id TEXT NOT NULL,
        table_name TEXT NOT NULL,
        operation TEXT NOT NULL,
        data TEXT NOT NULL,
        version INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        processed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
      )`,
      
      // Conflict tracking
      `CREATE TABLE IF NOT EXISTS sync_conflicts (
        id TEXT PRIMARY KEY,
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        device_id_1 TEXT NOT NULL,
        device_id_2 TEXT NOT NULL,
        data_1 TEXT NOT NULL,
        data_2 TEXT NOT NULL,
        conflict_type TEXT NOT NULL,
        resolved INTEGER DEFAULT 0,
        resolution TEXT,
        created_at TEXT DEFAULT (datetime('now'))
      )`,
      
      // Device registry
      `CREATE TABLE IF NOT EXISTS devices (
        device_id TEXT PRIMARY KEY,
        device_name TEXT NOT NULL,
        user_id TEXT NOT NULL,
        last_sync TEXT,
        sync_version INTEGER DEFAULT 1,
        status TEXT DEFAULT 'active',
        created_at TEXT DEFAULT (datetime('now'))
      )`,
      
      // User permissions
      `CREATE TABLE IF NOT EXISTS user_permissions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        permission TEXT NOT NULL,
        granted_by TEXT NOT NULL,
        granted_at TEXT DEFAULT (datetime('now')),
        UNIQUE(user_id, permission)
      )`,
      
      // Audit log
      `CREATE TABLE IF NOT EXISTS audit_log (
        id TEXT PRIMARY KEY,
        table_name TEXT NOT NULL,
        record_id TEXT NOT NULL,
        operation TEXT NOT NULL,
        old_values TEXT,
        new_values TEXT,
        user_id TEXT NOT NULL,
        device_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        sync_version INTEGER DEFAULT 1
      )`
    ];

    for (const sql of tables) {
      await this.dbRun(sql);
    }
    
    // Create indexes for performance
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_sync_ops_device ON sync_operations(device_id, timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_sync_ops_table ON sync_operations(table_name, timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_conflicts_unresolved ON sync_conflicts(resolved, created_at)',
      'CREATE INDEX IF NOT EXISTS idx_audit_table_record ON audit_log(table_name, record_id)',
      'CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id, status)'
    ];

    for (const sql of indexes) {
      await this.dbRun(sql);
    }
  }

  private setupMiddleware(): void {
    this.app.use(cors({
      origin: this.config.allowedOrigins,
      credentials: true
    }));
    
    this.app.use(express.json({ limit: this.config.maxFileSize }));
    this.app.use(express.urlencoded({ extended: true, limit: this.config.maxFileSize }));
    
    // Request logging
    this.app.use((req, res, next) => {
      console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
      next();
    });
    
    // Error handling
    this.app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
      console.error('Server error:', err);
      res.status(500).json({
        success: false,
        error: 'Internal server error',
        sync_timestamp: new Date().toISOString()
      });
    });
  }

  private setupRoutes(): void {
    // Health check
    this.app.get('/api/health', (req, res) => {
      res.json({
        success: true,
        data: {
          status: 'ok',
          version: '1.0.0',
          timestamp: new Date().toISOString()
        },
        sync_timestamp: new Date().toISOString()
      });
    });

    // Dataset definitions
    this.app.get('/api/datasets', this.getDatasetDefinitions.bind(this));
    this.app.post('/api/datasets', this.createDatasetDefinition.bind(this));
    this.app.put('/api/datasets/:id', this.updateDatasetDefinition.bind(this));
    this.app.delete('/api/datasets/:id', this.deleteDatasetDefinition.bind(this));

    // Sync operations
    this.app.post('/api/sync/push', this.pushOperations.bind(this));
    this.app.post('/api/sync/pull', this.pullChanges.bind(this));

    // Data operations
    this.app.get('/api/data/:tableName', this.getTableData.bind(this));
    this.app.post('/api/data/:tableName', this.createRecord.bind(this));
    this.app.put('/api/data/:tableName/:id', this.updateRecord.bind(this));
    this.app.delete('/api/data/:tableName/:id', this.deleteRecord.bind(this));

    // Conflict resolution
    this.app.get('/api/conflicts', this.getConflicts.bind(this));
    this.app.post('/api/conflicts/:id/resolve', this.resolveConflict.bind(this));

    // CSV import/export
    this.app.post('/api/import/:tableName', this.importCSV.bind(this));
    this.app.get('/api/export/:tableName', this.exportCSV.bind(this));

    // Schema management
    this.app.get('/api/schema/:tableName?', this.getSchema.bind(this));
    this.app.post('/api/schema/create', this.createTable.bind(this));
    this.app.delete('/api/schema/:tableName', this.dropTable.bind(this));

    // Device management
    this.app.post('/api/devices/register', this.registerDevice.bind(this));
    this.app.get('/api/devices', this.getDevices.bind(this));

    // Audit log
    this.app.get('/api/audit', this.getAuditLog.bind(this));
    this.app.post('/api/audit', this.pushAuditLog.bind(this));
  }

  // Dataset definitions endpoints
  private async getDatasetDefinitions(req: express.Request, res: express.Response): Promise<void> {
    try {
      const { since } = req.query;
      let sql = 'SELECT * FROM dataset_definitions WHERE is_active = 1';
      const params: any[] = [];

      if (since) {
        sql += ' AND updated_at > ?';
        params.push(since);
      }

      sql += ' ORDER BY category, name';
      const definitions = await this.dbAll(sql, params);
      
      const parsedDefinitions = definitions.map(def => ({
        ...def,
        fields: JSON.parse(def.fields),
        permissions: JSON.parse(def.permissions || '[]'),
        is_active: Boolean(def.is_active)
      }));

      res.json({
        success: true,
        data: parsedDefinitions,
        sync_timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get dataset definitions',
        sync_timestamp: new Date().toISOString()
      });
    }
  }

  private async createDatasetDefinition(req: express.Request, res: express.Response): Promise<void> {
    try {
      const definition = req.body;
      const now = new Date().toISOString();
      
      const newDefinition = {
        ...definition,
        id: definition.id || crypto.randomUUID(),
        created_at: now,
        updated_at: now,
        sync_version: 1
      };

      await this.dbRun(
        `INSERT INTO dataset_definitions 
         (id, name, description, category, icon, table_name, fields, permissions, version, created_by, created_at, updated_at, is_active, sync_version) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          newDefinition.id,
          newDefinition.name,
          newDefinition.description,
          newDefinition.category,
          newDefinition.icon,
          newDefinition.table_name,
          JSON.stringify(newDefinition.fields),
          JSON.stringify(newDefinition.permissions),
          newDefinition.version,
          newDefinition.created_by,
          newDefinition.created_at,
          newDefinition.updated_at,
          newDefinition.is_active ? 1 : 0,
          newDefinition.sync_version
        ]
      );

      // Create the actual data table
      await this.createDataTableFromDefinition(newDefinition);

      res.json({
        success: true,
        data: newDefinition,
        sync_timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create dataset definition',
        sync_timestamp: new Date().toISOString()
      });
    }
  }

  // Sync operations endpoints
  private async pushOperations(req: express.Request, res: express.Response): Promise<void> {
    try {
      const { operations } = req.body;
      const conflicts: any[] = [];
      let processed = 0;

      for (const operation of operations) {
        try {
          // Check for conflicts
          const conflict = await this.detectConflict(operation);
          if (conflict) {
            conflicts.push(conflict);
            continue;
          }

          // Apply operation
          await this.applyOperation(operation);
          
          // Log the operation
          await this.dbRun(
            `INSERT INTO sync_operations 
             (id, device_id, table_name, operation, data, version, user_id, timestamp, processed) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              operation.id,
              operation.device_id,
              operation.table_name,
              operation.operation,
              JSON.stringify(operation.data),
              operation.version,
              operation.user_id,
              operation.timestamp,
              1
            ]
          );

          processed++;
        } catch (error) {
          console.error('Failed to process operation:', error);
        }
      }

      res.json({
        success: true,
        data: { processed, conflicts },
        sync_timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to push operations',
        sync_timestamp: new Date().toISOString()
      });
    }
  }

  private async pullChanges(req: express.Request, res: express.Response): Promise<void> {
    try {
      const { last_sync, tables } = req.body;
      
      let sql = 'SELECT * FROM sync_operations WHERE processed = 1';
      const params: any[] = [];

      if (last_sync) {
        sql += ' AND timestamp > ?';
        params.push(last_sync);
      }

      if (tables && tables.length > 0) {
        sql += ` AND table_name IN (${tables.map(() => '?').join(',')})`;
        params.push(...tables);
      }

      sql += ' ORDER BY timestamp ASC';
      
      const operations = await this.dbAll(sql, params);
      const conflicts = await this.dbAll('SELECT * FROM sync_conflicts WHERE resolved = 0');

      const parsedOperations = operations.map(op => ({
        ...op,
        data: JSON.parse(op.data),
        processed: Boolean(op.processed)
      }));

      const parsedConflicts = conflicts.map(conf => ({
        ...conf,
        data_1: JSON.parse(conf.data_1),
        data_2: JSON.parse(conf.data_2),
        resolved: Boolean(conf.resolved)
      }));

      res.json({
        success: true,
        data: {
          operations: parsedOperations,
          conflicts: parsedConflicts
        },
        sync_timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to pull changes',
        sync_timestamp: new Date().toISOString()
      });
    }
  }

  // Helper methods
  private async detectConflict(operation: any): Promise<any | null> {
    // Check if another device has modified the same record
    const existing = await this.dbGet(
      'SELECT * FROM sync_operations WHERE table_name = ? AND data LIKE ? AND device_id != ? AND timestamp > ?',
      [
        operation.table_name,
        `%"id":"${operation.data.id}"%`,
        operation.device_id,
        new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() // Last 24 hours
      ]
    );

    if (existing) {
      return {
        id: crypto.randomUUID(),
        table_name: operation.table_name,
        record_id: operation.data.id,
        device_id_1: operation.device_id,
        device_id_2: existing.device_id,
        data_1: operation.data,
        data_2: JSON.parse(existing.data),
        conflict_type: 'update_update'
      };
    }

    return null;
  }

  private async applyOperation(operation: any): Promise<void> {
    const { table_name, operation: op, data } = operation;

    switch (op) {
      case 'INSERT':
        const insertColumns = Object.keys(data);
        const insertPlaceholders = insertColumns.map(() => '?').join(', ');
        const insertValues = Object.values(data);
        
        await this.dbRun(
          `INSERT OR REPLACE INTO ${table_name} (${insertColumns.join(', ')}) VALUES (${insertPlaceholders})`,
          insertValues
        );
        break;

      case 'UPDATE':
        const updateColumns = Object.keys(data).filter(key => key !== 'id');
        const updateSetClause = updateColumns.map(col => `${col} = ?`).join(', ');
        const updateValues = [...updateColumns.map(col => data[col]), data.id];
        
        await this.dbRun(
          `UPDATE ${table_name} SET ${updateSetClause} WHERE id = ?`,
          updateValues
        );
        break;

      case 'DELETE':
        await this.dbRun(`DELETE FROM ${table_name} WHERE id = ?`, [data.id]);
        break;
    }
  }

  private async createDataTableFromDefinition(definition: any): Promise<void> {
    const columnDefinitions = definition.fields.map((field: any) => {
      let columnDef = `${field.name} `;
      
      switch (field.type) {
        case 'number':
          columnDef += 'REAL';
          break;
        case 'date':
          columnDef += 'DATETIME';
          break;
        case 'boolean':
          columnDef += 'INTEGER';
          break;
        default:
          columnDef += 'TEXT';
      }
      
      if (field.required) {
        columnDef += ' NOT NULL';
      }
      
      return columnDef;
    }).join(', ');

    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS ${definition.table_name} (
        id TEXT PRIMARY KEY,
        ${columnDefinitions},
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT,
        updated_by TEXT,
        sync_version INTEGER DEFAULT 1
      )
    `;

    await this.dbRun(createTableSQL);
  }

  // Additional endpoint implementations would go here...
  
  public start(): void {
    this.app.listen(this.config.port, () => {
      console.log(`Reference Data Sync Server running on port ${this.config.port}`);
      console.log(`Database: ${this.config.dbPath}`);
    });
  }

  public stop(): void {
    this.db.close();
  }
}

// Server configuration and startup
const serverConfig: ServerConfig = {
  port: 3001,
  dbPath: path.join(process.cwd(), 'reference_data_server.db'),
  allowedOrigins: ['http://localhost:3000', 'http://localhost:5173'],
  maxFileSize: '10mb'
};

// Start server if this file is run directly
if (require.main === module) {
  const server = new ReferenceDataSyncServer(serverConfig);
  server.start();
  
  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('Shutting down server...');
    server.stop();
    process.exit(0);
  });
}

export { ReferenceDataSyncServer, serverConfig };